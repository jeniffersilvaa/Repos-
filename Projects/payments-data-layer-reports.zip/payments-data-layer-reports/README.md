# Data Layer Reports

A aplicação Data Layer Reports, comunmente chamada de DALAR, é responsável pela geração de relatórios assincronos, atendendo tanto clientes internos quanto externos.

## Monitoramento

- data-layer-reports (client) 
    - [[STG](https://argocd.stone.tech/applications/argocd/pay-data-layer-reports-stg?orphaned=false&resource=)] [[PRD](https://argocd.stone.tech/applications/argocd/pay-data-layer-reports-prd?orphaned=false&resource=)] ArgoCD
    - [[STG](https://stone-tech.datadoghq.com/apm/entity/service%3Apayments-data-layer-reports?dependencyMap.showNetworkMetrics=false&env=staging&fromUser=false&graphType=waterfall&groupMapByOperation=null&operationName=Microsoft.AspNetCore.server&panels=qson%3A%28data%3A%28%29%2Cversion%3A%210%29&resources=qson%3A%28data%3A%28visible%3A%21t%2Chits%3A%28selected%3Atotal%29%2Cerrors%3A%28selected%3Atotal%29%2Clatency%3A%28selected%3Aavg%29%2CtopN%3Aall%29%2Cversion%3A%211%29&shouldShowLegend=true&spanKind=server&summary=qson%3A%28data%3A%28visible%3A%21t%2Cchanges%3A%28%29%2Cerrors%3A%28selected%3Acount%29%2Chits%3A%28selected%3Arate%29%2Clatency%3A%28selected%3Alatency%2Cslot%3A%28agg%3A50%29%2Cdistribution%3A%28maxPercentile%3A%2199.9%2CisLogScale%3A%21f%29%2CshowTraceOutliers%3A%21t%29%2Csublayer%3A%28slot%3A%28layers%3AserviceAndInferred%29%2Cselected%3Apercentage%29%2ClagMetrics%3A%28selectedMetric%3A%21s%2CselectedGroupBy%3A%21s%29%29%2Cversion%3A%211%29&traceQuery=&start=1765896639210&end=1765900239210&paused=false)] [[PRD](https://stone-tech.datadoghq.com/apm/entity/service%3Apayments-data-layer-reports?dependencyMap.showNetworkMetrics=false&env=production&fromUser=false&graphType=waterfall&groupMapByOperation=null&operationName=Microsoft.AspNetCore.server&panels=qson%3A%28data%3A%28%29%2Cversion%3A%210%29&resources=qson%3A%28data%3A%28visible%3A%21t%2Chits%3A%28selected%3Atotal%29%2Cerrors%3A%28selected%3Atotal%29%2Clatency%3A%28selected%3Aavg%29%2CtopN%3Aall%29%2Cversion%3A%211%29&shouldShowLegend=true&spanKind=server&summary=qson%3A%28data%3A%28visible%3A%21t%2Cchanges%3A%28%29%2Cerrors%3A%28selected%3Acount%29%2Chits%3A%28selected%3Arate%29%2Clatency%3A%28selected%3Alatency%2Cslot%3A%28agg%3A50%29%2Cdistribution%3A%28maxPercentile%3A%2199.9%2CisLogScale%3A%21f%29%2CshowTraceOutliers%3A%21t%29%2Csublayer%3A%28slot%3A%28layers%3AserviceAndInferred%29%2Cselected%3Apercentage%29%2ClagMetrics%3A%28selectedMetric%3A%21s%2CselectedGroupBy%3A%21s%29%29%2Cversion%3A%211%29&traceQuery=&start=1765896639210&end=1765900239210&paused=false)] Datadog - APM
    - [[STG](https://stone-tech.datadoghq.com/logs?query=service%3Adata-layer-reports%20env%3Astaging&agg_m=count&agg_m_source=base&agg_t=count&cols=host%2Cservice&fromUser=true&messageDisplay=inline&refresh_mode=sliding&storage=hot&stream_sort=desc&viz=stream)] [[PRD](https://stone-tech.datadoghq.com/logs?query=service%3Adata-layer-reports%20env%3Aproduction&agg_m=count&agg_m_source=base&agg_t=count&cols=host%2Cservice&fromUser=true&messageDisplay=inline&refresh_mode=sliding&storage=hot&stream_sort=desc&viz=stream)] Datadog - Logs
    - [[STG](https://stone-tech.datadoghq.com/dash/integration/57/kubernetes-pods-overview?fromUser=false&refresh_mode=sliding&tpl_var_deployment%5B0%5D=pay-data-layer-reports-stg)] [[PRD](https://stone-tech.datadoghq.com/dash/integration/57/kubernetes-pods-overview?fromUser=false&refresh_mode=sliding&tpl_var_deployment%5B0%5D=pay-data-layer-reports-prd)] Datadog - Pods Overview
- data-layer-reports-worker-1
    - [[STG](https://argocd.stone.tech/applications/argocd/pay-data-layer-reports-worker-1-stg?orphaned=false&resource=)] [[PRD](https://argocd.stone.tech/applications/argocd/pay-data-layer-reports-worker-1-prd?orphaned=false&resource=)] ArgoCD
    - [[STG](https://stone-tech.datadoghq.com/apm/entity/service%3Adata-layer-reports-worker-1?dependencyMap.showNetworkMetrics=false&env=staging&fromUser=false&graphType=waterfall&groupMapByOperation=null&historicalData=true&panels=qson%3A%28data%3A%28%29%2Cversion%3A%210%29&resources=qson%3A%28data%3A%28visible%3A%21t%2Chits%3A%28selected%3Atotal%29%2Cerrors%3A%28selected%3Atotal%29%2Clatency%3A%28selected%3Aavg%29%2CtopN%3Aall%29%2Cversion%3A%211%29&shouldShowLegend=true&spanKind=server&summary=qson%3A%28data%3A%28visible%3A%21t%2Cchanges%3A%28%29%2Cerrors%3A%28selected%3Acount%29%2Chits%3A%28selected%3Arate%29%2Clatency%3A%28selected%3Alatency%2Cslot%3A%28agg%3A50%29%2Cdistribution%3A%28maxPercentile%3A%2199.9%2CisLogScale%3A%21f%29%2CshowTraceOutliers%3A%21t%29%2Csublayer%3A%28slot%3A%28layers%3AserviceAndInferred%29%2Cselected%3Apercentage%29%2ClagMetrics%3A%28selectedMetric%3A%21s%2CselectedGroupBy%3A%21s%29%29%2Cversion%3A%211%29&traceQuery=&start=1765896715697&end=1765900315697&paused=false)] [[PRD](https://stone-tech.datadoghq.com/apm/entity/service%3Adata-layer-reports-worker-1?dependencyMap.showNetworkMetrics=false&env=production&fromUser=false&graphType=waterfall&groupMapByOperation=null&historicalData=true&panels=qson%3A%28data%3A%28%29%2Cversion%3A%210%29&resources=qson%3A%28data%3A%28visible%3A%21t%2Chits%3A%28selected%3Atotal%29%2Cerrors%3A%28selected%3Atotal%29%2Clatency%3A%28selected%3Aavg%29%2CtopN%3Aall%29%2Cversion%3A%211%29&shouldShowLegend=true&spanKind=server&summary=qson%3A%28data%3A%28visible%3A%21t%2Cchanges%3A%28%29%2Cerrors%3A%28selected%3Acount%29%2Chits%3A%28selected%3Arate%29%2Clatency%3A%28selected%3Alatency%2Cslot%3A%28agg%3A50%29%2Cdistribution%3A%28maxPercentile%3A%2199.9%2CisLogScale%3A%21f%29%2CshowTraceOutliers%3A%21t%29%2Csublayer%3A%28slot%3A%28layers%3AserviceAndInferred%29%2Cselected%3Apercentage%29%2ClagMetrics%3A%28selectedMetric%3A%21s%2CselectedGroupBy%3A%21s%29%29%2Cversion%3A%211%29&traceQuery=&start=1765896715697&end=1765900315697&paused=false)] Datadog - APM
    - [[STG](https://stone-tech.datadoghq.com/logs?query=service%3Adata-layer-reports-worker-1%20env%3Astaging&agg_m=count&agg_m_source=base&agg_t=count&cols=host%2Cservice&fromUser=true&messageDisplay=inline&refresh_mode=sliding&storage=hot&stream_sort=desc&viz=stream)] [[PRD](https://stone-tech.datadoghq.com/logs?query=service%3Adata-layer-reports-worker-1%20env%3Aproduction&agg_m=count&agg_m_source=base&agg_t=count&cols=host%2Cservice&fromUser=true&messageDisplay=inline&refresh_mode=sliding&storage=hot&stream_sort=desc&viz=stream)] Datadog - Logs 
    - [[STG](https://stone-tech.datadoghq.com/dash/integration/57/kubernetes-pods-overview?fromUser=false&refresh_mode=sliding&tpl_var_deployment%5B0%5D=pay-data-layer-reports-worker-1-stg)] [[PRD](https://stone-tech.datadoghq.com/dash/integration/57/kubernetes-pods-overview?fromUser=false&refresh_mode=sliding&tpl_var_deployment%5B0%5D=pay-data-layer-reports-worker-1-prd)] Datadog - Pods Overview
- data-layer-reports-pre-deploy
    - [[STG](https://argocd.stone.tech/applications/argocd/pay-data-layer-reports-pre-deploy-stg?orphaned=false&resource=)] [[PRD](https://argocd.stone.tech/applications/argocd/pay-data-layer-reports-pre-deploy-prd?orphaned=false&resource=)] ArgoCD
    - [[STG](https://stone-tech.datadoghq.com/apm/entity/service%3Adata-layer-reports-pre-deploy?dependencyMap.showNetworkMetrics=false&env=staging&fromUser=false&graphType=waterfall&groupMapByOperation=null&panels=qson%3A%28data%3A%28%29%2Cversion%3A%210%29&resources=qson%3A%28data%3A%28visible%3A%21t%2Chits%3A%28selected%3Atotal%29%2Cerrors%3A%28selected%3Atotal%29%2Clatency%3A%28selected%3Aavg%29%2CtopN%3Aall%29%2Cversion%3A%211%29&shouldShowLegend=true&spanKind=server&summary=qson%3A%28data%3A%28visible%3A%21t%2Cchanges%3A%28%29%2Cerrors%3A%28selected%3Acount%29%2Chits%3A%28selected%3Arate%29%2Clatency%3A%28selected%3Alatency%2Cslot%3A%28agg%3A50%29%2Cdistribution%3A%28maxPercentile%3A%2199.9%2CisLogScale%3A%21f%29%2CshowTraceOutliers%3A%21t%29%2Csublayer%3A%28slot%3A%28layers%3AserviceAndInferred%29%2Cselected%3Apercentage%29%2ClagMetrics%3A%28selectedMetric%3A%21s%2CselectedGroupBy%3A%21s%29%29%2Cversion%3A%211%29&traceQuery=&start=1765896748698&end=1765900348698&paused=false)] [[PRD](https://stone-tech.datadoghq.com/apm/entity/service%3Adata-layer-reports-pre-deploy?dependencyMap.showNetworkMetrics=false&env=production&fromUser=false&graphType=waterfall&groupMapByOperation=null&panels=qson%3A%28data%3A%28%29%2Cversion%3A%210%29&resources=qson%3A%28data%3A%28visible%3A%21t%2Chits%3A%28selected%3Atotal%29%2Cerrors%3A%28selected%3Atotal%29%2Clatency%3A%28selected%3Aavg%29%2CtopN%3Aall%29%2Cversion%3A%211%29&shouldShowLegend=true&spanKind=server&summary=qson%3A%28data%3A%28visible%3A%21t%2Cchanges%3A%28%29%2Cerrors%3A%28selected%3Acount%29%2Chits%3A%28selected%3Arate%29%2Clatency%3A%28selected%3Alatency%2Cslot%3A%28agg%3A50%29%2Cdistribution%3A%28maxPercentile%3A%2199.9%2CisLogScale%3A%21f%29%2CshowTraceOutliers%3A%21t%29%2Csublayer%3A%28slot%3A%28layers%3AserviceAndInferred%29%2Cselected%3Apercentage%29%2ClagMetrics%3A%28selectedMetric%3A%21s%2CselectedGroupBy%3A%21s%29%29%2Cversion%3A%211%29&traceQuery=&start=1765896748698&end=1765900348698&paused=false)] Datadog - APM
    - [[STG](https://stone-tech.datadoghq.com/logs?query=service%3Adata-layer-reports-pre-deploy%20env%3Astaging&agg_m=count&agg_m_source=base&agg_t=count&cols=host%2Cservice&fromUser=true&messageDisplay=inline&refresh_mode=sliding&storage=hot&stream_sort=desc&viz=stream)] [[PRD](https://stone-tech.datadoghq.com/logs?query=service%3Adata-layer-reports-pre-deploy%20env%3Aproduction&agg_m=count&agg_m_source=base&agg_t=count&cols=host%2Cservice&fromUser=true&messageDisplay=inline&refresh_mode=sliding&storage=hot&stream_sort=desc&viz=stream)] Datadog - Logs 
    - [[STG](https://stone-tech.datadoghq.com/dash/integration/57/kubernetes-pods-overview?fromUser=false&refresh_mode=sliding&tpl_var_deployment%5B0%5D=pay-data-layer-reports-pre-deploy-stg)] [[PRD](https://stone-tech.datadoghq.com/dash/integration/57/kubernetes-pods-overview?fromUser=false&refresh_mode=sliding&tpl_var_deployment%5B0%5D=pay-data-layer-reports-pre-deploy-prd)] Datadog - Pods Overview
- hangfire
    - [[STG](https://data-layer-reports-stg.stone.tech/hangfire/)] [[PRD](https://data-layer-reports-prd.stone.tech/hangfire/)] Fluxo principal
    - [[PRD](https://data-layer-reports-pre-deploy-prd.stone.tech/hangfire)] Fluxo de pre deploy
    

## 🛠️ Desenvolvimento Local

Para setup do ambiente de desenvolvimento, comandos úteis e estrutura do projeto, consulte [docs/development/DEVELOPMENT.md](docs/development/DEVELOPMENT.md).

## 🧪 Testes

[![Tests](https://github.com/stone-payments/payments-data-layer-reports/workflows/Tests/badge.svg)](https://github.com/stone-payments/payments-data-layer-reports/actions/workflows/tests.yaml)

```bash
make test-unit      # Durante desenvolvimento (rápido)
make test-phased    # Antes de commit (completo)
make test-coverage  # Com cobertura de código
```

> 📖 **Documentação detalhada:** [docs/development/TESTING.md](docs/development/TESTING.md) - arquitetura de testes, padrões, helpers e guia para criação de novos testes.

## 📊 Performance Benchmark

Existem duas formas de executar benchmarks: localmente ou pela action no PR.

### Execução local
```bash
# Listar benchmarks disponíveis
dotnet run --project tests/PaymentsDataLayerReports.Benchmark/PaymentsDataLayerReports.Benchmark.csproj \
  --configuration Release -- --list flat

# Rodar todos
dotnet run --project tests/PaymentsDataLayerReports.Benchmark/PaymentsDataLayerReports.Benchmark.csproj \
  --configuration Release -- --filter '*'

# Rodar um benchmark específico
dotnet run --project tests/PaymentsDataLayerReports.Benchmark/PaymentsDataLayerReports.Benchmark.csproj \
  --configuration Release -- --filter '*ReceivablesModifier*'
```
> Os resultados ficam em `tests/PaymentsDataLayerReports.Benchmark/.Results`.

### Disparar a action no PR
Comente no PR com um dos comandos abaixo:

1. **Lista de benchmarks disponíveis (padrão)**:
   ```
   !benchmark
   !benchmark list
   ```
2. **Benchmark completo** (compara base vs PR):
   ```
   !benchmark all
   !benchmark -all
   ```
3. **Benchmark específico** (compara base vs PR):
   ```
   !benchmark <benchmark_name>
   !benchmark-<benchmark_name>
   # exemplo:
   !benchmark ReceivablesModifier
   ```
4. **Benchmark de apenas uma branch** (opcional):
   ```
   !benchmark-source <benchmark_name>  # executa só na base
   !benchmark-target <benchmark_name>  # executa só no PR
   # exemplo:
   !benchmark-target ReceivablesModifier
   ```
   > Para executar todos em uma branch: `!benchmark-source all` ou `!benchmark-target all`.

## Arquitetura

A aplicação é composta por uma API Rest, via .NET minimal api, e workers, via Hangfire background jobs.

No lado da API Rest, os endpoints são simples, apenas utilizados para enfileirar os jobs de geração de relatórios e também para buscar o status do processamento.

Quanto aos workers, são neles em que o processamento de fato é feito, sendo que cada relatório pode acabar sendo realizado em mais de um worker.

> 📖 **Documentação detalhada:** [docs/architecture/ARCHITECTURE.md](docs/architecture/ARCHITECTURE.md) - fluxos de dados, fontes e destinos, considerações de performance.

## Relatórios

A aplicação gera dois tipos de relatórios com propósitos distintos:

### Relatórios Legados (CSV bruto)

Projetados para pós-processamento por outros times, replicam o schema dos endpoints da Data Layer API.

| Tipo | Endpoint | Descrição |
|------|----------|-----------|
| `charges_events` | `POST /charges/report` | Cada linha = 1 evento de charge |
| `charges_list` | `POST /charges/report` | Cada linha = 1 charge completa (agregada) |

- **Entrega:** Polling via `GET /charges/report/{id}`
- **Fonte:** S3 DeltaTable (dados históricos em Parquet)

### Relatórios Produto Final (user-friendly)

Relatórios finais com schema simplificado, entregues diretamente ao cliente.

| Tipo | Endpoint | Fonte | Descrição |
|------|----------|-------|-----------|
| `sales_stone` / `sales_ton` | `POST /v1/reports` | ES (≤6 meses) / S3 (>6 meses) | Vendas (a partir de charges) - formato legado |
| `sale` | `POST /v1/reports` | ES (≤6 meses) / S3 (>6 meses) | Vendas (a partir de charges) - formato ONE STONE |
| `receivables` | `POST /v1/reports` | ES (≤6 meses) / S3 (>6 meses) | Recebimentos (a partir de finmov) - formato ONE STONE |
| `receivables_legacy` | `POST /v1/reports` | ES (≤6 meses) / S3 (>6 meses) | Recebimentos (a partir de finmov) - formato legado |
| `orders` | `POST /v1/reports` | Elasticsearch | Pedidos |

- **Entrega:** Email, Webhook e/ou Polling via `GET /v1/reports/{id}`
- **Formatos:** CSV, XLSX

> 📖 **Documentação detalhada:**
> - [docs/architecture/REPORT_FLOWS.md](docs/architecture/REPORT_FLOWS.md) - Fluxos de processamento, arquitetura distribuída, características de performance
> - [docs/domain/CHARGES_FROM_EVENTS.md](docs/domain/CHARGES_FROM_EVENTS.md) - Lógica de agregação de eventos em charges

## Endpoints

A documentação dos endpoints pode ser acessada via Swagger: [[STG](https://data-layer-reports-stg.stone.tech/swagger/index.html)] [[PRD](https://data-layer-reports-prd.stone.tech/swagger/index.html)]

## Workers

### ChargeReportWorker

- Gera relatórios de charges a partir do ElasticSearch.
- Triggado diretamente no endpoint, apenas quando o relatório for de tipo "charges_list" e o range de datas estiver dentro dos ultimos 6 meses.

### ChargeReportS3Dispatch

- Enfileira os jobs de geração de relatórios, considerando os jobs necessários para cada ReportType.
- Os jobs são enfileirados utilizando ContinueJobWith defindo o ID do disptach como parent, ou seja, os jobs são enfileirados apenas após o dispatch finalizar com sucesso.
- O dispatch cria e salva o arquivo de metadados do relatório, neste arquivo são registrados os ids de todos os jobs enfileirados, bem como todos os parametros do relatório solicitado.
- Este job é triggado diretamente pelo endpoint quando o range de datas estiver fora dos ultimos 6 meses.


### ChargeReportS3Worker

- Gera relatórios a partir do S3.
- Acessa uma unica partição da DeltaTable, baixa os arquivos e processa os dados localmente.
- Extraí eventos recentes do indice de charge_event do Elasticsearch, garantindo que eventos recentes de transações antigas estejam presentes no relatório. 
- Triggado ChargeReportS3Dispatch.

### ChargeReportS3Concat

- Concatena os arquivos de relatório gerados pelo ChargeReportS3Worker.
- Triggado ChargeReportS3Dispatch.

### FinMovWorker

- Gera relatórios de movimentações financeiras (recebíveis) a partir do Elasticsearch.
- Consulta dados via Data Layer API com paginação por cursor.
- Faz streaming direto para S3.

### OrderReportESWorker

- Gera relatórios de pedidos (orders) a partir do Elasticsearch.
- Consulta dados via Data Layer API com paginação por cursor.
- Faz streaming direto para S3.

## Deployments

A DALAR é uma aplicação com multiplos deploys, a mesma base de códigos, só que com instancias diferentes.

A especificidades e configurações de cada deploy podem ser vistas em [/chart/api](/chart/api).

De forma resumida:
- data-layer-reports (client)
    - API REST (recebe requisições HTTP e enfileira jobs)
- data-layer-reports-worker-1
    - Processa relatórios via S3/DeltaTable
    - ChargeReportS3Dispatch, ChargeReportS3Worker, ChargeReportS3Concat
- data-layer-reports-worker-2
    - Processa relatórios via Elasticsearch e notificações
    - ChargeReportWorker, FinMovWorker, OrderReportESWorker
- data-layer-reports-pre-deploy
    - Deployment para testes (shadow testing)
    - Permite validar alterações sem afetar dados entregues ao cliente

## Testes em Pre Deploy

Através do deployment [data-layer-reports-pre-deploy](/chart/api/data-layer-reports-pre-deploy) podemos testar uma nova release antes de disponibilizar para o cliente final, possibilitando validar tanto lógicas novas quanto o impacto em desempenho.

Para cada relatório solicitado em produção, o endpoint `POST /charges/report` faz uma chamada FireAndForget para o endpoint `POST /charges/report/pre-deploy` do workload de pre-deploy.

Caso esse workload esteja sem nenhum pod, o que é esperado para o dia a dia, a chamada irá falhar, mas como nenhuma exception ou log são gerados, o fluxo oficial de produção não será afetado.

Ao subir uma nova feature, após o merge na branch de release na `main`, podemos triggar o workflow [DALAR Pre Deploy - Deploy](.github/workflows/karavela_containers_deploy_pre_deploy.yaml) para subir a feature no workload de pre-deploy. Neste momento, as requisições FireAndForget feitas no fluxo oficial chegarão neste deployment e o fluxo de produção será duplicado, permitindo um `shadow test` sem impactos ao cliente

Quando as validações estiverem concluídas, ou quando a alteração for mínima a ponto de não precisar validar em pre-deploy, basta triggar a action do deployment afetado, ou de multiplos deployments, conforme o necessário para cada feature/fix.

## Deploy de Breaking Changes

Quando uma release contém breaking changes, ou seja, alterações que afetam a compatibilidade com a versão anterior, é necessário uma atenção especial durante o deploy.

> 📖 **Documentação completa:** [docs/development/BREAKING_CHANGES.md](docs/development/BREAKING_CHANGES.md) - contém detalhes sobre arquitetura distribuída, serialização do Hangfire, cenários de risco e procedimento passo a passo.

### Por que Breaking Changes são Críticos

Como temos fluxos de relatórios que são gerados em arquivos parciais e são posteriormente concatenados, podemos ter casos em que um relatório tem seu processamento iniciado antes da release e finalizado após a release, ou seja, os arquivos parciais serão gerados com versões diferentes.

O Hangfire serializa os parâmetros dos workers em JSON no Redis. Alterações em classes como `ChargeReportsWorkerParameters`, `FinMovESWorkerParameters` ou `OrderReportWorkerParameters` podem quebrar jobs que foram enfileirados antes do deploy.

### Procedimento de Deploy Controlado

Para isto, devemos:
1. Fazer redeploy da versão antiga removendo o consumo da fila de dispatch
2. Relatórios em processamento continuam sendo processados, mas novos relatórios permanecem na fila
3. Acompanhar os processamentos até que tudo seja finalizado
4. Subir nova versão, voltando o consumo da fila de dispatch

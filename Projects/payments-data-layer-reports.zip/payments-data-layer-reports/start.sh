#!/bin/bash

# Export all secrets from /secrets directory
for secret_file in /secrets/*; do
  if [ -f "$secret_file" ]; then
    secret_name=$(basename "$secret_file")
    secret_value=$(cat "$secret_file")
    export "$secret_name"="$secret_value"
    echo "Exported secret: $secret_name"
  fi
done

# Start the application
dotnet PaymentsDataLayerReports.Application.dll
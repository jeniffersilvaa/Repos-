# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [1.44.1](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.44.0...v1.44.1) (2026-04-13)


### Bug Fixes

* Include cetFeeAmount in discounts calculation ([dfd5642](https://github.com/stone-payments/payments-data-layer-reports/commit/dfd5642aa79f420b31c8eaea8b57588578d221a1))

## [1.44.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.43.2...v1.44.0) (2026-04-09)


### Features

* Add fee turbo calculation on legacy reports ([ca0c2c2](https://github.com/stone-payments/payments-data-layer-reports/commit/ca0c2c2fed75314c16c412bf8d5611cedefcecdc))
* Add turbo anticipation fee support to OneStone sales and receivables reports ([782135b](https://github.com/stone-payments/payments-data-layer-reports/commit/782135b2d969198fc1c6fca41e42f87d74aa65b4))

### [1.43.2](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.43.1...v1.43.2) (2026-04-02)


### Bug Fixes

* add missing card_transaction__capture_date to realtime mapper ([40c409c](https://github.com/stone-payments/payments-data-layer-reports/commit/40c409c958e7d11d79f632a4756c74097ed6803a))
* Fix receivables report date ([c62adb7](https://github.com/stone-payments/payments-data-layer-reports/commit/c62adb74454cbded726d9e28302422de73b5ec63))

### [1.43.1](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.43.0...v1.43.1) (2026-04-01)


### Bug Fixes

* always normalize receivables to receivables_legacy at dispatch ([9e773c5](https://github.com/stone-payments/payments-data-layer-reports/commit/9e773c5b6b0836a740c38bbf358a906647dc1ddb))
* add missing card_transaction__capture_date to realtime charge events mapper ([40c409c](https://github.com/stone-payments/payments-data-layer-reports/commit/40c409c9))
* Fix ton boleto ([b765b55](https://github.com/stone-payments/payments-data-layer-reports/commit/b765b55cbf82f060d61dc12a0a7d4d50450be330))
* normalize receivables type to legacy at dispatch when FORCE_LEGACY_RECEIVABLES is set ([fffdc88](https://github.com/stone-payments/payments-data-layer-reports/commit/fffdc88b9c31cb8c03871033d1acb9194599704a))

## [1.43.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.42.0...v1.43.0) (2026-03-31)


### Features

* Add one stone sale and receivables reports ([576a889](https://github.com/stone-payments/payments-data-layer-reports/commit/576a88946397796654a4068fb2f3a7dde2632dd9))


### Bug Fixes

* Use correct CSV separator in SortChargesByCreatedAt ([365583a](https://github.com/stone-payments/payments-data-layer-reports/commit/365583a9abcfe037f0398031bf153aee7271b166))

## [1.42.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.41.2...v1.42.0) (2026-03-30)


### Features

* Adds processed_at column to sorting logic for deduplication in charge reports ([39a21ee](https://github.com/stone-payments/payments-data-layer-reports/commit/39a21ee0ca0778fd4911391e64c52a414e13172e))

### [1.41.2](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.41.0...v1.41.2) (2026-03-30)


### Bug Fixes

* Adds a method that prevents the accumulation of IDs with each call ([173e761](https://github.com/stone-payments/payments-data-layer-reports/commit/173e7616016b913bc81557ca93b64d8e64739558))
* Calculation of MDR discount when using Pix payment method ([9078634](https://github.com/stone-payments/payments-data-layer-reports/commit/90786348e42998d2460a6475b797465b07c41135))
* Fix sales reports canceled amount ([79218fc](https://github.com/stone-payments/payments-data-layer-reports/commit/79218fc98622bc3a7dd442e2d60c5ba1939ec603))
* Mapping the correlation ID for pre-deployment ([37dfcb9](https://github.com/stone-payments/payments-data-layer-reports/commit/37dfcb95b6c536b017578be31cbe95f528ca3ec8))

### [1.41.1](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.41.0...v1.41.1) (2026-03-30)


### Bug Fixes

* Adds a method that prevents the accumulation of IDs with each call ([173e761](https://github.com/stone-payments/payments-data-layer-reports/commit/173e7616016b913bc81557ca93b64d8e64739558))
* Calculation of MDR discount when using Pix payment method ([9078634](https://github.com/stone-payments/payments-data-layer-reports/commit/90786348e42998d2460a6475b797465b07c41135))
* Fix sales reports canceled amount ([5498a0b](https://github.com/stone-payments/payments-data-layer-reports/commit/5498a0b846ee983c9d9254582177c33e4c740930))

## [1.41.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.40.0...v1.41.0) (2026-03-25)


### Features

* Adds pre deploy forwarding and correlationId to POST /v1/reports ([37a074c](https://github.com/stone-payments/payments-data-layer-reports/commit/37a074c2d3d7710878b753ee99a9629f4037b93e))

## [1.40.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.39.0...v1.40.0) (2026-03-13)


### Features

* create utility class report query filters ([85393ef](https://github.com/stone-payments/payments-data-layer-reports/commit/85393ef84735e7ad7586fc5f3a9ebfe38d5678b9))
* Implements event deduplication in ChargeListReportService ([d6d6d3a](https://github.com/stone-payments/payments-data-layer-reports/commit/d6d6d3a533d4cc358e5fca2fd7e8feb7bd865ef7))
* Updates Map method in IdMapperService to return non-nullable ([0ad524c](https://github.com/stone-payments/payments-data-layer-reports/commit/0ad524ce05007d88752b0319bcb1cfd38533dbcb))

## [1.39.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.38.0...v1.39.0) (2026-03-10)


### Features

* Add reportsettings for financial movement category filtering ([721d62b](https://github.com/stone-payments/payments-data-layer-reports/commit/721d62b1aad3ac6847eb0000614ca75ef4eeecaa))
* create utility class report query filters ([80523e0](https://github.com/stone-payments/payments-data-layer-reports/commit/80523e08009f06bc64f762c7dfdb2e37c9b1f6e0))
* Populates report metadata from merchant id summary ([651fd09](https://github.com/stone-payments/payments-data-layer-reports/commit/651fd093d318a635523dc70e09663b03c29636b5))

## [1.38.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.37.0...v1.38.0) (2026-03-05)


### Features

* add poi types enumerable on endpoint and worker parameters ([1888d89](https://github.com/stone-payments/payments-data-layer-reports/commit/1888d89da8740c690c27654fb914837558c9a2e7))
* Adds new reporting parameters for IDs mapped in ESReceivableReportEnqueueService ([0fb2bc4](https://github.com/stone-payments/payments-data-layer-reports/commit/0fb2bc4d816c3c4b602f65814a3e6e8de7a64e52))
* Padronize orders params ([6a031ce](https://github.com/stone-payments/payments-data-layer-reports/commit/6a031ce9572261239a69c6c830ec9b0bf493ebff))
### [1.37.1](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.37.0...v1.37.1) (2026-03-06)


### Bug Fixes

* Fix boleto discount serialization ([db28f41](https://github.com/stone-payments/payments-data-layer-reports/commit/db28f41d55145808297243e4484c08d6bb9c8b13))

## [1.37.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.36.1...v1.37.0) (2026-03-02)


### Features

* Adds IIdMapperService and integrates it with PostHandler for identifier mapping ([d45070a](https://github.com/stone-payments/payments-data-layer-reports/commit/d45070a0681507b2b545fe10ceacbc551fbb8c8f))

### [1.36.1](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.36.0...v1.36.1) (2026-02-26)


### Bug Fixes

* Updates the billing list configuration to reflect the correct column ([9739920](https://github.com/stone-payments/payments-data-layer-reports/commit/97399208126d5185129260d479d6b8e8037bf25d))

## [1.36.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.35.1...v1.36.0) (2026-02-23)


### Features

* Implements a mechanism for mapping OneStone IDs to legacy IDs ([7c4449b](https://github.com/stone-payments/payments-data-layer-reports/commit/7c4449b1b34a81edadc9946772f873f85752b8a0))


### Bug Fixes

* Changes position of the created at column in ChargeCsvMapper ([b83a997](https://github.com/stone-payments/payments-data-layer-reports/commit/b83a9974ef082df85f3a119381686c983381e6ad))

### [1.35.1](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.35.0...v1.35.1) (2026-02-20)


### Bug Fixes

* Add LatestEventDatetime to ChargeFinancialMovement model and mapper ([e13bab5](https://github.com/stone-payments/payments-data-layer-reports/commit/e13bab5272644328bd2482d83f879829a693d888))

## [1.35.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.34.0...v1.35.0) (2026-02-12)


### Features

* Add xlsx support for charges_list report type ([f66cc8a](https://github.com/stone-payments/payments-data-layer-reports/commit/f66cc8a1679b73fac2944ad642e43cdce180397c))
* Adds a cet fee validation mechanism ([1da1a88](https://github.com/stone-payments/payments-data-layer-reports/commit/1da1a88cf64f2bc9d2e0347ec3f23892717afcd1))
* Adds sales modifier for csv sales mapping ([4ef0581](https://github.com/stone-payments/payments-data-layer-reports/commit/4ef058139fa7256905960a9c5518bbd4e04aa324))


### Bug Fixes

* **docs:** Correct spelling error in README.md ([c4e1c31](https://github.com/stone-payments/payments-data-layer-reports/commit/c4e1c3184e6f25c4af917ae7e803cbdcca411e14))

## [1.34.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.33.0...v1.34.0) (2026-02-03)

### Bug Fixes

* throw error when build real time file ([bb6233e](https://github.com/stone-payments/payments-data-layer-reports/commit/bb6233e521d5d3b97126555a3755b0e8c9e47e65))

## [1.33.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.32.1...v1.33.0) (2026-01-15)


### Features

* config env vars value chart stg worker 2 ([723a146](https://github.com/stone-payments/payments-data-layer-reports/commit/723a146362704d2788b8f33306d0668c7e7b6938))
* create deploy file to worker 2 ([b347d38](https://github.com/stone-payments/payments-data-layer-reports/commit/b347d38a750bde16d3f0b697536a80f3c782eb7b))
* create staging application files to default [skip ci] - created by karavela-portal-applications-user ([29b4738](https://github.com/stone-payments/payments-data-layer-reports/commit/29b47381e305ddbf97abcda529d7f5dc36db0261))
* create staging application files to default [skip ci] - created by karavela-portal-applications-user ([bc15302](https://github.com/stone-payments/payments-data-layer-reports/commit/bc153029f9747925ec9139a6caee0ec80b4c14ab))
* create staging application files to develop [skip ci] - created by karavela-portal-applications-user ([575b6c5](https://github.com/stone-payments/payments-data-layer-reports/commit/575b6c5ce3b3f3205fa2ab6f192f3cec3afb6abb))
* create staging application files to develop [skip ci] - created by karavela-portal-applications-user ([df6a210](https://github.com/stone-payments/payments-data-layer-reports/commit/df6a2103480c42d7dcb48a1af5379118ca345ddd))
* create workflows files in default branch [skip ci] - created by karavela-portal-applications-user ([564b1b1](https://github.com/stone-payments/payments-data-layer-reports/commit/564b1b1dde4002a914a131755f0c60611d75ec7f))
* create workflows files in default branch [skip ci] - created by karavela-portal-applications-user ([a56211c](https://github.com/stone-payments/payments-data-layer-reports/commit/a56211c093dc0a21a0ff8a8dbc1ef267b7e97089))
* create workflows files in default branch [skip ci] - created by karavela-portal-applications-user ([a9caea2](https://github.com/stone-payments/payments-data-layer-reports/commit/a9caea223e2215c5d85ddbd5f1190f5f4e851967))
* create workflows files in default branch [skip ci] - created by karavela-portal-applications-user ([406e799](https://github.com/stone-payments/payments-data-layer-reports/commit/406e799051949a88cff91bde77cfd92d5d9e547b))
* create workflows files in default branch [skip ci] - created by karavela-portal-applications-user ([28e4b5b](https://github.com/stone-payments/payments-data-layer-reports/commit/28e4b5bdd0ab9ef291391a3e8fb4a98c73af4b03))
* create workflows files in develop branch [skip ci] - created by karavela-portal-applications-user ([574220c](https://github.com/stone-payments/payments-data-layer-reports/commit/574220cb2ef3e50c25da68ec88e09d4b0af2e4ff))
* create workflows files in develop branch [skip ci] - created by karavela-portal-applications-user ([eb9e2b4](https://github.com/stone-payments/payments-data-layer-reports/commit/eb9e2b4940ca5c51a3d26f9371901f6c2cabbcd5))
* create workflows files in develop branch [skip ci] - created by karavela-portal-applications-user ([ed8c3a1](https://github.com/stone-payments/payments-data-layer-reports/commit/ed8c3a163ed7ce5a497e3a289de1119457feb281))
* create workflows files in develop branch [skip ci] - created by karavela-portal-applications-user ([d2e6dc1](https://github.com/stone-payments/payments-data-layer-reports/commit/d2e6dc1971b20dedd9dce45f4cab256e760f03f2))
* create workflows files in develop branch [skip ci] - created by karavela-portal-applications-user ([afce564](https://github.com/stone-payments/payments-data-layer-reports/commit/afce564cf020699e8d84fd1a337338f4883b2ef3))
* new application added to the catalog to default [skip ci] - created by karavela-portal-applications-user ([0ba7472](https://github.com/stone-payments/payments-data-layer-reports/commit/0ba7472359d0ab885c7e0eee76039e2508ca782f))
* new application added to the catalog to default [skip ci] - created by karavela-portal-applications-user ([0705ae0](https://github.com/stone-payments/payments-data-layer-reports/commit/0705ae0cb0fb4e5b14eda165fe4b1eae28329528))
* new application added to the catalog to develop [skip ci] - created by karavela-portal-applications-user ([a7dfb52](https://github.com/stone-payments/payments-data-layer-reports/commit/a7dfb525822971000a5c8209efa3d229477d5840))
* new application added to the catalog to develop [skip ci] - created by karavela-portal-applications-user ([18e460b](https://github.com/stone-payments/payments-data-layer-reports/commit/18e460b3f00de221d7a8d5db2d89dfdf421be55c))

### [1.32.1](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.32.0...v1.32.1) (2026-01-14)


### Bug Fixes

* Fix dalapi request by affiliation_codes ([be88c3d](https://github.com/stone-payments/payments-data-layer-reports/commit/be88c3d8be8bfc3f97022286d4ec20053bb64407))
* Fix report finder service ([9830a9a](https://github.com/stone-payments/payments-data-layer-reports/commit/9830a9a791ee254d126a445854261ef11a63c317))

## [1.32.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.31.0...v1.32.0) (2026-01-13)


### Features

* Add financial movement and onestone fields to charge list report ([312cd93](https://github.com/stone-payments/payments-data-layer-reports/commit/312cd9380c187f9eb47533cae1838e06b8d98e72))
* Add stress and memory allocation benchmarks for ChargeReportS3Worker ([2308aaa](https://github.com/stone-payments/payments-data-layer-reports/commit/2308aaa30965be4d04ee74462e77800eab0e33a1))

## [1.31.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.30.1...v1.31.0) (2026-01-09)


### Features

* : Create sale stone csv mapper ([7c0d53e](https://github.com/stone-payments/payments-data-layer-reports/commit/7c0d53ebc3fe5abbcb10ad34721242dfb4215c98))
* Adds a cet fee validation mechanism ([57ad8b5](https://github.com/stone-payments/payments-data-layer-reports/commit/57ad8b51fc9a83e2e5181908c4d20d3b485e5dde))
* Adds environment variable that defines whether the report will have a cet fee ([7599306](https://github.com/stone-payments/payments-data-layer-reports/commit/75993065f0c1b9da0e633e2e86b6ef65488cd9d0))
* Adds sales report type ([e36f329](https://github.com/stone-payments/payments-data-layer-reports/commit/e36f3299dec6068c85b65370d9bc07ed4c1cf03d))
* Adds sales report type to validator to support multiple report types ([9496d3a](https://github.com/stone-payments/payments-data-layer-reports/commit/9496d3a9af2fe5180d18a86af4a6a20446ec7721))
* Adds singleton services for csv mappers ([9b9c545](https://github.com/stone-payments/payments-data-layer-reports/commit/9b9c5458fe40cfdf9bcd8662e910c9f2783fd77d))
* Adds support for csv mapper interface to csv mappers ([16ef9a3](https://github.com/stone-payments/payments-data-layer-reports/commit/16ef9a308bf5c9efe3411d7883c54a79090ee6ff))
* Changes map last status name method for better resource utilization ([68a1f40](https://github.com/stone-payments/payments-data-layer-reports/commit/68a1f4047c6eba72984f704684f6186b51436fcd))
* Create sale aux mappers ([79b552c](https://github.com/stone-payments/payments-data-layer-reports/commit/79b552c75e44c1096593d88e97e28dfc47aa7cce))
* Create sale stone with cet csv mapper ([dfd1c2c](https://github.com/stone-payments/payments-data-layer-reports/commit/dfd1c2c217163cb907f65332e7147265121e6428))
* Create sale ton csv mapper ([796fbbc](https://github.com/stone-payments/payments-data-layer-reports/commit/796fbbc88dc32a88277654127165bc5763b487be))


### Bug Fixes

* Adjust find report to suport multi format reports ([9592094](https://github.com/stone-payments/payments-data-layer-reports/commit/959209414cb59bb47bba70d74e24914e872d8850))

### [1.30.1](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.30.0...v1.30.1) (2026-01-09)


### Bug Fixes

* Fix dalapi request by affiliation_codes ([a4957f8](https://github.com/stone-payments/payments-data-layer-reports/commit/a4957f82e3cae224a9d66987754f2a5c5437609c))

## [1.30.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.29.0...v1.30.0) (2026-01-07)


### Features

* Add legacy id system api ([df40c5e](https://github.com/stone-payments/payments-data-layer-reports/commit/df40c5e286c9176f694460333d39a69cb05d57b1))
* Add XlsxReportStreamWriter ([37ec4db](https://github.com/stone-payments/payments-data-layer-reports/commit/37ec4db97bdcd728ab8cc8fe62c09cb124986d59))

## [1.29.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.28.0...v1.29.0) (2026-01-06)


### Features

* Add benchmarks ([3e65666](https://github.com/stone-payments/payments-data-layer-reports/commit/3e656660a6f51c905636c447da7bdcbb0db4fe38))
* add call of notification v2 in concat worker ([d21f5d4](https://github.com/stone-payments/payments-data-layer-reports/commit/d21f5d494fa3f0a48d39e4afe9e9d8d085b9d918))
* add notification es charge report ([b9e038a](https://github.com/stone-payments/payments-data-layer-reports/commit/b9e038a9ad1364589fd68017c7eff7722c711f11))

## [1.28.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.27.0...v1.28.0) (2025-12-17)


### Features

* create es receivavble report enqueue service ([ceadfb7](https://github.com/stone-payments/payments-data-layer-reports/commit/ceadfb76d885afdbecbb5b142dd9b1bfc3ba9640))
* create hybrid receivable report enqueue service ([896b7b2](https://github.com/stone-payments/payments-data-layer-reports/commit/896b7b298b10eb3544e2b8562d5da868933a1b8f))
* Fix receivables columns and filename ([05581e4](https://github.com/stone-payments/payments-data-layer-reports/commit/05581e4bdb0b2bd126172a43ebb4b4bb585916ce))

## [1.27.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.26.0...v1.27.0) (2025-12-15)


### Features

* Make use of main endpoints into PreDeploy environment ([4185de3](https://github.com/stone-payments/payments-data-layer-reports/commit/4185de34e677947ebda25948af13fcace13733b3))

### [1.26.1](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.26.0...v1.26.1) (2025-12-10)


### Features

* Update CsvRowBuilder to support semicolon ([c37eec4](https://github.com/stone-payments/payments-data-layer-reports/commit/c37eec40b5452c85666b968bb16a16aeaa110a57))
* Remove unnecessary fields from Receivables report ([842bde7](https://github.com/stone-payments/payments-data-layer-reports/commit/842bde7edb484b7dd6f0256cea37fbe14b8dc91b))

## [1.26.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.25.0...v1.26.0) (2025-12-09)


### Features

* **charge-report-s3-concat:** Add partitioned record source and k-way merge over partitions ([d8b96ab](https://github.com/stone-payments/payments-data-layer-reports/commit/d8b96abdfa2634ac4ebff3ac371dfc507bb966be))
* **concat:** Add CSV S3 report writer and multipart sink ([61438ed](https://github.com/stone-payments/payments-data-layer-reports/commit/61438ed7c7e9c3a7bc086045ea849b33bae3a84a))
* **concat:** Add S3 CSV report record source ([7a00643](https://github.com/stone-payments/payments-data-layer-reports/commit/7a0064304eee363135819395765d8258065a8496))
* **concat:** add S3 writer factory ([61f1e53](https://github.com/stone-payments/payments-data-layer-reports/commit/61f1e53de02b22868a6beb108b0325091bb50642))

## [1.25.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.24.2...v1.25.0) (2025-12-03)


### Features

* create es order report enqueue ([e0d9f24](https://github.com/stone-payments/payments-data-layer-reports/commit/e0d9f2478549fb229885fad0815c918652230d95))
* create order report worker ([dfbab27](https://github.com/stone-payments/payments-data-layer-reports/commit/dfbab271a0c5d19c37cb41fcf1fb0ebbf9202f30))

### [1.24.2](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.24.1...v1.24.2) (2025-11-27)


### Bug Fixes

* Fix predeploy queue name ([61998d9](https://github.com/stone-payments/payments-data-layer-reports/commit/61998d90f5d196f5afce5cb3455e5f4af67f21c9))

### [1.24.1](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.24.0...v1.24.1) (2025-11-26)


### Bug Fixes

* Fix IReportingTimeMetrics DI ([0a37555](https://github.com/stone-payments/payments-data-layer-reports/commit/0a37555810919caca51996e3dba580db994593c9))

## [1.24.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.23.2...v1.24.0) (2025-11-26)


### Features

* Add enum to file formats ([efeb5e1](https://github.com/stone-payments/payments-data-layer-reports/commit/efeb5e1c1daef063d3214e87c9d0e20759c30ca1))
* Add notification worker v2 ([539e40a](https://github.com/stone-payments/payments-data-layer-reports/commit/539e40a67a639a4767af355c0ca1d5f668a33d01))
* Add unit test structure ([2bc1213](https://github.com/stone-payments/payments-data-layer-reports/commit/2bc1213250fafab9cd585c6a428c06cecef59efe))
* Adds a format field to /v1/reports endpoint request ([1162126](https://github.com/stone-payments/payments-data-layer-reports/commit/11621267b00e41999dd70f1fe49263bd413af1ee))
* Adds a method that terminates processing and maps to receivables ([79e1c1b](https://github.com/stone-payments/payments-data-layer-reports/commit/79e1c1bbb3437467a8ee52d8f87abab67da7750a))
* Adds a method to set timestamp of the last event in the finmov processor ([48efe7e](https://github.com/stone-payments/payments-data-layer-reports/commit/48efe7efded4748b8ded3f3436ec8d16662144dc))
* Adds buildrow method to process csv rows in receivables modifier ([d84ae4e](https://github.com/stone-payments/payments-data-layer-reports/commit/d84ae4ee893e8dfb3c2e9359fd0dc52c88c93f08))
* Adds fraud coverage in compute amounts ([791604a](https://github.com/stone-payments/payments-data-layer-reports/commit/791604a38cee989dc64149228217168cac58eabf))
* Adds new fields to fin mov list report header ([29d5eae](https://github.com/stone-payments/payments-data-layer-reports/commit/29d5eae63911f8ea51031a998b75b6c7369b13b2))
* Adds new fields to the finmov processor ([c56087c](https://github.com/stone-payments/payments-data-layer-reports/commit/c56087c722dfd44e5c0ae6fd50f1aad4f81e7f53))
* Adds receivables report type to delta lake manager ([cfc13f1](https://github.com/stone-payments/payments-data-layer-reports/commit/cfc13f11672d7f0cf41d011f8651dbc6d077dcb6))
* Adds report type validation to ensure it is 'receivables' ([5fcbf3d](https://github.com/stone-payments/payments-data-layer-reports/commit/5fcbf3d118617c699af7ebd67fe4c33422c04055))
* Apply dotnet format ([6fac413](https://github.com/stone-payments/payments-data-layer-reports/commit/6fac41391298c255570727a22f240e83611b3258))
* Change report type from 'finmov_list' to 'receivables' and adjust dependencies ([dca2657](https://github.com/stone-payments/payments-data-layer-reports/commit/dca26578a5cb07addef196e0643b6f247ac129ac))
* Changes category to operation in FinancialMovement ([7a705a5](https://github.com/stone-payments/payments-data-layer-reports/commit/7a705a5034aa3f012bb939c17f8b30dad64fe4ab))
* Changes the logic for processing moviments to include fee categories ([58dd255](https://github.com/stone-payments/payments-data-layer-reports/commit/58dd255d22ffed51b116cf3d30c4307e26ef61d8))
* Changes the processing logic to check if the transaction is valid ([e76a037](https://github.com/stone-payments/payments-data-layer-reports/commit/e76a037fc02dac4260733f2a98772492884620f4))
* create extractor by cusrsor ([2a3167e](https://github.com/stone-payments/payments-data-layer-reports/commit/2a3167e156e28f58d65b2e760633d1ea4e4f1b6c))
* create s3 adapter to multipart upload ([1a042a1](https://github.com/stone-payments/payments-data-layer-reports/commit/1a042a1f1c16a6b4a056f9028e1443d75ee52e0b))
* dispatch hybrid report ([163f8f6](https://github.com/stone-payments/payments-data-layer-reports/commit/163f8f6f13afe18fa855c29a6d7c0e8317aff73c))
* Remove commented code for deleting parquet path in finmov generator ([e6b5215](https://github.com/stone-payments/payments-data-layer-reports/commit/e6b5215052a828a82974169c938d2b75a82ce802))
* Renames format field to file format in the report request and adjusts the corresponding validations ([82ecd1a](https://github.com/stone-payments/payments-data-layer-reports/commit/82ecd1aa3883e3dd93a022a9f244a44829f3b8a6))
* Uncomment finmov generator class adapting to the current code ([242bc57](https://github.com/stone-payments/payments-data-layer-reports/commit/242bc574693d08b3724733328e980861b390f40e))
* use financial_movements as primary fee data source ([7b2540d](https://github.com/stone-payments/payments-data-layer-reports/commit/7b2540de0b3706bc909fa479f090cd1d7f4889df))


### Bug Fixes

* adjust unit tests ([613834a](https://github.com/stone-payments/payments-data-layer-reports/commit/613834a4cad9fdec48ed6853df256abbbf8d7ee9))
* Fix finmov generator constructor ([79bd3af](https://github.com/stone-payments/payments-data-layer-reports/commit/79bd3afe0cf2a7bbd9d0b6bab72aac65b21c18e1))
* Fix notification worker call ([b4a0865](https://github.com/stone-payments/payments-data-layer-reports/commit/b4a0865557c69a0b75e47fb69d291d5a9a1179cd))

## [1.21.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.19.4...v1.21.0) (2025-10-17)


### Features

* Add LegacyStatusEnum and integrate legacy status in charge report processing ([bac3b65](https://github.com/stone-payments/payments-data-layer-reports/commit/bac3b656bc92c55d259e6ff6de0d7952c096b3c9))

### Bug Fixes

* Change date fields from DateTimeOffset to DateOnly ([82666e1](https://github.com/stone-payments/payments-data-layer-reports/commit/82666e12eb5b9c7953c12d502a6ecfd1401da2d6))

## [1.20.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.19.4...v1.20.0) (2025-10-13)


### Features

* Add finmov s3 report ([386d009](https://github.com/stone-payments/payments-data-layer-reports/commit/386d009555d9f968ec2cab82d86a5648b828d9cc))
* create clone of charge report worker ([7ee998c](https://github.com/stone-payments/payments-data-layer-reports/commit/7ee998c5ee675ff55750887a9fba0c241d6ac822))

### Bug Fixes

* Add s3 existence check for report files in ReportService ([8136279](https://github.com/stone-payments/payments-data-layer-reports/commit/8136279f66ac76481132cf341a90cd63f9bc49cd))
* solve conflicts of main and develop ([692840d](https://github.com/stone-payments/payments-data-layer-reports/commit/692840d01ee1ec4d46f43e86efb3beb8df179795))

### [1.19.4](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.19.3...v1.19.4) (2025-10-09)


### Bug Fixes

* Add s3 check on get report endpoint ([26e9adb](https://github.com/stone-payments/payments-data-layer-reports/commit/26e9adbd887ab4f6c8e70e55274268a4423f46b5))

### [1.19.3](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.19.2...v1.19.3) (2025-10-07)


### Bug Fixes

* Send email from notification worker ([30aaf7a](https://github.com/stone-payments/payments-data-layer-reports/commit/30aaf7a2054d3023ea17a7c39b1ec162203555c0))

### [1.19.2](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.19.1...v1.19.2) (2025-10-03)


### Bug Fixes

* Change finmov report to receivables schema ([69cd3d9](https://github.com/stone-payments/payments-data-layer-reports/commit/69cd3d9738f493e30acb7aef08c1d477f3d1bcb7))

### [1.19.1](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.19.0...v1.19.1) (2025-09-25)


### Features

* Add IdempotentJobManager to replace ContinueJobWith jobs ([b9cd19b](https://github.com/stone-payments/payments-data-layer-reports/commit/b9cd19bc6c0492927791f4394b025604744c4223))


### Bug Fixes

* Replace ContinueJobWith jobs by regular jobs handled by the IdempotentJobManager ([ac9cf9f](https://github.com/stone-payments/payments-data-layer-reports/commit/ac9cf9f5982891c1b50b83342c993757ecd0da7c))

## [1.19.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.18.4...v1.19.0) (2025-09-25)


### Features

* Add notification system for report processing with webhook support ([7d96203](https://github.com/stone-payments/payments-data-layer-reports/commit/7d962034891cbd8102a1a2445c3f328f25651d07))
* Add reportid to webhook payload ([444c68c](https://github.com/stone-payments/payments-data-layer-reports/commit/444c68cf5405466ddad3ec933f872f1571407069))
* add support to fetch data from ES ([f7fd155](https://github.com/stone-payments/payments-data-layer-reports/commit/f7fd15583e9ede09c416e65d58e18bf995e33054))
* Add sync team as code owner ([a28ce6b](https://github.com/stone-payments/payments-data-layer-reports/commit/a28ce6b1b62a86d6d32e51c288056b822d4d83a3))
* Update codeowners ([8f69ef0](https://github.com/stone-payments/payments-data-layer-reports/commit/8f69ef061716204bc5f7f9697dc6630a1756f1f3))

### [1.18.4](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.18.3...v1.18.4) (2025-09-22)


### Bug Fixes

* Add job existence check before processing report in ChargeReportS3Worker ([7147f69](https://github.com/stone-payments/payments-data-layer-reports/commit/7147f692dfffcff6c4745367ce565160d1840290))

### [1.18.3](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.18.2...v1.18.3) (2025-09-19)


### Bug Fixes

* Add pix canceled amount condition ([d540a13](https://github.com/stone-payments/payments-data-layer-reports/commit/d540a134ebd6139dcca25f723d20bdf1aa51e6f4))

### [1.18.2](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.18.1...v1.18.2) (2025-09-18)


### Bug Fixes

* Apply custom transform to pix additional data ([8a57762](https://github.com/stone-payments/payments-data-layer-reports/commit/8a57762707efa2e5f9d53018cb22b2853ac2dca9))

### [1.18.1](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.18.0...v1.18.1) (2025-09-18)


### Bug Fixes

* Change priority queue criteria to lexicographical comparer ([7f079a0](https://github.com/stone-payments/payments-data-layer-reports/commit/7f079a0da27fb9943370c34f59c03f0ba2bae802))

## [1.18.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.17.4...v1.18.0) (2025-09-15)


### Features

* Add custom bash path option ([851e3c4](https://github.com/stone-payments/payments-data-layer-reports/commit/851e3c4ac7fe35710e1d3a1b88a0d08526531ec0))
* Add merge report service ([f0b27f4](https://github.com/stone-payments/payments-data-layer-reports/commit/f0b27f450bc4809928fed536f6fe52ae2f00c7ae))
* Add multi docs support to realtime service ([41161b0](https://github.com/stone-payments/payments-data-layer-reports/commit/41161b07ce71d920f7e44d44f8dbf1d006fbbc69))
* creation of reporting time metric ([1600771](https://github.com/stone-payments/payments-data-layer-reports/commit/160077150b1260a7d9533f40b07e6566edccd8fa))

### Bug Fixes

* Refactor S3ClientWrapper into facade ([6829551](https://github.com/stone-payments/payments-data-layer-reports/commit/682955190fd75d6cc762d5a6bce100ee55f6ae66))

### [1.17.7](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.17.6...v1.17.7) (2025-09-17)


### Bug Fixes

* add event_id in charge events report ([42b5819](https://github.com/stone-payments/payments-data-layer-reports/commit/42b5819e301ef65bb70188ca0fa8bf5305eeba08))

### [1.17.6](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.17.5...v1.17.6) (2025-09-17)


### Bug Fixes

* Fix date format ([46fe31a](https://github.com/stone-payments/payments-data-layer-reports/commit/46fe31a4007d38557035d5f6a24bccb97b3b07ce))

## [1.17.5](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.17.4...v1.17.5) (2025-09-16)


### Bug Fixes

* adjust format of event_datetime and created_at fields ([ff58126](https://github.com/stone-payments/payments-data-layer-reports/commit/ff581266baf2b5831a44579c3e1458c45f79ff0c))

### [1.17.4](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.17.3...v1.17.4) (2025-09-12)


### Bug Fixes

* Ensure event datetime iso8601 format ([a7c7659](https://github.com/stone-payments/payments-data-layer-reports/commit/a7c7659357e500c46e2248b65a4942b833c29566))

### [1.17.3](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.17.2...v1.17.3) (2025-09-12)


### Bug Fixes

* FIx charges events dedup and sort ([c8b40eb](https://github.com/stone-payments/payments-data-layer-reports/commit/c8b40eb841b810470713ee732f5a5aff42874d70))

### [1.17.2](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.17.1...v1.17.2) (2025-09-12)


### Bug Fixes

* Add missing fields to realtime file ([8e534f9](https://github.com/stone-payments/payments-data-layer-reports/commit/8e534f9729b4f24a7b7f0c6b7cd6db21248cca73))
* Adjust charges events report for is sandbox field ([3bc1b50](https://github.com/stone-payments/payments-data-layer-reports/commit/3bc1b5035dc5f99db0d02db1f3f3617b781d0e47))

### [1.17.1](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.17.0...v1.17.1) (2025-09-12)


### Bug Fixes

* Add concat loop execution limit ([e46976c](https://github.com/stone-payments/payments-data-layer-reports/commit/e46976c2a82ce89c7644da6950b7ab751e546591))
* Does not apply is sandbox filter for realtime data ([bc65b6f](https://github.com/stone-payments/payments-data-layer-reports/commit/bc65b6f4b75df549aa7b7496fdf01d2bace0d591))

## [1.17.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.16.0...v1.17.0) (2025-09-10)


### Features

* Add Get Reports endpoint ([e3e79ae](https://github.com/stone-payments/payments-data-layer-reports/commit/e3e79aeaad0e24d5b10912408cdd7ac4062df334))
* Adds GetReportsRequest and GetReportsResponse ([f7ce9c9](https://github.com/stone-payments/payments-data-layer-reports/commit/f7ce9c9b25dc961492c9b4a09898a564d96ab3af))


## [1.16.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.15.0...v1.16.0) (2025-09-09)


### Features

* Add delete pre deploy queues endpoint ([aeb8db6](https://github.com/stone-payments/payments-data-layer-reports/commit/aeb8db6b79dd676ec309eee8cb9d8be442f1538c))

## [1.15.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.14.0...v1.15.0) (2025-09-08)


### Features

* remove pagarme_id unnused field ([3706aea](https://github.com/stone-payments/payments-data-layer-reports/commit/3706aeab7ec2e28d01a60c6a3b2968e4d34f747d))

## [1.14.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.13.1...v1.14.0) (2025-09-03)


### Features

* config otel-collector, prometheus, metrics and traces ([3828b2c](https://github.com/stone-payments/payments-data-layer-reports/commit/3828b2c6023c8c8ebeabcd70b1c7d65e2a56acf0))
* create open telemetry settings ([64e00a3](https://github.com/stone-payments/payments-data-layer-reports/commit/64e00a3e24a05fc5e37f21912d83b4751547f462))
* create opentelemetry extensions and config it ([bf0c28d](https://github.com/stone-payments/payments-data-layer-reports/commit/bf0c28d0d24fba8c0f70092b2f52b8d41c5ea4d7))
* define autoscaling ([93ff55c](https://github.com/stone-payments/payments-data-layer-reports/commit/93ff55ca82f7369fb53078251b978d9424fba3da))
* remove event_id of charges envets report ([10fb2fe](https://github.com/stone-payments/payments-data-layer-reports/commit/10fb2fe9ae1f2c46ff73ae55af16930c8a876a13))
* set env variables into values stg ([a25c38e](https://github.com/stone-payments/payments-data-layer-reports/commit/a25c38e8072aaec8191ab6cb445a1bc0fc9fb9e4))


### Bug Fixes

* Fix chargeback refund amount ([9e65fc6](https://github.com/stone-payments/payments-data-layer-reports/commit/9e65fc63a9a9bce6b3bb0eec0885a6ea7ef8425a))

### [1.13.1](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.13.0...v1.13.1) (2025-08-26)


### Bug Fixes

* add real-time data handling ([b18554e](https://github.com/stone-payments/payments-data-layer-reports/commit/b18554eb6aa8de9fce1746e589d3aead16b66e64))

## [1.13.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.12.2...v1.13.0) (2025-08-25)


### Features

* add charge events in report type enum ([c2997e7](https://github.com/stone-payments/payments-data-layer-reports/commit/c2997e75efdedb110dc88abce09f27772c751b1a))
* Add multi doc disptach ([d1dcdb5](https://github.com/stone-payments/payments-data-layer-reports/commit/d1dcdb5e5ab2d836ad62f588bd42a349d119b604))
* create metodo to get delta lake tables ([bba2c00](https://github.com/stone-payments/payments-data-layer-reports/commit/bba2c00bb66aefb7cc5d27eb1c4673f47b661624))
* Enable query with failed charges ([0ca685a](https://github.com/stone-payments/payments-data-layer-reports/commit/0ca685a8dcba31a18591819b20bff6cdfb75b64d))


### Bug Fixes

* Move partition defitition to dispatch worker ([2ebd5d7](https://github.com/stone-payments/payments-data-layer-reports/commit/2ebd5d74b7d5c632d287957d77b4e1e5a8e650c5))
* Remove concat queue ([7554652](https://github.com/stone-payments/payments-data-layer-reports/commit/7554652be830e4304035cbbe76508ef9ba2c4778))

### [1.12.2](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.12.1...v1.12.2) (2025-08-13)


### Bug Fixes

* Remove is sandbox from duckdb query ([cc2774b](https://github.com/stone-payments/payments-data-layer-reports/commit/cc2774b119cb2c2596a280cff79d47d11757bba1))

### [1.12.1](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.12.0...v1.12.1) (2025-08-13)


### Bug Fixes

* Fix realtime query to use initial filters ([7c7cf1d](https://github.com/stone-payments/payments-data-layer-reports/commit/7c7cf1daa31fcf91798fe21552d2e14184b1c158))

## [1.12.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.11.1...v1.12.0) (2025-08-13)


### Features

* Add new filters ([34aa580](https://github.com/stone-payments/payments-data-layer-reports/commit/34aa580498eb82aa2667ff8cfbad2471134f7f1a))

### [1.11.1](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.11.0...v1.11.1) (2025-08-12)


### Bug Fixes

* Unifies queue on worker ([41e55fc](https://github.com/stone-payments/payments-data-layer-reports/commit/41e55fcbccf67166d5e8447a562179cacc9859a9))

## [1.11.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.10.1...v1.11.0) (2025-08-12)


### Features

* Add cash fields on s3 report ([857c12d](https://github.com/stone-payments/payments-data-layer-reports/commit/857c12d01156a508889e96037c6539349b523f78))

### [1.10.1](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.10.0...v1.10.1) (2025-08-11)


### Bug Fixes

* Changes from downloading dir to download files individually ([e5708eb](https://github.com/stone-payments/payments-data-layer-reports/commit/e5708eb20ed3095e9437e3ca3bdc621eb20cc637))

## [1.10.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.9.0...v1.10.0) (2025-08-11)


### Features

* Add pagarme fields to s3 and es report without cash ([708eb9e](https://github.com/stone-payments/payments-data-layer-reports/commit/708eb9ee66f423cfb43f07e03c57074b54749ee5))

## [1.9.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.8.0...v1.9.0) (2025-08-11)


### Features

* Add pagarme fields on dalapi reports ([3fad178](https://github.com/stone-payments/payments-data-layer-reports/commit/3fad1782caac0c63a55291f65899c09c5ff9bca9))

## [1.8.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.7.1...v1.8.0) (2025-08-08)


### Features

* Add PreDeploy Endpoint ([38e6721](https://github.com/stone-payments/payments-data-layer-reports/commit/38e67216db7b412b885c02fdb5e04bfeaa2691cf))

### [1.7.1](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.7.0...v1.7.1) (2025-07-03)


### Bug Fixes

* Avoid non existing columns error ([594a89c](https://github.com/stone-payments/payments-data-layer-reports/commit/594a89cfb22e814332d63d87c466905d89e98eca))
* Extract CsvRowBuilder to shared module and add JSON serialization support ([62001ab](https://github.com/stone-payments/payments-data-layer-reports/commit/62001ab967ac39702905804ecc014a9bdaeefb23))
* Refactor realtime service by using csv mapper estrategy ([c59ad31](https://github.com/stone-payments/payments-data-layer-reports/commit/c59ad3155c74f3ba7f6448819c479d5287594808))

## [1.7.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.6.1...v1.7.0) (2025-07-01)


### Features

* Add charges events real time service ([aa28c32](https://github.com/stone-payments/payments-data-layer-reports/commit/aa28c32f8d577655fb1f38a226122c78f79af3dd))
* Add realtime query and post processing filter query ([d07a2a8](https://github.com/stone-payments/payments-data-layer-reports/commit/d07a2a8bad08028092032ae90e60a0fa8c88e62f))
* Feat add post processing filters ([0e0b1c2](https://github.com/stone-payments/payments-data-layer-reports/commit/0e0b1c2fdf83735383bbe82202978343d8c1b383))


### Bug Fixes

* Refactor processor adding each payment method peculiarities ([d87e0da](https://github.com/stone-payments/payments-data-layer-reports/commit/d87e0dab7bac23d16694edcbf3ef4e455e4fa654))

### [1.6.1](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.6.0...v1.6.1) (2025-06-27)


### Bug Fixes

* Avoids report file override ([b094b52](https://github.com/stone-payments/payments-data-layer-reports/commit/b094b526e4046643497dd83624be273bbcd02e42))

## [1.6.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.5.1...v1.6.0) (2025-06-25)


### Features

* Add concat report worker ([811de9f](https://github.com/stone-payments/payments-data-layer-reports/commit/811de9ff7e6df386fdd2978d35e427a419df1bdd))
* Add wrapper to consolidate s3 usage ([8d34546](https://github.com/stone-payments/payments-data-layer-reports/commit/8d3454608f3407b3ab555e991bf16fdfcc66d5dd))

### [1.5.1](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.5.0...v1.5.1) (2025-06-25)


### Bug Fixes

* Adjusts cloudid and improve logs ([3be454f](https://github.com/stone-payments/payments-data-layer-reports/commit/3be454fafb343d07b816cf35714ac74a23c67528))

## [1.5.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.4.0...v1.5.0) (2025-06-17)


### Features

* Add s3 reports dispatcher ([46b1386](https://github.com/stone-payments/payments-data-layer-reports/commit/46b1386d1f958fc59438e3f381138020152e7a55))
* Improve report metadata ([379379e](https://github.com/stone-payments/payments-data-layer-reports/commit/379379ed88f73c895b5fba61a9c639b314b07690))


### Bug Fixes

* Fix es client lib version ([3077c06](https://github.com/stone-payments/payments-data-layer-reports/commit/3077c0692268d7b1b6be8ebb6e3e7d3c664cdbca))

## [1.4.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.3.4...v1.4.0) (2025-06-06)


### Features

* Add Grouping Worker ([7c500e9](https://github.com/stone-payments/payments-data-layer-reports/commit/7c500e9596e74fa7343dd5c2f991a7bb8321a8a0))
* Enable pagarme report ([d57ef9d](https://github.com/stone-payments/payments-data-layer-reports/commit/d57ef9d0272f859cc20516045bc3d3098dcbb8e3))

### [1.3.4](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.3.3...v1.3.4) (2025-06-04)


### Bug Fixes

* Add id manipulation with endsWIth ([d3b25a4](https://github.com/stone-payments/payments-data-layer-reports/commit/d3b25a4d00ad2876ee6c0ef78da5428b7e473868))

### [1.3.3](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.3.2...v1.3.3) (2025-06-03)


### Bug Fixes

* Remove report id manipulation ([33cdc0a](https://github.com/stone-payments/payments-data-layer-reports/commit/33cdc0ac1927c4015294ff4bc2dfd17a13152eed))

### [1.3.2](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.3.1...v1.3.2) (2025-06-03)


### Bug Fixes

* Remove extra data from report id ([2843125](https://github.com/stone-payments/payments-data-layer-reports/commit/2843125a377a1daccb08a8942e8f2a1212134226))

### [1.3.1](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.3.0...v1.3.1) (2025-06-03)


### Bug Fixes

* Remove incorrect id modification ([9bcfd64](https://github.com/stone-payments/payments-data-layer-reports/commit/9bcfd6458ebc0080de67fd3f85bfb3c8a62146e6))

## [1.3.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.2.0...v1.3.0) (2025-06-02)


### Features

* Add data-layer-reports-worker-1 workload ([7fc317f](https://github.com/stone-payments/payments-data-layer-reports/commit/7fc317f595d1f28203c5182618ab52474e6d78cb))
* Adds card number token ([72a2f0b](https://github.com/stone-payments/payments-data-layer-reports/commit/72a2f0b409a19815ef86a4018c3252a39da0b733))


### Bug Fixes

* Correct pagarme report query building ([1b9d49e](https://github.com/stone-payments/payments-data-layer-reports/commit/1b9d49e1e2bf14e6cc3e18d98cfc372f1cc58feb))

## [1.2.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.1.3...v1.2.0) (2025-05-27)


### Features

* Add hangfire management endpoint ([e7045a3](https://github.com/stone-payments/payments-data-layer-reports/commit/e7045a32eedf1812f904784598f16e828e3bb838))
* Add pagarme parameters in postReport Requests ([6bb169e](https://github.com/stone-payments/payments-data-layer-reports/commit/6bb169e1600b091f0c3af2828ce03de2187a6b72))

### [1.1.3](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.1.2...v1.1.3) (2025-04-17)


### Bug Fixes

* Add missing pix fee amount ([f7c8baf](https://github.com/stone-payments/payments-data-layer-reports/commit/f7c8baf163196ac9cf29184c4e907fac926925cc))
* Fix provider datetime format ([c9e8cd2](https://github.com/stone-payments/payments-data-layer-reports/commit/c9e8cd26d61b9f91ff2cd8cac615144f03ffae3e))

### [1.1.2](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.1.1...v1.1.2) (2025-04-09)


### Bug Fixes

* Serialize objects using snake case ([8ad1f19](https://github.com/stone-payments/payments-data-layer-reports/commit/8ad1f199cec96b4b8bad0f8844a82493f62ecdae))

### [1.1.1](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.1.0...v1.1.1) (2025-04-08)


### Bug Fixes

* Adjust mapper ([8177995](https://github.com/stone-payments/payments-data-layer-reports/commit/8177995daceb1af9e913dbf0529df262847175c2))

## [1.1.0](https://github.com/stone-payments/payments-data-layer-reports/compare/v1.0.0...v1.1.0) (2025-04-07)


### Features

* Add basic authentication to Hangfire dashboard ([51f7b34](https://github.com/stone-payments/payments-data-layer-reports/commit/51f7b34e6f72eb36e3e563adcf04e46a81567433))


### Bug Fixes

* Adjust creation date params ([bfda215](https://github.com/stone-payments/payments-data-layer-reports/commit/bfda215bacd937ed09f2400ab7ffe4b891c3e74d))

## 1.0.0 (2025-04-02)


### Features

* Add charge entity ([f6fd48d](https://github.com/stone-payments/payments-data-layer-reports/commit/f6fd48d7a7dace0aecd1d9299ab5c0aff4a6e731))
* Add dalapi client ([4eb098a](https://github.com/stone-payments/payments-data-layer-reports/commit/4eb098a75368ec75708d74d9466cb4237d690411))
* Add Elastic to S3 lazy load ([bb4214e](https://github.com/stone-payments/payments-data-layer-reports/commit/bb4214e6c2f63738b83d2978329d3595484a93d8))
* Add s3 url builder ([ad5910e](https://github.com/stone-payments/payments-data-layer-reports/commit/ad5910ed4c557e1cd75626c089ada3d4066eb5a0))
* update data-layer-reports application ([1c0d0f5](https://github.com/stone-payments/payments-data-layer-reports/commit/1c0d0f57ce8e26761f40404d9a5875da956fe396))
* update data-layer-reports application to develop ([28fadae](https://github.com/stone-payments/payments-data-layer-reports/commit/28fadaed83947fc2642bfb7504fab46c172673d1))


### Bug Fixes

* Add array handling ([a94b138](https://github.com/stone-payments/payments-data-layer-reports/commit/a94b138be2cc43721d04038f5b78a0c3153c13d6))
* Add date to datetime with timezone conversion ([703653f](https://github.com/stone-payments/payments-data-layer-reports/commit/703653f3e1d34492df828eec785b577a706a8cca))
* Avoid returning failed when in retry ([ae03c41](https://github.com/stone-payments/payments-data-layer-reports/commit/ae03c41dcecf881710bde3367ea4397227b6f3ae))

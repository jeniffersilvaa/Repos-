# Documentação de Testes

Este documento descreve a arquitetura de testes do projeto, padrões utilizados e informações úteis para criação de novos testes.

## Estrutura de Projetos

```
tests/
├── PaymentsDataLayerReports.Unit.Test/        # Testes unitários
├── PaymentsDataLayerReports.Integration.Test/ # Testes de integração
└── PaymentsDataLayerReports.Benchmark/        # Benchmarks de performance
```

---

## 1. Testes Unitários

**Projeto:** `PaymentsDataLayerReports.Unit.Test`

### Objetivo
Testar unidades isoladas de código (classes, métodos) com dependências mockadas.

### Estrutura

```
PaymentsDataLayerReports.Unit.Test/
├── Application/                    # Espelha a estrutura do projeto principal
│   ├── Constants/
│   ├── Extensions/
│   ├── Infra/
│   │   ├── DataLayerApi/
│   │   ├── MultiPartFileUploader/
│   │   └── S3ClientWrapper/
│   ├── Routes/
│   ├── Services/
│   │   ├── ReportEnqueue/
│   │   ├── ReportFinder/
│   │   ├── ReportStreamWriterService/
│   │   └── ReportTypeConfigurationProvider/
│   └── Workers/
│       ├── ChargeReportS3Concat/
│       ├── ChargeReportS3Dispatch/
│       ├── ChargeReportS3Worker/
│       ├── FinMovReportESWorker/
│       ├── NotificationWorker/
│       ├── OrderReportESWorker/
│       └── Shared/
├── Helpers/                        # Utilitários compartilhados
│   ├── MockFactory.cs              # Factory para mocks de Hangfire
│   ├── TestDataFactory.cs          # Factory para objetos de domínio
│   └── TestMeterFactory.cs         # Factory para métricas
└── GlobalUsings.cs                 # Imports globais (Xunit, Helpers)
```

### Padrões e Convenções

#### Nomenclatura de Arquivos
- Arquivos de teste: `{ClasseTestada}Tests.cs`
- Localização: espelha o caminho da classe no projeto principal

#### Nomenclatura de Métodos
```csharp
[Fact]
public async Task {Método}_{Cenário}_{ResultadoEsperado}()

// Exemplos:
public async Task ProcessReport_WithValidParameters_ShouldCompleteSuccessfully()
public async Task ProcessReport_WhenMetadataNotFound_ShouldThrowException()
public async Task Execute_WithEmptyInput_ShouldReturnEmptyResult()
```

#### Estrutura do Teste (AAA)
```csharp
[Fact]
public async Task ProcessReport_WithValidParameters_ShouldCompleteSuccessfully()
{
    // Arrange - Setup de mocks e dados
    var reportId = "test-report-123";
    var metadata = TestDataFactory.CreateValidReportMetadata(reportId);
    _s3ClientWrapper.GetReportMetadataAsync(reportId)
        .Returns(Task.FromResult<ReportMetadata?>(metadata));

    // Act - Execução do método testado
    await _worker.ProcessReport(reportId, _performContext, _cancellationToken);

    // Assert - Verificação do resultado
    await _chargeListReportGenerator.Received(1)
        .Execute(Arg.Any<GenerateReportInput>());
}
```

#### Organização com Regions
```csharp
public class ChargeReportS3WorkerTests
{
    #region Success Scenarios
    // Testes de cenários de sucesso
    #endregion

    #region Error Handling
    // Testes de tratamento de erros
    #endregion

    #region Edge Cases
    // Testes de casos limite
    #endregion
}
```

### Helpers Disponíveis

| Helper | Descrição |
|--------|----------|
| `MockFactory` | Cria mocks de objetos Hangfire (`PerformContext`, `BackgroundJob`) |
| `TestDataFactory` | Cria objetos de domínio válidos (`ReportMetadata`, `ChargeReportsWorkerParameters`, `DeltaTablePartitionSet`) |
| `TestMeterFactory` | Cria objetos de métricas para testes |

### Convenções

- **Framework de mocking**: NSubstitute
- **GlobalUsings**: `Xunit` e `Helpers` são importados automaticamente

### Criando Novos Testes

1. Criar arquivo em `Application/` espelhando o path da classe testada
2. Nomenclatura: `{ClasseTestada}Tests.cs`
3. Usar `MockFactory` para Hangfire e `TestDataFactory` para domínio
4. Seguir padrão AAA e agrupar cenários com regions

---

## 2. Testes de Integração

**Projeto:** `PaymentsDataLayerReports.Integration.Test`

### Objetivo
Testar fluxos completos com dependências reais (S3 via LocalStack, arquivos, etc.).

### Estrutura

```
PaymentsDataLayerReports.Integration.Test/
├── Application/                    # Espelha a estrutura do projeto principal
│   ├── Infra/
│   │   └── S3ClientWrapper/
│   └── Workers/
│       └── ChargeReportS3Worker/
├── Helpers/
│   ├── CsvComparer.cs              # Comparador de CSVs para validação
│   ├── FileBasedTestHelper.cs      # Helper para testes baseados em arquivos
│   ├── MockFactory.cs              # Mocks específicos de integração
│   ├── S3IntegrationTestBase.cs    # Classe base para testes com S3
│   └── S3LocalStackFixture.cs      # Fixture do LocalStack
├── TestData/                       # Dados de teste (CSVs, Parquets)
│   ├── ChargeListReportService/
│   │   └── TestCases/
│   │       └── {nome_caso}/
│   │           ├── input.csv
│   │           └── expected.csv
│   └── ChargeReportS3Concat/
└── Exceptions/
    └── SkipException.cs            # Exceção para pular testes condicionalmente
```

### Padrões

#### Classe Base para Testes com S3 (LocalStack)

```csharp
public class MeuTesteDeIntegracao : S3IntegrationTestBase
{
    [Fact]
    public async Task MeuTeste()
    {
        // S3Client já está configurado e conectado ao LocalStack
        // TestBucketName contém o nome do bucket de teste
        
        await S3Client!.PutObjectAsync(new PutObjectRequest
        {
            BucketName = TestBucketName,
            Key = "meu-arquivo.csv",
            ContentBody = "conteudo"
        });

        // Métodos auxiliares disponíveis:
        var exists = await ObjectExistsAsync("meu-arquivo.csv");
        var content = await GetObjectContentAsync("meu-arquivo.csv");
    }
}
```

A classe `S3IntegrationTestBase`:
- Implementa `IAsyncLifetime` (setup/teardown automático)
- Inicia container LocalStack via Testcontainers
- Cria bucket de teste automaticamente
- Limpa bucket após cada teste

#### Testes Baseados em Arquivos

```csharp
public class ChargeListReportServiceTests
{
    private const string TestDataBasePath = "TestData/ChargeListReportService";

    [Theory]
    [InlineData("caso_basico")]
    [InlineData("caso_com_chargeback")]
    [InlineData("caso_pix")]
    public async Task ProcessAsync_TestCases(string testCaseName)
    {
        // Carrega caso de teste do diretório
        var testCase = FileBasedTestHelper.LoadTestCase(TestDataBasePath, testCaseName);
        
        // Prepara streams
        using var inputStream = FileBasedTestHelper.CreateInputStream(testCase);
        using var outputStream = FileBasedTestHelper.CreateOutputStream(testCase);
        
        // Executa
        await ChargeListReportService.ProcessAsync(
            inputStream,
            outputStream,
            testCase.InputHeader,
            "test-report",
            "test-job",
            CancellationToken.None
        );
        
        // Valida resultado comparando CSVs
        FileBasedTestHelper.ValidateOutput(testCase);
    }
}
```

#### Estrutura de TestCases

```
TestData/
└── ChargeListReportService/
    └── TestCases/
        ├── caso_basico/
        │   ├── input.csv       # Entrada do teste
        │   └── expected.csv    # Saída esperada
        ├── caso_com_chargeback/
        │   ├── input.csv
        │   └── expected.csv
        └── caso_pix/
            ├── input.csv
            └── expected.csv
```

### Helpers Disponíveis

| Helper | Descrição |
|--------|----------|
| `S3IntegrationTestBase` | Classe base com LocalStack para testes com S3 |
| `FileBasedTestHelper` | Carrega TestCases de arquivos CSV |
| `CsvComparer` | Compara CSVs com opções de ignorar colunas/ordem |
| `S3LocalStackFixture` | Fixture compartilhada do LocalStack |

### Criando Novos Testes

1. Herdar de `S3IntegrationTestBase` se precisar de S3
2. Usar `FileBasedTestHelper` para testes baseados em arquivos CSV
3. Criar TestCases em `TestData/{Serviço}/TestCases/{nome_caso}/`
4. Usar `CsvComparer` para validar outputs

---

## 3. Benchmarks

**Projeto:** `PaymentsDataLayerReports.Benchmark`

### Objetivo
Medir e validar performance (foco em alocação de memória) entre versões.

### Estrutura

```
PaymentsDataLayerReports.Benchmark/
├── Program.cs        # Entry point (BenchmarkSwitcher)
├── .Results/         # Resultados (gitignored)
├── Benchmarks/       # Benchmarks por fluxo
├── Generators/       # Geradores de dados fake
├── Mocks/            # Mocks específicos para benchmarks
├── Settings/         # Configurações do BenchmarkDotNet
└── README.md         # Documentação detalhada
```

### Padrões

#### Estrutura de um Benchmark

```csharp
[Config(typeof(BatchProcessingBenchmarkConfig))]
public class ReceivablesModifierBaseBenchmark
{
    protected List<FinancialMovement> _batchRecords = null!;

    [Params(1_000, 5_000, 10_000)]
    public virtual int RecordCount { get; set; }

    [GlobalSetup]
    public void Setup()
    {
        // Preparar dados de teste
        _batchRecords = FinancialMovementGenerator.GenerateBatch(RecordCount);
    }

    [Benchmark(Description = "BuildRow from FinancialMovement")]
    public int BuildRowFromObject()
    {
        var totalLength = 0;
        foreach (var record in _batchRecords)
        {
            var row = ReceivablesModifier.BuildRow(record);
            totalLength += row.Length;
        }
        return totalLength; // Retorno evita otimização do compilador
    }
}
```

#### Stress Test (volumes maiores)

```csharp
[Config(typeof(StressTestBenchmarkConfig))]
public class ReceivablesModifierStressBenchmark : ReceivablesModifierBaseBenchmark
{
    [Params(10_000, 50_000, 100_000)]
    public override int RecordCount { get; set; }
}
```

#### Generators Disponíveis

| Generator | Descrição |
|-----------|----------|
| `FinancialMovementGenerator` | Gera objetos `FinancialMovement` para testes de fluxo FinMov |
| `ChargeGenerator` | Gera objetos `Charge` para testes de fluxo Charge |
| `CsvRowGenerator` | Gera `CsvRow` para testes de fluxo S3 |

#### Mocks Disponíveis

| Mock | Descrição |
|------|----------|
| `NullSinkS3Client` | Mock de S3 que descarta dados (isola medição de processamento) |
| `MockDataLayerApiClient` | Simula API com dados gerados |
| `InMemoryReportOutputSink` | Sink em memória para capturar output |

### Critérios de Aceitação

| Métrica | Critério |
|---------|----------|
| **Alloc/Record** | Deve permanecer igual ou menor |
| **Allocated** | Variação aceitável < 5% |
| **Gen0/Gen1** | Não deve aumentar significativamente |
| **Gen2** | Deve permanecer 0 (ou muito baixo) |

> **Importante**: Regressões de memória são críticas em aplicações de streaming. Um aumento de alocação por registro se multiplica pelo volume total de dados.

### Criando Novos Benchmarks

1. Criar em `Benchmarks/{Fluxo}/`
2. Usar `BatchProcessingBenchmarkConfig` ou `StressTestBenchmarkConfig`
3. Usar Generators existentes ou criar novos em `Generators/`
4. Usar mocks NullSink para isolar medição de processamento
5. Sempre retornar algo do método para evitar dead code elimination

---

## Comandos Úteis

```bash
# Testes unitários (rápido, durante desenvolvimento)
make test-unit

# Testes completos (antes de commit)
make test-phased

# Com cobertura
make test-coverage

# Benchmark específico
dotnet run --project tests/PaymentsDataLayerReports.Benchmark \
  -c Release -- --filter '*ReceivablesModifier*'

# Listar benchmarks disponíveis
dotnet run --project tests/PaymentsDataLayerReports.Benchmark \
  -c Release -- --list flat
```

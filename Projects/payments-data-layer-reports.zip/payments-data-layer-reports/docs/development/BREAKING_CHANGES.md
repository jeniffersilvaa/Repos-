# Breaking Changes na DALAR

Este documento descreve as situações que podem causar breaking changes durante deploys na aplicação payments-data-layer-reports (DALAR), especialmente devido à arquitetura distribuída com Hangfire.

## Arquitetura de Deployments

A DALAR possui múltiplos deployments que compartilham a mesma base de código, mas consomem filas diferentes:

| Deployment | Filas Hangfire | Workers |
|------------|---------------|---------|
| **data-layer-reports** | | API |
| **worker-1** | `s3_reports`, `s3_reports_dispatch` | ChargeReportS3Dispatch, ChargeReportS3Worker, ChargeReportS3Concat |
| **worker-2** | `reports`, `notifications` | ChargeReportWorker (ES), OrderReportESWorker, FinMovWorker |

## Como o Hangfire Serializa Jobs

Quando um job é enfileirado via `BackgroundJob.Enqueue`, o Hangfire serializa:

1. **O tipo e nome do método** - Ex: `ChargeReportWorker.ProcessReport`
2. **Os parâmetros do método** - Serializados em JSON no Redis
3. **Metadados de continuação** - Para jobs encadeados via `ContinueJobWith`

### Exemplo de Serialização

```csharp
BackgroundJob.Enqueue<ChargeReportWorker>(
    job => job.ProcessReport(
        parameters,           // ChargeReportsWorkerParameters serializado em JSON
        notificationChannel,  // NotificationChannel serializado em JSON
        isPartialReport,
        null!,
        CancellationToken.None
    )
);
```

O Redis armazenará algo como:
```json
{
  "Type": "ChargeReportWorker",
  "Method": "ProcessReport",
  "Args": [
    {"StartDate": "2024-01-01", "EndDate": "2024-01-31", "Document": "123", ...},
    {"Email": {"Address": "..."}, ...},
    false,
    null
  ]
}
```

## Cenários de Breaking Change

### 1. Alteração em Classes de Parâmetros

**Afetados:** `ChargeReportsWorkerParameters`, `FinMovESWorkerParameters`, `OrderReportWorkerParameters`

| Alteração | Risco | Efeito |
|-----------|-------|--------|
| Adicionar campo opcional (nullable) | ✅ Seguro | JSON deserializa com `null` |
| Adicionar campo obrigatório | ❌ **Quebra** | Deserialização falha |
| Remover campo | ⚠️ Risco | Pode falhar se modelo tiver validação |
| Renomear campo | ❌ **Quebra** | Deserialização ignora campo antigo |
| Mudar tipo do campo | ❌ **Quebra** | Deserialização falha |

### 2. Alteração em Assinaturas de Métodos

| Alteração | Risco |
|-----------|-------|
| Renomear método do worker | ❌ **Quebra** |
| Adicionar parâmetro obrigatório | ❌ **Quebra** |
| Adicionar parâmetro com default | ⚠️ Risco |
| Mudar ordem dos parâmetros | ❌ **Quebra** |

### 3. Fluxo S3 - ReportMetadata

O fluxo S3 é particularmente sensível porque:

1. **Dispatch** cria `ReportMetadata` e salva em JSON no S3
2. **Workers** leem este JSON para processar cada partição
3. **Concat** lê o mesmo JSON para finalizar

Se o `ReportMetadata` ou `ChargeReportsWorkerParameters` mudar entre o dispatch e a execução dos workers, o relatório pode:
- Falhar na deserialização
- Processar com dados parciais/incorretos
- Gerar arquivos inconsistentes

## Procedimento de Deploy Seguro para Breaking Changes

Quando uma release contém alterações em classes de parâmetros ou assinaturas de métodos que afetam o fluxo S3:

### Passo a Passo

1. **Pausar o consumo de novos relatórios**
   - Fazer redeploy da versão atual removendo a fila `s3_reports_dispatch` do worker-1
   - Novos relatórios ficam enfileirados mas não são processados

2. **Aguardar processamento completo**
   - Monitorar via Hangfire Dashboard: https://data-layer-reports-prd.stone.tech/hangfire/
   - Aguardar filas `s3_reports` e `s3_reports_dispatch` chegarem a zero
   - Garantir que nenhum relatório está em estado "Processing"

3. **Deploy da nova versão**
   - Subir a nova versão com as breaking changes
   - Reabilitar consumo da fila `s3_reports_dispatch`

4. **Validar funcionamento**
   - Monitorar logs e métricas
   - Verificar se novos relatórios estão sendo processados corretamente

### Alterando a Configuração de Filas

Para remover temporariamente o consumo de uma fila, altere o values.yaml do worker:

```yaml
# Antes (consumindo dispatch)
Hangfire__Server__Queues: s3_reports,s3_reports_dispatch

# Durante pausa (apenas workers)
Hangfire__Server__Queues: s3_reports
```

## Classificação de Riscos por Tipo de Alteração

| Tipo de Alteração | Fluxo ES (worker-2) | Fluxo S3 (worker-1) |
|-------------------|---------------------|---------------------|
| Novo service/classe | ✅ Seguro | ✅ Seguro |
| Novo campo opcional em Parameters | ⚠️ Deploy em baixo movimento | ⚠️ Requer procedimento controlado |
| Alteração em lógica interna | ✅ Seguro | ✅ Seguro |
| Novo método em worker | ✅ Seguro | ✅ Seguro |
| Alteração em ReportMetadata | N/A | ❌ Requer procedimento controlado |
| Alteração em BuildBaseFilters | N/A | ⚠️ Pode afetar queries parciais |

## Referências

- [Hangfire Documentation](https://docs.hangfire.io/)
- [Chart Configurations](/chart/api)
- [Worker Diagrams](/diagrams)

# Guia de Desenvolvimento Local

Este documento descreve como configurar e executar a aplicação DALAR localmente.

## Pré-requisitos

- .NET SDK (versão compatível com o projeto)
- Docker e Docker Compose
- Make (opcional, mas recomendado)

## Setup Inicial

### 1. Configurar variáveis de ambiente

Copie o arquivo `.env.example` para `.env` e configure as variáveis necessárias:

```bash
cp .env.example .env
```

### 2. Restaurar dependências

```bash
dotnet restore
# ou
make restore
```

## Executando a Aplicação

### Usando Make (recomendado)

```bash
# Subir containers de infraestrutura (Redis, Redis Commander)
make up

# Executar aplicação com hot reload
make run
```

### Usando Docker Compose diretamente

```bash
# Subir todos os containers incluindo a aplicação
docker compose up

# Subir apenas infraestrutura
docker compose up redis redis-commander -d
```

### Serviços disponíveis localmente

| Serviço | URL | Descrição |
|---------|-----|-----------|
| API | http://localhost:5000 | Aplicação principal |
| Swagger | http://localhost:5000/swagger | Documentação dos endpoints |
| Hangfire | http://localhost:5000/hangfire | Dashboard de jobs |
| Redis Commander | http://localhost:8081 | UI para visualizar Redis |
| Jaeger | http://localhost:16686 | Tracing distribuído |
| Prometheus | http://localhost:9090 | Métricas |

## Comandos Make Úteis

```bash
make help              # Lista todos os comandos disponíveis

# Testes
make test-unit         # Executa apenas testes unitários (rápido)
make test-integration  # Executa apenas testes de integração
make test-phased       # Executa unit primeiro, depois integration
make test-coverage     # Executa testes com cobertura de código

# Benchmarks
make benchmark         # Inicia CLI interativo de benchmarks
make benchmark-quick   # Benchmarks rápidos (1K-10K records)
make benchmark-stress  # Benchmarks de stress (10K-100K records)

# Infraestrutura
make up                # Sobe containers de infraestrutura
make down              # Para containers
make wipe              # Para containers e remove volumes (CUIDADO!)

# Git
make clear-git-branches  # Remove branches locais exceto main/develop
make diff-name-develop   # Lista arquivos alterados vs develop
make diff-name-main      # Lista arquivos alterados vs main
```

## Estrutura do Projeto

```
src/
└── PaymentsDataLayerReports.Application/
    ├── Routes/          # Endpoints da API
    ├── Workers/         # Background jobs (Hangfire)
    ├── Services/        # Lógica de negócio
    ├── Infra/           # Integrações externas (S3, ES, APIs)
    ├── Entities/        # Modelos de domínio
    └── Settings/        # Configurações

tests/
├── PaymentsDataLayerReports.Unit.Test/        # Testes unitários
├── PaymentsDataLayerReports.Integration.Test/ # Testes de integração
└── PaymentsDataLayerReports.Benchmark/        # Benchmarks de performance
```

## Observabilidade Local

O docker-compose inclui stack de observabilidade:

- **OpenTelemetry Collector**: Coleta traces e métricas
- **Jaeger**: Visualização de traces distribuídos
- **Prometheus**: Armazenamento de métricas

Para usar, certifique-se que os containers estão rodando:

```bash
docker compose up jaeger otel-collector prometheus -d
```

## Dicas

### Hot Reload
O comando `make run` usa `dotnet watch`, então alterações no código são automaticamente recompiladas.

### Testes durante desenvolvimento
Para ciclos rápidos de desenvolvimento, use `make test-unit` que executa apenas testes unitários.

### Debugging
Configure seu IDE para anexar ao processo `dotnet` ou use a configuração de launch incluída em `.vscode/`.

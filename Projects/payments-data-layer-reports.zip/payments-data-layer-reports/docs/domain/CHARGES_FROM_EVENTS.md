# Documentação Completa: ChargeListReportService - Lógicas e Edge Cases

## Visão Geral

Este documento detalha todas as lógicas de negócio e edge cases implementados no `ChargeListReportService.cs`, que é responsável por transformar eventos de charges em charges completas agregadas.

**Fluxo Principal:**
1. Lê eventos CSV linha por linha (streaming)
2. Agrupa eventos pelo ID da charge
3. Para cada grupo, processa os eventos conforme o payment_method
4. Acumula valores, constrói histórico de operações
5. Pós-processa para calcular amounts finais e status

---

## 🔵 CARD (Cartão)

### Operações Suportadas

#### Operações de Detalhe (AppendDetails)
- `authorization` - Autorização de transação
- `auth_and_capture` - Autorização + captura em uma operação
- `pre_auth` - Pré-autorização
- `create` - Criação
- `capture` - Captura de valor autorizado
- `cancel` - Cancelamento
- `cancel_request` - Requisição de cancelamento
- `pay` - Pagamento
- `chargeback` - Estorno forçado
- `chargeback_refund` - Estorno de chargeback

#### Operações de Fees (AppendFees + ComputeFees)
- `discount_rate` - Taxa de desconto (MDR)
- `prepayment_fee` - Taxa de antecipação (RAV)
- `prepayment_fee_refund` - Estorno de taxa de antecipação
- `prepayment_fee` com `fee_type = "turbo"` - Taxa de antecipação Turbo/AutoD0 (venda já antecipada trazida para D0)
- `service_fee` - Taxa de serviço
- `service_fee_refund` - Estorno de taxa de serviço

---

### Edge Cases - CARD

#### 1. **SetFields - Chamado Apenas em Operações Iniciais**

**Contexto:** SetFields define os campos base da charge e é chamado apenas nas primeiras operações.

**Lógica:**
- Operações que chamam SetFields: `authorization`, `auth_and_capture`, `pre_auth`, `create`
- SetFields sobrescreve todos os campos base (id, merchant, card data, customer, etc.)
- Operações subsequentes (`capture`, `cancel`, `chargeback`) apenas adicionam ao histórico sem alterar campos base

**Motivo:** A primeira operação define a estrutura da charge; operações posteriores apenas modificam o estado.

---

#### 2. **Operações de Detalhe Sem Lógica Especial**

**Contexto:** Algumas operações apenas adicionam ao histórico sem processamento adicional.

**Lógica:**
- `cancel_request` e `pay` são tratadas como operações normais de detalhe
- Apenas adicionam entrada ao array `card_transaction__details`
- Não têm lógica especial de validação ou cálculo

**Motivo:** Essas operações servem apenas para tracking de histórico.

---

#### 3. **Chargeback Amount Handling (Pagarme vs Stone/Ton)**

**Contexto:** Chargebacks têm tratamento diferente de amount dependendo da organização.

**Pagarme:**
```csharp
// Para chargeback, usa operation_amount normalmente
operationAmount = currentEvent.GetField<int?>("card_transaction__detail__operation_amount") ?? 0;
```

**Stone/Ton:**
```csharp
// Para chargeback, usa financial_event__amount
if (isChargeback && organization != "pagarme")
    operationAmount = currentEvent.GetField<int?>("card_transaction__detail__financial_event__amount") ?? 0;
```

**Motivo:** Stone/Ton armazenam o valor do chargeback em um campo diferente.

---

#### 4. **Chargeback Deduplication**

**Contexto:** Múltiplos eventos de chargeback podem ser recebidos para a mesma operação.

**Lógica:**
```csharp
if (isChargeback)
{
    // Busca operação existente com mesmo operation_id
    var existing = details.FirstOrDefault(d =>
        d.TryGetValue("operation_id", out var existingId) &&
        existingId?.ToString() == operationId);

    // Se existe, SOMA o amount ao invés de criar nova entrada
    if (existing != null)
    {
        var existingAmount = existing.TryGetValue("operation_amount", out var amt) && amt != null 
            ? Convert.ToInt32(amt) : 0;
        existing["operation_amount"] = existingAmount + operationAmount;
        return;
    }
}
```

**Motivo:** Evita duplicação de chargebacks no histórico, acumulando valores.

---

#### 5. **Financial Movements - Inicialização da Lista**

**Contexto:** A lista de financial_movements é sempre inicializada se não existir.

**Lógica:**
- Se a lista não existe, é criada vazia antes de qualquer processamento
- Antes do cutoff date (01/04/2025), a lista é inicializada vazia e o processamento retorna
- Após o cutoff, a lista é populada com os movimentos financeiros

**Motivo:** Garante que o campo sempre existe, mesmo que vazio.

---

#### 6. **Financial Movements - Cutoff Date**

**Contexto:** Movimentos financeiros só são processados após 01/04/2025.

**Lógica:**
```csharp
var cutoff = new DateTime(2025, 4, 1);
var createdAtStr = currentEvent.GetField<string>("created_at");
_ = DateTime.TryParse(createdAtStr, out DateTime createdAt);

if (createdAt < cutoff)
{
    // Não adiciona movimentos financeiros, apenas inicializa lista vazia
    currentCharge.SetField("card_transaction__financial_movements", new List<Dictionary<string, object?>>());
    return;
}
```

**Motivo:** Mudança de modelo de dados/negócio implementada em abril de 2025.

---

#### 7. **Financial Movements - Update por Event DateTime**

**Contexto:** Múltiplos eventos de fee podem atualizar o mesmo movimento financeiro.

**Lógica:**
```csharp
var existingFinMov = financialMovements.FirstOrDefault(mov =>
    mov.TryGetValue("operation_id", out var oid) && oid?.ToString() == operationId);

if (existingFinMov != null)
{
    // Get the latest event datetime from the existing movement
    var latestEventDateTimeStr = existingFinMov.TryGetValue("latest_event_datetime", out var dt) ? dt?.ToString() : null;
    _ = DateTime.TryParse(latestEventDateTimeStr, out var latestEventDateTime);
    _ = DateTime.TryParse(currentEventDatetime, out var currentEventDateTimeParsed);

    // Only update if the current event is more recent
    if (currentEventDateTimeParsed > latestEventDateTime)
    {
        existingFinMov["current_due_date"] = currentDueDate;
        existingFinMov["latest_event_datetime"] = currentEventDatetime;
        // Atualiza discount_rate e prepayment_fee
    }
}
```

**Motivo:** Garante que sempre temos a informação mais recente de fees, baseado no timestamp do evento.

---

#### 8. **Fee Amount Computation - Inicialização de Valores Zerados**

**Contexto:** Quando fees são null, ambos os campos (decimal e centavos) são inicializados.

**Lógica:**
- Se `full_mdr_amount` é null, inicializa `full_mdr_amount` (decimal) e `mdr_amount` (int) com 0
- Se `full_mdr_refund_amount` é null, inicializa ambos os campos com 0
- Se `full_rav_amount` é null, inicializa ambos os campos com 0
- Se `full_rav_refund_amount` é null, inicializa ambos os campos com 0
- Se `full_fc_amount` é null, inicializa com 0 (apenas decimal)
- Se `full_fc_refund_amount` é null, inicializa com 0 (apenas decimal)

**Motivo:** Garante que cálculos posteriores não falhem com null e mantém consistência entre versões decimal e int.

---

#### 9. **Fee Amount Computation**

**Contexto:** Fees são classificados em três categorias: MDR (discount_rate), RAV (prepayment_fee) e FC (fraud_coverage).

**Lógica (Legacy Fee):**
```csharp
// MDR (full_mdr_amount): discount_rate NEGATIVO ou service_fee
if ((feeType == "discount_rate" && feeFullAmount < 0) || feeType == "service_fee")
    mdr += Math.Abs(feeFullAmount);

// MDR Refund: discount_rate POSITIVO ou service_fee_refund
else if ((feeType == "discount_rate" && feeFullAmount >= 0) || feeType == "service_fee_refund")
    mdrRefund += Math.Abs(feeFullAmount);

// RAV (full_rav_amount): prepayment_fee
else if (feeType == "prepayment_fee")
    rav += Math.Abs(feeFullAmount);

// RAV Refund: prepayment_fee_refund
else if (feeType == "prepayment_fee_refund")
    ravRefund += Math.Abs(feeFullAmount);

// Fee Total = (|MDR| - MDR_Refund) + (|RAV| - RAV_Refund) + (|FC| - FC_Refund)
var fullFee = (Math.Abs(mdr) - mdrRefund) + (Math.Abs(rav) - ravRefund) + (Math.Abs(fc) - fcRefund);
```

**Lógica (Financial Movement - após cutoff 01/04/2025):**
```csharp
// Extrai valores de financial_movement__amount
var discountRateAmount = currentEvent.GetField<Decimal?>("card_transaction__financial_movement__amount__discount_rate__amount");
var prepaymentAmount = currentEvent.GetField<Decimal?>("card_transaction__financial_movement__amount__prepayment_fee__amount");
var fraudCoverageAmount = currentEvent.GetField<Decimal?>("card_transaction__financial_movement__amount__fraud_coverage__amount");

// Valores negativos = fee, positivos = refund
if (discountRateAmount < 0) mdr += Math.Abs(discountRateAmount);
else mdrRefund += Math.Abs(discountRateAmount);

if (prepaymentAmount < 0) rav += Math.Abs(prepaymentAmount);
else ravRefund += Math.Abs(prepaymentAmount);

if (fraudCoverageAmount < 0) fc += Math.Abs(fraudCoverageAmount);
else fcRefund += Math.Abs(fraudCoverageAmount);
```

**Motivo:** Separação entre taxas de MDR, antecipação (RAV) e cobertura de fraude (FC), com tratamento de estornos.

---

#### 9.1. **Turbo Anticipation Fee (prepayment_fee_turbo)**

**Contexto:** A Stone introduziu o tipo de antecipação **Turbo (Nitro/AutoD0)**, no qual uma venda já antecipada é trazida para D0. Esses movimentos chegam com `category = prepayment_fee` e `fee_type = turbo`.

**Estrutura no Financial Movement:**
```json
{
  "amount": {
    "prepayment_fee_turbo": {
      "fee_type": "turbo",
      "fee": 4.0,
      "effective_fee": 2.0,
      "amount": -0.09502
    }
  }
}
```

**Campos:**
- `amount` - Valor monetário real (R$). Campo correto para cálculos de desconto
- `fee` - Taxa nominal (percentual)
- `effective_fee` - Taxa efetiva aplicada (percentual). **NÃO é valor monetário**
- `fee_type` - Sempre `"turbo"` para este tipo de antecipação

**Tratamento na agregação (ComputeFees):**
- `ComputeFeesFromFinancialMovement` (path por evento): lê `prepayment_fee_turbo__amount` e soma ao RAV, alinhado com o ES `setFeeAmounts`
- `ComputeAmountsFromFinancialMovements` (path por charge): lê `prepayment_fee_turbo.amount` de cada FM e soma ao RAV por categoria
- `FinancialMovementAppendHelper`: captura campos `prepayment_fee_turbo` na construção dos FM dictionaries
- `full_rav_amount` e `full_rav_refund_amount` incluem turbo (alinhado com ES)
- `full_fee_amount` e `fee_amount` incluem turbo via RAV consolidado

**Tratamento nos relatórios:**

**Relatório de Vendas OneStone (SaleCsvMapper):**
- Path CET: `CalculateAllMdrFeeAmount` soma TODOS `DiscountRate.Amount` (CET + não-CET) → DESCONTO DE VENDA; `CalculateAllRavFeeAmount` + `CalculateRavTurboFeeAmount` → DESCONTO DE ANTECIPAÇÃO. Não há coluna DESCONTO UNIFICADO, então fees CET são distribuídas entre MDR e RAV
- Path não-CET: `FullRavAmount` já inclui turbo (alinhado com ES), sem adição separada de `ravTurbo`
- Entra no cálculo de `discounts = |discountMdr + discountRav + chargeback + canceledAmount|`

**Relatório de Vendas Stone (SaleStoneCsvMapper):**
- Path CET: `CalculateRavFeeAmount` (não-CET) + `CalculateRavTurboFeeAmount` → DESCONTO DE ANTECIPAÇÃO; fees CET → DESCONTO UNIFICADO via `CalculateCetFeeAmount`
- Path não-CET: `FullRavAmount` já inclui turbo, sem adição separada
- `netAmount` recalculado incluindo turbo

**Relatório de Vendas Ton (SaleTonCsvMapper):**
- Usa `FeeAmount` (centavos, já inclui turbo via RAV consolidado)
- Sem adição separada de turbo — `FeeAmount` é a fonte única de desconto

**Relatório de Recebimentos OneStone (ReceivablesOneStoneCsvBase):**
- Coluna DESCONTO DE ANTECIPAÇÃO = `GetRegularFeeValue(prepaymentFee)` + `GetTurboFeeValue(prepaymentFeeTurbo)`
- Se `fee_type = "CET"`, o `prepaymentFee` regular é zerado; o turbo é exibido normalmente
- Se chargeback, ambos (regular e turbo) são zerados

**Relatório de Recebimentos Legado (ReceivablesModifier):**
- Coluna DESCONTO DE ANTECIPAÇÃO = `GetRegularFeeValue(prepaymentFee)` + `GetTurboFeeValue(prepaymentFeeTurbo)` (mesma lógica do OneStone)
- Path ES: usa `financialMovement.Amount?.PrepaymentFeeTurbo`
- Path S3: lê campos `amount__prepayment_fee_turbo__*` do CsvRow
- Se `fee_type = "CET"`, o `prepaymentFee` regular é zerado; o turbo é exibido normalmente
- Se chargeback, ambos são zerados
- DESCONTO UNIFICADO não é afetado (turbo nunca é CET)

**Path S3/DeltaLake (FinMovListReportService.ComputeAmounts):**
- Movimentos com `fee_type = "turbo"` são separados do `prepayment_fee` regular
- Acumulados em `prepaymentFeeTurboAmount` (separado de `prepaymentFeeAmount`)
- Incluído no cálculo: `netAmount = grossAmount + discountRateAmount + prepaymentFeeAmount + prepaymentFeeTurboAmount + fraudCoverageAmount`

**Motivo:** Turbo é um tipo distinto de antecipação que não deve ser misturado com o RAV regular na contabilização, mas deve compor a coluna DESCONTO DE ANTECIPAÇÃO nos relatórios finais.

---

#### 10. **Failed Amount (Pagarme) - Tracking Interno**

**Contexto:** O valor de `failed` é acumulado mas não usado em cálculos finais.

**Lógica:**
- Operações `not completed` que são `authorization` ou `pre_auth` acumulam em `failed`
- O valor de `failed` não afeta `updated_amount`, `net_amount` ou `status`
- Serve apenas para tracking interno e possível uso futuro

**Motivo:** Separar operações falhas das bem-sucedidas sem impactar cálculos de valor.

---

#### 11. **Auth_and_Capture + Capture Scenario (Stone/Ton)**

**Contexto:** Stone/Ton podem enviar `auth_and_capture` seguido de `capture` separado.

**Lógica:**
```csharp
// Verifica se existe pelo menos um capture
bool hasCapture = details.Any(d =>
    d.TryGetValue("operation", out var op) && op?.ToString() == "capture");

// Se tem capture E a operação é auth_and_capture, converte para authorization
if (hasCapture && operation == "auth_and_capture")
{
    detail["operation"] = "authorization"; // MODIFICA O DETAIL IN-PLACE
    operation = "authorization";
}
```

**Motivo:** Evita contar o mesmo valor duas vezes. A modificação altera o histórico armazenado em `card_transaction__details`.

---

#### 12. **Failed Operations Detection (Stone/Ton) - Códigos de Sucesso**

**Contexto:** Stone/Ton identificam falhas por acquirer_return_code e antifraud_status.

**Lógica:**
```csharp
var acquirerReturnCode = detail.TryGetValue("acquirer_return_code", out var arc) ? arc?.ToString() : null;

// Extração de antifraud_status de JsonElement nested
var antifraudStatus = detail.TryGetValue("antifraud_response", out var afr) &&
    afr is JsonElement afrElement &&
    afrElement.TryGetProperty("status", out var statusElement) ?
    statusElement.GetString() : null;

// Códigos de sucesso: "0000" OU "0"
bool isFailedOperation = (acquirerReturnCode != "0000" && acquirerReturnCode != "0" || antifraudStatus == "reproved") &&
                         operation != "chargeback" && operation != "chargeback_refund";

if (isFailedOperation)
{
    if (operation == "authorization")
    {
        // Apenas authorization falha conta para failed_amount
        failed += operationAmount;
    }
    // Outras operações falhas são ignoradas
}
```

**Motivo:** Apenas autorizações falhas afetam o amount. Chargebacks nunca são considerados falhas. Normalização de códigos de retorno de diferentes adquirentes.

---

#### 13. **Authorization State Validation (Stone/Ton)**

**Contexto:** Authorization com `authorized_state = "None"` é considerada falha.

**Lógica:**
```csharp
if (operation == "authorization")
{
    var authState = currentCharge.GetField<string>("card_transaction__authorized_state");

    if (authState == "None")
    {
        failed += operationAmount;
    }
    else
    {
        authorized += operationAmount;
    }
}
```

**Motivo:** `None` indica que a autorização não foi bem-sucedida.

---

#### 14. **Pagarme - Not Completed Operations**

**Contexto:** Pagarme tem operações que não devem ser contabilizadas.

**Lógica:**
```csharp
if (PagarmeHelper.IsNotCompletedOperation(operationStatus))
{
    if (operation == "authorization" || operation == "pre_auth")
        failed += operationAmount;
    continue; // Ignora a operação
}

// IsNotCompletedOperation verifica:
// - with_error
// - waiting_payment
// - waiting_cancellation
// - declined
// - analyzing
// - created
// - unknown (case insensitive)
```

**Motivo:** Operações incompletas não devem afetar os amounts finais (exceto auth/pre_auth que vão para failed).

---

#### 15. **Pagarme - Auth_and_Capture with waiting_capture**

**Contexto:** `auth_and_capture` com status `waiting_capture` não deve ser capturado.

**Lógica:**
```csharp
if (operation == "auth_and_capture")
{
    authorized += operationAmount;
    if (operationStatus != "waiting_capture")
        captured += operationAmount;
}
```

**Motivo:** `waiting_capture` indica que a captura ainda não ocorreu.

---

#### 16. **Pagarme - Debit Card Authorization Fix**

**Contexto:** Cartões de débito podem não ter `authorized_amount` preenchido.

**Lógica:**
```csharp
if (organization == "pagarme")
{
    var cardTransactionType = currentCharge.GetField<string>("card_transaction__type");
    if (cardTransactionType == "debit" && authorized == 0)
    {
        authorized = captured;
    }
}
```

**Motivo:** Em débito, a autorização e captura são simultâneas, então usa captured como authorized.

---

#### 17. **Updated Amount Calculation**

**Contexto:** Cálculo do valor final da charge considerando chargebacks.

**Lógica:**
```csharp
// Base: se tem captured, usa captured, senão usa authorized
var updatedAmount = captured > 0 ? captured - canceled : authorized - canceled;

// Aplica chargebacks
if (chargeback > 0)
    updatedAmount = updatedAmount - chargeback + chargebackRefund;

// Garante não-negativo
updatedAmount = Math.Max(updatedAmount, 0);
```

**Motivo:** Chargebacks reduzem o valor, mas chargeback_refund restaura.

---

#### 18. **Net Amount Calculation**

**Contexto:** Valor líquido após dedução de fees.

**Lógica:**
```csharp
var fullFeeAmount = currentCharge.GetField<Decimal?>("card_transaction__full_fee_amount") ?? 0;
var fullNetAmount = Math.Max((updatedAmount / 100m) - fullFeeAmount, 0);
var netAmount = (int)Math.Round(fullNetAmount * 100);
```

**Motivo:** Fees são em decimal (reais), amounts em int (centavos).

---

#### 19. **Status Computation (Pagarme)**

**Contexto:** Pagarme usa o último `operation_status` para determinar status.

**Lógica:**
```csharp
// Pega o último operation_status ordenado por provider_datetime
var statusFromSource = PagarmeHelper.GetLastOperationStatus(details);

// Mapeia para status final
return PagarmeHelper.GetStatus(statusFromSource, authorizedAmount, capturedAmount, "card");

// Mapeamento:
// - "waiting_capture" -> "authorized"
// - "analyzing", "waiting_payment", "pending", etc -> "processing"
// - "pay", "captured", "paid", etc -> "paid"
// - "declined" -> "failed"
// - "created", "canceled", "chargeback", "failed" -> mantém
// - "with_error" -> "paid" (se captured > 0), "processing" (se authorized > 0), senão "failed"
```

**Motivo:** Pagarme tem estados mais granulares que precisam ser mapeados.

---

#### 20. **Status Computation (Stone/Ton) - Ordem de Precedência**

**Contexto:** Stone/Ton usam lógica baseada em amounts e validações com ordem de precedência.

**Lógica:**
```csharp
// Verifica se todas as operações são inválidas
bool hasOnlyInvalidOperation = details.All(i =>
    (acquirerReturnCode != "0000" && acquirerReturnCode != "0") || antifraudStatus == "reproved"
);

bool hasInvalidAuthorizedState = authorizedState == "None";

// Ordem de avaliação (cada condição sobrescreve a anterior):
if (authorizedAmount > 0) status = "authorized";              // 1. Autorizado
if (capturedAmount > 0) status = "paid";                       // 2. Pago (sobrescreve authorized)
if (canceledAmount > 0 && (canceledAmount == capturedAmount || canceledAmount == authorizedAmount))
    status = "canceled";                                       // 3. Cancelado
if (chargebackAmount > 0 && (chargebackAmount == capturedAmount || chargebackAmount == authorizedAmount))
    status = "chargeback";                                     // 4. Chargeback
if (chargebackRefundAmount > 0) status = "paid";               // 5. Pago (restaura após chargeback)
if (hasOnlyInvalidOperation || hasInvalidAuthorizedState) status = "failed"; // 6. Failed (SEMPRE PREVALECE)
```

**Motivo:** `failed` tem maior precedência e sempre sobrescreve outros status quando operações são inválidas.

---

## 🟢 BOLETO

### Operações Suportadas
- `pay` - Pagamento do boleto
- `cancel` - Cancelamento do boleto

---

### Edge Cases - BOLETO

#### 1. **Events Without Details**

**Contexto:** Alguns eventos de boleto não têm dados de detalhe.

**Lógica:**
```csharp
var operation = currentEvent.GetField("boleto_transaction__detail__operation");

if (operation == null)
    return; // Ignora o evento
```

**Motivo:** Eventos parciais ou de criação podem não ter detalhes.

---

#### 2. **Pagarme - Not Completed Operations**

**Contexto:** Similar ao card, operações incompletas são ignoradas.

**Lógica:**
```csharp
if (organization == "pagarme")
{
    if (PagarmeHelper.IsNotCompletedOperation(operation))
    {
        continue; // Ignora a operação
    }
}
```

---

#### 3. **Updated Amount - Sem Conceito de Authorized**

**Contexto:** Boleto não tem fase de autorização, apenas pagamento.

**Lógica:**
- `updatedAmount = paid > 0 ? paid - canceled : 0`
- Diferente de card que usa `captured > 0 ? captured - canceled : authorized - canceled`

**Motivo:** Boleto é pago diretamente, sem autorização prévia.

---

#### 4. **Status Computation (Stone/Ton)**

**Contexto:** Boletos sem `our_number` ou `amount = 0` não têm status definido.

**Lógica:**
```csharp
// Para Stone/Ton
if (amount == 0 || ourNumber == null)
    return null; // Status fica null

if (paidAmount == 0)
    status = "created";

if (paidAmount > 0)
    status = "paid";

if ((canceledAmount > 0 && canceledAmount == paidAmount) || (canceledAmount > 0 && paidAmount == 0))
    status = "canceled";
```

**Motivo:** Eventos parciais de Ton podem não ter `our_number`, indicando que o boleto não foi completamente criado.

---

#### 5. **Status Computation (Pagarme)**

**Contexto:** Usa o último operation_status.

**Lógica:**
```csharp
var statusFromSource = PagarmeHelper.GetLastOperationStatus(details);

if (string.IsNullOrEmpty(statusFromSource))
    return "failed";

return PagarmeHelper.GetStatus(statusFromSource, paidAmount, canceledAmount, "boleto");
```

---

#### 6. **Net Amount Calculation**

**Contexto:** Fee pode vir de financial_movements (após cutoff) ou do campo legacy.

**Lógica:**
```csharp
// Usa full_fee_amount se disponível (calculado de financial_movements), senão usa fee_amount legacy
var fullFeeAmount = currentCharge.GetField<Decimal?>("boleto_transaction__full_fee_amount");
var feeAmount = currentCharge.GetField<Decimal?>("boleto_transaction__fee_amount") ?? 0;
var feeToUse = fullFeeAmount ?? (feeAmount / 100m);
var fullNetAmount = Math.Max((updatedAmount / 100m) - feeToUse, 0);
```

**Motivo:** Suporta tanto o modelo antigo (fee_amount em centavos) quanto o novo (full_fee_amount de financial_movements).

---

#### 7. **Fee Computation from Financial Movements**

**Contexto:** Boleto e Pix usam `FinancialMovementFeeHelper.ComputeFeesFromFinancialMovements` para calcular fees.

**Lógica:**
- Itera sobre `boleto_transaction__financial_movements` ou `pix_transaction__financial_movements`
- Acumula fees por categoria: `sale`, `reversal`, `partial_reversal`, `refund_reversal`
- Extrai `discount_rate`, `prepayment_fee` e `fraud_coverage` de cada movimento
- Calcula totais consolidados de MDR, RAV e FC

**Motivo:** Modelo unificado de cálculo de fees a partir de financial_movements para Boleto e Pix.

---

## 🟣 PIX

### Operações Suportadas
- `pay` - Pagamento via PIX
- `cancel` - Cancelamento/Estorno

---

### Edge Cases - PIX

#### 1. **Events Without Details**

**Contexto:** Alguns eventos PIX não têm dados de detalhe.

**Lógica:**
```csharp
var operation = currentEvent.GetField("pix_transaction__detail__operation");

if (operation == null)
    return; // Ignora o evento
```

---

#### 2. **Pagarme - Not Completed Operations**

**Contexto:** Similar aos outros payment methods.

**Lógica:**
```csharp
if (organization == "pagarme")
{
    if (PagarmeHelper.IsNotCompletedOperation(operation))
    {
        continue;
    }
}
```

---

#### 3. **Status Computation (Stone/Ton)**

**Contexto:** Status baseado em amounts.

**Lógica:**
```csharp
if (paidAmount == 0 && canceledAmount == 0)
    status = "created";

if (paidAmount > 0)
    status = "paid";

if ((canceledAmount > 0 && canceledAmount == paidAmount) || (canceledAmount > 0 && paidAmount == 0))
    status = "canceled";
```

---

#### 4. **Status Computation (Pagarme)**

**Contexto:** Usa último operation_status.

**Lógica:**
```csharp
var statusFromSource = PagarmeHelper.GetLastOperationStatus(details);

if (string.IsNullOrEmpty(statusFromSource))
    return "failed";

return PagarmeHelper.GetStatus(statusFromSource, paidAmount, canceledAmount, "pix");
```

---

#### 5. **Fee Amount Handling**

**Contexto:** Fee pode estar em centavos ou reais dependendo da fonte.

**Lógica:**
```csharp
var feeAmount = currentCharge.GetField<decimal?>("pix_transaction__fee_amount") ?? 0m;
var fullFeeAmount = feeAmount != 0 ? feeAmount / 100m : 0m;
var fullNetAmount = Math.Max((updatedAmount / 100m) - fullFeeAmount, 0);
```

**Motivo:** Normalização para trabalhar em reais.

---

#### 6. **Updated Amount - Garantia Dupla de Não-Negativo**

**Contexto:** O código aplica Math.Max duas vezes para updatedAmount.

**Lógica:**
- Primeira aplicação após cálculo: `updatedAmount = Math.Max(updatedAmount, 0)` (linha 1139)
- Segunda aplicação antes de usar: `updatedAmount = Math.Max(updatedAmount, 0)` (linha 1147)

**Motivo:** Redundância para garantir valor não-negativo em qualquer cenário.

---

## 🟡 CASH (Dinheiro)

### Operações Suportadas
- `pay` - Pagamento em dinheiro
- `cancel` - Cancelamento

---

### Edge Cases - CASH

#### 1. **Events Without Details**

**Contexto:** Alguns eventos cash não têm dados de detalhe.

**Lógica:**
```csharp
var operation = currentEvent.GetField("cash_transaction__detail__operation");

if (operation == null)
    return; // Ignora o evento
```

---

#### 2. **Not Completed Operations (Todos) - Implementação Local**

**Contexto:** Cash tem sua própria implementação de IsNotCompletedOperation.

**Lógica:**
- A lógica é **idêntica** ao PagarmeHelper.IsNotCompletedOperation
- Implementada localmente no CashProcessor por questões de organização de código
- Valida os mesmos status: with_error, waiting_payment, waiting_cancellation, declined, analyzing, created, unknown

**Motivo:** Manter o CashProcessor independente, mesmo com lógica duplicada.

---

#### 3. **Not Completed Operations - Detalhes da Implementação**

**Contexto:** Validação de operation_status antes de processar.

**Lógica:**
```csharp
private static bool IsNotCompletedOperation(string operationStatus)
{
    if (string.IsNullOrEmpty(operationStatus))
        return true;

    operationStatus = operationStatus.ToLower();
    return operationStatus == "with_error" ||
           operationStatus == "waiting_payment" ||
           operationStatus == "waiting_cancellation" ||
           operationStatus == "declined" ||
           operationStatus == "analyzing" ||
           operationStatus == "created" ||
           operationStatus.Contains("unknown", StringComparison.CurrentCultureIgnoreCase);
}
```

**Motivo:** Cash valida operation_status antes de processar qualquer operação.

---

#### 4. **Cancel Amount from Legacy**

**Contexto:** Valor de cancelamento vem do campo legacy.

**Lógica:**
```csharp
if (operation == "cancel")
{
    var legacyDetails = detail.TryGetValue("legacy", out var legacyRawObj) 
        ? legacyRawObj as Dictionary<string, object?> : null;
    
    if (legacyDetails != null)
    {
        var canceledAmountStr = legacyDetails.TryGetValue("canceled_amount", out var canceledAmountObj) 
            ? canceledAmountObj?.ToString() : null;
        
        if (canceledAmountStr != null)
        {
            bool success = int.TryParse(canceledAmountStr, out int canceledAmount);
            if (success)
                canceled += canceledAmount;
        }
    }
}
```

**Motivo:** Estrutura de dados específica do cash onde canceled_amount está em legacy.

---

#### 5. **Status Computation**

**Contexto:** Cash SEMPRE usa lógica Pagarme (mesmo para Stone/Ton).

**Lógica:**
```csharp
private static string? ComputeStatus(int paidAmount, int canceledAmount, List<Dictionary<string, object?>> details = null)
{
    // Sempre usa PagarmeHelper, independente da organização
    var statusFromSource = PagarmeHelper.GetLastOperationStatus(details);

    if (string.IsNullOrEmpty(statusFromSource))
        return "failed";

    return PagarmeHelper.GetStatus(statusFromSource, paidAmount, canceledAmount, "cash");
}
```

**Motivo:** Cash tem comportamento unificado entre organizações.

---

#### 6. **No Fee Deduction**

**Contexto:** Cash não tem fees deduzidos.

**Lógica:**
```csharp
var fullNetAmount = Math.Max((updatedAmount / 100m), 0);
var netAmount = (int)Math.Round(fullNetAmount * 100);
```

**Motivo:** Pagamentos em dinheiro não têm taxas de processamento.

---

## 🔧 PagarmeHelper - Lógicas Compartilhadas

### IsNotCompletedOperation

**Operações não completadas:**
- `with_error`
- `waiting_payment`
- `waiting_cancellation`
- `declined`
- `analyzing`
- `created`
- `unknown` (case insensitive)

---

### GetLastOperationStatus

**Lógica:**
```csharp
// Ordena details por provider_datetime
// Retorna o operation_status do último detail
var lastDetail = details
    .Where(d => d.ContainsKey("provider_datetime") && d["provider_datetime"] != null)
    .OrderBy(d => DateTime.TryParse(d["provider_datetime"]?.ToString(), out var dt) ? dt : DateTime.MinValue)
    .LastOrDefault();

return lastDetail?.TryGetValue("operation_status", out var status) ? status?.ToString() : null;
```

**Motivo:** O status mais recente é o que define o estado atual da charge.

---

### GetStatus - Status Mapping

**Mapeamento de status Pagarme:**

- `"authorized"` ← `["waiting_capture"]`
- `"processing"` ← `["analyzing", "waiting_payment", "pending", "waiting_cancellation", "pending_authentication"]`
- `"paid"` ← `["over_paid", "partial_capture", "pay", "under_paid", "partial_cancel", "captured", "paid"]`
- `"failed"` ← `["declined"]`
- `"default"` ← `["created", "canceled", "chargeback", "failed"]` (mantém o status original)

**Caso especial: "with_error"**
- Se `capturedAmount > 0` → `"paid"`
- Se `paymentMethod == "card"` e `authorizedAmount > 0` → `"processing"`
- Caso contrário → `"failed"`

**Fallback para status desconhecido:**
- Qualquer status não mapeado retorna `"failed"`

**Motivo:** Normalização de múltiplos estados Pagarme para estados padrão do sistema, com fallback seguro.

---

## 📊 Resumo de Diferenças por Organização

### PAGARME
- ✅ Usa `operation_status` para filtrar operações não completadas
- ✅ Status determinado pelo último `operation_status` + mapeamento
- ✅ `auth_and_capture` com `waiting_capture` não conta como captured
- ✅ Cartão débito: se `authorized = 0`, usa `captured` como `authorized`
- ✅ Chargeback usa `operation_amount` normalmente

### STONE / TON
- ✅ Valida operações por `acquirer_return_code` e `antifraud_status`
- ✅ Status determinado por lógica de amounts + validações
- ✅ `auth_and_capture` + `capture` separados: converte auth_and_capture para authorization
- ✅ `authorized_state = "None"` indica falha
- ✅ Chargeback usa `financial_event__amount`
- ✅ Boleto sem `our_number` ou `amount = 0` não tem status

### CASH (TODOS)
- ✅ Sempre usa lógica Pagarme (PagarmeHelper)
- ✅ Valida `operation_status` antes de processar
- ✅ `canceled_amount` vem de `legacy.canceled_amount`
- ✅ Sem fees

---

## 🎯 Campos Importantes

### DateTime Handling
```csharp
// SEMPRE usar DateTime? para evitar NullReferenceException
var createdAt = currentEvent.GetField<DateTime?>(inputHeaderIndex, "created_at");
if (createdAt != default && createdAt.HasValue)
    currentCharge.SetField(..., createdAt.Value.ToString("yyyy-MM-ddTHH:mm:ss.fffK"));
```

### Amount Conversions
- **Centavos (int):** Valores de operação, amounts acumulados
- **Reais (decimal):** Fees, net amounts
- **Conversão:** `amount / 100m` (centavos → reais), `(int)Math.Round(amount * 100)` (reais → centavos)

### Non-Negative Guarantees
```csharp
// SEMPRE garantir que amounts finais não sejam negativos
authorized = Math.Max(authorized, 0);
captured = Math.Max(captured, 0);
canceled = Math.Max(canceled, 0);
updatedAmount = Math.Max(updatedAmount, 0);
fullNetAmount = Math.Max(fullNetAmount, 0);
```

---

## 🔍 Fluxo de Processamento

```
1. ProcessAsync (Main Loop)
   ├─ Lê eventos linha por linha (streaming)
   ├─ Agrupa por ID
   ├─ Reutiliza CsvRow com ClearRow(DefaultValues) para otimização de memória
   └─ Para cada grupo:
       ├─ ProcessChargeEventRow (por payment_method)
       │   ├─ SetFields (primeira operação apenas)
       │   ├─ AppendDetails (histórico)
       │   └─ AppendFees + ComputeFees (card only)
       └─ PostProcessCharge
           └─ ComputeAmounts
               ├─ Acumula amounts por operação
               ├─ Aplica regras de organização
               ├─ Calcula updated_amount
               ├─ Calcula net_amount
               └─ Computa status final
```

---

## 📝 Notas Finais

1. **Streaming:** Todo o processamento é feito em streaming para suportar arquivos grandes com baixo consumo de memória.

2. **Reutilização de Objetos:** CsvRow é reutilizado entre charges com ClearRow para otimização de memória.

3. **Imutabilidade de Eventos:** Eventos são apenas lidos, nunca modificados (exceto conversão de `auth_and_capture` para `authorization` que modifica o detail in-place).

4. **Agregação:** Múltiplos eventos são agregados em uma única charge, com histórico completo em arrays.

5. **Validações:** Sempre validar nulls, usar tipos nullable para DateTime, e garantir amounts não-negativos.

6. **Organização:** A maior parte das diferenças está entre Pagarme vs (Stone/Ton), com Cash sendo exceção (sempre usa lógica Pagarme).

7. **Extensibilidade:** Cada payment_method tem seu próprio Processor, facilitando adição de novos métodos no futuro.

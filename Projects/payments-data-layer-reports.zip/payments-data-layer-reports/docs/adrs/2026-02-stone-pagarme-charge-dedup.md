# Deduplicação Stone-Pagarme no Relatório de Charges

| | |
|---|---|
| **Status** | Proposta |
| **Proposta em** | 2026-02-25 |
| **Implementada em** | 2026-03-06 |
| **Task** | [AFDAL-297](https://allstone.atlassian.net/browse/AFDAL-297) |
| **PR** | [530](https://github.com/stone-payments/payments-data-layer-reports/pull/530) |

## Contexto

Estamos num projeto de unificação das empresas Stone e Pagarme, absorvendo os clientes Pagarme para dentro da Stone. A Pagarme é um gateway de adquirência que usa a Stone como adquirente — ou seja, as transações da Pagarme também passam pela Stone quando a Stone é adquirente utilizada, gerando eventos em ambas as organizações.

O time camada da leitura ouve eventos de ambas as orgs, e ao gerar o relatório de charges a mesma transação pode aparecer duplicada: uma charge com ID numérico (vinda dos eventos Stone) e outra com ID `ch_...` (vinda dos eventos Pagarme). Como os IDs são completamente diferentes, a deduplicação atual — que opera sobre `event_id` e agrupa por `id` — não consegue identificar que se trata da mesma cobrança.

A chave que conecta as duas é o campo `card_transaction__detail__acquirer__nsu` dos eventos Pagarme, que contém o `id` da charge Stone correspondente (quando o acquirer é "Stone").

### Objetivo

Nesta iteração, queremos **dropar os eventos Stone** quando existir o equivalente Pagarme, mantendo apenas as charges Pagarme no relatório. Numa iteração futura, o plano é evoluir para aproveitar alguns eventos Stone (taxas) para enriquecer a charge Pagarme.

## Decisão

Pra resolver a duplicação, a estratégia é:

1. **Introduzir uma coluna computada `sort_key`** no CSV gerado pelo DuckDB. Essa coluna serve como chave de agrupamento que unifica eventos Stone e Pagarme da mesma transação. Pra eventos Pagarme que usam Stone como adquirente, o `sort_key` assume o valor do `card_transaction__detail__acquirer__nsu` (que é o ID da charge Stone). Pra todos os outros eventos, assume o `id` original. Dessa forma, eventos de ambas as orgs que pertencem à mesma transação passam a compartilhar o mesmo `sort_key`.

2. **Agrupar eventos pelo `sort_key`** em vez de agrupar apenas pelo `id`. Com o sort do CSV usando `sort_key` como critério primário, eventos duplicados ficam adjacentes no arquivo — mesmo tendo IDs diferentes.

3. **Priorizar eventos Pagarme quando houver conflito.** Ao processar um grupo de eventos com o mesmo `sort_key`, se existirem eventos de ambas as orgs, dropar todos os eventos Stone e processar apenas os Pagarme.

4. **Nesta iteração, dropar todos os eventos Stone** (incluindo taxas). Isso significa que as charges Pagarme resultantes terão taxas zeradas. Numa iteração futura, os eventos de taxa Stone serão aproveitados pra enriquecer a charge Pagarme.

### Definições

| # | Decisão | Resolução |
|---|---|---|
| 1 | Posição do `sort_key` | Primeira coluna do CSV |
| 2 | Lógica de drop | Dropar todos os eventos Stone (incluindo taxas) |
| 3 | Feature flag | Sem flag — a dedup é feita verificando a org de cada evento dentro do grupo |
| 4 | Abordagem de processamento | Acumular todos os eventos do grupo → verificar orgs → filtrar → processar |

---

## Implementação

### Fase 1: Gerar `sort_key` como primeira coluna (DuckDB)

#### Alterar `ChargeListReportQuery.cs`

Adicionar a coluna `sort_key` ao início do `SELECT` em `SelectChargesEventsAsync`. A expressão SQL:

```sql
CASE 
  WHEN payment_method = 'card' 
    AND lower(card_transaction__detail__acquirer__name) = 'stone'
    AND card_transaction__detail__acquirer__nsu IS NOT NULL
    AND card_transaction__detail__acquirer__nsu != ''
  THEN card_transaction__detail__acquirer__nsu 
  ELSE id 
END AS sort_key
```

Essa coluna serve pra agrupar eventos Stone e Pagarme que representam a mesma transação. Ela é usada apenas pro sort e agrupamento — não vai pro output final.

> **`sort_key` não pode ser um `DeltaTableColumnModel`.**
> Cada `DeltaTableColumnModel` representa uma coluna de origem com um transform opcional (ex: `REPLACE(...)`, `to_json(...)`), e o `ToSqlColumn` mapeia apenas **uma** coluna física pra **uma** lógica. A `sort_key` é um CASE que depende de múltiplas colunas (`payment_method`, `card_transaction__detail__acquirer__name`, `card_transaction__detail__acquirer__nsu`, `id`), então não se encaixa nesse modelo. Precisa ser injetada como SQL puro no `SelectChargesEventsAsync`, antes das `sqlColumns` geradas.

> **Column mapping entre parquet e realtime.**
> O método `SelectChargesEventsAsync` monta duas queries separadas:
> - **Parquet**: `SELECT {sqlColumnsStr} FROM (SELECT *, {nullClauses} FROM read_parquet(...)) AS base`. Aqui, as colunas dentro de `base` têm os **nomes físicos** do parquet. Então, a expressão `sort_key` precisa referenciar esses nomes físicos — que podem ser diferentes dos lógicos caso haja column mapping configurado. Pra resolver cada nome, usar `GetColumnNameForFilter(nomeLogico, columnMapping)`.
> - **Realtime**: `SELECT {sqlColumns} FROM read_csv([...], all_varchar=True)`. Aqui, as colunas já têm os nomes lógicos, então a expressão `sort_key` usa os nomes diretamente.
>
> Na prática, a expressão CASE do `sort_key` precisa ser construída duas vezes — uma pra cada tipo de query.

Locais exatos no código:
- **Parquet** (linhas 531-542): colocar a expressão `sort_key` (com nomes físicos) antes de `{sqlColumnsStr}`
- **Realtime** (linhas 557-561): colocar a expressão `sort_key` (com nomes lógicos) antes do `string.Join(...)` das sqlColumns

---

#### Alterar `ChargeListReportManager.cs`

Com `sort_key` como primeira coluna, todas as posições originais deslocam +1:

| Coluna | Posição antes | Posição depois |
|---|---|---|
| `sort_key` | — | 1 |
| `event_id` | 1 | 2 |
| `event_datetime` | 2 | 3 |
| `id` | 3 | 4 |

O comando de sort em `SortEventsByChargeId` faz duas coisas em sequência:

**1. Ordenação** — o objetivo principal é agrupar eventos de uma mesma charge. Os critérios de desempate organizam eventos repetidos pra que a dedup funcione corretamente:

| Prioridade | Antes | Depois | Propósito |
|---|---|---|---|
| 1ª | `-k3,3` (`id`) | `-k1,1` (`sort_key`) | Agrupa eventos da mesma charge |
| 2ª | `-k1,1` (`event_id`) | `-k2,2` (`event_id`) | Agrupa eventos duplicados (mesmo event_id) |
| 3ª | `-k2,2r` (`event_datetime` desc) | `-k3,3r` (`event_datetime` desc) | Mais recente primeiro, pra dedup manter o mais atual |

**2. Deduplicação** — `awk` percorre as linhas ordenadas e mantém apenas a primeira ocorrência de cada `event_id`. Como o sort coloca o mais recente primeiro (`-r`), a dedup preserva o evento mais atual:

| Antes | Depois |
|---|---|
| `$1` (`event_id`) | `$2` (`event_id`) |

```diff
-var sortByIdEventIdEventDateCommand = $"sort -t, -k3,3 -k1,1 -k2,2r --buffer-size=50M";
-var dedupByEventIdCommand = $"awk -F, '$1 != last {{print; last = $1}}'";
+var sortByIdEventIdEventDateCommand = $"sort -t, -k1,1 -k2,2 -k3,3r --buffer-size=50M";
+var dedupByEventIdCommand = $"awk -F, '$2 != last {{print; last = $2}}'";
```

---

### Fase 2: Acumular e dropar eventos no processamento

#### Alterar `ChargeListReportService.ProcessAsync`

Refatorar o loop do `ProcessAsync` (linhas 44-74). Hoje ele lê evento a evento e processa imediatamente. O problema é que, se o primeiro evento do grupo for Stone, ele já vai ser processado — e quando aparecer o Pagarme, seria necessário descartar tudo e reprocessar.

A nova abordagem evita isso: primeiro acumula todos os eventos de um grupo, depois decide o que processar.

**Fluxo novo:**
1. Ler cada linha e extrair o `sort_key` via `inputHeaderIndex["sort_key"]`
2. Enquanto o `sort_key` for o mesmo, acumular as linhas brutas em uma `List<string>`
3. Quando o `sort_key` mudar (ou chegar no EOF), processar o grupo acumulado:
   - Fazer um scan rápido pra verificar a `merchant__organization` de cada evento (parseando com `CsvHelper.ParseCsvRow`)
   - Se existem eventos de **ambas** as orgs (stone + pagarme) → filtrar só os pagarme
   - Caso contrário → manter todos os eventos
   - Processar cada evento filtrado com `ProcessChargeEventRow`
   - Escrever a charge com `WriteCsvRow`
   - Limpar o acumulador e o `currentCharge`

> O `inputHeaderIndex` é construído dinamicamente a partir do header do CSV que o DuckDB gera. Ao adicionar `sort_key` como primeira coluna, o dicionário se ajusta sozinho: `sort_key=0, event_id=1, ..., id=3`. Acessos como `inputHeaderIndex["id"]` continuam funcionando sem nenhum ajuste manual.

---

### Fase 3: Atualizar teste

#### Alterar `Case01_StonePagarmeDedup/expected.csv`

Atualizar pra refletir o novo comportamento — 2 charges (apenas Pagarme) em vez de 4:
- Remover `14262173648222` (Stone, era duplicata de `ch_7Gd0EGZSmaTKpj6b`)
- Remover `14262160708435` (Stone, era duplicata de `ch_6Lem0P8CWhL0EM2d`)

As charges Pagarme restantes vão ficar com taxas zeradas (MDR/RAV = 0), já que os eventos de taxa vêm exclusivamente da Stone e estão sendo dropados. Isso é esperado nesta iteração.

> **O `input.csv` não deve ser alterado.** Ele é copiado como `realtime.csv` no diretório de parquet e processado pelo DuckDB com `read_csv`. O DuckDB vai computar o `sort_key` automaticamente a partir da query modificada.

---

## Arquivos que NÃO precisam de alteração

| Arquivo | Motivo |
|---|---|
| `ChargeListReportGenerator` | Orquestra o fluxo chamando `SortEventsByChargeId`, `GetHeader`, `ProcessAsync` na mesma ordem. O `GetHeader` já vai pegar o header com `sort_key` do output do DuckDB |
| `ChargeListReportHeader` | Define o header de **output**. `sort_key` é coluna de **input** apenas, não vai pro relatório final |
| `DeltaLakeManager` | Apenas executa a query retornada pelo `ChargeListReportQuery` — a mudança é na query, não no executor |
| `CsvHelper` | `GetHeader` e `ParseCsvRow` são genéricos — funcionam com qualquer número de colunas |
| `ChargeListReportGeneratorTests` | Usa `DeltaLakeManager` real (DuckDB real) — a query modificada gera o `sort_key` automaticamente |
| `input.csv` | O DuckDB processa esse arquivo e computa o `sort_key` — não precisa de alteração manual |

---

## Edge Cases

| Cenário | Comportamento esperado |
|---|---|
| Apenas eventos Stone (sem Pagarme) | `sort_key = id`. Sem dedup, charge Stone segue normal |
| Apenas eventos Pagarme (sem Stone) | `sort_key = nsu` (se acquirer=Stone) ou `sort_key = id`. Sem dedup |
| Pagarme com acquirer diferente de Stone | `sort_key = id` (fallback). Não agrupa com Stone, sem dedup |
| Pagarme com acquirer=Stone mas `nsu` vazio | `sort_key = id` (fallback). Não agrupa com Stone |
| Stone + Pagarme no mesmo grupo | Eventos Stone são dropados. Charge final = Pagarme sem taxas |

---

## Verificação

### Teste automatizado

```bash
export LC_ALL=C && export LC_NUMERIC=C && dotnet test tests/PaymentsDataLayerReports.Integration.Test \
  --filter "FullyQualifiedName~ChargeListReportGeneratorTests.ProcessAsync" \
  --verbosity normal
```

### O que validar
- Output contém exatamente 2 charges (as Pagarme)
- Dados das charges Pagarme estão intactos (customer, details, amounts)
- taxas zeradas nas charges Pagarme (esperado nesta iteração)

# Architecture Decision Records

Registros de decisões e planos de alteração.

Cada arquivo documenta o contexto, decisões e mudanças planejadas para uma alteração significativa no sistema. O objetivo é manter um histórico consultável de **por que** e **como** as mudanças foram feitas.

## Formato

Não há modelo rígido — cada cenário pode ser descrito da forma que for melhor. O mínimo esperado é:

- **Título e header** com status, datas e links (task, PR)
- **Contexto** do problema
- **Objetivo** da mudança
- **Decisão** tomada e o raciocínio por trás
- **Implementação** detalhando o que muda no código

## Convenção de nomes

```
YYYY-MM-<descricao-curta>.md
```

Exemplo: `2026-02-stone-pagarme-charge-dedup.md`

## Status

| Status | Significado |
|---|---|
| Proposta | Plano em elaboração ou aguardando aprovação |
| Em andamento | Implementação em progresso |
| Concluído | Implementado e validado |
| Descartado | Plano abandonado (manter pra contexto histórico) |

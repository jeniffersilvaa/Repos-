# Arquitetura da DALAR

Este documento descreve a arquitetura de alto nível da aplicação Data Layer Reports (DALAR).

## Visão Geral

A DALAR é uma aplicação de geração de relatórios assíncronos que utiliza múltiplas fontes de dados e destinos de armazenamento.

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   Client API    │────▶│    Hangfire     │────▶│    Workers      │
│  (HTTP + Queue) │     │    (Redis)      │     │  (Processing)   │
└─────────────────┘     └─────────────────┘     └─────────────────┘
                                                        │
                        ┌───────────────────────────────┼───────────────────────────────┐
                        ▼                               ▼                               ▼
               ┌─────────────────┐             ┌─────────────────┐             ┌─────────────────┐
               │  Elasticsearch  │             │   S3 DeltaTable │             │   S3 Output     │
               │   (Source)      │             │    (Source)     │             │   (Destination) │
               └─────────────────┘             └─────────────────┘             └─────────────────┘
```

## Fontes de Dados

### Elasticsearch
- Usado para relatórios com dados recentes (últimos 6 meses)
- Índices: `chargesv3_*`, `charge_event`, etc.
- Acesso via Data Layer API (DALAPI)

### S3 DeltaTable
- Usado para relatórios históricos (> 6 meses)
- Dados particionados por data
- Formato Parquet otimizado para leitura

## Fluxos de Processamento

### Fluxo Elasticsearch (worker-2)

```
Request → API → Enqueue Job → Worker processa → Upload S3 → Notificação
```

**Características:**
- Processamento direto em um único job
- Consulta via DALAPI com cursor/paginação
- Streaming de dados para S3

**Workers:** `ChargeReportWorker`, `FinMovWorker`, `OrderReportESWorker`

### Fluxo S3/DeltaTable (worker-1)

```
Request → API → Dispatch → [Workers paralelos por partição] → Concat → Notificação
```

**Características:**
- Processamento distribuído por partições de data
- Cada partição gera um arquivo parcial
- Concatenação final dos arquivos parciais
- Metadata file coordena o fluxo

**Workers:** `ChargeReportS3Dispatch`, `ChargeReportS3Worker`, `ChargeReportS3Concat`

## Deployments

A aplicação roda em múltiplos deployments para separação de responsabilidades:

| Deployment | Responsabilidade | Filas Hangfire |
|------------|------------------|----------------|
| data-layer-reports | API | |
| worker-1 | Processamento S3 | `s3_reports`, `s3_reports_dispatch` |
| worker-2 | Processamento ES | `reports`, `notifications` |
| pre-deploy | Shadow testing | Todas (ambiente isolado) |

## Armazenamento

### Redis
- Fila de jobs do Hangfire
- Serialização de parâmetros em JSON
- State management de jobs

### S3
- **Input:** DeltaTable com dados históricos particionados
- **Output:** Relatórios finais gerados (CSV, XLSX)
- **Temp:** Arquivos parciais durante processamento

## Formatos de Saída

| Formato | Extensão | Características |
|---------|----------|-----------------|
| CSV | `.csv` | Streaming, baixa memória |
| XLSX | `.xlsx` | Requer mais memória, limite de linhas do Excel |

## Notificações

Após conclusão do relatório, notificações podem ser enviadas via:
- **Email:** Através da Acquirer Reports API
- **Webhook:** Callback HTTP para URL configurada

## Considerações de Performance

### Streaming
- Dados são processados em streaming sempre que possível
- Evita carregar datasets completos em memória
- Upload multipart para S3

### Paralelização
- Fluxo S3 processa partições em paralelo
- Autoscaling baseado em tamanho de fila

### Alocações
- Writers otimizados para zero/mínimas alocações por record
- StringBuilder reutilizável para construção de linhas CSV

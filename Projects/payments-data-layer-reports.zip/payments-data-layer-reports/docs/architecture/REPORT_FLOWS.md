# Fluxos de Geração de Relatórios

Este documento descreve os fluxos de processamento para cada tipo de relatório da aplicação DALAR.

## Visão Geral

A aplicação possui dois tipos de relatórios com propósitos distintos:

| Categoria | Relatórios | Propósito | Entrega |
|-----------|------------|-----------|---------|
| **Legado** | `charges_events`, `charges_list` | CSV bruto para pós-processamento por outros times | Polling |
| **Produto Final** | `sales_stone`, `sales_ton`, `sale`, `receivables`, `receivables_legacy`, `orders` | Relatório final user-friendly | Email/Webhook/Polling |

### Endpoints

| Endpoint | Relatórios | Descrição |
|----------|------------|-----------|
| `POST /charges/report` | `charges_events`, `charges_list` | Endpoint legado |
| `GET /charges/report/{id}` | - | Consulta status (polling) |
| `POST /v1/reports` | `sales_stone`, `sales_ton`, `sale`, `receivables`, `receivables_legacy`, `orders` | Endpoint novo (produtos finais) |
| `GET /v1/reports/{id}` | - | Consulta status (polling) |

---

## Fluxos por Fonte de Dados

### 🔵 Fluxo Elasticsearch (ES)

Usado por: `receivables`, `receivables_legacy`, `orders`, e `sales_*` para dados dos últimos 6 meses.

```
┌──────────────┐     ┌─────────────────┐     ┌──────────────┐     ┌─────────┐
│   Endpoint   │────▶│  ESWorker       │────▶│   S3 Upload  │────▶│  Done   │
│  POST /v1/*  │     │  (pagina ES)    │     │  (streaming) │     │         │
└──────────────┘     └─────────────────┘     └──────────────┘     └─────────┘
```

**Etapas:**
1. Endpoint enfileira job no Hangfire (queue: `reports`)
2. Worker pagina dados do Elasticsearch via Data Layer API
3. Cada página é modelada para o formato de saída (CSV/XLSX)
4. Streaming multipart upload para S3
5. Notificação via email/webhook (se configurado)

**Workers:**
- `FinMovWorker` - Recebimentos (receivables)
- `OrderReportESWorker` - Pedidos (orders)
- `ChargeReportWorker` - Charges via ES (fallback/legado)

---

### 🟢 Fluxo S3 DeltaTable (Distribuído)

Usado por: `charges_events`, `charges_list`, e `sales_*` para dados anteriores a 6 meses.

Este fluxo é mais complexo por trabalhar com grandes volumes de dados históricos armazenados em formato Parquet no S3.

```
┌──────────────┐     ┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   Endpoint   │────▶│    Dispatch     │────▶│   S3 Workers    │────▶│     Concat      │
│  POST /...   │     │   (1 job)       │     │   (N jobs)      │     │   (merge)       │
└──────────────┘     └─────────────────┘     └─────────────────┘     └─────────────────┘
                            │                        │                        │
                            ▼                        ▼                        ▼
                     Cria metadata            Processa partição        Merge K-Way
                     Calcula partições        Upload parcial           Upload final
                     Enfileira N jobs                                  Notificação
```

**Workers:**
- `ChargeReportS3DispatchWorker` - Orquestração e dispatch
- `ChargeReportS3Worker` - Processamento por partição (data + merchant)
- `ChargeReportS3ConcatWorker` - Concatenação final

---

## Fluxo Detalhado: S3 DeltaTable

### 1. Dispatch (`ChargeReportS3DispatchWorker`)

```
┌─────────────────────────────────────────────────────────────────┐
│                         DISPATCH                                │
├─────────────────────────────────────────────────────────────────┤
│ 1. Upload metadata para S3 (status: processing)                 │
│ 2. Calcular partições: dias × conjuntos de partição             │
│    - Partição por data: cada dia no range                       │
│    - Partição por merchant: document ou merchant_id             │
│ 3. Calcular total de jobs = dias × partições                    │
│ 4. Enfileirar N jobs de processamento (idempotente)             │
└─────────────────────────────────────────────────────────────────┘
```

### 2. Processamento por Partição (`ChargeReportS3Worker`)

Cada job processa uma combinação de (data, partição):

```
┌─────────────────────────────────────────────────────────────────┐
│                    PROCESSAMENTO S3                             │
├─────────────────────────────────────────────────────────────────┤
│ 1. Download Parquet                                             │
│    - Baixa arquivos .parquet do DeltaTable (S3)                 │
│    - Filtrado por data e partição do merchant                   │
│                                                                 │
│ 2. Conversão Parquet → CSV                                      │
│    - Transforma dados Parquet para CSV local                    │
│    - Aplica filtros básicos durante conversão                   │
│                                                                 │
│ 3. Ordenação por ID do Evento                                   │
│    - Ordena CSV por event_id                                    │
│    - Necessário para deduplicação e agrupamento                 │
│                                                                 │
│ 4. Deduplicação                                                 │
│    - Remove linhas com mesmo event_id                           │
│    - Mantém evento mais recente                                 │
│                                                                 │
│ 5. Agregação (apenas charges_list/sales)                        │
│    - Agrupa eventos por charge_id                               │
│    - Aplica regras de negócio (CHARGES_FROM_EVENTS.md)          │
│    - Calcula amounts, fees, status                              │
│                                                                 │
│ 6. Modelagem (apenas sales/receivables)                         │
│    - Aplica Modifier para schema user-friendly                  │
│                                                                 │
│ 7. Filtros Finais                                               │
│    - Aplica filtros do request (status, amount, etc)            │
│                                                                 │
│ 8. Ordenação Final                                              │
│    - Ordena por created_at                                      │
│                                                                 │
│ 9. Upload Parcial                                               │
│    - Upload do CSV processado para S3                           │
│    - Path: reports/{id}/partials/{partition}/{date}.csv         │
│                                                                 │
│ 10. Trigger Concatenação (se último job)                        │
└─────────────────────────────────────────────────────────────────┘
```

### 3. Concatenação (`ChargeReportS3ConcatWorker`)

```
┌─────────────────────────────────────────────────────────────────┐
│                      CONCATENAÇÃO                               │
├─────────────────────────────────────────────────────────────────┤
│ 1. K-Way Merge                                                  │
│    - Merge ordenado de todos os arquivos parciais               │
│    - Mantém ordenação por created_at                            │
│    - Streaming: baixo uso de memória                            │
│                                                                 │
│ 2. Upload Final                                                 │
│    - Upload do relatório consolidado                            │
│    - Path: reports/{id}/report.csv                              │
│                                                                 │
│ 3. Update Metadata                                              │
│    - Status: succeeded                                          │
│                                                                 │
│ 4. Notificação                                                  │
│    - Email via Acquirer Reports API                             │
│    - Webhook (se configurado)                                   │
└─────────────────────────────────────────────────────────────────┘
```

---

## Características de Performance

### Processamento em Streaming

Todo o processamento é feito em streaming para minimizar uso de memória:

| Etapa | Técnica |
|-------|---------|
| Download Parquet | Streaming direto para disco |
| Conversão CSV | Processo otimizado com DuckDB |
| Ordenação | External sort (GNU sort) |
| Deduplicação | Script com AWK |
| Agregação | Processo em memória por grupo de eventos da mesma transação|
| Upload | Multipart streaming |

### Arquivos Temporários em Disco

O fluxo S3 mantém dados em disco local durante processamento:

```
/tmp/{job_id}/
├── raw_parquet/           # Arquivos .parquet baixados
├── raw_events.csv         # CSV convertido
├── sorted_by_id.csv       # Ordenado por event_id
├── charges_raw.csv        # Após agregação
├── charges_filtered.csv   # Após filtros
└── charges_final.csv      # Ordenado por created_at
```

Cada arquivo intermediário é deletado após uso para economizar espaço.

### Processamento Distribuído

- Jobs são processados em paralelo por múltiplos workers
- Cada job processa uma partição independente
- Concatenação acontece apenas quando todos jobs finalizam
- Idempotência: jobs podem ser re-executados sem duplicação

---

## Tipos de Relatório: Detalhes

### Relatórios Legados

#### `charges_events`
- **Fonte:** S3 DeltaTable
- **Saída:** Cada linha = 1 evento de charge
- **Schema:** Replica retorno do endpoint `GET /charges/events` da Data Layer API
- **Uso:** Pós-processamento por outros times

#### `charges_list`
- **Fonte:** S3 DeltaTable
- **Saída:** Cada linha = 1 charge completa (agregada de eventos)
- **Schema:** Replica retorno do endpoint `GET /charges` da Data Layer API
- **Agregação:** Ver [CHARGES_FROM_EVENTS.md](../domain/CHARGES_FROM_EVENTS.md)
- **Uso:** Pós-processamento por outros times

### Relatórios Produto Final

#### `sales_stone` / `sales_ton`
- **Fonte:** S3 DeltaTable (usa mesma engine de charges_list)
- **Saída:** Relatório de vendas user-friendly
- **Schema:** Simplificado, campos em português
- **Diferença:** Regras de negócio específicas por organização (Stone vs Ton)
- **Turbo (`sales_stone`):** Path CET: `CalculateRavTurboFeeAmount` somado ao RAV não-CET em DESCONTO DE ANTECIPACAO. Path não-CET: `FullRavAmount` já inclui turbo (alinhado com ES)
- **Turbo (`sales_ton`):** `FeeAmount` (centavos) já inclui turbo via RAV consolidado. Sem adição separada de turbo
- **Formatos:** CSV, XLSX

#### `sale`
- **Fonte:** S3 DeltaTable (usa mesma engine de charges_list)
- **Saída:** Relatório de vendas OneStone (layout unificado)
- **Schema:** 22 colunas, separador `;`, campos em português (CNPJ, LOJA, IDENTIFICADOR DO PEDIDO, etc.)
- **Diferença do `sales_stone`/`sales_ton`:** Layout OneStone unificado com suporte a Card, PIX e Boleto no mesmo mapper (`SaleCsvMapper`)
- **Modifier:** `SaleModifier` converte CSV rows para entidades `Charge`, depois delega para `SaleCsvMapper`
- **Turbo:** Path CET: DESCONTO DE VENDA = Σ `DiscountRate.Amount` (todos), DESCONTO DE ANTECIPAÇÃO = Σ `PrepaymentFee.Amount` (todos) + Σ `PrepaymentFeeTurbo.Amount`. Path não-CET: `FullRavAmount` já inclui turbo
- **Formatos:** CSV, XLSX

#### `receivables`
- **Fonte:** Elasticsearch (Financial Movements)
- **Saída:** Movimentações financeiras/recebíveis (layout OneStone)
- **Schema:** 18 colunas OneStone, separador `;`, campos em português (CNPJ, LOJA, CATEGORIA, etc.)
- **Mapper:** `ReceivablesOneStoneCsvMapper` (via ES), `ReceivablesOneStoneModifier` (via S3)
- **Turbo:** Coluna DESCONTO DE ANTECIPAÇÃO = `prepayment_fee.Amount` (se não CET) + `prepayment_fee_turbo.Amount`
- **Formatos:** CSV, XLSX

#### `receivables_legacy`
- **Fonte:** Híbrido (S3 DeltaTable + Elasticsearch)
- **Saída:** Movimentações financeiras/recebíveis (layout legado)
- **Schema:** 18 colunas legado, separador `;` (DOCUMENTO, STONECODE, CATEGORIA, etc.)
- **Fluxo híbrido:**
  1. `DateRangeSplitter` divide o range em HOT (<=6 meses, ES) e COLD (>6 meses, S3 DeltaTable)
  2. Parte ES: `FinMovESWorker` pagina dados do ES e faz upload parcial para S3
  3. Parte S3: `ChargeReportS3DispatchWorker` processa dados históricos do DeltaTable
  4. `ChargeReportS3ConcatWorker` faz merge dos resultados ES + S3
- **Modifier:** `ReceivablesModifier` (inclui DESCONTO UNIFICADO para taxas CET)
- **Turbo:** Coluna DESCONTO DE ANTECIPAÇÃO = `prepayment_fee.Amount` (se não CET) + `prepayment_fee_turbo.Amount`. Mesma lógica do `receivables` OneStone
- **Formatos:** CSV, XLSX

#### `orders`
- **Fonte:** Elasticsearch
- **Saída:** Pedidos
- **Schema:** User-friendly
- **Formatos:** CSV, XLSX

---

## Diagrama: Sales (Fluxo Completo)

```
┌───────────────────────────────────────────────────────────────────────────────┐
│                            FLUXO SALES (S3)                                   │
├───────────────────────────────────────────────────────────────────────────────┤
│                                                                               │
│   POST /v1/reports                                                            │
│        │                                                                      │
│        ▼                                                                      │
│   ┌─────────────────┐                                                         │
│   │ HybridService   │ ─── Decide: ES ou S3? (baseado em período/volume)       │
│   └────────┬────────┘                                                         │
│            │                                                                  │
│            ▼                                                                  │
│   ┌─────────────────┐                                                         │
│   │    Dispatch     │ ─── Cria N jobs para cada (dia × partição)              │
│   └────────┬────────┘                                                         │
│            │                                                                  │
│            ▼                                                                  │
│   ┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐         │
│   │  S3Worker [1]   │     │  S3Worker [2]   │     │  S3Worker [N]   │         │
│   │  (dia 1, part A)│     │  (dia 1, part B)│ ... │  (dia N, part X)│         │
│   └────────┬────────┘     └────────┬────────┘     └────────┬────────┘         │
│            │                       │                       │                  │
│   ┌───────────────────────────────────────────────────────────────────────┐   │        
│   │ Download Parquet → CSV → Sort → Aggregate → Modifier → Filter → Upload│   │
│   └───────────────────────────────────────────────────────────────────────┘   │
│            │                       │                       │                  │
│            └───────────────────────┼───────────────────────┘                  │
│                                    │                                          │
│                                    ▼                                          │
│                           ┌─────────────────┐                                 │
│                           │     Concat      │ ─── K-Way Merge                 │
│                           └────────┬────────┘                                 │
│                                    │                                          │
│                                    ▼                                          │
│                           ┌─────────────────┐                                 │
│                           │  Notification   │ ─── Email / Webhook             │
│                           └─────────────────┘                                 │
│                                                                               │
└───────────────────────────────────────────────────────────────────────────────┘
```

---

## Diagrama: Receivables (Fluxo ES - OneStone)

```
┌───────────────────────────────────────────────────────────────────────────────┐
│                      FLUXO RECEIVABLES (ES - OneStone)                        │
├───────────────────────────────────────────────────────────────────────────────┤
│                                                                               │
│   POST /v1/reports                                                            │
│        │                                                                      │
│        ▼                                                                      │
│   ┌─────────────────┐                                                         │
│   │  FinMovWorker   │                                                         │
│   └────────┬────────┘                                                         │
│            │                                                                  │
│            ▼                                                                  │
│   ┌───────────────────────────────────────────────────────────────────────┐   │
│   │  Pagina ES → ReceivablesOneStoneCsvMapper → Stream Upload S3          │   │
│   └───────────────────────────────────────────────────────────────────────┘   │
│            │                                                                  │
│            ▼                                                                  │
│   ┌─────────────────┐                                                         │
│   │  Notification   │ ─── Email / Webhook                                     │
│   └─────────────────┘                                                         │
│                                                                               │
└───────────────────────────────────────────────────────────────────────────────┘
```

---

## Diagrama: Receivables Legacy (Fluxo Híbrido ES + S3)

```
┌───────────────────────────────────────────────────────────────────────────────┐
│                   FLUXO RECEIVABLES_LEGACY (Híbrido)                          │
├───────────────────────────────────────────────────────────────────────────────┤
│                                                                               │
│   POST /v1/reports                                                            │
│        │                                                                      │
│        ▼                                                                      │
│   ┌─────────────────┐                                                         │
│   │ HybridService   │ ─── DateRangeSplitter: HOT (≤6m) vs COLD (>6m)         │
│   └────────┬────────┘                                                         │
│            │                                                                  │
│       ┌────┴────────────────────────┐                                         │
│       │                             │                                         │
│       ▼                             ▼                                         │
│  ┌──────────────┐          ┌─────────────────┐                                │
│  │ HOT (ES)     │          │  COLD (S3)      │                                │
│  │ FinMovWorker │          │  S3Dispatch     │                                │
│  └──────┬───────┘          └────────┬────────┘                                │
│         │                           │                                         │
│         ▼                           ▼                                         │
│  ┌──────────────┐          ┌─────────────────┐                                │
│  │ Pagina ES    │          │  S3Workers [N]  │                                │
│  │ Modifier     │          │  DeltaTable     │                                │
│  │ Upload S3    │          │  Modifier       │                                │
│  │ (parcial)    │          │  Upload S3      │                                │
│  └──────┬───────┘          └────────┬────────┘                                │
│         │                           │                                         │
│         └─────────┬─────────────────┘                                         │
│                   │                                                           │
│                   ▼                                                           │
│          ┌─────────────────┐                                                  │
│          │     Concat      │ ─── K-Way Merge (ES parcial + S3 parciais)       │
│          └────────┬────────┘                                                  │
│                   │                                                           │
│                   ▼                                                           │
│          ┌─────────────────┐                                                  │
│          │  Notification   │ ─── Email / Webhook                              │
│          └─────────────────┘                                                  │
│                                                                               │
└───────────────────────────────────────────────────────────────────────────────┘
```

---

## Diagrama: Orders (Fluxo Atual)

> ⚠️ **Nota:** Atualmente apenas ES. Fluxo híbrido (ES + S3) planejado para o futuro.

```
┌───────────────────────────────────────────────────────────────────────────────┐
│                           FLUXO ORDERS (ES)                                   │
├───────────────────────────────────────────────────────────────────────────────┤
│                                                                               │
│   POST /v1/reports                                                            │
│        │                                                                      │
│        ▼                                                                      │
│   ┌─────────────────────┐                                                     │
│   │ OrderReportESWorker │                                                     │
│   └──────────┬──────────┘                                                     │
│              │                                                                │
│              ▼                                                                │
│   ┌───────────────────────────────────────────────────────────────────────┐   │
│   │  Pagina ES → OrderCsvMapper (modelagem inline) → Stream Upload S3     │   │
│   └───────────────────────────────────────────────────────────────────────┘   │
│              │                                                                │
│              ▼                                                                │
│   ┌─────────────────┐                                                         │
│   │  Notification   │ ─── Email / Webhook                                     │
│   └─────────────────┘                                                         │
│                                                                               │
└───────────────────────────────────────────────────────────────────────────────┘
```

---

## Referências

- [CHARGES_FROM_EVENTS.md](../domain/CHARGES_FROM_EVENTS.md) - Lógica de agregação de eventos em charges
- [ARCHITECTURE.md](ARCHITECTURE.md) - Visão geral da arquitetura

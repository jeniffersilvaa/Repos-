# Delta Table — Fluxo de Charges

Documentação técnica das Delta Tables de charges usadas como fonte de dados históricos pela DALAR.

## Visão Geral

A DALAR consome dados de charges armazenados em Delta Tables (formato Parquet) no S3 para gerar relatórios de períodos superiores a 6 meses. Dados recentes (< 6 meses) vêm do Elasticsearch.

### Pipeline End-to-End

```mermaid
flowchart LR
    K[Kafka Topic] -->|S3 Sink Connector| R[S3 Raw JSON]
    R -->|AWS Glue Job<br>00:00 BRT diário| D[Delta Table<br>Parquet no S3]
    D -->|DuckDB read_parquet| W[DALAR Worker]
    W --> CSV[Relatório CSV/XLSX]
```

1. **Kafka → S3 Raw**: Sink connector grava eventos JSON em `s3://{bucket}/raw/payments.{env}.core.dataaccesslayer.charges/year={YYYY}/month={MM}/day={DD}/`
2. **S3 Raw → Delta Table**: Glue job diário (00:00 BRT = 03:00 UTC) lê o JSON bruto, aplica flatten, deduplicação e particionamento, e faz append nas Delta Tables
3. **Delta Table → Relatório**: DALAR baixa os `.parquet` de uma partição, lê via DuckDB, converte para CSV e gera o relatório a partir do CSV
---

## Tabelas

| Tabela | Conteúdo | Partição Temporal |
|--------|----------|-------------------|
| `charges_events_by_created_at` | `event_date == created_at` | `created_at` da charge |
| `charges_posterior_events_by_created_at` | `event_date != created_at` | `created_at` da charge |
| `charges_posterior_events_by_event_date` | `event_date != created_at` | `event_date` do evento |

### Estratégia de 3 Tabelas

O objetivo é minimizar o volume de leitura ao gerar relatórios com diferentes visões temporais:

- **Visão por data da transação** (charges_list, sales): lê `charges_events_by_created_at` + `charges_posterior_events_by_created_at`
- **Visão por data do evento** (charges_events): lê `charges_events_by_created_at` + `charges_posterior_events_by_event_date`

> [!NOTE]
> **Posterior events** são eventos de uma transação que ocorrem num dia diferente da criação. Exemplo: uma transação criada em 01/01 e cancelada em 10/01 — o evento de cancelamento é um posterior event.

### Mapeamento Relatório → Tabelas

| Relatório | Tabelas |
|-----------|---------|
| `charges_list` | `charges_events_by_created_at` + `charges_posterior_events_by_created_at` |
| `sales_stone` / `sales_ton` | `charges_events_by_created_at` + `charges_posterior_events_by_created_at` |
| `charges_events` | `charges_events_by_created_at` + `charges_posterior_events_by_event_date` |

---

## Estrutura no S3

### Buckets

| Ambiente | Bucket |
|----------|--------|
| Staging | `pay-data-layer-warehouse-stg` |
| Produção | `pay-data-layer-warehouse-prd` |

### Path Template

```
s3://{bucket}/delta/pay_data_layer/{table_name}/
    partition_year={YYYY}/
        partition_month={MM}/
            partition_day={DD}/
                partition_id={ID}/
                    *.snappy.parquet
```

Exemplo concreto:

```
s3://pay-data-layer-warehouse-prd/delta/pay_data_layer/charges_events_by_created_at/
    partition_year=2026/
        partition_month=1/
            partition_day=5/
                partition_id=100/
                    part-00001-e01be1ac-....snappy.parquet   (29.8 MB - processamento principal)
                    part-00001-be5ba6a5-....snappy.parquet   (337.2 KB - late arrival)
                    part-00001-70491d37-....snappy.parquet   (153.1 KB - late arrival)
                    part-00001-55e30aa1-....snappy.parquet   (153.3 KB - late arrival)
```

---

## Particionamento

### Partition ID

O `partition_id` dispersa os dados dos clientes para que a DALAR não precise baixar todos os dados de um dia inteiro ao gerar relatório de um único cliente.

**Cálculo:**

```
Se Big Merchant  → partition_id = documento literal (ex: "10573521000191")
Se Pagarme       → partition_id = "pagarme_{hash(merchant_id) % 10}"
Caso contrário   → partition_id = "{hash(document) % mod}"
```

Onde `hash` = `MurmurHash3` (Spark: `spark_hash`; C#: `MurmurHash3.HashUnsafeBytes`), e `mod` varia por tabela:

| Tabela | Mod (document) | Mod (merchant) |
|--------|----------------|----------------|
| `charges_events_by_created_at` | 400 | 10 |
| `charges_posterior_events_*` | 10 | 10 |

> [!IMPORTANT]
> O hash no Glue (Spark `hash()`) e na DALAR (C# `MurmurHash3`) devem produzir resultados equivalentes para que as partições corretas sejam localizadas.

### Big Merchants

Documentos com particionamento especial (partition_id = documento):
- `10573521000191`
- `13236697000146`

Referência: [config.py](https://github.com/stone-payments/payments-data-layer-glue/blob/main/data_layer/core/config.py#L3) e [DeltaTableConfiguration.cs](https://github.com/stone-payments/payments-data-layer-reports/blob/main/src/PaymentsDataLayerReports.Application/Services/DeltaTablePartitionBuilder/DeltaTableConfiguration.cs#L12-L15)

---

## Volume de Dados

### Partições por dia (charges_events_by_created_at)

- **412 partition_ids** por dia (400 numéricos + 10 pagarme + 2 big merchants)
- ~**30 MB** por partition_id (numéricos)
- ~**100-315 MB** para partições Pagarme
- ~**222 MB** para o big merchant `10573521000191`
- **Total diário:** ~**13-18 GB**

### Acúmulo de arquivos (late arrivals)

Um dia recém-processado tem 1 arquivo por partition_id. Com o passar do tempo, eventos tardios geram appends incrementais:

| Período | Tamanho | Objetos | Arquivos por partição |
|---------|---------|---------|----------------------|
| 09/02/2026 | 13.6 GB | 412 | 1.0 |
| Dez/2025 | 455.1 GB | 28.549 | 2.2 |
| Nov/2025 | 398.0 GB | 34.646 | 2.8 |
| Out/2025 | 400.1 GB | 32.173 | 2.5 |
| Set/2025 | 416.4 GB | 14.309 | 1.2 |
| Ago/2025 | 383.2 GB | 15.690 | 1.2 |
| Jul/2025 | 350.0 GB | 14.894 | 1.2 |
| Jun/2025 | 338.6 GB | 22.935 | 1.9 |
| Mai/2025 | 336.9 GB | 35.372 | 2.8 |
| Abr/2025 | 345.7 GB | 46.282 | 3.7 |
| Mar/2025 | 334.5 GB | 133.816 | 10.5 |
| Fev/2025 | 243.8 GB | 64.791 | 5.6 |
| Jan/2025 | 255.1 GB | 109.761 | 8.6 |

> [!WARNING]
> **Pendência**: implementar rotinas de `OPTIMIZE` e `VACUUM` para compactar small files e manter a saúde das tabelas.

---

## Schema

### Transformação nested → flat

O evento bruto chega em formato JSON com campos aninhados (nested structs). O Glue job aplica `flatten_schema_transform` que converte:

```
merchant.document         → merchant__document
card_transaction.card.brand → card_transaction__card__brand
```

A conversão substitui `.` por `__` recursivamente.

Referência: [transformations.py](https://github.com/stone-payments/payments-data-layer-glue/blob/main/data_layer/core/transformations.py#L11-L33)

### Column Mapping (nomes lógicos → físicos)

O Delta Lake usa **column mapping** com nomes físicos no Parquet (GUIDs). Para traduzir de volta para nomes lógicos, existe um JSON de mapeamento:

```
s3://{bucket}/schema_mappings/{table_name}_column_mapping.json
```

Este JSON é extraído do `_delta_log` toda vez que a tabela é alterada (via `update_table.py`).

Na DALAR, o  [ColumnMappingService](https://github.com/stone-payments/payments-data-layer-reports/blob/main/src/PaymentsDataLayerReports.Application/Services/DeltaTableColumnMapping/ColumnMappingService.cs) carrega esse JSON e faz a tradução para montar as queries DuckDB.

---

## Processamento no Glue (Escrita)

O job está implementado em [processor.py](https://github.com/stone-payments/payments-data-layer-glue/blob/main/data_layer/charges/processor.py).

### Pipeline do Job

```mermaid
flowchart TD
    A[Ler JSON bruto do S3] --> B[Filtrar sandbox merchants]
    B --> C[Adicionar created_at_date]
    C --> D[Gerar event_id via coalesce]
    D --> E[Deduplicar por event_id<br>manter mais recente por ingestion_timestamp]
    E --> F{event_date == created_at_date?}
    F -->|Sim| G[df_events<br>partition_id mod 400]
    F -->|Não| H[df_posterior<br>partition_id mod 10]
    G --> I[Flatten schema]
    H --> J[Flatten schema]
    I --> K[Append em<br>charges_events_by_created_at]
    J --> L[Append em<br>charges_posterior_events_by_created_at<br><small>partition_date = created_at</small>]
    J --> M[Append em<br>charges_posterior_events_by_event_date<br><small>partition_date = event_date</small>]
```

### Detalhes Importantes

- **event_id**: calculado via `coalesce(financial_event.id, fee.id, detail.operation_id, ..., id)` — garante unicidade do evento
- **Deduplicação**: `ROW_NUMBER()` particionado por `event_id`, ordenado por `ingestion_timestamp DESC` — mantém o evento mais recente
- **Sandbox filtering**: merchants sandbox são excluídos no processamento
- **Repartition**: `df.repartition(50, "partition_id")` antes do write para balancear os arquivos de saída
- **processed_at**: timestamp fixo para todas as tabelas de uma execução, garantindo consistência

---

## Processamento na DALAR (Leitura)

### Fluxo S3 (worker-1)

```mermaid
flowchart LR
    D[S3 Dispatch Worker] -->|1 job por dia| W[S3 Worker<br>por partição/dia]
    W -->|baixa parquet| DK[DuckDB<br>read_parquet]
    DK -->|CSV parcial| S3[Upload S3]
    S3 --> C[S3 Concat Worker<br>junta CSVs parciais]
```

### Como a DALAR lê os arquivos

1. **Calcula partition_id**: via `MurmurHash3` no C# ([DeltaTableConfiguration.cs](https://github.com/stone-payments/payments-data-layer-reports/blob/main/src/PaymentsDataLayerReports.Application/Services/DeltaTablePartitionBuilder/DeltaTableConfiguration.cs))
2. **Monta o path S3**: `delta/pay_data_layer/{table}/partition_year={Y}/partition_month={M}/partition_day={D}/partition_id={ID}/`
3. **Baixa todos os `.parquet`** da partição para um diretório local
4. **Carrega column mapping** de `schema_mappings/{table}_column_mapping.json`
5. **Executa query DuckDB**: `read_parquet(['{path}/*.parquet'], union_by_name=True)` com colunas traduzidas e filtros
6. **Exporta para CSV**: `COPY (...) TO '{output}' (HEADER, DELIMITER ',')`

> [!NOTE]
> A DALAR **não** lê o `_delta_log/`. Acessa os arquivos Parquet diretamente. Como a tabela é append-only, não há risco de ler arquivos órfãos. Se houver duplicação, a deduplicação acontece na camada de lógica de negócio do relatório.

---

## Alterações de Schema

Quando colunas são adicionadas ou removidas:

1. Script [update_table.py](https://github.com/stone-payments/payments-data-layer-glue/blob/main/scripts/utils/update_table.py) executa `ALTER TABLE ... ADD COLUMNS` em todas as 3 tabelas de charges
2. Extrai o `physical_column_mapping` do `_delta_log`
3. Salva o mapping em `s3://{bucket}/schema_mappings/{table}_column_mapping.json`
4. A DALAR recarrega o mapping na próxima execução (cache em memória)

> [!CAUTION]
> Ao adicionar colunas, é necessário atualizar tanto o Glue (schema de entrada + tabela) quanto a DALAR (listas de `RequestedColumns` nos query files). A falta de sincronização resulta em valores `NULL` no relatório.

---

## Pendências Conhecidas

| Pendência | Impacto |
|-----------|---------|
| Implementar `OPTIMIZE` + `VACUUM` | Small files acumulam com late arrivals, degradando leitura |
| Criar expurgo de dados brutos (JSON) | Dados raw no S3 crescem indefinidamente sem lifecycle policy |

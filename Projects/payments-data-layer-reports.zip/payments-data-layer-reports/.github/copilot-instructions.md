# Instruções para o GitHub Copilot

## Diretrizes para Pull Requests

### Idioma
- Comentários e revisões de código: **Português do Brasil (pt-BR)**
- Mensagens de commit: **Inglês**
- Seja direto e conciso na comunicação
- Mantenha um tom profissional mas objetivo

### Mensagens de Commit
- Formato: `type(scope): Subject`
- Tipos permitidos (em minúsculas):
  - `feat`: Nova funcionalidade
  - `fix`: Correção de bug
  - `docs`: Atualização de documentação
  - `style`: Formatação, ponto e vírgula, etc. (sem mudança de código)
  - `refactor`: Refatoração de código
  - `test`: Adição ou modificação de testes
  - `chore`: Atualização de tarefas de build, configurações, etc.
- Exemplos:
  - `feat(charges): Add new charge processing`
  - `fix(payments): Correct amount validation`
  - `chore(deps): Update dependencies`

### Template de Pull Request
Sempre use o template de PR existente no repositório, que inclui:
1. Descrição das alterações
2. Motivação e contexto
3. Como testar
4. Checklist de verificação

### Mensagens de Commit
- Use o padrão [tipo/escopo] mensagem
- Exemplo: `[feat/charges] Adiciona processamento de cobranças`
- Tipos permitidos: feat, fix, docs, style, refactor, test, chore

### Análise de Código
- Seja construtivo e objetivo
- Aponte problemas específicos com sugestões claras
- Destaque tanto pontos positivos quanto oportunidades de melhoria
- Mantenha o foco na qualidade do código e nas boas práticas

### Geração de Código
- Priorize clareza e manutenibilidade
- Siga os padrões de código existentes no projeto
- Comentários apenas quando:
  - A lógica for complexa e não autoexplicativa
  - Explicar "por que" e não "o que" o código faz
  - Documentar decisões de arquitetura importantes
  - Alertar sobre comportamentos não óbvios
- Evite comentários óbvios que apenas repetem o código

### Revisão de Código
- Verificar se as alterações estão alinhadas com o escopo do PR
- Garantir que não há regressões
- Validar se os testes cobrem as mudanças
- Confirmar que a documentação foi atualizada se necessário

### Dicas para Melhorar o Prompt
- Seja específico sobre o contexto
- Inclua exemplos do comportamento esperado
- Mencione restrições técnicas quando aplicável
- Especifique o formato de saída desejado

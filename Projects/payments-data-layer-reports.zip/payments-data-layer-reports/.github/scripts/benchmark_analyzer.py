#!/usr/bin/env python3
import os
import csv
import sys
import re
from pathlib import Path

CSV_PATTERN = '*.csv'
REPORT_PATH = 'benchmark-report.md'
SUCCESS_STATUS = 'success'


def parse_value(value_str):
    if not value_str or value_str == 'N/A':
        return 0.0
    cleaned = re.sub(r'[^\d.]', '', value_str.replace(',', ''))
    try:
        return float(cleaned)
    except ValueError:
        return 0.0


def parse_csv(file_path):
    data = {}
    if os.path.exists(file_path):
        with open(file_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                method = row.get('Method', '')
                allocated = parse_value(row.get('Allocated', '0'))
                mean = parse_value(row.get('Mean', '0'))
                data[method] = {'allocated': allocated, 'mean': mean}
    return data


def parse_all_csvs(results_dir):
    data = {}
    for csv_file in sorted(Path(results_dir).rglob(CSV_PATTERN)):
        data.update(parse_csv(str(csv_file)))
    return data


def write_report(report):
    with open(REPORT_PATH, 'w', encoding='utf-8') as file_handle:
        file_handle.write(report)


def parse_benchmark_list(list_path):
    if not Path(list_path).exists():
        return []

    raw_lines = Path(list_path).read_text(encoding='utf-8').splitlines()

    benchmarks = []
    benchmark_pattern = re.compile(r'^[\w\.]+Benchmark[\w\.]*$')

    for line in raw_lines:
        stripped = line.strip()
        if not stripped or 'warning' in stripped.lower() or 'error' in stripped.lower():
            continue
        if stripped.startswith(('/home/', 'C:\\', 'Build', 'MSBuild', 'Restore')):
            continue

        if benchmark_pattern.match(stripped):
            benchmarks.append(stripped)

    return list(dict.fromkeys(benchmarks))


def has_csv_files(results_dir):
    if not Path(results_dir).exists():
        return False

    csv_files = list(Path(results_dir).rglob(CSV_PATTERN))
    return len(csv_files) > 0


def resolve_status(change, threshold, warning_threshold):
    abs_change = abs(change)
    if abs_change <= threshold:
        return '🟢'
    if abs_change <= warning_threshold:
        return '🟡'
    return '🔴'


def build_change(base_value, pr_value, threshold, warning_threshold, new_label, new_status):
    if base_value > 0:
        change = (pr_value - base_value) / base_value
        status = resolve_status(change, threshold, warning_threshold)
        return status, f'{change:+.1%}'
    if pr_value > 0:
        return new_status, new_label
    return '🟢', 'Sem alteração'


def resolve_overall_status(statuses):
    if '🔴' in statuses:
        return '🔴'
    if '🟡' in statuses:
        return '🟡'
    return '🟢'


def generate_comparison_report(base_dir, pr_dir, alloc_threshold, time_threshold):
    base_has_csv = has_csv_files(base_dir)
    pr_has_csv = has_csv_files(pr_dir)

    if not base_has_csv or not pr_has_csv:
        if not base_has_csv and not pr_has_csv:
            report = (
                '## Resultados do Benchmark\n\n'
                f'❌ **Erro**: Nenhum resultado encontrado.\n\n'
                f'- Diretório base: `{base_dir}` - ❌ Sem CSVs\n'
                f'- Diretório PR: `{pr_dir}` - ❌ Sem CSVs\n\n'
                'Verifique os logs da action para mais detalhes.'
            )
        elif not base_has_csv:
            report = (
                '## Resultados do Benchmark\n\n'
                f'❌ **Erro**: Resultados da base branch não encontrados em `{base_dir}`.\n\n'
                'Verifique os logs da execução na base branch.'
            )
        else:
            report = (
                '## Resultados do Benchmark\n\n'
                f'❌ **Erro**: Resultados da PR branch não encontrados em `{pr_dir}`.\n\n'
                'Verifique os logs da execução na PR branch.'
            )
        write_report(report)
        return SUCCESS_STATUS

    base_data = parse_all_csvs(base_dir)
    pr_data = parse_all_csvs(pr_dir)

    if not base_data and not pr_data:
        report = (
            '## Resultados do Benchmark\n\n'
            '❌ **Erro**: CSVs encontrados mas nenhum dado foi extraído.\n\n'
            f'- Diretório base: `{base_dir}`\n'
            f'- Diretório PR: `{pr_dir}`\n\n'
            'Verifique o formato dos arquivos CSV.'
        )
        write_report(report)
        return SUCCESS_STATUS

    status = SUCCESS_STATUS
    report = (
        '## Resultados do Benchmark\n\n'
        '| Benchmark | Métrica | Baseline | PR | Alteração | Status |\n'
        '|-----------|---------|----------|-----|-----------|--------|\n'
    )

    for method in sorted(set(base_data.keys()) | set(pr_data.keys())):
        base_alloc = base_data.get(method, {}).get('allocated', 0)
        pr_alloc = pr_data.get(method, {}).get('allocated', 0)
        base_time = base_data.get(method, {}).get('mean', 0)
        pr_time = pr_data.get(method, {}).get('mean', 0)

        alloc_status, alloc_change_str = build_change(
            base_alloc, pr_alloc, alloc_threshold, 0.10, 'Nova alocação', '🔴'
        )
        time_status, time_change_str = build_change(
            base_time, pr_time, time_threshold, 0.20, 'Novo tempo', '🟡'
        )

        overall_status = resolve_overall_status([alloc_status, time_status])
        if overall_status == '🔴':
            status = 'failure'

        report += f'| {method} | Tempo Médio | {base_time:.2f} ms | {pr_time:.2f} ms | {time_change_str} | {time_status} |\n'
        report += f'| | Alocação | {base_alloc:.0f} B | {pr_alloc:.0f} B | {alloc_change_str} | {alloc_status} |\n'

    write_report(report)
    return status


def extract_record_count(method):
    if 'RecordCount=' not in method:
        return None
    try:
        return method.split('RecordCount=')[1].split(',')[0]
    except IndexError:
        return None


def format_alloc_per_record(allocated, record_count):
    try:
        rc_int = int(record_count)
        if rc_int > 0:
            return f'{allocated / rc_int:.2f} B'
    except (TypeError, ValueError):
        return 'N/A'
    return 'N/A'


def generate_individual_report(results_dir, title):
    if not has_csv_files(results_dir):
        report = (
            f'## {title}\n\n'
            f'❌ **Erro**: Nenhum arquivo CSV encontrado em `{results_dir}`.\n\n'
            'Verifique os logs da action.'
        )
        write_report(report)
        return

    data = parse_all_csvs(results_dir)
    if not data:
        report = (
            f'## {title}\n\n'
            f'❌ **Erro**: CSVs encontrados mas nenhum dado foi extraído de `{results_dir}`.\n\n'
            'Verifique o formato dos arquivos CSV.'
        )
        write_report(report)
        return

    report = (
        f'## {title}\n\n'
        '| Benchmark | RecordCount | Tempo Médio (ms) | Alocação | Alocação/Record |\n'
        '|-----------|-------------|------------------|----------|-----------------|\n'
    )
    for method, values in sorted(data.items()):
        record_count = extract_record_count(method) or 'N/A'
        alloc_per_record = format_alloc_per_record(values["allocated"], record_count)
        report += (
            f'| {method.split("(")[0]} | {record_count} | {values["mean"]:.2f} '
            f'| {values["allocated"]:.0f} B | {alloc_per_record} |\n'
        )

    write_report(report)


def generate_list_report(list_path):
    if not Path(list_path).exists():
        report = (
            '## Benchmarks Disponíveis\n\n'
            f'❌ **Erro**: Arquivo de lista não encontrado: `{list_path}`\n\n'
            'Verifique se o comando foi executado corretamente.'
        )
        write_report(report)
        return

    benchmarks = parse_benchmark_list(list_path)
    if not benchmarks:
        report = (
            '## Benchmarks Disponíveis\n\n'
            '❌ **Erro**: Nenhum benchmark encontrado.\n\n'
            'Verifique se existem benchmarks definidos no projeto.'
        )
        write_report(report)
        return

    report = '## Benchmarks Disponíveis\n\n| Benchmark | Comando |\n|-----------|---------|\n'
    for benchmark in sorted(benchmarks, key=str.lower):
        report += f'| `{benchmark}` | `!benchmark {benchmark}` |\n'

    report += (
        '\n### Outros Comandos\n'
        '- `!benchmark` → lista benchmarks\n'
        '- `!benchmark all` → compara base vs PR (todos)\n'
        '- `!benchmark-target <nome>` → executa só no PR\n'
        '- `!benchmark-source <nome>` → executa só na base\n'
        '- `!benchmark list` → lista novamente\n'
    )

    write_report(report)


if __name__ == '__main__':
    mode = sys.argv[1] if len(sys.argv) > 1 else 'compare'

    if mode == 'compare':
        alloc_threshold = float(os.environ.get('ALLOCATION_THRESHOLD', '0.05'))
        time_threshold = float(os.environ.get('TIME_THRESHOLD', '0.10'))
        status = generate_comparison_report('base-results', 'pr-results', alloc_threshold, time_threshold)
        print(f'status={status}')
    elif mode == 'source':
        generate_individual_report('base-results', 'Benchmarks da Base Branch')
    elif mode == 'list':
        list_path = sys.argv[2] if len(sys.argv) > 2 else 'benchmark-list.txt'
        generate_list_report(list_path)
    else:
        generate_individual_report('pr-results', 'Benchmarks da PR Branch')

## Descrições das alterações

### Alteração 1

- Titulo:
- Link:
- Descrição do teste:
- Evidências:

### Alteração N

- Titulo:
- Link:
- Descrição do teste:
- Evidências:

<!-- end descriptions - don't remove -->
# Em PRs para Main
### Após abertura do PR o comentário do changeman deve ser atualizado da seguinte forma:
- [ ] `Descrição da Mudança` seguindo o formato `minha-app v1.2.3`
- [ ] `Objetivo da Mudança` com uma descrição simples do deploy
- [ ] `Plano de Rollback` como `Revert do Pull Request`
- [ ] `Plano de Teste` como `Teste local + testes unitários + validação em stg, conforme descrição do PR`
- [ ] `Requisitante` com o seu email, caso o PR tenha sido aberto via automação
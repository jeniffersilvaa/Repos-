using System.Text;
using Xunit.Sdk;

namespace PaymentsDataLayerReports.Integration.Test.Helpers;

/// <summary>
/// Utilitário para comparação de arquivos CSV em testes de integração.
/// Fornece métodos para comparar CSVs linha por linha, campo por campo, com relatórios detalhados de diferenças.
/// </summary>
public static class CsvComparer
{
    /// <summary>
    /// Compara dois arquivos CSV e retorna um resultado detalhado da comparação.
    /// </summary>
    /// <param name="actualCsvPath">Caminho para o arquivo CSV gerado (resultado atual)</param>
    /// <param name="expectedCsvPath">Caminho para o arquivo CSV esperado (baseline)</param>
    /// <param name="ignoreColumnOrder">Se true, ignora a ordem das colunas na comparação</param>
    /// <param name="columnsToIgnore">Lista de nomes de colunas que devem ser ignoradas na comparação</param>
    /// <returns>Resultado da comparação com informações sobre diferenças encontradas</returns>
    public static CsvComparisonResult Compare(
        string actualCsvPath,
        string expectedCsvPath,
        bool ignoreColumnOrder = false,
        HashSet<string>? columnsToIgnore = null)
    {
        if (!File.Exists(actualCsvPath))
            return CsvComparisonResult.Failure($"Arquivo atual não encontrado: {actualCsvPath}");

        if (!File.Exists(expectedCsvPath))
            return CsvComparisonResult.Failure($"Arquivo esperado não encontrado: {expectedCsvPath}");

        var actualLines = File.ReadAllLines(actualCsvPath);
        var expectedLines = File.ReadAllLines(expectedCsvPath);

        return CompareLines(actualLines, expectedLines, ignoreColumnOrder, columnsToIgnore);
    }

    /// <summary>
    /// Compara dois streams CSV e retorna um resultado detalhado da comparação.
    /// </summary>
    public static CsvComparisonResult CompareStreams(
        Stream actualStream,
        Stream expectedStream,
        bool ignoreColumnOrder = false,
        HashSet<string>? columnsToIgnore = null)
    {
        actualStream.Position = 0;
        expectedStream.Position = 0;

        using var actualReader = new StreamReader(actualStream, leaveOpen: true);
        using var expectedReader = new StreamReader(expectedStream, leaveOpen: true);

        var actualLines = new List<string>();
        var expectedLines = new List<string>();

        while (!actualReader.EndOfStream)
            actualLines.Add(actualReader.ReadLine() ?? string.Empty);

        while (!expectedReader.EndOfStream)
            expectedLines.Add(expectedReader.ReadLine() ?? string.Empty);

        return CompareLines(actualLines.ToArray(), expectedLines.ToArray(), ignoreColumnOrder, columnsToIgnore);
    }

    /// <summary>
    /// Compara arrays de linhas CSV.
    /// </summary>
    private static CsvComparisonResult CompareLines(
        string[] actualLines,
        string[] expectedLines,
        bool ignoreColumnOrder,
        HashSet<string>? columnsToIgnore)
    {
        var differences = new List<string>();
        columnsToIgnore ??= new HashSet<string>();

        // Verifica se ambos os arquivos têm conteúdo
        if (actualLines.Length == 0)
            return CsvComparisonResult.Failure("Arquivo atual está vazio");

        if (expectedLines.Length == 0)
            return CsvComparisonResult.Failure("Arquivo esperado está vazio");

        // Processa headers
        var actualHeader = ParseCsvLine(actualLines[0]);
        var expectedHeader = ParseCsvLine(expectedLines[0]);

        // Remove colunas ignoradas
        var actualHeaderFiltered = actualHeader.Where(h => !columnsToIgnore.Contains(h)).ToList();
        var expectedHeaderFiltered = expectedHeader.Where(h => !columnsToIgnore.Contains(h)).ToList();

        // Verifica headers
        if (!ignoreColumnOrder)
        {
            if (!actualHeaderFiltered.SequenceEqual(expectedHeaderFiltered))
            {
                differences.Add($"Headers diferentes:\n  Atual: {string.Join(", ", actualHeaderFiltered)}\n  Esperado: {string.Join(", ", expectedHeaderFiltered)}");
                return CsvComparisonResult.Failure(string.Join("\n", differences));
            }
        }
        else
        {
            var actualHeaderSet = new HashSet<string>(actualHeaderFiltered);
            var expectedHeaderSet = new HashSet<string>(expectedHeaderFiltered);

            if (!actualHeaderSet.SetEquals(expectedHeaderSet))
            {
                var missing = expectedHeaderSet.Except(actualHeaderSet);
                var extra = actualHeaderSet.Except(expectedHeaderSet);

                if (missing.Any())
                    differences.Add($"Colunas faltando no arquivo atual: {string.Join(", ", missing)}");
                if (extra.Any())
                    differences.Add($"Colunas extras no arquivo atual: {string.Join(", ", extra)}");

                return CsvComparisonResult.Failure(string.Join("\n", differences));
            }
        }

        // Cria mapeamento de índices de colunas
        var actualColumnIndex = actualHeader
            .Select((name, index) => new { name, index })
            .Where(x => !columnsToIgnore.Contains(x.name))
            .ToDictionary(x => x.name, x => x.index);

        var expectedColumnIndex = expectedHeader
            .Select((name, index) => new { name, index })
            .Where(x => !columnsToIgnore.Contains(x.name))
            .ToDictionary(x => x.name, x => x.index);

        // Verifica número de linhas
        if (actualLines.Length != expectedLines.Length)
        {
            differences.Add($"Número de linhas diferente: Atual={actualLines.Length}, Esperado={expectedLines.Length}");
        }

        // Compara linha por linha
        int minLines = Math.Min(actualLines.Length, expectedLines.Length);
        for (int i = 1; i < minLines; i++) // Começa em 1 para pular o header
        {
            var actualFields = ParseCsvLine(actualLines[i]);
            var expectedFields = ParseCsvLine(expectedLines[i]);

            var lineDifferences = new List<string>();

            foreach (var columnName in expectedColumnIndex.Keys)
            {
                if (!actualColumnIndex.TryGetValue(columnName, out var actualIdx))
                    continue;

                if (!expectedColumnIndex.TryGetValue(columnName, out var expectedIdx))
                    continue;

                var actualValue = actualIdx < actualFields.Count ? actualFields[actualIdx] : string.Empty;
                var expectedValue = expectedIdx < expectedFields.Count ? expectedFields[expectedIdx] : string.Empty;

                if (actualValue != expectedValue)
                {
                    lineDifferences.Add($"  Coluna '{columnName}': Atual='{actualValue}', Esperado='{expectedValue}'");
                }
            }

            if (lineDifferences.Any())
            {
                differences.Add($"Linha {i + 1} possui diferenças:");
                differences.AddRange(lineDifferences);
            }
        }

        if (differences.Any())
            return CsvComparisonResult.Failure(string.Join("\n", differences));

        return CsvComparisonResult.Success();
    }

    /// <summary>
    /// Faz o parse de uma linha CSV, respeitando campos entre aspas.
    /// </summary>
    private static List<string> ParseCsvLine(string line)
    {
        var fields = new List<string>();
        var currentField = new StringBuilder();
        bool inQuotes = false;

        for (int i = 0; i < line.Length; i++)
        {
            char c = line[i];

            if (c == '"')
            {
                if (inQuotes && i + 1 < line.Length && line[i + 1] == '"')
                {
                    // Aspas duplas escapadas
                    currentField.Append('"');
                    i++; // Pula a próxima aspa
                }
                else
                {
                    // Alterna o estado de estar dentro de aspas
                    inQuotes = !inQuotes;
                }
            }
            else if (c == ',' && !inQuotes)
            {
                // Fim do campo
                fields.Add(currentField.ToString());
                currentField.Clear();
            }
            else
            {
                currentField.Append(c);
            }
        }

        // Adiciona o último campo
        fields.Add(currentField.ToString());

        return fields;
    }

    /// <summary>
    /// Valida se um arquivo CSV tem a estrutura esperada (headers corretos).
    /// </summary>
    public static bool ValidateStructure(string csvPath, string[] expectedHeaders)
    {
        if (!File.Exists(csvPath))
            return false;

        var firstLine = File.ReadLines(csvPath).FirstOrDefault();
        if (string.IsNullOrEmpty(firstLine))
            return false;

        var actualHeaders = ParseCsvLine(firstLine);
        return actualHeaders.SequenceEqual(expectedHeaders);
    }

    /// <summary>
    /// Conta o número de linhas de dados em um CSV (excluindo o header).
    /// </summary>
    public static int CountDataRows(string csvPath)
    {
        if (!File.Exists(csvPath))
            return 0;

        return File.ReadLines(csvPath).Skip(1).Count();
    }
}

/// <summary>
/// Resultado da comparação de arquivos CSV.
/// </summary>
public class CsvComparisonResult
{
    public bool IsSuccess { get; init; }
    public string Message { get; init; } = string.Empty;
    public List<string> Differences { get; init; } = new();

    public static CsvComparisonResult Success() => new() { IsSuccess = true, Message = "CSVs são idênticos" };

    public static CsvComparisonResult Failure(string message) => new()
    {
        IsSuccess = false,
        Message = message
    };

    public void AssertSuccess()
    {
        if (!IsSuccess)
        {
            throw new XunitException($"Comparação de CSV falhou:\n{Message}");
        }
    }
}

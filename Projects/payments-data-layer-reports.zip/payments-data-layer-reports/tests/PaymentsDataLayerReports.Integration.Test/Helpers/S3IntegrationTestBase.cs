using Amazon.Runtime;
using Amazon.S3;
using Amazon.S3.Model;
using Amazon.S3.Util;
using DotNet.Testcontainers.Builders;
using Testcontainers.LocalStack;

namespace PaymentsDataLayerReports.Integration.Test.Helpers;

/// <summary>
/// Classe base para testes de integração com S3 usando LocalStack via Testcontainers.
/// Gerencia o ciclo de vida do container LocalStack e fornece um cliente S3 configurado.
/// </summary>
public abstract class S3IntegrationTestBase : IAsyncLifetime
{
    private LocalStackContainer? _localStackContainer;
    protected IAmazonS3? S3Client { get; private set; }
    protected const string TestBucketName = "test-integration-bucket";

    public async Task InitializeAsync()
    {
        _localStackContainer = new LocalStackBuilder()
            .WithImage("localstack/localstack:latest")
            .WithEnvironment("SERVICES", "s3")
            .WithEnvironment("DEBUG", "1")
            .WithWaitStrategy(Wait.ForUnixContainer().UntilPortIsAvailable(4566))
            .Build();

        await _localStackContainer.StartAsync();

        var config = new AmazonS3Config
        {
            ServiceURL = _localStackContainer.GetConnectionString(),
            ForcePathStyle = true,
            AuthenticationRegion = "us-east-1"
        };

        S3Client = new AmazonS3Client(
            new BasicAWSCredentials("test", "test"),
            config
        );

        await CreateTestBucketAsync();
    }

    public async Task DisposeAsync()
    {
        await CleanupTestBucketAsync();

        S3Client?.Dispose();

        if (_localStackContainer != null)
        {
            await _localStackContainer.DisposeAsync();
        }
    }

    private async Task CreateTestBucketAsync()
    {
        try
        {
            var bucketExists = await AmazonS3Util.DoesS3BucketExistV2Async(S3Client!, TestBucketName);
            if (!bucketExists)
            {
                await S3Client!.PutBucketAsync(new PutBucketRequest
                {
                    BucketName = TestBucketName,
                    UseClientRegion = true
                });
            }
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException($"Failed to create test bucket: {ex.Message}", ex);
        }
    }

    private async Task CleanupTestBucketAsync()
    {
        try
        {
            if (S3Client == null) return;

            var bucketExists = await AmazonS3Util.DoesS3BucketExistV2Async(S3Client, TestBucketName);
            if (!bucketExists) return;

            var listResponse = await S3Client.ListObjectsV2Async(new ListObjectsV2Request
            {
                BucketName = TestBucketName
            });

            if (listResponse.S3Objects.Count > 0)
            {
                var deleteRequest = new DeleteObjectsRequest
                {
                    BucketName = TestBucketName,
                    Objects = listResponse.S3Objects.Select(obj => new KeyVersion { Key = obj.Key }).ToList()
                };

                await S3Client.DeleteObjectsAsync(deleteRequest);
            }

            var multipartUploads = await S3Client.ListMultipartUploadsAsync(new ListMultipartUploadsRequest
            {
                BucketName = TestBucketName
            });

            foreach (var upload in multipartUploads.MultipartUploads)
            {
                await S3Client.AbortMultipartUploadAsync(new AbortMultipartUploadRequest
                {
                    BucketName = TestBucketName,
                    Key = upload.Key,
                    UploadId = upload.UploadId
                });
            }
        }
        catch (Exception)
        {
            // skip errors during cleanup
        }
    }

    protected async Task<bool> ObjectExistsAsync(string key)
    {
        try
        {
            await S3Client!.GetObjectMetadataAsync(new GetObjectMetadataRequest
            {
                BucketName = TestBucketName,
                Key = key
            });
            return true;
        }
        catch (AmazonS3Exception ex) when (ex.StatusCode == System.Net.HttpStatusCode.NotFound)
        {
            return false;
        }
    }

    protected async Task<string?> GetObjectContentAsync(string key)
    {
        var response = await S3Client!.GetObjectAsync(new GetObjectRequest
        {
            BucketName = TestBucketName,
            Key = key
        });

        using var reader = new StreamReader(response.ResponseStream);
        return await reader.ReadToEndAsync();
    }
}

using System.Text;
using PaymentsDataLayerReports.Integration.Test.Exceptions;

namespace PaymentsDataLayerReports.Integration.Test.Helpers;

/// <summary>
/// Helper para testes de integração baseados em arquivos.
/// Fornece métodos para carregar casos de teste de diretórios estruturados,
/// preparar streams de entrada/saída e validar resultados.
/// </summary>
public static class FileBasedTestHelper
{
    public class TestCase
    {
        public required string Name { get; init; }
        public required string InputPath { get; init; }
        public required string ExpectedOutputPath { get; init; }
        public required string ActualOutputPath { get; init; }
        public required string InputHeader { get; init; }
        public required string InputData { get; init; }
    }

    public static TestCase LoadTestCase(string testDataBasePath, string testCaseName)
    {
        var testCaseDir = Path.Combine(testDataBasePath, "TestCases", testCaseName);

        if (!Directory.Exists(testCaseDir))
        {
            throw new SkipException($"Test case directory not found: {testCaseName}");
        }

        var inputPath = Path.Combine(testCaseDir, "input.csv");
        var expectedOutputPath = Path.Combine(testCaseDir, "expected.csv");
        var actualOutputPath = Path.Combine(testCaseDir, "result.csv");

        if (!File.Exists(inputPath))
            throw new FileNotFoundException($"Arquivo de entrada não encontrado para o caso de teste '{testCaseName}'", inputPath);

        if (!File.Exists(expectedOutputPath))
            throw new FileNotFoundException($"Arquivo de saída esperada não encontrado para o caso de teste '{testCaseName}'", expectedOutputPath);

        var inputHeader = File.ReadLines(inputPath).First();

        var dataLines = File.ReadAllLines(inputPath)
            .Skip(1)
            .Where(line => !string.IsNullOrWhiteSpace(line));
        var inputData = string.Join(Environment.NewLine, dataLines);

        return new TestCase
        {
            Name = testCaseName,
            InputPath = inputPath,
            ExpectedOutputPath = expectedOutputPath,
            ActualOutputPath = actualOutputPath,
            InputHeader = inputHeader,
            InputData = inputData
        };
    }


    public static MemoryStream CreateInputStream(TestCase testCase)
    {
        return new MemoryStream(Encoding.UTF8.GetBytes(testCase.InputData));
    }

    public static FileStream CreateOutputStream(TestCase testCase)
    {
        return new FileStream(testCase.ActualOutputPath, FileMode.Create, FileAccess.Write);
    }

    public static void ValidateOutput(
        TestCase testCase,
        bool ignoreColumnOrder = false,
        HashSet<string>? columnsToIgnore = null)
    {
        var comparisonResult = CsvComparer.Compare(
            actualCsvPath: testCase.ActualOutputPath,
            expectedCsvPath: testCase.ExpectedOutputPath,
            ignoreColumnOrder: ignoreColumnOrder,
            columnsToIgnore: columnsToIgnore
        );

        comparisonResult.AssertSuccess();
    }

    public static (int ActualRowCount, int ExpectedRowCount) ValidateRowCount(TestCase testCase)
    {
        var actualRowCount = CsvComparer.CountDataRows(testCase.ActualOutputPath);
        var expectedRowCount = CsvComparer.CountDataRows(testCase.ExpectedOutputPath);

        return (actualRowCount, expectedRowCount);
    }
}

using Hangfire;
using Hangfire.Common;
using Hangfire.Server;
using Hangfire.Storage;
using NSubstitute;

namespace PaymentsDataLayerReports.Integration.Test.Helpers;

/// <summary>
/// Factory class for creating Hangfire mock objects used across integration tests.
/// </summary>
public static class MockFactory
{
    /// <summary>
    /// Creates a mock PerformContext with a specified job ID.
    /// </summary>
    /// <param name="jobId">The job ID to use. Default is "test-job-id".</param>
    /// <returns>A configured mock PerformContext.</returns>
    public static PerformContext CreatePerformContext(string jobId = "test-job-id")
    {
        var backgroundJob = CreateBackgroundJob(jobId);

        return Substitute.For<PerformContext>(
            Substitute.For<IStorageConnection>(),
            backgroundJob,
            Substitute.For<IJobCancellationToken>()
        );
    }

    /// <summary>
    /// Creates a mock BackgroundJob with a specified job ID.
    /// </summary>
    /// <param name="jobId">The job ID to use. Default is "test-job-id".</param>
    /// <param name="createdAt">The creation timestamp. Default is DateTime.UtcNow.</param>
    /// <returns>A configured mock BackgroundJob.</returns>
    public static BackgroundJob CreateBackgroundJob(
        string jobId = "test-job-id",
        DateTime? createdAt = null)
    {
        var job = Job.FromExpression(() => Console.WriteLine());
        var timestamp = createdAt ?? DateTime.UtcNow;

        return Substitute.For<BackgroundJob>(jobId, job, timestamp);
    }
}

using Amazon.Runtime;
using Amazon.S3;
using Amazon.S3.Model;
using Amazon.S3.Util;
using Testcontainers.LocalStack;

namespace PaymentsDataLayerReports.Integration.Test.Helpers;

/// <summary>
/// Fixture compartilhado para testes de integração com S3.
/// Cria um único container LocalStack que é reutilizado por todos os testes,
/// significativamente reduzindo o tempo de execução.
/// </summary>
public class S3LocalStackFixture : IAsyncLifetime
{
    private LocalStackContainer? _localStackContainer;
    public IAmazonS3? S3Client { get; private set; }
    public const string TestBucketName = "test-integration-bucket";

    public async Task InitializeAsync()
    {
        _localStackContainer = new LocalStackBuilder()
            .WithImage("localstack/localstack:3.0")
            .Build();

        await _localStackContainer.StartAsync();

        var config = new AmazonS3Config
        {
            ServiceURL = _localStackContainer.GetConnectionString(),
            ForcePathStyle = true,
            AuthenticationRegion = "us-east-1"
        };

        S3Client = new AmazonS3Client(
            new BasicAWSCredentials("test", "test"),
            config
        );

        // Aguarda um pouco para garantir que o LocalStack esteja totalmente inicializado
        await Task.Delay(1000);

        await CreateTestBucketAsync();
    }

    public async Task DisposeAsync()
    {
        S3Client?.Dispose();

        if (_localStackContainer != null)
        {
            await _localStackContainer.StopAsync();
            await _localStackContainer.DisposeAsync();
        }
    }

    private async Task CreateTestBucketAsync()
    {
        var bucketExists = await AmazonS3Util.DoesS3BucketExistV2Async(S3Client!, TestBucketName);
        if (!bucketExists)
        {
            await S3Client!.PutBucketAsync(new PutBucketRequest
            {
                BucketName = TestBucketName,
                UseClientRegion = true
            });
        }
    }

    public async Task CleanupBucketAsync()
    {
        if (S3Client == null) return;

        var listResponse = await S3Client.ListObjectsV2Async(new ListObjectsV2Request
        {
            BucketName = TestBucketName
        });

        if (listResponse.S3Objects.Count > 0)
        {
            var deleteRequest = new DeleteObjectsRequest
            {
                BucketName = TestBucketName,
                Objects = listResponse.S3Objects.Select(obj => new KeyVersion { Key = obj.Key }).ToList()
            };

            await S3Client.DeleteObjectsAsync(deleteRequest);
        }

        var multipartUploads = await S3Client.ListMultipartUploadsAsync(new ListMultipartUploadsRequest
        {
            BucketName = TestBucketName
        });

        foreach (var upload in multipartUploads.MultipartUploads)
        {
            await S3Client.AbortMultipartUploadAsync(new AbortMultipartUploadRequest
            {
                BucketName = TestBucketName,
                Key = upload.Key,
                UploadId = upload.UploadId
            });
        }
    }
}

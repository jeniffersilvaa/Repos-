#!/usr/bin/env python3
"""
Script para anonimização de dados sensíveis em arquivos CSV.
Usado para preparar dados de teste sem expor informações produtivas.

Uso:
    python anonymize.py input.csv output.csv
"""

import csv
import sys
import uuid
from pathlib import Path


# Colunas que devem ser anonimizadas
COLUMNS_TO_ANONYMIZE = [
    "event_id",
    "id",
    "initiator_id",
    "origin_id",
    "attempt_count",
    "all_ids",
    "code",
    "gateway",
    "gateway_order_id",
    "platform_name",
    "split",
    "merchant__user_id",
    "merchant__document",
    "merchant__affiliation_key",
    "merchant__affiliation_code",
    "merchant__account_id",
    "merchant__merchant_id",
    "card_transaction__transaction_id",
    "card_transaction__authorization_code",
    "card_transaction__card__holder_name",
    "card_transaction__card__number_token",
    "card_transaction__customer__name",
    "card_transaction__customer__customer_id",
    "card_transaction__customer__document",
    "card_transaction__customer__email",
    "card_transaction__customer__address__city",
    "card_transaction__customer__address__street",
    "card_transaction__customer__address__extra",
    "card_transaction__customer__address__street_number",
    "card_transaction__customer__address__neighborhood",
    "card_transaction__customer__address__state",
    "card_transaction__customer__address__postal_code",
    "card_transaction__terminal__serial_number",
    "card_transaction__detail__legacy__account_name",
    "card_transaction__detail__acquirer__nsu",
    "card_transaction__detail__acquirer__tid",
    "card_transaction__detail__antifraud_response__provider_name",
    "card_transaction__detail__pgid",
    "card_transaction__detail__operation_id",
    "card_transaction__fee__id",
    "card_transaction__financial_movement__operation_id",
    "boleto_transaction__transaction_id",
    "boleto_transaction__our_number",
    "boleto_transaction__barcode",
    "boleto_transaction__writable_line",
    "boleto_transaction__instructions",
    "boleto_transaction__url",
    "boleto_transaction__receiver__name",
    "boleto_transaction__receiver__document",
    "boleto_transaction__customer__name",
    "boleto_transaction__customer__customer_id",
    "boleto_transaction__customer__document",
    "boleto_transaction__customer__email",
    "boleto_transaction__customer__address__street",
    "boleto_transaction__customer__address__street_number",
    "boleto_transaction__customer__address__extra",
    "boleto_transaction__customer__address__neighborhood",
    "boleto_transaction__customer__address__postal_code",
    "boleto_transaction__customer__address__city",
    "boleto_transaction__customer__address__state",
    "boleto_transaction__detail__legacy__account_name",
    "boleto_transaction__detail__pgid",
    "boleto_transaction__detail__operation_id",
    "pix_transaction__transaction_id",
    "pix_transaction__e2e_id",
    "pix_transaction__pix_key",
    "pix_transaction__pix_key_nickname",
    "pix_transaction__request_for_payer",
    "pix_transaction__customer__name",
    "pix_transaction__customer__customer_id",
    "pix_transaction__customer__document",
    "pix_transaction__customer__email",
    "pix_transaction__customer__address__city",
    "pix_transaction__customer__address__street",
    "pix_transaction__customer__address__extra",
    "pix_transaction__customer__address__street_number",
    "pix_transaction__customer__address__neighborhood",
    "pix_transaction__customer__address__state",
    "pix_transaction__customer__address__postal_code",
    "pix_transaction__payer__name",
    "pix_transaction__payer__document",
    "pix_transaction__additional_data",
    "pix_transaction__terminal__id",
    "pix_transaction__detail__pgid",
    "pix_transaction__detail__operation_id",
    "pix_transaction__detail__qrcode_content",
    "pix_transaction__detail__description",
    "pix_transaction__detail__refund_id",
    "cash_transaction__description",
    "cash_transaction__transaction_id",
    "cash_transaction__customer__name",
    "cash_transaction__customer__customer_id",
    "cash_transaction__customer__document",
    "cash_transaction__customer__email",
    "cash_transaction__customer__address__city",
    "cash_transaction__customer__address__street",
    "cash_transaction__customer__address__extra",
    "cash_transaction__customer__address__street_number",
    "cash_transaction__customer__address__neighborhood",
    "cash_transaction__customer__address__state",
    "cash_transaction__customer__address__postal_code",
    "cash_transaction__detail__legacy__account_name",
    "cash_transaction__detail__operation_id"   
]

# Colunas com JSON estruturado — serão esvaziadas (não substituídas por UUID)
COLUMNS_TO_NULLIFY = [
    "metadata",
]


def anonymize_value(value: str) -> str:
    if not value or value.strip() == "":
        return value
    
    anonymized = str(uuid.uuid5(uuid.NAMESPACE_DNS, value))
    
    return anonymized


def anonymize_csv(input_path: str, output_path: str) -> None:
    """
    Lê um CSV, anonimiza as colunas sensíveis e salva em outro arquivo.
    
    Args:
        input_path: Caminho do arquivo CSV de entrada
        output_path: Caminho do arquivo CSV de saída
    """
    input_file = Path(input_path)
    output_file = Path(output_path)
    
    if not input_file.exists():
        print(f"❌ Erro: Arquivo '{input_path}' não encontrado.")
        sys.exit(1)
    
    print(f"📖 Lendo arquivo: {input_path}")
    
    rows_processed = 0
    columns_anonymized = set()
    
    try:
        with open(input_file, 'r', encoding='utf-8') as infile, \
             open(output_file, 'w', encoding='utf-8', newline='') as outfile:
            
            reader = csv.DictReader(infile)
            
            if not reader.fieldnames:
                print("❌ Erro: Arquivo CSV vazio ou sem cabeçalho.")
                sys.exit(1)
            
            # Identifica quais colunas existem no CSV e devem ser anonimizadas
            columns_to_process = [col for col in reader.fieldnames if col in COLUMNS_TO_ANONYMIZE]
            columns_to_nullify = [col for col in reader.fieldnames if col in COLUMNS_TO_NULLIFY]
            
            print(f"🔍 Encontradas {len(columns_to_process)} colunas para anonimizar e {len(columns_to_nullify)} para esvaziar de {len(reader.fieldnames)} totais")
            
            writer = csv.DictWriter(outfile, fieldnames=reader.fieldnames)
            writer.writeheader()
            
            for row in reader:
                # Anonimiza as colunas sensíveis
                for column in columns_to_process:
                    if column in row and row[column]:
                        row[column] = anonymize_value(row[column])
                        columns_anonymized.add(column)
                
                # Esvazia colunas com JSON estruturado
                for column in columns_to_nullify:
                    if column in row and row[column]:
                        row[column] = ""
                        columns_anonymized.add(column)
                
                writer.writerow(row)
                rows_processed += 1
                
                if rows_processed % 1000 == 0:
                    print(f"⏳ Processadas {rows_processed} linhas...")
        
        if columns_anonymized:
            print(f"\n   Colunas modificadas:")
            for col in sorted(columns_anonymized):
                print(f"      - {col}")
    
    except Exception as e:
        print(f"❌ Erro durante o processamento: {e}")
        sys.exit(1)


def main():
    if len(sys.argv) != 3:
        print("Uso: python anonymize.py <input.csv> <output.csv>")
        print("\nExemplo:")
        print("  python anonymize.py data/production.csv data/test_anonymized.csv")
        sys.exit(1)
    
    input_path = sys.argv[1]
    output_path = sys.argv[2]
    
    print("🔐 Script de Anonimização de Dados CSV")
    print("=" * 50)
    
    anonymize_csv(input_path, output_path)


if __name__ == "__main__":
    main()
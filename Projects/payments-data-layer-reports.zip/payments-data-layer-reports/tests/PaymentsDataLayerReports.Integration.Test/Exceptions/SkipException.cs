namespace PaymentsDataLayerReports.Integration.Test.Exceptions;

/// <summary>
/// Exception para marcar testes como "skipped" quando os dados de teste não estão disponíveis.
/// </summary>
public class SkipException(string message) : Exception(message)
{
}
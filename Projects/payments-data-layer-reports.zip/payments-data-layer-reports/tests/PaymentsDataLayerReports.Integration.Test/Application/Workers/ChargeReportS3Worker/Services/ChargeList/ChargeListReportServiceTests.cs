using System.Text;
using System.Text.Unicode;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.ChargeList;
using PaymentsDataLayerReports.Application.Workers.ChargeReportWorker;
using PaymentsDataLayerReports.Application.Workers.Shared.Mappers.Charges;
using PaymentsDataLayerReports.Application.Workers.Shared.Modifiers.ChargeList;

namespace PaymentsDataLayerReports.Integration.Test.Application.Workers.ChargeReportS3Worker.Services.ChargeList;

/// <summary>
/// Testes de integração para o ChargeListReportService.
/// Valida o processamento completo de arquivos CSV de entrada para saída,
/// comparando os resultados com arquivos de baseline esperados.
public class ChargeListReportServiceTests
{
    private const string TestDataBasePath = "TestData/ChargeListReportService";

    #region Active Tests - Card Transactions


    [Theory]
    /// <summary>
    /// Testa o processamento de transação básica de cartão.
    /// Valida: campos principais, valores monetários, status.
    /// </summary>
    [InlineData("Case01_BasicCardTransaction")]
    /// <summary>
    /// Testa autorização e captura como operações separadas.
    /// Valida: fluxo auth → capture, valores corretos em cada etapa.
    /// </summary>
    [InlineData("Case02_CardAuthAndCapture")]
    /// <summary>
    /// Testa transação de cartão com chargeback.
    /// Valida: valores de chargeback, status final, impacto nos valores líquidos.
    /// </summary>
    [InlineData("Case03_CardWithChargeback")]
    /// <summary>
    /// Testa transação com chargeback seguido de estorno (chargeback_refund).
    /// Valida: reversão de chargeback, valores corretos após estorno.
    /// </summary>
    [InlineData("Case04_CardWithChargebackRefund")]
    /// <summary>
    /// Testa transação com múltiplas operações (auth, capture, cancel).
    /// Valida: sequência correta, valores acumulados, status final.
    /// </summary>
    [InlineData("Case05_CardWithMultipleOperations")]
    /// <summary>
    /// Testa cálculo de taxas (MDR, RAV, FC).
    /// Valida: valores de taxas, cálculo correto de fee total.
    /// </summary>
    [InlineData("Case06_CardWithFees")]
    /// <summary>
    /// Testa transação básica de Pix.
    /// Valida: campos principais, valores monetários, status de pagamento.
    /// </summary>
    [InlineData("Case07_BasicPixTransaction")]
    /// <summary>
    /// Testa transação Pix com cancelamento.
    /// Valida: valores de cancelamento, status final cancelado.
    /// </summary>
    [InlineData("Case08_PixWithCancel")]
    /// <summary>
    /// Testa transação básica em dinheiro (cash).
    /// Valida: campos principais, valores monetários, status.
    /// </summary>
    [InlineData("Case09_BasicCashTransaction")]
    /// <summary>
    /// Testa transação cash com cancelamento.
    /// Valida: valores cancelados, status final.
    /// </summary>
    [InlineData("Case10_CashWithCancel")]
    public async Task ProcessAsync(string testCaseName)
    {
        // Arrange & Act & Assert
        await ExecuteTestCase(testCaseName, organization: "stone");
    }

    #endregion

    #region Helper Methods

    /// <summary>
    /// Executa um caso de teste completo: carrega dados, processa e valida saída.
    /// </summary>
    /// <param name="testCaseName">Nome do caso de teste (deve corresponder ao nome do diretório)</param>
    /// <param name="organization">Organização para filtro (padrão: "stone")</param>
    /// <param name="isCetEnabled">Se CET está habilitado (padrão: false)</param>
    private static async Task ExecuteTestCase(string testCaseName, string organization = "stone", bool isCetEnabled = false)
    {
        // Arrange
        var testCase = FileBasedTestHelper.LoadTestCase(TestDataBasePath, testCaseName);

        using var inputStream = FileBasedTestHelper.CreateInputStream(testCase);

        using var outputStream = FileBasedTestHelper.CreateOutputStream(testCase);

        var csvMapper = new ChargeCsvMapper
        {
            IsCetEnabled = isCetEnabled
        };
        var modifier = new SalesModifier(csvMapper);

        // Configuração de parâmetros do worker
        var parameters = new ChargeReportsWorkerParameters
        {
            StartDate = new DateTime(2025, 1, 1),
            EndDate = new DateTime(2025, 12, 31),
            ReportType = "charges_list",
            Organizations = organization
        };

        // Escrever cabeçalho no stream de saída
        await outputStream.WriteAsync(Encoding.UTF8.GetBytes(csvMapper.GetHeader() + "\n"));
        await outputStream.FlushAsync();

        // Act - Processar o CSV
        await ChargeListReportService.ProcessAsync(
            input: inputStream,
            output: outputStream,
            inputHeader: testCase.InputHeader,
            reportId: $"test-report-{testCaseName}",
            jobId: $"test-job-{testCaseName}",
            modifier: modifier,
            parameters: parameters,
            cancellationToken: CancellationToken.None
        );

        // Garantir que o stream foi fechado e o arquivo escrito
        outputStream.Dispose();

        // Assert - Validar contagem de linhas
        var (actualRowCount, expectedRowCount) = FileBasedTestHelper.ValidateRowCount(testCase);
        Assert.Equal(expectedRowCount, actualRowCount);

        // Assert - Validar conteúdo completo
        FileBasedTestHelper.ValidateOutput(testCase);
    }

    #endregion
}
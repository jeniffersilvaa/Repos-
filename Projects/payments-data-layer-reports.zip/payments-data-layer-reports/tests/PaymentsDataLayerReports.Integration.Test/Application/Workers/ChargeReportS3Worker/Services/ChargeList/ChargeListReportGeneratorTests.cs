using Amazon.S3;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using NSubstitute;
using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Services.DeltaTableColumnMapping;
using PaymentsDataLayerReports.Application.Services.DeltaTablePartitionBuilder;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.ChargeList;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.Models;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.RealtimeChargeEvents;
using PaymentsDataLayerReports.Application.Workers.ChargeReportWorker;
using PaymentsDataLayerReports.Application.Workers.Shared;
using PaymentsDataLayerReports.Application.Workers.Shared.Mappers.Charges;
using PaymentsDataLayerReports.Integration.Test.Helpers;

namespace PaymentsDataLayerReports.Integration.Test.Application.Workers.ChargeReportS3Worker.Services.ChargeList;

/// <summary>
/// Testes de integração para o ChargeListReportGenerator.
/// Valida o pipeline completo: conversão CSV (DuckDB), ordenação + deduplicação (bash), 
/// e processamento de charges (ChargeListReportService).
/// </summary>
public class ChargeListReportGeneratorTests
{
    private const string TestDataBasePath = "TestData/ChargeListReportGenerator";

    [Theory]
    [InlineData("Case01_StonePagarmeDedup", "document", new[] { "c7a0f83b-a398-5b6f-8d97-5eed59b22aa0" })]
    public async Task ProcessAsync(string testCaseName, string partitionIdReferenceType, string[] partitionIds)
    {
        await ExecuteTestCase(testCaseName, partitionIds, partitionIdReferenceType, organizations: "stone,pagarme");
    }

    private static async Task ExecuteTestCase(
        string testCaseName,
        string[] partitionIds,
        string partitionIdReferenceType = "document",
        string organizations = "stone",
        bool isCetEnabled = false)
    {
        // Arrange - Paths
        var testCaseDir = Path.Combine(TestDataBasePath, "TestCases", testCaseName);
        var inputCsvPath = Path.GetFullPath(Path.Combine(testCaseDir, "input.csv"));
        var expectedOutputPath = Path.Combine(testCaseDir, "expected.csv");
        var actualOutputPath = Path.Combine(testCaseDir, "result.csv");

        if (!File.Exists(inputCsvPath))
            throw new FileNotFoundException($"Arquivo de entrada não encontrado: {inputCsvPath}");
        if (!File.Exists(expectedOutputPath))
            throw new FileNotFoundException($"Arquivo de saída esperada não encontrado: {expectedOutputPath}");

        // Arrange - Real ChargeListReportManager (sort/dedup via bash)
        var dataLayerSettings = Options.Create(new DataLayerReportsSettings
        {
            BashPath = "/bin/bash"
        });
        var chargeListReportManager = new ChargeListReportManager(dataLayerSettings);

        // Arrange - Mock IRealtimeChargeEventsService
        // Copia o input.csv para o diretório como realtime.csv (simulando dados do Elasticsearch)
        var realtimeService = Substitute.For<IRealtimeChargeEventsService>();
        realtimeService.BuildRealtimeFileAsync(Arg.Any<GenerateReportInput>(), Arg.Any<string>())
            .Returns(callInfo =>
            {
                var path = callInfo.ArgAt<string>(1);
                var destPath = Path.Combine(path, "realtime.csv");
                File.Copy(inputCsvPath, destPath, overwrite: true);
                return true;
            });

        // Arrange - Real DeltaLakeManager (com IAmazonS3 mockado)
        // DownloadAsync retorna 0 pois Partitions é vazio (sem dados parquet)
        // ConvertToCsvAsync usa DuckDB real para processar o CSV
        var s3Client = Substitute.For<IAmazonS3>();
        var awsSettings = Options.Create(new AwsSettings { WarehouseBucket = "test-bucket" });
        var columnMappingService = Substitute.For<IColumnMappingService>();
        var reportSettings = Options.Create(new ReportSettings());
        var deltaLakeManager = new DeltaLakeManager(s3Client, awsSettings, columnMappingService, reportSettings);

        // Arrange - Mock IS3ClientWrapper
        // Captura o conteúdo do upload para validação (antes do Dispose do Generator)
        var s3ClientWrapper = Substitute.For<IS3ClientWrapper>();
        string? capturedHeader = null;
        string? capturedDataContent = null;

        s3ClientWrapper.UploadReportHeaderAsync(Arg.Any<string>(), Arg.Any<string>())
            .Returns(callInfo =>
            {
                capturedHeader = callInfo.ArgAt<string>(1);
                return Task.CompletedTask;
            });

        s3ClientWrapper.UploadReportAsync(
            Arg.Any<string>(), Arg.Any<string>(), Arg.Any<string>(), Arg.Any<DateTime>()
        ).Returns(callInfo =>
        {
            var sourcePath = callInfo.ArgAt<string>(0);
            if (File.Exists(sourcePath))
                capturedDataContent = File.ReadAllText(sourcePath);
            return Task.CompletedTask;
        });

        // Arrange - Mock ICetFeatureManager
        var cetFeatureManager = Substitute.For<ICetFeatureManager>();
        cetFeatureManager.IsCET(Arg.Any<string?>()).Returns(isCetEnabled);

        // Arrange - IServiceProvider com ChargeCsvMapper registrado
        var services = new ServiceCollection();
        services.AddKeyedSingleton<ISaleCsvMapper<Charge>, ChargeCsvMapper>("charges_list");
        var serviceProvider = services.BuildServiceProvider();

        // Arrange - Parâmetros do relatório
        var parameters = new ChargeReportsWorkerParameters
        {
            StartDate = new DateTime(2025, 1, 1),
            EndDate = new DateTime(2025, 12, 31),
            ReportType = "charges_list",
            Organizations = organizations,
            WithFailed = true
        };

        var reportMetadata = new ReportMetadata
        {
            Status = "processing",
            ReportId = $"test-report-{testCaseName}",
            DispatchId = $"test-dispatch-{testCaseName}",
            CreatedAt = DateTime.UtcNow,
            ReportSortColumnIndex = 0,
            ProcessorQueueName = "test-queue",
            FileFormat = "csv",
            ChargeReportParameters = parameters
        };

        var partitionSet = new DeltaTablePartitionSet
        {
            PartitionIdReferences = [.. partitionIds],
            PartitionIdReferenceType = partitionIdReferenceType,
            Partitions = [] // Vazio: DownloadAsync retorna 0 (sem parquet)
        };

        var input = new GenerateReportInput
        {
            PartitionDate = new DateTime(2025, 1, 1),
            PartitionSet = partitionSet,
            ReportMetadata = reportMetadata,
            CancellationToken = CancellationToken.None,
            JobId = $"test-job-{testCaseName}"
        };

        // Arrange - Criar o Generator com todas as dependências
        var generator = new ChargeListReportGenerator(
            deltaLakeManager,
            s3ClientWrapper,
            chargeListReportManager,
            realtimeService,
            cetFeatureManager,
            serviceProvider
        );

        // Act - Executar o pipeline completo
        await generator.Execute(input);

        // Assert - Verificar que o upload S3 foi chamado
        Assert.NotNull(capturedDataContent);
        Assert.NotNull(capturedHeader);

        // Escrever resultado com header para comparação
        await File.WriteAllTextAsync(actualOutputPath, capturedHeader + "\n" + capturedDataContent);

        // Assert - Validar contagem de linhas
        var actualRowCount = CsvComparer.CountDataRows(actualOutputPath);
        var expectedRowCount = CsvComparer.CountDataRows(expectedOutputPath);
        Assert.Equal(expectedRowCount, actualRowCount);

        // Assert - Validar conteúdo completo
        var comparisonResult = CsvComparer.Compare(
            actualCsvPath: actualOutputPath,
            expectedCsvPath: expectedOutputPath
        );
        comparisonResult.AssertSuccess();
    }
}

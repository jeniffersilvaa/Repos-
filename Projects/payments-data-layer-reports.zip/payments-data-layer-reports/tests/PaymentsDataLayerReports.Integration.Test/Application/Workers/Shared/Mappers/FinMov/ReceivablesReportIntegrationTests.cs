using Amazon.S3;
using Hangfire;
using Hangfire.Server;
using Microsoft.Extensions.Options;
using NSubstitute;
using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Entities.Models.FinMov;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Infra.MultiPartFileUploader;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Sinks;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.StreamWriters;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.FinMovList;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;
using PaymentsDataLayerReports.Application.Workers.Shared.Mappers.FinMov;
using PaymentsDataLayerReports.Application.Workers.Shared.Modifiers.FinMov;
using PaymentsDataLayerReports.Integration.Test.Helpers;

namespace PaymentsDataLayerReports.Integration.Test.Application.Workers.Shared.Mappers.FinMov;

public class ReceivablesReportIntegrationTests : IClassFixture<S3LocalStackFixture>, IAsyncLifetime
{
    private readonly S3LocalStackFixture _fixture;
    private readonly IReportStreamWriterFactory _writerFactory;
    private readonly AwsSettings _awsSettings;
    private readonly PerformContext _performContext;
    private readonly ReceivablesOneStoneCsvMapper _csvMapper;
    private readonly ReceivablesOneStoneModifier _s3Modifier;
    private const string TestBucketName = S3LocalStackFixture.TestBucketName;

    public ReceivablesReportIntegrationTests(S3LocalStackFixture fixture)
    {
        _fixture = fixture;
        _awsSettings = new AwsSettings { WorkgroupBucket = TestBucketName };
        _writerFactory = Substitute.For<IReportStreamWriterFactory>();
        _writerFactory.Create<string>(FileFormatEnum.Csv.Name).Returns(_ => CreateNewCsvWriter());
        _performContext = MockFactory.CreatePerformContext("integration-receivables-job");
        _csvMapper = new ReceivablesOneStoneCsvMapper();
        _s3Modifier = new ReceivablesOneStoneModifier();
    }

    private CsvReportStreamWriter CreateNewCsvWriter()
    {
        var uploader = new S3FileUploader(_fixture.S3Client!);
        var reportOutputSink = new S3MultipartReportSink(uploader);
        return new CsvReportStreamWriter(reportOutputSink, Options.Create(_awsSettings));
    }

    public Task InitializeAsync() => Task.CompletedTask;

    public async Task DisposeAsync()
    {
        await _fixture.CleanupBucketAsync();
    }

    [Fact]
    public Task ReceivablesOneStoneCsvMapper_WithFinMovData_ShouldGenerateValidCsvRow()
    {
        // Arrange
        var finMov = CreateTestFinancialMovement();

        // Act
        var csvRow = _csvMapper.BuildRow(finMov);
        var header = _csvMapper.GetHeader();

        // Assert
        Assert.NotNull(csvRow);
        Assert.NotEmpty(csvRow);
        Assert.Contains(";", csvRow);

        // Verify header contains expected columns
        Assert.Contains("CNPJ", header);
        Assert.Contains("LOJA", header);
        Assert.Contains("IDENTIFICADOR DA TRANSAÇÃO", header);
        Assert.Contains("DATA DE CAPTURA", header);
        Assert.Contains("CATEGORIA", header);
        Assert.Contains("MEIO DE CAPTURA", header);
        Assert.Contains("FORMA DE PAGAMENTO", header);
        Assert.Contains("BANDEIRA", header);
        return Task.CompletedTask;
    }

    [Fact]
    public Task ReceivablesOneStoneModifier_WithCsvRow_ShouldGenerateValidCsvRow()
    {
        // Arrange
        var csvRow = CreateTestCsvRow();

        // Act
        var result = _s3Modifier.BuildRow(csvRow);

        // Assert
        Assert.NotNull(result);
        Assert.NotEmpty(result);
        Assert.Contains(";", result);
        Assert.Contains("Venda", result); // Category should be translated
        return Task.CompletedTask;
    }

    [Fact]
    public Task ReceivablesOneStoneModifier_WithPointOfInteractionType_ShouldIncludeInOutput()
    {
        // Arrange
        var csvRow = CreateTestCsvRow(pointOfInteractionType: "Ecommerce");

        // Act
        var result = _s3Modifier.BuildRow(csvRow);

        // Assert
        Assert.NotNull(result);
        Assert.Contains("Ecommerce", result);
        return Task.CompletedTask;
    }

    [Fact]
    public async Task ReceivablesReport_EndToEnd_ShouldUploadToS3()
    {
        // Arrange
        var key = $"reports/receivables/{Guid.NewGuid()}.csv";
        var finMov = CreateTestFinancialMovement();
        var csvContent = _csvMapper.GetHeader() + "\n" + _csvMapper.BuildRow(finMov);

        // Act
        await _fixture.S3Client!.PutObjectAsync(new Amazon.S3.Model.PutObjectRequest
        {
            BucketName = TestBucketName,
            Key = key,
            ContentBody = csvContent
        });

        // Assert
        var response = await _fixture.S3Client.GetObjectAsync(TestBucketName, key);
        Assert.Equal(System.Net.HttpStatusCode.OK, response.HttpStatusCode);

        using var reader = new StreamReader(response.ResponseStream);
        var content = await reader.ReadToEndAsync();
        Assert.Contains("CNPJ", content);
        Assert.Contains("12.345.678/9012-34", content); // CNPJ formatado
    }

    [Fact]
    public Task ReceivablesOneStoneCsvMapper_WithDifferentCategories_ShouldTranslateCorrectly()
    {
        // Arrange & Act & Assert
        var categories = new[]
        {
            ("sale", "Venda"),
            ("chargeback", "Chargeback"),
            ("partial_reversal", "Cancelamento Parcial"),
            ("prepayment_fee", "Desconto de Antecipação")
        };

        foreach (var (operation, expectedCategory) in categories)
        {
            var finMov = CreateTestFinancialMovement(operation: operation);
            var csvRow = _csvMapper.BuildRow(finMov);
            Assert.Contains(expectedCategory, csvRow);
        }

        return Task.CompletedTask;
    }

    [Fact]
    public Task ReceivablesOneStoneCsvMapper_WithDifferentStatuses_ShouldTranslateCorrectly()
    {
        // Arrange & Act & Assert
        var statuses = new[]
        {
            ("paid", "Pago"),
            ("open", "Aberto"),
            ("scheduled", "Agendado")
        };

        foreach (var (status, expectedStatus) in statuses)
        {
            var finMov = CreateTestFinancialMovement(settlementStatus: status);
            var csvRow = _csvMapper.BuildRow(finMov);
            Assert.Contains(expectedStatus, csvRow);
        }

        return Task.CompletedTask;
    }

    #region Helper Methods

    private static FinancialMovement CreateTestFinancialMovement(
        string? operation = "sale",
        string? settlementStatus = "paid",
        string? pointOfInteractionType = "Ecommerce")
    {
        return new FinancialMovement(
            Id: "fin-test-001",
            OperationId: "op-001",
            OriginalDueDate: "2024-02-15",
            CurrentDueDate: "2024-02-15",
            LatestEventTimestamp: null,
            UpdatedAt: null,
            Amount: new Amount(
                Gross: 10000m,
                Net: 9500m,
                DiscountRate: new FeeModel(300m, 3.0m, 3.0m, "percentage"),
                PrepaymentFee: new FeeModel(200m, 2.0m, 2.0m, "percentage"),
                PrepaymentFeeTurbo: null
            ),
            Merchant: new Merchant(
                AffiliationCode: "1234567",
                UserId: null,
                Organization: null,
                Document: "12345678901234",
                AffiliationKey: null,
                PaymentProfileId: "PP123"
            ),
            PaymentOwner: new Merchant(
                AffiliationCode: null,
                UserId: null,
                Organization: null,
                Document: "12345678901234",
                AffiliationKey: null,
                PaymentProfileId: null
            ),
            Transaction: new Transaction(
                Product: null,
                AuthorizationDate: null,
                InstallmentNumber: 1,
                InstallmentQuantity: 1,
                CaptureDate: "2024-01-15T10:30:00Z",
                OperationKey: null,
                AccountFundingSource: null,
                Brand: "visa",
                Key: "txn-001",
                PointOfInteractionType: pointOfInteractionType
            ),
            Settlement: new Settlement(
                Status: settlementStatus,
                Key: null,
                BalanceDueDate: null,
                PaymentDate: null,
                Wallet: new Wallet("VisaCredit", "credit", null),
                Payment: null
            ),
            Operation: operation,
            Movements: null
        );
    }

    private static CsvRow CreateTestCsvRow(string? pointOfInteractionType = "Ecommerce")
    {
        var headerIndex = FinMovListReportHeader.HeaderIndex;
        var values = (object?[])FinMovListReportHeader.DefaultValues.Clone();
        values[headerIndex["id"]] = "fin-test-001";
        values[headerIndex["operation_id"]] = "op-001";
        values[headerIndex["original_due_date"]] = "2024-02-15";
        values[headerIndex["current_due_date"]] = "2024-02-15";
        values[headerIndex["amount__gross"]] = 10000m;
        values[headerIndex["amount__net"]] = 9500m;
        values[headerIndex["amount__discount_rate__amount"]] = 300m;
        values[headerIndex["amount__discount_rate__fee_type"]] = "percentage";
        values[headerIndex["amount__prepayment_fee__amount"]] = 200m;
        values[headerIndex["amount__prepayment_fee__fee_type"]] = "percentage";
        values[headerIndex["payment_owner__document"]] = "12345678901234";
        values[headerIndex["merchant__affiliation_code"]] = "1234567";
        values[headerIndex["transaction__key"]] = "txn-001";
        values[headerIndex["transaction__capture_date"]] = "2024-01-15T10:30:00Z";
        values[headerIndex["transaction__brand"]] = "visa";
        values[headerIndex["transaction__account_funding_source"]] = null;
        values[headerIndex["transaction__point_of_interaction_type"]] = pointOfInteractionType;
        values[headerIndex["transaction__installment_number"]] = 1;
        values[headerIndex["transaction__installment_quantity"]] = 1;
        values[headerIndex["settlement__status"]] = "paid";
        values[headerIndex["settlement__wallet__description"]] = "VisaCredit";
        values[headerIndex["operation"]] = "sale";
        return new CsvRow(values);
    }

    #endregion
}

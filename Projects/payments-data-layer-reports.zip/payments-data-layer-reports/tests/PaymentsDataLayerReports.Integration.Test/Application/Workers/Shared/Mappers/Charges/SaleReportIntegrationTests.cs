using Amazon.S3;
using Hangfire;
using Hangfire.Server;
using Microsoft.Extensions.Options;
using NSubstitute;
using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Entities.Models.Charge;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Infra.MultiPartFileUploader;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Sinks;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.StreamWriters;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.ChargeList;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;
using PaymentsDataLayerReports.Application.Workers.Shared.Mappers.Charges;
using PaymentsDataLayerReports.Application.Workers.Shared.Modifiers.ChargeList;
using PaymentsDataLayerReports.Integration.Test.Helpers;

namespace PaymentsDataLayerReports.Integration.Test.Application.Workers.Shared.Mappers.Charges;

public class SaleReportIntegrationTests : IClassFixture<S3LocalStackFixture>, IAsyncLifetime
{
    private readonly S3LocalStackFixture _fixture;
    private readonly IReportStreamWriterFactory _writerFactory;
    private readonly AwsSettings _awsSettings;
    private readonly PerformContext _performContext;
    private readonly SaleCsvMapper _csvMapper;
    private readonly SalesModifier _s3Modifier;
    private const string TestBucketName = S3LocalStackFixture.TestBucketName;

    public SaleReportIntegrationTests(S3LocalStackFixture fixture)
    {
        _fixture = fixture;
        _awsSettings = new AwsSettings { WorkgroupBucket = TestBucketName };
        _writerFactory = Substitute.For<IReportStreamWriterFactory>();
        _writerFactory.Create<string>(FileFormatEnum.Csv.Name).Returns(_ => CreateNewCsvWriter());
        _performContext = MockFactory.CreatePerformContext("integration-sale-job");
        _csvMapper = new SaleCsvMapper();
        _s3Modifier = new SalesModifier(_csvMapper);
    }

    private CsvReportStreamWriter CreateNewCsvWriter()
    {
        var uploader = new S3FileUploader(_fixture.S3Client!);
        var reportOutputSink = new S3MultipartReportSink(uploader);
        return new CsvReportStreamWriter(reportOutputSink, Options.Create(_awsSettings));
    }

    public Task InitializeAsync() => Task.CompletedTask;

    public async Task DisposeAsync()
    {
        await _fixture.CleanupBucketAsync();
    }

    [Fact]
    public Task SaleCsvMapper_WithChargeData_ShouldGenerateValidCsvRow()
    {
        // Arrange
        var charge = CreateTestCharge();

        // Act
        var csvRow = _csvMapper.BuildRow(charge);
        var header = _csvMapper.GetHeader();

        // Assert
        Assert.NotNull(csvRow);
        Assert.NotEmpty(csvRow);
        Assert.Contains(";", csvRow);

        // Verify header contains expected columns
        Assert.Contains("ADQUIRENTE", header);
        Assert.Contains("CNPJ", header);
        Assert.Contains("LOJA", header);
        Assert.Contains("IDENTIFICADOR DO PEDIDO", header);
        Assert.Contains("IDENTIFICADOR DA COBRANÇA", header);
        Assert.Contains("DATA DA AUTORIZAÇÃO", header);
        Assert.Contains("CÓDIGO DE AUTORIZAÇÃO", header);
        Assert.Contains("STATUS DO ANTIFRAUDE", header);
        Assert.Equal("ADQUIRENTE", header.Split(';')[19]);
        return Task.CompletedTask;
    }

    [Fact]
    public Task SalesModifier_WithCsvRow_ShouldGenerateValidCsvRow()
    {
        // Arrange
        var csvRow = CreateTestCsvRow();

        // Act
        var result = _s3Modifier.BuildRow(csvRow);

        // Assert
        Assert.NotNull(result);
        Assert.NotEmpty(result);
        Assert.Contains(";", result);
        return Task.CompletedTask;
    }

    [Fact]
    public async Task SaleReport_EndToEnd_ShouldUploadToS3()
    {
        // Arrange
        var key = $"reports/sale/{Guid.NewGuid()}.csv";
        var charge = CreateTestCharge();
        var csvContent = _csvMapper.GetHeader() + "\n" + _csvMapper.BuildRow(charge);

        // Act
        await _fixture.S3Client!.PutObjectAsync(new Amazon.S3.Model.PutObjectRequest
        {
            BucketName = TestBucketName,
            Key = key,
            ContentBody = csvContent
        });

        // Assert
        var response = await _fixture.S3Client.GetObjectAsync(TestBucketName, key);
        Assert.Equal(System.Net.HttpStatusCode.OK, response.HttpStatusCode);

        using var reader = new StreamReader(response.ResponseStream);
        var content = await reader.ReadToEndAsync();
        Assert.Contains("ADQUIRENTE", content);
        Assert.Contains("12345678901234", content); // CNPJ
        Assert.Contains("Stone", content);
    }

    #region Helper Methods

    private static Charge CreateTestCharge()
    {
        return new Charge(
            Id: "charge-test-001",
            ChargeId: "charge-test-001",
            InitiatorId: "init-001",
            Product: null,
            Origin: null,
            OriginId: null,
            Amount: 10000,
            UpdatedAmount: null,
            NetAmount: null,
            FullNetAmount: null,
            Status: "paid",
            PaymentMethod: "card",
            CreatedAt: DateTimeOffset.Now,
            PlatformName: null,
            AttemptCount: null,
            Gateway: null,
            GatewayOrderId: "order-001",
            Code: null,
            AllIds: null,
            Merchant: new Merchant(
                Organization: "org-001",
                Document: "12345678901234",
                UserId: "user-001",
                AffiliationKey: "key-001",
                AffiliationCode: "1234567",
                AccountId: "acc-001",
                MerchantId: "merch-001",
                StoneAccount: null,
                PaymentProfileId: "PP123"
            ),
            Split: new List<Split>(),
            CardTransaction: new CardTransaction(
                Type: "credit",
                FundingSource: "credit",
                TransactionId: "txn-001",
                FailedAmount: null,
                AuthorizedAmount: 10000,
                CapturedAmount: 10000,
                CanceledAmount: 0,
                ChargebackAmount: null,
                ChargebackRefundAmount: null,
                AuthorizationCode: "AUTH123",
                AuthorizedState: null,
                Installments: 1,
                InstallmentsType: "merchant",
                SchemeBusinessModel: "",
                FeeAmount: null,
                FullFeeAmount: null,
                MdrAmount: 300,
                FullMdrAmount: 300,
                MdrRefundAmount: null,
                FullMdrRefundAmount: null,
                FullFcAmount: null,
                FullFcRefundAmount: null,
                RavAmount: 100,
                FullRavAmount: 100,
                RavRefundAmount: null,
                FullRavRefundAmount: null,
                Customer: null,
                Card: new Card(
                    Brand: "visa",
                    BrandId: 1,
                    FirstSixDigits: "424242",
                    LastFourDigits: "4242",
                    EntryMode: "chip",
                    HolderName: "JOHN DOE",
                    ExpMonth: "12",
                    ExpYear: "2025",
                    CountryCode: 76,
                    CurrencyCode: 986,
                    NumberToken: null,
                    Label: null
                ),
                Terminal: new CardTerminal("ecommerce", "12345"),
                Last: null,
                Details: new List<CardDetail>
                {
                    new(
                        Operation: "authorization",
                        OperationId: "op-001",
                        OperationAmount: 10000,
                        ProviderDatetime: DateTime.Now.AddMinutes(-10),
                        LocalDatetime: null,
                        AcquirerMessage: "Approved",
                        AcquirerReturnCode: "00",
                        OperationReason: null,
                        Pgid: "pg-001",
                        Acquirer: new Acquirer("Stone", "123456", "789012"),
                        GatewayResponse: new GatewayResponse("00", "Approved"),
                        AntifraudResponse: new AntifraudResponse("antifraud-provider", "95", "approved"),
                        Legacy: null,
                        OperationStatus: "approved"
                    )
                }
            ),
            PixTransaction: null,
            BoletoTransaction: null,
            CashTransaction: null
        );
    }

    private static CsvRow CreateTestCsvRow()
    {
        var headerIndex = ChargeListReportHeader.HeaderIndex;
        var values = (object?[])ChargeListReportHeader.DefaultValues.Clone();
        values[headerIndex["id"]] = "charge-test-001";
        values[headerIndex["initiator_id"]] = "init-001";
        values[headerIndex["amount"]] = 10000;
        values[headerIndex["status"]] = "paid";
        values[headerIndex["payment_method"]] = "card";
        values[headerIndex["created_at"]] = DateTimeOffset.Now.ToString();
        values[headerIndex["gateway_order_id"]] = "order-001";
        values[headerIndex["merchant__document"]] = "12345678901234";
        values[headerIndex["merchant__affiliation_code"]] = "1234567";
        values[headerIndex["card_transaction__authorization_code"]] = "AUTH123";
        values[headerIndex["card_transaction__installments"]] = 1;
        values[headerIndex["card_transaction__card__brand"]] = "visa";
        values[headerIndex["card_transaction__terminal__type"]] = "ecommerce";
        return new CsvRow(values);
    }

    #endregion
}

using Amazon.S3;
using Amazon.S3.Model;
using Hangfire;
using Microsoft.Extensions.Options;
using NSubstitute;
using NSubstitute.ExceptionExtensions;
using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Entities.Models.Order;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Infra.DataLayerApi;
using PaymentsDataLayerReports.Application.Infra.DataLayerApi.Models;
using PaymentsDataLayerReports.Application.Infra.MultiPartFileUploader;
using PaymentsDataLayerReports.Application.Routes.Reports.PostReports.Models;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Sinks;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.StreamWriters;
using PaymentsDataLayerReports.Application.Settings;
using OrderAddress = PaymentsDataLayerReports.Application.Entities.Models.Order.Address;
using OrderCharge = PaymentsDataLayerReports.Application.Entities.Models.Order.Charge;
using OrderCustomer = PaymentsDataLayerReports.Application.Entities.Models.Order.Customer;
using ParametersType = PaymentsDataLayerReports.Application.Workers.OrderReportESWorker.OrderReportWorkerParameters;
using WorkerType = PaymentsDataLayerReports.Application.Workers.OrderReportESWorker.OrderReportESWorker;

namespace PaymentsDataLayerReports.Integration.Test.Application.Workers.OrderReportESWorker;

/// <summary>
/// Testes de integração para o OrderReportESWorker usando LocalStack.
/// Valida o comportamento completo do worker, incluindo geração de CSV e upload para S3.
/// 
/// Usa IClassFixture para compartilhar um único container LocalStack entre todos os testes,
/// mockando apenas o DataLayerApiClient para simular os dados vindos da API.
/// </summary>
public class OrderReportESWorkerIntegrationTests : IClassFixture<S3LocalStackFixture>, IAsyncLifetime
{
    private readonly S3LocalStackFixture _fixture;
    private readonly IDataLayerApiClient _dataLayerApiClient;
    private readonly IBackgroundJobClient _backgroundJobClient;
    private readonly IReportStreamWriterFactory _writerFactory;
    private readonly AwsSettings _awsSettings;
    private readonly Hangfire.Server.PerformContext _performContext;
    private readonly WorkerType _worker;
    private IAmazonS3 S3Client => _fixture.S3Client!;
    private const string TestBucketName = S3LocalStackFixture.TestBucketName;

    public OrderReportESWorkerIntegrationTests(S3LocalStackFixture fixture)
    {
        _fixture = fixture;
        _dataLayerApiClient = Substitute.For<IDataLayerApiClient>();
        _backgroundJobClient = Substitute.For<IBackgroundJobClient>();

        _awsSettings = new AwsSettings { WorkgroupBucket = TestBucketName };

        _writerFactory = Substitute.For<IReportStreamWriterFactory>();
        _writerFactory.Create<string>(FileFormatEnum.Csv.Name).Returns(_ => CreateNewCsvWriter());

        _performContext = MockFactory.CreatePerformContext("test-integration-job-id");

        _worker = new WorkerType(_dataLayerApiClient, _writerFactory, _backgroundJobClient);
    }

    private CsvReportStreamWriter CreateNewCsvWriter()
    {
        var uploader = new S3FileUploader(_fixture.S3Client!);
        var reportOutputSink = new S3MultipartReportSink(uploader);
        return new CsvReportStreamWriter(reportOutputSink, Options.Create(_awsSettings));
    }

    public Task InitializeAsync() => Task.CompletedTask;

    public async Task DisposeAsync()
    {
        await _fixture.CleanupBucketAsync();
    }

    private async Task<bool> ObjectExistsAsync(string key)
    {
        try
        {
            await S3Client.GetObjectMetadataAsync(new GetObjectMetadataRequest
            {
                BucketName = TestBucketName,
                Key = key
            });
            return true;
        }
        catch (AmazonS3Exception ex) when (ex.StatusCode == System.Net.HttpStatusCode.NotFound)
        {
            return false;
        }
    }

    private async Task<string> GetObjectContentAsync(string key)
    {
        var response = await S3Client.GetObjectAsync(new GetObjectRequest
        {
            BucketName = TestBucketName,
            Key = key
        });

        using var reader = new StreamReader(response.ResponseStream);
        return await reader.ReadToEndAsync();
    }

    private static Order CreateTestOrder(string orderId, int index)
    {
        var address = new OrderAddress(
            Id: $"address-{index}",
            Street: $"Test Street {index}",
            Neighborhood: "Test Neighborhood",
            Number: $"{index}",
            City: "Test City",
            State: "TS",
            Country: "BR",
            ZipCode: "12345-678"
        );

        var phones = new Phones
        {
            HomePhone = new Phone("11", "55", "22334455"),
            MobilePhone = new Phone("11", "55", "987654321")
        };

        var customer = new OrderCustomer(
            Name: $"Customer {index}",
            Email: $"customer{index}@test.com",
            Document: $"1234567890{index:D2}",
            Type: "individual",
            Id: $"customer-{index}",
            Address: address,
            Phones: phones
        );

        return new Order(
            Amount: 10000 + (index * 100),
            Charges:
            [
                new OrderCharge(Id: $"charge-{index}")
            ],
            Code: $"ORD-{index:D3}",
            Customer: customer,
            Device: new Device(Platform: "web"),
            Shipping: new Shipping(
                Amount: 1000,
                Description: "Standard Shipping",
                RecipientName: "Test Recipient",
                RecipientPhone: "11987654321",
                Address: new OrderAddress(
                    Id: $"shipping-address-{index}",
                    Street: "Shipping Street",
                    Neighborhood: "Shipping Neighborhood",
                    Number: "456",
                    City: "Shipping City",
                    State: "SP",
                    Country: "BR",
                    ZipCode: "87654-321"
                )
            ),
            Status: "paid",
            Id: orderId,
            Metadata: [],
            CreatedAt: DateTime.UtcNow.AddDays(-index),
            UpdatedAt: DateTime.UtcNow,
            ClosedAt: DateTime.UtcNow,
            CheckoutsCount: index
        );
    }

    [Fact]
    public async Task ProcessReport_WithSingleBatchOfOrders_ShouldUploadCsvToS3()
    {
        // Arrange
        var parameters = new ParametersType
        {
            StartDueDate = DateTime.UtcNow.AddDays(-7),
            EndDueDate = DateTime.UtcNow,
            Documents = "12345678900",
            FileFormat = "csv",
            Notification = new Notification { Email = new EmailNotification { Address = "test@example.com" } }
        };

        var orders = new List<Order>
        {
            CreateTestOrder("order-1", 1),
            CreateTestOrder("order-2", 2),
            CreateTestOrder("order-3", 3)
        };

        var cursorResult = new GetDataByCursorResponseModel<Order>
        {
            Data = orders,
            Cursor = null,
            Size = 3,
            Total = 3
        };

        _dataLayerApiClient
            .GetDataByCursor<Order>(default!, default!, default!, default!)
            .ReturnsForAnyArgs(cursorResult);

        // Act
        await _worker.ProcessReport(parameters, _performContext, CancellationToken.None);

        // Assert
        var expectedKey = "reports/test-integration-job-id.csv";
        var fileExists = await ObjectExistsAsync(expectedKey);
        Assert.True(fileExists, "CSV file should exist in S3");

        var content = await GetObjectContentAsync(expectedKey);
        Assert.NotEmpty(content);

        Assert.Contains("ID DO PEDIDO", content);
        Assert.Contains("CÓDIGO DO PEDIDO", content);
        Assert.Contains("STATUS", content);


        Assert.Contains("order-1", content);
        Assert.Contains("order-2", content);
        Assert.Contains("order-3", content);
        Assert.Contains("ORD-001", content);
        Assert.Contains("ORD-002", content);
        Assert.Contains("ORD-003", content);


        var lines = content.Split('\n', StringSplitOptions.RemoveEmptyEntries);
        Assert.Equal(4, lines.Length);
    }

    [Fact]
    public async Task ProcessReport_WithMultipleBatches_ShouldUploadCompleteCsvToS3()
    {
        // Arrange
        var parameters = new ParametersType
        {
            StartDueDate = DateTime.UtcNow.AddDays(-30),
            EndDueDate = DateTime.UtcNow,
            FileFormat = "csv",
            Notification = new Notification { Email = new EmailNotification { Address = "test@example.com" } }
        };

        var firstBatch = new GetDataByCursorResponseModel<Order>
        {
            Data =
            [
                CreateTestOrder("order-batch1-1", 1),
                CreateTestOrder("order-batch1-2", 2)
            ],
            Cursor = "cursor-1",
            Size = 2,
            Total = 5
        };

        var secondBatch = new GetDataByCursorResponseModel<Order>
        {
            Data =
            [
                CreateTestOrder("order-batch2-1", 3),
                CreateTestOrder("order-batch2-2", 4)
            ],
            Cursor = "cursor-2",
            Size = 2,
            Total = 5
        };

        var thirdBatch = new GetDataByCursorResponseModel<Order>
        {
            Data =
            [
                CreateTestOrder("order-batch3-1", 5)
            ],
            Cursor = null,
            Size = 1,
            Total = 5
        };

        _dataLayerApiClient
            .GetDataByCursor<Order>(default!, default!, default!, default!)
            .ReturnsForAnyArgs(callInfo =>
            {
                var request = callInfo.ArgAt<IGetDataByCursorRequestModel>(1);
                if (request.Cursor == null)
                    return firstBatch;
                if (request.Cursor == "cursor-1")
                    return secondBatch;
                if (request.Cursor == "cursor-2")
                    return thirdBatch;
                return thirdBatch;
            });

        // Act
        await _worker.ProcessReport(parameters, _performContext, CancellationToken.None);

        // Assert
        var expectedKey = "reports/test-integration-job-id.csv";
        var fileExists = await ObjectExistsAsync(expectedKey);
        Assert.True(fileExists, "CSV file should exist in S3");

        var content = await GetObjectContentAsync(expectedKey);

        Assert.Contains("order-batch1-1", content);
        Assert.Contains("order-batch1-2", content);
        Assert.Contains("order-batch2-1", content);
        Assert.Contains("order-batch2-2", content);
        Assert.Contains("order-batch3-1", content);


        var lines = content.Split('\n', StringSplitOptions.RemoveEmptyEntries);
        Assert.Equal(6, lines.Length);
    }

    [Fact]
    public async Task ProcessReport_WithEmptyResult_ShouldUploadHeaderOnlyToS3()
    {
        // Arrange
        var parameters = new ParametersType
        {
            StartDueDate = DateTime.UtcNow.AddDays(-1),
            EndDueDate = DateTime.UtcNow,
            Status = "nonexistent_status",
            FileFormat = "csv",
            Notification = new Notification { Email = new EmailNotification { Address = "test@example.com" } }
        };

        var emptyResult = new GetDataByCursorResponseModel<Order>
        {
            Data = [],
            Cursor = null,
            Size = 0,
            Total = 0
        };

        _dataLayerApiClient
            .GetDataByCursor<Order>(default!, default!, default!, default!)
            .ReturnsForAnyArgs(emptyResult);

        // Act
        await _worker.ProcessReport(parameters, _performContext, CancellationToken.None);

        // Assert
        var expectedKey = "reports/test-integration-job-id.csv";
        var fileExists = await ObjectExistsAsync(expectedKey);
        Assert.True(fileExists, "CSV file should exist in S3 even with no data");

        var content = await GetObjectContentAsync(expectedKey);

        Assert.Contains("ID DO PEDIDO", content);
        var lines = content.Split('\n', StringSplitOptions.RemoveEmptyEntries);
        Assert.Single(lines);
    }

    [Fact]
    public async Task ProcessReport_WithAllFilterParameters_ShouldPassCorrectFiltersToDataLayerApi()
    {
        // Arrange
        var parameters = new ParametersType
        {
            IsTestAccount = true,
            StartDueDate = DateTime.UtcNow.AddDays(-7),
            EndDueDate = DateTime.UtcNow,
            Status = "paid",
            Documents = "12345678900",
            MerchantId = "merchant-123",
            StoneAccounts = "stone-123",
            PaymentProfiles = "profile-1",
            PoiTypes = "ecommerce",
            FileFormat = "csv",
            Notification = new Notification { Email = new EmailNotification { Address = "test@example.com" } }
        };

        var orders = new List<Order> { CreateTestOrder("order-1", 1) };

        var cursorResult = new GetDataByCursorResponseModel<Order>
        {
            Data = orders,
            Cursor = null,
            Size = 1,
            Total = 1
        };

        IGetDataByCursorRequestModel? capturedRequest = null;

        _dataLayerApiClient
            .GetDataByCursor<Order>(
                Arg.Any<string>(),
                Arg.Do<IGetDataByCursorRequestModel>(r => capturedRequest = r),
                Arg.Any<string>(),
                Arg.Any<CancellationToken>()
            )
            .Returns(cursorResult);

        // Act
        await _worker.ProcessReport(parameters, _performContext, CancellationToken.None);

        // Assert
        Assert.NotNull(capturedRequest);
        Assert.Equal(parameters.IsTestAccount.ToString(), capturedRequest.FilterParameters!["is_test_account"]);
        Assert.Equal(parameters.StartDueDate.ToString("o"), capturedRequest.FilterParameters!["start_date"]);
        Assert.Equal(parameters.EndDueDate.ToString("o"), capturedRequest.FilterParameters!["end_date"]);
        Assert.Equal(parameters.Status, capturedRequest.FilterParameters!["settlement_status"]);
        Assert.Equal(parameters.Documents, capturedRequest.FilterParameters!["documents"]);
        Assert.Equal(parameters.StoneAccounts, capturedRequest.FilterParameters!["stone_accounts"]);
        Assert.Equal(parameters.PaymentProfiles, capturedRequest.FilterParameters!["payment_profile_ids"]);
        Assert.Equal(parameters.MerchantId, capturedRequest.FilterParameters!["merchant_id"]);
        Assert.Equal(parameters.PoiTypes, capturedRequest.FilterParameters!["point_of_interaction_types"]);

        var expectedKey = "reports/test-integration-job-id.csv";
        var fileExists = await ObjectExistsAsync(expectedKey);
        Assert.True(fileExists, "CSV file should exist in S3");
    }

    [Fact]
    public async Task ProcessReport_WhenDataLayerApiThrowsException_ShouldNotCreateFileInS3()
    {
        // Arrange
        var parameters = new ParametersType
        {
            StartDueDate = DateTime.UtcNow.AddDays(-1),
            EndDueDate = DateTime.UtcNow,
            FileFormat = "csv",
            Notification = new Notification { Email = new EmailNotification { Address = "test@example.com" } }
        };

        _dataLayerApiClient
            .GetDataByCursor<Order>(default!, default!, default!, default!)
            .ThrowsForAnyArgs(new Exception("DataLayer API Error"));

        // Act & Assert
        await Assert.ThrowsAsync<Exception>(
            async () => await _worker.ProcessReport(parameters, _performContext, CancellationToken.None)
        );

        var expectedKey = "reports/test-integration-job-id.csv";
        var fileExists = await ObjectExistsAsync(expectedKey);
        Assert.False(fileExists, "CSV file should not exist in S3 after error");

        var multipartUploads = await S3Client.ListMultipartUploadsAsync(new ListMultipartUploadsRequest
        {
            BucketName = TestBucketName
        });
        Assert.Empty(multipartUploads.MultipartUploads);
    }

    [Fact]
    public async Task ProcessReport_WithLargeDataSet_ShouldHandleMultipartUploadCorrectly()
    {
        // Arrange
        var parameters = new ParametersType
        {
            StartDueDate = DateTime.UtcNow.AddDays(-30),
            EndDueDate = DateTime.UtcNow,
            FileFormat = "csv",
            Notification = new Notification { Email = new EmailNotification { Address = "test@example.com" } }
        };

        var orders = Enumerable.Range(1, 100)
           .Select(i => CreateTestOrder($"order-{i}", i))
           .ToList();

        var cursorResult = new GetDataByCursorResponseModel<Order>
        {
            Data = orders,
            Cursor = null,
            Size = 100,
            Total = 100
        };

        _dataLayerApiClient
            .GetDataByCursor<Order>(default!, default!, default!, default!)
            .ReturnsForAnyArgs(cursorResult);

        // Act
        await _worker.ProcessReport(parameters, _performContext, CancellationToken.None);

        // Assert
        var expectedKey = "reports/test-integration-job-id.csv";
        var fileExists = await ObjectExistsAsync(expectedKey);
        Assert.True(fileExists, "Large CSV file should exist in S3");

        var content = await GetObjectContentAsync(expectedKey);

        Assert.Contains("order-1", content);
        Assert.Contains("order-50", content);
        Assert.Contains("order-100", content);

        var lines = content.Split('\n', StringSplitOptions.RemoveEmptyEntries);
        Assert.Equal(101, lines.Length);

        var metadata = await S3Client.GetObjectMetadataAsync(new GetObjectMetadataRequest
        {
            BucketName = TestBucketName,
            Key = expectedKey
        });
        Assert.True(metadata.ContentLength > 0, "File should have content");
    }

    [Fact]
    public async Task ProcessReport_WithCsvSpecialCharacters_ShouldEscapeCorrectly()
    {
        // Arrange
        var parameters = new ParametersType
        {
            StartDueDate = DateTime.UtcNow.AddDays(-1),
            EndDueDate = DateTime.UtcNow,
            FileFormat = "csv",
            Notification = new Notification { Email = new EmailNotification { Address = "test@example.com" } }
        };

        var order = CreateTestOrder("order-special", 1);

        var cursorResult = new GetDataByCursorResponseModel<Order>
        {
            Data = [order],
            Cursor = null,
            Size = 1,
            Total = 1
        };

        _dataLayerApiClient
            .GetDataByCursor<Order>(default!, default!, default!, default!)
            .ReturnsForAnyArgs(cursorResult);

        // Act
        await _worker.ProcessReport(parameters, _performContext, CancellationToken.None);

        // Assert
        var expectedKey = "reports/test-integration-job-id.csv";
        var fileExists = await ObjectExistsAsync(expectedKey);
        Assert.True(fileExists, "CSV file should exist in S3");

        var content = await GetObjectContentAsync(expectedKey);
        Assert.NotEmpty(content);

        var lines = content.Split('\n', StringSplitOptions.RemoveEmptyEntries);
        Assert.True(lines.Length >= 2, "Should have at least header and one data row");
    }
}

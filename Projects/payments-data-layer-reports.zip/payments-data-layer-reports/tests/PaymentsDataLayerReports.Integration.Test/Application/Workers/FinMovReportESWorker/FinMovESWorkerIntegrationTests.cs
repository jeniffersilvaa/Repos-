using Amazon.S3.Model;
using Hangfire;
using Hangfire.Common;
using Hangfire.Server;
using Hangfire.Storage;
using Microsoft.Extensions.Options;
using NSubstitute;
using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Entities.Models.FinMov;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Infra.DataLayerApi;
using PaymentsDataLayerReports.Application.Infra.DataLayerApi.Models;
using PaymentsDataLayerReports.Application.Infra.MultiPartFileUploader;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Sinks;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.StreamWriters;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Workers.FinMovReportESWorker;
using PaymentsDataLayerReports.Application.Workers.Shared.Modifiers.FinMov;
using PaymentsDataLayerReports.Integration.Test.Helpers;

namespace PaymentsDataLayerReports.Integration.Test.Application.Workers.FinMovReportESWorker;

public class FinMovESWorkerIntegrationTests : IClassFixture<S3LocalStackFixture>, IAsyncLifetime
{
    private readonly S3LocalStackFixture _fixture;
    private readonly IDataLayerApiClient _dataLayerApiClient = Substitute.For<IDataLayerApiClient>();
    private readonly IBackgroundJobClient _backgroundJobClient = Substitute.For<IBackgroundJobClient>();
    private readonly IReportStreamWriterFactory _writerFactory;
    private readonly AwsSettings _awsSettings;
    private readonly PerformContext _performContext;
    private readonly FinMovESWorker _worker;
    private const string TestBucketName = S3LocalStackFixture.TestBucketName;

    public FinMovESWorkerIntegrationTests(S3LocalStackFixture fixture)
    {
        _fixture = fixture;

        _awsSettings = new AwsSettings { WorkgroupBucket = TestBucketName };

        _writerFactory = Substitute.For<IReportStreamWriterFactory>();
        _writerFactory.Create<string>(FileFormatEnum.Csv.Name).Returns(_ => CreateNewCsvWriter());

        _performContext = MockFactory.CreatePerformContext("integration-finmov-job");

        _worker = new FinMovESWorker(_dataLayerApiClient, _writerFactory, _backgroundJobClient, Substitute.For<IS3ClientWrapper>());
    }

    private CsvReportStreamWriter CreateNewCsvWriter()
    {
        var uploader = new S3FileUploader(_fixture.S3Client!);
        var reportOutputSink = new S3MultipartReportSink(uploader);
        return new CsvReportStreamWriter(reportOutputSink, Options.Create(_awsSettings));
    }

    public Task InitializeAsync() => Task.CompletedTask;

    public async Task DisposeAsync()
    {
        await _fixture.CleanupBucketAsync();
    }

    [Fact]
    public async Task ProcessReport_ShouldUploadHeaderAndRowsToS3()
    {
        // Arrange
        var parameters = new FinMovESWorkerParameters
        {
            StartDate = DateOnly.FromDateTime(DateTime.UtcNow.AddDays(-7)),
            EndDate = DateOnly.FromDateTime(DateTime.UtcNow),
            Document = "12345678900"
        };

        var dataset = new List<FinancialMovement>
        {
            CreateMovement("movement-1"),
            CreateMovement("movement-2")
        };

        var response = new GetFinancialMovementsResponseModel
        {
            Data = dataset,
            Cursor = null,
            Size = dataset.Count,
            Total = dataset.Count
        };

        _dataLayerApiClient
            .GetFinancialMovements(Arg.Any<GetFinancialMovementsRequestModel>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(response);

        // Act
        await _worker.ProcessReport(parameters, _performContext, CancellationToken.None);

        // Assert
        var expectedKey = string.Format(S3ReportsConstants.ReportBasePath, _performContext.BackgroundJob.Id, FileFormatEnum.Csv.Name);
        var content = await GetObjectContentAsync(expectedKey);

        Assert.NotNull(content);
        Assert.Contains(ReceivablesModifier.GetHeader().Split(';')[0], content);
        Assert.Contains("movement-1", content);
        Assert.Contains("movement-2", content);
    }

    private async Task<string> GetObjectContentAsync(string key)
    {
        var response = await _fixture.S3Client!.GetObjectAsync(new GetObjectRequest
        {
            BucketName = TestBucketName,
            Key = key
        });

        using var reader = new StreamReader(response.ResponseStream);
        return await reader.ReadToEndAsync();
    }

    private static FinancialMovement CreateMovement(string id)
    {
        var amount = new Amount(1000m, 950m, new FeeModel(50m, null, null, "CET"), new FeeModel(0m, null, null, "CET"), null);
        var merchant = new Merchant("affiliation", "user", "organization", "12345678900", "key", "payment-profile");
        var transaction = new Transaction("product", DateTime.UtcNow.ToString("O"), 1, 1, DateTime.UtcNow.ToString("O"), "op-key", "fund", "VISA", id, "Ecommerce");
        var settlement = new Settlement(new Wallet("wallet", "nature", 1), "2025-01-01", "settlement-key", DateTime.UtcNow.ToString("O"), "paid", null);

        return new FinancialMovement(
            id,
            Guid.NewGuid().ToString(),
            "sale",
            DateTime.UtcNow.ToString("yyyy-MM-dd"),
            DateTime.UtcNow.ToString("yyyy-MM-dd"),
            DateTime.UtcNow.ToString("O"),
            DateTime.UtcNow.ToString("O"),
            amount,
            merchant,
            merchant,
            transaction,
            settlement,
            []
        );
    }
}

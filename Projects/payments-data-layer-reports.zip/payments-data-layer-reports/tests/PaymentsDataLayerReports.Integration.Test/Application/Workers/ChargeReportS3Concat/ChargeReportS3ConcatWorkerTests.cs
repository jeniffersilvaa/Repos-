using Amazon.S3;
using Amazon.S3.Model;
using Hangfire;
using Hangfire.Common;
using Hangfire.Server;
using Hangfire.Storage;
using Microsoft.Extensions.Options;
using NSubstitute;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Infra.MultiPartFileUploader;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Metrics;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Sinks;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.StreamWriters;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Concat;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;
using PaymentsDataLayerReports.Application.Workers.ChargeReportWorker;

namespace PaymentsDataLayerReports.Integration.Test.Application.Workers.ChargeReportS3Concat;

public class ChargeReportS3ConcatWorkerTests(S3LocalStackFixture fixture)
    : IClassFixture<S3LocalStackFixture>
{
    private readonly S3LocalStackFixture _fixture = fixture;
    private IAmazonS3 S3Client => _fixture.S3Client!;
    private const string BucketName = S3LocalStackFixture.TestBucketName;
    private const string TestDataBasePath = "TestData/ChargeReportS3Concat";

    private static AwsSettings CreateAwsSettings() => new()
    {
        WorkgroupBucket = BucketName
    };

    private static PerformContext CreatePerformContext(string jobId)
    {
        var backgroundJob = Substitute.For<BackgroundJob>(jobId, Job.FromExpression(() => Console.WriteLine()), DateTime.UtcNow);
        var performContext = Substitute.For<PerformContext>(
            Substitute.For<IStorageConnection>(),
            backgroundJob,
            Substitute.For<IJobCancellationToken>()
        );

        return performContext;
    }

    private static ReportMetadata CreateBasicMetadata(string reportId, DateTime date)
    {
        return new ReportMetadata
        {
            ReportId = reportId,
            DispatchId = "dispatch-1",
            Status = "Processing",
            CreatedAt = DateTime.UtcNow.AddMinutes(-5),
            ReportSortColumnIndex = 0,
            ProcessorQueueName = "dummy-queue",
            FileFormat = "csv",
            ChargeReportParameters = new ChargeReportsWorkerParameters
            {
                StartDate = date,
                EndDate = date,
                ReportType = "charges_list",
                Organizations = "stone"
            }
        };
    }

    private async Task SetupPartialFilesAsync(string reportId, DateTime date)
    {
        // Header
        var fileFormat = FileFormatEnum.Csv.Name;
        var headerKey = string.Format(S3ReportsConstants.PartialReportHeaderPath, reportId, fileFormat);
        await S3Client.PutObjectAsync(new PutObjectRequest
        {
            BucketName = BucketName,
            Key = headerKey,
            ContentBody = "date,amount"
        });

        // Two partial files for same date
        var partial1Key = string.Format(S3ReportsConstants.PartialReportFilePath, reportId, date, "part-1", fileFormat);
        var partial2Key = string.Format(S3ReportsConstants.PartialReportFilePath, reportId, date, "part-2", fileFormat);

        await S3Client.PutObjectAsync(new PutObjectRequest
        {
            BucketName = BucketName,
            Key = partial1Key,
            ContentBody = "2025-01-02,100\n2025-01-01,50"
        });

        await S3Client.PutObjectAsync(new PutObjectRequest
        {
            BucketName = BucketName,
            Key = partial2Key,
            ContentBody = "2025-01-03,200\n2025-01-01,25"
        });

        // Metadata
        var awsOptions = Options.Create(CreateAwsSettings());
        var metadataService = new S3ReportMetadataHandlerService(S3Client, awsOptions);
        var metadata = CreateBasicMetadata(reportId, date);
        await metadataService.UploadReportMetadataAsync(metadata);
    }

    private static async Task<string?> GetObjectContentAsync(IAmazonS3 s3Client, string bucketName, string key)
    {
        var response = await s3Client.GetObjectAsync(new GetObjectRequest
        {
            BucketName = bucketName,
            Key = key
        });

        using var reader = new StreamReader(response.ResponseStream);
        return await reader.ReadToEndAsync();
    }

    private static ChargeReportS3ConcatWorker CreateWorker(IAmazonS3 s3Client)
    {
        var awsSettings = CreateAwsSettings();
        var awsOptions = Options.Create(awsSettings);
        var mergeService = new S3ReportMergeService(s3Client, awsOptions);
        var metadataService = new S3ReportMetadataHandlerService(s3Client, awsOptions);
        var fileQueryService = new S3ReportFileQueryService(s3Client, awsOptions);

        var s3ClientWrapper = new S3ClientWrapper(
            s3Client,
            awsOptions,
            mergeService,
            metadataService,
            Substitute.For<IS3ReportUploadService>(),
            fileQueryService);

        var recordSource = new S3CsvPartialReportRecordSource(s3Client, awsOptions);
        var mergeEngine = new KWayMergeEngine();
        var uploader = new S3FileUploader(s3Client);
        var sink = new S3MultipartReportSink(uploader);
        var csvWriter = new CsvReportStreamWriter(sink, awsOptions);

        var writerFactory = Substitute.For<IReportStreamWriterFactory>();
        writerFactory.Create<string>(FileFormatEnum.Csv.Name).Returns(csvWriter);

        var metrics = Substitute.For<IReportingTimeMetrics>();
        var concatenationService = new S3ReportConcatenationService(s3Client, awsOptions, recordSource, mergeEngine, writerFactory);
        var backgroundJobClient = Substitute.For<IBackgroundJobClient>();
        var preDeploySettings = Options.Create(new DataLayerReportPreDeploySettings { IsPreDeployWorker = true });

        return new ChargeReportS3ConcatWorker(
            s3ClientWrapper,
            concatenationService,
            metrics,
            preDeploySettings,
            backgroundJobClient);
    }

    [Theory]
    [InlineData("Case01_SingleDate_MultiplePartials")]
    [InlineData("Case02_MultipleDates")]
    [InlineData("Case03_EmptyPartition")]
    [InlineData("Case04_NoData")]
    [InlineData("Case05_SortBySecondColumn")]
    public async Task ConcatReport_FileBasedCases_ShouldMatchExpectedOutput(string testCaseName)
    {
        // Arrange
        var testCase = ConcatReportFileBasedTestHelper.LoadTestCase(TestDataBasePath, testCaseName);

        var awsSettings = CreateAwsSettings();
        await ConcatReportFileBasedTestHelper.SeedS3Async(testCase, S3Client, BucketName, awsSettings, CancellationToken.None);

        var worker = CreateWorker(S3Client);
        var performContext = CreatePerformContext($"concat-job-{testCaseName}");

        // Act
        await worker.ConcatReport(testCase.ReportId, performContext, CancellationToken.None);

        // Assert
        await ConcatReportFileBasedTestHelper.AssertFinalReportMatchesExpectedAsync(testCase, S3Client, BucketName, CancellationToken.None);

        var awsOptions = Options.Create(CreateAwsSettings());
        var metadataService = new S3ReportMetadataHandlerService(S3Client, awsOptions);
        var metadata = await metadataService.GetReportMetadataAsync(testCase.ReportId);

        Assert.NotNull(metadata);
        Assert.Equal("Succeeded", metadata!.Status);
    }

    [Fact]
    public async Task ConcatReport_ShouldGenerateFinalCsvWithExpectedOrder()
    {
        // Arrange
        var reportId = "integration-report-1";
        var concatJobId = "concat-job-1";
        var date = new DateTime(2025, 1, 2);

        await SetupPartialFilesAsync(reportId, date);

        var worker = CreateWorker(S3Client);
        var performContext = CreatePerformContext(concatJobId);

        // Act
        await worker.ConcatReport(reportId, performContext, CancellationToken.None);

        // Assert
        var awsOptions = Options.Create(CreateAwsSettings());
        var metadataService = new S3ReportMetadataHandlerService(S3Client, awsOptions);
        var metadata = await metadataService.GetReportMetadataAsync(reportId);

        var fileFormat = string.IsNullOrWhiteSpace(metadata!.FileFormat)
            ? FileFormatEnum.Csv.Name
            : metadata.FileFormat.ToLowerInvariant();
        var finalKey = string.Format(S3ReportsConstants.ReportBasePath, reportId, fileFormat);
        var content = await GetObjectContentAsync(S3Client, BucketName, finalKey);

        Assert.NotNull(content);
        var lines = content!.Split('\n', StringSplitOptions.RemoveEmptyEntries);

        // Header + 4 data lines
        Assert.Equal(5, lines.Length);
        Assert.Equal("date,amount", lines[0]);

        // Ordered descending by date (SortKey = first column) for different dates
        Assert.Equal("2025-01-03,200", lines[1]);
        Assert.Equal("2025-01-02,100", lines[2]);

        // For the same date (2025-01-01), the merge algorithm does not guarantee
        // a stable order between partial files, so we only guarantee the set
        var lastTwo = new[] { lines[3], lines[4] };
        Assert.Contains("2025-01-01,50", lastTwo);
        Assert.Contains("2025-01-01,25", lastTwo);

        Assert.NotNull(metadata);
        Assert.Equal("Succeeded", metadata!.Status);
    }
}

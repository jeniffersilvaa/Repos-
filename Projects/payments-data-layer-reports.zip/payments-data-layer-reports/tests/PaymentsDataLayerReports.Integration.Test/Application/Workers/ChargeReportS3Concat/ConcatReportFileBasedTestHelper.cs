using System.Text.Json;
using Amazon.S3.Model;
using Microsoft.Extensions.Options;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;

namespace PaymentsDataLayerReports.Integration.Test.Application.Workers.ChargeReportS3Concat;

public static class ConcatReportFileBasedTestHelper
{
    public class ConcatTestCase
    {
        public required string Name { get; init; }
        public required string BasePath { get; init; }
        public required string ReportId { get; init; }
        public required ReportMetadata Metadata { get; init; }
    }

    public static ConcatTestCase LoadTestCase(string testDataBasePath, string testCaseName)
    {
        var testCaseDir = Path.Combine(testDataBasePath, "TestCases", testCaseName);

        if (!Directory.Exists(testCaseDir))
        {
            throw new DirectoryNotFoundException($"Test case directory not found: {testCaseDir}");
        }

        var metadataPath = Path.Combine(testCaseDir, "metadata.json");
        if (!File.Exists(metadataPath))
        {
            throw new FileNotFoundException($"Metadata file not found for test case '{testCaseName}'", metadataPath);
        }

        var metadataJson = File.ReadAllText(metadataPath);
        var metadata = JsonSerializer.Deserialize<ReportMetadata>(metadataJson, new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        }) ?? throw new InvalidOperationException($"Failed to deserialize ReportMetadata for '{testCaseName}'");

        return new ConcatTestCase
        {
            Name = testCaseName,
            BasePath = testCaseDir,
            ReportId = metadata.ReportId,
            Metadata = metadata
        };
    }

    public static async Task SeedS3Async(
        ConcatTestCase testCase,
        Amazon.S3.IAmazonS3 s3Client,
        string bucketName,
        AwsSettings awsSettings,
        CancellationToken cancellationToken = default)
    {
        // 1) Header
        var headerFilePath = Path.Combine(testCase.BasePath, "header.csv");
        if (!File.Exists(headerFilePath))
        {
            throw new FileNotFoundException($"header.csv not found for test case '{testCase.Name}'", headerFilePath);
        }

        var headerContent = await File.ReadAllTextAsync(headerFilePath, cancellationToken);
        var fileFormat = string.IsNullOrWhiteSpace(testCase.Metadata.FileFormat)
            ? FileFormatEnum.Csv.Name
            : testCase.Metadata.FileFormat.ToLowerInvariant();
        var headerKey = string.Format(S3ReportsConstants.PartialReportHeaderPath, testCase.ReportId, fileFormat);

        await s3Client.PutObjectAsync(new PutObjectRequest
        {
            BucketName = bucketName,
            Key = headerKey,
            ContentBody = headerContent
        }, cancellationToken);

        // 2) Partial files
        var partialFiles = Directory.GetFiles(testCase.BasePath, "partial_*.csv");
        foreach (var file in partialFiles)
        {
            var fileName = Path.GetFileNameWithoutExtension(file); // partial_2025-01-02_part1
            var parts = fileName.Split('_');
            if (parts.Length < 3) continue;

            var datePart = parts[1];
            var partitionId = parts[2];

            if (!DateTime.TryParse(datePart, out var date))
            {
                throw new InvalidOperationException($"Invalid date '{datePart}' in file name '{fileName}' for test case '{testCase.Name}'");
            }

            var key = string.Format(S3ReportsConstants.PartialReportFilePath, testCase.ReportId, date, partitionId, fileFormat);
            var body = await File.ReadAllTextAsync(file, cancellationToken);

            // LocalStack 3.0 has a bug when receiving an empty ContentBody (NoneType.to_bytes);
            // Additionally, an empty CSV is equivalent to having no rows for the merge.
            if (string.IsNullOrWhiteSpace(body))
            {
                continue;
            }

            await s3Client.PutObjectAsync(new PutObjectRequest
            {
                BucketName = bucketName,
                Key = key,
                ContentBody = body
            }, cancellationToken);
        }

        // 3) Metadata
        var awsOptions = Options.Create(awsSettings);
        var metadataService = new S3ReportMetadataHandlerService(s3Client, awsOptions);
        await metadataService.UploadReportMetadataAsync(testCase.Metadata);
    }

    public static async Task AssertFinalReportMatchesExpectedAsync(
        ConcatTestCase testCase,
        Amazon.S3.IAmazonS3 s3Client,
        string bucketName,
        CancellationToken cancellationToken = default)
    {
        var fileFormat = string.IsNullOrWhiteSpace(testCase.Metadata.FileFormat)
            ? FileFormatEnum.Csv.Name
            : testCase.Metadata.FileFormat.ToLowerInvariant();
        var finalKey = string.Format(S3ReportsConstants.ReportBasePath, testCase.ReportId, fileFormat);
        var response = await s3Client.GetObjectAsync(new GetObjectRequest
        {
            BucketName = bucketName,
            Key = finalKey
        }, cancellationToken);

        using var reader = new StreamReader(response.ResponseStream);
        var actualContent = await reader.ReadToEndAsync();

        var expectedPath = Path.Combine(testCase.BasePath, "expected.csv");
        if (!File.Exists(expectedPath))
        {
            throw new FileNotFoundException($"expected.csv not found for test case '{testCase.Name}'", expectedPath);
        }

        var actualTempPath = Path.Combine(testCase.BasePath, "actual_temp.csv");
        await File.WriteAllTextAsync(actualTempPath, actualContent, cancellationToken);

        var comparison = CsvComparer.Compare(actualTempPath, expectedPath);
        comparison.AssertSuccess();

        File.Delete(actualTempPath);
    }
}

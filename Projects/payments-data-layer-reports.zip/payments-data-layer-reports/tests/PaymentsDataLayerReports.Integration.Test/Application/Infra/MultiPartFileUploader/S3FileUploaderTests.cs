using Amazon.S3;
using Amazon.S3.Model;
using PaymentsDataLayerReports.Application.Infra.MultiPartFileUploader;

namespace PaymentsDataLayerReports.Integration.Test.Application.Infra.MultiPartFileUploader;

/// <summary>
/// Testes de integração para o S3FileUploader usando LocalStack.
/// Valida o comportamento real do upload multipart para S3,
/// incluindo inicialização, upload de partes, conclusão e cancelamento.
/// 
/// Usa IClassFixture para compartilhar um único container LocalStack entre todos os testes,
/// reduzindo significativamente o tempo de execução.
/// </summary>
public class S3FileUploaderTests(S3LocalStackFixture fixture) : IClassFixture<S3LocalStackFixture>, IAsyncLifetime
{
    private readonly S3LocalStackFixture _fixture = fixture;
    private IAmazonS3 S3Client => _fixture.S3Client!;
    private const string TestBucketName = S3LocalStackFixture.TestBucketName;
    private const string TestFileName = "test-multipart-file.txt";

    public Task InitializeAsync() => Task.CompletedTask;

    public async Task DisposeAsync()
    {
        // Limpa o bucket após cada teste para garantir isolamento
        await _fixture.CleanupBucketAsync();
    }

    private async Task<bool> ObjectExistsAsync(string key)
    {
        try
        {
            await S3Client.GetObjectMetadataAsync(new GetObjectMetadataRequest
            {
                BucketName = TestBucketName,
                Key = key
            });
            return true;
        }
        catch (AmazonS3Exception ex) when (ex.StatusCode == System.Net.HttpStatusCode.NotFound)
        {
            return false;
        }
    }

    private async Task<string?> GetObjectContentAsync(string key)
    {
        var response = await S3Client.GetObjectAsync(new GetObjectRequest
        {
            BucketName = TestBucketName,
            Key = key
        });

        using var reader = new StreamReader(response.ResponseStream);
        return await reader.ReadToEndAsync();
    }

    [Fact]
    public async Task InitiateMultipartUploadAsync_WithValidParameters_ShouldCreateUploadInS3()
    {
        // Arrange
        var uploader = new S3FileUploader(S3Client!);

        // Act
        await uploader.InitiateMultipartUploadAsync(TestFileName, TestBucketName);

        // Assert
        var multipartUploads = await S3Client!.ListMultipartUploadsAsync(new ListMultipartUploadsRequest
        {
            BucketName = TestBucketName
        });

        Assert.Single(multipartUploads.MultipartUploads);
        Assert.Equal(TestFileName, multipartUploads.MultipartUploads[0].Key);
    }

    [Fact]
    public async Task CompleteMultipartUploadAsync_WithSinglePart_ShouldCreateFileInS3()
    {
        // Arrange
        var uploader = new S3FileUploader(S3Client!);
        var testContent = "Test content for multipart upload"u8.ToArray();
        using var partStream = new MemoryStream(testContent);

        // Act
        await uploader.InitiateMultipartUploadAsync(TestFileName, TestBucketName);
        await uploader.UploadPartAsync(partStream, CancellationToken.None);
        var resultUrl = await uploader.CompleteMultipartUploadAsync(CancellationToken.None);

        // Assert
        Assert.Contains(TestFileName, resultUrl);

        var objectExists = await ObjectExistsAsync(TestFileName);
        Assert.True(objectExists, "File should exist in S3 after completion");

        var content = await GetObjectContentAsync(TestFileName);
        Assert.Equal("Test content for multipart upload", content);
    }

    [Fact]
    public async Task CompleteMultipartUploadAsync_WithMultipleParts_ShouldMergePartsInS3()
    {
        // Arrange
        var uploader = new S3FileUploader(S3Client!);

        // S3 requer no mínimo 5MB por parte (exceto a última)
        var part1 = new byte[5 * 1024 * 1024]; // 5MB
        var part2 = new byte[5 * 1024 * 1024]; // 5MB
        var part3 = "Final part content"u8.ToArray();

        new Random(42).NextBytes(part1);
        new Random(43).NextBytes(part2);

        using var partStream1 = new MemoryStream(part1);
        using var partStream2 = new MemoryStream(part2);
        using var partStream3 = new MemoryStream(part3);

        // Act
        await uploader.InitiateMultipartUploadAsync(TestFileName, TestBucketName);
        await uploader.UploadPartAsync(partStream1, CancellationToken.None);
        await uploader.UploadPartAsync(partStream2, CancellationToken.None);
        await uploader.UploadPartAsync(partStream3, CancellationToken.None);
        await uploader.CompleteMultipartUploadAsync(CancellationToken.None);

        // Assert
        var objectExists = await ObjectExistsAsync(TestFileName);
        Assert.True(objectExists, "File should exist in S3 after completion");

        var metadata = await S3Client!.GetObjectMetadataAsync(new GetObjectMetadataRequest
        {
            BucketName = TestBucketName,
            Key = TestFileName
        });

        Assert.Equal(part1.Length + part2.Length + part3.Length, metadata.ContentLength);
    }

    [Fact]
    public async Task AbortMultipartUploadAsync_ShouldCancelUploadAndNotCreateFile()
    {
        // Arrange
        var uploader = new S3FileUploader(S3Client!);
        var testContent = "Test content that will be aborted"u8.ToArray();
        using var partStream = new MemoryStream(testContent);

        // Act
        await uploader.InitiateMultipartUploadAsync(TestFileName, TestBucketName);
        await uploader.UploadPartAsync(partStream, CancellationToken.None);
        await uploader.AbortMultipartUploadAsync(CancellationToken.None);

        // Assert
        var objectExists = await ObjectExistsAsync(TestFileName);
        Assert.False(objectExists, "File should not exist in S3 after abort");

        var multipartUploads = await S3Client!.ListMultipartUploadsAsync(new ListMultipartUploadsRequest
        {
            BucketName = TestBucketName
        });

        Assert.Empty(multipartUploads.MultipartUploads);
    }

    [Fact]
    public async Task CompleteMultipartUploadAsync_AfterCompletion_ShouldAllowNewUpload()
    {
        // Arrange
        var uploader = new S3FileUploader(S3Client!);
        var content1 = "First upload content"u8.ToArray();
        var content2 = "Second upload content"u8.ToArray();

        using var partStream1 = new MemoryStream(content1);
        using var partStream2 = new MemoryStream(content2);

        var fileName1 = "file1.txt";
        var fileName2 = "file2.txt";

        // Act - Primeiro upload
        await uploader.InitiateMultipartUploadAsync(fileName1, TestBucketName);
        await uploader.UploadPartAsync(partStream1, CancellationToken.None);
        await uploader.CompleteMultipartUploadAsync(CancellationToken.None);

        // Act - Segundo upload para verificar reset
        await uploader.InitiateMultipartUploadAsync(fileName2, TestBucketName);
        await uploader.UploadPartAsync(partStream2, CancellationToken.None);
        await uploader.CompleteMultipartUploadAsync(CancellationToken.None);

        // Assert
        var file1Exists = await ObjectExistsAsync(fileName1);
        var file2Exists = await ObjectExistsAsync(fileName2);

        Assert.True(file1Exists, "First file should exist");
        Assert.True(file2Exists, "Second file should exist");

        var content1Result = await GetObjectContentAsync(fileName1);
        var content2Result = await GetObjectContentAsync(fileName2);

        Assert.Equal("First upload content", content1Result);
        Assert.Equal("Second upload content", content2Result);
    }

    [Fact]
    public async Task AbortMultipartUploadAsync_AfterAbort_ShouldAllowNewUpload()
    {
        // Arrange
        var uploader = new S3FileUploader(S3Client!);
        var content1 = "First upload to abort"u8.ToArray();
        var content2 = "Second upload to complete"u8.ToArray();

        using var partStream1 = new MemoryStream(content1);
        using var partStream2 = new MemoryStream(content2);

        var fileName = "test-abort-reset.txt";

        // Act - Primeiro upload abortado
        await uploader.InitiateMultipartUploadAsync(fileName, TestBucketName);
        await uploader.UploadPartAsync(partStream1, CancellationToken.None);
        await uploader.AbortMultipartUploadAsync(CancellationToken.None);

        // Act - Segundo upload completo
        await uploader.InitiateMultipartUploadAsync(fileName, TestBucketName);
        await uploader.UploadPartAsync(partStream2, CancellationToken.None);
        await uploader.CompleteMultipartUploadAsync(CancellationToken.None);

        // Assert
        var fileExists = await ObjectExistsAsync(fileName);
        Assert.True(fileExists, "File should exist after second upload");

        var content = await GetObjectContentAsync(fileName);
        Assert.Equal("Second upload to complete", content);
    }

    [Fact]
    public async Task UploadPartAsync_WithLargeContent_ShouldUploadSuccessfully()
    {
        // Arrange
        var uploader = new S3FileUploader(S3Client!);

        // Cria um conteúdo maior (1MB)
        var largeContent = new byte[1024 * 1024];
        new Random().NextBytes(largeContent);
        using var partStream = new MemoryStream(largeContent);

        // Act
        await uploader.InitiateMultipartUploadAsync(TestFileName, TestBucketName);
        await uploader.UploadPartAsync(partStream, CancellationToken.None);
        await uploader.CompleteMultipartUploadAsync(CancellationToken.None);

        // Assert
        var objectExists = await ObjectExistsAsync(TestFileName);
        Assert.True(objectExists, "Large file should exist in S3");

        var metadata = await S3Client!.GetObjectMetadataAsync(new GetObjectMetadataRequest
        {
            BucketName = TestBucketName,
            Key = TestFileName
        });

        Assert.Equal(largeContent.Length, metadata.ContentLength);
    }

    [Fact]
    public async Task CompleteMultipartUploadAsync_WithSmallPart_ShouldCreateSmallFile()
    {
        // Arrange
        var uploader = new S3FileUploader(S3Client!);
        // LocalStack tem problemas com partes vazias, então usamos uma parte muito pequena
        var smallContent = "x"u8.ToArray();
        using var smallStream = new MemoryStream(smallContent);

        // Act
        await uploader.InitiateMultipartUploadAsync(TestFileName, TestBucketName);
        await uploader.UploadPartAsync(smallStream, CancellationToken.None);
        await uploader.CompleteMultipartUploadAsync(CancellationToken.None);

        // Assert
        var objectExists = await ObjectExistsAsync(TestFileName);
        Assert.True(objectExists, "Small file should exist in S3");

        var content = await GetObjectContentAsync(TestFileName);
        Assert.Equal("x", content);
    }

    [Fact]
    public async Task UploadPartAsync_WithCancellationToken_ShouldRespectCancellation()
    {
        // Arrange
        var uploader = new S3FileUploader(S3Client!);
        var testContent = "Test content"u8.ToArray();
        using var partStream = new MemoryStream(testContent);
        using var cts = new CancellationTokenSource();

        await uploader.InitiateMultipartUploadAsync(TestFileName, TestBucketName);

        // Act
        cts.Cancel();

        // Assert - TaskCanceledException herda de OperationCanceledException
        await Assert.ThrowsAnyAsync<OperationCanceledException>(async () =>
            await uploader.UploadPartAsync(partStream, cts.Token));
    }

    [Fact]
    public async Task CompleteMultipartUploadAsync_WithCancellationToken_ShouldRespectCancellation()
    {
        // Arrange
        var uploader = new S3FileUploader(S3Client!);
        var testContent = "Test content"u8.ToArray();
        using var partStream = new MemoryStream(testContent);
        using var cts = new CancellationTokenSource();

        await uploader.InitiateMultipartUploadAsync(TestFileName, TestBucketName);
        await uploader.UploadPartAsync(partStream, CancellationToken.None);

        // Act
        cts.Cancel();

        // Assert - TaskCanceledException herda de OperationCanceledException
        await Assert.ThrowsAnyAsync<OperationCanceledException>(async () =>
            await uploader.CompleteMultipartUploadAsync(cts.Token));
    }

    [Fact]
    public async Task MultipleUploads_InParallel_ShouldNotInterfereWithEachOther()
    {
        // Arrange
        var uploader1 = new S3FileUploader(S3Client!);
        var uploader2 = new S3FileUploader(S3Client!);

        var content1 = "Content for file 1"u8.ToArray();
        var content2 = "Content for file 2"u8.ToArray();

        using var stream1 = new MemoryStream(content1);
        using var stream2 = new MemoryStream(content2);

        var file1 = "parallel-file-1.txt";
        var file2 = "parallel-file-2.txt";

        // Act
        await Task.WhenAll(
            Task.Run(async () =>
            {
                await uploader1.InitiateMultipartUploadAsync(file1, TestBucketName);
                await uploader1.UploadPartAsync(stream1, CancellationToken.None);
                await uploader1.CompleteMultipartUploadAsync(CancellationToken.None);
            }),
            Task.Run(async () =>
            {
                await uploader2.InitiateMultipartUploadAsync(file2, TestBucketName);
                await uploader2.UploadPartAsync(stream2, CancellationToken.None);
                await uploader2.CompleteMultipartUploadAsync(CancellationToken.None);
            })
        );

        // Assert
        var file1Exists = await ObjectExistsAsync(file1);
        var file2Exists = await ObjectExistsAsync(file2);

        Assert.True(file1Exists, "File 1 should exist");
        Assert.True(file2Exists, "File 2 should exist");

        var content1Result = await GetObjectContentAsync(file1);
        var content2Result = await GetObjectContentAsync(file2);

        Assert.Equal("Content for file 1", content1Result);
        Assert.Equal("Content for file 2", content2Result);
    }
}

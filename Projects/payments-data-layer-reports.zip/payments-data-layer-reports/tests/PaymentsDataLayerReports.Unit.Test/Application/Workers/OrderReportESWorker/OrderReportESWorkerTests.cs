using Hangfire;
using Hangfire.Server;
using NSubstitute;
using NSubstitute.ExceptionExtensions;
using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Entities.Models.Order;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Infra.DataLayerApi;
using PaymentsDataLayerReports.Application.Infra.DataLayerApi.Models;
using PaymentsDataLayerReports.Application.Routes.Reports.PostReports.Models;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Interfaces;
using NotificationWorkerV2Type = PaymentsDataLayerReports.Application.Workers.NotificationWorkerV2.NotificationWorkerV2;
using OrderAddress = PaymentsDataLayerReports.Application.Entities.Models.Order.Address;
using OrderCharge = PaymentsDataLayerReports.Application.Entities.Models.Order.Charge;
using OrderCustomer = PaymentsDataLayerReports.Application.Entities.Models.Order.Customer;
using OrderReportWorker = PaymentsDataLayerReports.Application.Workers.OrderReportESWorker;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.OrderReportESWorker;

public class OrderReportESWorkerTests
{
    private readonly IDataLayerApiClient _dataLayerApiClient;
    private readonly IReportStreamWriter<string> _reportStreamWriter;
    private readonly IReportStreamWriterFactory _writerFactory;
    private readonly IBackgroundJobClient _backgroundJobClient;
    private readonly OrderReportWorker.OrderReportESWorker _worker;
    private readonly PerformContext _performContext;
    private readonly CancellationToken _cancellationToken;

    public OrderReportESWorkerTests()
    {
        _dataLayerApiClient = Substitute.For<IDataLayerApiClient>();
        _reportStreamWriter = Substitute.For<IReportStreamWriter<string>>();
        _writerFactory = Substitute.For<IReportStreamWriterFactory>();
        _backgroundJobClient = Substitute.For<IBackgroundJobClient>();

        _writerFactory.Create<string>(Arg.Any<string>()).Returns(_reportStreamWriter);

        _worker = new OrderReportWorker.OrderReportESWorker(
            _dataLayerApiClient,
            _writerFactory,
            _backgroundJobClient
        );

        _performContext = MockFactory.CreatePerformContext("test-job-id");
        _cancellationToken = CancellationToken.None;
    }

    #region Helper Methods

    private static Order CreateTestOrder(string orderId)
    {
        var address = new OrderAddress(
            Id: "address-1",
            Street: "Test Street",
            Neighborhood: "Test Neighborhood",
            Number: "123",
            City: "Test City",
            State: "TS",
            Country: "BR",
            ZipCode: "12345-678"
        );

        var phones = new Phones
        {
            HomePhone = new Phone("11", "55", "22334455"),
            MobilePhone = new Phone("11", "55", "987654321")
        };

        var customer = new OrderCustomer(
            Name: "Test Customer",
            Email: "test@example.com",
            Document: "12345678900",
            Type: "individual",
            Id: "customer-1",
            Address: address,
            Phones: phones
        );

        return new Order(
            Amount: 10000,
            Charges:
            [
                new OrderCharge(Id: "charge-1")
            ],
            Code: "ORD-001",
            Customer: customer,
            Device: new Device(Platform: "web"),
            Shipping: new Shipping(
                Amount: 1000,
                Description: "Standard Shipping",
                RecipientName: "Test Recipient",
                RecipientPhone: "11987654321",
                Address: new OrderAddress(
                    Id: "address-2",
                    Street: "Test Street",
                    Neighborhood: "Test Neighborhood",
                    Number: "123",
                    City: "Test City",
                    State: "TS",
                    Country: "BR",
                    ZipCode: "12345-678"
                )
            ),
            Status: "paid",
            Id: orderId,
            Metadata: [],
            CreatedAt: DateTime.UtcNow.AddDays(-1),
            UpdatedAt: DateTime.UtcNow,
            ClosedAt: DateTime.UtcNow,
            CheckoutsCount: 1
        );
    }

    #endregion

    #region Success Scenarios

    [Fact]
    public async Task ProcessReport_WithValidParameters_ShouldCompleteSuccessfully()
    {
        // Arrange
        var parameters = new OrderReportWorker.OrderReportWorkerParameters
        {
            StartDueDate = DateTime.UtcNow.AddDays(-1),
            EndDueDate = DateTime.UtcNow,
            Documents = "12345678900",
            FileFormat = "csv",
            Notification = new Notification { Email = new EmailNotification { Address = "test@example.com" } }
        };

        var orders = new List<Order>
        {
            CreateTestOrder("order-1"),
            CreateTestOrder("order-2")
        };

        var cursorResult = new GetDataByCursorResponseModel<Order>
        {
            Data = orders,
            Cursor = null
        };

        _dataLayerApiClient
            .GetDataByCursor<Order>(
                Arg.Is("orders"),
                Arg.Any<IGetDataByCursorRequestModel>(),
                Arg.Any<string>(),
                Arg.Any<CancellationToken>()
            )
            .Returns(cursorResult);

        // Act
        await _worker.ProcessReport(parameters, _performContext, _cancellationToken);

        // Assert
        _writerFactory.Received(1).Create<string>(FileFormatEnum.Csv.Name);
        await _reportStreamWriter.Received(1).InitializeAsync("test-job-id", _cancellationToken);
        await _reportStreamWriter.Received(1).WriteHeaderAsync(Arg.Any<string>(), _cancellationToken);
        await _reportStreamWriter.Received(2).WriteRecordAsync(Arg.Any<string>(), _cancellationToken);
        await _reportStreamWriter.Received(1).CompleteAsync(_cancellationToken);
        await _reportStreamWriter.DidNotReceive().AbortAsync(Arg.Any<CancellationToken>());

        await _dataLayerApiClient.Received(1).GetDataByCursor<Order>(
            Arg.Is("orders"),
            Arg.Is<IGetDataByCursorRequestModel>(r => r.FilterParameters!["documents"] == "12345678900"),
            Arg.Is("test-job-id"),
            Arg.Any<CancellationToken>()
        );
    }

    [Fact]
    public async Task ProcessReport_WithMultipleBatches_ShouldProcessAllData()
    {
        // Arrange
        var parameters = new OrderReportWorker.OrderReportWorkerParameters
        {
            StartDueDate = DateTime.UtcNow.AddDays(-1),
            EndDueDate = DateTime.UtcNow,
            FileFormat = "csv",
            Notification = new Notification { Email = new EmailNotification { Address = "test@example.com" } }
        };

        var firstBatch = new GetDataByCursorResponseModel<Order>
        {
            Data = [CreateTestOrder("order-1")],
            Cursor = "cursor-1"
        };

        var secondBatch = new GetDataByCursorResponseModel<Order>
        {
            Data = [CreateTestOrder("order-2")],
            Cursor = "cursor-2"
        };

        var thirdBatch = new GetDataByCursorResponseModel<Order>
        {
            Data = [CreateTestOrder("order-3")],
            Cursor = null
        };

        _dataLayerApiClient
            .GetDataByCursor<Order>(
                Arg.Is("orders"),
                Arg.Is<IGetDataByCursorRequestModel>(r => r.Cursor == null),
                Arg.Any<string>(),
                Arg.Any<CancellationToken>()
            )
            .Returns(firstBatch);

        _dataLayerApiClient
            .GetDataByCursor<Order>(
                Arg.Is("orders"),
                Arg.Is<IGetDataByCursorRequestModel>(r => r.Cursor == "cursor-1"),
                Arg.Any<string>(),
                Arg.Any<CancellationToken>()
            )
            .Returns(secondBatch);

        _dataLayerApiClient
            .GetDataByCursor<Order>(
                Arg.Is("orders"),
                Arg.Is<IGetDataByCursorRequestModel>(r => r.Cursor == "cursor-2"),
                Arg.Any<string>(),
                Arg.Any<CancellationToken>()
            )
            .Returns(thirdBatch);

        // Act
        await _worker.ProcessReport(parameters, _performContext, _cancellationToken);

        // Assert
        await _dataLayerApiClient.Received(3).GetDataByCursor<Order>(
            Arg.Is("orders"),
            Arg.Any<IGetDataByCursorRequestModel>(),
            Arg.Any<string>(),
            Arg.Any<CancellationToken>()
        );

        await _reportStreamWriter.Received(3).WriteRecordAsync(Arg.Any<string>(), _cancellationToken);
        await _reportStreamWriter.Received(1).CompleteAsync(_cancellationToken);
    }

    [Fact]
    public async Task ProcessReport_WithAllOptionalParameters_ShouldIncludeAllFilters()
    {
        // Arrange
        var parameters = new OrderReportWorker.OrderReportWorkerParameters
        {
            IsTestAccount = true,
            StartDueDate = DateTime.UtcNow.AddDays(-1),
            EndDueDate = DateTime.UtcNow,
            Status = "paid",
            Documents = "12345678900",
            StoneAccounts = "stone-123",
            PaymentProfiles = "profile-1",
            FileFormat = "csv",
            Notification = new Notification { Email = new EmailNotification { Address = "test@example.com" } }
        };

        var cursorResult = new GetDataByCursorResponseModel<Order>
        {
            Data = [],
            Cursor = null
        };

        GetOrderByCursorRequestModel? capturedRequest = null;

        _dataLayerApiClient
            .GetDataByCursor<Order>(
                Arg.Any<string>(),
                Arg.Do<IGetDataByCursorRequestModel>(r => capturedRequest = r as GetOrderByCursorRequestModel),
                Arg.Any<string>(),
                Arg.Any<CancellationToken>()
            )
            .Returns(cursorResult);

        // Act
        await _worker.ProcessReport(parameters, _performContext, _cancellationToken);

        // Assert
        Assert.NotNull(capturedRequest);
        Assert.Equal(parameters.IsTestAccount.ToString(), capturedRequest.FilterParameters!["is_test_account"]);
        Assert.Equal(parameters.StartDueDate.ToString("o"), capturedRequest.FilterParameters!["start_date"]);
        Assert.Equal(parameters.EndDueDate.ToString("o"), capturedRequest.FilterParameters!["end_date"]);
        Assert.Equal(parameters.Status, capturedRequest.FilterParameters!["settlement_status"]);
        Assert.Equal(parameters.Documents, capturedRequest.FilterParameters!["documents"]);
        Assert.Equal(parameters.StoneAccounts, capturedRequest.FilterParameters!["stone_accounts"]);
        Assert.Equal(parameters.PaymentProfiles, capturedRequest.FilterParameters!["payment_profile_ids"]);
    }

    [Fact]
    public async Task ProcessReport_WithEmptyResult_ShouldCompleteSuccessfully()
    {
        // Arrange
        var parameters = new OrderReportWorker.OrderReportWorkerParameters
        {
            StartDueDate = DateTime.UtcNow.AddDays(-1),
            EndDueDate = DateTime.UtcNow,
            FileFormat = "csv",
            Notification = new Notification { Email = new EmailNotification { Address = "test@example.com" } }
        };

        var cursorResult = new GetDataByCursorResponseModel<Order>
        {
            Data = [],
            Cursor = null
        };

        _dataLayerApiClient
            .GetDataByCursor<Order>(
                Arg.Any<string>(),
                Arg.Any<IGetDataByCursorRequestModel>(),
                Arg.Any<string>(),
                Arg.Any<CancellationToken>()
            )
            .Returns(cursorResult);

        // Act
        await _worker.ProcessReport(parameters, _performContext, _cancellationToken);

        // Assert
        await _reportStreamWriter.Received(1).InitializeAsync("test-job-id", _cancellationToken);
        await _reportStreamWriter.Received(1).WriteHeaderAsync(Arg.Any<string>(), _cancellationToken);
        await _reportStreamWriter.Received(1).CompleteAsync(_cancellationToken);
        await _reportStreamWriter.DidNotReceive().WriteRecordAsync(Arg.Any<string>(), _cancellationToken);
    }

    #endregion

    #region Error Scenarios

    [Fact]
    public async Task ProcessReport_WhenDataLayerApiThrowsException_ShouldAbortWriterAndThrow()
    {
        // Arrange
        var parameters = new OrderReportWorker.OrderReportWorkerParameters
        {
            StartDueDate = DateTime.UtcNow.AddDays(-1),
            EndDueDate = DateTime.UtcNow,
            FileFormat = "csv",
            Notification = new Notification { Email = new EmailNotification { Address = "test@example.com" } }
        };

        var expectedException = new Exception("DataLayer API Error");

        _dataLayerApiClient
            .GetDataByCursor<Order>(
                Arg.Any<string>(),
                Arg.Any<GetOrderByCursorRequestModel>(),
                Arg.Any<string>(),
                Arg.Any<CancellationToken>()
            )
            .Throws(expectedException);

        // Act & Assert
        var exception = await Assert.ThrowsAsync<Exception>(
            async () => await _worker.ProcessReport(parameters, _performContext, _cancellationToken)
        );

        Assert.Equal("DataLayer API Error", exception.Message);

        await _reportStreamWriter.Received(1).AbortAsync(Arg.Any<CancellationToken>());
        await _reportStreamWriter.DidNotReceive().CompleteAsync(Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task ProcessReport_WhenWriterThrowsException_ShouldAbortWriterAndThrow()
    {
        // Arrange
        var parameters = new OrderReportWorker.OrderReportWorkerParameters
        {
            StartDueDate = DateTime.UtcNow.AddDays(-1),
            EndDueDate = DateTime.UtcNow,
            FileFormat = "csv",
            Notification = new Notification { Email = new EmailNotification { Address = "test@example.com" } }
        };

        var orders = new List<Order> { CreateTestOrder("order-1") };

        var cursorResult = new GetDataByCursorResponseModel<Order>
        {
            Data = orders,
            Cursor = null
        };

        var expectedException = new Exception("Writer Error");

        _dataLayerApiClient
            .GetDataByCursor<Order>(
                Arg.Any<string>(),
                Arg.Any<GetOrderByCursorRequestModel>(),
                Arg.Any<string>(),
                Arg.Any<CancellationToken>()
            )
            .Returns(cursorResult);

        _reportStreamWriter
            .WriteRecordAsync(Arg.Any<string>(), Arg.Any<CancellationToken>())
            .ThrowsAsync(expectedException);

        // Act & Assert
        var exception = await Assert.ThrowsAsync<Exception>(
            async () => await _worker.ProcessReport(parameters, _performContext, _cancellationToken)
        );

        Assert.Equal("Writer Error", exception.Message);

        await _reportStreamWriter.Received(1).AbortAsync(Arg.Any<CancellationToken>());
        await _reportStreamWriter.DidNotReceive().CompleteAsync(Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task ProcessReport_WhenInitializeThrowsException_ShouldAbortWriterAndThrow()
    {
        // Arrange
        var parameters = new OrderReportWorker.OrderReportWorkerParameters
        {
            StartDueDate = DateTime.UtcNow.AddDays(-1),
            EndDueDate = DateTime.UtcNow,
            FileFormat = "csv",
            Notification = new Notification { Email = new EmailNotification { Address = "test@example.com" } }
        };

        var expectedException = new Exception("Initialize Error");

        _reportStreamWriter
            .InitializeAsync(Arg.Any<string>(), Arg.Any<CancellationToken>())
            .ThrowsAsync(expectedException);

        // Act & Assert
        var exception = await Assert.ThrowsAsync<Exception>(
            async () => await _worker.ProcessReport(parameters, _performContext, _cancellationToken)
        );

        Assert.Equal("Initialize Error", exception.Message);

        await _reportStreamWriter.Received(1).AbortAsync(Arg.Any<CancellationToken>());
        await _dataLayerApiClient.DidNotReceive().GetDataByCursor<Order>(
            Arg.Any<string>(),
            Arg.Any<IGetDataByCursorRequestModel>(),
            Arg.Any<string>(),
            Arg.Any<CancellationToken>()
        );
    }

    #endregion
}

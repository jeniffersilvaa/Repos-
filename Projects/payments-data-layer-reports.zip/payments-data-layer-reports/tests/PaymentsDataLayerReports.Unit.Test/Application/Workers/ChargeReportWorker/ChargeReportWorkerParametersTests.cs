using PaymentsDataLayerReports.Application.Workers.ChargeReportWorker;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.ChargeReportWorker;

public class ChargeReportWorkerParametersTests
{
    private static ChargeReportsWorkerParameters CreateBasicParameters() => new()
    {
        StartDate = new DateTimeOffset(2025, 1, 1, 0, 0, 0, TimeSpan.Zero),
        EndDate = new DateTimeOffset(2025, 1, 31, 23, 59, 59, TimeSpan.Zero),
        Document = "12345678901",
        MerchantId = "merchant-1",
        AccountId = "account-1",
        AffiliationCodes = "code1,code2",
        Organizations = "stone,ton",
        PaymentMethods = "boleto,card,pix",
        ReportType = "charges_list"
    };

    [Fact]
    public void ToGetChargesRequestModel_ShouldMapBasicFields()
    {
        // Arrange
        var parameters = CreateBasicParameters();

        // Act
        var result = parameters.ToGetChargesRequestModel();

        // Assert
        Assert.Equal(1000, result.Size);
        Assert.Equal(parameters.StartDate, result.StartCreationDate);
        Assert.Equal(parameters.EndDate, result.EndCreationDate);
        Assert.Equal("12345678901", result.Document);
        Assert.Equal("merchant-1", result.MerchantId);
        Assert.Equal("account-1", result.AccountId);
        Assert.Equal("code1,code2", result.AffiliationCodes);
        Assert.Equal("stone,ton", result.Organizations);
        Assert.Equal("boleto,card,pix", result.PaymentMethods);
    }

    [Fact]
    public void ToGetChargesRequestModel_ShouldAlwaysSetWithFullAmountsTrue()
    {
        // Arrange
        var parameters = CreateBasicParameters();

        // Act
        var result = parameters.ToGetChargesRequestModel();

        // Assert
        Assert.True(result.WithFullAmounts);
    }

    [Fact]
    public void ToGetChargesRequestModel_ShouldAlwaysSetDalarRequestTrue()
    {
        // Arrange
        var parameters = CreateBasicParameters();

        // Act
        var result = parameters.ToGetChargesRequestModel();

        // Assert
        Assert.True(result.DalarRequest);
    }

    [Fact]
    public void ToGetChargesRequestModel_ShouldAlwaysSetSizeTo1000()
    {
        // Arrange
        var parameters = CreateBasicParameters();

        // Act
        var result = parameters.ToGetChargesRequestModel();

        // Assert
        Assert.Equal(1000, result.Size);
    }

    [Fact]
    public void ToGetChargesRequestModel_ShouldMapStoneAccounts()
    {
        // Arrange
        var parameters = CreateBasicParameters() with { StoneAccounts = "sa1,sa2" };

        // Act
        var result = parameters.ToGetChargesRequestModel();

        // Assert
        Assert.Equal("sa1,sa2", result.StoneAccounts);
    }

    [Fact]
    public void ToGetChargesRequestModel_ShouldMapPaymentProfiles()
    {
        // Arrange
        var parameters = CreateBasicParameters() with { PaymentProfiles = "pp1,pp2" };

        // Act
        var result = parameters.ToGetChargesRequestModel();

        // Assert
        Assert.Equal("pp1,pp2", result.PaymentProfiles);
    }

    [Fact]
    public void ToGetChargesRequestModel_ShouldMapPoiTypes()
    {
        // Arrange
        var parameters = CreateBasicParameters() with { PoiTypes = "pos,ecommerce" };

        // Act
        var result = parameters.ToGetChargesRequestModel();

        // Assert
        Assert.Equal("pos,ecommerce", result.PoiTypes);
    }

    [Fact]
    public void ToGetChargesRequestModel_ShouldMapAllNewFields()
    {
        // Arrange
        var parameters = CreateBasicParameters() with
        {
            StoneAccounts = "sa1,sa2",
            PaymentProfiles = "pp1,pp2",
            PoiTypes = "pos,ecommerce"
        };

        // Act
        var result = parameters.ToGetChargesRequestModel();

        // Assert
        Assert.Equal("sa1,sa2", result.StoneAccounts);
        Assert.Equal("pp1,pp2", result.PaymentProfiles);
        Assert.Equal("pos,ecommerce", result.PoiTypes);
    }

    [Fact]
    public void ToGetChargesRequestModel_WithNullNewFields_ShouldReturnNullForNewFields()
    {
        // Arrange
        var parameters = CreateBasicParameters();

        // Act
        var result = parameters.ToGetChargesRequestModel();

        // Assert
        Assert.Null(result.StoneAccounts);
        Assert.Null(result.PaymentProfiles);
        Assert.Null(result.PoiTypes);
    }

    [Fact]
    public void ToGetChargesRequestModel_ShouldMapOptionalFields()
    {
        // Arrange
        var paidAt = new DateTime(2025, 1, 15, 12, 0, 0, DateTimeKind.Utc);
        var parameters = CreateBasicParameters() with
        {
            AllIds = "id1,id2",
            Customers = "cust1",
            Acquirers = "acq1",
            BankNames = "bank1",
            CardBrands = "visa,mastercard",
            PaidAt = paidAt,
            FundingSources = "prepaid",
            PlatformName = "platform1",
            Status = "paid",
            AntifraudStatus = "approved",
            LastOperationStatus = "captured",
            LastLegacyStatus = "active",
            MinAmount = 100,
            MaxAmount = 5000,
            WithFailed = true,
            IsSandbox = true
        };

        // Act
        var result = parameters.ToGetChargesRequestModel();

        // Assert
        Assert.Equal("id1,id2", result.AllIds);
        Assert.Equal("cust1", result.Customers);
        Assert.Equal("acq1", result.Acquirers);
        Assert.Equal("bank1", result.BankNames);
        Assert.Equal("visa,mastercard", result.CardBrands);
        Assert.Equal(paidAt, result.PaidAt);
        Assert.Equal("prepaid", result.FundingSources);
        Assert.Equal("platform1", result.PlatformNames);
        Assert.Equal("paid", result.Status);
        Assert.Equal("approved", result.AntifraudStatus);
        Assert.Equal("captured", result.LastOperationStatus);
        Assert.Equal("active", result.LastLegacyStatus);
        Assert.Equal(100, result.MinAmount);
        Assert.Equal(5000, result.MaxAmount);
        Assert.True(result.WithFailed);
        Assert.True(result.IsSandbox);
    }

    [Fact]
    public void ToGetChargesRequestModel_WithAllNullOptionalFields_ShouldNotThrow()
    {
        // Arrange
        var parameters = new ChargeReportsWorkerParameters
        {
            StartDate = new DateTimeOffset(2025, 1, 1, 0, 0, 0, TimeSpan.Zero),
            EndDate = new DateTimeOffset(2025, 1, 31, 23, 59, 59, TimeSpan.Zero),
            Organizations = string.Empty,
            Document = null,
            AccountId = null,
            MerchantId = null
        };

        // Act
        var result = parameters.ToGetChargesRequestModel();

        // Assert
        Assert.Null(result.Document);
        Assert.Null(result.MerchantId);
        Assert.Null(result.AccountId);
        Assert.Null(result.AffiliationCodes);
        Assert.Null(result.AllIds);
        Assert.Null(result.Customers);
        Assert.Null(result.Acquirers);
        Assert.Null(result.BankNames);
        Assert.Null(result.CardBrands);
        Assert.Null(result.PaidAt);
        Assert.Null(result.FundingSources);
        Assert.Null(result.PlatformNames);
        Assert.Null(result.Status);
        Assert.Null(result.AntifraudStatus);
        Assert.Null(result.LastOperationStatus);
        Assert.Null(result.LastLegacyStatus);
        Assert.Null(result.MinAmount);
        Assert.Null(result.MaxAmount);
        Assert.Null(result.WithFailed);
        Assert.Null(result.StoneAccounts);
        Assert.Null(result.PaymentProfiles);
        Assert.Null(result.PoiTypes);
    }
}

using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Entities.Models.FinMov;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.FinMovList;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;
using PaymentsDataLayerReports.Application.Workers.Shared.Modifiers.FinMov;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.Shared.Modifiers.FinMov;

public class ReceivablesModifierTests
{
    #region BuildRow(FinancialMovement) - Turbo Anticipation

    [Fact]
    public void BuildRow_FinancialMovement_WithTurboFee_ShouldSumPrepaymentAndTurbo()
    {
        var amount = new Amount(
            Gross: 10000m,
            Net: 9500m,
            DiscountRate: new FeeModel(Amount: -200m, Fee: 1.5m, EffectiveFee: 1.5m, FeeType: "mdr"),
            PrepaymentFee: new FeeModel(Amount: -150m, Fee: 0.5m, EffectiveFee: 0.5m, FeeType: "rav"),
            PrepaymentFeeTurbo: new FeeModel(Amount: -100m, Fee: 2.0m, EffectiveFee: 2.0m, FeeType: "turbo")
        );
        var fm = CreateFinancialMovement("sale", amount);

        var row = ReceivablesModifier.BuildRow(fm);
        var columns = row.Split(';');

        // DESCONTO DE ANTECIPAÇÃO (col 14) = prepayment (-150) + turbo (-100) = -250
        Assert.Equal("-250,000000", columns[14]);
    }

    [Fact]
    public void BuildRow_FinancialMovement_WithCetAndTurbo_ShouldShowOnlyTurbo()
    {
        var amount = new Amount(
            Gross: 10000m,
            Net: 9500m,
            DiscountRate: new FeeModel(Amount: -200m, Fee: 1.5m, EffectiveFee: 1.5m, FeeType: "CET"),
            PrepaymentFee: new FeeModel(Amount: -150m, Fee: 0.5m, EffectiveFee: 0.5m, FeeType: "CET"),
            PrepaymentFeeTurbo: new FeeModel(Amount: -100m, Fee: 2.0m, EffectiveFee: 2.0m, FeeType: "turbo")
        );
        var fm = CreateFinancialMovement("sale", amount);

        var row = ReceivablesModifier.BuildRow(fm);
        var columns = row.Split(';');

        // Regular prepayment is CET → 0, turbo → -100. Total = -100
        Assert.Equal("-100,000000", columns[14]);
    }

    [Fact]
    public void BuildRow_FinancialMovement_WithChargeback_ShouldZeroBoth()
    {
        var amount = new Amount(
            Gross: 10000m,
            Net: 9500m,
            DiscountRate: new FeeModel(Amount: -200m, Fee: 1.5m, EffectiveFee: 1.5m, FeeType: "mdr"),
            PrepaymentFee: new FeeModel(Amount: -150m, Fee: 0.5m, EffectiveFee: 0.5m, FeeType: "rav"),
            PrepaymentFeeTurbo: new FeeModel(Amount: -100m, Fee: 2.0m, EffectiveFee: 2.0m, FeeType: "turbo")
        );
        var fm = CreateFinancialMovement("chargeback", amount);

        var row = ReceivablesModifier.BuildRow(fm);
        var columns = row.Split(';');

        // Both zeroed on chargeback
        Assert.Equal("0,000000", columns[14]);
    }

    [Fact]
    public void BuildRow_FinancialMovement_WithoutTurbo_ShouldPreserveExistingBehavior()
    {
        var amount = new Amount(
            Gross: 10000m,
            Net: 9700m,
            DiscountRate: new FeeModel(Amount: -200m, Fee: 1.5m, EffectiveFee: 1.5m, FeeType: "mdr"),
            PrepaymentFee: new FeeModel(Amount: -100m, Fee: 0.5m, EffectiveFee: 0.5m, FeeType: "rav"),
            PrepaymentFeeTurbo: null
        );
        var fm = CreateFinancialMovement("sale", amount);

        var row = ReceivablesModifier.BuildRow(fm);
        var columns = row.Split(';');

        // Only regular prepayment
        Assert.Equal("-100,000000", columns[14]);
    }

    #endregion

    #region BuildRow(CsvRow) - Turbo Anticipation

    [Fact]
    public void BuildRow_CsvRow_WithTurboFee_ShouldSumPrepaymentAndTurbo()
    {
        var csvRow = CreateCsvRow(
            prepaymentFeeAmount: -150m,
            prepaymentFeeFeeType: "rav",
            turboAmount: -100m,
            turboFeeType: "turbo"
        );

        var row = ReceivablesModifier.BuildRow(csvRow);
        var columns = row.Split(';');

        // DESCONTO DE ANTECIPAÇÃO (col 14) = -150 + -100 = -250
        Assert.Equal("-250,000000", columns[14]);
    }

    [Fact]
    public void BuildRow_CsvRow_WithoutTurbo_ShouldPreserveExistingBehavior()
    {
        var csvRow = CreateCsvRow(
            prepaymentFeeAmount: -100m,
            prepaymentFeeFeeType: "rav",
            turboAmount: null,
            turboFeeType: null
        );

        var row = ReceivablesModifier.BuildRow(csvRow);
        var columns = row.Split(';');

        Assert.Equal("-100,000000", columns[14]);
    }

    [Fact]
    public void BuildRow_CsvRow_WithCetAndTurbo_ShouldShowOnlyTurbo()
    {
        var csvRow = CreateCsvRow(
            prepaymentFeeAmount: -150m,
            prepaymentFeeFeeType: "CET",
            turboAmount: -100m,
            turboFeeType: "turbo"
        );

        var row = ReceivablesModifier.BuildRow(csvRow);
        var columns = row.Split(';');

        // Regular CET → 0, turbo → -100. Total = -100
        Assert.Equal("-100,000000", columns[14]);
    }

    #endregion

    #region Helpers

    private static FinancialMovement CreateFinancialMovement(string operation, Amount amount)
    {
        var merchant = new Merchant("AFF001", "user-001", "Org", "12345678000199", "key", "PP001");
        var transaction = new Transaction(
            "credit", DateTime.UtcNow.ToString("O"), 1, 1,
            DateTime.UtcNow.ToString("O"), "op-key", "credit", "VISA", "stone-key-001", "Ecommerce");
        var settlement = new Settlement(
            new Wallet("credit_card", "credit", 1), "2025-01-01",
            "settlement-key", null, "paid", null);

        return new FinancialMovement(
            "fm-001", "op-001", operation,
            "2025-06-15", "2025-06-20",
            DateTime.UtcNow.ToString("O"), DateTime.UtcNow.ToString("O"),
            amount, merchant, merchant, transaction, settlement, []);
    }

    private static CsvRow CreateCsvRow(
        decimal? prepaymentFeeAmount,
        string? prepaymentFeeFeeType,
        decimal? turboAmount,
        string? turboFeeType)
    {
        var headerIndex = FinMovListReportHeader.HeaderIndex;
        var csvRow = new CsvRow(FinMovListReportHeader.DefaultValues);

        csvRow.SetField(headerIndex["operation"], "sale");
        csvRow.SetField(headerIndex["current_due_date"], "2025-06-20");
        csvRow.SetField(headerIndex["original_due_date"], "2025-06-15");
        csvRow.SetField(headerIndex["payment_owner__document"], "12345678000199");
        csvRow.SetField(headerIndex["payment_owner__affiliation_code"], "AFF001");
        csvRow.SetField(headerIndex["transaction__capture_date"], "2025-06-10T10:00:00Z");
        csvRow.SetField(headerIndex["transaction__brand"], "VISA");
        csvRow.SetField(headerIndex["transaction__key"], "stone-key-001");
        csvRow.SetField(headerIndex["transaction__installment_number"], 1);
        csvRow.SetField(headerIndex["transaction__installment_quantity"], 1);
        csvRow.SetField(headerIndex["amount__gross"], 10000m);
        csvRow.SetField(headerIndex["amount__net"], 9500m);
        csvRow.SetField(headerIndex["amount__discount_rate__amount"], -200m);
        csvRow.SetField(headerIndex["amount__discount_rate__fee_type"], "mdr");
        csvRow.SetField(headerIndex["settlement__status"], "paid");

        if (prepaymentFeeAmount.HasValue)
            csvRow.SetField(headerIndex["amount__prepayment_fee__amount"], prepaymentFeeAmount.Value);
        if (prepaymentFeeFeeType != null)
            csvRow.SetField(headerIndex["amount__prepayment_fee__fee_type"], prepaymentFeeFeeType);

        if (turboAmount.HasValue)
            csvRow.SetField(headerIndex["amount__prepayment_fee_turbo__amount"], turboAmount.Value);
        if (turboFeeType != null)
            csvRow.SetField(headerIndex["amount__prepayment_fee_turbo__fee_type"], turboFeeType);

        return csvRow;
    }

    #endregion
}

using System.Text.Json;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Workers.Shared;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.Shared;

public class CsvRowBuilderTests
{
    #region Constructor and Default Behavior

    [Fact]
    public void Constructor_WithNoArguments_ShouldDefaultToCommaSeparator()
    {
        // Arrange & Act
        var builder = new CsvRowBuilder();
        builder.Add("value1").Add("value2");
        var result = builder.Build();

        // Assert
        Assert.Equal("\"value1\",\"value2\"", result);
    }

    [Fact]
    public void Constructor_WithCommaSeparator_ShouldUseComma()
    {
        // Arrange & Act
        var builder = new CsvRowBuilder(CsvSeparatorEnum.Comma);
        builder.Add("value1").Add("value2");
        var result = builder.Build();

        // Assert
        Assert.Equal("\"value1\",\"value2\"", result);
    }

    [Fact]
    public void Constructor_WithSemicolonSeparator_ShouldUseSemicolon()
    {
        // Arrange & Act
        var builder = new CsvRowBuilder(CsvSeparatorEnum.Semicolon);
        builder.Add("value1").Add("value2");
        var result = builder.Build();

        // Assert
        Assert.Equal("value1;value2", result);
    }

    #endregion

    #region Add String Values

    [Fact]
    public void Add_WithNullString_ShouldAppendEmptyField()
    {
        // Arrange
        var builder = new CsvRowBuilder();

        // Act
        builder.Add((string?)null);
        var result = builder.Build();

        // Assert
        Assert.Equal("", result);
    }

    [Fact]
    public void Add_WithEmptyString_ShouldAppendEmptyField()
    {
        // Arrange
        var builder = new CsvRowBuilder();

        // Act
        builder.Add("");
        var result = builder.Build();

        // Assert
        Assert.Equal("", result);
    }

    [Fact]
    public void Add_WithSimpleString_ShouldWrapInQuotesForCommaSeparator()
    {
        // Arrange
        var builder = new CsvRowBuilder(CsvSeparatorEnum.Comma);

        // Act
        builder.Add("simple");
        var result = builder.Build();

        // Assert
        Assert.Equal("\"simple\"", result);
    }

    [Fact]
    public void Add_WithSimpleString_ShouldNotWrapInQuotesForSemicolonSeparator()
    {
        // Arrange
        var builder = new CsvRowBuilder(CsvSeparatorEnum.Semicolon);

        // Act
        builder.Add("simple");
        var result = builder.Build();

        // Assert
        Assert.Equal("simple", result);
    }

    [Fact]
    public void Add_WithStringContainingQuotes_ShouldEscapeQuotesForCommaSeparator()
    {
        // Arrange
        var builder = new CsvRowBuilder(CsvSeparatorEnum.Comma);

        // Act
        builder.Add("value with \"quotes\"");
        var result = builder.Build();

        // Assert
        Assert.Equal("\"value with \"\"quotes\"\"\"", result);
    }

    [Fact]
    public void Add_WithStringContainingQuotes_ShouldNotEscapeForSemicolonSeparator()
    {
        // Arrange
        var builder = new CsvRowBuilder(CsvSeparatorEnum.Semicolon);

        // Act
        builder.Add("value with \"quotes\"");
        var result = builder.Build();

        // Assert
        Assert.Equal("value with \"quotes\"", result);
    }

    [Fact]
    public void Add_WithStringContainingComma_ShouldWrapInQuotesForCommaSeparator()
    {
        // Arrange
        var builder = new CsvRowBuilder(CsvSeparatorEnum.Comma);

        // Act
        builder.Add("value, with comma");
        var result = builder.Build();

        // Assert
        Assert.Equal("\"value, with comma\"", result);
    }

    [Fact]
    public void Add_WithStringContainingSemicolon_ShouldNotEscapeForSemicolonSeparator()
    {
        // Arrange
        var builder = new CsvRowBuilder(CsvSeparatorEnum.Semicolon);

        // Act
        builder.Add("value; with semicolon");
        var result = builder.Build();

        // Assert
        Assert.Equal("value; with semicolon", result);
    }

    #endregion

    #region Add Generic Values

    [Fact]
    public void AddGeneric_WithIntValue_ShouldConvertToString()
    {
        // Arrange
        var builder = new CsvRowBuilder(CsvSeparatorEnum.Comma);

        // Act
        builder.Add(123);
        var result = builder.Build();

        // Assert
        Assert.Equal("\"123\"", result);
    }

    [Fact]
    public void AddGeneric_WithDecimalValue_ShouldConvertToString()
    {
        // Arrange
        var builder = new CsvRowBuilder(CsvSeparatorEnum.Comma);

        // Act
        builder.Add(123.45m);
        var result = builder.Build();

        // Assert
        Assert.Equal("\"123.45\"", result);
    }

    [Fact]
    public void AddGeneric_WithBoolValue_ShouldConvertToString()
    {
        // Arrange
        var builder = new CsvRowBuilder(CsvSeparatorEnum.Comma);

        // Act
        builder.Add(true);
        var result = builder.Build();

        // Assert
        Assert.Equal("\"True\"", result);
    }

    [Fact]
    public void AddGeneric_WithNullValue_ShouldAppendEmptyField()
    {
        // Arrange
        var builder = new CsvRowBuilder(CsvSeparatorEnum.Comma);

        // Act
        builder.Add<int?>(null);
        var result = builder.Build();

        // Assert
        Assert.Equal("", result);
    }

    [Fact]
    public void AddGeneric_WithNullValueAndDefaultValue_ShouldUseDefaultValue()
    {
        // Arrange
        var builder = new CsvRowBuilder(CsvSeparatorEnum.Comma);

        // Act
        builder.Add<int?>(null, "N/A");
        var result = builder.Build();

        // Assert
        Assert.Equal("\"N/A\"", result);
    }

    [Fact]
    public void AddGeneric_WithValueAndDefaultValue_ShouldUseActualValue()
    {
        // Arrange
        var builder = new CsvRowBuilder(CsvSeparatorEnum.Comma);

        // Act
        builder.Add(42, "N/A");
        var result = builder.Build();

        // Assert
        Assert.Equal("\"42\"", result);
    }

    #endregion

    #region AddDateTimeOffset

    [Fact]
    public void AddDateTimeOffset_WithNullValue_ShouldAppendEmptyField()
    {
        // Arrange
        var builder = new CsvRowBuilder(CsvSeparatorEnum.Comma);

        // Act
        builder.AddDateTimeOffset(null, "yyyy-MM-dd");
        var result = builder.Build();

        // Assert
        Assert.Equal("", result);
    }

    [Fact]
    public void AddDateTimeOffset_WithValue_ShouldFormatWithDefaultFormat()
    {
        // Arrange
        var builder = new CsvRowBuilder(CsvSeparatorEnum.Comma);
        var dateTime = new DateTimeOffset(2025, 12, 9, 14, 30, 45, 123, TimeSpan.FromHours(-3));

        // Act
        builder.AddDateTimeOffset(dateTime);
        var result = builder.Build();

        // Assert
        Assert.Equal("\"2025-12-09T14:30:45.123000-03:00\"", result);
    }

    [Fact]
    public void AddDateTimeOffset_WithValueAndCustomFormat_ShouldUseCustomFormat()
    {
        // Arrange
        var builder = new CsvRowBuilder(CsvSeparatorEnum.Comma);
        var dateTime = new DateTimeOffset(2025, 12, 9, 14, 30, 45, TimeSpan.Zero);

        // Act
        builder.AddDateTimeOffset(dateTime, "yyyy-MM-dd");
        var result = builder.Build();

        // Assert
        Assert.Equal("\"2025-12-09\"", result);
    }

    [Fact]
    public void AddDateTimeOffset_WithSemicolonSeparator_ShouldNotWrapInQuotes()
    {
        // Arrange
        var builder = new CsvRowBuilder(CsvSeparatorEnum.Semicolon);
        var dateTime = new DateTimeOffset(2025, 12, 9, 14, 30, 45, TimeSpan.Zero);

        // Act
        builder.AddDateTimeOffset(dateTime, "yyyy-MM-dd");
        var result = builder.Build();

        // Assert
        Assert.Equal("2025-12-09", result);
    }

    #endregion

    #region AddSerializableObject

    [Fact]
    public void AddSerializableObject_WithNullValue_ShouldAppendEmptyField()
    {
        // Arrange
        var builder = new CsvRowBuilder(CsvSeparatorEnum.Comma);

        // Act
        builder.AddSerializableObject(null);
        var result = builder.Build();

        // Assert
        Assert.Equal("", result);
    }

    [Fact]
    public void AddSerializableObject_WithSimpleObject_ShouldSerializeToJson()
    {
        // Arrange
        var builder = new CsvRowBuilder(CsvSeparatorEnum.Comma);
        var obj = new { Name = "Test", Value = 123 };

        // Act
        builder.AddSerializableObject(obj);
        var result = builder.Build();

        // Assert
        // JSON contains quotes which should be escaped
        Assert.Equal("\"{\"\"Name\"\":\"\"Test\"\",\"\"Value\"\":123}\"", result);
    }

    [Fact]
    public void AddSerializableObject_WithCustomOptions_ShouldUseOptions()
    {
        // Arrange
        var builder = new CsvRowBuilder(CsvSeparatorEnum.Comma);
        var obj = new { PropertyName = "Test" };
        var options = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        };

        // Act
        builder.AddSerializableObject(obj, options);
        var result = builder.Build();

        // Assert
        Assert.Equal("\"{\"\"propertyName\"\":\"\"Test\"\"}\"", result);
    }

    [Fact]
    public void AddSerializableObject_WithSemicolonSeparator_ShouldNotWrapInQuotes()
    {
        // Arrange
        var builder = new CsvRowBuilder(CsvSeparatorEnum.Semicolon);
        var obj = new { Name = "Test" };

        // Act
        builder.AddSerializableObject(obj);
        var result = builder.Build();

        // Assert
        Assert.Equal("{\"Name\":\"Test\"}", result);
    }

    #endregion

    #region Multiple Fields

    [Fact]
    public void Build_WithMultipleFields_ShouldJoinWithCommaSeparator()
    {
        // Arrange
        var builder = new CsvRowBuilder(CsvSeparatorEnum.Comma);

        // Act
        builder.Add("field1").Add("field2").Add("field3");
        var result = builder.Build();

        // Assert
        Assert.Equal("\"field1\",\"field2\",\"field3\"", result);
    }

    [Fact]
    public void Build_WithMultipleFields_ShouldJoinWithSemicolonSeparator()
    {
        // Arrange
        var builder = new CsvRowBuilder(CsvSeparatorEnum.Semicolon);

        // Act
        builder.Add("field1").Add("field2").Add("field3");
        var result = builder.Build();

        // Assert
        Assert.Equal("field1;field2;field3", result);
    }

    [Fact]
    public void Build_WithMixedNullAndValues_ShouldHandleCorrectly()
    {
        // Arrange
        var builder = new CsvRowBuilder(CsvSeparatorEnum.Comma);

        // Act
        builder.Add("first").Add((string?)null).Add("third");
        var result = builder.Build();

        // Assert
        Assert.Equal("\"first\",,\"third\"", result);
    }

    [Fact]
    public void Build_WithMixedTypes_ShouldHandleCorrectly()
    {
        // Arrange
        var builder = new CsvRowBuilder(CsvSeparatorEnum.Comma);
        var dateTime = new DateTimeOffset(2025, 12, 9, 0, 0, 0, TimeSpan.Zero);

        // Act
        builder
            .Add("text")
            .Add(123)
            .AddDateTimeOffset(dateTime, "yyyy-MM-dd")
            .AddSerializableObject(new { Key = "value" });
        var result = builder.Build();

        // Assert
        Assert.Equal("\"text\",\"123\",\"2025-12-09\",\"{\"\"Key\"\":\"\"value\"\"}\"", result);
    }

    #endregion

    #region Fluent Interface

    [Fact]
    public void Add_ShouldReturnSameBuilderInstance()
    {
        // Arrange
        var builder = new CsvRowBuilder();

        // Act
        var returnedBuilder = builder.Add("test");

        // Assert
        Assert.Same(builder, returnedBuilder);
    }

    [Fact]
    public void AddGeneric_ShouldReturnSameBuilderInstance()
    {
        // Arrange
        var builder = new CsvRowBuilder();

        // Act
        var returnedBuilder = builder.Add(123);

        // Assert
        Assert.Same(builder, returnedBuilder);
    }

    [Fact]
    public void AddDateTimeOffset_ShouldReturnSameBuilderInstance()
    {
        // Arrange
        var builder = new CsvRowBuilder();

        // Act
        var returnedBuilder = builder.AddDateTimeOffset(DateTimeOffset.Now, "yyyy-MM-dd");

        // Assert
        Assert.Same(builder, returnedBuilder);
    }

    [Fact]
    public void AddSerializableObject_ShouldReturnSameBuilderInstance()
    {
        // Arrange
        var builder = new CsvRowBuilder();

        // Act
        var returnedBuilder = builder.AddSerializableObject(new { });

        // Assert
        Assert.Same(builder, returnedBuilder);
    }

    #endregion

    #region Edge Cases

    [Fact]
    public void Build_WithNoFields_ShouldReturnEmptyString()
    {
        // Arrange
        var builder = new CsvRowBuilder();

        // Act
        var result = builder.Build();

        // Assert
        Assert.Equal("", result);
    }

    [Fact]
    public void Add_WithMultipleQuotes_ShouldEscapeAllQuotes()
    {
        // Arrange
        var builder = new CsvRowBuilder(CsvSeparatorEnum.Comma);

        // Act
        builder.Add("\"\"\"");
        var result = builder.Build();

        // Assert
        Assert.Equal("\"\"\"\"\"\"\"\"", result);
    }

    [Fact]
    public void Add_WithNewlineCharacter_ShouldPreserveNewline()
    {
        // Arrange
        var builder = new CsvRowBuilder(CsvSeparatorEnum.Comma);

        // Act
        builder.Add("line1\nline2");
        var result = builder.Build();

        // Assert
        Assert.Equal("\"line1\nline2\"", result);
    }

    [Fact]
    public void Build_WithOnlyNullFields_ShouldReturnSeparatorsOnly()
    {
        // Arrange
        var builder = new CsvRowBuilder(CsvSeparatorEnum.Comma);

        // Act
        builder.Add((string?)null).Add((string?)null).Add((string?)null);
        var result = builder.Build();

        // Assert
        Assert.Equal(",,", result);
    }

    #endregion
}

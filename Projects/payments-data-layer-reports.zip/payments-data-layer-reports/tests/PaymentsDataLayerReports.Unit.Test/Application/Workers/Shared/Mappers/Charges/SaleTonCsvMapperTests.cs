using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Workers.Shared.Mappers.Charges;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.Shared.Mappers.Charges;

public class SaleTonCsvMapperTests
{
    private readonly SaleTonCsvMapper _mapper = new();

    #region GetHeader

    [Fact]
    public void GetHeader_ShouldReturnExpectedColumns()
    {
        var header = _mapper.GetHeader();

        var columns = header.Split(';');
        Assert.Equal(15, columns.Length);
        Assert.Equal("Id da transação", columns[0]);
        Assert.Equal("Data da transação", columns[1]);
        Assert.Equal("Valor", columns[2]);
        Assert.Equal("Taxa", columns[3]);
        Assert.Equal("Desconto", columns[4]);
        Assert.Equal("Valor recebido", columns[5]);
        Assert.Equal("Status", columns[6]);
        Assert.Equal("Nome do titular", columns[7]);
        Assert.Equal("Bandeira", columns[8]);
        Assert.Equal("Método de pagamento", columns[9]);
        Assert.Equal("Parcelas", columns[10]);
        Assert.Equal("Cartão(últimos 4 dígitos)", columns[11]);
        Assert.Equal("Método de captura", columns[12]);
        Assert.Equal("Tipo de cartão", columns[13]);
        Assert.Equal("Nº de série", columns[14]);
    }

    #endregion

    #region CreatedAtColumnPosition

    [Fact]
    public void CreatedAtColumnPosition_ShouldReturnTwo()
    {
        Assert.Equal(2, _mapper.CreatedAtColumnPosition);
    }

    #endregion

    #region BuildRow - Payment Method Routing

    [Fact]
    public void BuildRow_WithCardPaymentMethod_ShouldReturnNonEmptyRow()
    {
        var charge = ChargeTestFactory.CreateCardCharge();

        var row = _mapper.BuildRow(charge);

        Assert.NotEmpty(row);
        var columns = row!.Split(';');
        Assert.Equal(15, columns.Length);
    }

    [Fact]
    public void BuildRow_WithPixPaymentMethod_ShouldReturnNonEmptyRow()
    {
        var charge = ChargeTestFactory.CreatePixCharge();

        var row = _mapper.BuildRow(charge);

        Assert.NotEmpty(row);
        var columns = row!.Split(';');
        Assert.Equal(15, columns.Length);
    }

    [Fact]
    public void BuildRow_WithBoletoPaymentMethod_ShouldReturnNull()
    {
        var charge = ChargeTestFactory.CreateBoletoCharge();

        var row = _mapper.BuildRow(charge);

        Assert.Null(row);
    }

    [Fact]
    public void BuildRow_WithUnsupportedPaymentMethod_ShouldThrowNotSupportedException()
    {
        var charge = ChargeTestFactory.CreateUnsupportedCharge();

        Assert.Throws<NotSupportedException>(() => _mapper.BuildRow(charge));
    }

    #endregion

    #region BuildRowCard

    [Fact]
    public void BuildRowCard_ShouldFormatAmountWithCurrencyPrefix()
    {
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(feeAmount: 500);
        var charge = ChargeTestFactory.CreateCardCharge(amount: 10000, cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        // amount = 10000/100 = 100 → "R$ 100,00"
        Assert.Equal("R$ 100,00", columns[2]);
    }

    [Fact]
    public void BuildRowCard_ShouldCalculatePercentageFeeCorrectly()
    {
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(feeAmount: 500);
        var charge = ChargeTestFactory.CreateCardCharge(amount: 10000, cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        // amount = 100, discount = 5, fee = |5|/|100| * 100 = 5.00 → "5.00%" (pt-BR)
        Assert.Equal("5.00%", columns[3]);
    }

    [Fact]
    public void BuildRowCard_ShouldCalculateDiscountWithCurrencyPrefix()
    {
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(feeAmount: 500);
        var charge = ChargeTestFactory.CreateCardCharge(amount: 10000, cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        // discount = 500/100 = 5 → "R$ 5,00"
        Assert.Equal("R$ 5,00", columns[4]);
    }

    [Fact]
    public void BuildRowCard_ShouldCalculateNetAmountCorrectly()
    {
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(feeAmount: 500);
        var charge = ChargeTestFactory.CreateCardCharge(amount: 10000, cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        // netAmount = 100 - 5 = 95 → "R$ 95,00"
        Assert.Equal("R$ 95,00", columns[5]);
    }

    [Fact]
    public void BuildRowCard_ShouldMapStatusViaSaleDomainMapper()
    {
        var charge = ChargeTestFactory.CreateCardCharge(status: "paid");

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        Assert.Equal("Paga", columns[6]);
    }

    [Theory]
    [InlineData("processing", "Processando")]
    [InlineData("authorized", "Autorizada")]
    [InlineData("paid", "Paga")]
    [InlineData("refunded", "Estornada")]
    [InlineData("canceled", "Cancelada")]
    public void BuildRowCard_ShouldMapVariousStatuses(string status, string expected)
    {
        var charge = ChargeTestFactory.CreateCardCharge(status: status);

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        Assert.Equal(expected, columns[6]);
    }

    [Fact]
    public void BuildRowCard_ShouldIncludeHolderName()
    {
        var card = ChargeTestFactory.CreateCard(holderName: "MARIA SANTOS");
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(card: card);
        var charge = ChargeTestFactory.CreateCardCharge(cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        Assert.Equal("MARIA SANTOS", columns[7]);
    }

    [Fact]
    public void BuildRowCard_ShouldIncludeCardBrand()
    {
        var card = ChargeTestFactory.CreateCard(brand: "Mastercard");
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(card: card);
        var charge = ChargeTestFactory.CreateCardCharge(cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        Assert.Equal("Mastercard", columns[8]);
    }

    [Fact]
    public void BuildRowCard_ShouldMapCardProduct()
    {
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(type: "credit");
        var charge = ChargeTestFactory.CreateCardCharge(cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        Assert.Equal("Cartão de Crédito", columns[9]);
    }

    [Theory]
    [InlineData("credit", "Cartão de Crédito")]
    [InlineData("debit", "Cartão de Débito")]
    [InlineData("voucher", "Voucher")]
    public void BuildRowCard_ShouldMapCardProductVariations(string cardType, string expected)
    {
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(type: cardType);
        var charge = ChargeTestFactory.CreateCardCharge(cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        Assert.Equal(expected, columns[9]);
    }

    [Fact]
    public void BuildRowCard_ShouldShowInstallmentCount()
    {
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(installments: 6);
        var charge = ChargeTestFactory.CreateCardCharge(cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        Assert.Equal("6", columns[10]);
    }

    [Fact]
    public void BuildRowCard_ShouldShowLastFourDigitsOnly()
    {
        var card = ChargeTestFactory.CreateCard(lastFourDigits: "9876");
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(card: card);
        var charge = ChargeTestFactory.CreateCardCharge(cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        Assert.Equal("9876", columns[11]);
    }

    [Fact]
    public void BuildRowCard_ShouldMapCardEntryMode()
    {
        var card = ChargeTestFactory.CreateCard(entryMode: "emv");
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(card: card);
        var charge = ChargeTestFactory.CreateCardCharge(cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        Assert.Equal("Cartão inserido na maquininha", columns[12]);
    }

    [Theory]
    [InlineData("emv_contactless", "Cartão por aproximação")]
    [InlineData("emv", "Cartão inserido na maquininha")]
    [InlineData("magstripe", "Tarja magnética")]
    [InlineData("tap_phone", "Transações com Tap")]
    public void BuildRowCard_ShouldMapEntryModeVariations(string entryMode, string expected)
    {
        var card = ChargeTestFactory.CreateCard(entryMode: entryMode);
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(card: card);
        var charge = ChargeTestFactory.CreateCardCharge(cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        Assert.Equal(expected, columns[12]);
    }

    [Fact]
    public void BuildRowCard_ShouldMapTransactionType()
    {
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(fundingSource: "credit");
        var charge = ChargeTestFactory.CreateCardCharge(cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        Assert.Equal("Crédito", columns[13]);
    }

    [Theory]
    [InlineData("credit", "Crédito")]
    [InlineData("debit", "Débito")]
    [InlineData("prepaid", "Pré-pago")]
    public void BuildRowCard_ShouldMapTransactionTypeVariations(string fundingSource, string expected)
    {
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(fundingSource: fundingSource);
        var charge = ChargeTestFactory.CreateCardCharge(cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        Assert.Equal(expected, columns[13]);
    }

    [Fact]
    public void BuildRowCard_ShouldIncludeSerialNumber()
    {
        var terminal = ChargeTestFactory.CreateCardTerminal(serialNumber: "SN-TON-001");
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(terminal: terminal);
        var charge = ChargeTestFactory.CreateCardCharge(cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        Assert.Equal("SN-TON-001", columns[14]);
    }

    [Fact]
    public void BuildRowCard_ShouldIncludeTransactionId()
    {
        var charge = ChargeTestFactory.CreateCardCharge();

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        Assert.Equal("charge-card-001", columns[0]);
    }

    [Fact]
    public void BuildRowCard_ShouldFormatCreatedAtInBrazilianTimezone()
    {
        // UTC 15:30 → São Paulo (UTC-3) = 12:30
        var createdAt = new DateTimeOffset(2025, 6, 15, 15, 30, 0, TimeSpan.Zero);
        var charge = ChargeTestFactory.CreateCardCharge(createdAt: createdAt);

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        Assert.Equal("15/06/2025 12:30", columns[1]);
    }

    #endregion

    #region BuildRowPix

    [Fact]
    public void BuildRowPix_ShouldFormatAmountWithCurrencyPrefix()
    {
        var pixTransaction = ChargeTestFactory.CreatePixTransaction(paidAmount: 5000, feeAmount: 100);
        var charge = ChargeTestFactory.CreatePixCharge(pixTransaction: pixTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        // amount = 5000/100 = 50 → "R$ 50,00"
        Assert.Equal("R$ 50,00", columns[2]);
    }

    [Fact]
    public void BuildRowPix_ShouldCalculateNetAmountCorrectly()
    {
        var pixTransaction = ChargeTestFactory.CreatePixTransaction(paidAmount: 5000, feeAmount: 100);
        var charge = ChargeTestFactory.CreatePixCharge(pixTransaction: pixTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        // amount = 50, discount = 1, netAmount = 50 - 1 = 49 → "R$ 49,00"
        Assert.Equal("R$ 49,00", columns[5]);
    }

    [Fact]
    public void BuildRowPix_ShouldSetPayerNameFromPixTransaction()
    {
        var payer = ChargeTestFactory.CreatePayer(name: "Carlos Souza");
        var pixTransaction = ChargeTestFactory.CreatePixTransaction(payer: payer);
        var charge = ChargeTestFactory.CreatePixCharge(pixTransaction: pixTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        Assert.Equal("Carlos Souza", columns[7]);
    }

    [Fact]
    public void BuildRowPix_ShouldSetBandeiraAsEmpty()
    {
        var charge = ChargeTestFactory.CreatePixCharge();

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        Assert.Empty(columns[8]);
    }

    [Fact]
    public void BuildRowPix_ShouldSetMetodoDePagamentoAsPix()
    {
        var charge = ChargeTestFactory.CreatePixCharge();

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        Assert.Equal("Pix", columns[9]);
    }

    [Fact]
    public void BuildRowPix_ShouldSetParcelsAndLastFourDigitsAsEmpty()
    {
        var charge = ChargeTestFactory.CreatePixCharge();

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        Assert.Empty(columns[10]);
        Assert.Empty(columns[11]);
    }

    [Fact]
    public void BuildRowPix_ShouldMapEntryModeFromTerminalType()
    {
        var terminal = ChargeTestFactory.CreatePixTerminal(type: "standalone_device");
        var pixTransaction = ChargeTestFactory.CreatePixTransaction(terminal: terminal);
        var charge = ChargeTestFactory.CreatePixCharge(pixTransaction: pixTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        // standalone_device is not in the MapCardEntryMode switch → "Outros"
        Assert.Equal("Outros", columns[12]);
    }

    [Fact]
    public void BuildRowPix_ShouldMapPixTransactionType()
    {
        var pixTransaction = ChargeTestFactory.CreatePixTransaction(type: "dynamic");
        var charge = ChargeTestFactory.CreatePixCharge(pixTransaction: pixTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        Assert.Equal("Pix QRcode", columns[13]);
    }

    [Theory]
    [InlineData("dynamic", "Pix QRcode")]
    [InlineData("static", "Pix QRcode")]
    [InlineData("sale_transfer", "Transferência por PIX")]
    public void BuildRowPix_ShouldMapPixTransactionTypeVariations(string pixType, string expected)
    {
        var pixTransaction = ChargeTestFactory.CreatePixTransaction(type: pixType);
        var charge = ChargeTestFactory.CreatePixCharge(pixTransaction: pixTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        Assert.Equal(expected, columns[13]);
    }

    [Fact]
    public void BuildRowPix_ShouldIncludeSerialNumber()
    {
        var terminal = ChargeTestFactory.CreatePixTerminal(serialNumber: "SN-PIX-TON");
        var pixTransaction = ChargeTestFactory.CreatePixTransaction(terminal: terminal);
        var charge = ChargeTestFactory.CreatePixCharge(pixTransaction: pixTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        Assert.Equal("SN-PIX-TON", columns[14]);
    }

    [Fact]
    public void BuildRowPix_ShouldIncludeChargeId()
    {
        var charge = ChargeTestFactory.CreatePixCharge();

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        Assert.Equal("charge-pix-001", columns[0]);
    }

    [Fact]
    public void BuildRowPix_ShouldMapStatusViaSaleDomainMapper()
    {
        var charge = ChargeTestFactory.CreatePixCharge(status: "paid");

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        Assert.Equal("Paga", columns[6]);
    }

    [Fact]
    public void BuildRowPix_ShouldCalculatePercentageFeeCorrectly()
    {
        var pixTransaction = ChargeTestFactory.CreatePixTransaction(paidAmount: 10000, feeAmount: 250);
        var charge = ChargeTestFactory.CreatePixCharge(pixTransaction: pixTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        // amount = 100, discount = 2.5, fee = 2.5/100 * 100 = 2.50 → "2,50%" (pt-BR)
        Assert.Equal("2.50%", columns[3]);
    }

    #endregion

    #region BuildRowCard - FeeAmount already includes turbo

    [Fact]
    public void BuildRowCard_WithTurboInFeeAmount_ShouldUseOnlyFeeAmount()
    {
        // FeeAmount already includes turbo (aligned with ES setFeeAmounts)
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(feeAmount: 750);
        var charge = ChargeTestFactory.CreateCardCharge(amount: 10000, cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        // discount = FeeAmount/100 = 750/100 = 7.50
        Assert.Equal("R$ 7,50", columns[4]);
    }

    [Fact]
    public void BuildRowCard_WithTurboInFeeAmount_ShouldCalculateNetAmount()
    {
        // FeeAmount already includes turbo (aligned with ES setFeeAmounts)
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(feeAmount: 750);
        var charge = ChargeTestFactory.CreateCardCharge(amount: 10000, cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row!.Split(';');

        // amount = 100, discount = 7.50, netAmount = 100 - 7.50 = 92.50
        Assert.Equal("R$ 92,50", columns[5]);
    }

    #endregion
}

using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Entities.Models.Charge;
using PaymentsDataLayerReports.Application.Workers.Shared.Mappers.Charges;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.Shared.Mappers.Charges;

public class SaleStoneCsvMapperTests
{
    private readonly SaleStoneCsvMapper _mapper = new();

    #region GetHeader

    [Fact]
    public void GetHeader_ShouldReturnExpectedColumns()
    {
        var header = _mapper.GetHeader();

        var columns = header.Split(';');
        Assert.Equal(17, columns.Length);
        Assert.Equal("DOCUMENTO", columns[0]);
        Assert.Equal("STONECODE", columns[1]);
        Assert.Equal("DATA DA VENDA", columns[2]);
        Assert.Equal("BANDEIRA", columns[3]);
        Assert.Equal("PRODUTO", columns[4]);
        Assert.Equal("STONE ID", columns[5]);
        Assert.Equal("N DE PARCELAS", columns[6]);
        Assert.Equal("VALOR BRUTO", columns[7]);
        Assert.Equal("VALOR LIQUIDO", columns[8]);
        Assert.Equal("DESCONTO DE MDR", columns[9]);
        Assert.Equal("DESCONTO DE ANTECIPACAO", columns[10]);
        Assert.Equal("DESCONTO UNIFICADO", columns[11]);
        Assert.Equal("N DO CARTAO", columns[12]);
        Assert.Equal("MEIO DE CAPTURA", columns[13]);
        Assert.Equal("N DE SERIE", columns[14]);
        Assert.Equal("ULTIMO STATUS", columns[15]);
        Assert.Equal("DATA DO ULTIMO STATUS", columns[16]);
    }

    #endregion

    #region CreatedAtColumnPosition

    [Fact]
    public void CreatedAtColumnPosition_ShouldReturnThree()
    {
        Assert.Equal(3, _mapper.CreatedAtColumnPosition);
    }

    #endregion

    #region BuildRow - Payment Method Routing

    [Fact]
    public void BuildRow_WithCardPaymentMethod_ShouldReturnNonEmptyRow()
    {
        var charge = ChargeTestFactory.CreateCardCharge();

        var row = _mapper.BuildRow(charge);

        Assert.NotEmpty(row);
        var columns = row.Split(';');
        Assert.Equal(17, columns.Length);
    }

    [Fact]
    public void BuildRow_WithPixPaymentMethod_ShouldReturnNonEmptyRow()
    {
        var charge = ChargeTestFactory.CreatePixCharge();

        var row = _mapper.BuildRow(charge);

        Assert.NotEmpty(row);
        var columns = row.Split(';');
        Assert.Equal(17, columns.Length);
    }

    [Fact]
    public void BuildRow_WithBoletoPaymentMethod_ShouldReturnNonEmptyRow()
    {
        var charge = ChargeTestFactory.CreateBoletoCharge();

        var row = _mapper.BuildRow(charge);

        Assert.NotEmpty(row);
        var columns = row.Split(';');
        Assert.Equal(17, columns.Length);
    }

    [Fact]
    public void BuildRow_WithUnsupportedPaymentMethod_ShouldThrowNotSupportedException()
    {
        var charge = ChargeTestFactory.CreateUnsupportedCharge();

        Assert.Throws<NotSupportedException>(() => _mapper.BuildRow(charge));
    }

    #endregion

    #region BuildRowCard - Without CET

    [Fact]
    public void BuildRowCard_WithoutCet_ShouldCalculateDiscountsFromAggregatedFields()
    {
        _mapper.IsCetEnabled = false;
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(
            fullMdrAmount: 300m,
            fullMdrRefundAmount: 0m,
            fullRavAmount: 200m,
            fullRavRefundAmount: 0m,
            chargebackAmount: 0,
            chargebackRefundAmount: 0,
            canceledAmount: 0
        );
        var charge = ChargeTestFactory.CreateCardCharge(amount: 10000, cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        // DESCONTO DE MDR = |fullMdrRefundAmount| - |fullMdrAmount| = 0 - 300 = -300
        // DESCONTO DE ANTECIPACAO = |fullRavRefundAmount| - |fullRavAmount| = 0 - 200 = -200
        Assert.Equal("-300,000000", columns[9]);
        Assert.Equal("-200,000000", columns[10]);
        // DESCONTO UNIFICADO = 0 quando CET desabilitado
        Assert.Equal("0,000000", columns[11]);
    }

    [Fact]
    public void BuildRowCard_WithoutCet_ShouldFormatValuesWithSixDecimalsInPtBr()
    {
        _mapper.IsCetEnabled = false;
        var charge = ChargeTestFactory.CreateCardCharge(amount: 10000);

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        // amount = 10000 / 100 = 100.00 → "100,000000" (N6 pt-BR)
        Assert.Equal("100,000000", columns[7]);
    }

    [Fact]
    public void BuildRowCard_WithoutCet_ShouldCalculateNetAmountCorrectly()
    {
        _mapper.IsCetEnabled = false;
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(
            fullMdrAmount: 300m,
            fullMdrRefundAmount: 0m,
            fullRavAmount: 200m,
            fullRavRefundAmount: 0m,
            chargebackAmount: 0,
            chargebackRefundAmount: 0,
            canceledAmount: 0
        );
        var charge = ChargeTestFactory.CreateCardCharge(amount: 10000, cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        // amount = 100, discountMdr = -300, discountRav = -200, chargeback=0, canceled=0
        // discounts = abs(-300 + -200 + 0 + 0) = 500
        // netAmount = 100 - 500 = -400
        Assert.Equal("-400,000000", columns[8]);
    }

    [Fact]
    public void BuildRowCard_DefaultInstallments_ShouldBeOne()
    {
        _mapper.IsCetEnabled = false;
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(installments: null);
        var charge = ChargeTestFactory.CreateCardCharge(cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        Assert.Equal("1", columns[6]);
    }

    [Fact]
    public void BuildRowCard_WithInstallments_ShouldShowInstallmentCount()
    {
        _mapper.IsCetEnabled = false;
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(installments: 6);
        var charge = ChargeTestFactory.CreateCardCharge(cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        Assert.Equal("6", columns[6]);
    }

    [Fact]
    public void BuildRowCard_ShouldMapDocumentAndStonecode()
    {
        _mapper.IsCetEnabled = false;
        var merchant = ChargeTestFactory.CreateMerchant(document: "98765432000100", affiliationCode: "STONE999");
        var charge = ChargeTestFactory.CreateCardCharge(merchant: merchant);

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        Assert.Equal("98765432000100", columns[0]);
        Assert.Equal("STONE999", columns[1]);
    }

    [Fact]
    public void BuildRowCard_ShouldMapCardBrandAndProduct()
    {
        _mapper.IsCetEnabled = false;
        var card = ChargeTestFactory.CreateCard(brand: "Mastercard");
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(
            fundingSource: "credit", type: "credit", card: card);
        var charge = ChargeTestFactory.CreateCardCharge(cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        Assert.Equal("Mastercard", columns[3]);
        Assert.Equal("Credito", columns[4]);
    }

    [Fact]
    public void BuildRowCard_ShouldMapCardNumber()
    {
        _mapper.IsCetEnabled = false;
        var card = ChargeTestFactory.CreateCard(firstSixDigits: "555555", lastFourDigits: "4444");
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(card: card);
        var charge = ChargeTestFactory.CreateCardCharge(cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        Assert.Equal("555555******4444", columns[12]);
    }

    [Fact]
    public void BuildRowCard_ShouldMapTerminalTypeAndSerialNumber()
    {
        _mapper.IsCetEnabled = false;
        var terminal = ChargeTestFactory.CreateCardTerminal(type: "standalone_device", serialNumber: "SN-789");
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(terminal: terminal);
        var charge = ChargeTestFactory.CreateCardCharge(cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        Assert.Equal("POS", columns[13]);
        Assert.Equal("SN-789", columns[14]);
    }

    [Fact]
    public void BuildRowCard_ShouldMapLastStatusForPaidCharge()
    {
        _mapper.IsCetEnabled = false;
        var charge = ChargeTestFactory.CreateCardCharge(status: "paid");

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        Assert.Equal("Aprovada", columns[15]);
    }

    [Fact]
    public void BuildRowCard_WithChargeback_ShouldMapParteContestada()
    {
        _mapper.IsCetEnabled = false;
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(
            chargebackAmount: 500, chargebackRefundAmount: 0);
        var charge = ChargeTestFactory.CreateCardCharge(status: "paid", cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        Assert.Equal("Parte contestada", columns[15]);
    }

    [Fact]
    public void BuildRowCard_WithCanceledAmount_ShouldMapParteCancelada()
    {
        _mapper.IsCetEnabled = false;
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(canceledAmount: 1000);
        var charge = ChargeTestFactory.CreateCardCharge(status: "paid", cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        Assert.Equal("Parte cancelada", columns[15]);
    }

    #endregion

    #region BuildRowCard - With CET and FinancialMovements

    [Fact]
    public void BuildRowCard_WithCetAndFinancialMovements_ShouldUseFeeFromMovements()
    {
        _mapper.IsCetEnabled = true;
        var financialMovements = ChargeTestFactory.CreateFinancialMovements(
            mdrAmount: -150m, ravAmount: -50m, cetDiscountRateAmount: -30m, cetPrepaymentFeeAmount: -20m);
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(
            financialMovements: financialMovements);
        var charge = ChargeTestFactory.CreateCardCharge(cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        // MDR = DiscountRate where FeeType != "cet" → -150
        Assert.Equal("-150,000000", columns[9]);
        // RAV = PrepaymentFee where FeeType != "cet" → -50
        Assert.Equal("-50,000000", columns[10]);
        // CET = DiscountRate(cet) + PrepaymentFee(cet) → -30 + -20 = -50
        Assert.Equal("-50,000000", columns[11]);
    }

    [Fact]
    public void BuildRowCard_WithCetButEmptyFinancialMovements_ShouldFallbackToAggregated()
    {
        _mapper.IsCetEnabled = true;
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(
            fullMdrAmount: 300m, fullMdrRefundAmount: 0m,
            fullRavAmount: 200m, fullRavRefundAmount: 0m,
            financialMovements: new List<ChargeFinancialMovement>());
        var charge = ChargeTestFactory.CreateCardCharge(cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        Assert.Equal("-300,000000", columns[9]);
        Assert.Equal("-200,000000", columns[10]);
        Assert.Equal("0,000000", columns[11]);
    }

    [Fact]
    public void BuildRowCard_WithCetButNullFinancialMovements_ShouldFallbackToAggregated()
    {
        _mapper.IsCetEnabled = true;
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(
            fullMdrAmount: 300m, fullMdrRefundAmount: 0m,
            fullRavAmount: 200m, fullRavRefundAmount: 0m,
            financialMovements: null);
        var charge = ChargeTestFactory.CreateCardCharge(cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        Assert.Equal("-300,000000", columns[9]);
        Assert.Equal("-200,000000", columns[10]);
        Assert.Equal("0,000000", columns[11]);
    }

    #endregion

    #region BuildRowPix

    [Fact]
    public void BuildRowPix_ShouldSetStonecodeAsEmpty()
    {
        var charge = ChargeTestFactory.CreatePixCharge();

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        Assert.Empty(columns[1]);
    }

    [Fact]
    public void BuildRowPix_ShouldSetBandeiraAndInstallmentsAsEmpty()
    {
        var charge = ChargeTestFactory.CreatePixCharge();

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        Assert.Empty(columns[3]);
        Assert.Empty(columns[6]);
    }

    [Fact]
    public void BuildRowPix_ShouldUseE2eIdAsStoneId()
    {
        var pixTransaction = ChargeTestFactory.CreatePixTransaction(e2eId: "E2E-TEST-999");
        var charge = ChargeTestFactory.CreatePixCharge(pixTransaction: pixTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        Assert.Equal("E2E-TEST-999", columns[5]);
    }

    [Fact]
    public void BuildRowPix_ShouldCalculateNetAmountCorrectly()
    {
        var pixTransaction = ChargeTestFactory.CreatePixTransaction(paidAmount: 5000, feeAmount: 100);
        var charge = ChargeTestFactory.CreatePixCharge(pixTransaction: pixTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        // amount = 5000/100 = 50, discountMdr = 100/100 = 1, netAmount = 50 - 1 = 49
        Assert.Equal("50,000000", columns[7]);
        Assert.Equal("49,000000", columns[8]);
    }

    [Fact]
    public void BuildRowPix_ShouldMapPixTransactionType()
    {
        var pixTransaction = ChargeTestFactory.CreatePixTransaction(type: "dynamic");
        var charge = ChargeTestFactory.CreatePixCharge(pixTransaction: pixTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        Assert.Equal("Pix QRcode", columns[4]);
    }

    [Fact]
    public void BuildRowPix_ShouldMapTerminalTypeAndSerialNumber()
    {
        var terminal = ChargeTestFactory.CreatePixTerminal(type: "standalone_device", serialNumber: "SN-PIX-789");
        var pixTransaction = ChargeTestFactory.CreatePixTransaction(terminal: terminal);
        var charge = ChargeTestFactory.CreatePixCharge(pixTransaction: pixTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        Assert.Equal("POS", columns[13]);
        Assert.Equal("SN-PIX-789", columns[14]);
    }

    [Fact]
    public void BuildRowPix_ShouldSetDescontoDeAntecipacaoAndUnificadoAsZero()
    {
        var charge = ChargeTestFactory.CreatePixCharge();

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        Assert.Equal("0,000000", columns[10]);
        Assert.Equal("0,000000", columns[11]);
    }

    [Fact]
    public void BuildRowPix_ShouldSetNDoCartaoAsEmpty()
    {
        var charge = ChargeTestFactory.CreatePixCharge();

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        Assert.Empty(columns[12]);
    }

    #endregion

    #region BuildRowBankslip

    [Fact]
    public void BuildRowBankslip_ShouldSetProductAsBoleto()
    {
        var charge = ChargeTestFactory.CreateBoletoCharge();

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        Assert.Equal("Boleto", columns[4]);
    }

    [Fact]
    public void BuildRowBankslip_ShouldSetMeioDeCapturaAsEcommerce()
    {
        var charge = ChargeTestFactory.CreateBoletoCharge();

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        Assert.Equal("Ecommerce", columns[13]);
    }

    [Fact]
    public void BuildRowBankslip_ShouldUseBankNameAsBandeira()
    {
        var bank = ChargeTestFactory.CreateBank(name: "Bradesco");
        var boletoTransaction = ChargeTestFactory.CreateBoletoTransaction(bank: bank);
        var charge = ChargeTestFactory.CreateBoletoCharge(boletoTransaction: boletoTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        Assert.Equal("Bradesco", columns[3]);
    }

    [Fact]
    public void BuildRowBankslip_ShouldSetInstallmentsAsOne()
    {
        var charge = ChargeTestFactory.CreateBoletoCharge();

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        Assert.Equal("1", columns[6]);
    }

    [Fact]
    public void BuildRowBankslip_ShouldSetSerialNumberAsEmpty()
    {
        var charge = ChargeTestFactory.CreateBoletoCharge();

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        Assert.Empty(columns[14]);
    }

    [Fact]
    public void BuildRowBankslip_ShouldCalculateNetAmountCorrectly()
    {
        var boletoTransaction = ChargeTestFactory.CreateBoletoTransaction(feeAmount: 350);
        var charge = ChargeTestFactory.CreateBoletoCharge(amount: 10000, boletoTransaction: boletoTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        // amount = 10000/100 = 100, discountMdr = 350/100 = 3.5, netAmount = 100 - 3.5 = 96.5
        Assert.Equal("100,000000", columns[7]);
        Assert.Equal("96,500000", columns[8]);
    }

    [Fact]
    public void BuildRowBankslip_ShouldSetDescontoDeAntecipacaoAndUnificadoAsZero()
    {
        var charge = ChargeTestFactory.CreateBoletoCharge();

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        Assert.Equal("0,000000", columns[10]);
        Assert.Equal("0,000000", columns[11]);
    }

    [Fact]
    public void BuildRowBankslip_ShouldMapDocumentAndStonecode()
    {
        var merchant = ChargeTestFactory.CreateMerchant(document: "11222333000144", affiliationCode: "STONE-BOL");
        var charge = ChargeTestFactory.CreateBoletoCharge(merchant: merchant);

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        Assert.Equal("11222333000144", columns[0]);
        Assert.Equal("STONE-BOL", columns[1]);
    }

    #endregion

    #region CalculateMdrFeeAmount

    [Fact]
    public void CalculateMdrFeeAmount_WithNullMovements_ShouldReturnZero()
    {
        var result = SaleStoneCsvMapper.CalculateMdrFeeAmount(null);

        Assert.Equal(0, result);
    }

    [Fact]
    public void CalculateMdrFeeAmount_ShouldSumDiscountRateWhereNotCet()
    {
        var movements = ChargeTestFactory.CreateFinancialMovements(
            mdrAmount: -150m, cetDiscountRateAmount: -30m);

        var result = SaleStoneCsvMapper.CalculateMdrFeeAmount(movements);

        Assert.Equal(-150d, result);
    }

    [Fact]
    public void CalculateMdrFeeAmount_ShouldExcludeCetFees()
    {
        var movements = ChargeTestFactory.CreateFinancialMovements(
            mdrAmount: -100m, cetDiscountRateAmount: -50m);

        var result = SaleStoneCsvMapper.CalculateMdrFeeAmount(movements);

        Assert.Equal(-100d, result);
        Assert.NotEqual(-150d, result);
    }

    #endregion

    #region CalculateRavFeeAmount

    [Fact]
    public void CalculateRavFeeAmount_WithNullMovements_ShouldReturnZero()
    {
        var result = SaleStoneCsvMapper.CalculateRavFeeAmount(null);

        Assert.Equal(0, result);
    }

    [Fact]
    public void CalculateRavFeeAmount_ShouldSumPrepaymentFeeWhereNotCet()
    {
        var movements = ChargeTestFactory.CreateFinancialMovements(
            ravAmount: -75m, cetPrepaymentFeeAmount: -25m);

        var result = SaleStoneCsvMapper.CalculateRavFeeAmount(movements);

        Assert.Equal(-75d, result);
    }

    #endregion

    #region CalculateCetFeeAmount

    [Fact]
    public void CalculateCetFeeAmount_WithNullMovements_ShouldReturnZero()
    {
        var result = SaleStoneCsvMapper.CalculateCetFeeAmount(null);

        Assert.Equal(0, result);
    }

    [Fact]
    public void CalculateCetFeeAmount_ShouldSumBothDiscountRateAndPrepaymentFeeWhereCet()
    {
        var movements = ChargeTestFactory.CreateFinancialMovements(
            cetDiscountRateAmount: -30m, cetPrepaymentFeeAmount: -20m);

        var result = SaleStoneCsvMapper.CalculateCetFeeAmount(movements);

        Assert.Equal(-50d, result);
    }

    [Fact]
    public void CalculateCetFeeAmount_WithMixedFeeTypes_ShouldOnlySumCetEntries()
    {
        var movements = ChargeTestFactory.CreateFinancialMovements(
            mdrAmount: -150m, ravAmount: -50m, cetDiscountRateAmount: -30m, cetPrepaymentFeeAmount: -20m);

        var result = SaleStoneCsvMapper.CalculateCetFeeAmount(movements);

        // Apenas CET: -30 + -20 = -50 (não inclui mdr -150 nem rav -50)
        Assert.Equal(-50d, result);
    }

    #endregion

    #region DateTime Formatting

    [Fact]
    public void BuildRowCard_ShouldFormatCreatedAtInBrazilianTimezone()
    {
        _mapper.IsCetEnabled = false;
        // UTC 15:30 → São Paulo (UTC-3) = 12:30
        var createdAt = new DateTimeOffset(2025, 6, 15, 15, 30, 0, TimeSpan.Zero);
        var charge = ChargeTestFactory.CreateCardCharge(createdAt: createdAt);

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        Assert.Equal("15/06/2025 12:30", columns[2]);
    }

    #endregion

    #region CalculateRavTurboFeeAmount

    [Fact]
    public void CalculateRavTurboFeeAmount_WithNullMovements_ShouldReturnZero()
    {
        var result = SaleStoneCsvMapper.CalculateRavTurboFeeAmount(null);

        Assert.Equal(0, result);
    }

    [Fact]
    public void CalculateRavTurboFeeAmount_WithTurboFee_ShouldSumAmounts()
    {
        var movements = ChargeTestFactory.CreateFinancialMovements(turboAmount: -250m);

        var result = SaleStoneCsvMapper.CalculateRavTurboFeeAmount(movements);

        Assert.Equal(-250d, result);
    }

    [Fact]
    public void CalculateRavTurboFeeAmount_WithNullTurboFee_ShouldReturnZero()
    {
        var movements = ChargeTestFactory.CreateFinancialMovements();

        var result = SaleStoneCsvMapper.CalculateRavTurboFeeAmount(movements);

        Assert.Equal(0d, result);
    }

    #endregion

    #region BuildRowCard - Turbo Anticipation

    [Fact]
    public void BuildRowCard_WithoutCet_WithTurboFee_ShouldAddTurboToAnticipation()
    {
        _mapper.IsCetEnabled = false;
        // fullRavAmount=300 already includes turbo (200 regular + 100 turbo), aligned with ES setFeeAmounts
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(
            fullMdrAmount: 300m,
            fullMdrRefundAmount: 0m,
            fullRavAmount: 300m,
            fullRavRefundAmount: 0m,
            chargebackAmount: 0,
            chargebackRefundAmount: 0,
            canceledAmount: 0
        );
        var charge = ChargeTestFactory.CreateCardCharge(amount: 10000, cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        // DESCONTO DE ANTECIPACAO = |fullRavRefundAmount| - |fullRavAmount| = 0 - 300 = -300
        Assert.Equal("-300,000000", columns[10]);
    }

    [Fact]
    public void BuildRowCard_WithCetAndTurboFee_ShouldAddTurboToRav()
    {
        _mapper.IsCetEnabled = true;
        var financialMovements = ChargeTestFactory.CreateFinancialMovements(
            ravAmount: -50m, turboAmount: -100m);
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(
            financialMovements: financialMovements);
        var charge = ChargeTestFactory.CreateCardCharge(cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        // RAV = -50 (from movements) + turbo -100 = -150
        Assert.Equal("-150,000000", columns[10]);
    }

    [Fact]
    public void BuildRowCard_WithTurboFee_ShouldRecalculateNetAmount()
    {
        _mapper.IsCetEnabled = false;
        // fullRavAmount=300 already includes turbo (200 regular + 100 turbo), aligned with ES setFeeAmounts
        var cardTransaction = ChargeTestFactory.CreateCardTransaction(
            fullMdrAmount: 300m,
            fullMdrRefundAmount: 0m,
            fullRavAmount: 300m,
            fullRavRefundAmount: 0m,
            chargebackAmount: 0,
            chargebackRefundAmount: 0,
            canceledAmount: 0
        );
        var charge = ChargeTestFactory.CreateCardCharge(amount: 10000, cardTransaction: cardTransaction);

        var row = _mapper.BuildRow(charge);
        var columns = row.Split(';');

        // amount = 100, discountMdr = -300, discountRav = -300 (includes turbo)
        // discounts = abs(-300 + -300 + 0 + 0) = 600
        // netAmount = 100 - 600 = -500
        Assert.Equal("-500,000000", columns[8]);
    }

    #endregion
}

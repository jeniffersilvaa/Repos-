using PaymentsDataLayerReports.Application.Workers.Shared;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.Shared;

public class DownloadFileNameBuilderTests
{
    #region BuildReceivablesFileName Tests

    [Fact]
    public void BuildReceivablesFileName_WithValidParameters_ShouldReturnCorrectFileName()
    {
        // Arrange
        var startDate = "2025-01-01";
        var endDate = "2025-01-31";
        var reportId = "report-123";
        var fileFormat = "csv";

        // Act
        var result = DownloadFileNameBuilder.BuildReceivablesFileName(startDate, endDate, reportId, fileFormat);

        // Assert
        Assert.Equal("relatorio-recebimentos-2025-01-01-2025-01-31-report-123.csv", result);
    }

    [Fact]
    public void BuildReceivablesFileName_WithXlsxFormat_ShouldReturnCorrectExtension()
    {
        // Arrange
        var startDate = "2025-01-01";
        var endDate = "2025-01-31";
        var reportId = "report-123";
        var fileFormat = "xlsx";

        // Act
        var result = DownloadFileNameBuilder.BuildReceivablesFileName(startDate, endDate, reportId, fileFormat);

        // Assert
        Assert.Equal("relatorio-recebimentos-2025-01-01-2025-01-31-report-123.xlsx", result);
    }

    [Fact]
    public void BuildReceivablesFileName_WithDifferentDates_ShouldIncludeDatesInFileName()
    {
        // Arrange
        var startDate = "2024-06-15";
        var endDate = "2024-06-30";
        var reportId = "abc-456";
        var fileFormat = "csv";

        // Act
        var result = DownloadFileNameBuilder.BuildReceivablesFileName(startDate, endDate, reportId, fileFormat);

        // Assert
        Assert.Contains("2024-06-15", result);
        Assert.Contains("2024-06-30", result);
        Assert.Contains("abc-456", result);
    }

    [Fact]
    public void BuildReceivablesFileName_ShouldStartWithCorrectPrefix()
    {
        // Arrange & Act
        var result = DownloadFileNameBuilder.BuildReceivablesFileName("2025-01-01", "2025-01-31", "id", "csv");

        // Assert
        Assert.StartsWith("relatorio-recebimentos-", result);
    }

    #endregion

    #region BuildOrderFileName Tests

    [Fact]
    public void BuildOrderFileName_WithValidParameters_ShouldReturnCorrectFileName()
    {
        // Arrange
        var startDate = "2025-01-01";
        var endDate = "2025-01-31";
        var reportId = "report-123";
        var fileFormat = "csv";

        // Act
        var result = DownloadFileNameBuilder.BuildOrderFileName(startDate, endDate, reportId, fileFormat);

        // Assert
        Assert.Equal("relatorio-pedidos-2025-01-01-2025-01-31-report-123.csv", result);
    }

    [Fact]
    public void BuildOrderFileName_WithXlsxFormat_ShouldReturnCorrectExtension()
    {
        // Arrange
        var startDate = "2025-01-01";
        var endDate = "2025-01-31";
        var reportId = "report-123";
        var fileFormat = "xlsx";

        // Act
        var result = DownloadFileNameBuilder.BuildOrderFileName(startDate, endDate, reportId, fileFormat);

        // Assert
        Assert.Equal("relatorio-pedidos-2025-01-01-2025-01-31-report-123.xlsx", result);
    }

    [Fact]
    public void BuildOrderFileName_WithDifferentDates_ShouldIncludeDatesInFileName()
    {
        // Arrange
        var startDate = "2024-06-15";
        var endDate = "2024-06-30";
        var reportId = "abc-456";
        var fileFormat = "csv";

        // Act
        var result = DownloadFileNameBuilder.BuildOrderFileName(startDate, endDate, reportId, fileFormat);

        // Assert
        Assert.Contains("2024-06-15", result);
        Assert.Contains("2024-06-30", result);
        Assert.Contains("abc-456", result);
    }

    [Fact]
    public void BuildOrderFileName_ShouldStartWithCorrectPrefix()
    {
        // Arrange & Act
        var result = DownloadFileNameBuilder.BuildOrderFileName("2025-01-01", "2025-01-31", "id", "csv");

        // Assert
        Assert.StartsWith("relatorio-pedidos-", result);
    }

    #endregion

    #region Comparison Tests

    [Fact]
    public void BuildReceivablesFileName_And_BuildOrderFileName_ShouldHaveDifferentPrefixes()
    {
        // Arrange
        var startDate = "2025-01-01";
        var endDate = "2025-01-31";
        var reportId = "report-123";
        var fileFormat = "csv";

        // Act
        var receivablesFileName = DownloadFileNameBuilder.BuildReceivablesFileName(startDate, endDate, reportId, fileFormat);
        var orderFileName = DownloadFileNameBuilder.BuildOrderFileName(startDate, endDate, reportId, fileFormat);

        // Assert
        Assert.NotEqual(receivablesFileName, orderFileName);
        Assert.Contains("recebimentos", receivablesFileName);
        Assert.Contains("pedidos", orderFileName);
    }

    #endregion
}

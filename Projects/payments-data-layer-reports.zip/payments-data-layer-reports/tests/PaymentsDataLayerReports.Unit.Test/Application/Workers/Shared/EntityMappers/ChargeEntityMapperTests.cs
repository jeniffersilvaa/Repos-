using System.Globalization;
using System.Reflection;
using System.Text.Json;
using PaymentsDataLayerReports.Application.Entities.Models.Charge;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.ChargeList;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;
using PaymentsDataLayerReports.Application.Workers.Shared.EntityMappers;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.Shared.EntityMappers;

public class ChargeEntityMapperTests
{
    private static readonly Dictionary<string, int> HeaderIndex = ChargeListReportHeader.HeaderIndex;

    #region Helper Methods

    private static CsvRow CreateBaseCsvRow()
    {
        var csvRow = new CsvRow(HeaderIndex.Count);

        // Campos base obrigatórios
        csvRow.SetField(HeaderIndex["id"], "charge_123");
        csvRow.SetField(HeaderIndex["initiator_id"], "initiator_456");
        csvRow.SetField(HeaderIndex["product"], "payment");
        csvRow.SetField(HeaderIndex["origin"], "api");
        csvRow.SetField(HeaderIndex["origin_id"], "origin_789");
        csvRow.SetField(HeaderIndex["amount"], 10000);
        csvRow.SetField(HeaderIndex["updated_amount"], 10000);
        csvRow.SetField(HeaderIndex["net_amount"], 9800);
        csvRow.SetField(HeaderIndex["full_net_amount"], "98.00");
        csvRow.SetField(HeaderIndex["status"], "paid");
        csvRow.SetField(HeaderIndex["created_at"], DateTime.Parse("2024-01-15T10:30:00Z"));
        csvRow.SetField(HeaderIndex["platform_name"], "stone");
        csvRow.SetField(HeaderIndex["attempt_count"], 1);
        csvRow.SetField(HeaderIndex["gateway"], "stone_gateway");
        csvRow.SetField(HeaderIndex["gateway_order_id"], "order_123");
        csvRow.SetField(HeaderIndex["code"], "CODE123");
        csvRow.SetField(HeaderIndex["all_ids"], "id1,id2,id3");
        csvRow.SetField(HeaderIndex["charge_id"], "charge_external_123");
        csvRow.SetField(HeaderIndex["point_of_interaction_type"], "pos");

        // Merchant obrigatório
        csvRow.SetField(HeaderIndex["merchant__organization"], "stone");
        csvRow.SetField(HeaderIndex["merchant__document"], "12345678000190");
        csvRow.SetField(HeaderIndex["merchant__user_id"], "user_123");
        csvRow.SetField(HeaderIndex["merchant__affiliation_key"], "aff_key_123");
        csvRow.SetField(HeaderIndex["merchant__affiliation_code"], "aff_code_456");
        csvRow.SetField(HeaderIndex["merchant__account_id"], "acc_789");
        csvRow.SetField(HeaderIndex["merchant__merchant_id"], "merch_012");

        return csvRow;
    }

    private static void SetCardTransactionFields(CsvRow csvRow)
    {
        csvRow.SetField(HeaderIndex["payment_method"], "card");
        csvRow.SetField(HeaderIndex["card_transaction__type"], "credit");
        csvRow.SetField(HeaderIndex["card_transaction__funding_source"], "credit");
        csvRow.SetField(HeaderIndex["card_transaction__transaction_id"], "card_txn_123");
        csvRow.SetField(HeaderIndex["card_transaction__authorized_amount"], 10000);
        csvRow.SetField(HeaderIndex["card_transaction__captured_amount"], 10000);
        csvRow.SetField(HeaderIndex["card_transaction__canceled_amount"], 0);
        csvRow.SetField(HeaderIndex["card_transaction__chargeback_amount"], 0);
        csvRow.SetField(HeaderIndex["card_transaction__chargeback_refund_amount"], 0);
        csvRow.SetField(HeaderIndex["card_transaction__authorization_code"], "AUTH123");
        csvRow.SetField(HeaderIndex["card_transaction__authorized_state"], "authorized");
        csvRow.SetField(HeaderIndex["card_transaction__installments"], 1);
        csvRow.SetField(HeaderIndex["card_transaction__installments_type"], "none");
        csvRow.SetField(HeaderIndex["card_transaction__scheme_business_model"], "debit");
        csvRow.SetField(HeaderIndex["card_transaction__fee_amount"], 200);
        csvRow.SetField(HeaderIndex["card_transaction__full_fee_amount"], "2.00");
        csvRow.SetField(HeaderIndex["card_transaction__mdr_amount"], 150);
        csvRow.SetField(HeaderIndex["card_transaction__full_mdr_amount"], "1.50");
        csvRow.SetField(HeaderIndex["card_transaction__mdr_refund_amount"], 0);
        csvRow.SetField(HeaderIndex["card_transaction__full_mdr_refund_amount"], "0.00");
        csvRow.SetField(HeaderIndex["card_transaction__full_fc_amount"], "0.00");
        csvRow.SetField(HeaderIndex["card_transaction__full_fc_refund_amount"], "0.00");
        csvRow.SetField(HeaderIndex["card_transaction__rav_amount"], 50);
        csvRow.SetField(HeaderIndex["card_transaction__full_rav_amount"], "0.50");
        csvRow.SetField(HeaderIndex["card_transaction__rav_refund_amount"], 0);
        csvRow.SetField(HeaderIndex["card_transaction__full_rav_refund_amount"], "0.00");

        // Card details
        csvRow.SetField(HeaderIndex["card_transaction__card__brand"], "visa");
        csvRow.SetField(HeaderIndex["card_transaction__card__brand_id"], "1");
        csvRow.SetField(HeaderIndex["card_transaction__card__first_six_digits"], "411111");
        csvRow.SetField(HeaderIndex["card_transaction__card__last_four_digits"], 1111);
        csvRow.SetField(HeaderIndex["card_transaction__card__entry_mode"], "chip");
        csvRow.SetField(HeaderIndex["card_transaction__card__holder_name"], "JOHN DOE");
        csvRow.SetField(HeaderIndex["card_transaction__card__exp_month"], 12);
        csvRow.SetField(HeaderIndex["card_transaction__card__exp_year"], "2025");
        csvRow.SetField(HeaderIndex["card_transaction__card__country_code"], "076");
        csvRow.SetField(HeaderIndex["card_transaction__card__currency_code"], "986");
        csvRow.SetField(HeaderIndex["card_transaction__card__number_token"], "token_123");
        csvRow.SetField(HeaderIndex["card_transaction__card__label"], "Corporate Card");

        // Terminal
        csvRow.SetField(HeaderIndex["card_transaction__terminal__type"], "pos");
        csvRow.SetField(HeaderIndex["card_transaction__terminal__serial_number"], "SN123456");

        // Customer
        csvRow.SetField(HeaderIndex["card_transaction__customer__name"], "John Doe Customer");
        csvRow.SetField(HeaderIndex["card_transaction__customer__document_type"], "cpf");
        csvRow.SetField(HeaderIndex["card_transaction__customer__document"], "12345678900");
        csvRow.SetField(HeaderIndex["card_transaction__customer__customer_id"], "cust_123");
        csvRow.SetField(HeaderIndex["card_transaction__customer__email"], "john@example.com");

        // Last status
        csvRow.SetField(HeaderIndex["card_transaction__last__operation_status"], "captured");
        csvRow.SetField(HeaderIndex["card_transaction__last__antifraud_status"], "approved");
        csvRow.SetField(HeaderIndex["card_transaction__last__acquirer_name"], "stone");
        csvRow.SetField(HeaderIndex["card_transaction__last__acquirer_return_code"], "00");
        csvRow.SetField(HeaderIndex["card_transaction__last__legacy_status"], "paid");

        // Details (empty array)
        csvRow.SetField(HeaderIndex["card_transaction__details"], "[]");
        csvRow.SetField(HeaderIndex["card_transaction__financial_movements"], "[]");
    }

    private static void SetPixTransactionFields(CsvRow csvRow)
    {
        csvRow.SetField(HeaderIndex["payment_method"], "pix");
        csvRow.SetField(HeaderIndex["pix_transaction__type"], "qrcode");
        csvRow.SetField(HeaderIndex["pix_transaction__transaction_id"], "pix_txn_123");
        csvRow.SetField(HeaderIndex["pix_transaction__e2e_id"], "E12345678202401151030ABCD1234");
        csvRow.SetField(HeaderIndex["pix_transaction__pix_key"], "12345678900");
        csvRow.SetField(HeaderIndex["pix_transaction__is_pix_sale_key"], true);
        csvRow.SetField(HeaderIndex["pix_transaction__pix_key_nickname"], "Minha Chave");
        csvRow.SetField(HeaderIndex["pix_transaction__paid_amount"], 10000);
        csvRow.SetField(HeaderIndex["pix_transaction__canceled_amount"], 0);
        csvRow.SetField(HeaderIndex["pix_transaction__fee_amount"], 0);
        csvRow.SetField(HeaderIndex["pix_transaction__full_fee_amount"], "0.00");
        csvRow.SetField(HeaderIndex["pix_transaction__full_mdr_amount"], "0.00");
        csvRow.SetField(HeaderIndex["pix_transaction__full_mdr_refund_amount"], "0.00");
        csvRow.SetField(HeaderIndex["pix_transaction__full_rav_amount"], "0.00");
        csvRow.SetField(HeaderIndex["pix_transaction__full_rav_refund_amount"], "0.00");
        csvRow.SetField(HeaderIndex["pix_transaction__full_fc_amount"], "0.00");
        csvRow.SetField(HeaderIndex["pix_transaction__full_fc_refund_amount"], "0.00");
        csvRow.SetField(HeaderIndex["pix_transaction__expire_at"], "2024-01-15T23:59:59Z");
        csvRow.SetField(HeaderIndex["pix_transaction__payment_limit_period_days"], 30);
        csvRow.SetField(HeaderIndex["pix_transaction__business_days_only"], false);
        csvRow.SetField(HeaderIndex["pix_transaction__expires_in"], 3600);
        csvRow.SetField(HeaderIndex["pix_transaction__request_for_payer"], "Pagamento de serviço");

        // Customer
        csvRow.SetField(HeaderIndex["pix_transaction__customer__name"], "John Pix Customer");
        csvRow.SetField(HeaderIndex["pix_transaction__customer__document_type"], "cpf");
        csvRow.SetField(HeaderIndex["pix_transaction__customer__document"], "12345678900");
        csvRow.SetField(HeaderIndex["pix_transaction__customer__email"], "john.pix@example.com");
        csvRow.SetField(HeaderIndex["pix_transaction__customer__customer_id"], "pix_cust_123");

        // Payer
        csvRow.SetField(HeaderIndex["pix_transaction__payer__name"], "Jane Payer");
        csvRow.SetField(HeaderIndex["pix_transaction__payer__document_type"], "cpf");
        csvRow.SetField(HeaderIndex["pix_transaction__payer__document"], "98765432100");
        csvRow.SetField(HeaderIndex["pix_transaction__payer__ispb"], "12345678");
        csvRow.SetField(HeaderIndex["pix_transaction__payer__institution_name"], "Banco Exemplo");

        // Terminal
        csvRow.SetField(HeaderIndex["pix_transaction__terminal__type"], "online");
        csvRow.SetField(HeaderIndex["pix_transaction__terminal__serial_number"], "");

        // Last
        csvRow.SetField(HeaderIndex["pix_transaction__last__operation_status"], "paid");
        csvRow.SetField(HeaderIndex["pix_transaction__last__legacy_status"], "paid");

        // Fine
        csvRow.SetField(HeaderIndex["pix_transaction__fine__start_at"], "2024-01-16T00:00:00Z");
        csvRow.SetField(HeaderIndex["pix_transaction__fine__type"], "percentage");
        csvRow.SetField(HeaderIndex["pix_transaction__fine__value"], "2.00");

        // Interest
        csvRow.SetField(HeaderIndex["pix_transaction__interest__start_at"], "2024-01-16T00:00:00Z");
        csvRow.SetField(HeaderIndex["pix_transaction__interest__type"], "daily_percentage");
        csvRow.SetField(HeaderIndex["pix_transaction__interest__value"], "0.033");
        csvRow.SetField(HeaderIndex["pix_transaction__interest__period"], "calendar_days");

        // Reduction
        csvRow.SetField(HeaderIndex["pix_transaction__reduction__start_at"], "2024-01-15T00:00:00Z");
        csvRow.SetField(HeaderIndex["pix_transaction__reduction__value"], "500");

        // Details
        csvRow.SetField(HeaderIndex["pix_transaction__details"], "[]");
        csvRow.SetField(HeaderIndex["pix_transaction__financial_movements"], "[]");
        csvRow.SetField(HeaderIndex["pix_transaction__additional_data"], "[]");
    }

    private static void SetBoletoTransactionFields(CsvRow csvRow)
    {
        csvRow.SetField(HeaderIndex["payment_method"], "boleto");
        csvRow.SetField(HeaderIndex["boleto_transaction__type"], "registered");
        csvRow.SetField(HeaderIndex["boleto_transaction__transaction_id"], "boleto_txn_123");
        csvRow.SetField(HeaderIndex["boleto_transaction__our_number"], "12345678901");
        csvRow.SetField(HeaderIndex["boleto_transaction__paid_amount"], 10000);
        csvRow.SetField(HeaderIndex["boleto_transaction__fine_amount"], 100);
        csvRow.SetField(HeaderIndex["boleto_transaction__interest_amount"], 50);
        csvRow.SetField(HeaderIndex["boleto_transaction__discount_amount"], 0);
        csvRow.SetField(HeaderIndex["boleto_transaction__canceled_amount"], 0);
        csvRow.SetField(HeaderIndex["boleto_transaction__fee_amount"], 250);
        csvRow.SetField(HeaderIndex["boleto_transaction__full_fee_amount"], "2.50");
        csvRow.SetField(HeaderIndex["boleto_transaction__full_mdr_amount"], "0.00");
        csvRow.SetField(HeaderIndex["boleto_transaction__full_mdr_refund_amount"], "0.00");
        csvRow.SetField(HeaderIndex["boleto_transaction__full_rav_amount"], "0.00");
        csvRow.SetField(HeaderIndex["boleto_transaction__full_rav_refund_amount"], "0.00");
        csvRow.SetField(HeaderIndex["boleto_transaction__full_fc_amount"], "0.00");
        csvRow.SetField(HeaderIndex["boleto_transaction__full_fc_refund_amount"], "0.00");
        csvRow.SetField(HeaderIndex["boleto_transaction__expire_at"], "2024-02-15T23:59:59Z");
        csvRow.SetField(HeaderIndex["boleto_transaction__limit_date"], "2024-02-20T23:59:59Z");
        csvRow.SetField(HeaderIndex["boleto_transaction__barcode"], "12345678901234567890123456789012345678901234");
        csvRow.SetField(HeaderIndex["boleto_transaction__writable_line"], "12345.67890 12345.678901 12345.678901 1 12340000010000");
        csvRow.SetField(HeaderIndex["boleto_transaction__instructions"], "Não receber após vencimento");
        csvRow.SetField(HeaderIndex["boleto_transaction__url"], "https://boleto.example.com/view/123");
        csvRow.SetField(HeaderIndex["boleto_transaction__paid_at"], DateTime.Parse("2024-01-15T14:30:00Z"));

        // Bank
        csvRow.SetField(HeaderIndex["boleto_transaction__bank__code"], "237");
        csvRow.SetField(HeaderIndex["boleto_transaction__bank__name"], "Bradesco");

        // Receiver
        csvRow.SetField(HeaderIndex["boleto_transaction__receiver__name"], "Empresa Recebedora LTDA");
        csvRow.SetField(HeaderIndex["boleto_transaction__receiver__document_type"], "cnpj");
        csvRow.SetField(HeaderIndex["boleto_transaction__receiver__document"], "12345678000190");

        // Customer
        csvRow.SetField(HeaderIndex["boleto_transaction__customer__name"], "John Boleto Customer");
        csvRow.SetField(HeaderIndex["boleto_transaction__customer__document_type"], "cpf");
        csvRow.SetField(HeaderIndex["boleto_transaction__customer__document"], "12345678900");
        csvRow.SetField(HeaderIndex["boleto_transaction__customer__customer_id"], "boleto_cust_123");
        csvRow.SetField(HeaderIndex["boleto_transaction__customer__email"], "john.boleto@example.com");

        // Last
        csvRow.SetField(HeaderIndex["boleto_transaction__last__operation_status"], "paid");
        csvRow.SetField(HeaderIndex["boleto_transaction__last__legacy_status"], "paid");

        // Fine
        csvRow.SetField(HeaderIndex["boleto_transaction__fine__start_at"], "2024-02-16T00:00:00Z");
        csvRow.SetField(HeaderIndex["boleto_transaction__fine__type"], "percentage");
        csvRow.SetField(HeaderIndex["boleto_transaction__fine__value"], "2.00");

        // Interest
        csvRow.SetField(HeaderIndex["boleto_transaction__interest__start_at"], "2024-02-16T00:00:00Z");
        csvRow.SetField(HeaderIndex["boleto_transaction__interest__type"], "daily_amount");
        csvRow.SetField(HeaderIndex["boleto_transaction__interest__value"], "3.33");

        // Details
        csvRow.SetField(HeaderIndex["boleto_transaction__details"], "[]");
        csvRow.SetField(HeaderIndex["boleto_transaction__financial_movements"], "[]");
        csvRow.SetField(HeaderIndex["boleto_transaction__discounts"], "[]");
    }

    private static void SetCashTransactionFields(CsvRow csvRow)
    {
        csvRow.SetField(HeaderIndex["payment_method"], "cash");
        csvRow.SetField(HeaderIndex["cash_transaction__description"], "Pagamento em dinheiro");
        csvRow.SetField(HeaderIndex["cash_transaction__transaction_id"], "cash_txn_123");
        csvRow.SetField(HeaderIndex["cash_transaction__paid_amount"], "10000");
        csvRow.SetField(HeaderIndex["cash_transaction__canceled_amount"], "0");

        // Customer
        csvRow.SetField(HeaderIndex["cash_transaction__customer__name"], "John Cash Customer");
        csvRow.SetField(HeaderIndex["cash_transaction__customer__document_type"], "cpf");
        csvRow.SetField(HeaderIndex["cash_transaction__customer__document"], "12345678900");
        csvRow.SetField(HeaderIndex["cash_transaction__customer__customer_id"], "cash_cust_123");
        csvRow.SetField(HeaderIndex["cash_transaction__customer__email"], "john.cash@example.com");

        // Last
        csvRow.SetField(HeaderIndex["cash_transaction__last__operation_status"], "paid");
        csvRow.SetField(HeaderIndex["cash_transaction__last__legacy_status"], "paid");

        // Details
        csvRow.SetField(HeaderIndex["cash_transaction__details"], "[]");
    }

    #endregion

    #region Card Transaction Tests

    [Fact]
    public void MapToEntity_WithCardTransaction_ShouldMapSuccessfully()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(csvRow.GetField<string>(HeaderIndex, "id"), result.Id);
        Assert.Equal(csvRow.GetField<string>(HeaderIndex, "initiator_id"), result.InitiatorId);
        Assert.Equal(csvRow.GetField<string>(HeaderIndex, "payment_method"), result.PaymentMethod);
        Assert.Equal(csvRow.GetField<string>(HeaderIndex, "status"), result.Status);
        Assert.Equal(csvRow.GetField<int>(HeaderIndex, "amount"), result.Amount);
        Assert.Equal(csvRow.GetField<int>(HeaderIndex, "net_amount"), result.NetAmount);

        // Merchant
        Assert.NotNull(result.Merchant);
        Assert.Equal(csvRow.GetField<string>(HeaderIndex, "merchant__organization"), result.Merchant.Organization);
        Assert.Equal(csvRow.GetField<string>(HeaderIndex, "merchant__document"), result.Merchant.Document);
        Assert.Equal(csvRow.GetField<string>(HeaderIndex, "merchant__user_id"), result.Merchant.UserId);
        Assert.Equal(csvRow.GetField<string>(HeaderIndex, "merchant__affiliation_key"), result.Merchant.AffiliationKey);
        Assert.Equal(csvRow.GetField<string>(HeaderIndex, "merchant__affiliation_code"), result.Merchant.AffiliationCode);
        Assert.Equal(csvRow.GetField<string>(HeaderIndex, "merchant__account_id"), result.Merchant.AccountId);
        Assert.Equal(csvRow.GetField<string>(HeaderIndex, "merchant__merchant_id"), result.Merchant.MerchantId);

        // Card Transaction
        Assert.NotNull(result.CardTransaction);
        Assert.Equal("credit", result.CardTransaction.Type);
        Assert.Equal("credit", result.CardTransaction.FundingSource);
        Assert.Equal("card_txn_123", result.CardTransaction.TransactionId);
        Assert.Equal(10000, result.CardTransaction.AuthorizedAmount);
        Assert.Equal(10000, result.CardTransaction.CapturedAmount);
        Assert.Equal(0, result.CardTransaction.CanceledAmount);
        Assert.Equal(0, result.CardTransaction.ChargebackAmount);
        Assert.Equal(0, result.CardTransaction.ChargebackRefundAmount);
        Assert.Equal("AUTH123", result.CardTransaction.AuthorizationCode);
        Assert.Equal("authorized", result.CardTransaction.AuthorizedState);
        Assert.Equal(1, result.CardTransaction.Installments);
        Assert.Equal("none", result.CardTransaction.InstallmentsType);
        Assert.Equal("debit", result.CardTransaction.SchemeBusinessModel);
        Assert.Equal(200, result.CardTransaction.FeeAmount);
        Assert.NotNull(result.CardTransaction.FullFeeAmount);
        Assert.Equal(150, result.CardTransaction.MdrAmount);
        Assert.NotNull(result.CardTransaction.FullMdrAmount);
        Assert.Equal(0, result.CardTransaction.MdrRefundAmount);
        Assert.Equal(50, result.CardTransaction.RavAmount);
        Assert.NotNull(result.CardTransaction.FullRavAmount);
        Assert.Equal(0, result.CardTransaction.RavRefundAmount);

        // Card
        Assert.NotNull(result.CardTransaction.Card);
        Assert.Equal("visa", result.CardTransaction.Card.Brand);
        Assert.Equal((byte)1, result.CardTransaction.Card.BrandId);
        Assert.Equal("411111", result.CardTransaction.Card.FirstSixDigits);
        Assert.Equal("1111", result.CardTransaction.Card.LastFourDigits);
        Assert.Equal("chip", result.CardTransaction.Card.EntryMode);
        Assert.Equal("JOHN DOE", result.CardTransaction.Card.HolderName);
        Assert.Equal("12", result.CardTransaction.Card.ExpMonth);
        Assert.Equal("2025", result.CardTransaction.Card.ExpYear);
        Assert.Equal((short)76, result.CardTransaction.Card.CountryCode);
        Assert.Equal((short)986, result.CardTransaction.Card.CurrencyCode);
        Assert.Equal("token_123", result.CardTransaction.Card.NumberToken);
        Assert.Equal("Corporate Card", result.CardTransaction.Card.Label);

        // Other transactions should be null
        Assert.Null(result.PixTransaction);
        Assert.Null(result.BoletoTransaction);
        Assert.Null(result.CashTransaction);
    }

    [Fact]
    public void MapToEntity_WithCardTransactionAndCustomer_ShouldMapCustomer()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.CardTransaction);
        Assert.NotNull(result.CardTransaction.Customer);
        Assert.Equal("John Doe Customer", result.CardTransaction.Customer.Name);
        Assert.Equal("cpf", result.CardTransaction.Customer.DocumentType);
        Assert.Equal("12345678900", result.CardTransaction.Customer.Document);
        Assert.Equal("john@example.com", result.CardTransaction.Customer.Email);
    }

    [Fact]
    public void MapToEntity_WithCardTransactionAndTerminal_ShouldMapTerminal()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.CardTransaction);
        Assert.NotNull(result.CardTransaction.Terminal);
        Assert.Equal("pos", result.CardTransaction.Terminal.Type);
        Assert.Equal("SN123456", result.CardTransaction.Terminal.SerialNumber);
    }

    [Fact]
    public void MapToEntity_WithCardTransactionAndLast_ShouldMapLast()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.CardTransaction);
        Assert.NotNull(result.CardTransaction.Last);
        Assert.Equal("captured", result.CardTransaction.Last.OperationStatus);
        Assert.Equal("approved", result.CardTransaction.Last.AntifraudStatus);
        Assert.Equal("stone", result.CardTransaction.Last.AcquirerName);
        Assert.Equal("00", result.CardTransaction.Last.AcquirerReturnCode);
    }

    [Fact]
    public void MapToEntity_WithCardDetailsAsJsonArray_ShouldMapCardDetails()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);

        csvRow.SetField(
            HeaderIndex["card_transaction__details"],
            "[{\"operation\":\"capture\",\"operation_id\":\"op_1\",\"operation_amount\":\"10000\",\"provider_datetime\":\"2024-01-15T10:31:00Z\",\"local_datetime\":\"2024-01-15T07:31:00-03:00\",\"operation_status\":\"success\"}]"
        );

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.CardTransaction);
        Assert.NotNull(result.CardTransaction.Details);
        Assert.Single(result.CardTransaction.Details);
        Assert.Equal("capture", result.CardTransaction.Details[0].Operation);
        Assert.Equal("op_1", result.CardTransaction.Details[0].OperationId);
        Assert.Equal(10000, result.CardTransaction.Details[0].OperationAmount);
    }

    [Fact]
    public void MapToEntity_WithCardDetailsNestedJson_ShouldMapNestedObjects()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);

        csvRow.SetField(
            HeaderIndex["card_transaction__details"],
            "[{\"operation\":\"capture\",\"operation_id\":\"op_nested\",\"operation_amount\":\"10000\",\"provider_datetime\":\"2024-01-15T10:31:00Z\",\"local_datetime\":\"2024-01-15T10:31:00Z\",\"acquirer_message\":\"ok\",\"acquirer\":{\"name\":\"stone\",\"nsu\":\"123\",\"tid\":\"999\"},\"gateway_response\":{\"code\":\"00\",\"message\":\"approved\"},\"antifraud_response\":{\"provider_name\":\"af\",\"score\":\"1\",\"status\":\"approved\"},\"legacy\":{\"status\":\"paid\",\"transaction_status\":\"paid\",\"account_name\":\"stone\"}}]"
        );

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.CardTransaction);
        Assert.NotNull(result.CardTransaction.Details);
        Assert.Single(result.CardTransaction.Details);
        Assert.NotNull(result.CardTransaction.Details[0].Acquirer);
        Assert.NotNull(result.CardTransaction.Details[0].GatewayResponse);
        Assert.NotNull(result.CardTransaction.Details[0].AntifraudResponse);
        Assert.NotNull(result.CardTransaction.Details[0].Legacy);
    }

    [Fact]
    public void MapToEntity_WithCardFinancialMovementsAsJsonArray_ShouldMapFinancialMovements()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);

        csvRow.SetField(
            HeaderIndex["card_transaction__financial_movements"],
            "[{\"operation\":\"capture\",\"operation_id\":\"fm_1\",\"installment_number\":\"1\",\"amount\":{\"gross\":\"10000\",\"net\":\"9700\"}}]"
        );

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.CardTransaction);
        Assert.NotNull(result.CardTransaction.FinancialMovements);
        Assert.Single(result.CardTransaction.FinancialMovements);
        Assert.Equal("capture", result.CardTransaction.FinancialMovements[0].Operation);
        Assert.Equal("fm_1", result.CardTransaction.FinancialMovements[0].OperationId);
        Assert.Equal((short)1, result.CardTransaction.FinancialMovements[0].InstallmentNumber);
        var amount = result.CardTransaction.FinancialMovements[0].Amount;
        Assert.NotNull(amount);
        Assert.Equal(10000m, amount!.Gross);
        Assert.Equal(9700m, amount.Net);
    }

    [Fact]
    public void MapToEntity_WithCardFinancialMovementsNestedFees_ShouldMapNestedFees()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);

        csvRow.SetField(
            HeaderIndex["card_transaction__financial_movements"],
            "[{\"operation\":\"capture\",\"operation_id\":\"fm_2\",\"installment_number\":\"2\",\"amount\":{\"gross\":\"10000\",\"net\":\"9500\",\"discount_rate\":{\"fee_type\":\"mdr\",\"fee\":\"2.0\",\"effective_fee\":\"1.9\",\"amount\":\"200\"},\"prepayment_fee\":{\"fee_type\":\"pre\",\"fee\":\"1.0\",\"effective_fee\":\"0.9\",\"amount\":\"100\"},\"fraud_coverage\":{\"fee_type\":\"fraud\",\"fee\":\"0.5\",\"effective_fee\":\"0.4\",\"amount\":\"50\"}}}]"
        );

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.CardTransaction);
        Assert.NotNull(result.CardTransaction.FinancialMovements);
        Assert.Single(result.CardTransaction.FinancialMovements);
        var amount = result.CardTransaction.FinancialMovements[0].Amount;
        Assert.NotNull(amount);
        Assert.NotNull(amount!.DiscountRate);
        Assert.NotNull(amount.PrepaymentFee);
        Assert.NotNull(amount.FraudCoverage);
        Assert.Equal("mdr", amount.DiscountRate!.FeeType);
    }

    #endregion

    #region Pix Transaction Tests

    [Fact]
    public void MapToEntity_WithPixTransaction_ShouldMapSuccessfully()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetPixTransactionFields(csvRow);

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result);
        Assert.Equal("charge_123", result.Id);
        Assert.Equal("pix", result.PaymentMethod);

        // Pix Transaction
        Assert.NotNull(result.PixTransaction);
        Assert.Equal("qrcode", result.PixTransaction.Type);
        Assert.Equal("pix_txn_123", result.PixTransaction.TransactionId);
        Assert.Equal("E12345678202401151030ABCD1234", result.PixTransaction.E2eId);
        Assert.Equal("12345678900", result.PixTransaction.PixKey);
        Assert.True(result.PixTransaction.IsPixSaleKey);
        Assert.Equal("Minha Chave", result.PixTransaction.PixKeyNickname);
        Assert.Equal(10000, result.PixTransaction.PaidAmount);
        Assert.Equal(0, result.PixTransaction.CanceledAmount);
        Assert.Equal(0, result.PixTransaction.FeeAmount);
        Assert.NotNull(result.PixTransaction.FullFeeAmount);
        Assert.Equal("2024-01-15T23:59:59Z", result.PixTransaction.ExpireAt);
        Assert.Equal(30, result.PixTransaction.PaymentLimitPeriodDays);
        Assert.False(result.PixTransaction.BusinessDaysOnly);
        Assert.Equal(3600, result.PixTransaction.ExpiresIn);
        Assert.Equal("Pagamento de serviço", result.PixTransaction.RequestForPayer);

        // Fine
        Assert.NotNull(result.PixTransaction.Fine);
        Assert.Equal("2024-01-16T00:00:00Z", result.PixTransaction.Fine.StartAt);
        Assert.Equal("percentage", result.PixTransaction.Fine.Type);
        Assert.Equal("2.00", result.PixTransaction.Fine.Value);

        // Interest
        Assert.NotNull(result.PixTransaction.Interest);
        Assert.Equal("daily_percentage", result.PixTransaction.Interest.Type);
        Assert.Equal("0.033", result.PixTransaction.Interest.Value);
        Assert.Equal("calendar_days", result.PixTransaction.Interest.Period);

        // Reduction
        Assert.NotNull(result.PixTransaction.Reduction);
        Assert.Equal("500", result.PixTransaction.Reduction.Value);

        // Other transactions should be null
        Assert.Null(result.CardTransaction);
        Assert.Null(result.BoletoTransaction);
        Assert.Null(result.CashTransaction);
    }

    [Fact]
    public void MapToEntity_WithPixTransactionAndCustomer_ShouldMapCustomer()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetPixTransactionFields(csvRow);

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.PixTransaction);
        Assert.NotNull(result.PixTransaction.Customer);
        Assert.Equal("John Pix Customer", result.PixTransaction.Customer.Name);
        Assert.Equal("cpf", result.PixTransaction.Customer.DocumentType);
        Assert.Equal("12345678900", result.PixTransaction.Customer.Document);
        Assert.Equal("john.pix@example.com", result.PixTransaction.Customer.Email);
    }

    [Fact]
    public void MapToEntity_WithPixTransactionAndPayer_ShouldMapPayer()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetPixTransactionFields(csvRow);

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.PixTransaction);
        Assert.NotNull(result.PixTransaction.Payer);
        Assert.Equal("Jane Payer", result.PixTransaction.Payer.Name);
        Assert.Equal("cpf", result.PixTransaction.Payer.DocumentType);
        Assert.Equal("98765432100", result.PixTransaction.Payer.Document);
        Assert.Equal("12345678", result.PixTransaction.Payer.Ispb);
        Assert.Equal("Banco Exemplo", result.PixTransaction.Payer.InstitutionName);
    }

    [Fact]
    public void MapToEntity_WithPixTransactionAndTerminal_ShouldMapTerminal()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetPixTransactionFields(csvRow);

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.PixTransaction);
        Assert.NotNull(result.PixTransaction.Terminal);
        Assert.Equal("online", result.PixTransaction.Terminal.Type);
    }

    [Fact]
    public void MapToEntity_WithPixAdditionalDataAsJsonArray_ShouldMapAdditionalData()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetPixTransactionFields(csvRow);

        csvRow.SetField(
            HeaderIndex["pix_transaction__additional_data"],
            "[{\"name\":\"pedido\",\"value\":\"123\"}]"
        );

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.PixTransaction);
        Assert.NotNull(result.PixTransaction.AdditionalData);
        Assert.Single(result.PixTransaction.AdditionalData);
        Assert.Equal("pedido", result.PixTransaction.AdditionalData[0].Name);
        Assert.Equal("123", result.PixTransaction.AdditionalData[0].Value);
    }

    [Fact]
    public void MapToEntity_WithPixAdditionalDataAsJsonObject_ShouldMapAdditionalData()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetPixTransactionFields(csvRow);

        csvRow.SetField(
            HeaderIndex["pix_transaction__additional_data"],
            "{\"pedido\":\"123\",\"canal\":\"app\"}"
        );

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.PixTransaction);
        Assert.NotNull(result.PixTransaction.AdditionalData);
        Assert.Equal(2, result.PixTransaction.AdditionalData.Length);
        Assert.Contains(result.PixTransaction.AdditionalData, x => x.Name == "pedido" && x.Value == "123");
        Assert.Contains(result.PixTransaction.AdditionalData, x => x.Name == "canal" && x.Value == "app");
    }

    [Fact]
    public void MapToEntity_WithPixAdditionalDataObjectWithNonStringValues_ShouldMapRawValues()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetPixTransactionFields(csvRow);

        csvRow.SetField(
            HeaderIndex["pix_transaction__additional_data"],
            "{\"pedido\":123,\"ativo\":true}"
        );

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.PixTransaction);
        Assert.NotNull(result.PixTransaction.AdditionalData);
        Assert.Contains(result.PixTransaction.AdditionalData, x => x.Name == "pedido" && x.Value == "123");
        Assert.Contains(result.PixTransaction.AdditionalData, x => x.Name == "ativo" && x.Value == "true");
    }

    [Fact]
    public void MapToEntity_WithPixDetailsAsJsonArray_ShouldMapDetails()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetPixTransactionFields(csvRow);

        csvRow.SetField(
            HeaderIndex["pix_transaction__details"],
            "[{\"operation\":\"pay\",\"operation_id\":\"pix_det_1\",\"local_datetime\":\"2024-01-15T10:31:00Z\",\"provider_datetime\":\"2024-01-15T10:31:00Z\",\"operation_amount\":\"10000\",\"reason\":\"ok\",\"gateway_response\":{\"code\":\"00\",\"message\":\"approved\"},\"legacy\":{\"status\":\"paid\",\"transaction_status\":\"paid\",\"account_name\":\"stone\"},\"antifraud_response\":{\"provider_name\":\"af\",\"score\":\"1\",\"status\":\"approved\"},\"pgid\":\"pg_1\"}]"
        );

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.PixTransaction);
        Assert.NotNull(result.PixTransaction.Details);
        Assert.Single(result.PixTransaction.Details);
        Assert.Equal("pay", result.PixTransaction.Details[0].Operation);
        Assert.Equal("pix_det_1", result.PixTransaction.Details[0].OperationId);
        Assert.Equal(10000, result.PixTransaction.Details[0].OperationAmount);
    }

    #endregion

    #region Boleto Transaction Tests

    [Fact]
    public void MapToEntity_WithBoletoTransaction_ShouldMapSuccessfully()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetBoletoTransactionFields(csvRow);

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result);
        Assert.Equal("charge_123", result.Id);
        Assert.Equal("boleto", result.PaymentMethod);

        // Boleto Transaction
        Assert.NotNull(result.BoletoTransaction);
        Assert.Equal("registered", result.BoletoTransaction.Type);
        Assert.Equal("boleto_txn_123", result.BoletoTransaction.TransactionId);
        Assert.Equal("12345678901", result.BoletoTransaction.OurNumber);
        Assert.Equal(10000, result.BoletoTransaction.PaidAmount);
        Assert.Equal(100, result.BoletoTransaction.FineAmount);
        Assert.Equal(50, result.BoletoTransaction.InterestAmount);
        Assert.Equal(0, result.BoletoTransaction.DiscountAmount);
        Assert.Equal(0, result.BoletoTransaction.CanceledAmount);
        Assert.Equal(250, result.BoletoTransaction.FeeAmount);
        Assert.NotNull(result.BoletoTransaction.FullFeeAmount);
        Assert.Equal("2024-02-15T23:59:59Z", result.BoletoTransaction.ExpireAt);
        Assert.Equal("2024-02-20T23:59:59Z", result.BoletoTransaction.LimitDate);
        Assert.Equal("Não receber após vencimento", result.BoletoTransaction.Instructions);
        Assert.Equal("https://boleto.example.com/view/123", result.BoletoTransaction.Url);
        Assert.NotNull(result.BoletoTransaction.PaidAt);

        // Fine
        Assert.NotNull(result.BoletoTransaction.Fine);
        Assert.Equal("2024-02-16T00:00:00Z", result.BoletoTransaction.Fine.StartAt);
        Assert.Equal("percentage", result.BoletoTransaction.Fine.Type);
        Assert.Equal("2.00", result.BoletoTransaction.Fine.Value);

        // Interest
        Assert.NotNull(result.BoletoTransaction.Interest);
        Assert.Equal("daily_amount", result.BoletoTransaction.Interest.Type);
        Assert.Equal("3.33", result.BoletoTransaction.Interest.Value);

        // Other transactions should be null
        Assert.Null(result.CardTransaction);
        Assert.Null(result.PixTransaction);
        Assert.Null(result.CashTransaction);
    }

    [Fact]
    public void MapToEntity_WithBoletoTransactionAndBank_ShouldMapBank()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetBoletoTransactionFields(csvRow);

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.BoletoTransaction);
        Assert.NotNull(result.BoletoTransaction.Bank);
        Assert.Equal("237", result.BoletoTransaction.Bank.Code);
        Assert.Equal("Bradesco", result.BoletoTransaction.Bank.Name);
    }

    [Fact]
    public void MapToEntity_WithBoletoTransactionAndReceiver_ShouldMapReceiver()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetBoletoTransactionFields(csvRow);

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.BoletoTransaction);
        Assert.NotNull(result.BoletoTransaction.Receiver);
        Assert.Equal("Empresa Recebedora LTDA", result.BoletoTransaction.Receiver.Name);
        Assert.Equal("cnpj", result.BoletoTransaction.Receiver.DocumentType);
        Assert.Equal("12345678000190", result.BoletoTransaction.Receiver.Document);
    }

    [Fact]
    public void MapToEntity_WithBoletoTransactionAndCustomer_ShouldMapCustomer()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetBoletoTransactionFields(csvRow);

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.BoletoTransaction);
        Assert.NotNull(result.BoletoTransaction.Customer);
        Assert.Equal("John Boleto Customer", result.BoletoTransaction.Customer.Name);
        Assert.Equal("cpf", result.BoletoTransaction.Customer.DocumentType);
        Assert.Equal("12345678900", result.BoletoTransaction.Customer.Document);
    }

    [Fact]
    public void MapToEntity_WithBoletoTransactionBarcode_ShouldMapBarcode()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetBoletoTransactionFields(csvRow);

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.BoletoTransaction);
        Assert.Equal("12345678901234567890123456789012345678901234", result.BoletoTransaction.Barcode);
        Assert.Equal("12345.67890 12345.678901 12345.678901 1 12340000010000", result.BoletoTransaction.WritableLine);
    }

    [Fact]
    public void MapToEntity_WithBoletoDiscountsAsObject_ShouldMapDiscounts()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetBoletoTransactionFields(csvRow);

        csvRow.SetField(
            HeaderIndex["boleto_transaction__discounts"],
            "{\"expire_at\":\"2024-02-10T23:59:59Z\",\"type\":\"percentage\",\"value\":\"10\"}"
        );

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.BoletoTransaction);
        Assert.NotNull(result.BoletoTransaction.Discounts);
        Assert.Single(result.BoletoTransaction.Discounts);
        Assert.Equal("2024-02-10T23:59:59Z", result.BoletoTransaction.Discounts[0].ExpireAt);
        Assert.Equal("percentage", result.BoletoTransaction.Discounts[0].Type);
        Assert.Equal("10", result.BoletoTransaction.Discounts[0].Value);
    }

    [Fact]
    public void MapToEntity_WithBoletoDiscountsAsStringifiedJson_ShouldMapDiscounts()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetBoletoTransactionFields(csvRow);

        var discountsArrayJson =
            "[{\"expire_at\":\"2024-02-10T23:59:59Z\",\"type\":\"fixed\",\"value\":\"500\"}]";
        var stringifiedDiscountsJson = JsonSerializer.Serialize(discountsArrayJson);

        csvRow.SetField(HeaderIndex["boleto_transaction__discounts"], stringifiedDiscountsJson);

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.BoletoTransaction);
        Assert.NotNull(result.BoletoTransaction.Discounts);
        Assert.Single(result.BoletoTransaction.Discounts);
        Assert.Equal("2024-02-10T23:59:59Z", result.BoletoTransaction.Discounts[0].ExpireAt);
        Assert.Equal("fixed", result.BoletoTransaction.Discounts[0].Type);
        Assert.Equal("500", result.BoletoTransaction.Discounts[0].Value);
    }

    [Fact]
    public void MapToEntity_WithBoletoDiscountsAsSingleQuotedAndUnquotedStringValues_ShouldMapDiscounts()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetBoletoTransactionFields(csvRow);

        csvRow.SetField(
            HeaderIndex["boleto_transaction__discounts"],
            "[{'expire_at':2024-02-10T23:59:59Z,'type':fixed,'value':500}]"
        );

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.BoletoTransaction);
        Assert.NotNull(result.BoletoTransaction.Discounts);
        Assert.Single(result.BoletoTransaction.Discounts);
        Assert.Equal("2024-02-10T23:59:59Z", result.BoletoTransaction.Discounts[0].ExpireAt);
        Assert.Equal("fixed", result.BoletoTransaction.Discounts[0].Type);
        Assert.Equal("500", result.BoletoTransaction.Discounts[0].Value);
    }

    [Fact]
    public void MapToEntity_WithBoletoDetailsAsJsonArray_ShouldMapDetails()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetBoletoTransactionFields(csvRow);

        csvRow.SetField(
            HeaderIndex["boleto_transaction__details"],
            "[{\"operation\":\"pay\",\"operation_id\":\"bol_det_1\",\"provider_datetime\":\"2024-01-15T10:31:00Z\",\"local_datetime\":\"2024-01-15T10:31:00Z\",\"operation_amount\":\"10000\",\"reason\":\"ok\",\"operation_status\":\"success\",\"pgid\":\"pg_1\"}]"
        );

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.BoletoTransaction);
        Assert.NotNull(result.BoletoTransaction.Details);
        Assert.Single(result.BoletoTransaction.Details);
        Assert.Equal("pay", result.BoletoTransaction.Details[0].Operation);
        Assert.Equal("bol_det_1", result.BoletoTransaction.Details[0].OperationId);
    }

    [Fact]
    public void MapToEntity_WithBoletoDetailsNestedJson_ShouldMapNestedObjects()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetBoletoTransactionFields(csvRow);

        csvRow.SetField(
            HeaderIndex["boleto_transaction__details"],
            "[{\"operation\":\"pay\",\"operation_id\":\"bol_det_nested\",\"provider_datetime\":\"2024-01-15T10:31:00Z\",\"local_datetime\":\"2024-01-15T10:31:00Z\",\"operation_amount\":\"10000\",\"reason\":\"ok\",\"operation_status\":\"success\",\"gateway_response\":{\"code\":\"00\",\"message\":\"approved\"},\"legacy\":{\"status\":\"paid\",\"transaction_status\":\"paid\",\"account_name\":\"stone\"},\"antifraud_response\":{\"provider_name\":\"af\",\"score\":\"1\",\"status\":\"approved\"},\"pgid\":\"pg_nested\"}]"
        );

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.BoletoTransaction);
        Assert.NotNull(result.BoletoTransaction.Details);
        Assert.Single(result.BoletoTransaction.Details);
        Assert.NotNull(result.BoletoTransaction.Details[0].GatewayResponse);
        Assert.NotNull(result.BoletoTransaction.Details[0].Legacy);
        Assert.NotNull(result.BoletoTransaction.Details[0].AntifraudResponse);
    }

    #endregion

    #region Cash Transaction Tests

    [Fact]
    public void MapToEntity_WithCashTransaction_ShouldMapSuccessfully()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCashTransactionFields(csvRow);

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result);
        Assert.Equal("charge_123", result.Id);
        Assert.Equal("cash", result.PaymentMethod);

        // Cash Transaction
        Assert.NotNull(result.CashTransaction);
        Assert.Equal("Pagamento em dinheiro", result.CashTransaction.Description);
        Assert.Equal("cash_txn_123", result.CashTransaction.TransactionId);
        Assert.Equal(10000, result.CashTransaction.PaidAmount);
        Assert.Equal(0, result.CashTransaction.CanceledAmount);

        // Other transactions should be null
        Assert.Null(result.CardTransaction);
        Assert.Null(result.PixTransaction);
        Assert.Null(result.BoletoTransaction);
    }

    [Fact]
    public void MapToEntity_WithCashTransactionAndCustomer_ShouldMapCustomer()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCashTransactionFields(csvRow);

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.CashTransaction);
        Assert.NotNull(result.CashTransaction.Customer);
        Assert.Equal("John Cash Customer", result.CashTransaction.Customer.Name);
        Assert.Equal("cpf", result.CashTransaction.Customer.DocumentType);
        Assert.Equal("12345678900", result.CashTransaction.Customer.Document);
    }

    [Fact]
    public void MapToEntity_WithCashTransactionAndLast_ShouldMapLast()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCashTransactionFields(csvRow);

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.CashTransaction);
        Assert.NotNull(result.CashTransaction.Last);
        Assert.Equal("paid", result.CashTransaction.Last.OperationStatus);
        Assert.Equal("paid", result.CashTransaction.Last.LegacyStatus);
    }

    [Fact]
    public void MapToEntity_WithCashDetailsAsJsonArray_ShouldMapDetails()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCashTransactionFields(csvRow);

        csvRow.SetField(
            HeaderIndex["cash_transaction__details"],
            "[{\"operation\":\"pay\",\"operation_id\":\"cash_det_1\",\"local_datetime\":\"2024-01-15T10:31:00Z\",\"provider_datetime\":\"2024-01-15T10:31:00Z\",\"operation_amount\":\"10000\",\"operation_reason\":\"ok\",\"operation_status\":\"success\",\"pgid\":\"pg_1\"}]"
        );

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.CashTransaction);
        Assert.NotNull(result.CashTransaction.Details);
        Assert.Single(result.CashTransaction.Details);
        Assert.Equal("pay", result.CashTransaction.Details[0].Operation);
        Assert.Equal("cash_det_1", result.CashTransaction.Details[0].OperationId);
    }

    #endregion

    #region Metadata Tests

    [Fact]
    public void MapToEntity_WithMetadata_ShouldMapMetadata()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);

        var metadataJson = JsonSerializer.Serialize(new Dictionary<string, string>
        {
            { "custom_field_1", "value_1" },
            { "custom_field_2", "value_2" }
        });
        csvRow.SetField(HeaderIndex["metadata"], metadataJson);

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.Metadata);
        Assert.Equal(2, result.Metadata.Count);
        Assert.Equal("value_1", result.Metadata["custom_field_1"]);
        Assert.Equal("value_2", result.Metadata["custom_field_2"]);
    }

    [Fact]
    public void MapToEntity_WithNullMetadata_ShouldReturnNullMetadata()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);
        csvRow.SetField(HeaderIndex["metadata"], null);

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.Null(result.Metadata);
    }

    [Fact]
    public void MapToEntity_WithInvalidMetadata_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);
        csvRow.SetField(HeaderIndex["metadata"], "{invalid-json}");

        // Act
        var ex = Assert.Throws<InvalidOperationException>(() => ChargeEntityMapper.MapToEntity(csvRow));

        // Assert
        Assert.Equal("Failed to parse Metadata JSON.", ex.Message);
    }

    [Fact]
    public void MapToEntity_WithMetadataNonStringValues_ShouldMapAsEmptyStrings()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);
        csvRow.SetField(HeaderIndex["metadata"], "{\"flag\":true,\"count\":10}");

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.Metadata);
        Assert.Equal("true", result.Metadata["flag"]);
        Assert.Equal("10", result.Metadata["count"]);
    }

    [Fact]
    public void MapToEntity_WithMetadataAsSingleQuotedAndUnquotedStringValues_ShouldMapMetadata()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);
        csvRow.SetField(HeaderIndex["metadata"], "{'origin':worker,'flow':charge_list,'active':true}");

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.Metadata);
        Assert.Equal("worker", result.Metadata["origin"]);
        Assert.Equal("charge_list", result.Metadata["flow"]);
        Assert.Equal("true", result.Metadata["active"]);
    }

    #endregion

    #region Base Fields Tests

    [Fact]
    public void MapToEntity_WithAllBaseFields_ShouldMapCorrectly()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.Equal("charge_123", result.Id);
        Assert.Equal("initiator_456", result.InitiatorId);
        Assert.Equal("payment", result.Product);
        Assert.Equal("api", result.Origin);
        Assert.Equal("origin_789", result.OriginId);
        Assert.Equal(10000, result.Amount);
        Assert.Equal(10000, result.UpdatedAmount);
        Assert.Equal(9800, result.NetAmount);
        Assert.Equal(98.00m, result.FullNetAmount);
        Assert.Equal("paid", result.Status);
        Assert.Equal("card", result.PaymentMethod);
        Assert.Equal(DateTime.Parse("2024-01-15T10:30:00Z"), result.CreatedAt);
        Assert.Equal("stone", result.PlatformName);
        Assert.Equal(1, result.AttemptCount);
        Assert.Equal("stone_gateway", result.Gateway);
        Assert.Equal("order_123", result.GatewayOrderId);
        Assert.Equal("CODE123", result.Code);
        Assert.Equal("id1,id2,id3", result.AllIds);
        Assert.Equal("charge_external_123", result.ChargeId);
        Assert.Equal("pos", result.PointOfInteractionType);
    }

    [Fact]
    public void MapToEntity_WithMerchant_ShouldMapMerchantFields()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.Merchant);
        Assert.Equal("stone", result.Merchant.Organization);
        Assert.Equal("12345678000190", result.Merchant.Document);
        Assert.Equal("user_123", result.Merchant.UserId);
        Assert.Equal("aff_key_123", result.Merchant.AffiliationKey);
        Assert.Equal("aff_code_456", result.Merchant.AffiliationCode);
        Assert.Equal("acc_789", result.Merchant.AccountId);
        Assert.Equal("merch_012", result.Merchant.MerchantId);
    }

    [Fact]
    public void MapToEntity_WithSplitAsJsonArray_ShouldMapSplit()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);

        csvRow.SetField(
            HeaderIndex["split"],
            "[{\"id\":\"split_1\",\"recipient_id\":\"recipient_1\",\"gateway_recipient_id\":\"gateway_1\"}]"
        );

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.Split);
        Assert.Single(result.Split);
        Assert.Equal("split_1", result.Split[0].Id);
        Assert.Equal("recipient_1", result.Split[0].RecipientId);
        Assert.Equal("gateway_1", result.Split[0].GatewayRecipientId);
    }

    [Fact]
    public void MapToEntity_WithSplitAsJsonObject_ShouldMapSplit()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);

        csvRow.SetField(
            HeaderIndex["split"],
            "{\"id\":\"split_1\",\"recipient_id\":\"recipient_1\",\"gateway_recipient_id\":\"gateway_1\"}"
        );

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.Split);
        Assert.Single(result.Split);
        Assert.Equal("split_1", result.Split[0].Id);
    }

    [Fact]
    public void MapToEntity_WithSplitAsStringifiedJsonArray_ShouldMapSplit()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);

        var splitArrayJson =
            "[{\"id\":\"split_1\",\"recipient_id\":\"recipient_1\",\"gateway_recipient_id\":\"gateway_1\"}]";
        csvRow.SetField(HeaderIndex["split"], JsonSerializer.Serialize(splitArrayJson));

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.Split);
        Assert.Single(result.Split);
        Assert.Equal("split_1", result.Split[0].Id);
    }

    [Fact]
    public void MapToEntity_WithSplitAsStringifiedSingleQuotedJsonArray_ShouldMapSplit()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);

        var singleQuotedJson = "[{'id':'split_1','recipient_id':'recipient_1','gateway_recipient_id':'gateway_1'}]";
        csvRow.SetField(HeaderIndex["split"], JsonSerializer.Serialize(singleQuotedJson));

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.Split);
        Assert.Single(result.Split);
        Assert.Equal("split_1", result.Split[0].Id);
        Assert.Equal("recipient_1", result.Split[0].RecipientId);
        Assert.Equal("gateway_1", result.Split[0].GatewayRecipientId);
    }

    [Fact]
    public void MapToEntity_WithSplitAsSingleQuotedAndUnquotedStringValues_ShouldMapSplit()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);

        csvRow.SetField(
            HeaderIndex["split"],
            "[{'id':split_1,'recipient_id':recipient_1,'gateway_recipient_id':gateway_1}]"
        );

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.Split);
        Assert.Single(result.Split);
        Assert.Equal("split_1", result.Split[0].Id);
        Assert.Equal("recipient_1", result.Split[0].RecipientId);
        Assert.Equal("gateway_1", result.Split[0].GatewayRecipientId);
    }

    [Fact]
    public void MapToEntity_WithSplitAsPrimitiveJson_ShouldReturnNullSplit()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);
        csvRow.SetField(HeaderIndex["split"], "1");

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.Null(result.Split);
    }

    #endregion

    #region Decimal Parsing Tests

    [Fact]
    public void NormalizeUnquotedStringValues_WithInvariantDecimalInPtBrCulture_ShouldKeepNumberUnquoted()
    {
        // Arrange
        var originalCulture = CultureInfo.CurrentCulture;
        var originalUiCulture = CultureInfo.CurrentUICulture;

        try
        {
            CultureInfo.CurrentCulture = new CultureInfo("pt-BR");
            CultureInfo.CurrentUICulture = new CultureInfo("pt-BR");

            var method = typeof(ChargeEntityMapper).GetMethod(
                "NormalizeUnquotedStringValues",
                BindingFlags.NonPublic | BindingFlags.Static
            );

            Assert.NotNull(method);

            // Act
            var normalized = (string?)method!.Invoke(null, ["{\"amount\":2.5,\"name\":abc}"]);

            // Assert
            Assert.NotNull(normalized);
            Assert.Contains("\"amount\":2.5", normalized);
            Assert.Contains("\"name\":\"abc\"", normalized);
        }
        finally
        {
            CultureInfo.CurrentCulture = originalCulture;
            CultureInfo.CurrentUICulture = originalUiCulture;
        }
    }

    [Fact]
    public void MapToEntity_WithIntegerAmounts_ShouldParseCorrectly()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.CardTransaction);
        // Fee amount e mdr amount são int
        Assert.Equal(200, result.CardTransaction.FeeAmount);
        Assert.Equal(150, result.CardTransaction.MdrAmount);
        // Full amounts são decimal parseados das strings
        // Mas o CsvRow converte valores para string então "2.00" vira 2
        Assert.NotNull(result.CardTransaction.FullFeeAmount);
        Assert.NotNull(result.CardTransaction.FullMdrAmount);
    }

    #endregion

    #region Null/Empty Values Tests

    [Fact]
    public void MapToEntity_WithNullOptionalFields_ShouldHandleGracefully()
    {
        // Arrange
        var csvRow = new CsvRow(HeaderIndex.Count);

        // Campos base obrigatórios
        csvRow.SetField(HeaderIndex["id"], "charge_123");
        csvRow.SetField(HeaderIndex["initiator_id"], "initiator_456");
        csvRow.SetField(HeaderIndex["product"], null);
        csvRow.SetField(HeaderIndex["origin"], null);
        csvRow.SetField(HeaderIndex["origin_id"], null);
        csvRow.SetField(HeaderIndex["amount"], 10000);
        csvRow.SetField(HeaderIndex["updated_amount"], 10000);
        csvRow.SetField(HeaderIndex["net_amount"], 9800);
        csvRow.SetField(HeaderIndex["full_net_amount"], "98.00");
        csvRow.SetField(HeaderIndex["status"], "paid");
        csvRow.SetField(HeaderIndex["payment_method"], "card");
        csvRow.SetField(HeaderIndex["created_at"], DateTime.Parse("2024-01-15T10:30:00Z"));
        csvRow.SetField(HeaderIndex["gateway"], null);

        // Merchant obrigatório
        csvRow.SetField(HeaderIndex["merchant__organization"], "stone");
        csvRow.SetField(HeaderIndex["merchant__document"], "12345678000190");
        csvRow.SetField(HeaderIndex["merchant__user_id"], "user_123");
        csvRow.SetField(HeaderIndex["merchant__affiliation_key"], "aff_key_123");
        csvRow.SetField(HeaderIndex["merchant__affiliation_code"], "aff_code_456");
        csvRow.SetField(HeaderIndex["merchant__account_id"], "acc_789");
        csvRow.SetField(HeaderIndex["merchant__merchant_id"], "merch_012");

        SetCardTransactionFields(csvRow);

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result);
        Assert.Null(result.Product);
        Assert.Null(result.Origin);
        Assert.Null(result.Gateway);
    }

    [Fact]
    public void MapToEntity_WithInvalidSplitJson_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);
        csvRow.SetField(HeaderIndex["split"], "{invalid-json}");

        // Act
        var ex = Assert.Throws<InvalidOperationException>(() => ChargeEntityMapper.MapToEntity(csvRow));

        // Assert
        Assert.Equal("Failed to parse split JSON.", ex.Message);
    }

    [Fact]
    public void MapToEntity_WithInvalidCardDetailsJson_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);
        csvRow.SetField(HeaderIndex["card_transaction__details"], "{invalid-json}");

        // Act
        var ex = Assert.Throws<InvalidOperationException>(() => ChargeEntityMapper.MapToEntity(csvRow));

        // Assert
        Assert.Equal("Failed to parse card details JSON.", ex.Message);
    }

    [Fact]
    public void MapToEntity_WithInvalidBoletoDetailsJson_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetBoletoTransactionFields(csvRow);
        csvRow.SetField(HeaderIndex["boleto_transaction__details"], "{invalid-json}");

        // Act
        var ex = Assert.Throws<InvalidOperationException>(() => ChargeEntityMapper.MapToEntity(csvRow));

        // Assert
        Assert.Equal("Failed to parse boleto details JSON.", ex.Message);
    }

    [Fact]
    public void MapToEntity_WithInvalidCashDetailsJson_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCashTransactionFields(csvRow);
        csvRow.SetField(HeaderIndex["cash_transaction__details"], "{invalid-json}");

        // Act
        var ex = Assert.Throws<InvalidOperationException>(() => ChargeEntityMapper.MapToEntity(csvRow));

        // Assert
        Assert.Equal("Failed to parse cash details JSON.", ex.Message);
    }

    [Fact]
    public void MapToEntity_WithInvalidPixDetailsJson_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetPixTransactionFields(csvRow);
        csvRow.SetField(HeaderIndex["pix_transaction__details"], "{invalid-json}");

        // Act
        var ex = Assert.Throws<InvalidOperationException>(() => ChargeEntityMapper.MapToEntity(csvRow));

        // Assert
        Assert.Equal("Failed to parse pix details JSON.", ex.Message);
    }

    [Fact]
    public void MapToEntity_WithInvalidPixAdditionalDataJson_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetPixTransactionFields(csvRow);
        csvRow.SetField(HeaderIndex["pix_transaction__additional_data"], "{invalid-json}");

        // Act
        var ex = Assert.Throws<InvalidOperationException>(() => ChargeEntityMapper.MapToEntity(csvRow));

        // Assert
        Assert.Equal("Failed to parse Pix Additional Data JSON.", ex.Message);
    }

    [Fact]
    public void MapToEntity_WithInvalidCardFinancialMovementsJson_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);
        csvRow.SetField(HeaderIndex["card_transaction__financial_movements"], "{invalid-json}");

        // Act
        var ex = Assert.Throws<InvalidOperationException>(() => ChargeEntityMapper.MapToEntity(csvRow));

        // Assert
        Assert.Equal("Failed to parse card financial movement JSON.", ex.Message);
    }

    [Fact]
    public void MapToEntity_WithCardDetailsAsJsonObject_ShouldMapDetails()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);

        csvRow.SetField(
            HeaderIndex["card_transaction__details"],
            "{\"operation\":\"capture\",\"operation_id\":\"op_obj\",\"operation_amount\":\"10000\",\"provider_datetime\":\"2024-01-15T10:31:00Z\",\"local_datetime\":\"2024-01-15T10:31:00Z\"}"
        );

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.CardTransaction);
        Assert.NotNull(result.CardTransaction.Details);
        Assert.Single(result.CardTransaction.Details);

        var detail = result.CardTransaction.Details[0];
        Assert.Equal("capture", detail.Operation);
        Assert.Equal("op_obj", detail.OperationId);
        Assert.Equal(10000, detail.OperationAmount);
    }

    [Fact]
    public void MapToEntity_WithPaymentMethodUnknown_ShouldKeepTransactionsNull()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        csvRow.SetField(HeaderIndex["payment_method"], "voucher");

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.Null(result.CardTransaction);
        Assert.Null(result.PixTransaction);
        Assert.Null(result.BoletoTransaction);
        Assert.Null(result.CashTransaction);
    }

    #endregion

    #region Pix Financial Movements Tests

    [Fact]
    public void MapToEntity_WithPixFinancialMovementsAsJsonArray_ShouldMapFinancialMovements()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetPixTransactionFields(csvRow);

        csvRow.SetField(
            HeaderIndex["pix_transaction__financial_movements"],
            "[{\"operation\":\"payment\",\"operation_id\":\"pix_fm_1\",\"detail_operation_id\":\"det_op_1\",\"current_due_date\":\"2024-01-20\",\"original_due_date\":\"2024-01-18\",\"payment_owner_document\":\"12345678900\",\"settlement_status\":\"settled\",\"category\":\"pix_payment\",\"installment_number\":\"1\",\"amount\":{\"gross\":\"10000\",\"net\":\"9700\",\"discount_rate\":{\"fee_type\":\"mdr\",\"fee\":\"1.5\",\"effective_fee\":\"1.4\",\"amount\":\"150\"},\"prepayment_fee\":{\"fee_type\":\"pre\",\"fee\":\"0.5\",\"effective_fee\":\"0.4\",\"amount\":\"50\"},\"fraud_coverage\":{\"fee_type\":\"fc\",\"fee\":\"0.3\",\"effective_fee\":\"0.2\",\"amount\":\"30\"}},\"id\":\"fm_id_1\",\"payment_method\":\"pix\",\"split_rule_id\":\"sr_1\",\"bulk_anticipation_id\":\"ba_1\",\"payment_owner_id\":\"po_1\",\"recipient_id\":\"rec_1\",\"payment_owner_stone_account\":\"sa_1\",\"created_at\":\"2024-01-15T10:30:00Z\",\"latest_event_datetime\":\"2024-01-15T10:35:00Z\"}]"
        );

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.PixTransaction);
        Assert.NotNull(result.PixTransaction.FinancialMovements);
        Assert.Single(result.PixTransaction.FinancialMovements);

        var fm = result.PixTransaction.FinancialMovements[0];
        Assert.Equal("payment", fm.Operation);
        Assert.Equal("pix_fm_1", fm.OperationId);
        Assert.Equal("det_op_1", fm.DetailOperationId);
        Assert.Equal(new DateOnly(2024, 1, 20), fm.CurrentDueDate);
        Assert.Equal(new DateOnly(2024, 1, 18), fm.OriginalDueDate);
        Assert.Equal("12345678900", fm.PaymentOwnerDocument);
        Assert.Equal("settled", fm.SettlementStatus);
        Assert.Equal("pix_payment", fm.Category);
        Assert.Equal((short)1, fm.InstallmentNumber);
        Assert.Equal("fm_id_1", fm.Id);
        Assert.Equal("pix", fm.PaymentMethod);
        Assert.Equal("sr_1", fm.SplitRuleId);
        Assert.Equal("ba_1", fm.BulkAnticipationId);
        Assert.Equal("po_1", fm.PaymentOwnerId);
        Assert.Equal("rec_1", fm.RecipientId);
        Assert.Equal("sa_1", fm.PaymentOwnerStoneAccount);
        Assert.NotNull(fm.CreatedAt);
        Assert.NotNull(fm.LatestEventDatetime);

        // Amount
        Assert.NotNull(fm.Amount);
        Assert.Equal(10000m, fm.Amount!.Gross);
        Assert.Equal(9700m, fm.Amount.Net);

        // Nested fees
        Assert.NotNull(fm.Amount.DiscountRate);
        Assert.Equal("mdr", fm.Amount.DiscountRate!.FeeType);
        Assert.Equal(150m, fm.Amount.DiscountRate.Amount);

        Assert.NotNull(fm.Amount.PrepaymentFee);
        Assert.Equal("pre", fm.Amount.PrepaymentFee!.FeeType);
        Assert.Equal(50m, fm.Amount.PrepaymentFee.Amount);

        Assert.NotNull(fm.Amount.FraudCoverage);
        Assert.Equal("fc", fm.Amount.FraudCoverage!.FeeType);
        Assert.Equal(30m, fm.Amount.FraudCoverage.Amount);
    }

    #endregion

    #region Boleto Financial Movements Tests

    [Fact]
    public void MapToEntity_WithBoletoFinancialMovementsAsJsonArray_ShouldMapFinancialMovements()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetBoletoTransactionFields(csvRow);

        csvRow.SetField(
            HeaderIndex["boleto_transaction__financial_movements"],
            "[{\"operation\":\"payment\",\"operation_id\":\"bol_fm_1\",\"installment_number\":\"1\",\"amount\":{\"gross\":\"10000\",\"net\":\"9750\"}}]"
        );

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.BoletoTransaction);
        Assert.NotNull(result.BoletoTransaction.FinancialMovements);
        Assert.Single(result.BoletoTransaction.FinancialMovements);
        Assert.Equal("payment", result.BoletoTransaction.FinancialMovements[0].Operation);
        Assert.Equal("bol_fm_1", result.BoletoTransaction.FinancialMovements[0].OperationId);
        Assert.NotNull(result.BoletoTransaction.FinancialMovements[0].Amount);
        Assert.Equal(10000m, result.BoletoTransaction.FinancialMovements[0].Amount!.Gross);
        Assert.Equal(9750m, result.BoletoTransaction.FinancialMovements[0].Amount.Net);
    }

    [Fact]
    public void MapToEntity_WithInvalidBoletoFinancialMovementsJson_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetBoletoTransactionFields(csvRow);
        csvRow.SetField(HeaderIndex["boleto_transaction__financial_movements"], "{invalid-json}");

        // Act
        var ex = Assert.Throws<InvalidOperationException>(() => ChargeEntityMapper.MapToEntity(csvRow));

        // Assert
        Assert.Equal("Failed to parse card financial movement JSON.", ex.Message);
    }

    [Fact]
    public void MapToEntity_WithInvalidPixFinancialMovementsJson_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetPixTransactionFields(csvRow);
        csvRow.SetField(HeaderIndex["pix_transaction__financial_movements"], "{invalid-json}");

        // Act
        var ex = Assert.Throws<InvalidOperationException>(() => ChargeEntityMapper.MapToEntity(csvRow));

        // Assert
        Assert.Equal("Failed to parse card financial movement JSON.", ex.Message);
    }

    #endregion

    #region Boleto Discounts Additional Tests

    [Fact]
    public void MapToEntity_WithBoletoDiscountsAsArray_ShouldMapMultipleDiscounts()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetBoletoTransactionFields(csvRow);

        csvRow.SetField(
            HeaderIndex["boleto_transaction__discounts"],
            "[{\"expire_at\":\"2024-02-10T23:59:59Z\",\"type\":\"percentage\",\"value\":\"10\"},{\"expire_at\":\"2024-02-12T23:59:59Z\",\"type\":\"fixed\",\"value\":\"500\"}]"
        );

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.BoletoTransaction);
        Assert.NotNull(result.BoletoTransaction.Discounts);
        Assert.Equal(2, result.BoletoTransaction.Discounts.Length);
        Assert.Equal("percentage", result.BoletoTransaction.Discounts[0].Type);
        Assert.Equal("10", result.BoletoTransaction.Discounts[0].Value);
        Assert.Equal("fixed", result.BoletoTransaction.Discounts[1].Type);
        Assert.Equal("500", result.BoletoTransaction.Discounts[1].Value);
    }

    [Fact]
    public void MapToEntity_WithBoletoDiscountsAsStringifiedEmptyArray_ShouldReturnNull()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetBoletoTransactionFields(csvRow);

        // Simula double-stringified "[]" → "\"[]\""
        csvRow.SetField(HeaderIndex["boleto_transaction__discounts"], JsonSerializer.Serialize("[]"));

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.BoletoTransaction);
        Assert.Null(result.BoletoTransaction.Discounts);
    }

    [Fact]
    public void MapToEntity_WithInvalidBoletoDiscountsJson_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetBoletoTransactionFields(csvRow);
        csvRow.SetField(HeaderIndex["boleto_transaction__discounts"], "{invalid-json}");

        // Act
        var ex = Assert.Throws<InvalidOperationException>(() => ChargeEntityMapper.MapToEntity(csvRow));

        // Assert
        Assert.Equal("Failed to parse Boleto Discounts JSON.", ex.Message);
    }

    #endregion

    #region Card Detail Extended Tests

    [Fact]
    public void MapToEntity_WithCardDetailAllOptionalFields_ShouldMapAllFields()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);

        csvRow.SetField(
            HeaderIndex["card_transaction__details"],
            "[{\"operation\":\"capture\",\"operation_id\":\"op_full\",\"operation_amount\":\"10000\",\"provider_datetime\":\"2024-01-15T10:31:00Z\",\"local_datetime\":\"2024-01-15T10:31:00Z\",\"acquirer_message\":\"Transação aprovada\",\"acquirer_return_code\":\"00\",\"operation_reason\":\"approved\",\"pgid\":\"pg_full_1\",\"operation_status\":\"success\",\"acquirer\":{\"name\":\"stone\",\"nsu\":\"123456\",\"tid\":\"tid_789\"},\"gateway_response\":{\"code\":\"00\",\"message\":\"approved\"},\"antifraud_response\":{\"provider_name\":\"clearsale\",\"score\":\"95\",\"status\":\"approved\"},\"legacy\":{\"status\":\"paid\",\"operation\":\"capture\",\"transaction_status\":\"captured\",\"canceled_amount\":100,\"account_name\":\"stone_account\"}}]"
        );

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.CardTransaction);
        Assert.NotNull(result.CardTransaction.Details);
        Assert.Single(result.CardTransaction.Details);

        var detail = result.CardTransaction.Details[0];
        Assert.Equal("capture", detail.Operation);
        Assert.Equal("op_full", detail.OperationId);
        Assert.Equal(10000, detail.OperationAmount);
        Assert.Equal("Transação aprovada", detail.AcquirerMessage);
        Assert.Equal("00", detail.AcquirerReturnCode);
        Assert.Equal("approved", detail.OperationReason);
        Assert.Equal("pg_full_1", detail.Pgid);
        Assert.Equal("success", detail.OperationStatus);

        // Acquirer
        Assert.NotNull(detail.Acquirer);
        Assert.Equal("stone", detail.Acquirer!.Name);
        Assert.Equal("123456", detail.Acquirer.Nsu);
        Assert.Equal("tid_789", detail.Acquirer.Tid);

        // GatewayResponse
        Assert.NotNull(detail.GatewayResponse);
        Assert.Equal("00", detail.GatewayResponse!.Code);
        Assert.Equal("approved", detail.GatewayResponse.Message);

        // AntifraudResponse
        Assert.NotNull(detail.AntifraudResponse);
        Assert.Equal("clearsale", detail.AntifraudResponse!.ProviderName);
        Assert.Equal("95", detail.AntifraudResponse.Score);
        Assert.Equal("approved", detail.AntifraudResponse.Status);

        // Legacy (with canceled_amount as number)
        Assert.NotNull(detail.Legacy);
        Assert.Equal("paid", detail.Legacy!.Status);
        Assert.Equal("capture", detail.Legacy.Operation);
        Assert.Equal("captured", detail.Legacy.TransactionStatus);
        Assert.Equal(100, detail.Legacy.CanceledAmount);
        Assert.Equal("stone_account", detail.Legacy.AccountName);
    }

    #endregion

    #region Pix Detail Extended Tests

    [Fact]
    public void MapToEntity_WithPixDetailsAllOptionalFields_ShouldMapOptionalFields()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetPixTransactionFields(csvRow);

        csvRow.SetField(
            HeaderIndex["pix_transaction__details"],
            "[{\"operation\":\"pay\",\"operation_id\":\"pix_det_full\",\"local_datetime\":\"2024-01-15T10:31:00Z\",\"provider_datetime\":\"2024-01-15T10:31:00Z\",\"operation_amount\":\"10000\",\"qrcode_content\":\"00020126580014br.gov.bcb.pix\",\"description\":\"Pagamento PIX\",\"refund_id\":\"ref_123\",\"reason\":\"pagamento efetuado\",\"pgid\":\"pg_pix_1\"}]"
        );

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.PixTransaction);
        Assert.NotNull(result.PixTransaction.Details);
        Assert.Single(result.PixTransaction.Details);

        var detail = result.PixTransaction.Details[0];
        Assert.Equal("pix_det_full", detail.OperationId);
        Assert.Equal("00020126580014br.gov.bcb.pix", detail.QrcodeContent);
        Assert.Equal("Pagamento PIX", detail.Description);
        Assert.Equal("ref_123", detail.RefundId);
        Assert.Equal("pagamento efetuado", detail.Reason);
        Assert.Equal("pg_pix_1", detail.Pgid);
    }

    #endregion

    #region Cash Detail Extended Tests

    [Fact]
    public void MapToEntity_WithCashDetailsAndLegacy_ShouldMapLegacy()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCashTransactionFields(csvRow);

        csvRow.SetField(
            HeaderIndex["cash_transaction__details"],
            "[{\"operation\":\"pay\",\"operation_id\":\"cash_det_leg\",\"local_datetime\":\"2024-01-15T10:31:00Z\",\"provider_datetime\":\"2024-01-15T10:31:00Z\",\"operation_amount\":\"10000\",\"operation_reason\":\"ok\",\"legacy\":{\"status\":\"paid\",\"transaction_status\":\"paid\",\"account_name\":\"stone\"},\"operation_status\":\"success\",\"pgid\":\"pg_cash_1\"}]"
        );

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.CashTransaction);
        Assert.NotNull(result.CashTransaction.Details);
        Assert.Single(result.CashTransaction.Details);

        var detail = result.CashTransaction.Details[0];
        Assert.NotNull(detail.Legacy);
        Assert.Equal("paid", detail.Legacy!.Status);
        Assert.Equal("paid", detail.Legacy.TransactionStatus);
        Assert.Equal("stone", detail.Legacy.AccountName);
        Assert.Equal("success", detail.OperationStatus);
        Assert.Equal("pg_cash_1", detail.Pgid);
    }

    #endregion

    #region Empty/Edge Cases Tests

    [Fact]
    public void MapToEntity_WithEmptyMetadata_ShouldReturnNull()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);
        csvRow.SetField(HeaderIndex["metadata"], "");

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.Null(result.Metadata);
    }

    [Fact]
    public void MapToEntity_WithPixDiscountsKeyNotInHeader_ShouldReturnNullDiscounts()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetPixTransactionFields(csvRow);

        // pix_transaction__discounts não existe no HeaderIndex
        // GetField usa TryGetValue → retorna null → GetPixDiscounts retorna null
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.PixTransaction);
        Assert.Null(result.PixTransaction.Discounts);
    }

    [Fact]
    public void MapToEntity_WithCardDetailNonStringJsonValues_ShouldHandleAllValueKinds()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);

        // JSON com propriedades de tipos variados: true, false, null, number, array
        // Testa todos os branches do switch em GetJsonString (String, Number, True, False, Null, default)
        csvRow.SetField(
            HeaderIndex["card_transaction__details"],
            "[{\"operation\":\"capture\",\"operation_id\":\"op_types\",\"operation_amount\":\"10000\",\"provider_datetime\":\"2024-01-15T10:31:00Z\",\"local_datetime\":\"2024-01-15T10:31:00Z\",\"operation_status\":true,\"acquirer_message\":null,\"pgid\":[1,2],\"acquirer_return_code\":false,\"operation_reason\":99}]"
        );

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.CardTransaction);
        Assert.NotNull(result.CardTransaction.Details);
        Assert.Single(result.CardTransaction.Details);

        var detail = result.CardTransaction.Details[0];
        Assert.Equal("true", detail.OperationStatus);
        Assert.Null(detail.AcquirerMessage);
        Assert.Equal("[1,2]", detail.Pgid);
        Assert.Equal("false", detail.AcquirerReturnCode);
        Assert.Equal("99", detail.OperationReason);
    }

    [Fact]
    public void MapToEntity_WithSplitAsEmptyString_ShouldReturnNullSplit()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);
        csvRow.SetField(HeaderIndex["split"], "");

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.Null(result.Split);
    }

    [Fact]
    public void MapToEntity_WithSplitAsStringifiedWhitespace_ShouldReturnNullSplit()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);

        // Simula double-stringified whitespace: "\"  \""
        csvRow.SetField(HeaderIndex["split"], JsonSerializer.Serialize("  "));

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.Null(result.Split);
    }

    [Fact]
    public void MapToEntity_WithSplitAsNonStringObject_ShouldReturnNullSplit()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);

        // Objeto não-string: int, que será serializado via JsonSerializer.Serialize(fieldValue)
        csvRow.SetField(HeaderIndex["split"], 42);

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.Null(result.Split);
    }

    [Fact]
    public void MapToEntity_WithCardDetailContainingNullElement_ShouldHandleGracefully()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);

        // Array com elemento null seguido de objeto válido: testa GetJsonString/GetJsonElement com null element
        csvRow.SetField(
            HeaderIndex["card_transaction__details"],
            "[null,{\"operation\":\"capture\",\"operation_id\":\"op_valid\",\"operation_amount\":\"5000\",\"provider_datetime\":\"2024-01-15T10:31:00Z\",\"local_datetime\":\"2024-01-15T10:31:00Z\"}]"
        );

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.CardTransaction);
        Assert.NotNull(result.CardTransaction.Details);
        Assert.Equal(2, result.CardTransaction.Details.Count);

        // Primeiro detail vem do null element - campos ficam nulos/default
        var nullDetail = result.CardTransaction.Details[0];
        Assert.Null(nullDetail.OperationStatus);
        Assert.Null(nullDetail.Acquirer);
        Assert.Null(nullDetail.GatewayResponse);
        Assert.Null(nullDetail.AntifraudResponse);
        Assert.Null(nullDetail.Legacy);

        // Segundo detail é válido
        Assert.Equal("capture", result.CardTransaction.Details[1].Operation);
        Assert.Equal("op_valid", result.CardTransaction.Details[1].OperationId);
    }

    [Fact]
    public void MapToEntity_WithPixDetailContainingNullElement_ShouldHandleGracefully()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetPixTransactionFields(csvRow);

        csvRow.SetField(
            HeaderIndex["pix_transaction__details"],
            "[null,{\"operation\":\"pay\",\"operation_id\":\"pix_valid\",\"local_datetime\":\"2024-01-15T10:31:00Z\",\"provider_datetime\":\"2024-01-15T10:31:00Z\",\"operation_amount\":\"5000\"}]"
        );

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.PixTransaction);
        Assert.NotNull(result.PixTransaction.Details);
        Assert.Equal(2, result.PixTransaction.Details.Count);
        Assert.Null(result.PixTransaction.Details[0].GatewayResponse);
        Assert.Null(result.PixTransaction.Details[0].Legacy);
        Assert.Equal("pay", result.PixTransaction.Details[1].Operation);
    }

    [Fact]
    public void MapToEntity_WithBoletoDetailContainingNullElement_ShouldHandleGracefully()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetBoletoTransactionFields(csvRow);

        csvRow.SetField(
            HeaderIndex["boleto_transaction__details"],
            "[null,{\"operation\":\"pay\",\"operation_id\":\"bol_valid\",\"provider_datetime\":\"2024-01-15T10:31:00Z\",\"local_datetime\":\"2024-01-15T10:31:00Z\",\"operation_amount\":\"5000\",\"reason\":\"ok\",\"operation_status\":\"success\",\"pgid\":\"pg_1\"}]"
        );

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.BoletoTransaction);
        Assert.NotNull(result.BoletoTransaction.Details);
        Assert.Equal(2, result.BoletoTransaction.Details.Count);
        Assert.Equal("pay", result.BoletoTransaction.Details[1].Operation);
    }

    [Fact]
    public void MapToEntity_WithCashDetailContainingNullElement_ShouldHandleGracefully()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCashTransactionFields(csvRow);

        csvRow.SetField(
            HeaderIndex["cash_transaction__details"],
            "[null,{\"operation\":\"pay\",\"operation_id\":\"cash_valid\",\"local_datetime\":\"2024-01-15T10:31:00Z\",\"provider_datetime\":\"2024-01-15T10:31:00Z\",\"operation_amount\":\"5000\",\"operation_status\":\"success\",\"pgid\":\"pg_1\"}]"
        );

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.CashTransaction);
        Assert.NotNull(result.CashTransaction.Details);
        Assert.Equal(2, result.CashTransaction.Details.Count);
        Assert.Equal("pay", result.CashTransaction.Details[1].Operation);
    }

    [Fact]
    public void MapToEntity_WithFinancialMovementContainingNullElement_ShouldHandleGracefully()
    {
        // Arrange
        var csvRow = CreateBaseCsvRow();
        SetCardTransactionFields(csvRow);

        csvRow.SetField(
            HeaderIndex["card_transaction__financial_movements"],
            "[null,{\"operation\":\"capture\",\"operation_id\":\"fm_valid\",\"installment_number\":\"1\",\"amount\":{\"gross\":\"5000\",\"net\":\"4800\"}}]"
        );

        // Act
        var result = ChargeEntityMapper.MapToEntity(csvRow);

        // Assert
        Assert.NotNull(result.CardTransaction);
        Assert.NotNull(result.CardTransaction.FinancialMovements);
        Assert.Equal(2, result.CardTransaction.FinancialMovements.Count);
        Assert.Equal("capture", result.CardTransaction.FinancialMovements[1].Operation);
    }

    #endregion
}

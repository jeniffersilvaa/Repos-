using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.FinMovList;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;
using PaymentsDataLayerReports.Application.Workers.Shared.Modifiers.FinMov;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.Shared.Modifiers.FinMov;

public class ReceivablesOneStoneModifierTests
{
    private readonly ReceivablesOneStoneModifier _modifier = new();

    #region GetHeader Tests

    [Fact]
    public void GetHeader_ShouldReturnNonEmptyString()
    {
        // Act
        var header = _modifier.GetHeader();

        // Assert
        Assert.NotNull(header);
        Assert.NotEmpty(header);
    }

    [Fact]
    public void GetHeader_ShouldContainExpectedColumns()
    {
        // Act
        var header = _modifier.GetHeader();

        // Assert - Check for key columns in Portuguese
        Assert.Contains("CNPJ", header);
        Assert.Contains("LOJA", header);
        Assert.Contains("IDENTIFICADOR DA TRANSAÇÃO", header);
        Assert.Contains("DATA DE CAPTURA", header);
        Assert.Contains("CATEGORIA", header);
        Assert.Contains("MEIO DE CAPTURA", header);
        Assert.Contains("FORMA DE PAGAMENTO", header);
        Assert.Contains("BANDEIRA", header);
        Assert.Contains("PARCELA", header);
        Assert.Contains("NÚMERO DE PARCELAS", header);
        Assert.Contains("VALOR BRUTO", header);
        Assert.Contains("DESCONTO DE VENDA", header);
        Assert.Contains("DESCONTO DE ANTECIPAÇÃO", header);
        Assert.Contains("VALOR LÍQUIDO", header);
        Assert.Contains("DATA DE VENCIMENTO ORIGINAL", header);
        Assert.Contains("DATA DE VENCIMENTO", header);
        Assert.Contains("ÚLTIMO STATUS", header);
        Assert.Contains("DATA DO ÚLTIMO STATUS", header);
    }

    [Fact]
    public void GetHeader_ShouldUseSemicolonSeparator()
    {
        // Act
        var header = _modifier.GetHeader();

        // Assert
        Assert.Contains(";", header);
    }

    [Fact]
    public void GetHeader_ShouldReturnConsistentResult()
    {
        // Act
        var header1 = _modifier.GetHeader();
        var header2 = _modifier.GetHeader();

        // Assert
        Assert.Equal(header1, header2);
    }

    #endregion

    #region BuildRow Tests - Basic Scenarios

    [Fact]
    public void BuildRow_WithEmptyCsvRow_ShouldReturnRowWithEmptyFields()
    {
        // Arrange
        var csvRow = new CsvRow(FinMovListReportHeader.DefaultValues);

        // Act
        var row = _modifier.BuildRow(csvRow);

        // Assert
        Assert.NotNull(row);
        Assert.NotEmpty(row);
        Assert.Contains(";", row);
    }

    [Fact]
    public void BuildRow_WithBasicFinMovData_ShouldMapCorrectly()
    {
        // Arrange
        var csvRow = CreateBasicFinMovCsvRow();

        // Act
        var row = _modifier.BuildRow(csvRow);

        // Assert
        Assert.NotNull(row);
        Assert.Contains("txn-001", row);
    }

    [Fact]
    public void BuildRow_WithSaleOperation_ShouldTranslateCategory()
    {
        // Arrange
        var csvRow = CreateFinMovCsvRow(operation: "sale");

        // Act
        var row = _modifier.BuildRow(csvRow);

        // Assert
        Assert.Contains("Venda", row);
    }

    [Fact]
    public void BuildRow_WithChargebackOperation_ShouldTranslateCategory()
    {
        // Arrange
        var csvRow = CreateFinMovCsvRow(operation: "chargeback");

        // Act
        var row = _modifier.BuildRow(csvRow);

        // Assert
        Assert.Contains("Chargeback", row);
    }

    #endregion

    #region BuildRow Tests - Document Formatting

    [Fact]
    public void BuildRow_WithCPF_ShouldFormatCorrectly()
    {
        // Arrange
        var csvRow = CreateFinMovCsvRow(document: "12345678901"); // CPF

        // Act
        var row = _modifier.BuildRow(csvRow);

        // Assert
        Assert.Contains("123.456.789-01", row);
    }

    [Fact]
    public void BuildRow_WithCNPJ_ShouldFormatCorrectly()
    {
        // Arrange
        var csvRow = CreateFinMovCsvRow(document: "12345678901234"); // CNPJ

        // Act
        var row = _modifier.BuildRow(csvRow);

        // Assert
        Assert.Contains("12.345.678/9012-34", row);
    }

    [Fact]
    public void BuildRow_WithNullDocument_ShouldHandleGracefully()
    {
        // Arrange
        var csvRow = CreateFinMovCsvRow(document: null);

        // Act
        var row = _modifier.BuildRow(csvRow);

        // Assert
        Assert.NotNull(row);
    }

    #endregion

    #region BuildRow Tests - Amount Formatting

    [Fact]
    public void BuildRow_WithAmount_ShouldFormatMonetaryValue()
    {
        // Arrange
        var csvRow = CreateFinMovCsvRow(grossAmount: 10000, netAmount: 9500);

        // Act
        var row = _modifier.BuildRow(csvRow);

        // Assert
        Assert.Contains("10.000,000000", row); // Formato brasileiro
        Assert.Contains("9.500,000000", row);
    }

    [Fact]
    public void BuildRow_WithChargeback_ShouldUseNetAsGross()
    {
        // Arrange
        var csvRow = CreateFinMovCsvRow(
            operation: "chargeback",
            grossAmount: 10000,
            netAmount: -10000
        );

        // Act
        var row = _modifier.BuildRow(csvRow);

        // Assert
        // For chargeback, gross should equal net
        Assert.Contains("-10.000,000000", row);
    }

    [Fact]
    public void BuildRow_WithZeroFees_ShouldReturnNullFee()
    {
        // Arrange
        var csvRow = CreateFinMovCsvRow(
            discountRateAmount: null,
            prepaymentFeeAmount: null
        );

        // Act
        var row = _modifier.BuildRow(csvRow);

        // Assert
        Assert.NotNull(row);
    }

    [Fact]
    public void BuildRow_WithCETFee_ShouldReturnZeroFee()
    {
        // Arrange
        var csvRow = CreateFinMovCsvRow(
            discountRateAmount: 500,
            discountRateFeeType: "CET"
        );

        // Act
        var row = _modifier.BuildRow(csvRow);

        // Assert
        Assert.Contains("0,000000", row); // CET fee should be zero
    }

    #endregion

    #region BuildRow Tests - Date Formatting

    [Fact]
    public void BuildRow_WithValidDates_ShouldFormatCorrectly()
    {
        // Arrange
        var csvRow = CreateFinMovCsvRow(
            captureDate: "2024-01-15T10:30:00Z",
            currentDueDate: "2024-02-15",
            originalDueDate: "2024-02-15"
        );

        // Act
        var row = _modifier.BuildRow(csvRow);

        // Assert
        Assert.Contains("15/01/2024", row);
        Assert.Contains("15/02/2024", row);
    }

    [Fact]
    public void BuildRow_WithInvalidDate_ShouldReturnOriginalValue()
    {
        // Arrange
        var csvRow = CreateFinMovCsvRow(captureDate: "invalid-date");

        // Act
        var row = _modifier.BuildRow(csvRow);

        // Assert
        Assert.Contains("invalid-date", row);
    }

    [Fact]
    public void BuildRow_WithNullDate_ShouldHandleGracefully()
    {
        // Arrange
        var csvRow = CreateFinMovCsvRow(captureDate: null);

        // Act
        var row = _modifier.BuildRow(csvRow);

        // Assert
        Assert.NotNull(row);
    }

    #endregion

    #region BuildRow Tests - Settlement Status

    [Fact]
    public void BuildRow_WithPaidStatus_ShouldTranslateStatus()
    {
        // Arrange
        var csvRow = CreateFinMovCsvRow(settlementStatus: "paid");

        // Act
        var row = _modifier.BuildRow(csvRow);

        // Assert
        Assert.Contains("Pago", row);
    }

    [Fact]
    public void BuildRow_WithOpenStatus_ShouldTranslateStatus()
    {
        // Arrange
        var csvRow = CreateFinMovCsvRow(settlementStatus: "open");

        // Act
        var row = _modifier.BuildRow(csvRow);

        // Assert
        Assert.Contains("Aberto", row);
    }

    [Fact]
    public void BuildRow_WithScheduledStatus_ShouldTranslateStatus()
    {
        // Arrange
        var csvRow = CreateFinMovCsvRow(settlementStatus: "scheduled");

        // Act
        var row = _modifier.BuildRow(csvRow);

        // Assert
        Assert.Contains("Agendado", row);
    }

    #endregion

    #region BuildRow Tests - Wallet/Product Mapping

    [Fact]
    public void BuildRow_WithVisaCreditWallet_ShouldMapCorrectly()
    {
        // Arrange
        var csvRow = CreateFinMovCsvRow(walletDescription: "VisaCredit");

        // Act
        var row = _modifier.BuildRow(csvRow);

        // Assert
        Assert.Contains("Crédito", row);
    }

    [Fact]
    public void BuildRow_WithMasterDebitWallet_ShouldMapCorrectly()
    {
        // Arrange
        var csvRow = CreateFinMovCsvRow(walletDescription: "MasterDebit");

        // Act
        var row = _modifier.BuildRow(csvRow);

        // Assert
        Assert.Contains("Débito", row);
    }

    [Fact]
    public void BuildRow_WithPrepaidWallet_ShouldMapCorrectly()
    {
        // Arrange
        var csvRow = CreateFinMovCsvRow(
            walletDescription: "VisaPrePayment",
            accountFundingSource: "prepaid"
        );

        // Act
        var row = _modifier.BuildRow(csvRow);

        // Assert
        Assert.Contains("Pré-pago", row);
    }

    #endregion

    #region BuildRow Tests - Brand Mapping

    [Fact]
    public void BuildRow_WithVisaBrand_ShouldMapCorrectly()
    {
        // Arrange
        var csvRow = CreateFinMovCsvRow(
            brand: "visa",
            walletDescription: "VisaCredit"
        );

        // Act
        var row = _modifier.BuildRow(csvRow);

        // Assert
        Assert.Contains("Visa", row);
    }

    [Fact]
    public void BuildRow_WithMastercardBrand_ShouldMapCorrectly()
    {
        // Arrange
        var csvRow = CreateFinMovCsvRow(
            brand: "mastercard",
            walletDescription: "MasterCredit"
        );

        // Act
        var row = _modifier.BuildRow(csvRow);

        // Assert
        Assert.Contains("MasterCard", row);
    }

    #endregion

    #region BuildRow Tests - Installment Handling

    [Fact]
    public void BuildRow_WithInstallmentNumber_ShouldMapCorrectly()
    {
        // Arrange
        var csvRow = CreateFinMovCsvRow(
            installmentNumber: 3,
            installmentQuantity: 12
        );

        // Act
        var row = _modifier.BuildRow(csvRow);

        // Assert
        Assert.Contains("3", row);
        Assert.Contains("12", row);
    }

    [Fact]
    public void BuildRow_WithNullInstallment_ShouldDefaultToOne()
    {
        // Arrange
        var csvRow = CreateFinMovCsvRow(
            installmentNumber: null,
            installmentQuantity: null
        );

        // Act
        var row = _modifier.BuildRow(csvRow);

        // Assert
        Assert.Contains("1", row);
    }

    #endregion

    #region BuildRow Tests - Edge Cases

    [Fact]
    public void BuildRow_WithLargeAmount_ShouldFormatCorrectly()
    {
        // Arrange
        var csvRow = CreateFinMovCsvRow(grossAmount: 100000000); // 1,000,000.00

        // Act
        var row = _modifier.BuildRow(csvRow);

        // Assert
        Assert.Contains("100.000.000,000000", row);
    }

    [Fact]
    public void BuildRow_WithNegativeAmount_ShouldFormatCorrectly()
    {
        // Arrange
        var csvRow = CreateFinMovCsvRow(netAmount: -5000);

        // Act
        var row = _modifier.BuildRow(csvRow);

        // Assert
        Assert.Contains("-5.000,000000", row);
    }

    [Fact]
    public void BuildRow_WithPartialReversal_ShouldTranslateCategory()
    {
        // Arrange
        var csvRow = CreateFinMovCsvRow(operation: "partial_reversal");

        // Act
        var row = _modifier.BuildRow(csvRow);

        // Assert
        Assert.Contains("Cancelamento Parcial", row);
    }

    [Fact]
    public void BuildRow_WithPrepaymentFeeOperation_ShouldTranslateCategory()
    {
        // Arrange
        var csvRow = CreateFinMovCsvRow(operation: "prepayment_fee");

        // Act
        var row = _modifier.BuildRow(csvRow);

        // Assert
        Assert.Contains("Desconto de Antecipação", row);
    }

    [Fact]
    public void BuildRow_HeaderAndRowFieldCount_ShouldMatch()
    {
        // Arrange
        var header = _modifier.GetHeader();
        var expectedFieldCount = header.Split(';').Length;
        var csvRow = CreateBasicFinMovCsvRow();

        // Act
        var row = _modifier.BuildRow(csvRow);
        var actualFieldCount = row.Split(';').Length;

        // Assert
        Assert.Equal(expectedFieldCount, actualFieldCount);
    }

    #endregion

    #region Helper Methods

    private static CsvRow CreateBasicFinMovCsvRow()
    {
        var headerIndex = FinMovListReportHeader.HeaderIndex;
        var values = new object?[headerIndex.Count];
        values[headerIndex["id"]] = "fin-001";
        values[headerIndex["operation_id"]] = "op-001";
        values[headerIndex["original_due_date"]] = "2024-02-15";
        values[headerIndex["current_due_date"]] = "2024-02-15";
        values[headerIndex["payment_owner__document"]] = "12345678901234";
        values[headerIndex["merchant__affiliation_code"]] = "1234567";
        values[headerIndex["transaction__key"]] = "txn-001";
        values[headerIndex["transaction__capture_date"]] = "2024-01-15T10:30:00Z";
        values[headerIndex["transaction__brand"]] = "visa";
        values[headerIndex["settlement__status"]] = "paid";
        values[headerIndex["settlement__wallet__description"]] = "VisaCredit";
        values[headerIndex["operation"]] = "sale";
        values[headerIndex["amount__gross"]] = 10000m;
        values[headerIndex["amount__net"]] = 9500m;
        values[headerIndex["transaction__installment_number"]] = 1;
        values[headerIndex["transaction__installment_quantity"]] = 1;
        values[headerIndex["transaction__point_of_interaction_type"]] = "Ecommerce";

        return new CsvRow(values);
    }

    private static CsvRow CreateFinMovCsvRow(
        string? operation = "sale",
        string? document = "12345678901234",
        string? captureDate = "2024-01-15T10:30:00Z",
        string? currentDueDate = "2024-02-15",
        string? originalDueDate = "2024-02-15",
        decimal? grossAmount = 10000m,
        decimal? netAmount = 9500m,
        decimal? discountRateAmount = 300m,
        string? discountRateFeeType = "percentage",
        decimal? prepaymentFeeAmount = 200m,
        string? prepaymentFeeFeeType = "percentage",
        string? settlementStatus = "paid",
        string? brand = "visa",
        string? walletDescription = "VisaCredit",
        string? accountFundingSource = null,
        int? installmentNumber = 1,
        int? installmentQuantity = 1,
        string? transactionKey = "txn-001",
        string? pointOfInteractionType = "Ecommerce")
    {
        var headerIndex = FinMovListReportHeader.HeaderIndex;
        var values = new object?[headerIndex.Count];
        values[headerIndex["id"]] = "fin-001";
        values[headerIndex["operation_id"]] = "op-001";
        values[headerIndex["original_due_date"]] = originalDueDate;
        values[headerIndex["current_due_date"]] = currentDueDate;
        values[headerIndex["payment_owner__document"]] = document;
        values[headerIndex["merchant__affiliation_code"]] = "1234567";
        values[headerIndex["transaction__key"]] = transactionKey;
        values[headerIndex["transaction__capture_date"]] = captureDate;
        values[headerIndex["transaction__brand"]] = brand;
        values[headerIndex["transaction__account_funding_source"]] = accountFundingSource;
        values[headerIndex["transaction__point_of_interaction_type"]] = pointOfInteractionType;
        values[headerIndex["settlement__status"]] = settlementStatus;
        values[headerIndex["settlement__wallet__description"]] = walletDescription;
        values[headerIndex["operation"]] = operation;
        values[headerIndex["amount__gross"]] = grossAmount;
        values[headerIndex["amount__net"]] = netAmount;
        values[headerIndex["amount__discount_rate__amount"]] = discountRateAmount;
        values[headerIndex["amount__discount_rate__fee_type"]] = discountRateFeeType;
        values[headerIndex["amount__prepayment_fee__amount"]] = prepaymentFeeAmount;
        values[headerIndex["amount__prepayment_fee__fee_type"]] = prepaymentFeeFeeType;
        values[headerIndex["transaction__installment_number"]] = installmentNumber;
        values[headerIndex["transaction__installment_quantity"]] = installmentQuantity;

        return new CsvRow(values);
    }

    #endregion
}

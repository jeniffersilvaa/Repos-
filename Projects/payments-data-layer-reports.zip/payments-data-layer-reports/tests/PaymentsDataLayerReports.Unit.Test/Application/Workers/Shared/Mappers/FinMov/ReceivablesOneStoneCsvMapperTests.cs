using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Entities.Models.FinMov;
using PaymentsDataLayerReports.Application.Workers.Shared.Mappers.FinMov;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.Shared.Mappers.FinMov;

public class ReceivablesOneStoneCsvMapperTests
{
    private readonly ReceivablesOneStoneCsvMapper _mapper = new();

    #region GetHeader Tests

    [Fact]
    public void GetHeader_ShouldReturnNonEmptyString()
    {
        // Act
        var header = _mapper.GetHeader();

        // Assert
        Assert.NotNull(header);
        Assert.NotEmpty(header);
    }

    [Fact]
    public void GetHeader_ShouldContainExpectedColumns()
    {
        // Act
        var header = _mapper.GetHeader();

        // Assert - Check for key columns in Portuguese
        Assert.Contains("CNPJ", header);
        Assert.Contains("LOJA", header);
        Assert.Contains("IDENTIFICADOR DA TRANSAÇÃO", header);
        Assert.Contains("DATA DE CAPTURA", header);
        Assert.Contains("CATEGORIA", header);
        Assert.Contains("MEIO DE CAPTURA", header);
        Assert.Contains("FORMA DE PAGAMENTO", header);
        Assert.Contains("BANDEIRA", header);
        Assert.Contains("PARCELA", header);
        Assert.Contains("NÚMERO DE PARCELAS", header);
        Assert.Contains("VALOR BRUTO", header);
        Assert.Contains("DESCONTO DE VENDA", header);
        Assert.Contains("DESCONTO DE ANTECIPAÇÃO", header);
        Assert.Contains("VALOR LÍQUIDO", header);
        Assert.Contains("DATA DE VENCIMENTO ORIGINAL", header);
        Assert.Contains("DATA DE VENCIMENTO", header);
        Assert.Contains("ÚLTIMO STATUS", header);
        Assert.Contains("DATA DO ÚLTIMO STATUS", header);
    }

    [Fact]
    public void GetHeader_ShouldUseSemicolonSeparator()
    {
        // Act
        var header = _mapper.GetHeader();

        // Assert
        Assert.Contains(";", header);
    }

    #endregion

    #region BuildRow Tests - Basic Scenarios

    [Fact]
    public void BuildRow_WithFinancialMovement_ShouldMapAllFields()
    {
        // Arrange
        var finMov = CreateBasicFinancialMovement();

        // Act
        var row = _mapper.BuildRow(finMov);

        // Assert
        Assert.NotNull(row);
        Assert.NotEmpty(row);
        Assert.Contains(";", row);
    }

    [Fact]
    public void BuildRow_WithPointOfInteractionType_ShouldMapCorrectly()
    {
        // Arrange
        var finMov = CreateFinancialMovement(pointOfInteractionType: "Ecommerce");

        // Act
        var row = _mapper.BuildRow(finMov);

        // Assert
        Assert.Contains("Ecommerce", row);
    }

    [Fact]
    public void BuildRow_WithSaleOperation_ShouldTranslateCategory()
    {
        // Arrange
        var finMov = CreateFinancialMovement(operation: "sale");

        // Act
        var row = _mapper.BuildRow(finMov);

        // Assert
        Assert.Contains("Venda", row);
    }

    [Fact]
    public void BuildRow_WithChargebackOperation_ShouldTranslateCategory()
    {
        // Arrange
        var finMov = CreateFinancialMovement(operation: "chargeback");

        // Act
        var row = _mapper.BuildRow(finMov);

        // Assert
        Assert.Contains("Chargeback", row);
    }

    #endregion

    #region BuildRow Tests - Document Formatting

    [Fact]
    public void BuildRow_WithCPF_ShouldFormatCorrectly()
    {
        // Arrange
        var finMov = CreateFinancialMovement(document: "12345678901"); // CPF

        // Act
        var row = _mapper.BuildRow(finMov);

        // Assert
        Assert.Contains("123.456.789-01", row);
    }

    [Fact]
    public void BuildRow_WithCNPJ_ShouldFormatCorrectly()
    {
        // Arrange
        var finMov = CreateFinancialMovement(document: "12345678901234"); // CNPJ

        // Act
        var row = _mapper.BuildRow(finMov);

        // Assert
        Assert.Contains("12.345.678/9012-34", row);
    }

    #endregion

    #region BuildRow Tests - Amount Formatting

    [Fact]
    public void BuildRow_WithAmount_ShouldFormatMonetaryValue()
    {
        // Arrange
        var finMov = CreateFinancialMovement(grossAmount: 10000, netAmount: 9500);

        // Act
        var row = _mapper.BuildRow(finMov);

        // Assert
        Assert.Contains("10.000,000000", row); // Formato brasileiro
        Assert.Contains("9.500,000000", row);
    }

    [Fact]
    public void BuildRow_WithChargeback_ShouldUseNetAsGross()
    {
        // Arrange
        var finMov = CreateFinancialMovement(
            operation: "chargeback",
            grossAmount: -10000,
            netAmount: -10000
        );

        // Act
        var row = _mapper.BuildRow(finMov);

        // Assert
        Assert.Contains("-10.000,000000", row);
    }

    #endregion

    #region BuildRow Tests - Date Formatting

    [Fact]
    public void BuildRow_WithValidDates_ShouldFormatCorrectly()
    {
        // Arrange
        var finMov = CreateFinancialMovement(
            captureDate: "2024-01-15T10:30:00Z",
            currentDueDate: "2024-02-15",
            originalDueDate: "2024-02-15"
        );

        // Act
        var row = _mapper.BuildRow(finMov);

        // Assert
        Assert.Contains("15/01/2024", row);
        Assert.Contains("15/02/2024", row);
    }

    #endregion

    #region BuildRow Tests - Settlement Status

    [Fact]
    public void BuildRow_WithPaidStatus_ShouldTranslateStatus()
    {
        // Arrange
        var finMov = CreateFinancialMovement(settlementStatus: "paid");

        // Act
        var row = _mapper.BuildRow(finMov);

        // Assert
        Assert.Contains("Pago", row);
    }

    [Fact]
    public void BuildRow_WithOpenStatus_ShouldTranslateStatus()
    {
        // Arrange
        var finMov = CreateFinancialMovement(settlementStatus: "open");

        // Act
        var row = _mapper.BuildRow(finMov);

        // Assert
        Assert.Contains("Aberto", row);
    }

    #endregion

    #region BuildRow Tests - Wallet/Product Mapping

    [Fact]
    public void BuildRow_WithVisaCreditWallet_ShouldMapCorrectly()
    {
        // Arrange
        var finMov = CreateFinancialMovement(walletDescription: "VisaCredit");

        // Act
        var row = _mapper.BuildRow(finMov);

        // Assert
        Assert.Contains("Crédito", row);
    }

    [Fact]
    public void BuildRow_WithMasterDebitWallet_ShouldMapCorrectly()
    {
        // Arrange
        var finMov = CreateFinancialMovement(walletDescription: "MasterDebit");

        // Act
        var row = _mapper.BuildRow(finMov);

        // Assert
        Assert.Contains("Débito", row);
    }

    #endregion

    #region BuildRow Tests - Brand Mapping

    [Fact]
    public void BuildRow_WithVisaBrand_ShouldMapCorrectly()
    {
        // Arrange
        var finMov = CreateFinancialMovement(
            brand: "visa",
            walletDescription: "VisaCredit"
        );

        // Act
        var row = _mapper.BuildRow(finMov);

        // Assert
        Assert.Contains("Visa", row);
    }

    #endregion

    #region BuildRow Tests - UpdatedAt as DATA DO ÚLTIMO STATUS

    [Fact]
    public void BuildRow_WithUpdatedAt_ShouldIncludeFormattedDateInLastColumn()
    {
        // DATA DO ÚLTIMO STATUS (last column) must come from UpdatedAt, not from CurrentDueDate.
        // Before the fix, CurrentDueDate was mistakenly used for this column.
        var finMov = CreateFinancialMovement(
            currentDueDate: "2024-02-15",
            updatedAt: "2024-06-10T13:00:00Z" // 10:00 BRT (UTC-3)
        );

        var row = _mapper.BuildRow(finMov);

        Assert.Contains("10/06/2024", row);
        Assert.Contains("10:00:00", row);
    }

    [Fact]
    public void BuildRow_DifferentUpdatedAtAndCurrentDueDate_ShouldUseUpdatedAtForLastColumn()
    {
        // Verifies UpdatedAt and CurrentDueDate are mapped to distinct columns.
        // "DATA DO ÚLTIMO STATUS" (last) must reflect UpdatedAt.
        var finMov = CreateFinancialMovement(
            currentDueDate: "2030-12-31",   // far future — should NOT appear as last column value
            updatedAt: "2024-03-05T12:00:00Z" // 09:00 BRT
        );

        var row = _mapper.BuildRow(finMov);
        var columns = row.Split(';');

        // Last column is DATA DO ÚLTIMO STATUS
        var lastColumn = columns[^1];
        Assert.Contains("05/03/2024", lastColumn);
        Assert.DoesNotContain("31/12/2030", lastColumn);
    }

    #endregion

    #region BuildRow Tests - Store uses PaymentOwner, not Merchant

    [Fact]
    public void BuildRow_ShouldUsePaymentOwnerPaymentProfileIdForStoreColumn()
    {
        // LOJA column must come from PaymentOwner.PaymentProfileId, not Merchant.PaymentProfileId.
        // Before the fix, Merchant.PaymentProfileId was incorrectly used for the ES path,
        // while S3 correctly used payment_owner__payment_profile_id.
        var finMov = new FinancialMovement(
            Id: "fin-001",
            OperationId: "op-001",
            OriginalDueDate: "2024-02-15",
            CurrentDueDate: "2024-02-15",
            LatestEventTimestamp: null,
            UpdatedAt: null,
            Amount: new Amount(10000m, 9500m, new FeeModel(300m, 3.0m, 3.0m, "percentage"), new FeeModel(200m, 2.0m, 2.0m, "percentage"), null),
            Merchant: new Merchant("aff", null, null, "12345678901234", null, "MERCHANT_PP"),
            PaymentOwner: new Merchant(null, null, null, "12345678901234", null, "PAYMENT_OWNER_PP"),
            Transaction: new Transaction(null, null, 1, 1, "2024-01-15T10:30:00Z", null, null, "visa", "txn-001", "Ecommerce"),
            Settlement: new Settlement(new Wallet("VisaCredit", "credit", null), null, null, null, "paid", null),
            Operation: "sale",
            Movements: null
        );

        var row = _mapper.BuildRow(finMov);

        Assert.Contains("PAYMENT_OWNER_PP", row);
        Assert.DoesNotContain("MERCHANT_PP", row);
    }

    #endregion

    #region BuildRow Tests - Installment Handling

    [Fact]
    public void BuildRow_WithInstallmentNumber_ShouldMapCorrectly()
    {
        // Arrange
        var finMov = CreateFinancialMovement(
            installmentNumber: 3,
            installmentQuantity: 12
        );

        // Act
        var row = _mapper.BuildRow(finMov);

        // Assert
        Assert.Contains("3", row);
        Assert.Contains("12", row);
    }

    [Fact]
    public void BuildRow_WithNullInstallment_ShouldDefaultToOne()
    {
        // Arrange
        var finMov = CreateFinancialMovement(
            installmentNumber: null,
            installmentQuantity: null
        );

        // Act
        var row = _mapper.BuildRow(finMov);

        // Assert
        Assert.Contains("1", row);
    }

    #endregion

    #region Helper Methods

    private static FinancialMovement CreateBasicFinancialMovement()
    {
        return new FinancialMovement(
            Id: "fin-001",
            OperationId: "op-001",
            OriginalDueDate: "2024-02-15",
            CurrentDueDate: "2024-02-15",
            LatestEventTimestamp: null,
            UpdatedAt: null,
            Amount: new Amount(
                Gross: 10000m,
                Net: 9500m,
                DiscountRate: new FeeModel(300m, 3.0m, 3.0m, "percentage"),
                PrepaymentFee: new FeeModel(200m, 2.0m, 2.0m, "percentage"),
                PrepaymentFeeTurbo: null
            ),
            Merchant: new Merchant(
                AffiliationCode: "1234567",
                UserId: null,
                Organization: null,
                Document: "12345678901234",
                AffiliationKey: null,
                PaymentProfileId: "PP123"
            ),
            PaymentOwner: new Merchant(
                AffiliationCode: null,
                UserId: null,
                Organization: null,
                Document: "12345678901234",
                AffiliationKey: null,
                PaymentProfileId: null
            ),
            Transaction: new Transaction(
                Product: null,
                AuthorizationDate: null,
                InstallmentNumber: 1,
                InstallmentQuantity: 1,
                CaptureDate: "2024-01-15T10:30:00Z",
                OperationKey: null,
                AccountFundingSource: null,
                Brand: "visa",
                Key: "txn-001",
                PointOfInteractionType: "Ecommerce"
            ),
            Settlement: new Settlement(
                Status: "paid",
                Key: null,
                BalanceDueDate: null,
                PaymentDate: null,
                Wallet: new Wallet("VisaCredit", "credit", null),
                Payment: null
            ),
            Operation: "sale",
            Movements: null
        );
    }

    private static FinancialMovement CreateFinancialMovement(
        string? operation = "sale",
        string? document = "12345678901234",
        string? captureDate = "2024-01-15T10:30:00Z",
        string? currentDueDate = "2024-02-15",
        string? originalDueDate = "2024-02-15",
        decimal? grossAmount = 10000m,
        decimal? netAmount = 9500m,
        string? settlementStatus = "paid",
        string? brand = "visa",
        string? walletDescription = "VisaCredit",
        string? accountFundingSource = null,
        int? installmentNumber = 1,
        int? installmentQuantity = 1,
        string? transactionKey = "txn-001",
        string? pointOfInteractionType = "Ecommerce",
        string? updatedAt = null)
    {
        return new FinancialMovement(
            Id: "fin-001",
            OperationId: "op-001",
            OriginalDueDate: originalDueDate,
            CurrentDueDate: currentDueDate,
            LatestEventTimestamp: null,
            UpdatedAt: updatedAt,
            Amount: new Amount(
                Gross: grossAmount,
                Net: netAmount,
                DiscountRate: new FeeModel(300m, 3.0m, 3.0m, "percentage"),
                PrepaymentFee: new FeeModel(200m, 2.0m, 2.0m, "percentage"),
                PrepaymentFeeTurbo: null
            ),
            Merchant: new Merchant(
                AffiliationCode: "1234567",
                UserId: null,
                Organization: null,
                Document: document,
                AffiliationKey: null,
                PaymentProfileId: "PP123"
            ),
            PaymentOwner: new Merchant(
                AffiliationCode: null,
                UserId: null,
                Organization: null,
                Document: document,
                AffiliationKey: null,
                PaymentProfileId: null
            ),
            Transaction: new Transaction(
                Product: null,
                AuthorizationDate: null,
                InstallmentNumber: installmentNumber,
                InstallmentQuantity: installmentQuantity,
                CaptureDate: captureDate,
                OperationKey: null,
                AccountFundingSource: accountFundingSource,
                Brand: brand,
                Key: transactionKey,
                PointOfInteractionType: pointOfInteractionType
            ),
            Settlement: new Settlement(
                Status: settlementStatus,
                Key: null,
                BalanceDueDate: null,
                PaymentDate: null,
                Wallet: new Wallet(walletDescription, "credit", null),
                Payment: null
            ),
            Operation: operation,
            Movements: null
        );
    }

    #endregion

    #region BuildRow Tests - Turbo Anticipation Fee

    [Fact]
    public void BuildRow_WithTurboFeeAndNonCet_ShouldSumPrepaymentAndTurboAmount()
    {
        // Arrange: regular prepayment Amount (-200) + turbo Amount (-300) = -500
        var finMov = CreateFinancialMovement();
        finMov = finMov with
        {
            Amount = new Amount(
                Gross: 10000m,
                Net: 9300m,
                DiscountRate: new FeeModel(-300m, 3.0m, 3.0m, "percentage"),
                PrepaymentFee: new FeeModel(-200m, 2.0m, 2.0m, "percentage"),
                PrepaymentFeeTurbo: new FeeModel(-300m, 2.5m, -500m, "turbo")
            )
        };

        // Act
        var row = _mapper.BuildRow(finMov);
        var columns = row.Split(';');

        // Assert: column 14 (index 14) is DESCONTO DE ANTECIPAÇÃO = (-200 + -300) = -500,000000
        Assert.Equal("-500,000000", columns[14]);
    }

    [Fact]
    public void BuildRow_WithTurboFeeAndCet_ShouldShowOnlyTurboAmount()
    {
        // Arrange: CET regular prepayment (zeroed) + turbo Amount (-300) = -300
        var finMov = CreateFinancialMovement();
        finMov = finMov with
        {
            Amount = new Amount(
                Gross: 10000m,
                Net: 9200m,
                DiscountRate: new FeeModel(-300m, 3.0m, 3.0m, "CET"),
                PrepaymentFee: new FeeModel(-200m, 2.0m, 2.0m, "CET"),
                PrepaymentFeeTurbo: new FeeModel(-300m, 2.5m, -500m, "turbo")
            )
        };

        // Act
        var row = _mapper.BuildRow(finMov);
        var columns = row.Split(';');

        // Assert: CET regular = 0, turbo Amount = -300 = -300,000000
        Assert.Equal("-300,000000", columns[14]);
    }

    [Fact]
    public void BuildRow_WithoutTurboFee_ShouldPreserveExistingBehavior()
    {
        // Arrange: no turbo, only regular prepayment (-200)
        var finMov = CreateFinancialMovement();
        finMov = finMov with
        {
            Amount = new Amount(
                Gross: 10000m,
                Net: 9500m,
                DiscountRate: new FeeModel(-300m, 3.0m, 3.0m, "percentage"),
                PrepaymentFee: new FeeModel(-200m, 2.0m, 2.0m, "percentage"),
                PrepaymentFeeTurbo: null
            )
        };

        // Act
        var row = _mapper.BuildRow(finMov);
        var columns = row.Split(';');

        // Assert: only regular prepayment = -200 = -200,000000
        Assert.Equal("-200,000000", columns[14]);
    }

    [Fact]
    public void BuildRow_WithChargebackAndTurboFee_ShouldReturnZeroForAnticipationDiscount()
    {
        // Arrange: chargeback operation with turbo fee
        var finMov = CreateFinancialMovement(operation: "chargeback");
        finMov = finMov with
        {
            Amount = finMov.Amount! with
            {
                PrepaymentFeeTurbo = new FeeModel(-300m, 2.5m, -500m, "turbo")
            }
        };

        // Act
        var row = _mapper.BuildRow(finMov);
        var columns = row.Split(';');

        // Assert: chargeback -> anticipation discount = 0
        Assert.Equal("0,000000", columns[14]);
    }

    #endregion
}

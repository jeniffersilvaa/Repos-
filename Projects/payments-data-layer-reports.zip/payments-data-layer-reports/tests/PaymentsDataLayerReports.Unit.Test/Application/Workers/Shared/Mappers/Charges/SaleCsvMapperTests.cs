using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Entities.Models.Charge;
using PaymentsDataLayerReports.Application.Workers.Shared.Mappers.Charges;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.Shared.Mappers.Charges;

public class SaleCsvMapperTests
{
    private readonly SaleCsvMapper _mapper = new();

    #region GetHeader Tests

    [Fact]
    public void GetHeader_ShouldReturnNonEmptyString()
    {
        // Act
        var header = _mapper.GetHeader();

        // Assert
        Assert.NotNull(header);
        Assert.NotEmpty(header);
    }

    [Fact]
    public void GetHeader_ShouldContainExpectedColumns()
    {
        // Act
        var header = _mapper.GetHeader();

        // Assert - Check for key columns in Portuguese
        Assert.Contains("ADQUIRENTE", header);
        Assert.Contains("CNPJ", header);
        Assert.Contains("LOJA", header);
        Assert.Contains("IDENTIFICADOR DO PEDIDO", header);
        Assert.Contains("IDENTIFICADOR DA COBRANÇA", header);
        Assert.Contains("DATA DA AUTORIZAÇÃO", header);
        Assert.Contains("CÓDIGO DE AUTORIZAÇÃO", header);
        Assert.Contains("STATUS DO ANTIFRAUDE", header);
        Assert.Contains("DATA DE CAPTURA", header);
        Assert.Contains("MEIO DE CAPTURA", header);
        Assert.Contains("FORMA DE PAGAMENTO", header);
        Assert.Contains("BANDEIRA", header);
        Assert.Contains("NÚMERO DE PARCELAS", header);
        Assert.Contains("VALOR BRUTO", header);
        Assert.Contains("VALOR LÍQUIDO", header);
        Assert.Contains("ÚLTIMO STATUS", header);
    }

    [Fact]
    public void GetHeader_ShouldUseSemicolonSeparator()
    {
        // Act
        var header = _mapper.GetHeader();

        // Assert
        Assert.Contains(";", header);
    }

    [Fact]
    public void CreatedAtColumnPosition_ShouldBe6()
    {
        // Assert
        Assert.Equal(6, _mapper.CreatedAtColumnPosition);
    }

    [Fact]
    public void GetHeader_ShouldPlaceAcquirerAtColumn19()
    {
        // Act
        var header = _mapper.GetHeader();

        // Assert
        Assert.Equal("ADQUIRENTE", GetColumnValue(header, 19));
        Assert.Equal("CNPJ", GetColumnValue(header, 0));
    }

    #endregion

    #region BuildRow Tests - Card Transaction

    [Fact]
    public void BuildRow_WithCardTransaction_ShouldMapAllFields()
    {
        // Arrange
        var charge = CreateCardCharge();

        // Act
        var row = _mapper.BuildRow(charge);

        // Assert
        Assert.NotNull(row);
        Assert.NotEmpty(row);
        // Row should contain semicolon separators
        Assert.Contains(";", row);
    }

    [Fact]
    public void BuildRow_WithCardTransaction_ShouldContainMerchantDocument()
    {
        // Arrange
        var charge = CreateCardCharge();

        // Act
        var row = _mapper.BuildRow(charge);

        // Assert
        Assert.Contains("12345678901234", row); // CNPJ formatado
    }

    [Fact]
    public void BuildRow_WithCardTransaction_ShouldContainAcquirerName()
    {
        // Arrange
        var charge = CreateCardChargeWithDetails();

        // Act
        var row = _mapper.BuildRow(charge);

        // Assert
        Assert.Contains("Stone", row); // Acquirer name from Details
    }

    [Fact]
    public void BuildRow_WithCardTransaction_ShouldPlaceAcquirerAtColumn19()
    {
        // Arrange
        var charge = CreateCardChargeWithDetails();

        // Act
        var row = _mapper.BuildRow(charge);

        // Assert
        Assert.Equal("Stone", GetColumnValue(row, 19));
    }

    [Fact]
    public void BuildRow_WithCardTransaction_ShouldContainAntifraudStatus()
    {
        // Arrange
        var charge = CreateCardChargeWithDetails();

        // Act
        var row = _mapper.BuildRow(charge);

        // Assert
        Assert.Contains("approved", row); // Antifraud status from Details
    }

    [Fact]
    public void BuildRow_WithCardTransaction_ShouldContainChargeId()
    {
        // Arrange
        var charge = CreateCardCharge();

        // Act
        var row = _mapper.BuildRow(charge);

        // Assert - ChargeId should appear (IDENTIFICADOR DA COBRANÇA)
        Assert.Contains("charge-card-001", row);
    }

    [Fact]
    public void BuildRow_WithCardTransaction_ShouldUseGatewayOrderIdAsTransactionIdentifierWhenAvailable()
    {
        // Arrange
        var charge = CreateCardCharge();

        // Act
        var row = _mapper.BuildRow(charge);

        // Assert
        Assert.Equal("order-001", GetColumnValue(row, 4));
    }

    [Fact]
    public void BuildRow_WithCardTransaction_ShouldUseTransactionIdWhenGatewayOrderIdIsNull()
    {
        // Arrange
        var charge = CreateCardCharge() with { GatewayOrderId = null };

        // Act
        var row = _mapper.BuildRow(charge);

        // Assert
        Assert.Equal("txn-001", GetColumnValue(row, 4));
    }

    [Fact]
    public void BuildRow_WithCardTransaction_ShouldContainCardBrand()
    {
        // Arrange
        var charge = CreateCardCharge();

        // Act
        var row = _mapper.BuildRow(charge);

        // Assert
        Assert.Contains("visa", row);
    }

    [Fact]
    public void BuildRow_WithCardTransaction_ShouldContainInstallments()
    {
        // Arrange
        var charge = CreateCardCharge();

        // Act
        var row = _mapper.BuildRow(charge);

        // Assert
        Assert.Contains("3", row);
    }

    [Fact]
    public void BuildRow_WithCardTransaction_ShouldFormatAmountCorrectly()
    {
        // Arrange
        var charge = CreateCardCharge(amount: 10000); // 100.00 in cents

        // Act
        var row = _mapper.BuildRow(charge);

        // Assert
        Assert.Contains("100,000000", row); // Formato brasileiro
    }

    #endregion

    #region BuildRow Tests - PIX Transaction

    [Fact]
    public void BuildRow_WithPixTransaction_ShouldMapAllFields()
    {
        // Arrange
        var charge = CreatePixCharge();

        // Act
        var row = _mapper.BuildRow(charge);

        // Assert
        Assert.NotNull(row);
        Assert.NotEmpty(row);
        Assert.Contains(";", row);
    }

    [Fact]
    public void BuildRow_WithPixTransaction_ShouldContainE2eId()
    {
        // Arrange
        var charge = CreatePixCharge();

        // Act
        var row = _mapper.BuildRow(charge);

        // Assert
        Assert.Equal("E2E123456", GetColumnValue(row, 6));
    }

    [Fact]
    public void BuildRow_WithPixTransaction_ShouldUseTransactionIdWhenGatewayOrderIdIsNull()
    {
        // Arrange
        var charge = CreatePixCharge() with { GatewayOrderId = null };

        // Act
        var row = _mapper.BuildRow(charge);

        // Assert
        Assert.Equal("txn-pix-001", GetColumnValue(row, 4));
    }

    #endregion

    #region BuildRow Tests - Boleto Transaction

    [Fact]
    public void BuildRow_WithBoletoTransaction_ShouldMapAllFields()
    {
        // Arrange
        var charge = CreateBoletoCharge();

        // Act
        var row = _mapper.BuildRow(charge);

        // Assert
        Assert.NotNull(row);
        Assert.NotEmpty(row);
        Assert.Contains(";", row);
    }

    [Fact]
    public void BuildRow_WithBoletoTransaction_ShouldContainBankName()
    {
        // Arrange
        var charge = CreateBoletoCharge();

        // Act
        var row = _mapper.BuildRow(charge);

        // Assert
        Assert.Contains("Banco do Brasil", row);
    }

    [Fact]
    public void BuildRow_WithBoletoTransaction_ShouldUseTransactionIdWhenGatewayOrderIdIsNull()
    {
        // Arrange
        var charge = CreateBoletoCharge() with { GatewayOrderId = null };

        // Act
        var row = _mapper.BuildRow(charge);

        // Assert
        Assert.Equal("txn-boleto-001", GetColumnValue(row, 4));
    }

    #endregion

    #region BuildRow Tests - Edge Cases

    [Fact]
    public void BuildRow_WithNullValues_ShouldHandleGracefully()
    {
        // Arrange
        var charge = CreateMinimalCharge();

        // Act
        var row = _mapper.BuildRow(charge);

        // Assert
        Assert.NotNull(row);
        Assert.NotEmpty(row);
    }

    [Fact]
    public void BuildRow_WithEmptyCardTransaction_ShouldNotThrow()
    {
        // Arrange
        var charge = new Charge(
            Id: "charge-001",
            InitiatorId: "init-001",
            Product: null,
            Origin: null,
            OriginId: null,
            Amount: 1000,
            UpdatedAmount: null,
            NetAmount: null,
            FullNetAmount: null,
            Status: "paid",
            PaymentMethod: "card",
            CreatedAt: DateTimeOffset.Now,
            PlatformName: null,
            AttemptCount: null,
            Gateway: null,
            GatewayOrderId: "order-001",
            Code: null,
            AllIds: null,
            Merchant: CreateMerchant(),
            Split: new List<Split>(),
            CardTransaction: null, // Null card transaction
            PixTransaction: null,
            BoletoTransaction: null,
            CashTransaction: null
        );

        // Act & Assert - Should not throw
        var exception = Record.Exception(() => _mapper.BuildRow(charge));
        Assert.Null(exception);
    }

    [Fact]
    public void BuildRow_WithHighInstallmentCount_ShouldMapCorrectly()
    {
        // Arrange
        var charge = CreateCardCharge(installments: 12);

        // Act
        var row = _mapper.BuildRow(charge);

        // Assert
        Assert.Contains("12", row);
    }

    [Fact]
    public void BuildRow_WithLargeAmount_ShouldFormatCorrectly()
    {
        // Arrange
        var charge = CreateCardCharge(amount: 1000000); // 10,000.00

        // Act
        var row = _mapper.BuildRow(charge);

        // Assert
        Assert.Contains("10.000,000000", row); // Formato brasileiro
    }

    [Fact]
    public void BuildRow_WithCanceledStatus_ShouldCalculateNetAmountCorrectly()
    {
        // Arrange
        var cardTransaction = new CardTransaction(
            Type: "credit",
            FundingSource: "credit",
            TransactionId: "txn-001",
            FailedAmount: null,
            AuthorizedAmount: 10000,
            CapturedAmount: 10000,
            CanceledAmount: 10000, // Fully canceled
            ChargebackAmount: null,
            ChargebackRefundAmount: null,
            AuthorizationCode: "AUTH001",
            AuthorizedState: null,
            Installments: 1,
            InstallmentsType: "none",
            SchemeBusinessModel: "",
            FeeAmount: null,
            FullFeeAmount: null,
            MdrAmount: null,
            FullMdrAmount: 500,
            MdrRefundAmount: null,
            FullMdrRefundAmount: 500,
            FullFcAmount: null,
            FullFcRefundAmount: null,
            RavAmount: null,
            FullRavAmount: null,
            RavRefundAmount: null,
            FullRavRefundAmount: null,
            Customer: null,
            Card: new Card(
                Brand: "visa",
                BrandId: 1,
                FirstSixDigits: "424242",
                LastFourDigits: "4242",
                EntryMode: "chip",
                HolderName: "JOHN DOE",
                ExpMonth: "12",
                ExpYear: "2025",
                CountryCode: 76,
                CurrencyCode: 986,
                NumberToken: null,
                Label: null
            ),
            Terminal: new CardTerminal("ecommerce", "12345"),
            Last: null,
            Details: null!
        );

        var charge = new Charge(
            Id: "charge-cancel-001",
            InitiatorId: "init-001",
            Product: null,
            Origin: null,
            OriginId: null,
            Amount: 10000,
            UpdatedAmount: null,
            NetAmount: null,
            FullNetAmount: null,
            Status: "canceled",
            PaymentMethod: "card",
            CreatedAt: DateTimeOffset.Now,
            PlatformName: null,
            AttemptCount: null,
            Gateway: null,
            GatewayOrderId: "order-001",
            Code: null,
            AllIds: null,
            Merchant: CreateMerchant(),
            Split: new List<Split>(),
            CardTransaction: cardTransaction,
            PixTransaction: null,
            BoletoTransaction: null,
            CashTransaction: null
        );

        // Act
        var row = _mapper.BuildRow(charge);

        // Assert
        Assert.NotNull(row);
    }

    #endregion

    #region Helper Methods

    private static Charge CreateCardCharge(int amount = 10000, int installments = 3)
    {
        var cardTransaction = new CardTransaction(
            Type: "credit",
            FundingSource: "credit",
            TransactionId: "txn-001",
            FailedAmount: null,
            AuthorizedAmount: amount,
            CapturedAmount: amount,
            CanceledAmount: 0,
            ChargebackAmount: null,
            ChargebackRefundAmount: null,
            AuthorizationCode: "AUTH123",
            AuthorizedState: null,
            Installments: installments,
            InstallmentsType: "merchant",
            SchemeBusinessModel: "",
            FeeAmount: null,
            FullFeeAmount: null,
            MdrAmount: 300,
            FullMdrAmount: 300,
            MdrRefundAmount: null,
            FullMdrRefundAmount: null,
            FullFcAmount: null,
            FullFcRefundAmount: null,
            RavAmount: 100,
            FullRavAmount: 100,
            RavRefundAmount: null,
            FullRavRefundAmount: null,
            Customer: null,
            Card: new Card(
                Brand: "visa",
                BrandId: 1,
                FirstSixDigits: "424242",
                LastFourDigits: "4242",
                EntryMode: "chip",
                HolderName: "JOHN DOE",
                ExpMonth: "12",
                ExpYear: "2025",
                CountryCode: 76,
                CurrencyCode: 986,
                NumberToken: null,
                Label: null
            ),
            Terminal: new CardTerminal("ecommerce", "12345"),
            Last: null,
            Details: null!
        );

        return new Charge(
            Id: "charge-card-001",
            InitiatorId: "init-001",
            Product: null,
            Origin: null,
            OriginId: null,
            Amount: amount,
            UpdatedAmount: null,
            NetAmount: null,
            FullNetAmount: null,
            Status: "paid",
            PaymentMethod: "card",
            CreatedAt: DateTimeOffset.Now,
            PlatformName: null,
            AttemptCount: null,
            Gateway: null,
            GatewayOrderId: "order-001",
            Code: null,
            AllIds: null,
            Merchant: CreateMerchant(),
            Split: new List<Split>(),
            CardTransaction: cardTransaction,
            PixTransaction: null,
            BoletoTransaction: null,
            CashTransaction: null
        );
    }

    private static Charge CreatePixCharge(int amount = 10000)
    {
        var pixTransaction = new PixTransaction(
            Type: "pix",
            TransactionId: "txn-pix-001",
            E2eId: "E2E123456",
            PixKey: "pix@example.com",
            IsPixSaleKey: false,
            PixKeyNickname: null,
            PaidAmount: amount,
            FineAmount: null,
            InterestAmount: null,
            DiscountAmount: null,
            ReductionAmount: null,
            CanceledAmount: 0,
            FeeAmount: 100,
            FullFeeAmount: 100,
            FullMdrAmount: null,
            FullMdrRefundAmount: null,
            FullRavAmount: null,
            FullRavRefundAmount: null,
            FullFcAmount: null,
            FullFcRefundAmount: null,
            ExpireAt: null,
            PaymentLimitPeriodDays: null,
            BusinessDaysOnly: null,
            ExpiresIn: null,
            Fine: null,
            Interest: null,
            Discounts: null,
            Reduction: null,
            RequestForPayer: null,
            AdditionalData: null,
            Customer: null!,
            Payer: null!,
            Terminal: new PixTerminal("ecommerce", "12345"),
            Last: null,
            Details: null!
        );

        return new Charge(
            Id: "charge-pix-001",
            InitiatorId: "init-001",
            Product: null,
            Origin: null,
            OriginId: null,
            Amount: amount,
            UpdatedAmount: null,
            NetAmount: null,
            FullNetAmount: null,
            Status: "paid",
            PaymentMethod: "pix",
            CreatedAt: DateTimeOffset.Now,
            PlatformName: null,
            AttemptCount: null,
            Gateway: null,
            GatewayOrderId: "order-002",
            Code: null,
            AllIds: null,
            Merchant: CreateMerchant(),
            Split: new List<Split>(),
            CardTransaction: null,
            PixTransaction: pixTransaction,
            BoletoTransaction: null,
            CashTransaction: null
        );
    }

    private static Charge CreateBoletoCharge(int amount = 10000)
    {
        var boletoTransaction = new BoletoTransaction(
            Type: "boleto",
            TransactionId: "txn-boleto-001",
            OurNumber: "12345678901",
            PaidAmount: amount,
            FineAmount: null,
            InterestAmount: null,
            DiscountAmount: null,
            CanceledAmount: 0,
            FeeAmount: 200,
            FullFeeAmount: null,
            FullMdrAmount: null,
            FullMdrRefundAmount: null,
            FullRavAmount: null,
            FullRavRefundAmount: null,
            FullFcAmount: null,
            FullFcRefundAmount: null,
            ExpireAt: "2024-12-31",
            LimitDate: null,
            Barcode: "34191234567890123456789012345678901234",
            WritableLine: "34191.23456 78901.234567 89012.345678 9 01234567890123",
            Instructions: null,
            Url: "https://example.com/boleto",
            Bank: new Bank("001", "Banco do Brasil"),
            Receiver: null,
            Fine: null,
            Interest: null,
            Discounts: null,
            DocumentNumber: null,
            PaidAt: null,
            Customer: null,
            Last: null,
            Details: null!
        );

        return new Charge(
            Id: "charge-boleto-001",
            InitiatorId: "init-001",
            Product: null,
            Origin: null,
            OriginId: null,
            Amount: amount,
            UpdatedAmount: null,
            NetAmount: null,
            FullNetAmount: null,
            Status: "paid",
            PaymentMethod: "boleto",
            CreatedAt: DateTimeOffset.Now,
            PlatformName: null,
            AttemptCount: null,
            Gateway: null,
            GatewayOrderId: "order-003",
            Code: null,
            AllIds: null,
            Merchant: CreateMerchant(),
            Split: new List<Split>(),
            CardTransaction: null,
            PixTransaction: null,
            BoletoTransaction: boletoTransaction,
            CashTransaction: null
        );
    }

    private static Charge CreateMinimalCharge()
    {
        return new Charge(
            Id: "charge-minimal",
            InitiatorId: "init-001",
            Product: null,
            Origin: null,
            OriginId: null,
            Amount: 1000,
            UpdatedAmount: null,
            NetAmount: null,
            FullNetAmount: null,
            Status: "paid",
            PaymentMethod: "card",
            CreatedAt: DateTimeOffset.Now,
            PlatformName: null,
            AttemptCount: null,
            Gateway: null,
            GatewayOrderId: "order-minimal",
            Code: null,
            AllIds: null,
            Merchant: CreateMerchant(),
            Split: new List<Split>(),
            CardTransaction: new CardTransaction(
                Type: "",
                FundingSource: "",
                TransactionId: "",
                FailedAmount: null,
                AuthorizedAmount: 0,
                CapturedAmount: 0,
                CanceledAmount: 0,
                ChargebackAmount: null,
                ChargebackRefundAmount: null,
                AuthorizationCode: "",
                AuthorizedState: null,
                Installments: null,
                InstallmentsType: "",
                SchemeBusinessModel: "",
                FeeAmount: null,
                FullFeeAmount: null,
                MdrAmount: null,
                FullMdrAmount: null,
                MdrRefundAmount: null,
                FullMdrRefundAmount: null,
                FullFcAmount: null,
                FullFcRefundAmount: null,
                RavAmount: null,
                FullRavAmount: null,
                RavRefundAmount: null,
                FullRavRefundAmount: null,
                Customer: null,
                Card: new Card(
                    Brand: "",
                    BrandId: 0,
                    FirstSixDigits: "",
                    LastFourDigits: "",
                    EntryMode: "",
                    HolderName: "",
                    ExpMonth: "",
                    ExpYear: "",
                    CountryCode: 0,
                    CurrencyCode: 0,
                    NumberToken: null,
                    Label: null
                ),
                Terminal: new CardTerminal("", ""),
                Last: null,
                Details: null!
            ),
            PixTransaction: null,
            BoletoTransaction: null,
            CashTransaction: null
        );
    }

    private static Charge CreateCardChargeWithDetails(int amount = 10000, int installments = 3)
    {
        var details = new List<CardDetail>
        {
            new(
                Operation: "authorization",
                OperationId: "op-001",
                OperationAmount: amount,
                ProviderDatetime: DateTime.Now.AddMinutes(-10),
                LocalDatetime: null,
                AcquirerMessage: "Approved",
                AcquirerReturnCode: "00",
                OperationReason: null,
                Pgid: "pg-001",
                Acquirer: new Acquirer("Stone", "123456", "789012"),
                GatewayResponse: new GatewayResponse("00", "Approved"),
                AntifraudResponse: new AntifraudResponse("antifraud-provider", "95", "approved"),
                Legacy: null,
                OperationStatus: "approved"
            ),
            new(
                Operation: "capture",
                OperationId: "op-002",
                OperationAmount: amount,
                ProviderDatetime: DateTime.Now,
                LocalDatetime: null,
                AcquirerMessage: "Approved",
                AcquirerReturnCode: "00",
                OperationReason: null,
                Pgid: "pg-001",
                Acquirer: new Acquirer("Stone", "123456", "789012"),
                GatewayResponse: new GatewayResponse("00", "Approved"),
                AntifraudResponse: null,
                Legacy: null,
                OperationStatus: "approved"
            )
        };

        var cardTransaction = new CardTransaction(
            Type: "credit",
            FundingSource: "credit",
            TransactionId: "txn-001",
            FailedAmount: null,
            AuthorizedAmount: amount,
            CapturedAmount: amount,
            CanceledAmount: 0,
            ChargebackAmount: null,
            ChargebackRefundAmount: null,
            AuthorizationCode: "AUTH123",
            AuthorizedState: null,
            Installments: installments,
            InstallmentsType: "merchant",
            SchemeBusinessModel: "",
            FeeAmount: null,
            FullFeeAmount: null,
            MdrAmount: 300,
            FullMdrAmount: 300,
            MdrRefundAmount: null,
            FullMdrRefundAmount: null,
            FullFcAmount: null,
            FullFcRefundAmount: null,
            RavAmount: 100,
            FullRavAmount: 100,
            RavRefundAmount: null,
            FullRavRefundAmount: null,
            Customer: null,
            Card: new Card(
                Brand: "visa",
                BrandId: 1,
                FirstSixDigits: "424242",
                LastFourDigits: "4242",
                EntryMode: "chip",
                HolderName: "JOHN DOE",
                ExpMonth: "12",
                ExpYear: "2025",
                CountryCode: 76,
                CurrencyCode: 986,
                NumberToken: null,
                Label: null
            ),
            Terminal: new CardTerminal("ecommerce", "12345"),
            Last: null,
            Details: details
        );

        return new Charge(
            Id: "charge-card-001",
            ChargeId: "charge-card-001",
            InitiatorId: "init-001",
            Product: null,
            Origin: null,
            OriginId: null,
            Amount: amount,
            UpdatedAmount: null,
            NetAmount: null,
            FullNetAmount: null,
            Status: "paid",
            PaymentMethod: "card",
            CreatedAt: DateTimeOffset.Now,
            PlatformName: null,
            AttemptCount: null,
            Gateway: null,
            GatewayOrderId: "order-001",
            Code: null,
            AllIds: null,
            Merchant: CreateMerchant(),
            Split: new List<Split>(),
            CardTransaction: cardTransaction,
            PixTransaction: null,
            BoletoTransaction: null,
            CashTransaction: null
        );
    }

    private static Merchant CreateMerchant()
    {
        return new Merchant(
            Organization: "org-001",
            Document: "12345678901234",
            UserId: "user-001",
            AffiliationKey: "key-001",
            AffiliationCode: "1234567",
            AccountId: "acc-001",
            MerchantId: "merch-001",
            StoneAccount: null,
            PaymentProfileId: "PP123"
        );
    }

    private static string GetColumnValue(string row, int index)
    {
        return row.Split(';')[index];
    }

    #endregion

    #region Turbo Anticipation Fee Tests

    [Fact]
    public void CalculateRavTurboFeeAmount_WithTurboFee_ShouldSumAmounts()
    {
        // Arrange
        var financialMovements = new List<ChargeFinancialMovement>
        {
            new(
                Operation: "capture", OperationId: "op-001", DetailOperationId: null,
                CurrentDueDate: null, OriginalDueDate: null, PaymentOwnerDocument: null,
                SettlementStatus: null, Category: null, InstallmentNumber: 1,
                Amount: new FinancialMovementAmount(
                    Gross: 10000m, Net: 9200m,
                    DiscountRate: null,
                    PrepaymentFee: null,
                    FraudCoverage: null,
                    PrepaymentFeeTurbo: new FinancialMovementFee("turbo", 2.5m, -300m, -250m)
                ),
                Id: "fm-001", PaymentMethod: "card", SplitRuleId: null, BulkAnticipationId: null,
                PaymentOwnerId: null, RecipientId: null, PaymentOwnerStoneAccount: null,
                CreatedAt: null, LatestEventDatetime: null
            ),
            new(
                Operation: "capture", OperationId: "op-002", DetailOperationId: null,
                CurrentDueDate: null, OriginalDueDate: null, PaymentOwnerDocument: null,
                SettlementStatus: null, Category: null, InstallmentNumber: 2,
                Amount: new FinancialMovementAmount(
                    Gross: 10000m, Net: 9200m,
                    DiscountRate: null,
                    PrepaymentFee: null,
                    FraudCoverage: null,
                    PrepaymentFeeTurbo: new FinancialMovementFee("turbo", 2.5m, -200m, -150m)
                ),
                Id: "fm-002", PaymentMethod: "card", SplitRuleId: null, BulkAnticipationId: null,
                PaymentOwnerId: null, RecipientId: null, PaymentOwnerStoneAccount: null,
                CreatedAt: null, LatestEventDatetime: null
            )
        };

        // Act: amounts = -250 + -150 = -400
        var result = SaleCsvMapper.CalculateRavTurboFeeAmount(financialMovements);

        // Assert
        Assert.Equal(-400.0, result);
    }

    [Fact]
    public void CalculateRavTurboFeeAmount_WithNullTurboFee_ShouldReturnZero()
    {
        // Arrange: financial movements with no turbo
        var financialMovements = ChargeTestFactory.CreateFinancialMovements();

        // Act
        var result = SaleCsvMapper.CalculateRavTurboFeeAmount(financialMovements);

        // Assert
        Assert.Equal(0.0, result);
    }

    [Fact]
    public void CalculateRavTurboFeeAmount_WithNullList_ShouldReturnZero()
    {
        Assert.Equal(0.0, SaleCsvMapper.CalculateRavTurboFeeAmount(null));
    }

    #endregion
}

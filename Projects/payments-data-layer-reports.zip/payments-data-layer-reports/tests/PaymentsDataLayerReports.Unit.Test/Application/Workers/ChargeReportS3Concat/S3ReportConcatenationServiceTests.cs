using System.Text;
using Amazon.S3;
using Amazon.S3.Model;
using Microsoft.Extensions.Options;
using NSubstitute;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Interfaces;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Models;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Concat;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;
using PaymentsDataLayerReports.Application.Workers.ChargeReportWorker;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.ChargeReportS3Concat;

public class S3ReportConcatenationServiceTests
{
    private static ReportMetadata CreateMetadata()
    {
        var today = DateTimeOffset.UtcNow.Date;

        return new ReportMetadata
        {
            Status = "Processing",
            ReportId = "test-report",
            DispatchId = "dispatch-1",
            CreatedAt = DateTime.UtcNow,
            ReportSortColumnIndex = 0,
            ProcessorQueueName = "queue",
            FileFormat = "csv",
            ChargeReportParameters = new ChargeReportsWorkerParameters
            {
                ReportType = "charges_list",
                StartDate = today,
                EndDate = today
            }
        };
    }

    private static S3ReportConcatenationService CreateService(
        IAmazonS3 s3Client,
        IS3CsvPartialReportRecordSource recordSource,
        IReportMergeEngine mergeEngine,
        IReportStreamWriterFactory writerFactory)
    {
        var awsOptions = Options.Create(new AwsSettings { WorkgroupBucket = "bucket-test" });
        return new S3ReportConcatenationService(s3Client, awsOptions, recordSource, mergeEngine, writerFactory);
    }

    private static GetObjectResponse CreateGetObjectResponse(string content)
    {
        var response = new GetObjectResponse
        {
            ResponseStream = new MemoryStream(Encoding.UTF8.GetBytes(content))
        };
        return response;
    }

    [Fact]
    public async Task ConcatAsync_HappyPath_ShouldReadHeaderMergeRecordsAndComplete()
    {
        var s3Client = Substitute.For<IAmazonS3>();
        var recordSource = Substitute.For<IS3CsvPartialReportRecordSource>();
        var mergeEngine = Substitute.For<IReportMergeEngine>();
        var writer = Substitute.For<IReportStreamWriter<string>>();
        var writerFactory = Substitute.For<IReportStreamWriterFactory>();
        writerFactory.Create<string>(Arg.Any<string>()).Returns(writer);

        s3Client
            .GetObjectAsync(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(Task.FromResult(CreateGetObjectResponse("header-line")));

        var records = GetRecords();

        mergeEngine
            .MergeOrderedAsync(Arg.Any<IAsyncEnumerable<IAsyncEnumerable<ReportRecord>>>(), Arg.Any<ReportMetadata>(), Arg.Any<CancellationToken>())
            .Returns(callInfo => records);

        var service = CreateService(s3Client, recordSource, mergeEngine, writerFactory);
        var metadata = CreateMetadata();

        await service.ConcatAsync("concat-1", metadata, CancellationToken.None);

        writerFactory.Received(1).Create<string>(metadata.FileFormat);
        await writer.Received(1).InitializeAsync(metadata.ReportId, Arg.Any<CancellationToken>());
        await writer.Received(1).WriteHeaderAsync("header-line", Arg.Any<CancellationToken>());
        await writer.Received(2).WriteRecordAsync(Arg.Any<string>(), Arg.Any<CancellationToken>());

        await writer.Received(1).CompleteAsync(Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task ConcatAsync_WhenMergeThrows_ShouldAbortAndRethrow()
    {
        var s3Client = Substitute.For<IAmazonS3>();
        var recordSource = Substitute.For<IS3CsvPartialReportRecordSource>();
        var mergeEngine = Substitute.For<IReportMergeEngine>();
        var writer = Substitute.For<IReportStreamWriter<string>>();
        var writerFactory = Substitute.For<IReportStreamWriterFactory>();
        writerFactory.Create<string>(Arg.Any<string>()).Returns(writer);

        s3Client
            .GetObjectAsync(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(Task.FromResult(CreateGetObjectResponse("header-line")));

        mergeEngine
            .MergeOrderedAsync(Arg.Any<IAsyncEnumerable<IAsyncEnumerable<ReportRecord>>>(), Arg.Any<ReportMetadata>(), Arg.Any<CancellationToken>())
            .Returns(_ => ThrowingRecords());

        var service = CreateService(s3Client, recordSource, mergeEngine, writerFactory);
        var metadata = CreateMetadata();

        await Assert.ThrowsAsync<InvalidOperationException>(() => service.ConcatAsync("concat-err", metadata, CancellationToken.None));

        await writer.Received(1).AbortAsync(Arg.Any<CancellationToken>());
    }

    private static async IAsyncEnumerable<ReportRecord> GetRecords()
    {
        yield return new ReportRecord("line-1", "2025-01-02");
        await Task.Yield();
        yield return new ReportRecord("line-2", "2025-01-01");
    }

    private static IAsyncEnumerable<ReportRecord> ThrowingRecords()
    {
        throw new InvalidOperationException("merge failed");
    }

    [Fact]
    public async Task ConcatAsync_WithEmptyHeader_ShouldNotWriteHeader()
    {
        var s3Client = Substitute.For<IAmazonS3>();
        var recordSource = Substitute.For<IS3CsvPartialReportRecordSource>();
        var mergeEngine = Substitute.For<IReportMergeEngine>();
        var writer = Substitute.For<IReportStreamWriter<string>>();
        var writerFactory = Substitute.For<IReportStreamWriterFactory>();
        writerFactory.Create<string>(Arg.Any<string>()).Returns(writer);

        s3Client
            .GetObjectAsync(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(Task.FromResult(CreateGetObjectResponse("")));

        mergeEngine
            .MergeOrderedAsync(Arg.Any<IAsyncEnumerable<IAsyncEnumerable<ReportRecord>>>(), Arg.Any<ReportMetadata>(), Arg.Any<CancellationToken>())
            .Returns(callInfo => EmptyRecords());

        var service = CreateService(s3Client, recordSource, mergeEngine, writerFactory);
        var metadata = CreateMetadata();

        await service.ConcatAsync("concat-1", metadata, CancellationToken.None);

        await writer.DidNotReceive().WriteHeaderAsync(Arg.Any<string>(), Arg.Any<CancellationToken>());
        await writer.Received(1).CompleteAsync(Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task ConcatAsync_WithNoRecords_ShouldCompleteSuccessfully()
    {
        var s3Client = Substitute.For<IAmazonS3>();
        var recordSource = Substitute.For<IS3CsvPartialReportRecordSource>();
        var mergeEngine = Substitute.For<IReportMergeEngine>();
        var writer = Substitute.For<IReportStreamWriter<string>>();
        var writerFactory = Substitute.For<IReportStreamWriterFactory>();
        writerFactory.Create<string>(Arg.Any<string>()).Returns(writer);

        s3Client
            .GetObjectAsync(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(Task.FromResult(CreateGetObjectResponse("header-line")));

        mergeEngine
            .MergeOrderedAsync(Arg.Any<IAsyncEnumerable<IAsyncEnumerable<ReportRecord>>>(), Arg.Any<ReportMetadata>(), Arg.Any<CancellationToken>())
            .Returns(callInfo => EmptyRecords());

        var service = CreateService(s3Client, recordSource, mergeEngine, writerFactory);
        var metadata = CreateMetadata();

        await service.ConcatAsync("concat-1", metadata, CancellationToken.None);

        await writer.Received(1).WriteHeaderAsync("header-line", Arg.Any<CancellationToken>());
        await writer.DidNotReceive().WriteRecordAsync(Arg.Any<string>(), Arg.Any<CancellationToken>());
        await writer.Received(1).CompleteAsync(Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task ConcatAsync_WhenHeaderReadFails_ShouldAbortAndRethrow()
    {
        var s3Client = Substitute.For<IAmazonS3>();
        var recordSource = Substitute.For<IS3CsvPartialReportRecordSource>();
        var mergeEngine = Substitute.For<IReportMergeEngine>();
        var writer = Substitute.For<IReportStreamWriter<string>>();
        var writerFactory = Substitute.For<IReportStreamWriterFactory>();
        writerFactory.Create<string>(Arg.Any<string>()).Returns(writer);

        s3Client
            .GetObjectAsync(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns<GetObjectResponse>(_ => throw new InvalidOperationException("S3 error"));

        var service = CreateService(s3Client, recordSource, mergeEngine, writerFactory);
        var metadata = CreateMetadata();

        await Assert.ThrowsAsync<InvalidOperationException>(() => service.ConcatAsync("concat-err", metadata, CancellationToken.None));

        await writer.Received(1).AbortAsync(Arg.Any<CancellationToken>());
    }

    private static async IAsyncEnumerable<ReportRecord> EmptyRecords()
    {
        await Task.CompletedTask;
        yield break;
    }
}

using System.Runtime.CompilerServices;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Models;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Concat;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.ChargeReportS3Concat;

public class KWayMergeEngineTests
{
    private static ReportMetadata CreateMetadata()
    {
        return new ReportMetadata
        {
            Status = "Processing",
            ReportId = "test-report",
            DispatchId = "dispatch-1",
            CreatedAt = DateTime.UtcNow,
            ReportSortColumnIndex = 0,
            ProcessorQueueName = "queue",
            FileFormat = "csv"
        };
    }

    #region Basic Merge Functionality

    [Fact]
    public async Task MergeOrderedAsync_WithMultiplePartitions_ShouldMergeBySortKeyDescending()
    {
        var engine = new KWayMergeEngine();
        var metadata = CreateMetadata();

        async IAsyncEnumerable<ReportRecord> Partition1()
        {
            await Task.Yield();
            yield return new ReportRecord("p1-line2", "2025-01-03");
            yield return new ReportRecord("p1-line1", "2025-01-01");
        }

        async IAsyncEnumerable<ReportRecord> Partition2()
        {
            await Task.Yield();
            yield return new ReportRecord("p2-line1", "2025-01-02");
        }

        async IAsyncEnumerable<IAsyncEnumerable<ReportRecord>> Partitions()
        {
            await Task.Yield();
            yield return Partition1();
            yield return Partition2();
        }

        var result = new List<ReportRecord>();
        await foreach (var record in engine.MergeOrderedAsync(Partitions(), metadata, CancellationToken.None))
        {
            result.Add(record);
        }

        Assert.Equal(3, result.Count);
        Assert.Equal("2025-01-03", result[0].SortKey);
        Assert.Equal("2025-01-02", result[1].SortKey);
        Assert.Equal("2025-01-01", result[2].SortKey);
    }

    [Fact]
    public async Task MergeOrderedAsync_WithSinglePartition_ShouldReturnAllRecordsInOrder()
    {
        var engine = new KWayMergeEngine();
        var metadata = CreateMetadata();

        async IAsyncEnumerable<ReportRecord> SinglePartition()
        {
            await Task.Yield();
            yield return new ReportRecord("line1", "C");
            yield return new ReportRecord("line2", "B");
            yield return new ReportRecord("line3", "A");
        }

        async IAsyncEnumerable<IAsyncEnumerable<ReportRecord>> Partitions()
        {
            await Task.Yield();
            yield return SinglePartition();
        }

        var result = new List<ReportRecord>();
        await foreach (var record in engine.MergeOrderedAsync(Partitions(), metadata, CancellationToken.None))
        {
            result.Add(record);
        }

        Assert.Equal(3, result.Count);
        Assert.Equal("C", result[0].SortKey);
        Assert.Equal("B", result[1].SortKey);
        Assert.Equal("A", result[2].SortKey);
    }

    [Fact]
    public async Task MergeOrderedAsync_WithNoPartitions_ShouldReturnEmpty()
    {
        var engine = new KWayMergeEngine();
        var metadata = CreateMetadata();

        async IAsyncEnumerable<IAsyncEnumerable<ReportRecord>> EmptyPartitions()
        {
            await Task.Yield();
            yield break;
        }

        var result = new List<ReportRecord>();
        await foreach (var record in engine.MergeOrderedAsync(EmptyPartitions(), metadata, CancellationToken.None))
        {
            result.Add(record);
        }

        Assert.Empty(result);
    }

    [Fact]
    public async Task MergeOrderedAsync_WithEmptyPartitions_ShouldSkipThem()
    {
        var engine = new KWayMergeEngine();
        var metadata = CreateMetadata();

        async IAsyncEnumerable<ReportRecord> EmptyPartition()
        {
            await Task.Yield();
            yield break;
        }

        async IAsyncEnumerable<ReportRecord> NonEmptyPartition()
        {
            await Task.Yield();
            yield return new ReportRecord("line1", "A");
        }

        async IAsyncEnumerable<IAsyncEnumerable<ReportRecord>> Partitions()
        {
            await Task.Yield();
            yield return EmptyPartition();
            yield return NonEmptyPartition();
            yield return EmptyPartition();
        }

        var result = new List<ReportRecord>();
        await foreach (var record in engine.MergeOrderedAsync(Partitions(), metadata, CancellationToken.None))
        {
            result.Add(record);
        }

        Assert.Single(result);
        Assert.Equal("A", result[0].SortKey);
    }

    #endregion

    #region Sort Key Comparison

    [Fact]
    public async Task MergeOrderedAsync_WithSameSortKeys_ShouldReturnAllRecords()
    {
        var engine = new KWayMergeEngine();
        var metadata = CreateMetadata();

        async IAsyncEnumerable<ReportRecord> Partition1()
        {
            await Task.Yield();
            yield return new ReportRecord("p1-line1", "2025-01-01");
        }

        async IAsyncEnumerable<ReportRecord> Partition2()
        {
            await Task.Yield();
            yield return new ReportRecord("p2-line1", "2025-01-01");
        }

        async IAsyncEnumerable<IAsyncEnumerable<ReportRecord>> Partitions()
        {
            await Task.Yield();
            yield return Partition1();
            yield return Partition2();
        }

        var result = new List<ReportRecord>();
        await foreach (var record in engine.MergeOrderedAsync(Partitions(), metadata, CancellationToken.None))
        {
            result.Add(record);
        }

        Assert.Equal(2, result.Count);
        Assert.All(result, r => Assert.Equal("2025-01-01", r.SortKey));
    }

    [Fact]
    public async Task MergeOrderedAsync_WithCaseInsensitiveSortKeys_ShouldSortCorrectly()
    {
        var engine = new KWayMergeEngine();
        var metadata = CreateMetadata();

        async IAsyncEnumerable<ReportRecord> Partition1()
        {
            await Task.Yield();
            yield return new ReportRecord("line1", "ABC");
        }

        async IAsyncEnumerable<ReportRecord> Partition2()
        {
            await Task.Yield();
            yield return new ReportRecord("line2", "abc");
        }

        async IAsyncEnumerable<IAsyncEnumerable<ReportRecord>> Partitions()
        {
            await Task.Yield();
            yield return Partition1();
            yield return Partition2();
        }

        var result = new List<ReportRecord>();
        await foreach (var record in engine.MergeOrderedAsync(Partitions(), metadata, CancellationToken.None))
        {
            result.Add(record);
        }

        Assert.Equal(2, result.Count);
    }

    [Fact]
    public async Task MergeOrderedAsync_WithNumericSortKeys_ShouldSortAsStringsDescending()
    {
        var engine = new KWayMergeEngine();
        var metadata = CreateMetadata();

        async IAsyncEnumerable<ReportRecord> Partition1()
        {
            await Task.Yield();
            yield return new ReportRecord("line1", "9");
            yield return new ReportRecord("line2", "10");
        }

        async IAsyncEnumerable<IAsyncEnumerable<ReportRecord>> Partitions()
        {
            await Task.Yield();
            yield return Partition1();
        }

        var result = new List<ReportRecord>();
        await foreach (var record in engine.MergeOrderedAsync(Partitions(), metadata, CancellationToken.None))
        {
            result.Add(record);
        }

        Assert.Equal(2, result.Count);
        // String comparison: "9" > "10" because '9' > '1'
        Assert.Equal("9", result[0].SortKey);
        Assert.Equal("10", result[1].SortKey);
    }

    #endregion

    #region Cancellation

    [Fact]
    public async Task MergeOrderedAsync_WhenCancelled_ShouldThrowOperationCanceledException()
    {
        var engine = new KWayMergeEngine();
        var metadata = CreateMetadata();
        using var cts = new CancellationTokenSource();
        cts.Cancel();

        async IAsyncEnumerable<ReportRecord> Partition([EnumeratorCancellation] CancellationToken ct = default)
        {
            await Task.Yield();
            ct.ThrowIfCancellationRequested();
            yield return new ReportRecord("line1", "A");
        }

        async IAsyncEnumerable<IAsyncEnumerable<ReportRecord>> Partitions()
        {
            await Task.Yield();
            yield return Partition(cts.Token);
        }

        await Assert.ThrowsAsync<OperationCanceledException>(async () =>
        {
            await foreach (var _ in engine.MergeOrderedAsync(Partitions(), metadata, cts.Token))
            {
                // Intentionally empty: just force full enumeration to trigger cancellation
            }
        });
    }

    #endregion

    #region Many Partitions

    [Fact]
    public async Task MergeOrderedAsync_WithManyPartitions_ShouldMergeAllCorrectly()
    {
        var engine = new KWayMergeEngine();
        var metadata = CreateMetadata();

        async IAsyncEnumerable<ReportRecord> CreatePartition(int partitionId, string sortKey)
        {
            await Task.Yield();
            yield return new ReportRecord($"partition-{partitionId}", sortKey);
        }

        async IAsyncEnumerable<IAsyncEnumerable<ReportRecord>> Partitions()
        {
            await Task.Yield();
            yield return CreatePartition(1, "E");
            yield return CreatePartition(2, "C");
            yield return CreatePartition(3, "A");
            yield return CreatePartition(4, "D");
            yield return CreatePartition(5, "B");
        }

        var result = new List<ReportRecord>();
        await foreach (var record in engine.MergeOrderedAsync(Partitions(), metadata, CancellationToken.None))
        {
            result.Add(record);
        }

        Assert.Equal(5, result.Count);
        Assert.Equal("E", result[0].SortKey);
        Assert.Equal("D", result[1].SortKey);
        Assert.Equal("C", result[2].SortKey);
        Assert.Equal("B", result[3].SortKey);
        Assert.Equal("A", result[4].SortKey);
    }

    [Fact]
    public async Task MergeOrderedAsync_WithInterleavedData_ShouldMergeCorrectly()
    {
        var engine = new KWayMergeEngine();
        var metadata = CreateMetadata();

        async IAsyncEnumerable<ReportRecord> Partition1()
        {
            await Task.Yield();
            yield return new ReportRecord("p1-1", "2025-01-05");
            yield return new ReportRecord("p1-2", "2025-01-03");
            yield return new ReportRecord("p1-3", "2025-01-01");
        }

        async IAsyncEnumerable<ReportRecord> Partition2()
        {
            await Task.Yield();
            yield return new ReportRecord("p2-1", "2025-01-04");
            yield return new ReportRecord("p2-2", "2025-01-02");
        }

        async IAsyncEnumerable<IAsyncEnumerable<ReportRecord>> Partitions()
        {
            await Task.Yield();
            yield return Partition1();
            yield return Partition2();
        }

        var result = new List<ReportRecord>();
        await foreach (var record in engine.MergeOrderedAsync(Partitions(), metadata, CancellationToken.None))
        {
            result.Add(record);
        }

        Assert.Equal(5, result.Count);
        Assert.Equal("2025-01-05", result[0].SortKey);
        Assert.Equal("2025-01-04", result[1].SortKey);
        Assert.Equal("2025-01-03", result[2].SortKey);
        Assert.Equal("2025-01-02", result[3].SortKey);
        Assert.Equal("2025-01-01", result[4].SortKey);
    }

    #endregion
}

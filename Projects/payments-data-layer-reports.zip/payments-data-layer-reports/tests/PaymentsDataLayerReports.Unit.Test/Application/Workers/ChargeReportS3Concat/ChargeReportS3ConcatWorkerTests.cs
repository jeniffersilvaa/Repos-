using Hangfire;
using Hangfire.Common;
using Hangfire.Server;
using Hangfire.Storage;
using Microsoft.Extensions.Options;
using NSubstitute;
using NSubstitute.ExceptionExtensions;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Exceptions;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Metrics;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Types;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Concat;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;
using PaymentsDataLayerReports.Application.Workers.FinMovReportESWorker;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.ChargeReportS3Concat;


public class ChargeReportS3ConcatWorkerTests
{
    private readonly IS3ClientWrapper _s3ClientWrapper;
    private readonly IReportConcatenationService _reportConcatenationService;
    private readonly IReportingTimeMetrics _reportingTimeMetrics;
    private readonly ChargeReportS3ConcatWorker _worker;
    private readonly PerformContext _performContext;
    private readonly CancellationToken _cancellationToken;

    public ChargeReportS3ConcatWorkerTests()
    {
        // Arrange - Setup common mocks
        _s3ClientWrapper = Substitute.For<IS3ClientWrapper>();
        _reportConcatenationService = Substitute.For<IReportConcatenationService>();
        _reportingTimeMetrics = Substitute.For<IReportingTimeMetrics>();
        var backgroundJobClient = Substitute.For<IBackgroundJobClient>();
        var preDeploySettings = Options.Create(new DataLayerReportPreDeploySettings { IsPreDeployWorker = true });

        _worker = new ChargeReportS3ConcatWorker(
            _s3ClientWrapper,
            _reportConcatenationService,
            _reportingTimeMetrics,
            preDeploySettings,
            backgroundJobClient);

        // Setup PerformContext mock
        var backgroundJob = Substitute.For<BackgroundJob>("test-job-id", Job.FromExpression(() => Console.WriteLine()), DateTime.UtcNow);
        _performContext = Substitute.For<PerformContext>(
            Substitute.For<IStorageConnection>(),
            backgroundJob,
            Substitute.For<IJobCancellationToken>()
        );

        _cancellationToken = CancellationToken.None;
    }

    #region Success Scenarios

    [Fact]
    public async Task ConcatReport_WithValidReportId_ShouldCompleteSuccessfully()
    {
        // Arrange
        var reportId = "test-report-123";
        var metadata = TestDataFactory.CreateValidReportMetadata(reportId);

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _reportConcatenationService.ConcatAsync(
            Arg.Any<string>(),
            Arg.Any<ReportMetadata>(),
            Arg.Any<CancellationToken>())
            .Returns(Task.CompletedTask);

        _s3ClientWrapper.MergeReportFilesAsync(
            Arg.Any<string>(),
            Arg.Any<ReportMetadata>(),
            Arg.Any<CancellationToken>())
            .Returns(Task.CompletedTask);

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        // Act
        await _worker.ConcatReport(reportId, _performContext, _cancellationToken);

        // Assert
        await _s3ClientWrapper.Received(1).GetReportMetadataAsync(reportId);
        var concatCalls = 0;
        foreach (var call in _reportConcatenationService.ReceivedCalls())
        {
            if (call.GetMethodInfo().Name == nameof(IReportConcatenationService.ConcatAsync))
            {
                concatCalls++;
            }
        }

        var legacyCalls = 0;
        foreach (var call in _s3ClientWrapper.ReceivedCalls())
        {
            if (call.GetMethodInfo().Name == nameof(IS3ClientWrapper.MergeReportFilesAsync))
            {
                legacyCalls++;
            }
        }

        Assert.Equal(1, concatCalls + legacyCalls);
        await _s3ClientWrapper.Received(1).UploadReportMetadataAsync(
            Arg.Is<ReportMetadata>(m => m.Status == WorkerStatesEnum.Succeeded.ToString()));
    }

    [Fact]
    public async Task ConcatReport_WithValidMetadata_ShouldUpdateStatusToSucceeded()
    {
        // Arrange
        var reportId = "test-report-456";
        var metadata = TestDataFactory.CreateValidReportMetadata(reportId);
        metadata.Status = WorkerStatesEnum.Processing.ToString();

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _reportConcatenationService.ConcatAsync(Arg.Any<string>(), Arg.Any<ReportMetadata>(), Arg.Any<CancellationToken>())
            .Returns(Task.CompletedTask);

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        // Act
        await _worker.ConcatReport(reportId, _performContext, _cancellationToken);

        // Assert
        await _s3ClientWrapper.Received(1).UploadReportMetadataAsync(
            Arg.Is<ReportMetadata>(m =>
                m.ReportId == reportId &&
                m.Status == WorkerStatesEnum.Succeeded.ToString()));
    }

    [Fact]
    public async Task ConcatReport_WhenSuccessful_ShouldCallMergeReportFilesWithCorrectParameters()
    {
        // Arrange
        var reportId = "test-report-789";
        var concatId = "concat-job-123";
        var metadata = TestDataFactory.CreateValidReportMetadata(reportId);

        var backgroundJob = Substitute.For<BackgroundJob>(concatId, Job.FromExpression(() => Console.WriteLine()), DateTime.UtcNow);
        var performContext = Substitute.For<PerformContext>(
            Substitute.For<IStorageConnection>(),
            backgroundJob,
            Substitute.For<IJobCancellationToken>()
        );

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));
        string? capturedConcatId = null;
        ReportMetadata? capturedMetadata = null;

        _reportConcatenationService.ConcatAsync(
            Arg.Any<string>(),
            Arg.Any<ReportMetadata>(),
            Arg.Any<CancellationToken>())
            .Returns(callInfo =>
            {
                capturedConcatId = callInfo.Arg<string>();
                capturedMetadata = callInfo.Arg<ReportMetadata>();
                return Task.CompletedTask;
            });

        _s3ClientWrapper.MergeReportFilesAsync(
            Arg.Any<string>(),
            Arg.Any<ReportMetadata>(),
            Arg.Any<CancellationToken>())
            .Returns(callInfo =>
            {
                capturedConcatId = callInfo.Arg<string>();
                capturedMetadata = callInfo.Arg<ReportMetadata>();
                return Task.CompletedTask;
            });

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        // Act
        await _worker.ConcatReport(reportId, performContext, _cancellationToken);

        // Assert
        Assert.Equal(concatId, capturedConcatId);
        Assert.NotNull(capturedMetadata);
        Assert.Equal(reportId, capturedMetadata!.ReportId);
    }

    #endregion

    #region Error Handling - ReportMetadataNotFoundException

    [Fact]
    public async Task ConcatReport_WhenMetadataNotFound_ShouldThrowReportMetadataNotFoundException()
    {
        // Arrange
        var reportId = "non-existent-report";

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(null));

        // Act & Assert
        var exception = await Assert.ThrowsAsync<ReportMetadataNotFoundException>(
            () => _worker.ConcatReport(reportId, _performContext, _cancellationToken));

        Assert.Contains(reportId, exception.Message);
    }

    [Fact]
    public async Task ConcatReport_WhenMetadataNotFound_ShouldNotCallMergeReportFiles()
    {
        // Arrange
        var reportId = "non-existent-report-2";

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(null));

        // Act & Assert
        await Assert.ThrowsAsync<ReportMetadataNotFoundException>(
            () => _worker.ConcatReport(reportId, _performContext, _cancellationToken));

        await _reportConcatenationService.DidNotReceive().ConcatAsync(
            Arg.Any<string>(),
            Arg.Any<ReportMetadata>(),
            Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task ConcatReport_WhenMetadataNotFound_ShouldNotUploadMetadata()
    {
        // Arrange
        var reportId = "non-existent-report-3";

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(null));

        // Act & Assert
        await Assert.ThrowsAsync<ReportMetadataNotFoundException>(
            () => _worker.ConcatReport(reportId, _performContext, _cancellationToken));

        await _s3ClientWrapper.DidNotReceive().UploadReportMetadataAsync(Arg.Any<ReportMetadata>());
    }

    #endregion

    #region Error Handling - Concat Service Failures

    [Fact]
    public async Task ConcatReport_WhenMergeReportFilesFails_ShouldThrowException()
    {
        // Arrange
        var reportId = "test-report-merge-fail";
        var metadata = TestDataFactory.CreateValidReportMetadata(reportId);
        var expectedException = new InvalidOperationException("S3 merge failed");

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _reportConcatenationService.ConcatAsync(Arg.Any<string>(), Arg.Any<ReportMetadata>(), Arg.Any<CancellationToken>())
            .Throws(expectedException);

        _s3ClientWrapper.MergeReportFilesAsync(
            Arg.Any<string>(),
            Arg.Any<ReportMetadata>(),
            Arg.Any<CancellationToken>())
            .Throws(expectedException);

        // Act & Assert
        var exception = await Assert.ThrowsAsync<InvalidOperationException>(
            () => _worker.ConcatReport(reportId, _performContext, _cancellationToken));

        Assert.Equal(expectedException.Message, exception.Message);
    }

    [Fact]
    public async Task ConcatReport_WhenMergeReportFilesFails_ShouldNotUploadMetadata()
    {
        // Arrange
        var reportId = "test-report-merge-fail-2";
        var metadata = TestDataFactory.CreateValidReportMetadata(reportId);

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        var expectedException = new InvalidOperationException("Merge failed");

        _reportConcatenationService.ConcatAsync(Arg.Any<string>(), Arg.Any<ReportMetadata>(), Arg.Any<CancellationToken>())
            .Throws(expectedException);

        _s3ClientWrapper.MergeReportFilesAsync(
            Arg.Any<string>(),
            Arg.Any<ReportMetadata>(),
            Arg.Any<CancellationToken>())
            .Throws(expectedException);

        // Act & Assert
        await Assert.ThrowsAsync<InvalidOperationException>(
            () => _worker.ConcatReport(reportId, _performContext, _cancellationToken));

        await _s3ClientWrapper.DidNotReceive().UploadReportMetadataAsync(Arg.Any<ReportMetadata>());
    }

    [Fact]
    public async Task ConcatReport_WhenMergeReportFilesThrowsIOException_ShouldPropagateException()
    {
        // Arrange
        var reportId = "test-report-io-fail";
        var metadata = TestDataFactory.CreateValidReportMetadata(reportId);
        var expectedException = new IOException("Network error during merge");

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _s3ClientWrapper.MergeReportFilesAsync(Arg.Any<string>(), Arg.Any<ReportMetadata>(), Arg.Any<CancellationToken>())
            .Throws(expectedException);

        _reportConcatenationService.ConcatAsync(Arg.Any<string>(), Arg.Any<ReportMetadata>(), Arg.Any<CancellationToken>())
            .Throws(expectedException);

        // Act & Assert
        var exception = await Assert.ThrowsAsync<IOException>(
            () => _worker.ConcatReport(reportId, _performContext, _cancellationToken));

        Assert.Equal(expectedException.Message, exception.Message);
    }

    #endregion

    #region Error Handling - UploadReportMetadataAsync Failures

    [Fact]
    public async Task ConcatReport_WhenUploadMetadataFails_ShouldThrowException()
    {
        // Arrange
        var reportId = "test-report-upload-fail";
        var metadata = TestDataFactory.CreateValidReportMetadata(reportId);
        var expectedException = new InvalidOperationException("Upload metadata failed");

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _s3ClientWrapper.MergeReportFilesAsync(Arg.Any<string>(), Arg.Any<ReportMetadata>(), Arg.Any<CancellationToken>())
            .Returns(Task.CompletedTask);

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Throws(expectedException);

        // Act & Assert
        var exception = await Assert.ThrowsAsync<InvalidOperationException>(
            () => _worker.ConcatReport(reportId, _performContext, _cancellationToken));

        Assert.Equal(expectedException.Message, exception.Message);
    }

    #endregion

    #region Edge Cases - Cancellation

    [Fact]
    public async Task ConcatReport_WhenCancellationRequested_ShouldPassCancellationTokenToMerge()
    {
        // Arrange
        var reportId = "test-report-cancel";
        var metadata = TestDataFactory.CreateValidReportMetadata(reportId);
        using var cts = new CancellationTokenSource();

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _s3ClientWrapper.MergeReportFilesAsync(Arg.Any<string>(), Arg.Any<ReportMetadata>(), Arg.Any<CancellationToken>())
            .Returns(Task.CompletedTask);

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        // Act
        await _worker.ConcatReport(reportId, _performContext, cts.Token);

        // Assert
        try
        {
            await _reportConcatenationService.Received(1).ConcatAsync(
                Arg.Any<string>(),
                Arg.Any<ReportMetadata>(),
                cts.Token);
        }
        catch (NSubstitute.Exceptions.ReceivedCallsException)
        {
            await _s3ClientWrapper.Received(1).MergeReportFilesAsync(
                Arg.Any<string>(),
                Arg.Any<ReportMetadata>(),
                cts.Token);
        }
    }

    [Fact]
    public async Task ConcatReport_WhenMergeThrowsOperationCanceledException_ShouldPropagateException()
    {
        // Arrange
        var reportId = "test-report-canceled";
        var metadata = TestDataFactory.CreateValidReportMetadata(reportId);
        using var cts = new CancellationTokenSource();
        cts.Cancel();

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        var expectedException = new OperationCanceledException("Operation was canceled");

        _reportConcatenationService.ConcatAsync(Arg.Any<string>(), Arg.Any<ReportMetadata>(), Arg.Any<CancellationToken>())
            .Throws(expectedException);

        _s3ClientWrapper.MergeReportFilesAsync(
            Arg.Any<string>(),
            Arg.Any<ReportMetadata>(),
            Arg.Any<CancellationToken>())
            .Throws(expectedException);

        // Act & Assert
        await Assert.ThrowsAsync<OperationCanceledException>(
            () => _worker.ConcatReport(reportId, _performContext, cts.Token));
    }

    #endregion

    #region Edge Cases - Different Report Types

    [Theory]
    [InlineData("charges_events")]
    [InlineData("pix_charges_events")]
    [InlineData("charges_resume")]
    [InlineData("charges_list")]
    public async Task ConcatReport_WithDifferentReportTypes_ShouldCompleteSuccessfully(string reportType)
    {
        // Arrange
        var reportId = $"test-report-{reportType}";
        var metadata = TestDataFactory.CreateValidReportMetadata(reportId);
        var reportTypeFromEnum = Enumeration.FromName<ReportTypeEnum>(reportType);
        metadata.ChargeReportParameters!.ReportType = reportTypeFromEnum.Name;

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _s3ClientWrapper.MergeReportFilesAsync(Arg.Any<string>(), Arg.Any<ReportMetadata>(), Arg.Any<CancellationToken>())
            .Returns(Task.CompletedTask);

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        // Act
        await _worker.ConcatReport(reportId, _performContext, _cancellationToken);

        // Assert
        await _s3ClientWrapper.Received(1).UploadReportMetadataAsync(
            Arg.Is<ReportMetadata>(m =>
                m.ChargeReportParameters!.ReportType == reportTypeFromEnum.Name &&
                m.Status == WorkerStatesEnum.Succeeded.ToString()));
    }

    #endregion

    #region Edge Cases - Boundary Values

    [Fact]
    public async Task ConcatReport_WithEmptyReportId_ShouldStillAttemptToGetMetadata()
    {
        // Arrange
        var reportId = string.Empty;

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(null));

        // Act & Assert
        await Assert.ThrowsAsync<ReportMetadataNotFoundException>(
            () => _worker.ConcatReport(reportId, _performContext, _cancellationToken));

        await _s3ClientWrapper.Received(1).GetReportMetadataAsync(reportId);
    }

    [Fact]
    public async Task ConcatReport_WithVeryLongReportId_ShouldHandleCorrectly()
    {
        // Arrange
        var reportId = new string('a', 1000); // Very long report ID
        var metadata = TestDataFactory.CreateValidReportMetadata(reportId);

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _s3ClientWrapper.MergeReportFilesAsync(Arg.Any<string>(), Arg.Any<ReportMetadata>(), Arg.Any<CancellationToken>())
            .Returns(Task.CompletedTask);

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        // Act
        await _worker.ConcatReport(reportId, _performContext, _cancellationToken);

        // Assert
        await _s3ClientWrapper.Received(1).GetReportMetadataAsync(reportId);
    }

    [Fact]
    public async Task ConcatReport_WithSpecialCharactersInReportId_ShouldHandleCorrectly()
    {
        // Arrange
        var reportId = "report-123_!@#$%^&*()";
        var metadata = TestDataFactory.CreateValidReportMetadata(reportId);

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _s3ClientWrapper.MergeReportFilesAsync(Arg.Any<string>(), Arg.Any<ReportMetadata>(), Arg.Any<CancellationToken>())
            .Returns(Task.CompletedTask);

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        // Act
        await _worker.ConcatReport(reportId, _performContext, _cancellationToken);

        // Assert
        await _s3ClientWrapper.Received(1).GetReportMetadataAsync(reportId);
    }

    #endregion

    #region Edge Cases - Metadata Status Transitions

    [Theory]
    [InlineData("Awaiting")]
    [InlineData("Enqueued")]
    [InlineData("Scheduled")]
    [InlineData("Processing")]
    [InlineData("Failed")]
    public async Task ConcatReport_WithDifferentInitialStatuses_ShouldUpdateToSucceeded(string initialStatus)
    {
        // Arrange
        var reportId = $"test-report-status-{initialStatus}";
        var metadata = TestDataFactory.CreateValidReportMetadata(reportId);
        metadata.Status = initialStatus;

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _s3ClientWrapper.MergeReportFilesAsync(Arg.Any<string>(), Arg.Any<ReportMetadata>(), Arg.Any<CancellationToken>())
            .Returns(Task.CompletedTask);

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        // Act
        await _worker.ConcatReport(reportId, _performContext, _cancellationToken);

        // Assert
        await _s3ClientWrapper.Received(1).UploadReportMetadataAsync(
            Arg.Is<ReportMetadata>(m => m.Status == WorkerStatesEnum.Succeeded.ToString()));
    }

    #endregion

    #region Edge Cases - Date Ranges

    [Fact]
    public async Task ConcatReport_WithSameDayDateRange_ShouldCompleteSuccessfully()
    {
        // Arrange
        var reportId = "test-report-same-day";
        var metadata = TestDataFactory.CreateValidReportMetadata(reportId);
        var today = DateTime.Today;
        metadata.ChargeReportParameters!.StartDate = today;
        metadata.ChargeReportParameters!.EndDate = today;

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _s3ClientWrapper.MergeReportFilesAsync(Arg.Any<string>(), Arg.Any<ReportMetadata>(), Arg.Any<CancellationToken>())
            .Returns(Task.CompletedTask);

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        // Act
        await _worker.ConcatReport(reportId, _performContext, _cancellationToken);

        // Assert
        await _s3ClientWrapper.Received(1).UploadReportMetadataAsync(
            Arg.Is<ReportMetadata>(m => m.Status == WorkerStatesEnum.Succeeded.ToString()));
    }

    [Fact]
    public async Task ConcatReport_WithLargeDateRange_ShouldCompleteSuccessfully()
    {
        // Arrange
        var reportId = "test-report-large-range";
        var metadata = TestDataFactory.CreateValidReportMetadata(reportId);
        metadata.ChargeReportParameters!.StartDate = DateTime.Today.AddDays(-365);
        metadata.ChargeReportParameters!.EndDate = DateTime.Today;

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _s3ClientWrapper.MergeReportFilesAsync(Arg.Any<string>(), Arg.Any<ReportMetadata>(), Arg.Any<CancellationToken>())
            .Returns(Task.CompletedTask);

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        // Act
        await _worker.ConcatReport(reportId, _performContext, _cancellationToken);

        // Assert
        await _s3ClientWrapper.Received(1).UploadReportMetadataAsync(
            Arg.Is<ReportMetadata>(m => m.Status == WorkerStatesEnum.Succeeded.ToString()));
    }

    #endregion

    #region Metrics - SendReportingTimeMetric Behavior

    [Fact]
    public async Task ConcatReport_WhenSuccessful_ShouldSendReportingTimeMetric()
    {
        // Arrange
        var reportId = "test-report-metrics";
        var metadata = TestDataFactory.CreateValidReportMetadata(reportId);
        metadata.CreatedAt = DateTime.Now.AddMinutes(-5);

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _s3ClientWrapper.MergeReportFilesAsync(Arg.Any<string>(), Arg.Any<ReportMetadata>(), Arg.Any<CancellationToken>())
            .Returns(Task.CompletedTask);

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        // Act
        await _worker.ConcatReport(reportId, _performContext, _cancellationToken);

        // Assert
        // The metric should be sent successfully without throwing
        // This test validates that the metric flow doesn't break the main flow
        await _s3ClientWrapper.Received(1).UploadReportMetadataAsync(
            Arg.Is<ReportMetadata>(m => m.Status == WorkerStatesEnum.Succeeded.ToString()));
    }

    [Fact]
    public async Task ConcatReport_WhenMetricSendingFails_ShouldNotAffectMainFlow()
    {
        // Arrange
        var reportId = "test-report-metrics-fail";
        var metadata = TestDataFactory.CreateValidReportMetadata(reportId);
        metadata.ChargeReportParameters!.ReportType = ReportTypeEnum.ChargesEvents.Name;

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _s3ClientWrapper.MergeReportFilesAsync(Arg.Any<string>(), Arg.Any<ReportMetadata>(), Arg.Any<CancellationToken>())
            .Returns(Task.CompletedTask);

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        _reportingTimeMetrics.When(x => x.SendMetric(Arg.Any<SendMetricInput>()))
            .Do(_ => throw new Exception("Metric sending failed"));

        // Act & Assert
        // Should complete successfully even if metrics fail
        await _worker.ConcatReport(reportId, _performContext, _cancellationToken);

        await _s3ClientWrapper.Received(1).UploadReportMetadataAsync(
            Arg.Is<ReportMetadata>(m => m.Status == WorkerStatesEnum.Succeeded.ToString()));

        _reportingTimeMetrics.Received(1).SendMetric(Arg.Any<SendMetricInput>());
    }

    [Fact]
    public async Task ConcatReport_WithValidReportType_ShouldCalculateReportingTime()
    {
        // Arrange
        var reportId = "test-report-timing";
        var metadata = TestDataFactory.CreateValidReportMetadata(reportId);
        var createdAt = DateTime.Now.AddMinutes(-10);
        metadata.CreatedAt = createdAt;
        metadata.ChargeReportParameters!.ReportType = ReportTypeEnum.ChargesList.Name;

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _s3ClientWrapper.MergeReportFilesAsync(Arg.Any<string>(), Arg.Any<ReportMetadata>(), Arg.Any<CancellationToken>())
            .Returns(Task.CompletedTask);

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        // Act
        await _worker.ConcatReport(reportId, _performContext, _cancellationToken);

        // Assert
        // Verify the main flow completed successfully
        await _s3ClientWrapper.Received(1).UploadReportMetadataAsync(
            Arg.Is<ReportMetadata>(m =>
                m.Status == WorkerStatesEnum.Succeeded.ToString() &&
                m.CreatedAt == createdAt));
    }

    [Fact]
    public async Task ConcatReport_WithFinMovReportParameters_ShouldUseFinMovReportTypeForMetrics()
    {
        // Arrange
        var reportId = "test-report-metrics-finmov";
        var metadata = TestDataFactory.CreateValidReportMetadata(reportId);
        var createdAt = new DateTime(2025, 1, 1, 10, 0, 0, DateTimeKind.Utc);
        metadata.CreatedAt = createdAt;
        metadata.ChargeReportParameters = null;
        metadata.FinMovReportParameters = new FinMovESWorkerParameters
        {
            ReportType = ReportTypeEnum.Receivables.Name
        };

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _s3ClientWrapper.MergeReportFilesAsync(Arg.Any<string>(), Arg.Any<ReportMetadata>(), Arg.Any<CancellationToken>())
            .Returns(Task.CompletedTask);

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        // Act
        await _worker.ConcatReport(reportId, _performContext, _cancellationToken);

        // Assert
        _reportingTimeMetrics.Received(1).SendMetric(Arg.Is<SendMetricInput>(input =>
            input.ReportType == ReportTypeEnum.Receivables &&
            input.StartedAt == createdAt &&
            input.Status == WorkerStatesEnum.Succeeded.ToString()));
    }

    [Fact]
    public async Task ConcatReport_WhenReportTypeIsMissing_ShouldThrowException()
    {
        // Arrange
        var reportId = "test-report-metrics-missing-type";
        var metadata = TestDataFactory.CreateValidReportMetadata(reportId);
        metadata.ChargeReportParameters = null;
        metadata.FinMovReportParameters = null;

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _s3ClientWrapper.MergeReportFilesAsync(Arg.Any<string>(), Arg.Any<ReportMetadata>(), Arg.Any<CancellationToken>())
            .Returns(Task.CompletedTask);

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        // Act & Assert
        var exception = await Assert.ThrowsAsync<InvalidOperationException>(
            () => _worker.ConcatReport(reportId, _performContext, _cancellationToken));

        Assert.Equal("Report type not found", exception.Message);

        await _s3ClientWrapper.Received(1).UploadReportMetadataAsync(
            Arg.Is<ReportMetadata>(m => m.Status == WorkerStatesEnum.Succeeded.ToString()));

        _reportingTimeMetrics.DidNotReceive().SendMetric(Arg.Any<SendMetricInput>());
    }

    #endregion

    #region Integration - Complete Flow Validation

    [Fact]
    public async Task ConcatReport_CompleteFlow_ShouldExecuteAllStepsInOrder()
    {
        // Arrange
        var reportId = "test-report-complete-flow";
        var metadata = TestDataFactory.CreateValidReportMetadata(reportId);
        var callOrder = new List<string>();

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(callInfo =>
            {
                callOrder.Add("GetMetadata");
                return Task.FromResult<ReportMetadata?>(metadata);
            });

        _reportConcatenationService.ConcatAsync(Arg.Any<string>(), Arg.Any<ReportMetadata>(), Arg.Any<CancellationToken>())
            .Returns(callInfo =>
            {
                callOrder.Add("ConcatNew");
                return Task.CompletedTask;
            });

        _s3ClientWrapper.MergeReportFilesAsync(Arg.Any<string>(), Arg.Any<ReportMetadata>(), Arg.Any<CancellationToken>())
            .Returns(callInfo =>
            {
                callOrder.Add("ConcatLegacy");
                return Task.CompletedTask;
            });

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(callInfo =>
            {
                callOrder.Add("UploadMetadata");
                return Task.CompletedTask;
            });

        // Act
        await _worker.ConcatReport(reportId, _performContext, _cancellationToken);

        // Assert
        Assert.Equal(3, callOrder.Count);
        Assert.Equal("GetMetadata", callOrder[0]);
        Assert.Equal("UploadMetadata", callOrder[2]);
        Assert.True(
            callOrder[1] == "ConcatNew" || callOrder[1] == "ConcatLegacy",
            $"Expected second step to be 'ConcatNew' or 'ConcatLegacy' but was '{callOrder[1]}'");
    }

    [Fact]
    public async Task ConcatReport_WhenGetMetadataThrows_ShouldNotCallSubsequentMethods()
    {
        // Arrange
        var reportId = "test-report-early-fail";

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Throws(new InvalidOperationException("S3 connection failed"));

        // Act & Assert
        await Assert.ThrowsAsync<InvalidOperationException>(
            () => _worker.ConcatReport(reportId, _performContext, _cancellationToken));

        await _reportConcatenationService.DidNotReceive().ConcatAsync(
            Arg.Any<string>(),
            Arg.Any<ReportMetadata>(),
            Arg.Any<CancellationToken>());
        await _s3ClientWrapper.DidNotReceive().UploadReportMetadataAsync(Arg.Any<ReportMetadata>());
    }

    #endregion

    #region Edge Cases - Concurrent Execution

    [Fact]
    public async Task ConcatReport_WithMultipleConcurrentCalls_ShouldHandleIndependently()
    {
        // Arrange
        var reportId1 = "test-report-concurrent-1";
        var reportId2 = "test-report-concurrent-2";
        var metadata1 = TestDataFactory.CreateValidReportMetadata(reportId1);
        var metadata2 = TestDataFactory.CreateValidReportMetadata(reportId2);

        _s3ClientWrapper.GetReportMetadataAsync(reportId1)
            .Returns(Task.FromResult<ReportMetadata?>(metadata1));
        _s3ClientWrapper.GetReportMetadataAsync(reportId2)
            .Returns(Task.FromResult<ReportMetadata?>(metadata2));

        _reportConcatenationService.ConcatAsync(Arg.Any<string>(), Arg.Any<ReportMetadata>(), Arg.Any<CancellationToken>())
            .Returns(Task.CompletedTask);

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        // Act
        var task1 = _worker.ConcatReport(reportId1, _performContext, _cancellationToken);
        var task2 = _worker.ConcatReport(reportId2, _performContext, _cancellationToken);

        await Task.WhenAll(task1, task2);

        // Assert
        await _s3ClientWrapper.Received(1).GetReportMetadataAsync(reportId1);
        await _s3ClientWrapper.Received(1).GetReportMetadataAsync(reportId2);
        await _s3ClientWrapper.Received(2).UploadReportMetadataAsync(
            Arg.Is<ReportMetadata>(m => m.Status == WorkerStatesEnum.Succeeded.ToString()));
    }

    #endregion

    #region Edge Cases - Metadata Validation

    [Fact]
    public async Task ConcatReport_WithNullReportParameters_ShouldHandleGracefully()
    {
        // Arrange
        var reportId = "test-report-null-params";
        var metadata = TestDataFactory.CreateValidReportMetadata(reportId);
        // This tests if the worker can handle edge cases in metadata structure

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _s3ClientWrapper.MergeReportFilesAsync(Arg.Any<string>(), Arg.Any<ReportMetadata>(), Arg.Any<CancellationToken>())
            .Returns(Task.CompletedTask);

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        // Act
        await _worker.ConcatReport(reportId, _performContext, _cancellationToken);

        // Assert
        await _s3ClientWrapper.Received(1).UploadReportMetadataAsync(
            Arg.Is<ReportMetadata>(m => m.Status == WorkerStatesEnum.Succeeded.ToString()));
    }

    [Fact]
    public async Task ConcatReport_WithFutureStartedAt_ShouldStillComplete()
    {
        // Arrange
        var reportId = "test-report-future-time";
        var metadata = TestDataFactory.CreateValidReportMetadata(reportId);
        metadata.CreatedAt = DateTime.Now.AddHours(1);

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _s3ClientWrapper.MergeReportFilesAsync(Arg.Any<string>(), Arg.Any<ReportMetadata>(), Arg.Any<CancellationToken>())
            .Returns(Task.CompletedTask);

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        // Act
        await _worker.ConcatReport(reportId, _performContext, _cancellationToken);

        // Assert
        await _s3ClientWrapper.Received(1).UploadReportMetadataAsync(
            Arg.Is<ReportMetadata>(m => m.Status == WorkerStatesEnum.Succeeded.ToString()));
    }

    #endregion
}
using Hangfire.Server;
using Microsoft.Extensions.Options;
using NSubstitute;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Workers.NotificationWorkerV2.Services;
using PaymentsDataLayerReports.Unit.Test.Helpers;
using EmailChannelV2 = PaymentsDataLayerReports.Application.Workers.NotificationWorkerV2.EmailChannel;
using NotificationChannelV2 = PaymentsDataLayerReports.Application.Workers.NotificationWorkerV2.NotificationChannel;
using NotificationParametersV2 = PaymentsDataLayerReports.Application.Workers.NotificationWorkerV2.NotificationParameters;
using NotificationWorkerV2Type = PaymentsDataLayerReports.Application.Workers.NotificationWorkerV2.NotificationWorkerV2;
using WebhookChannelV2 = PaymentsDataLayerReports.Application.Workers.NotificationWorkerV2.WebhookChannel;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.NotificationWorkerV2;

public class NotificationWorkerV2Tests
{
    private readonly IWebhookService _webhookService = Substitute.For<IWebhookService>();
    private readonly IEmailService _emailService = Substitute.For<IEmailService>();
    private readonly IS3ClientWrapper _s3ClientWrapper = Substitute.For<IS3ClientWrapper>();
    private readonly CancellationToken _cancellationToken = CancellationToken.None;

    private NotificationWorkerV2Type CreateWorker(bool? isPreDeployWorker)
    {
        var options = Options.Create(new DataLayerReportPreDeploySettings
        {
            IsPreDeployWorker = isPreDeployWorker
        });

        return new NotificationWorkerV2Type(_webhookService, _emailService, _s3ClientWrapper, options);
    }

    [Fact]
    public async Task SendNotificationAsync_ShouldSkip_WhenPreDeployWorker()
    {
        // Arrange
        var worker = CreateWorker(true);
        var parameters = CreateParameters();

        // Act
        await worker.SendNotificationAsync(parameters, MockFactory.CreatePerformContext(), _cancellationToken);

        // Assert
        await _webhookService.DidNotReceiveWithAnyArgs().SendWebhookAsync(default!, default);
        await _emailService.DidNotReceiveWithAnyArgs().SendEmailAsync(default!, default);
    }

    [Fact]
    public async Task SendNotificationAsync_ShouldSendWebhookAndEmail_WhenChannelsProvided()
    {
        // Arrange
        var worker = CreateWorker(false);
        var parameters = CreateParameters(reportId: "report-123", includeWebhook: true, includeEmail: true);

        _s3ClientWrapper.BuildReportUrl(parameters.ReportId, fileName: parameters.DownloadFileName, fileFormat: parameters.FileFormat).Returns("https://s3/report-123");

        // Act
        await worker.SendNotificationAsync(parameters, MockFactory.CreatePerformContext(), _cancellationToken);

        // Assert
        _s3ClientWrapper.Received(1).BuildReportUrl(parameters.ReportId, fileName: parameters.DownloadFileName, fileFormat: parameters.FileFormat);
        await _webhookService.Received(1).SendWebhookAsync(parameters, _cancellationToken);
        await _emailService.Received(1).SendEmailAsync(parameters, _cancellationToken);
        Assert.Equal("https://s3/report-123", parameters.DownloadUrl);
    }

    [Fact]
    public async Task SendNotificationAsync_ShouldThrow_WhenWebhookFails()
    {
        // Arrange
        var worker = CreateWorker(false);
        var parameters = CreateParameters(includeWebhook: true);

        _webhookService
            .SendWebhookAsync(parameters, _cancellationToken)
            .Returns(Task.FromException(new InvalidOperationException("fail")));

        // Act & Assert
        await Assert.ThrowsAsync<InvalidOperationException>(() => worker.SendNotificationAsync(parameters, MockFactory.CreatePerformContext(), _cancellationToken));
    }

    [Fact]
    public async Task SendNotificationAsync_ShouldSendOnlyEmail_WhenOnlyEmailChannelProvided()
    {
        // Arrange
        var worker = CreateWorker(false);
        var parameters = CreateParameters(reportId: "report-456", includeWebhook: false, includeEmail: true);

        _s3ClientWrapper.BuildReportUrl(parameters.ReportId, fileName: parameters.DownloadFileName, fileFormat: parameters.FileFormat).Returns("https://s3/report-456");

        // Act
        await worker.SendNotificationAsync(parameters, MockFactory.CreatePerformContext(), _cancellationToken);

        // Assert
        await _webhookService.DidNotReceiveWithAnyArgs().SendWebhookAsync(default!, default);
        await _emailService.Received(1).SendEmailAsync(parameters, _cancellationToken);
    }

    [Fact]
    public async Task SendNotificationAsync_ShouldSendOnlyWebhook_WhenOnlyWebhookChannelProvided()
    {
        // Arrange
        var worker = CreateWorker(false);
        var parameters = CreateParameters(reportId: "report-789", includeWebhook: true, includeEmail: false);

        _s3ClientWrapper.BuildReportUrl(parameters.ReportId, fileName: parameters.DownloadFileName, fileFormat: parameters.FileFormat).Returns("https://s3/report-789");

        // Act
        await worker.SendNotificationAsync(parameters, MockFactory.CreatePerformContext(), _cancellationToken);

        // Assert
        await _webhookService.Received(1).SendWebhookAsync(parameters, _cancellationToken);
        await _emailService.DidNotReceiveWithAnyArgs().SendEmailAsync(default!, default);
    }

    [Fact]
    public async Task SendNotificationAsync_ShouldThrow_WhenEmailFails()
    {
        // Arrange
        var worker = CreateWorker(false);
        var parameters = CreateParameters(includeWebhook: false, includeEmail: true);

        _emailService
            .SendEmailAsync(parameters, _cancellationToken)
            .Returns(Task.FromException(new InvalidOperationException("email fail")));

        // Act & Assert
        await Assert.ThrowsAsync<InvalidOperationException>(() => worker.SendNotificationAsync(parameters, MockFactory.CreatePerformContext(), _cancellationToken));
    }

    [Fact]
    public async Task SendNotificationAsync_WithEmptyReportId_ShouldNotGenerateDownloadUrl()
    {
        // Arrange
        var worker = CreateWorker(false);
        var parameters = CreateParameters(reportId: "", includeWebhook: true, includeEmail: false);

        // Act
        await worker.SendNotificationAsync(parameters, MockFactory.CreatePerformContext(), _cancellationToken);

        // Assert
        _s3ClientWrapper.DidNotReceiveWithAnyArgs().BuildReportUrl(default!, default, default, default);
        Assert.Null(parameters.DownloadUrl);
    }

    [Fact]
    public async Task SendNotificationAsync_WithNoChannels_ShouldNotSendAnyNotification()
    {
        // Arrange
        var worker = CreateWorker(false);
        var parameters = CreateParameters(reportId: "report-123", includeWebhook: false, includeEmail: false);

        _s3ClientWrapper.BuildReportUrl(parameters.ReportId, fileName: parameters.DownloadFileName, fileFormat: parameters.FileFormat).Returns("https://s3/report-123");

        // Act
        await worker.SendNotificationAsync(parameters, MockFactory.CreatePerformContext(), _cancellationToken);

        // Assert
        await _webhookService.DidNotReceiveWithAnyArgs().SendWebhookAsync(default!, default);
        await _emailService.DidNotReceiveWithAnyArgs().SendEmailAsync(default!, default);
    }

    private static NotificationParametersV2 CreateParameters(string reportId = "report-1", bool includeWebhook = true, bool includeEmail = false)
    {
        return new NotificationParametersV2
        {
            Status = "succeeded",
            ReportId = reportId,
            ReportType = "receivables",
            FileFormat = "csv",
            Channel = new NotificationChannelV2
            {
                Webhook = includeWebhook ? new WebhookChannelV2 { Url = "https://hook", Headers = new Dictionary<string, string> { { "x-test", "value" } } } : null,
                Email = includeEmail ? new EmailChannelV2 { Address = "user@test.com" } : null
            }
        };
    }
}

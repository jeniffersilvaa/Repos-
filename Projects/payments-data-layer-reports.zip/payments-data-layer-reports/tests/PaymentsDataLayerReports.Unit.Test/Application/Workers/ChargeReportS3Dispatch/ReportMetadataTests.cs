using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;
using PaymentsDataLayerReports.Unit.Test.Helpers;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.ChargeReportS3Dispatch;

public class ReportMetadataTests
{
    #region GetDateRangeDescending - Core Functionality

    [Fact]
    public void GetDateRangeDescending_WithSingleDay_ShouldReturnSingleDate()
    {
        // Arrange
        var metadata = TestDataFactory.CreateValidReportMetadata();
        var today = DateTime.Today;
        metadata.ChargeReportParameters!.StartDate = today;
        metadata.ChargeReportParameters!.EndDate = today;

        // Act
        var result = metadata.GetDateRangeDescending().ToList();

        // Assert
        Assert.Single(result);
        Assert.Equal(today, result[0]);
    }

    [Fact]
    public void GetDateRangeDescending_WithMultipleDays_ShouldReturnDatesInDescendingOrder()
    {
        // Arrange
        var metadata = TestDataFactory.CreateValidReportMetadata();
        var startDate = new DateTime(2024, 1, 1);
        var endDate = new DateTime(2024, 1, 5);
        metadata.ChargeReportParameters!.StartDate = startDate;
        metadata.ChargeReportParameters!.EndDate = endDate;

        // Act
        var result = metadata.GetDateRangeDescending().ToList();

        // Assert
        Assert.Equal(5, result.Count);
        Assert.Equal(new DateTime(2024, 1, 5), result[0]); // Most recent first
        Assert.Equal(new DateTime(2024, 1, 4), result[1]);
        Assert.Equal(new DateTime(2024, 1, 3), result[2]);
        Assert.Equal(new DateTime(2024, 1, 2), result[3]);
        Assert.Equal(new DateTime(2024, 1, 1), result[4]); // Oldest last
    }

    [Fact]
    public void GetDateRangeDescending_WithTimeComponents_ShouldIgnoreTimeAndUseOnlyDate()
    {
        // Arrange
        var metadata = TestDataFactory.CreateValidReportMetadata();
        var startDate = new DateTime(2024, 1, 1, 14, 30, 45);
        var endDate = new DateTime(2024, 1, 3, 23, 59, 59);
        metadata.ChargeReportParameters!.StartDate = startDate;
        metadata.ChargeReportParameters!.EndDate = endDate;

        // Act
        var result = metadata.GetDateRangeDescending().ToList();

        // Assert
        Assert.Equal(3, result.Count);
        Assert.All(result, date => Assert.Equal(TimeSpan.Zero, date.TimeOfDay));
    }

    #endregion

    #region GetDateRangeDescending - Edge Cases

    [Fact]
    public void GetDateRangeDescending_CrossingMonthBoundary_ShouldIncludeAllDates()
    {
        // Arrange
        var metadata = TestDataFactory.CreateValidReportMetadata();
        var startDate = new DateTime(2024, 1, 30);
        var endDate = new DateTime(2024, 2, 2);
        metadata.ChargeReportParameters!.StartDate = startDate;
        metadata.ChargeReportParameters!.EndDate = endDate;

        // Act
        var result = metadata.GetDateRangeDescending().ToList();

        // Assert
        Assert.Equal(4, result.Count);
        Assert.Equal(new DateTime(2024, 2, 2), result[0]);
        Assert.Equal(new DateTime(2024, 1, 30), result[3]);
    }

    [Fact]
    public void GetDateRangeDescending_CrossingYearBoundary_ShouldIncludeAllDates()
    {
        // Arrange
        var metadata = TestDataFactory.CreateValidReportMetadata();
        var startDate = new DateTime(2023, 12, 30);
        var endDate = new DateTime(2024, 1, 2);
        metadata.ChargeReportParameters!.StartDate = startDate;
        metadata.ChargeReportParameters!.EndDate = endDate;

        // Act
        var result = metadata.GetDateRangeDescending().ToList();

        // Assert
        Assert.Equal(4, result.Count);
        Assert.Equal(new DateTime(2024, 1, 2), result[0]);
        Assert.Equal(new DateTime(2023, 12, 30), result[3]);
    }

    [Fact]
    public void GetDateRangeDescending_LeapYearFebruary_ShouldReturn29Days()
    {
        // Arrange
        var metadata = TestDataFactory.CreateValidReportMetadata();
        var startDate = new DateTime(2024, 2, 1);
        var endDate = new DateTime(2024, 2, 29);
        metadata.ChargeReportParameters!.StartDate = startDate;
        metadata.ChargeReportParameters!.EndDate = endDate;

        // Act
        var result = metadata.GetDateRangeDescending().ToList();

        // Assert
        Assert.Equal(29, result.Count);
    }

    [Fact]
    public void GetDateRangeDescending_WithLargeDateRange_ShouldReturnAllDates()
    {
        // Arrange
        var metadata = TestDataFactory.CreateValidReportMetadata();
        var startDate = new DateTime(2024, 1, 1);
        var endDate = new DateTime(2024, 12, 31);
        metadata.ChargeReportParameters!.StartDate = startDate;
        metadata.ChargeReportParameters!.EndDate = endDate;

        // Act
        var result = metadata.GetDateRangeDescending().ToList();

        // Assert
        Assert.Equal(366, result.Count); // 2024 is a leap year
        Assert.Equal(endDate, result[0]);
        Assert.Equal(startDate, result[365]);
    }

    #endregion

}

using Hangfire;
using Hangfire.Common;
using Hangfire.Server;
using Hangfire.Storage;
using NSubstitute;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Services.DeltaTablePartitionBuilder;
using PaymentsDataLayerReports.Application.Services.IdempotentJobManager;
using PaymentsDataLayerReports.Application.Versioning;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;
using PaymentsDataLayerReports.Application.Workers.ChargeReportWorker;
using PaymentsDataLayerReports.Application.Workers.FinMovReportESWorker;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.ChargeReportS3Dispatch;

public class ChargeReportS3DispatchWorkerByReportMetadataTests
{
    private readonly IS3ClientWrapper _s3ClientWrapper;
    private readonly IIdempotentJobManager _idempotentJobManager;
    private readonly ChargeReportS3DispatchWorkerByReportMetadata _worker;
    private readonly PerformContext _performContext;
    private readonly CancellationToken _cancellationToken;
    private readonly AppVersion1320 _version;

    public ChargeReportS3DispatchWorkerByReportMetadataTests()
    {
        _s3ClientWrapper = Substitute.For<IS3ClientWrapper>();
        _idempotentJobManager = Substitute.For<IIdempotentJobManager>();
        _worker = new ChargeReportS3DispatchWorkerByReportMetadata(_s3ClientWrapper, _idempotentJobManager);

        var backgroundJob = Substitute.For<BackgroundJob>(
            "test-job-id",
            Job.FromExpression(() => Console.WriteLine()),
            DateTime.UtcNow
        );

        _performContext = Substitute.For<PerformContext>(
            Substitute.For<IStorageConnection>(),
            backgroundJob,
            Substitute.For<IJobCancellationToken>()
        );

        _cancellationToken = CancellationToken.None;
        _version = new AppVersion1320();
    }

    private static ReportMetadata CreateChargeMetadata(string reportId, string? document = "12345678900", string? merchantId = null)
    {
        return new ReportMetadata
        {
            Status = WorkerStatesEnum.Enqueued.ToString(),
            ReportId = reportId,
            DispatchId = string.Empty,
            CreatedAt = DateTime.UtcNow,
            ReportSortColumnIndex = 0,
            ProcessorQueueName = "test-queue",
            FileFormat = FileFormatEnum.Csv.Name,
            ChargeReportParameters = new ChargeReportsWorkerParameters
            {
                ReportType = "charges_list",
                StartDate = DateTimeOffset.UtcNow.AddDays(-1),
                EndDate = DateTimeOffset.UtcNow,
                Document = document,
                MerchantId = merchantId
            },
            FinMovReportParameters = null
        };
    }

    private static ReportMetadata CreateFinMovMetadata(string reportId, string? document = "12345678900")
    {
        return new ReportMetadata
        {
            Status = WorkerStatesEnum.Enqueued.ToString(),
            ReportId = reportId,
            DispatchId = string.Empty,
            CreatedAt = DateTime.UtcNow,
            ReportSortColumnIndex = 0,
            ProcessorQueueName = "test-queue",
            FileFormat = FileFormatEnum.Csv.Name,
            ChargeReportParameters = null,
            FinMovReportParameters = new FinMovESWorkerParameters
            {
                ReportType = "receivables",
                StartDate = DateOnly.FromDateTime(DateTime.Today.AddDays(-1)),
                EndDate = DateOnly.FromDateTime(DateTime.Today),
                Document = document
            }
        };
    }

    [Fact]
    public async Task DispatchReport_WithEmptyReportId_ShouldGenerateReportIdFromDispatchId()
    {
        var startDate = new DateOnly(2025, 1, 1);
        var finalDate = new DateOnly(2025, 1, 1);
        var metadata = CreateChargeMetadata(string.Empty);

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.SetTotalJobsAsync(Arg.Any<string>(), Arg.Any<int>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager
            .CreateJobIfNotExistsAsync<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker>(
                Arg.Any<string>(),
                Arg.Any<DateTime>(),
                Arg.Any<DeltaTablePartitionSet>(),
                Arg.Any<string>(),
                Arg.Any<System.Linq.Expressions.Expression<Func<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker, Task>>>())
            .Returns(Task.FromResult<string?>("job-id"));

        await _worker.DispatchReport(startDate, finalDate, metadata, _performContext, _version, _cancellationToken);

        await _s3ClientWrapper.Received(1).UploadReportMetadataAsync(
            Arg.Is<ReportMetadata>(m =>
                m.ReportId == "test-job-id" &&
                m.DispatchId == "test-job-id" &&
                m.Status == WorkerStatesEnum.Processing.ToString()));

        await _idempotentJobManager.Received(1).SetTotalJobsAsync(
            "test-job-id",
            Arg.Any<int>());
    }

    [Fact]
    public async Task DispatchReport_WithExistingReportId_ShouldPreserveReportId()
    {
        var startDate = new DateOnly(2025, 1, 1);
        var finalDate = new DateOnly(2025, 1, 1);
        var metadata = CreateChargeMetadata("existing-report-id");

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.SetTotalJobsAsync(Arg.Any<string>(), Arg.Any<int>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager
            .CreateJobIfNotExistsAsync<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker>(
                Arg.Any<string>(),
                Arg.Any<DateTime>(),
                Arg.Any<DeltaTablePartitionSet>(),
                Arg.Any<string>(),
                Arg.Any<System.Linq.Expressions.Expression<Func<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker, Task>>>())
            .Returns(Task.FromResult<string?>("job-id"));

        await _worker.DispatchReport(startDate, finalDate, metadata, _performContext, _version, _cancellationToken);

        await _s3ClientWrapper.Received(1).UploadReportMetadataAsync(
            Arg.Is<ReportMetadata>(m =>
                m.ReportId == "existing-report-id" &&
                m.DispatchId == "test-job-id"));
    }

    [Fact]
    public async Task DispatchReport_WithBothParametersNull_ShouldThrowInvalidOperationException()
    {
        var startDate = new DateOnly(2025, 1, 1);
        var finalDate = new DateOnly(2025, 1, 1);

        var metadata = new ReportMetadata
        {
            Status = WorkerStatesEnum.Enqueued.ToString(),
            ReportId = string.Empty,
            DispatchId = string.Empty,
            CreatedAt = DateTime.UtcNow,
            ReportSortColumnIndex = 0,
            ProcessorQueueName = "test-queue",
            FileFormat = FileFormatEnum.Csv.Name,
            ChargeReportParameters = null,
            FinMovReportParameters = null
        };

        var exception = await Assert.ThrowsAsync<InvalidOperationException>(
            () => _worker.DispatchReport(startDate, finalDate, metadata, _performContext, _version, _cancellationToken));

        Assert.Contains("At least one report type must be specified", exception.Message);

        await _s3ClientWrapper.DidNotReceive().UploadReportMetadataAsync(Arg.Any<ReportMetadata>());
        await _idempotentJobManager.DidNotReceive().SetTotalJobsAsync(Arg.Any<string>(), Arg.Any<int>());
    }

    [Fact]
    public async Task DispatchReport_WithoutDocumentOrMerchantId_ShouldThrowInvalidOperationException()
    {
        var startDate = new DateOnly(2025, 1, 1);
        var finalDate = new DateOnly(2025, 1, 1);

        var metadata = CreateChargeMetadata("report-without-identifiers", document: null, merchantId: null);

        var exception = await Assert.ThrowsAsync<InvalidOperationException>(
            () => _worker.DispatchReport(startDate, finalDate, metadata, _performContext, _version, _cancellationToken));

        Assert.Contains("Document or MerchantId not found", exception.Message);

        await _s3ClientWrapper.DidNotReceive().UploadReportMetadataAsync(Arg.Any<ReportMetadata>());
        await _idempotentJobManager.DidNotReceive().SetTotalJobsAsync(Arg.Any<string>(), Arg.Any<int>());
    }

    [Fact]
    public async Task DispatchReport_WithEndDateBeforeStartDate_ShouldThrowArgumentException()
    {
        var startDate = new DateOnly(2025, 1, 2);
        var finalDate = new DateOnly(2025, 1, 1);
        var metadata = CreateChargeMetadata("test-report-id");

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        var exception = await Assert.ThrowsAsync<ArgumentException>(
            () => _worker.DispatchReport(startDate, finalDate, metadata, _performContext, _version, _cancellationToken));

        Assert.Contains("endDate must be greater than or equal to startDate.", exception.Message);

        await _idempotentJobManager.DidNotReceive().SetTotalJobsAsync(Arg.Any<string>(), Arg.Any<int>());
    }

    [Fact]
    public async Task DispatchReport_WithFinMovParameters_ShouldUploadMetadataAndCreateJobs()
    {
        var startDate = new DateOnly(2025, 1, 1);
        var finalDate = new DateOnly(2025, 1, 3);
        var metadata = CreateFinMovMetadata("finmov-report-id");

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.SetTotalJobsAsync(Arg.Any<string>(), Arg.Any<int>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager
            .CreateJobIfNotExistsAsync<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker>(
                Arg.Any<string>(),
                Arg.Any<DateTime>(),
                Arg.Any<DeltaTablePartitionSet>(),
                Arg.Any<string>(),
                Arg.Any<System.Linq.Expressions.Expression<Func<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker, Task>>>())
            .Returns(Task.FromResult<string?>("job-id"));

        await _worker.DispatchReport(startDate, finalDate, metadata, _performContext, _version, _cancellationToken);

        await _s3ClientWrapper.Received(1).UploadReportMetadataAsync(
            Arg.Is<ReportMetadata>(m => m.ReportId == "finmov-report-id"));

        await _idempotentJobManager.Received(1).SetTotalJobsAsync(
            "finmov-report-id",
            Arg.Any<int>());
    }
}

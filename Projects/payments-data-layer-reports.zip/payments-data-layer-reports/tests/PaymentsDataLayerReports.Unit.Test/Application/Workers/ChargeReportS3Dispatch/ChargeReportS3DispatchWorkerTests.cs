using Hangfire;
using Hangfire.Common;
using Hangfire.Server;
using Hangfire.Storage;
using NSubstitute;
using NSubstitute.ExceptionExtensions;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Services.DeltaTablePartitionBuilder;
using PaymentsDataLayerReports.Application.Services.IdempotentJobManager;
using PaymentsDataLayerReports.Application.Versioning;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;
using PaymentsDataLayerReports.Application.Workers.ChargeReportWorker;
using PaymentsDataLayerReports.Application.Workers.FinMovReportESWorker;
using ChargeReportS3Worker = PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.ChargeReportS3Dispatch;

public class ChargeReportS3DispatchWorkerTests
{
    private readonly IS3ClientWrapper _s3ClientWrapper;
    private readonly IIdempotentJobManager _idempotentJobManager;
    private readonly ChargeReportS3DispatchWorker _worker;
    private readonly PerformContext _performContext;
    private readonly CancellationToken _cancellationToken;
    private readonly AppVersion1320 _version;

    public ChargeReportS3DispatchWorkerTests()
    {
        // Arrange - Setup common mocks
        _s3ClientWrapper = Substitute.For<IS3ClientWrapper>();
        _idempotentJobManager = Substitute.For<IIdempotentJobManager>();
        _worker = new ChargeReportS3DispatchWorker(_s3ClientWrapper, _idempotentJobManager);


        // Setup PerformContext mock
        var backgroundJob = Substitute.For<BackgroundJob>("test-job-id", Job.FromExpression(() => Console.WriteLine()), DateTime.UtcNow);
        _performContext = Substitute.For<PerformContext>(
            Substitute.For<IStorageConnection>(),
            backgroundJob,
            Substitute.For<IJobCancellationToken>()
        );

        _cancellationToken = CancellationToken.None;
        _version = new AppVersion1320();
    }

    #region Success Scenarios - Charge Parameters

    [Fact]
    public async Task DispatchReport_WithValidChargeParameters_ShouldCompleteSuccessfully()
    {
        // Arrange
        var reportId = "test-report-123";
        var processorQueueName = "test-queue";
        var startedAt = DateTime.UtcNow;
        var chargeParameters = new ChargeReportsWorkerParameters
        {
            ReportType = "charges_list",
            StartDate = DateTimeOffset.UtcNow.AddDays(-1),
            EndDate = DateTimeOffset.UtcNow,
            Document = "12345678900",
            Organizations = "org-123"
        };

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.SetTotalJobsAsync(Arg.Any<string>(), Arg.Any<int>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.CreateJobIfNotExistsAsync<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker>(
            Arg.Any<string>(),
            Arg.Any<DateTime>(),
            Arg.Any<DeltaTablePartitionSet>(),
            Arg.Any<string>(),
            Arg.Any<System.Linq.Expressions.Expression<Func<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker, Task>>>()
        ).Returns(Task.FromResult<string?>("job-id"));

        // Act
        await _worker.DispatchReport(reportId, processorQueueName, chargeParameters, null, startedAt, _performContext, _cancellationToken, _version);

        // Assert
        await _s3ClientWrapper.Received(1).UploadReportMetadataAsync(
            Arg.Is<ReportMetadata>(m =>
                m.ReportId == reportId &&
                m.Status == WorkerStatesEnum.Processing.ToString() &&
                m.ProcessorQueueName == processorQueueName
            )
        );

        await _idempotentJobManager.Received(1).SetTotalJobsAsync(reportId, Arg.Is<int>(t => t > 0));
    }

    [Fact]
    public async Task DispatchReport_WithNullReportId_ShouldGenerateReportIdFromDispatchId()
    {
        // Arrange
        var processorQueueName = "test-queue";
        var startedAt = DateTime.UtcNow;
        var chargeParameters = new ChargeReportsWorkerParameters
        {
            ReportType = "charges_list",
            StartDate = DateTimeOffset.UtcNow.AddDays(-1),
            EndDate = DateTimeOffset.UtcNow,
            Document = "12345678900"
        };

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.SetTotalJobsAsync(Arg.Any<string>(), Arg.Any<int>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.CreateJobIfNotExistsAsync<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker>(
            Arg.Any<string>(),
            Arg.Any<DateTime>(),
            Arg.Any<DeltaTablePartitionSet>(),
            Arg.Any<string>(),
            Arg.Any<System.Linq.Expressions.Expression<Func<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker, Task>>>()
        ).Returns(Task.FromResult<string?>("job-id"));

        // Act
        await _worker.DispatchReport(null, processorQueueName, chargeParameters, null, startedAt, _performContext, _cancellationToken, _version);

        // Assert
        await _s3ClientWrapper.Received(1).UploadReportMetadataAsync(
            Arg.Is<ReportMetadata>(m => m.ReportId == "test-job-id-s3")
        );
    }

    [Fact]
    public async Task DispatchReport_WithMultipleDays_ShouldCreateJobsForEachDay()
    {
        // Arrange
        var reportId = "test-report-multiday";
        var processorQueueName = "test-queue";
        var startedAt = DateTime.UtcNow;
        var startDate = DateTime.Today.AddDays(-2);
        var endDate = DateTime.Today;
        var chargeParameters = new ChargeReportsWorkerParameters
        {
            ReportType = "charges_list",
            StartDate = new DateTimeOffset(startDate),
            EndDate = new DateTimeOffset(endDate),
            Document = "12345678900"
        };

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.SetTotalJobsAsync(Arg.Any<string>(), Arg.Any<int>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.CreateJobIfNotExistsAsync<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker>(
            Arg.Any<string>(),
            Arg.Any<DateTime>(),
            Arg.Any<DeltaTablePartitionSet>(),
            Arg.Any<string>(),
            Arg.Any<System.Linq.Expressions.Expression<Func<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker, Task>>>()
        ).Returns(Task.FromResult<string?>("job-id"));

        // Act
        await _worker.DispatchReport(reportId, processorQueueName, chargeParameters, null, startedAt, _performContext, _cancellationToken, _version);

        // Assert - Should create jobs for 3 days (day -2, -1, and today)
        await _idempotentJobManager.Received().CreateJobIfNotExistsAsync<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker>(
            reportId,
            Arg.Any<DateTime>(),
            Arg.Any<DeltaTablePartitionSet>(),
            processorQueueName,
            Arg.Any<System.Linq.Expressions.Expression<Func<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker, Task>>>()
        );
    }

    #endregion

    #region Success Scenarios - FinMov Parameters

    [Fact]
    public async Task DispatchReport_WithValidFinMovParameters_ShouldCompleteSuccessfully()
    {
        // Arrange
        var reportId = "test-finmov-report";
        var processorQueueName = "test-queue";
        var startedAt = DateTime.UtcNow;
        var finMovParameters = new FinMovESWorkerParameters
        {
            ReportType = "receivables",
            StartDate = DateOnly.FromDateTime(DateTime.Today.AddDays(-1)),
            EndDate = DateOnly.FromDateTime(DateTime.Today),
            Document = "12345678900"
        };

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.SetTotalJobsAsync(Arg.Any<string>(), Arg.Any<int>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.CreateJobIfNotExistsAsync<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker>(
            Arg.Any<string>(),
            Arg.Any<DateTime>(),
            Arg.Any<DeltaTablePartitionSet>(),
            Arg.Any<string>(),
            Arg.Any<System.Linq.Expressions.Expression<Func<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker, Task>>>()
        ).Returns(Task.FromResult<string?>("job-id"));

        // Act
        await _worker.DispatchReport(reportId, processorQueueName, null, finMovParameters, startedAt, _performContext, _cancellationToken, _version);

        // Assert
        await _s3ClientWrapper.Received(1).UploadReportMetadataAsync(
            Arg.Is<ReportMetadata>(m =>
                m.ReportId == reportId &&
                m.FinMovReportParameters == finMovParameters
            )
        );
    }

    [Fact]
    public async Task DispatchReport_WithFinMovMerchantId_ShouldCompleteSuccessfully()
    {
        // Arrange
        var reportId = "test-finmov-merchant";
        var processorQueueName = "test-queue";
        var startedAt = DateTime.UtcNow;
        var finMovParameters = new FinMovESWorkerParameters
        {
            ReportType = "receivables",
            StartDate = DateOnly.FromDateTime(DateTime.Today),
            EndDate = DateOnly.FromDateTime(DateTime.Today),
            MerchantId = "merchant-123"
        };

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.SetTotalJobsAsync(Arg.Any<string>(), Arg.Any<int>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.CreateJobIfNotExistsAsync<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker>(
            Arg.Any<string>(),
            Arg.Any<DateTime>(),
            Arg.Any<DeltaTablePartitionSet>(),
            Arg.Any<string>(),
            Arg.Any<System.Linq.Expressions.Expression<Func<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker, Task>>>()
        ).Returns(Task.FromResult<string?>("job-id"));

        // Act
        await _worker.DispatchReport(reportId, processorQueueName, null, finMovParameters, startedAt, _performContext, _cancellationToken, _version);

        // Assert
        await _idempotentJobManager.Received().SetTotalJobsAsync(reportId, Arg.Is<int>(t => t > 0));
    }

    #endregion

    #region Error Handling - Missing Parameters

    [Fact]
    public async Task DispatchReport_WithBothParametersNull_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var reportId = "test-report";
        var processorQueueName = "test-queue";
        var startedAt = DateTime.UtcNow;

        // Act & Assert
        var exception = await Assert.ThrowsAsync<InvalidOperationException>(
            () => _worker.DispatchReport(reportId, processorQueueName, null, null, startedAt, _performContext, _cancellationToken, _version)
        );

        Assert.Contains("At least one report type must be specified", exception.Message);
    }

    [Fact]
    public async Task DispatchReport_WithBothParametersNull_ShouldNotUploadMetadata()
    {
        // Arrange
        var reportId = "test-report";
        var processorQueueName = "test-queue";
        var startedAt = DateTime.UtcNow;

        // Act & Assert
        await Assert.ThrowsAsync<InvalidOperationException>(
            () => _worker.DispatchReport(reportId, processorQueueName, null, null, startedAt, _performContext, _cancellationToken, _version)
        );

        await _s3ClientWrapper.DidNotReceive().UploadReportMetadataAsync(Arg.Any<ReportMetadata>());
    }

    [Fact]
    public async Task DispatchReport_WithoutDocumentOrMerchantId_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var reportId = "test-report";
        var processorQueueName = "test-queue";
        var startedAt = DateTime.UtcNow;
        var chargeParameters = new ChargeReportsWorkerParameters
        {
            ReportType = "charges_list",
            StartDate = DateTimeOffset.UtcNow.AddDays(-1),
            EndDate = DateTimeOffset.UtcNow,
            Document = null,
            MerchantId = null
        };

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        // Act & Assert
        var exception = await Assert.ThrowsAsync<InvalidOperationException>(
            () => _worker.DispatchReport(reportId, processorQueueName, chargeParameters, null, startedAt, _performContext, _cancellationToken, _version)
        );

        Assert.Contains("Document or MerchantId not found", exception.Message);
    }

    #endregion

    #region Error Handling - Invalid Report Configuration

    [Fact]
    public async Task DispatchReport_WithInvalidReportType_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var reportId = "test-report";
        var processorQueueName = "test-queue";
        var startedAt = DateTime.UtcNow;
        var chargeParameters = new ChargeReportsWorkerParameters
        {
            ReportType = "invalid_report_type",
            StartDate = DateTimeOffset.UtcNow.AddDays(-1),
            EndDate = DateTimeOffset.UtcNow,
            Document = "12345678900"
        };

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        // Act & Assert
        var exception = await Assert.ThrowsAsync<InvalidOperationException>(
            () => _worker.DispatchReport(reportId, processorQueueName, chargeParameters, null, startedAt, _performContext, _cancellationToken, _version)
        );

        Assert.Contains("Report configuration not found", exception.Message);
    }

    #endregion

    #region Error Handling - S3 Upload Failures

    [Fact]
    public async Task DispatchReport_WhenUploadMetadataFails_ShouldThrowException()
    {
        // Arrange
        var reportId = "test-report";
        var processorQueueName = "test-queue";
        var startedAt = DateTime.UtcNow;
        var chargeParameters = new ChargeReportsWorkerParameters
        {
            ReportType = "charges_list",
            StartDate = DateTimeOffset.UtcNow.AddDays(-1),
            EndDate = DateTimeOffset.UtcNow,
            Document = "12345678900"
        };

        var expectedException = new InvalidOperationException("S3 upload failed");
        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Throws(expectedException);

        // Act & Assert
        var exception = await Assert.ThrowsAsync<InvalidOperationException>(
            () => _worker.DispatchReport(reportId, processorQueueName, chargeParameters, null, startedAt, _performContext, _cancellationToken, _version)
        );

        Assert.Equal(expectedException.Message, exception.Message);
    }

    [Fact]
    public async Task DispatchReport_WhenUploadMetadataFails_ShouldNotCreateJobs()
    {
        // Arrange
        var reportId = "test-report";
        var processorQueueName = "test-queue";
        var startedAt = DateTime.UtcNow;
        var chargeParameters = new ChargeReportsWorkerParameters
        {
            ReportType = "charges_list",
            StartDate = DateTimeOffset.UtcNow.AddDays(-1),
            EndDate = DateTimeOffset.UtcNow,
            Document = "12345678900"
        };

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Throws(new InvalidOperationException("S3 upload failed"));

        // Act & Assert
        await Assert.ThrowsAsync<InvalidOperationException>(
            () => _worker.DispatchReport(reportId, processorQueueName, chargeParameters, null, startedAt, _performContext, _cancellationToken, _version)
        );

        await _idempotentJobManager.DidNotReceive().SetTotalJobsAsync(Arg.Any<string>(), Arg.Any<int>());
        await _idempotentJobManager.DidNotReceive().CreateJobIfNotExistsAsync<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker>(
            Arg.Any<string>(),
            Arg.Any<DateTime>(),
            Arg.Any<DeltaTablePartitionSet>(),
            Arg.Any<string>(),
            Arg.Any<System.Linq.Expressions.Expression<Func<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker, Task>>>()
        );
    }

    #endregion

    #region Edge Cases - Date Ranges

    [Fact]
    public async Task DispatchReport_WithSameDayDateRange_ShouldCreateJobsForOneDay()
    {
        // Arrange
        var reportId = "test-report-same-day";
        var processorQueueName = "test-queue";
        var startedAt = DateTime.UtcNow;
        var today = DateTime.Today;
        var chargeParameters = new ChargeReportsWorkerParameters
        {
            ReportType = "charges_list",
            StartDate = new DateTimeOffset(today),
            EndDate = new DateTimeOffset(today),
            Document = "12345678900"
        };

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.SetTotalJobsAsync(Arg.Any<string>(), Arg.Any<int>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.CreateJobIfNotExistsAsync<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker>(
            Arg.Any<string>(),
            Arg.Any<DateTime>(),
            Arg.Any<DeltaTablePartitionSet>(),
            Arg.Any<string>(),
            Arg.Any<System.Linq.Expressions.Expression<Func<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker, Task>>>()
        ).Returns(Task.FromResult<string?>("job-id"));

        // Act
        await _worker.DispatchReport(reportId, processorQueueName, chargeParameters, null, startedAt, _performContext, _cancellationToken, _version);

        // Assert - Should set total jobs for 1 day * number of partitions
        await _idempotentJobManager.Received(1).SetTotalJobsAsync(reportId, Arg.Is<int>(t => t > 0));
    }

    [Fact]
    public async Task DispatchReport_WithEndDateBeforeStartDate_ShouldNotCreateJobs()
    {
        // Arrange
        var reportId = "test-report-invalid-range";
        var processorQueueName = "test-queue";
        var startedAt = DateTime.UtcNow;
        var chargeParameters = new ChargeReportsWorkerParameters
        {
            ReportType = "charges_list",
            StartDate = DateTimeOffset.UtcNow,
            EndDate = DateTimeOffset.UtcNow.AddDays(-1),
            Document = "12345678900"
        };

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.SetTotalJobsAsync(Arg.Any<string>(), Arg.Any<int>())
            .Returns(Task.CompletedTask);

        // Act
        await _worker.DispatchReport(reportId, processorQueueName, chargeParameters, null, startedAt, _performContext, _cancellationToken, _version);

        // Assert - Should set total jobs to 0 and not create any jobs
        await _idempotentJobManager.DidNotReceive().SetTotalJobsAsync(Arg.Any<string>(), Arg.Any<int>());
        await _idempotentJobManager.DidNotReceive().CreateJobIfNotExistsAsync<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker>(
            Arg.Any<string>(),
            Arg.Any<DateTime>(),
            Arg.Any<DeltaTablePartitionSet>(),
            Arg.Any<string>(),
            Arg.Any<System.Linq.Expressions.Expression<Func<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker, Task>>>()
        );
    }

    #endregion

    #region Edge Cases - Different Report Types

    [Theory]
    [InlineData("charges_list")]
    [InlineData("charges_events")]
    [InlineData("receivables")]
    public async Task DispatchReport_WithDifferentReportTypes_ShouldCompleteSuccessfully(string reportType)
    {
        // Arrange
        var reportId = $"test-report-{reportType}";
        var processorQueueName = "test-queue";
        var startedAt = DateTime.UtcNow;

        ChargeReportsWorkerParameters? chargeParameters = null;
        FinMovESWorkerParameters? finMovParameters = null;

        if (reportType == "receivables")
        {
            finMovParameters = new FinMovESWorkerParameters
            {
                ReportType = reportType,
                StartDate = DateOnly.FromDateTime(DateTime.Today),
                EndDate = DateOnly.FromDateTime(DateTime.Today),
                Document = "12345678900"
            };
        }
        else
        {
            chargeParameters = new ChargeReportsWorkerParameters
            {
                ReportType = reportType,
                StartDate = DateTimeOffset.UtcNow,
                EndDate = DateTimeOffset.UtcNow,
                Document = "12345678900"
            };
        }

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.SetTotalJobsAsync(Arg.Any<string>(), Arg.Any<int>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.CreateJobIfNotExistsAsync<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker>(
            Arg.Any<string>(),
            Arg.Any<DateTime>(),
            Arg.Any<DeltaTablePartitionSet>(),
            Arg.Any<string>(),
            Arg.Any<System.Linq.Expressions.Expression<Func<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker, Task>>>()
        ).Returns(Task.FromResult<string?>("job-id"));

        // Act
        await _worker.DispatchReport(reportId, processorQueueName, chargeParameters, finMovParameters, startedAt, _performContext, _cancellationToken, _version);

        // Assert
        await _s3ClientWrapper.Received(1).UploadReportMetadataAsync(
            Arg.Is<ReportMetadata>(m => m.ReportId == reportId)
        );
    }

    #endregion

    #region Integration - Complete Flow Validation

    [Fact]
    public async Task DispatchReport_CompleteFlow_ShouldExecuteAllStepsInOrder()
    {
        // Arrange
        var reportId = "test-report-complete";
        var processorQueueName = "test-queue";
        var startedAt = DateTime.UtcNow;
        var chargeParameters = new ChargeReportsWorkerParameters
        {
            ReportType = "charges_list",
            StartDate = DateTimeOffset.UtcNow,
            EndDate = DateTimeOffset.UtcNow,
            Document = "12345678900"
        };

        var callOrder = new List<string>();

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(callInfo =>
            {
                callOrder.Add("UploadMetadata");
                return Task.CompletedTask;
            });

        _idempotentJobManager.SetTotalJobsAsync(Arg.Any<string>(), Arg.Any<int>())
            .Returns(callInfo =>
            {
                callOrder.Add("SetTotalJobs");
                return Task.CompletedTask;
            });

        _idempotentJobManager.CreateJobIfNotExistsAsync<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker>(
            Arg.Any<string>(),
            Arg.Any<DateTime>(),
            Arg.Any<DeltaTablePartitionSet>(),
            Arg.Any<string>(),
            Arg.Any<System.Linq.Expressions.Expression<Func<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker, Task>>>()
        ).Returns(callInfo =>
        {
            callOrder.Add("CreateJob");
            return Task.FromResult<string?>("job-id");
        });

        // Act
        await _worker.DispatchReport(reportId, processorQueueName, chargeParameters, null, startedAt, _performContext, _cancellationToken, _version);

        // Assert - Verify execution order
        Assert.True(callOrder.Count >= 2);
        Assert.Equal("UploadMetadata", callOrder[0]);
        Assert.Equal("SetTotalJobs", callOrder[1]);
        Assert.Contains("CreateJob", callOrder);
    }

    [Fact]
    public async Task DispatchReport_WithMerchantId_ShouldCreateJobsWithCorrectPartitions()
    {
        // Arrange
        var reportId = "test-report-merchant";
        var processorQueueName = "test-queue";
        var startedAt = DateTime.UtcNow;
        var chargeParameters = new ChargeReportsWorkerParameters
        {
            ReportType = "charges_list",
            StartDate = DateTimeOffset.UtcNow,
            EndDate = DateTimeOffset.UtcNow,
            MerchantId = "merchant-123"
        };

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.SetTotalJobsAsync(Arg.Any<string>(), Arg.Any<int>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.CreateJobIfNotExistsAsync<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker>(
            Arg.Any<string>(),
            Arg.Any<DateTime>(),
            Arg.Any<DeltaTablePartitionSet>(),
            Arg.Any<string>(),
            Arg.Any<System.Linq.Expressions.Expression<Func<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker, Task>>>()
        ).Returns(Task.FromResult<string?>("job-id"));

        // Act
        await _worker.DispatchReport(reportId, processorQueueName, chargeParameters, null, startedAt, _performContext, _cancellationToken, _version);

        // Assert
        await _idempotentJobManager.Received().CreateJobIfNotExistsAsync<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker>(
            reportId,
            Arg.Any<DateTime>(),
            Arg.Is<DeltaTablePartitionSet>(p => p.PartitionIdReferenceType == "merchant_id"),
            processorQueueName,
            Arg.Any<System.Linq.Expressions.Expression<Func<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker, Task>>>()
        );
    }

    [Fact]
    public async Task DispatchReport_WithDocument_ShouldCreateJobsWithCorrectPartitions()
    {
        // Arrange
        var reportId = "test-report-document";
        var processorQueueName = "test-queue";
        var startedAt = DateTime.UtcNow;
        var chargeParameters = new ChargeReportsWorkerParameters
        {
            ReportType = "charges_list",
            StartDate = DateTimeOffset.UtcNow,
            EndDate = DateTimeOffset.UtcNow,
            Document = "12345678900"
        };

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.SetTotalJobsAsync(Arg.Any<string>(), Arg.Any<int>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.CreateJobIfNotExistsAsync<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker>(
            Arg.Any<string>(),
            Arg.Any<DateTime>(),
            Arg.Any<DeltaTablePartitionSet>(),
            Arg.Any<string>(),
            Arg.Any<System.Linq.Expressions.Expression<Func<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker, Task>>>()
        ).Returns(Task.FromResult<string?>("job-id"));

        // Act
        await _worker.DispatchReport(reportId, processorQueueName, chargeParameters, null, startedAt, _performContext, _cancellationToken, _version);

        // Assert
        await _idempotentJobManager.Received().CreateJobIfNotExistsAsync<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker>(
            reportId,
            Arg.Any<DateTime>(),
            Arg.Is<DeltaTablePartitionSet>(p => p.PartitionIdReferenceType == "document"),
            processorQueueName,
            Arg.Any<System.Linq.Expressions.Expression<Func<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker, Task>>>()
        );
    }

    #endregion

    #region Edge Cases - Metadata Validation

    [Fact]
    public async Task DispatchReport_ShouldUploadMetadataWithCorrectReportSortColumnIndex()
    {
        // Arrange
        var reportId = "test-report-sort-index";
        var processorQueueName = "test-queue";
        var startedAt = DateTime.UtcNow;
        var chargeParameters = new ChargeReportsWorkerParameters
        {
            ReportType = "charges_list",
            StartDate = DateTimeOffset.UtcNow,
            EndDate = DateTimeOffset.UtcNow,
            Document = "12345678900"
        };

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.SetTotalJobsAsync(Arg.Any<string>(), Arg.Any<int>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.CreateJobIfNotExistsAsync<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker>(
            Arg.Any<string>(),
            Arg.Any<DateTime>(),
            Arg.Any<DeltaTablePartitionSet>(),
            Arg.Any<string>(),
            Arg.Any<System.Linq.Expressions.Expression<Func<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker, Task>>>()
        ).Returns(Task.FromResult<string?>("job-id"));

        // Act
        await _worker.DispatchReport(reportId, processorQueueName, chargeParameters, null, startedAt, _performContext, _cancellationToken, _version);

        // Assert - charges_list should have ReportSortColumnIndex = 10
        await _s3ClientWrapper.Received(1).UploadReportMetadataAsync(
            Arg.Is<ReportMetadata>(m => m.ReportSortColumnIndex == 10)
        );
    }

    [Fact]
    public async Task DispatchReport_ShouldUploadMetadataWithCorrectDispatchId()
    {
        // Arrange
        var reportId = "test-report-dispatch-id";
        var processorQueueName = "test-queue";
        var startedAt = DateTime.UtcNow;
        var chargeParameters = new ChargeReportsWorkerParameters
        {
            ReportType = "charges_list",
            StartDate = DateTimeOffset.UtcNow,
            EndDate = DateTimeOffset.UtcNow,
            Document = "12345678900"
        };

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.SetTotalJobsAsync(Arg.Any<string>(), Arg.Any<int>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.CreateJobIfNotExistsAsync<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker>(
            Arg.Any<string>(),
            Arg.Any<DateTime>(),
            Arg.Any<DeltaTablePartitionSet>(),
            Arg.Any<string>(),
            Arg.Any<System.Linq.Expressions.Expression<Func<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker, Task>>>()
        ).Returns(Task.FromResult<string?>("job-id"));

        // Act
        await _worker.DispatchReport(reportId, processorQueueName, chargeParameters, null, startedAt, _performContext, _cancellationToken, _version);

        // Assert
        await _s3ClientWrapper.Received(1).UploadReportMetadataAsync(
            Arg.Is<ReportMetadata>(m => m.DispatchId == "test-job-id")
        );
    }

    [Fact]
    public async Task DispatchReport_ShouldUploadMetadataWithCorrectCreatedAt()
    {
        // Arrange
        var reportId = "test-report-created-at";
        var processorQueueName = "test-queue";
        var startedAt = new DateTime(2024, 1, 15, 10, 30, 0, DateTimeKind.Utc);
        var chargeParameters = new ChargeReportsWorkerParameters
        {
            ReportType = "charges_list",
            StartDate = DateTimeOffset.UtcNow,
            EndDate = DateTimeOffset.UtcNow,
            Document = "12345678900"
        };

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.SetTotalJobsAsync(Arg.Any<string>(), Arg.Any<int>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.CreateJobIfNotExistsAsync<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker>(
            Arg.Any<string>(),
            Arg.Any<DateTime>(),
            Arg.Any<DeltaTablePartitionSet>(),
            Arg.Any<string>(),
            Arg.Any<System.Linq.Expressions.Expression<Func<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker, Task>>>()
        ).Returns(Task.FromResult<string?>("job-id"));

        // Act
        await _worker.DispatchReport(reportId, processorQueueName, chargeParameters, null, startedAt, _performContext, _cancellationToken, _version);

        // Assert
        await _s3ClientWrapper.Received(1).UploadReportMetadataAsync(
            Arg.Is<ReportMetadata>(m => m.CreatedAt == startedAt)
        );
    }

    #endregion

    #region Edge Cases - Multiple Documents/Merchants

    [Fact]
    public async Task DispatchReport_WithMultipleDocuments_ShouldCreateJobsForEachPartitionSet()
    {
        // Arrange
        var reportId = "test-report-multi-docs";
        var processorQueueName = "test-queue";
        var startedAt = DateTime.UtcNow;
        var chargeParameters = new ChargeReportsWorkerParameters
        {
            ReportType = "charges_list",
            StartDate = DateTimeOffset.UtcNow,
            EndDate = DateTimeOffset.UtcNow,
            Document = "12345678900,98765432100"
        };

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.SetTotalJobsAsync(Arg.Any<string>(), Arg.Any<int>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.CreateJobIfNotExistsAsync<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker>(
            Arg.Any<string>(),
            Arg.Any<DateTime>(),
            Arg.Any<DeltaTablePartitionSet>(),
            Arg.Any<string>(),
            Arg.Any<System.Linq.Expressions.Expression<Func<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker, Task>>>()
        ).Returns(Task.FromResult<string?>("job-id"));

        // Act
        await _worker.DispatchReport(reportId, processorQueueName, chargeParameters, null, startedAt, _performContext, _cancellationToken, _version);

        // Assert - Should create jobs for multiple partition sets
        await _idempotentJobManager.Received().SetTotalJobsAsync(reportId, Arg.Is<int>(t => t > 0));
    }

    #endregion

    #region Edge Cases - Cancellation

    [Fact]
    public async Task DispatchReport_WithCancellationToken_ShouldPassTokenToAsyncCalls()
    {
        // Arrange
        var reportId = "test-report-cancellation";
        var processorQueueName = "test-queue";
        var startedAt = DateTime.UtcNow;
        var chargeParameters = new ChargeReportsWorkerParameters
        {
            ReportType = "charges_list",
            StartDate = DateTimeOffset.UtcNow,
            EndDate = DateTimeOffset.UtcNow,
            Document = "12345678900"
        };

        using var cts = new CancellationTokenSource();

        _s3ClientWrapper.UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.SetTotalJobsAsync(Arg.Any<string>(), Arg.Any<int>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.CreateJobIfNotExistsAsync<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker>(
            Arg.Any<string>(),
            Arg.Any<DateTime>(),
            Arg.Any<DeltaTablePartitionSet>(),
            Arg.Any<string>(),
            Arg.Any<System.Linq.Expressions.Expression<Func<PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker, Task>>>()
        ).Returns(Task.FromResult<string?>("job-id"));

        // Act
        await _worker.DispatchReport(reportId, processorQueueName, chargeParameters, null, startedAt, _performContext, cts.Token, _version);

        // Assert - Verify the worker completes successfully with cancellation token
        await _s3ClientWrapper.Received(1).UploadReportMetadataAsync(Arg.Any<ReportMetadata>());
    }

    #endregion
}

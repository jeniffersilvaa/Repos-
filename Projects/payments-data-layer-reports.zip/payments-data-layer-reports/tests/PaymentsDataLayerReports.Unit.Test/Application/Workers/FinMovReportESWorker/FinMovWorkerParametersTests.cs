using PaymentsDataLayerReports.Application.Workers.FinMovReportESWorker;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.FinMovReportESWorker;

public class FinMovWorkerParametersTests
{
    [Fact]
    public void ToGetFinancialMovementsRequestModel_ShouldMapBasicFields()
    {
        // Arrange
        var parameters = new FinMovESWorkerParameters
        {
            StartDate = new DateOnly(2025, 1, 1),
            EndDate = new DateOnly(2025, 1, 31),
            Document = "12345678901",
            AffiliationCodes = "code1,code2",
            Organizations = "stone,ton"
        };

        // Act
        var result = parameters.ToGetFinancialMovementsRequestModel(100, "cursor-123");

        // Assert
        Assert.Equal(100, result.Size);
        Assert.Equal("cursor-123", result.Cursor);
        Assert.Equal(new DateOnly(2025, 1, 1), result.StartDueDate);
        Assert.Equal(new DateOnly(2025, 1, 31), result.EndDueDate);
        Assert.Equal("12345678901", result.Document);
        Assert.Equal("code1,code2", result.AffiliationCodes);
        Assert.Equal("stone,ton", result.Organizations);
    }

    [Fact]
    public void ToGetFinancialMovementsRequestModel_ShouldMapCardBrandsToBrands()
    {
        // Arrange
        var parameters = new FinMovESWorkerParameters
        {
            StartDate = new DateOnly(2025, 1, 1),
            EndDate = new DateOnly(2025, 1, 31),
            CardBrands = "visa,mastercard"
        };

        // Act
        var result = parameters.ToGetFinancialMovementsRequestModel(100);

        // Assert
        Assert.Equal("visa,mastercard", result.Brands);
    }

    [Fact]
    public void ToGetFinancialMovementsRequestModel_ShouldMapWithPayments()
    {
        // Arrange
        var parameters = new FinMovESWorkerParameters
        {
            StartDate = new DateOnly(2025, 1, 1),
            EndDate = new DateOnly(2025, 1, 31),
            WithPayments = true
        };

        // Act
        var result = parameters.ToGetFinancialMovementsRequestModel(100);

        // Assert
        Assert.True(result.WithPayments);
    }

    [Fact]
    public void ToGetFinancialMovementsRequestModel_WithNullCursor_ShouldSetCursorToNull()
    {
        // Arrange
        var parameters = new FinMovESWorkerParameters
        {
            StartDate = new DateOnly(2025, 1, 1),
            EndDate = new DateOnly(2025, 1, 31)
        };

        // Act
        var result = parameters.ToGetFinancialMovementsRequestModel(100);

        // Assert
        Assert.Null(result.Cursor);
    }

    [Fact]
    public void ToGetFinancialMovementsRequestModel_WithNullSize_ShouldSetSizeToNull()
    {
        // Arrange
        var parameters = new FinMovESWorkerParameters
        {
            StartDate = new DateOnly(2025, 1, 1),
            EndDate = new DateOnly(2025, 1, 31)
        };

        // Act
        var result = parameters.ToGetFinancialMovementsRequestModel(null);

        // Assert
        Assert.Null(result.Size);
    }

    [Fact]
    public void ToGetFinancialMovementsRequestModel_WithAllNullOptionalFields_ShouldNotThrow()
    {
        // Arrange
        var parameters = new FinMovESWorkerParameters
        {
            StartDate = new DateOnly(2025, 1, 1),
            EndDate = new DateOnly(2025, 1, 31)
        };

        // Act
        var result = parameters.ToGetFinancialMovementsRequestModel(100);

        // Assert
        Assert.Null(result.Document);
        Assert.Null(result.AffiliationCodes);
        Assert.Null(result.Organizations);
        Assert.Null(result.Brands);
        Assert.Null(result.WithPayments);
    }

    [Fact]
    public void ToGetFinancialMovementsRequestModel_ShouldPreserveDateValues()
    {
        // Arrange
        var startDate = new DateOnly(2024, 6, 15);
        var endDate = new DateOnly(2024, 6, 30);
        var parameters = new FinMovESWorkerParameters
        {
            StartDate = startDate,
            EndDate = endDate
        };

        // Act
        var result = parameters.ToGetFinancialMovementsRequestModel(100);

        // Assert
        Assert.Equal(startDate, result.StartDueDate);
        Assert.Equal(endDate, result.EndDueDate);
    }

    [Fact]
    public void ToGetFinancialMovementsRequestModel_ShouldMapStoneAccounts()
    {
        // Arrange
        var parameters = new FinMovESWorkerParameters
        {
            StartDate = new DateOnly(2025, 1, 1),
            EndDate = new DateOnly(2025, 1, 31),
            StoneAccounts = "account1,account2,account3"
        };

        // Act
        var result = parameters.ToGetFinancialMovementsRequestModel(100);

        // Assert
        Assert.Equal("account1,account2,account3", result.StoneAccounts);
    }

    [Fact]
    public void ToGetFinancialMovementsRequestModel_ShouldMapPaymentProfiles()
    {
        // Arrange
        var parameters = new FinMovESWorkerParameters
        {
            StartDate = new DateOnly(2025, 1, 1),
            EndDate = new DateOnly(2025, 1, 31),
            PaymentProfiles = "profile1,profile2"
        };

        // Act
        var result = parameters.ToGetFinancialMovementsRequestModel(100);

        // Assert
        Assert.Equal("profile1,profile2", result.PaymentProfiles);
    }

    [Fact]
    public void ToGetFinancialMovementsRequestModel_ShouldMapPoiTypes()
    {
        // Arrange
        var parameters = new FinMovESWorkerParameters
        {
            StartDate = new DateOnly(2025, 1, 1),
            EndDate = new DateOnly(2025, 1, 31),
            PoiTypes = "pos,ecommerce,mobile"
        };

        // Act
        var result = parameters.ToGetFinancialMovementsRequestModel(100);

        // Assert
        Assert.Equal("pos,ecommerce,mobile", result.PoiTypes);
    }

    [Fact]
    public void ToGetFinancialMovementsRequestModel_ShouldMapAllNewFieldsTogether()
    {
        // Arrange
        var parameters = new FinMovESWorkerParameters
        {
            StartDate = new DateOnly(2025, 1, 1),
            EndDate = new DateOnly(2025, 1, 31),
            StoneAccounts = "acc1,acc2",
            PaymentProfiles = "prof1,prof2",
            PoiTypes = "pos,mobile"
        };

        // Act
        var result = parameters.ToGetFinancialMovementsRequestModel(100);

        // Assert
        Assert.Equal("acc1,acc2", result.StoneAccounts);
        Assert.Equal("prof1,prof2", result.PaymentProfiles);
        Assert.Equal("pos,mobile", result.PoiTypes);
    }

    [Fact]
    public void ToGetFinancialMovementsRequestModel_WithNullNewFields_ShouldSetToNull()
    {
        // Arrange
        var parameters = new FinMovESWorkerParameters
        {
            StartDate = new DateOnly(2025, 1, 1),
            EndDate = new DateOnly(2025, 1, 31),
            StoneAccounts = null,
            PaymentProfiles = null,
            PoiTypes = null
        };

        // Act
        var result = parameters.ToGetFinancialMovementsRequestModel(100);

        // Assert
        Assert.Null(result.StoneAccounts);
        Assert.Null(result.PaymentProfiles);
        Assert.Null(result.PoiTypes);
    }
}

using Hangfire;
using Hangfire.Server;
using NSubstitute;
using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Entities.Models.FinMov;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Infra.DataLayerApi;
using PaymentsDataLayerReports.Application.Infra.DataLayerApi.Models;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Interfaces;
using PaymentsDataLayerReports.Application.Workers.FinMovReportESWorker;
using PaymentsDataLayerReports.Application.Workers.Shared.Mappers.FinMov;
using PaymentsDataLayerReports.Application.Workers.Shared.Modifiers.FinMov;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.FinMovReportESWorker;

public class FinMovESWorkerTests
{
    private readonly IDataLayerApiClient _dataLayerApiClient = Substitute.For<IDataLayerApiClient>();
    private readonly IReportStreamWriter<string> _reportStreamWriter = Substitute.For<IReportStreamWriter<string>>();
    private readonly IReportStreamWriterFactory _writerFactory = Substitute.For<IReportStreamWriterFactory>();
    private readonly IBackgroundJobClient _backgroundJobClient = Substitute.For<IBackgroundJobClient>();
    private readonly IS3ClientWrapper _s3ClientWrapper = Substitute.For<IS3ClientWrapper>();
    private readonly PerformContext _performContext;
    private readonly CancellationToken _cancellationToken = CancellationToken.None;
    private readonly FinMovESWorker _worker;

    public FinMovESWorkerTests()
    {
        _performContext = MockFactory.CreatePerformContext("job-123");
        _writerFactory.Create<string>(Arg.Any<string>()).Returns(_reportStreamWriter);
        _worker = new FinMovESWorker(_dataLayerApiClient, _writerFactory, _backgroundJobClient, _s3ClientWrapper);
    }

    [Fact]
    public async Task ProcessReport_ShouldInitializeStreamWriterAndStreamAllRecords()
    {
        // Arrange
        var parameters = CreateParameters();
        var firstBatch = CreateResponse([CreateFinancialMovement("1"), CreateFinancialMovement("2")], "cursor-1");
        var lastBatch = CreateResponse([CreateFinancialMovement("3")], null);

        _dataLayerApiClient
            .GetFinancialMovements(Arg.Any<GetFinancialMovementsRequestModel>(), Arg.Any<string>(), _cancellationToken)
            .Returns(firstBatch, lastBatch);

        // Act
        await _worker.ProcessReport(parameters, _performContext, _cancellationToken);

        // Assert
        var expectedReportId = "job-123";

        _writerFactory.Received(1).Create<string>(FileFormatEnum.Csv.Name);
        await _reportStreamWriter.Received(1).InitializeAsync(expectedReportId, _cancellationToken);
        await _reportStreamWriter.Received(1).WriteHeaderAsync(ReceivablesModifier.GetHeader(), _cancellationToken);
        await _reportStreamWriter.Received(3).WriteRecordAsync(Arg.Any<string>(), _cancellationToken);
        await _reportStreamWriter.Received(1).CompleteAsync(_cancellationToken);
        await _reportStreamWriter.DidNotReceive().AbortAsync(Arg.Any<CancellationToken>());

        Assert.Equal(expectedReportId, parameters.ReportId);
        await _dataLayerApiClient.Received(2)
            .GetFinancialMovements(Arg.Any<GetFinancialMovementsRequestModel>(), expectedReportId, _cancellationToken);
    }

    [Fact]
    public async Task ProcessReport_WithReceivablesReportType_ShouldUseOneStoneCsvMapperHeader()
    {
        // Arrange — "receivables" triggers the OneStone layout; any other type (or null) uses the legacy layout.
        // This verifies that the routing in GetHeader() correctly delegates to the right mapper.
        var parameters = CreateParameters();
        parameters.ReportType = ReportTypeEnum.Receivables.Name;
        var lastBatch = CreateResponse([CreateFinancialMovement("1")], null);

        _dataLayerApiClient
            .GetFinancialMovements(Arg.Any<GetFinancialMovementsRequestModel>(), Arg.Any<string>(), _cancellationToken)
            .Returns(lastBatch);

        // Act
        await _worker.ProcessReport(parameters, _performContext, _cancellationToken);

        // Assert
        var expectedHeader = new ReceivablesOneStoneCsvMapper().GetHeader();
        await _reportStreamWriter.Received(1).WriteHeaderAsync(expectedHeader, _cancellationToken);
    }

    [Fact]
    public async Task ProcessReport_WhenDataLayerApiFails_ShouldAbortStreamWriterAndBubbleException()
    {
        // Arrange
        var parameters = CreateParameters();

        _dataLayerApiClient
            .GetFinancialMovements(Arg.Any<GetFinancialMovementsRequestModel>(), Arg.Any<string>(), _cancellationToken)
            .Returns<Task<GetFinancialMovementsResponseModel>>(_ => throw new InvalidOperationException("DataLayer failure"));

        // Act & Assert
        await Assert.ThrowsAsync<InvalidOperationException>(() => _worker.ProcessReport(parameters, _performContext, _cancellationToken));

        await _reportStreamWriter.Received(1).AbortAsync(CancellationToken.None);
        await _reportStreamWriter.DidNotReceive().CompleteAsync(_cancellationToken);
    }

    private static FinMovESWorkerParameters CreateParameters()
    {
        return new FinMovESWorkerParameters
        {
            StartDate = DateOnly.FromDateTime(DateTime.UtcNow.Date.AddDays(-2)),
            EndDate = DateOnly.FromDateTime(DateTime.UtcNow.Date.AddDays(-1)),
            Document = "12345678900",
            WithPayments = true
        };
    }

    private static GetFinancialMovementsResponseModel CreateResponse(IEnumerable<FinancialMovement> data, string? cursor)
    {
        return new GetFinancialMovementsResponseModel
        {
            Data = data,
            Cursor = cursor,
            Size = data.Count(),
            Total = data.Count()
        };
    }

    private static FinancialMovement CreateFinancialMovement(string id)
    {
        var amount = new Amount(1000m, 950m, new FeeModel(50m, null, null, "CET"), new FeeModel(0m, null, null, "CET"), null);
        var merchant = new Merchant("affiliation", "user", "org", "12345678900", "key", "payment-profile");
        var transaction = new Transaction("product", DateTime.UtcNow.ToString("O"), 1, 1, DateTime.UtcNow.ToString("O"), "op-key", "fund", "VISA", "stone-key", "Ecommerce");
        var settlement = new Settlement(new Wallet("wallet", "nature", 1), "2025-01-01", "settlement-key", DateTime.UtcNow.ToString("O"), "paid", null);

        return new FinancialMovement(
            id,
            Guid.NewGuid().ToString(),
            "sale",
            DateTime.UtcNow.ToString("yyyy-MM-dd"),
            DateTime.UtcNow.ToString("yyyy-MM-dd"),
            DateTime.UtcNow.ToString("O"),
            DateTime.UtcNow.ToString("O"),
            amount,
            merchant,
            merchant,
            transaction,
            settlement,
            []
        );
    }
}

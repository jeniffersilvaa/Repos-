
using NSubstitute;
using PaymentsDataLayerReports.Application.Services.DeltaTableColumnMapping;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.ChargesEvents;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.ChargeReportS3Worker.Services.ChargesEvents;

public class ChargesEventsReportQueryTests : IDisposable
{
    private readonly IColumnMappingService _columnMappingService;
    private readonly List<string> _allowedCategoriesList = ["sale", "reversal", "partial_reversal", "refund_reversal", "antecipacao"];
    private string? _tempInputPath;
    private string? _tempOutputPath;

    public ChargesEventsReportQueryTests()
    {
        _columnMappingService = Substitute.For<IColumnMappingService>();
    }

    public void Dispose()
    {
        TestDataFactory.CleanupTestFiles(_tempInputPath, _tempOutputPath);
        GC.SuppressFinalize(this);
    }

    [Fact]
    public async Task SelectChargesEventsAsync_ShouldIncludeFinancialMovementCategoryFilter()
    {
        // Arrange
        _tempInputPath = TestDataFactory.CreateTempDirectory();
        _tempOutputPath = Path.Combine(Path.GetTempPath(), $"output-{Guid.NewGuid()}.csv");
        var reportInput = TestDataFactory.CreateGenerateReportInput();

        // Act
        var query = await ChargeEventsReportQuery.SelectChargesEventsAsync(
            _tempInputPath, _tempOutputPath, reportInput, true, false, _columnMappingService, _allowedCategoriesList);

        // Assert
        Assert.Contains("card_transaction__financial_movement__category", query);
        Assert.Contains("boleto_transaction__financial_movement__category", query);
        Assert.Contains("pix_transaction__financial_movement__category", query);
        Assert.Contains("'sale'", query);
        Assert.Contains("'reversal'", query);
        Assert.Contains("'antecipacao'", query);
    }

    [Fact]
    public async Task SelectChargesEventsAsync_WithEmptyAllowedCategories_ShouldOmitCategoryFilter()
    {
        // Arrange
        _tempInputPath = TestDataFactory.CreateTempDirectory();
        _tempOutputPath = Path.Combine(Path.GetTempPath(), $"output-{Guid.NewGuid()}.csv");
        var reportInput = TestDataFactory.CreateGenerateReportInput();

        // Act
        var query = await ChargeEventsReportQuery.SelectChargesEventsAsync(
            _tempInputPath, _tempOutputPath, reportInput, true, false, _columnMappingService, []);

        // Assert
        Assert.DoesNotContain("financial_movement__category IS NULL", query);
        Assert.DoesNotContain("financial_movement__category IN", query);
    }
}

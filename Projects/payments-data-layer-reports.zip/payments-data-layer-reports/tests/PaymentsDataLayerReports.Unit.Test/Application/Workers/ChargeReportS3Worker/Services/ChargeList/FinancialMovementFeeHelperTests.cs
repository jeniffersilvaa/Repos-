using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.ChargeList;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.ChargeReportS3Worker.Services.ChargeList;

public class FinancialMovementFeeHelperTests
{
    #region Test Data Helpers

    private static CsvRow CreateCsvRowWithFinancialMovements(List<Dictionary<string, object?>> financialMovements, string transactionPrefix = "boleto_transaction")
    {
        var row = new CsvRow(ChargeListReportHeader.DefaultValues);
        var financialMovementsFieldName = $"{transactionPrefix}__financial_movements";
        row.SetField(ChargeListReportHeader.HeaderIndex[financialMovementsFieldName], financialMovements);
        return row;
    }

    private static Dictionary<string, object?> CreateFinancialMovement(
        string category,
        decimal? discountRateAmount = null,
        decimal? prepaymentFeeAmount = null,
        decimal? fraudCoverageAmount = null,
        decimal? prepaymentFeeTurboAmount = null)
    {
        var movement = new Dictionary<string, object?>
        {
            ["category"] = category,
            ["amount"] = new Dictionary<string, object>()
        };

        var amountDict = (Dictionary<string, object>)movement["amount"]!;

        if (discountRateAmount.HasValue)
        {
            amountDict["discount_rate"] = new Dictionary<string, object>
            {
                ["amount"] = discountRateAmount.Value
            };
        }

        if (prepaymentFeeAmount.HasValue)
        {
            amountDict["prepayment_fee"] = new Dictionary<string, object>
            {
                ["amount"] = prepaymentFeeAmount.Value
            };
        }

        if (fraudCoverageAmount.HasValue)
        {
            amountDict["fraud_coverage"] = new Dictionary<string, object>
            {
                ["amount"] = fraudCoverageAmount.Value
            };
        }

        if (prepaymentFeeTurboAmount.HasValue)
        {
            amountDict["prepayment_fee_turbo"] = new Dictionary<string, object>
            {
                ["amount"] = prepaymentFeeTurboAmount.Value
            };
        }

        return movement;
    }

    #endregion

    #region Sale Category Tests

    [Fact]
    public void ComputeFeesFromFinancialMovements_WithSaleCategory_ShouldAccumulateInMainAmounts()
    {
        // Arrange
        var financialMovements = new List<Dictionary<string, object?>>
        {
            CreateFinancialMovement("sale", discountRateAmount: -100.50m, prepaymentFeeAmount: -50.25m, fraudCoverageAmount: -25.10m)
        };

        var row = CreateCsvRowWithFinancialMovements(financialMovements);

        // Act
        FinancialMovementFeeHelper.ComputeFeesFromFinancialMovements(row, "boleto_transaction__financial_movements", "boleto_transaction");

        // Assert
        var fullMdrAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_mdr_amount");
        var fullRavAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_rav_amount");
        var fullFcAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_fc_amount");
        var fullFeeAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_fee_amount");

        Assert.Equal(100.50m, fullMdrAmount);
        Assert.Equal(50.25m, fullRavAmount);
        Assert.Equal(25.10m, fullFcAmount);
        Assert.Equal(175.85m, fullFeeAmount); // 100.50 + 50.25 + 25.10
    }

    [Fact]
    public void ComputeFeesFromFinancialMovements_WithMultipleSales_ShouldSumAllAmounts()
    {
        // Arrange
        var financialMovements = new List<Dictionary<string, object?>>
        {
            CreateFinancialMovement("sale", discountRateAmount: -100m, prepaymentFeeAmount: -50m, fraudCoverageAmount: -25m),
            CreateFinancialMovement("sale", discountRateAmount: -200m, prepaymentFeeAmount: -75m, fraudCoverageAmount: -30m)
        };

        var row = CreateCsvRowWithFinancialMovements(financialMovements);

        // Act
        FinancialMovementFeeHelper.ComputeFeesFromFinancialMovements(row, "boleto_transaction__financial_movements", "boleto_transaction");

        // Assert
        var fullMdrAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_mdr_amount");
        var fullRavAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_rav_amount");
        var fullFcAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_fc_amount");

        Assert.Equal(300m, fullMdrAmount); // 100 + 200
        Assert.Equal(125m, fullRavAmount); // 50 + 75
        Assert.Equal(55m, fullFcAmount);   // 25 + 30
    }

    #endregion

    #region Reversal Category Tests

    [Fact]
    public void ComputeFeesFromFinancialMovements_WithReversalCategory_ShouldAccumulateInRefundAmounts()
    {
        // Arrange
        var financialMovements = new List<Dictionary<string, object?>>
        {
            CreateFinancialMovement("reversal", discountRateAmount: 50m, prepaymentFeeAmount: 25m, fraudCoverageAmount: 10m)
        };

        var row = CreateCsvRowWithFinancialMovements(financialMovements);

        // Act
        FinancialMovementFeeHelper.ComputeFeesFromFinancialMovements(row, "boleto_transaction__financial_movements", "boleto_transaction");

        // Assert
        var fullMdrRefundAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_mdr_refund_amount");
        var fullRavRefundAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_rav_refund_amount");
        var fullFcRefundAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_fc_refund_amount");

        Assert.Equal(50m, fullMdrRefundAmount);
        Assert.Equal(25m, fullRavRefundAmount);
        Assert.Equal(10m, fullFcRefundAmount);
    }

    [Fact]
    public void ComputeFeesFromFinancialMovements_WithPartialReversalCategory_ShouldAccumulateInRefundAmounts()
    {
        // Arrange
        var financialMovements = new List<Dictionary<string, object?>>
        {
            CreateFinancialMovement("partial_reversal", discountRateAmount: 30m, prepaymentFeeAmount: 15m, fraudCoverageAmount: 5m)
        };

        var row = CreateCsvRowWithFinancialMovements(financialMovements);

        // Act
        FinancialMovementFeeHelper.ComputeFeesFromFinancialMovements(row, "boleto_transaction__financial_movements", "boleto_transaction");

        // Assert
        var fullMdrRefundAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_mdr_refund_amount");
        var fullRavRefundAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_rav_refund_amount");
        var fullFcRefundAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_fc_refund_amount");

        Assert.Equal(30m, fullMdrRefundAmount);
        Assert.Equal(15m, fullRavRefundAmount);
        Assert.Equal(5m, fullFcRefundAmount);
    }

    #endregion

    #region Refund Reversal Category Tests

    [Fact]
    public void ComputeFeesFromFinancialMovements_WithRefundReversalCategory_ShouldAccumulateInMainAmounts()
    {
        // Arrange
        var financialMovements = new List<Dictionary<string, object?>>
        {
            CreateFinancialMovement("refund_reversal", discountRateAmount: -40m, prepaymentFeeAmount: -20m, fraudCoverageAmount: -8m)
        };

        var row = CreateCsvRowWithFinancialMovements(financialMovements);

        // Act
        FinancialMovementFeeHelper.ComputeFeesFromFinancialMovements(row, "boleto_transaction__financial_movements", "boleto_transaction");

        // Assert
        var fullMdrAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_mdr_amount");
        var fullRavAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_rav_amount");
        var fullFcAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_fc_amount");

        Assert.Equal(40m, fullMdrAmount);
        Assert.Equal(20m, fullRavAmount);
        Assert.Equal(8m, fullFcAmount);
    }

    #endregion

    #region Mixed Categories Tests

    [Fact]
    public void ComputeFeesFromFinancialMovements_WithMixedCategories_ShouldCalculateCorrectConsolidatedAmounts()
    {
        // Arrange - Simulating: Sale of 100, then partial refund of 30
        var financialMovements = new List<Dictionary<string, object?>>
        {
            CreateFinancialMovement("sale", discountRateAmount: -100m, prepaymentFeeAmount: -50m, fraudCoverageAmount: -25m),
            CreateFinancialMovement("reversal", discountRateAmount: 30m, prepaymentFeeAmount: 15m, fraudCoverageAmount: 7.5m)
        };

        var row = CreateCsvRowWithFinancialMovements(financialMovements);

        // Act
        FinancialMovementFeeHelper.ComputeFeesFromFinancialMovements(row, "boleto_transaction__financial_movements", "boleto_transaction");

        // Assert
        var fullMdrAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_mdr_amount");
        var fullMdrRefundAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_mdr_refund_amount");
        var fullRavAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_rav_amount");
        var fullRavRefundAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_rav_refund_amount");
        var fullFcAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_fc_amount");
        var fullFcRefundAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_fc_refund_amount");
        var fullFeeAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_fee_amount");

        // Main amounts (absolute values)
        Assert.Equal(100m, fullMdrAmount);
        Assert.Equal(50m, fullRavAmount);
        Assert.Equal(25m, fullFcAmount);

        // Refund amounts
        Assert.Equal(30m, fullMdrRefundAmount);
        Assert.Equal(15m, fullRavRefundAmount);
        Assert.Equal(7.5m, fullFcRefundAmount);

        // Consolidated fee = (|100| - 30) + (|50| - 15) + (|25| - 7.5) = 70 + 35 + 17.5 = 122.5
        Assert.Equal(122.5m, fullFeeAmount);
    }

    [Fact]
    public void ComputeFeesFromFinancialMovements_WithSaleReversalAndRefundReversal_ShouldCalculateCorrectly()
    {
        // Arrange
        var financialMovements = new List<Dictionary<string, object?>>
        {
            CreateFinancialMovement("sale", discountRateAmount: -200m, prepaymentFeeAmount: -100m, fraudCoverageAmount: -50m),
            CreateFinancialMovement("reversal", discountRateAmount: 50m, prepaymentFeeAmount: 25m, fraudCoverageAmount: 12.5m),
            CreateFinancialMovement("refund_reversal", discountRateAmount: -30m, prepaymentFeeAmount: -15m, fraudCoverageAmount: -7.5m)
        };

        var row = CreateCsvRowWithFinancialMovements(financialMovements);

        // Act
        FinancialMovementFeeHelper.ComputeFeesFromFinancialMovements(row, "boleto_transaction__financial_movements", "boleto_transaction");

        // Assert
        var fullMdrAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_mdr_amount");
        var fullMdrRefundAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_mdr_refund_amount");
        var fullFeeAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_fee_amount");

        // fullMdrAmount = |-200 + (-30)| = 230
        Assert.Equal(230m, fullMdrAmount);
        Assert.Equal(50m, fullMdrRefundAmount);

        // Consolidated: (230 - 50) + (115 - 25) + (57.5 - 12.5) = 180 + 90 + 45 = 315
        Assert.Equal(315m, fullFeeAmount);
    }

    #endregion

    #region Null and Missing Data Tests

    [Fact]
    public void ComputeFeesFromFinancialMovements_WithNullFinancialMovements_ShouldReturnEarlyWithoutErrors()
    {
        // Arrange
        var row = new CsvRow(ChargeListReportHeader.DefaultValues);
        row.SetField(ChargeListReportHeader.HeaderIndex["boleto_transaction__financial_movements"], null);

        // Act
        FinancialMovementFeeHelper.ComputeFeesFromFinancialMovements(row, "boleto_transaction__financial_movements", "boleto_transaction");

        // Assert - Should not throw and fields should remain at default values (0)
        var fullFeeAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_fee_amount");
        Assert.Equal(0m, fullFeeAmount);
    }

    [Fact]
    public void ComputeFeesFromFinancialMovements_WithEmptyFinancialMovements_ShouldSetAllFieldsToZero()
    {
        // Arrange
        var financialMovements = new List<Dictionary<string, object?>>();
        var row = CreateCsvRowWithFinancialMovements(financialMovements);

        // Act
        FinancialMovementFeeHelper.ComputeFeesFromFinancialMovements(row, "boleto_transaction__financial_movements", "boleto_transaction");

        // Assert
        var fullMdrAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_mdr_amount");
        var fullRavAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_rav_amount");
        var fullFcAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_fc_amount");
        var fullFeeAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_fee_amount");

        Assert.Equal(0m, fullMdrAmount);
        Assert.Equal(0m, fullRavAmount);
        Assert.Equal(0m, fullFcAmount);
        Assert.Equal(0m, fullFeeAmount);
    }

    [Fact]
    public void ComputeFeesFromFinancialMovements_WithNullAmountObject_ShouldSkipMovementAndContinue()
    {
        // Arrange
        var financialMovements = new List<Dictionary<string, object?>>
        {
            new Dictionary<string, object?>
            {
                ["category"] = "sale",
                ["amount"] = null // Null amount object
            },
            CreateFinancialMovement("sale", discountRateAmount: -100m, prepaymentFeeAmount: -50m, fraudCoverageAmount: -25m)
        };

        var row = CreateCsvRowWithFinancialMovements(financialMovements);

        // Act
        FinancialMovementFeeHelper.ComputeFeesFromFinancialMovements(row, "boleto_transaction__financial_movements", "boleto_transaction");

        // Assert - Should only process the second movement
        var fullMdrAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_mdr_amount");
        var fullRavAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_rav_amount");
        var fullFcAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_fc_amount");

        Assert.Equal(100m, fullMdrAmount);
        Assert.Equal(50m, fullRavAmount);
        Assert.Equal(25m, fullFcAmount);
    }

    [Fact]
    public void ComputeFeesFromFinancialMovements_WithMissingFeeFields_ShouldTreatAsZero()
    {
        // Arrange - Movement with only discount_rate, missing prepayment_fee and fraud_coverage
        var financialMovements = new List<Dictionary<string, object?>>
        {
            CreateFinancialMovement("sale", discountRateAmount: -100m)
        };

        var row = CreateCsvRowWithFinancialMovements(financialMovements);

        // Act
        FinancialMovementFeeHelper.ComputeFeesFromFinancialMovements(row, "boleto_transaction__financial_movements", "boleto_transaction");

        // Assert
        var fullMdrAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_mdr_amount");
        var fullRavAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_rav_amount");
        var fullFcAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_fc_amount");
        var fullFeeAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_fee_amount");

        Assert.Equal(100m, fullMdrAmount);
        Assert.Equal(0m, fullRavAmount);
        Assert.Equal(0m, fullFcAmount);
        Assert.Equal(100m, fullFeeAmount);
    }

    [Fact]
    public void ComputeFeesFromFinancialMovements_WithNullAmountInFeeObject_ShouldTreatAsZero()
    {
        // Arrange
        var movement = new Dictionary<string, object?>
        {
            ["category"] = "sale",
            ["amount"] = new Dictionary<string, object>
            {
                ["discount_rate"] = new Dictionary<string, object>
                {
                    ["amount"] = null! // Null amount value
                },
                ["prepayment_fee"] = new Dictionary<string, object>
                {
                    ["amount"] = -50m
                }
            }
        };

        var financialMovements = new List<Dictionary<string, object?>> { movement };
        var row = CreateCsvRowWithFinancialMovements(financialMovements);

        // Act
        FinancialMovementFeeHelper.ComputeFeesFromFinancialMovements(row, "boleto_transaction__financial_movements", "boleto_transaction");

        // Assert
        var fullMdrAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_mdr_amount");
        var fullRavAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_rav_amount");

        Assert.Equal(0m, fullMdrAmount); // Null treated as 0
        Assert.Equal(50m, fullRavAmount);
    }

    #endregion

    #region Pix Transaction Tests

    [Fact]
    public void ComputeFeesFromFinancialMovements_WithPixTransaction_ShouldCalculateCorrectly()
    {
        // Arrange
        var financialMovements = new List<Dictionary<string, object?>>
        {
            CreateFinancialMovement("sale", discountRateAmount: -150m, prepaymentFeeAmount: -75m, fraudCoverageAmount: -30m)
        };

        var row = CreateCsvRowWithFinancialMovements(financialMovements, "pix_transaction");

        // Act
        FinancialMovementFeeHelper.ComputeFeesFromFinancialMovements(row, "pix_transaction__financial_movements", "pix_transaction");

        // Assert
        var fullMdrAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "pix_transaction__full_mdr_amount");
        var fullRavAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "pix_transaction__full_rav_amount");
        var fullFcAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "pix_transaction__full_fc_amount");
        var fullFeeAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "pix_transaction__full_fee_amount");

        Assert.Equal(150m, fullMdrAmount);
        Assert.Equal(75m, fullRavAmount);
        Assert.Equal(30m, fullFcAmount);
        Assert.Equal(255m, fullFeeAmount); // 150 + 75 + 30
    }

    [Fact]
    public void ComputeFeesFromFinancialMovements_WithPixTransactionMixedCategories_ShouldCalculateCorrectly()
    {
        // Arrange
        var financialMovements = new List<Dictionary<string, object?>>
        {
            CreateFinancialMovement("sale", discountRateAmount: -200m, prepaymentFeeAmount: -100m, fraudCoverageAmount: -40m),
            CreateFinancialMovement("partial_reversal", discountRateAmount: 60m, prepaymentFeeAmount: 30m, fraudCoverageAmount: 12m)
        };

        var row = CreateCsvRowWithFinancialMovements(financialMovements, "pix_transaction");

        // Act
        FinancialMovementFeeHelper.ComputeFeesFromFinancialMovements(row, "pix_transaction__financial_movements", "pix_transaction");

        // Assert
        var fullFeeAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "pix_transaction__full_fee_amount");

        // Consolidated: (200 - 60) + (100 - 30) + (40 - 12) = 140 + 70 + 28 = 238
        Assert.Equal(238m, fullFeeAmount);
    }

    #endregion

    #region Prepayment Fee Turbo Tests

    [Fact]
    public void ComputeFeesFromFinancialMovements_WithSaleTurbo_ShouldIncludeTurboInRav()
    {
        var financialMovements = new List<Dictionary<string, object?>>
        {
            CreateFinancialMovement("sale", discountRateAmount: -100m, prepaymentFeeAmount: -50m, prepaymentFeeTurboAmount: -20m)
        };

        var row = CreateCsvRowWithFinancialMovements(financialMovements);

        FinancialMovementFeeHelper.ComputeFeesFromFinancialMovements(row, "boleto_transaction__financial_movements", "boleto_transaction");

        var fullRavAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_rav_amount");
        var fullFeeAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_fee_amount");

        // RAV = |prepaymentFee + turbo| = |(-50) + (-20)| = 70
        Assert.Equal(70m, fullRavAmount);
        // Fee = MDR + RAV + FC = 100 + 70 + 0 = 170
        Assert.Equal(170m, fullFeeAmount);
    }

    [Fact]
    public void ComputeFeesFromFinancialMovements_WithTurboOnlyInSale_ShouldAddToRav()
    {
        var financialMovements = new List<Dictionary<string, object?>>
        {
            CreateFinancialMovement("sale", prepaymentFeeTurboAmount: -30m)
        };

        var row = CreateCsvRowWithFinancialMovements(financialMovements);

        FinancialMovementFeeHelper.ComputeFeesFromFinancialMovements(row, "boleto_transaction__financial_movements", "boleto_transaction");

        var fullRavAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_rav_amount");
        Assert.Equal(30m, fullRavAmount);
    }

    [Fact]
    public void ComputeFeesFromFinancialMovements_WithTurboInPartialReversal_ShouldAddToRavRefund()
    {
        var financialMovements = new List<Dictionary<string, object?>>
        {
            CreateFinancialMovement("sale", prepaymentFeeAmount: -100m, prepaymentFeeTurboAmount: -20m),
            CreateFinancialMovement("partial_reversal", prepaymentFeeAmount: 50m, prepaymentFeeTurboAmount: 10m)
        };

        var row = CreateCsvRowWithFinancialMovements(financialMovements);

        FinancialMovementFeeHelper.ComputeFeesFromFinancialMovements(row, "boleto_transaction__financial_movements", "boleto_transaction");

        var fullRavAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_rav_amount");
        var fullRavRefundAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_rav_refund_amount");
        var fullFeeAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_fee_amount");

        // RAV = |(-100) + (-20)| = 120
        Assert.Equal(120m, fullRavAmount);
        // RAV Refund = 50 + 10 = 60
        Assert.Equal(60m, fullRavRefundAmount);
        // Fee = (0 - 0) + (120 - 60) + (0 - 0) = 60
        Assert.Equal(60m, fullFeeAmount);
    }

    [Fact]
    public void ComputeFeesFromFinancialMovements_WithTurboInRefundReversal_ShouldAddToRav()
    {
        var financialMovements = new List<Dictionary<string, object?>>
        {
            CreateFinancialMovement("refund_reversal", prepaymentFeeTurboAmount: -15m)
        };

        var row = CreateCsvRowWithFinancialMovements(financialMovements);

        FinancialMovementFeeHelper.ComputeFeesFromFinancialMovements(row, "boleto_transaction__financial_movements", "boleto_transaction");

        var fullRavAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_rav_amount");
        Assert.Equal(15m, fullRavAmount);
    }

    #endregion

    #region Edge Cases

    [Fact]
    public void ComputeFeesFromFinancialMovements_WithUnknownCategory_ShouldNotAccumulateAnything()
    {
        // Arrange
        var financialMovements = new List<Dictionary<string, object?>>
        {
            CreateFinancialMovement("unknown_category", discountRateAmount: -100m, prepaymentFeeAmount: -50m, fraudCoverageAmount: -25m)
        };

        var row = CreateCsvRowWithFinancialMovements(financialMovements);

        // Act
        FinancialMovementFeeHelper.ComputeFeesFromFinancialMovements(row, "boleto_transaction__financial_movements", "boleto_transaction");

        // Assert - Unknown category should not be processed
        var fullMdrAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_mdr_amount");
        var fullRavAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_rav_amount");
        var fullFcAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_fc_amount");
        var fullFeeAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_fee_amount");

        Assert.Equal(0m, fullMdrAmount);
        Assert.Equal(0m, fullRavAmount);
        Assert.Equal(0m, fullFcAmount);
        Assert.Equal(0m, fullFeeAmount);
    }

    [Fact]
    public void ComputeFeesFromFinancialMovements_WithZeroAmounts_ShouldCalculateCorrectly()
    {
        // Arrange
        var financialMovements = new List<Dictionary<string, object?>>
        {
            CreateFinancialMovement("sale", discountRateAmount: 0m, prepaymentFeeAmount: 0m, fraudCoverageAmount: 0m)
        };

        var row = CreateCsvRowWithFinancialMovements(financialMovements);

        // Act
        FinancialMovementFeeHelper.ComputeFeesFromFinancialMovements(row, "boleto_transaction__financial_movements", "boleto_transaction");

        // Assert
        var fullFeeAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_fee_amount");
        Assert.Equal(0m, fullFeeAmount);
    }

    [Fact]
    public void ComputeFeesFromFinancialMovements_WithVeryLargeNumbers_ShouldHandleCorrectly()
    {
        // Arrange
        var financialMovements = new List<Dictionary<string, object?>>
        {
            CreateFinancialMovement("sale", discountRateAmount: -999999.99m, prepaymentFeeAmount: -888888.88m, fraudCoverageAmount: -777777.77m)
        };

        var row = CreateCsvRowWithFinancialMovements(financialMovements);

        // Act
        FinancialMovementFeeHelper.ComputeFeesFromFinancialMovements(row, "boleto_transaction__financial_movements", "boleto_transaction");

        // Assert
        var fullMdrAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_mdr_amount");
        var fullRavAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_rav_amount");
        var fullFcAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_fc_amount");
        var fullFeeAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_fee_amount");

        Assert.Equal(999999.99m, fullMdrAmount);
        Assert.Equal(888888.88m, fullRavAmount);
        Assert.Equal(777777.77m, fullFcAmount);
        Assert.Equal(2666666.64m, fullFeeAmount);
    }

    [Fact]
    public void ComputeFeesFromFinancialMovements_WithDecimalPrecision_ShouldMaintainAccuracy()
    {
        // Arrange
        var financialMovements = new List<Dictionary<string, object?>>
        {
            CreateFinancialMovement("sale", discountRateAmount: -10.123456m, prepaymentFeeAmount: -5.654321m, fraudCoverageAmount: -2.987654m)
        };

        var row = CreateCsvRowWithFinancialMovements(financialMovements);

        // Act
        FinancialMovementFeeHelper.ComputeFeesFromFinancialMovements(row, "boleto_transaction__financial_movements", "boleto_transaction");

        // Assert
        var fullMdrAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_mdr_amount");
        var fullRavAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_rav_amount");
        var fullFcAmount = row.GetField<decimal>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_fc_amount");

        Assert.Equal(10.123456m, fullMdrAmount);
        Assert.Equal(5.654321m, fullRavAmount);
        Assert.Equal(2.987654m, fullFcAmount);
    }

    #endregion
}

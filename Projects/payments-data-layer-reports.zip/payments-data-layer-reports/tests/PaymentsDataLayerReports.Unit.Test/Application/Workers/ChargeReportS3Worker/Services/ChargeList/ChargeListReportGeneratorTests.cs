using Microsoft.Extensions.DependencyInjection;
using NSubstitute;
using NSubstitute.ExceptionExtensions;
using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.ChargeList;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.Models;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.RealtimeChargeEvents;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;
using PaymentsDataLayerReports.Application.Workers.Shared;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.ChargeReportS3Worker.Services.ChargeList;

public class ChargeListReportGeneratorTests
{
    private readonly IDeltaLakeManager _deltaLakeManager;
    private readonly IS3ClientWrapper _s3ClientWrapper;
    private readonly IChargeListReportManager _chargeListReportManager;
    private readonly IRealtimeChargeEventsService _realtimeChargeEventsService;
    private readonly ChargeListReportGenerator _generator;
    private readonly ISaleCsvMapper<CsvRow> _saleCsvMapper;
    private readonly ICetFeatureManager _cetFeatureManager;
    private readonly IServiceProvider _serviceProvider;
    private readonly string headerMock = "id,amount,status,created_at";

    public ChargeListReportGeneratorTests()
    {
        // Arrange - Setup common mocks using interfaces
        _deltaLakeManager = Substitute.For<IDeltaLakeManager>();
        _s3ClientWrapper = Substitute.For<IS3ClientWrapper>();
        _chargeListReportManager = Substitute.For<IChargeListReportManager>();
        _realtimeChargeEventsService = Substitute.For<IRealtimeChargeEventsService>();
        _cetFeatureManager = Substitute.For<ICetFeatureManager>();

        // Configure ISaleCsvMapper mock
        _saleCsvMapper = Substitute.For<ISaleCsvMapper<CsvRow>>();
        var csvMapperForCharge = Substitute.For<ISaleCsvMapper<Charge>>();
        csvMapperForCharge.CreatedAtColumnPosition.Returns(8);
        csvMapperForCharge.GetHeader().Returns(headerMock);
        csvMapperForCharge.BuildRow(Arg.Any<Charge>()).Returns("test-id,1000,succeeded");

        // Create real ServiceProvider with keyed services
        var services = new ServiceCollection();
        services.AddKeyedSingleton(typeof(ISaleCsvMapper<Charge>), "charges_list", csvMapperForCharge);
        services.AddKeyedSingleton(typeof(ISaleCsvMapper<Charge>), "sales_ton", csvMapperForCharge);
        services.AddKeyedSingleton(typeof(ISaleCsvMapper<Charge>), "sales_stone", csvMapperForCharge);
        _serviceProvider = services.BuildServiceProvider();

        _generator = new ChargeListReportGenerator(
            _deltaLakeManager,
            _s3ClientWrapper,
            _chargeListReportManager,
            _realtimeChargeEventsService,
            _cetFeatureManager,
            _serviceProvider
        );
    }

    #region Success Scenarios - Complete Flow

    [Fact]
    public async Task Execute_WithValidInput_ShouldCompleteSuccessfully()
    {
        // Arrange
        var input = TestDataFactory.CreateGenerateReportInput(reportType: "charges_list");

        // Set StartDate = PartitionDate to ensure header upload happens
        input.ReportMetadata.ChargeReportParameters!.StartDate = input.PartitionDate;

        var parquetPath = "/tmp/test-parquet";
        var csvFile = "/tmp/test.csv";

        _chargeListReportManager.ChargesEventsRawParquetPath.Returns(parquetPath);
        _chargeListReportManager.ChargesEventsRawCsvFile.Returns(csvFile);
        _chargeListReportManager.ChargesEventsSortedByIdCsvFile.Returns("/tmp/sorted.csv");
        _chargeListReportManager.ChargesRawCsvFile.Returns("/tmp/raw.csv");
        _chargeListReportManager.ChargesFilteredCsvFile.Returns("/tmp/filtered.csv");
        _chargeListReportManager.ChargesSortedByCreatedAtCsvFile.Returns("/tmp/sorted-created.csv");

        _realtimeChargeEventsService.BuildRealtimeFileAsync(
            Arg.Any<GenerateReportInput>(),
            Arg.Any<string>())
            .Returns(Task.FromResult(true));

        _deltaLakeManager.DownloadAsync(Arg.Any<GenerateReportInput>(), Arg.Any<string>())
            .Returns(Task.FromResult(1000L));

        _deltaLakeManager.ConvertToCsvAsync(
            Arg.Any<GenerateReportInput>(),
            Arg.Any<string>(),
            Arg.Any<string>(),
            Arg.Any<bool>(),
            Arg.Any<bool>())
            .Returns(Task.FromResult((10, 500L)));

        // Mock file operations
        SetupFileSystemMocks(csvFile);

        // Act
        await _generator.Execute(input);

        // Assert
        await _s3ClientWrapper.Received(1).UploadReportHeaderAsync(
            input.ReportMetadata.ReportId,
            headerMock);

        await _deltaLakeManager.Received(1).DownloadAsync(input, parquetPath);
        await _deltaLakeManager.Received(1).ConvertToCsvAsync(
            input,
            parquetPath,
            csvFile,
            true,
            true);

        _chargeListReportManager.Received(1).SortEventsByChargeId(
            input.JobId,
            input.ReportMetadata.ReportId,
            input.PartitionDate,
            Arg.Any<int>());

        _chargeListReportManager.Received(1).SortChargesByCreatedAt(
            input.JobId,
            input.ReportMetadata.ReportId,
            input.PartitionDate,
            Arg.Any<string>(),
            8,
            Arg.Any<char>()
            );

        await _s3ClientWrapper.Received(1).UploadReportAsync(
            Arg.Any<string>(),
            input.ReportMetadata.ReportId,
            Arg.Any<string>(),
            input.PartitionDate);

        _chargeListReportManager.Received(1).Dispose();
    }

    [Fact]
    public async Task Execute_WhenPartitionDateEqualsStartDate_ShouldUploadHeader()
    {
        // Arrange
        var startDate = DateTime.Today;
        var input = TestDataFactory.CreateGenerateReportInput(
            partitionDate: startDate,
            reportType: "charges_list");

        input.ReportMetadata.ChargeReportParameters!.StartDate = startDate;

        SetupSuccessfulExecution(input);

        // Act
        await _generator.Execute(input);

        // Assert
        await _s3ClientWrapper.Received(1).UploadReportHeaderAsync(
            input.ReportMetadata.ReportId,
            headerMock);
    }

    [Fact]
    public async Task Execute_WhenPartitionDateAfterStartDate_ShouldNotUploadHeader()
    {
        // Arrange
        var startDate = DateTime.Today.AddDays(-5);
        var partitionDate = DateTime.Today;
        var input = TestDataFactory.CreateGenerateReportInput(
            partitionDate: partitionDate,
            reportType: "charges_list");

        input.ReportMetadata.ChargeReportParameters!.StartDate = startDate;

        SetupSuccessfulExecution(input);

        // Act
        await _generator.Execute(input);

        // Assert
        await _s3ClientWrapper.DidNotReceive().UploadReportHeaderAsync(
            Arg.Any<string>(),
            Arg.Any<string>());
    }

    #endregion

    #region Edge Cases - No Data Scenarios

    [Fact]
    public async Task Execute_WhenNoRealtimeDataAndNoParquetData_ShouldReturnEarly()
    {
        // Arrange
        var input = TestDataFactory.CreateGenerateReportInput(reportType: "charges_list");
        var parquetPath = "/tmp/test-parquet";

        _chargeListReportManager.ChargesEventsRawParquetPath.Returns(parquetPath);

        _realtimeChargeEventsService.BuildRealtimeFileAsync(
            Arg.Any<GenerateReportInput>(),
            Arg.Any<string>())
            .Returns(Task.FromResult(false));

        _deltaLakeManager.DownloadAsync(Arg.Any<GenerateReportInput>(), Arg.Any<string>())
            .Returns(Task.FromResult(0L)); // No parquet data

        // Act
        await _generator.Execute(input);

        // Assert
        await _deltaLakeManager.DidNotReceive().ConvertToCsvAsync(
            Arg.Any<GenerateReportInput>(),
            Arg.Any<string>(),
            Arg.Any<string>(),
            Arg.Any<bool>(),
            Arg.Any<bool>());

        _chargeListReportManager.DidNotReceive().SortEventsByChargeId(
            Arg.Any<string>(),
            Arg.Any<string>(),
            Arg.Any<DateTime>(),
            Arg.Any<int>());

        await _s3ClientWrapper.DidNotReceive().UploadReportAsync(
            Arg.Any<string>(),
            Arg.Any<string>(),
            Arg.Any<string>(),
            Arg.Any<DateTime>(),
            Arg.Any<string?>());

        _chargeListReportManager.Received(1).Dispose();
    }

    [Fact]
    public async Task Execute_WhenOnlyRealtimeData_ShouldProcessSuccessfully()
    {
        // Arrange
        var input = TestDataFactory.CreateGenerateReportInput(reportType: "charges_list");
        var parquetPath = "/tmp/test-parquet";
        var csvFile = "/tmp/test.csv";

        _chargeListReportManager.ChargesEventsRawParquetPath.Returns(parquetPath);
        _chargeListReportManager.ChargesEventsRawCsvFile.Returns(csvFile);
        _chargeListReportManager.ChargesEventsSortedByIdCsvFile.Returns("/tmp/sorted.csv");
        _chargeListReportManager.ChargesRawCsvFile.Returns("/tmp/raw.csv");
        _chargeListReportManager.ChargesFilteredCsvFile.Returns("/tmp/filtered.csv");
        _chargeListReportManager.ChargesSortedByCreatedAtCsvFile.Returns("/tmp/sorted-created.csv");

        _realtimeChargeEventsService.BuildRealtimeFileAsync(
            Arg.Any<GenerateReportInput>(),
            Arg.Any<string>())
            .Returns(Task.FromResult(true)); // Has realtime data

        _deltaLakeManager.DownloadAsync(Arg.Any<GenerateReportInput>(), Arg.Any<string>())
            .Returns(Task.FromResult(0L)); // No parquet data

        _deltaLakeManager.ConvertToCsvAsync(
            Arg.Any<GenerateReportInput>(),
            Arg.Any<string>(),
            Arg.Any<string>(),
            Arg.Any<bool>(),
            Arg.Any<bool>())
            .Returns(Task.FromResult((5, 200L)));

        SetupFileSystemMocks(csvFile);

        // Act
        await _generator.Execute(input);

        // Assert
        await _deltaLakeManager.Received(1).ConvertToCsvAsync(
            input,
            parquetPath,
            csvFile,
            true,  // hasRealTimeData
            false); // hasParquetData

        await _s3ClientWrapper.Received(1).UploadReportAsync(
            Arg.Any<string>(),
            input.ReportMetadata.ReportId,
            Arg.Any<string>(),
            input.PartitionDate);
    }

    [Fact]
    public async Task Execute_WhenOnlyParquetData_ShouldProcessSuccessfully()
    {
        // Arrange
        var input = TestDataFactory.CreateGenerateReportInput(reportType: "charges_list");
        var parquetPath = "/tmp/test-parquet";
        var csvFile = "/tmp/test.csv";

        _chargeListReportManager.ChargesEventsRawParquetPath.Returns(parquetPath);
        _chargeListReportManager.ChargesEventsRawCsvFile.Returns(csvFile);
        _chargeListReportManager.ChargesEventsSortedByIdCsvFile.Returns("/tmp/sorted.csv");
        _chargeListReportManager.ChargesRawCsvFile.Returns("/tmp/raw.csv");
        _chargeListReportManager.ChargesFilteredCsvFile.Returns("/tmp/filtered.csv");
        _chargeListReportManager.ChargesSortedByCreatedAtCsvFile.Returns("/tmp/sorted-created.csv");

        _realtimeChargeEventsService.BuildRealtimeFileAsync(
            Arg.Any<GenerateReportInput>(),
            Arg.Any<string>())
            .Returns(Task.FromResult(false)); // No realtime data

        _deltaLakeManager.DownloadAsync(Arg.Any<GenerateReportInput>(), Arg.Any<string>())
            .Returns(Task.FromResult(2000L)); // Has parquet data

        _deltaLakeManager.ConvertToCsvAsync(
            Arg.Any<GenerateReportInput>(),
            Arg.Any<string>(),
            Arg.Any<string>(),
            Arg.Any<bool>(),
            Arg.Any<bool>())
            .Returns(Task.FromResult((15, 1000L)));

        SetupFileSystemMocks(csvFile);

        // Act
        await _generator.Execute(input);

        // Assert
        await _deltaLakeManager.Received(1).ConvertToCsvAsync(
            input,
            parquetPath,
            csvFile,
            false, // hasRealTimeData
            true); // hasParquetData

        await _s3ClientWrapper.Received(1).UploadReportAsync(
            Arg.Any<string>(),
            input.ReportMetadata.ReportId,
            Arg.Any<string>(),
            input.PartitionDate);
    }

    [Fact]
    public async Task Execute_WhenCsvCountIsZero_ShouldReturnEarlyAfterFiltering()
    {
        // Arrange
        var input = TestDataFactory.CreateGenerateReportInput(reportType: "charges_list");
        var parquetPath = "/tmp/test-parquet";
        var csvFile = "/tmp/test.csv";

        _chargeListReportManager.ChargesEventsRawParquetPath.Returns(parquetPath);
        _chargeListReportManager.ChargesEventsRawCsvFile.Returns(csvFile);

        _realtimeChargeEventsService.BuildRealtimeFileAsync(
            Arg.Any<GenerateReportInput>(),
            Arg.Any<string>())
            .Returns(Task.FromResult(true));

        _deltaLakeManager.DownloadAsync(Arg.Any<GenerateReportInput>(), Arg.Any<string>())
            .Returns(Task.FromResult(1000L));

        _deltaLakeManager.ConvertToCsvAsync(
            Arg.Any<GenerateReportInput>(),
            Arg.Any<string>(),
            Arg.Any<string>(),
            Arg.Any<bool>(),
            Arg.Any<bool>())
            .Returns(Task.FromResult((0, 500L))); // Zero count after filtering

        // Act
        await _generator.Execute(input);

        // Assert - When csvCount is 0, the code returns early WITHOUT calling TryDeleteParquetPath
        _chargeListReportManager.DidNotReceive().TryDeleteParquetPath();

        _chargeListReportManager.DidNotReceive().SortEventsByChargeId(
            Arg.Any<string>(),
            Arg.Any<string>(),
            Arg.Any<DateTime>(),
            Arg.Any<int>());

        await _s3ClientWrapper.DidNotReceive().UploadReportAsync(
            Arg.Any<string>(),
            Arg.Any<string>(),
            Arg.Any<string>(),
            Arg.Any<DateTime>(),
            Arg.Any<string?>());

        _chargeListReportManager.Received(1).Dispose();
    }

    #endregion

    #region Error Handling - Exception Propagation

    [Fact]
    public async Task Execute_WhenRealtimeServiceThrows_ShouldPropagateException()
    {
        // Arrange
        var input = TestDataFactory.CreateGenerateReportInput(reportType: "charges_list");
        var expectedException = new InvalidOperationException("Realtime service failed");

        _chargeListReportManager.ChargesEventsRawParquetPath.Returns("/tmp/test-parquet");

        _realtimeChargeEventsService.BuildRealtimeFileAsync(
            Arg.Any<GenerateReportInput>(),
            Arg.Any<string>())
            .Throws(expectedException);

        // Act & Assert
        var exception = await Assert.ThrowsAsync<InvalidOperationException>(
            () => _generator.Execute(input));

        Assert.Equal(expectedException.Message, exception.Message);
        _chargeListReportManager.Received(1).Dispose();
    }

    [Fact]
    public async Task Execute_WhenDownloadAsyncThrows_ShouldPropagateException()
    {
        // Arrange
        var input = TestDataFactory.CreateGenerateReportInput(reportType: "charges_list");
        var expectedException = new IOException("Download failed");

        _chargeListReportManager.ChargesEventsRawParquetPath.Returns("/tmp/test-parquet");

        _realtimeChargeEventsService.BuildRealtimeFileAsync(
            Arg.Any<GenerateReportInput>(),
            Arg.Any<string>())
            .Returns(Task.FromResult(true));

        _deltaLakeManager.DownloadAsync(Arg.Any<GenerateReportInput>(), Arg.Any<string>())
            .Throws(expectedException);

        // Act & Assert
        var exception = await Assert.ThrowsAsync<IOException>(
            () => _generator.Execute(input));

        Assert.Equal(expectedException.Message, exception.Message);
        _chargeListReportManager.Received(1).Dispose();
    }

    [Fact]
    public async Task Execute_WhenConvertToCsvAsyncThrows_ShouldPropagateException()
    {
        // Arrange
        var input = TestDataFactory.CreateGenerateReportInput(reportType: "charges_list");
        var expectedException = new InvalidOperationException("CSV conversion failed");

        _chargeListReportManager.ChargesEventsRawParquetPath.Returns("/tmp/test-parquet");

        _realtimeChargeEventsService.BuildRealtimeFileAsync(
            Arg.Any<GenerateReportInput>(),
            Arg.Any<string>())
            .Returns(Task.FromResult(true));

        _deltaLakeManager.DownloadAsync(Arg.Any<GenerateReportInput>(), Arg.Any<string>())
            .Returns(Task.FromResult(1000L));

        _deltaLakeManager.ConvertToCsvAsync(
            Arg.Any<GenerateReportInput>(),
            Arg.Any<string>(),
            Arg.Any<string>(),
            Arg.Any<bool>(),
            Arg.Any<bool>())
            .Throws(expectedException);

        // Act & Assert
        var exception = await Assert.ThrowsAsync<InvalidOperationException>(
            () => _generator.Execute(input));

        Assert.Equal(expectedException.Message, exception.Message);
        _chargeListReportManager.Received(1).Dispose();
    }

    [Fact]
    public async Task Execute_WhenSortEventsByChargeIdThrows_ShouldPropagateException()
    {
        // Arrange
        var input = TestDataFactory.CreateGenerateReportInput(reportType: "charges_list");
        var expectedException = new Exception("Sort failed with exit code 1");
        var csvFile = "/tmp/test.csv";

        _chargeListReportManager.ChargesEventsRawParquetPath.Returns("/tmp/test-parquet");
        _chargeListReportManager.ChargesEventsRawCsvFile.Returns(csvFile);

        _realtimeChargeEventsService.BuildRealtimeFileAsync(
            Arg.Any<GenerateReportInput>(),
            Arg.Any<string>())
            .Returns(Task.FromResult(true));

        _deltaLakeManager.DownloadAsync(Arg.Any<GenerateReportInput>(), Arg.Any<string>())
            .Returns(Task.FromResult(1000L));

        _deltaLakeManager.ConvertToCsvAsync(
            Arg.Any<GenerateReportInput>(),
            Arg.Any<string>(),
            Arg.Any<string>(),
            Arg.Any<bool>(),
            Arg.Any<bool>())
            .Returns(Task.FromResult((10, 500L)));

        SetupFileSystemMocks(csvFile);

        _chargeListReportManager.When(x => x.SortEventsByChargeId(
            Arg.Any<string>(),
            Arg.Any<string>(),
            Arg.Any<DateTime>(),
            Arg.Any<int>()))
            .Do(x => throw expectedException);

        // Act & Assert
        var exception = await Assert.ThrowsAsync<Exception>(
            () => _generator.Execute(input));

        Assert.Equal(expectedException.Message, exception.Message);
        _chargeListReportManager.Received(1).Dispose();
    }

    [Fact]
    public async Task Execute_WhenUploadReportAsyncThrows_ShouldPropagateException()
    {
        // Arrange
        var input = TestDataFactory.CreateGenerateReportInput(reportType: "charges_list");
        var expectedException = new InvalidOperationException("S3 upload failed");
        var csvFile = "/tmp/test.csv";

        _chargeListReportManager.ChargesEventsRawParquetPath.Returns("/tmp/test-parquet");
        _chargeListReportManager.ChargesEventsRawCsvFile.Returns(csvFile);
        _chargeListReportManager.ChargesEventsSortedByIdCsvFile.Returns("/tmp/sorted.csv");
        _chargeListReportManager.ChargesRawCsvFile.Returns("/tmp/raw.csv");
        _chargeListReportManager.ChargesFilteredCsvFile.Returns("/tmp/filtered.csv");
        _chargeListReportManager.ChargesSortedByCreatedAtCsvFile.Returns("/tmp/sorted-created.csv");

        SetupSuccessfulDataProcessing(input);
        SetupFileSystemMocks(csvFile);

        _s3ClientWrapper.UploadReportAsync(
            Arg.Any<string>(),
            Arg.Any<string>(),
            Arg.Any<string>(),
            Arg.Any<DateTime>(),
            Arg.Any<string?>())
            .Throws(expectedException);

        // Act & Assert
        var exception = await Assert.ThrowsAsync<InvalidOperationException>(
            () => _generator.Execute(input));

        Assert.Equal(expectedException.Message, exception.Message);
        _chargeListReportManager.Received(1).Dispose();
    }

    #endregion

    #region Edge Cases - Cancellation

    [Fact]
    public async Task Execute_WhenCancellationRequested_ShouldThrowOperationCanceledException()
    {
        // Arrange
        using var cts = new CancellationTokenSource();
        cts.Cancel();
        var input = TestDataFactory.CreateGenerateReportInput(
            reportType: "charges_list",
            cancellationToken: cts.Token);

        _chargeListReportManager.ChargesEventsRawParquetPath.Returns("/tmp/test-parquet");

        _realtimeChargeEventsService.BuildRealtimeFileAsync(
            Arg.Any<GenerateReportInput>(),
            Arg.Any<string>())
            .Returns(Task.FromResult(true));

        _deltaLakeManager.DownloadAsync(Arg.Any<GenerateReportInput>(), Arg.Any<string>())
            .Returns(Task.FromResult(1000L));

        _deltaLakeManager.ConvertToCsvAsync(
            Arg.Any<GenerateReportInput>(),
            Arg.Any<string>(),
            Arg.Any<string>(),
            Arg.Any<bool>(),
            Arg.Any<bool>())
            .Throws(new OperationCanceledException("Operation was canceled"));

        // Act & Assert
        await Assert.ThrowsAsync<OperationCanceledException>(
            () => _generator.Execute(input));

        _chargeListReportManager.Received(1).Dispose();
    }

    #endregion

    #region Edge Cases - File Cleanup

    [Fact]
    public async Task Execute_ShouldDeleteIntermediateFiles()
    {
        // Arrange
        var input = TestDataFactory.CreateGenerateReportInput(reportType: "charges_list");
        var csvFile = "/tmp/test.csv";

        _chargeListReportManager.ChargesEventsRawParquetPath.Returns("/tmp/test-parquet");
        _chargeListReportManager.ChargesEventsRawCsvFile.Returns(csvFile);
        _chargeListReportManager.ChargesEventsSortedByIdCsvFile.Returns("/tmp/sorted.csv");
        _chargeListReportManager.ChargesRawCsvFile.Returns("/tmp/raw.csv");
        _chargeListReportManager.ChargesFilteredCsvFile.Returns("/tmp/filtered.csv");
        _chargeListReportManager.ChargesSortedByCreatedAtCsvFile.Returns("/tmp/sorted-created.csv");

        SetupSuccessfulExecution(input);

        // Act
        await _generator.Execute(input);

        // Assert - Verify cleanup calls
        _chargeListReportManager.Received(1).TryDeleteParquetPath();
        _chargeListReportManager.Received(1).TryDeleteFile(csvFile);
        _chargeListReportManager.Received(1).TryDeleteFile("/tmp/sorted.csv");
        _chargeListReportManager.Received(1).TryDeleteFile("/tmp/raw.csv");
        _chargeListReportManager.Received(1).TryDeleteFile("/tmp/filtered.csv");
    }

    [Fact]
    public async Task Execute_WhenExceptionOccurs_ShouldStillCallDispose()
    {
        // Arrange
        var input = TestDataFactory.CreateGenerateReportInput(reportType: "charges_list");

        _chargeListReportManager.ChargesEventsRawParquetPath.Returns("/tmp/test-parquet");

        _realtimeChargeEventsService.BuildRealtimeFileAsync(
            Arg.Any<GenerateReportInput>(),
            Arg.Any<string>())
            .Throws(new InvalidOperationException("Test exception"));

        // Act & Assert
        await Assert.ThrowsAsync<InvalidOperationException>(
            () => _generator.Execute(input));

        // Verify Dispose was called in finally block
        _chargeListReportManager.Received(1).Dispose();
    }

    #endregion

    #region Integration - Complete Flow Validation

    [Fact]
    public async Task Execute_CompleteFlow_ShouldExecuteAllStepsInCorrectOrder()
    {
        // Arrange
        var input = TestDataFactory.CreateGenerateReportInput(reportType: "charges_list");

        // Set StartDate = PartitionDate to ensure header upload happens
        input.ReportMetadata.ChargeReportParameters!.StartDate = input.PartitionDate;

        var callOrder = new List<string>();
        var csvFile = "/tmp/test.csv";

        _chargeListReportManager.ChargesEventsRawParquetPath.Returns("/tmp/test-parquet");
        _chargeListReportManager.ChargesEventsRawCsvFile.Returns(csvFile);
        _chargeListReportManager.ChargesEventsSortedByIdCsvFile.Returns("/tmp/sorted.csv");
        _chargeListReportManager.ChargesRawCsvFile.Returns("/tmp/raw.csv");
        _chargeListReportManager.ChargesFilteredCsvFile.Returns("/tmp/filtered.csv");
        _chargeListReportManager.ChargesSortedByCreatedAtCsvFile.Returns("/tmp/sorted-created.csv");

        _realtimeChargeEventsService.BuildRealtimeFileAsync(
            Arg.Any<GenerateReportInput>(),
            Arg.Any<string>())
            .Returns(callInfo =>
            {
                callOrder.Add("BuildRealtimeFile");
                return Task.FromResult(true);
            });

        _s3ClientWrapper.UploadReportHeaderAsync(Arg.Any<string>(), Arg.Any<string>())
            .Returns(callInfo =>
            {
                callOrder.Add("UploadHeader");
                return Task.CompletedTask;
            });

        _deltaLakeManager.DownloadAsync(Arg.Any<GenerateReportInput>(), Arg.Any<string>())
            .Returns(callInfo =>
            {
                callOrder.Add("Download");
                return Task.FromResult(1000L);
            });

        _deltaLakeManager.ConvertToCsvAsync(
            Arg.Any<GenerateReportInput>(),
            Arg.Any<string>(),
            Arg.Any<string>(),
            Arg.Any<bool>(),
            Arg.Any<bool>())
            .Returns(callInfo =>
            {
                callOrder.Add("ConvertToCsv");
                return Task.FromResult((10, 500L));
            });

        SetupFileSystemMocks(csvFile);

        _chargeListReportManager.When(x => x.TryDeleteParquetPath())
            .Do(x => callOrder.Add("DeleteParquet"));

        _chargeListReportManager.When(x => x.SortEventsByChargeId(
            Arg.Any<string>(),
            Arg.Any<string>(),
            Arg.Any<DateTime>(),
            Arg.Any<int>()))
            .Do(x => callOrder.Add("SortEventsByChargeId"));

        _chargeListReportManager.When(x => x.SortChargesByCreatedAt(
            Arg.Any<string>(),
            Arg.Any<string>(),
            Arg.Any<DateTime>(),
            Arg.Any<string>(),
            Arg.Any<int>(),
            Arg.Any<char>()))
            .Do(x => callOrder.Add("SortChargesByCreatedAt"));

        _s3ClientWrapper.UploadReportAsync(
            Arg.Any<string>(),
            Arg.Any<string>(),
            Arg.Any<string>(),
            Arg.Any<DateTime>(),
            Arg.Any<string?>())
            .Returns(callInfo =>
            {
                callOrder.Add("UploadReport");
                return Task.CompletedTask;
            });

        // Act
        await _generator.Execute(input);

        // Assert - Verify execution order
        // Note: BuildRealtimeFile runs async and may complete at different times
        // The important order is: Download -> ConvertToCsv -> DeleteParquet -> Sort -> Filter -> Sort -> Upload
        Assert.Contains("BuildRealtimeFile", callOrder);
        Assert.Contains("Download", callOrder);
        Assert.Contains("ConvertToCsv", callOrder);
        Assert.Contains("DeleteParquet", callOrder);
        Assert.Contains("SortEventsByChargeId", callOrder);
        // Assert.Contains("FilterCharges", callOrder);
        Assert.Contains("SortChargesByCreatedAt", callOrder);
        Assert.Contains("UploadReport", callOrder);

        // Verify the synchronous order (after ConvertToCsv)
        var convertIndex = callOrder.IndexOf("ConvertToCsv");
        var deleteIndex = callOrder.IndexOf("DeleteParquet");
        var sortEventsIndex = callOrder.IndexOf("SortEventsByChargeId");
        var sortChargesIndex = callOrder.IndexOf("SortChargesByCreatedAt");
        var uploadIndex = callOrder.IndexOf("UploadReport");

        Assert.True(convertIndex < deleteIndex, "ConvertToCsv should happen before DeleteParquet");
        Assert.True(deleteIndex < sortEventsIndex, "DeleteParquet should happen before SortEventsByChargeId");
        Assert.True(sortEventsIndex < sortChargesIndex, "SortEventsByChargeId should happen before SortChargesByCreatedAt");
        Assert.True(sortChargesIndex < uploadIndex, "SortChargesByCreatedAt should happen before UploadReport");
    }

    #endregion

    #region Helper Methods

    /// <summary>
    /// Sets up mocks for a successful execution flow
    /// </summary>
    private void SetupSuccessfulExecution(GenerateReportInput input)
    {
        var csvFile = "/tmp/test.csv";

        _chargeListReportManager.ChargesEventsRawParquetPath.Returns("/tmp/test-parquet");
        _chargeListReportManager.ChargesEventsRawCsvFile.Returns(csvFile);
        _chargeListReportManager.ChargesEventsSortedByIdCsvFile.Returns("/tmp/sorted.csv");
        _chargeListReportManager.ChargesRawCsvFile.Returns("/tmp/raw.csv");
        _chargeListReportManager.ChargesFilteredCsvFile.Returns("/tmp/filtered.csv");
        _chargeListReportManager.ChargesSortedByCreatedAtCsvFile.Returns("/tmp/sorted-created.csv");

        SetupSuccessfulDataProcessing(input);
        SetupFileSystemMocks(csvFile);
    }

    /// <summary>
    /// Sets up mocks for successful data processing (download, convert, etc.)
    /// </summary>
    private void SetupSuccessfulDataProcessing(GenerateReportInput input)
    {
        _realtimeChargeEventsService.BuildRealtimeFileAsync(
            Arg.Any<GenerateReportInput>(),
            Arg.Any<string>())
            .Returns(Task.FromResult(true));

        _deltaLakeManager.DownloadAsync(Arg.Any<GenerateReportInput>(), Arg.Any<string>())
            .Returns(Task.FromResult(1000L));

        _deltaLakeManager.ConvertToCsvAsync(
            Arg.Any<GenerateReportInput>(),
            Arg.Any<string>(),
            Arg.Any<string>(),
            Arg.Any<bool>(),
            Arg.Any<bool>())
            .Returns(Task.FromResult((10, 500L)));

        _s3ClientWrapper.UploadReportHeaderAsync(Arg.Any<string>(), Arg.Any<string>())
            .Returns(Task.CompletedTask);

        _s3ClientWrapper.UploadReportAsync(
            Arg.Any<string>(),
            Arg.Any<string>(),
            Arg.Any<string>(),
            Arg.Any<DateTime>(),
            Arg.Any<string?>())
            .Returns(Task.CompletedTask);
    }

    /// <summary>
    /// Sets up file system mocks for CSV processing
    /// </summary>
    private void SetupFileSystemMocks(string csvFile)
    {
        // Create actual temporary CSV file with header for CsvHelper.GetHeader to read
        var directory = Path.GetDirectoryName(csvFile);
        if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
        {
            Directory.CreateDirectory(directory);
        }

        // Write a simple CSV header to the file
        File.WriteAllText(csvFile, "header1,header2,header3\n");

        // Mock file streams for ChargeListReportService.ProcessAsync
        var sortedCsvFile = "/tmp/sorted.csv";
        var rawCsvFile = "/tmp/raw.csv";

        File.WriteAllText(sortedCsvFile, "header1,header2,header3\n");
        File.WriteAllText(rawCsvFile, "");
    }

    #endregion
}

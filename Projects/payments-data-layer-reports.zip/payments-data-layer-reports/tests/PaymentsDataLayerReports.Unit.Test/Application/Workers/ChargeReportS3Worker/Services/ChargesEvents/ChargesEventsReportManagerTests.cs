using Microsoft.Extensions.Options;
using NSubstitute;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.ChargesEvents;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.ChargeReportS3Worker.Services.ChargesEvents;

public class ChargesEventsReportManagerTests : IDisposable
{
    private readonly List<string> _tempDirsToCleanup = [];

    private static ChargeEventsReportManager CreateManager()
    {
        var settings = Substitute.For<IOptions<DataLayerReportsSettings>>();
        settings.Value.Returns(new DataLayerReportsSettings { BashPath = "/bin/bash" });
        return new ChargeEventsReportManager(settings);
    }

    [Fact]
    public void SortChargesEvents_WithDuplicateEventIds_ShouldKeepMostRecentProcessedAt()
    {
        // Arrange
        using var manager = CreateManager();
        _tempDirsToCleanup.Add(manager.ChargesEventsRawParquetPath);

        // IMPORTANT: the row with NEWER processed_at has OLDER event_datetime to prove
        // that processed_at takes priority over event_datetime in the dedup sort.
        var csvContent = @"event_datetime,event_id,id,processed_at
2024-01-15 11:00:00.000 UTC,event-1,charge-1,2026-01-01 10:00:00.000 UTC
2024-01-15 10:30:00.000 UTC,event-1,charge-1,2026-03-30 01:52:43.300 UTC
2024-01-15 09:00:00.000 UTC,event-2,charge-2,2026-03-30 01:00:00.000 UTC";
        File.WriteAllText(manager.ChargesEventsRawCsvFile, csvContent);

        // Act - processedAtColumnPosition=4, columnCountWithoutProcessedAt=3
        manager.SortChargesEventsByIdAndEventDatetimeDesc("job", "report", DateTime.Today, 4, 3);

        // Assert
        var sortedLines = File.ReadAllLines(manager.ChargesEventsSortedByEventIdAndEventDatetimeDescCsvFile);
        Assert.Equal(2, sortedLines.Length);

        // event-1 should keep the row with most recent processed_at (2026-03-30),
        // even though its event_datetime (10:30) is older
        var event1Line = sortedLines.First(l => l.Contains("event-1"));
        Assert.Contains("2024-01-15 10:30:00.000 UTC", event1Line);
    }

    [Fact]
    public void SortChargesEvents_ShouldStripProcessedAtColumn()
    {
        // Arrange
        using var manager = CreateManager();
        _tempDirsToCleanup.Add(manager.ChargesEventsRawParquetPath);

        var csvContent = @"event_datetime,event_id,id,processed_at
2024-01-15 11:00:00.000 UTC,event-1,charge-1,2026-03-30 01:52:43.300 UTC
2024-01-15 10:00:00.000 UTC,event-2,charge-2,2026-03-30 01:00:00.000 UTC";
        File.WriteAllText(manager.ChargesEventsRawCsvFile, csvContent);

        // Act - 4 columns total, strip to 3
        manager.SortChargesEventsByIdAndEventDatetimeDesc("job", "report", DateTime.Today, 4, 3);

        // Assert - each output line should have exactly 3 columns (no processed_at)
        var sortedLines = File.ReadAllLines(manager.ChargesEventsSortedByEventIdAndEventDatetimeDescCsvFile);
        Assert.Equal(2, sortedLines.Length);
        foreach (var line in sortedLines)
        {
            var columnCount = line.Split(',').Length;
            Assert.Equal(3, columnCount);
            // processed_at values must not appear in output
            Assert.DoesNotContain("2026-03-30", line);
            Assert.DoesNotContain("2026-01-01", line);
        }
    }

    [Fact]
    public void SortChargesEvents_OutputShouldBeSortedByEventDatetimeDesc()
    {
        // Arrange
        using var manager = CreateManager();
        _tempDirsToCleanup.Add(manager.ChargesEventsRawParquetPath);

        // Input deliberately NOT in event_datetime order
        var csvContent = @"event_datetime,event_id,id,processed_at
2024-01-15 09:00:00.000 UTC,event-1,charge-1,2026-03-30 01:00:00.000 UTC
2024-01-15 11:00:00.000 UTC,event-3,charge-3,2026-03-30 01:00:00.000 UTC
2024-01-15 10:00:00.000 UTC,event-2,charge-2,2026-03-30 01:00:00.000 UTC";
        File.WriteAllText(manager.ChargesEventsRawCsvFile, csvContent);

        // Act
        manager.SortChargesEventsByIdAndEventDatetimeDesc("job", "report", DateTime.Today, 4, 3);

        // Assert - output should be sorted by event_datetime descending
        var sortedLines = File.ReadAllLines(manager.ChargesEventsSortedByEventIdAndEventDatetimeDescCsvFile);
        Assert.Equal(3, sortedLines.Length);

        // Extract event_datetime (first column) from each line
        var eventDatetimes = sortedLines.Select(l => l.Split(',')[0]).ToList();
        Assert.Equal("2024-01-15 11:00:00.000 UTC", eventDatetimes[0]);
        Assert.Equal("2024-01-15 10:00:00.000 UTC", eventDatetimes[1]);
        Assert.Equal("2024-01-15 09:00:00.000 UTC", eventDatetimes[2]);
    }

    [Fact]
    public void SortChargesEvents_WithEmptyProcessedAt_ShouldPreferFilledProcessedAt()
    {
        // Arrange
        using var manager = CreateManager();
        _tempDirsToCleanup.Add(manager.ChargesEventsRawParquetPath);

        // event-1 appears twice: one with filled processed_at (older event_datetime),
        // one with empty processed_at (newer event_datetime).
        // The filled one should win despite having an older event_datetime.
        var csvContent = @"event_datetime,event_id,id,processed_at
2024-01-15 11:00:00.000 UTC,event-1,charge-1,
2024-01-15 10:30:00.000 UTC,event-1,charge-1,2026-01-01 10:00:00.000 UTC
2024-01-15 09:00:00.000 UTC,event-2,charge-2,";
        File.WriteAllText(manager.ChargesEventsRawCsvFile, csvContent);

        // Act
        manager.SortChargesEventsByIdAndEventDatetimeDesc("job", "report", DateTime.Today, 4, 3);

        // Assert
        var sortedLines = File.ReadAllLines(manager.ChargesEventsSortedByEventIdAndEventDatetimeDescCsvFile);
        Assert.Equal(2, sortedLines.Length);

        // event-1 should keep the row with filled processed_at (event_datetime 10:30)
        var event1Line = sortedLines.First(l => l.Contains("event-1"));
        Assert.Contains("2024-01-15 10:30:00.000 UTC", event1Line);
    }

    public void Dispose()
    {
        foreach (var dir in _tempDirsToCleanup)
        {
            try { if (Directory.Exists(dir)) Directory.Delete(dir, true); } catch { }
        }
    }
}

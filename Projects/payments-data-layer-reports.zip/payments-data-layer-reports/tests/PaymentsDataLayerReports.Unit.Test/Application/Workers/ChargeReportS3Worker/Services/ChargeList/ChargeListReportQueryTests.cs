

using NSubstitute;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Services.DeltaTableColumnMapping;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.ChargeList;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.ChargeReportS3Worker.Services.ChargeList;

public class ChargeListReportQueryTests : IDisposable
{
    private readonly IColumnMappingService _columnMappingService;
    private readonly List<string> _allowedCategoriesList = ["sale", "reversal", "partial_reversal", "refund_reversal", "antecipacao"];
    private string? _tempInputPath;
    private string? _tempOutputPath;

    public ChargeListReportQueryTests()
    {
        _columnMappingService = Substitute.For<IColumnMappingService>();
    }

    public void Dispose()
    {
        TestDataFactory.CleanupTestFiles(_tempInputPath, _tempOutputPath);
        GC.SuppressFinalize(this);
    }

    #region SelectChargesEventsAsync - Success Scenarios

    [Fact]
    public async Task SelectChargesEventsAsync_WithParquetDataOnly_ShouldGenerateValidQuery()
    {
        // Arrange
        _tempInputPath = TestDataFactory.CreateTempDirectory();
        _tempOutputPath = Path.Combine(Path.GetTempPath(), $"output-{Guid.NewGuid()}.csv");

        var reportInput = TestDataFactory.CreateGenerateReportInput();
        SetupColumnMappingMocks();
        CreateParquetTestFiles("charges_events_by_created_at");

        // Act
        var query = await ChargeListReportQuery.SelectChargesEventsAsync(
            _tempInputPath, _tempOutputPath, reportInput, false, true, _columnMappingService, _allowedCategoriesList);

        // Assert
        Assert.NotNull(query);
        Assert.Contains("COPY", query);
        Assert.Contains("read_parquet", query);
        Assert.DoesNotContain("read_csv", query);
        Assert.Contains("created_at::TIMESTAMPTZ", query);
    }

    [Fact]
    public async Task SelectChargesEventsAsync_WithRealTimeDataOnly_ShouldGenerateValidQuery()
    {
        // Arrange
        _tempInputPath = TestDataFactory.CreateTempDirectory();
        _tempOutputPath = Path.Combine(Path.GetTempPath(), $"output-{Guid.NewGuid()}.csv");
        var reportInput = TestDataFactory.CreateGenerateReportInput();

        // Act
        var query = await ChargeListReportQuery.SelectChargesEventsAsync(
            _tempInputPath, _tempOutputPath, reportInput, true, false, _columnMappingService, _allowedCategoriesList);

        // Assert
        Assert.NotNull(query);
        Assert.Contains("read_csv", query);
        Assert.DoesNotContain("read_parquet", query);
    }

    [Fact]
    public async Task SelectChargesEventsAsync_WithBothDataSources_ShouldGenerateUnionQuery()
    {
        // Arrange
        _tempInputPath = TestDataFactory.CreateTempDirectory();
        _tempOutputPath = Path.Combine(Path.GetTempPath(), $"output-{Guid.NewGuid()}.csv");
        var reportInput = TestDataFactory.CreateGenerateReportInput();
        SetupColumnMappingMocks();
        CreateParquetTestFiles("charges_events_by_created_at");

        // Act
        var query = await ChargeListReportQuery.SelectChargesEventsAsync(
            _tempInputPath, _tempOutputPath, reportInput, true, true, _columnMappingService, _allowedCategoriesList);

        // Assert
        Assert.Contains("UNION ALL", query);
        Assert.Contains("read_parquet", query);
        Assert.Contains("read_csv", query);
    }

    #endregion

    #region SelectChargesEventsAsync - Filter Tests

    [Theory]
    [InlineData("document", "merchant__document")]
    [InlineData("merchant_id", "merchant__merchant_id")]
    public async Task SelectChargesEventsAsync_WithPartitionType_ShouldGenerateCorrectFilter(
        string partitionType, string expectedField)
    {
        // Arrange
        _tempInputPath = TestDataFactory.CreateTempDirectory();
        _tempOutputPath = Path.Combine(Path.GetTempPath(), $"output-{Guid.NewGuid()}.csv");
        var partitionSet = TestDataFactory.CreateValidPartitionSet(
            partitionIdReferenceType: partitionType);
        var reportInput = TestDataFactory.CreateGenerateReportInput(partitionSet: partitionSet);

        // Act
        var query = await ChargeListReportQuery.SelectChargesEventsAsync(
            _tempInputPath, _tempOutputPath, reportInput, true, false, _columnMappingService, _allowedCategoriesList);

        // Assert
        Assert.Contains(expectedField, query);
        Assert.Contains("IN (", query);
    }

    [Fact]
    public async Task SelectChargesEventsAsync_WithAccountId_ShouldIncludeAccountIdFilter()
    {
        // Arrange
        _tempInputPath = TestDataFactory.CreateTempDirectory();
        _tempOutputPath = Path.Combine(Path.GetTempPath(), $"output-{Guid.NewGuid()}.csv");
        var reportInput = TestDataFactory.CreateGenerateReportInput(accountId: "acc-123,acc-456");

        // Act
        var query = await ChargeListReportQuery.SelectChargesEventsAsync(
            _tempInputPath, _tempOutputPath, reportInput, true, false, _columnMappingService, _allowedCategoriesList);

        // Assert
        Assert.Contains("merchant__account_id", query);
        Assert.Contains("'acc-123'", query);
        Assert.Contains("'acc-456'", query);
    }

    [Fact]
    public async Task SelectChargesEventsAsync_WithIsSandbox_ShouldIncludeSandboxFilter()
    {
        // Arrange
        _tempInputPath = TestDataFactory.CreateTempDirectory();
        _tempOutputPath = Path.Combine(Path.GetTempPath(), $"output-{Guid.NewGuid()}.csv");
        var reportInput = TestDataFactory.CreateGenerateReportInput();
        reportInput.ReportMetadata.ChargeReportParameters!.IsSandbox = true;
        SetupColumnMappingMocks();
        CreateParquetTestFiles("charges_events_by_created_at");

        // Act
        var query = await ChargeListReportQuery.SelectChargesEventsAsync(
            _tempInputPath, _tempOutputPath, reportInput, false, true, _columnMappingService, _allowedCategoriesList);

        // Assert
        Assert.Contains("merchant__is_sandbox = true", query);
    }

    [Fact]
    public async Task SelectChargesEventsAsync_WithPaymentMethods_ShouldIncludePaymentMethodFilter()
    {
        // Arrange
        _tempInputPath = TestDataFactory.CreateTempDirectory();
        _tempOutputPath = Path.Combine(Path.GetTempPath(), $"output-{Guid.NewGuid()}.csv");
        var reportInput = TestDataFactory.CreateGenerateReportInput(paymentMethods: "credit_card,pix");

        // Act
        var query = await ChargeListReportQuery.SelectChargesEventsAsync(
            _tempInputPath, _tempOutputPath, reportInput, true, false, _columnMappingService, _allowedCategoriesList);

        // Assert
        Assert.Contains("payment_method", query);
        Assert.Contains("'credit_card'", query);
        Assert.Contains("'pix'", query);
    }

    [Fact]
    public async Task SelectChargesEventsAsync_ShouldIncludeFinancialMovementCategoryFilter()
    {
        // Arrange
        _tempInputPath = TestDataFactory.CreateTempDirectory();
        _tempOutputPath = Path.Combine(Path.GetTempPath(), $"output-{Guid.NewGuid()}.csv");
        var reportInput = TestDataFactory.CreateGenerateReportInput();

        // Act
        var query = await ChargeListReportQuery.SelectChargesEventsAsync(
            _tempInputPath, _tempOutputPath, reportInput, true, false, _columnMappingService, _allowedCategoriesList);

        // Assert
        Assert.Contains("card_transaction__financial_movement__category", query);
        Assert.Contains("boleto_transaction__financial_movement__category", query);
        Assert.Contains("pix_transaction__financial_movement__category", query);
        Assert.Contains("'sale'", query);
        Assert.Contains("'reversal'", query);
        Assert.Contains("'antecipacao'", query);
    }

    [Fact]
    public async Task SelectChargesEventsAsync_WithEmptyAllowedCategories_ShouldOmitCategoryFilter()
    {
        // Arrange
        _tempInputPath = TestDataFactory.CreateTempDirectory();
        _tempOutputPath = Path.Combine(Path.GetTempPath(), $"output-{Guid.NewGuid()}.csv");
        var reportInput = TestDataFactory.CreateGenerateReportInput();

        // Act
        var query = await ChargeListReportQuery.SelectChargesEventsAsync(
            _tempInputPath, _tempOutputPath, reportInput, true, false, _columnMappingService, []);

        // Assert
        Assert.DoesNotContain("financial_movement__category IS NULL", query);
        Assert.DoesNotContain("financial_movement__category IN", query);
    }

    #endregion

    #region FilterCharges - Success Scenarios

    [Fact]
    public void FilterCharges_WithBasicParameters_ShouldGenerateValidQuery()
    {
        // Arrange
        var chargeParameters = TestDataFactory.CreateChargeReportsWorkerParameters();

        // Act
        var query = ChargeListReportQuery.FilterCharges("/tmp/input.csv", "/tmp/output.csv", chargeParameters);

        // Assert
        Assert.Contains("COPY", query);
        Assert.Contains("read_csv", query);
        Assert.Contains("status IS NOT NULL", query);
        Assert.Contains("status <> 'failed'", query);
    }

    [Fact]
    public void FilterCharges_WithWithFailedTrue_ShouldNotFilterFailedStatus()
    {
        // Arrange
        var chargeParameters = TestDataFactory.CreateChargeReportsWorkerParameters(withFailed: true);

        // Act
        var query = ChargeListReportQuery.FilterCharges("/tmp/input.csv", "/tmp/output.csv", chargeParameters);

        // Assert
        Assert.DoesNotContain("status <> 'failed'", query);
    }

    [Fact]
    public void FilterCharges_WithAllIds_ShouldIncludeAllIdsFilter()
    {
        // Arrange
        var chargeParameters = TestDataFactory.CreateChargeReportsWorkerParameters(allIds: "id1,id2");

        // Act
        var query = ChargeListReportQuery.FilterCharges("/tmp/input.csv", "/tmp/output.csv", chargeParameters);

        // Assert
        Assert.Contains("all_ids IN (", query);
        Assert.Contains("'id1'", query);
        Assert.Contains("'id2'", query);
    }

    [Fact]
    public void FilterCharges_WithLastOperationStatus_ShouldIncludeAllPaymentMethods()
    {
        // Arrange
        var chargeParameters = TestDataFactory.CreateChargeReportsWorkerParameters(lastOperationStatus: "approved,denied");

        // Act
        var query = ChargeListReportQuery.FilterCharges("/tmp/input.csv", "/tmp/output.csv", chargeParameters);

        // Assert
        Assert.Contains("card_transaction__last__operation_status IN (", query);
        Assert.Contains("boleto_transaction__last__operation_status IN (", query);
        Assert.Contains("pix_transaction__last__operation_status IN (", query);
        Assert.Contains("cash_transaction__last__operation_status IN (", query);
    }

    [Fact]
    public void FilterCharges_WithAmountRange_ShouldIncludeAmountFilters()
    {
        // Arrange
        var chargeParameters = TestDataFactory.CreateChargeReportsWorkerParameters(minAmount: 1000, maxAmount: 50000);

        // Act
        var query = ChargeListReportQuery.FilterCharges("/tmp/input.csv", "/tmp/output.csv", chargeParameters);

        // Assert
        Assert.Contains("amount >= 1000", query);
        Assert.Contains("amount <= 50000", query);
    }

    [Fact]
    public void FilterCharges_WithCustomers_ShouldIncludeMultipleCustomerFields()
    {
        // Arrange
        var chargeParameters = TestDataFactory.CreateChargeReportsWorkerParameters(customers: "John Doe,12345");

        // Act
        var query = ChargeListReportQuery.FilterCharges("/tmp/input.csv", "/tmp/output.csv", chargeParameters);

        // Assert
        Assert.Contains("pix_transaction__customer__name IN (", query);
        Assert.Contains("boleto_transaction__customer__name IN (", query);
        Assert.Contains("card_transaction__customer__name IN (", query);
        Assert.Contains("cash_transaction__customer__name IN (", query);
        Assert.Contains("'John Doe'", query);
        Assert.Contains("'12345'", query);
    }

    #endregion

    #region Edge Cases

    [Fact]
    public async Task SelectChargesEventsAsync_WithInvalidPartitionType_ShouldThrowException()
    {
        // Arrange
        _tempInputPath = TestDataFactory.CreateTempDirectory();
        _tempOutputPath = Path.Combine(Path.GetTempPath(), $"output-{Guid.NewGuid()}.csv");
        var partitionSet = TestDataFactory.CreateValidPartitionSet(
            partitionIdReferenceType: "invalid_type");
        var reportInput = TestDataFactory.CreateGenerateReportInput(partitionSet: partitionSet);

        // Act & Assert
        await Assert.ThrowsAsync<InvalidOperationException>(() =>
            ChargeListReportQuery.SelectChargesEventsAsync(
                _tempInputPath, _tempOutputPath, reportInput, true, false, _columnMappingService, _allowedCategoriesList));
    }

    [Fact]
    public async Task SelectChargesEventsAsync_WithNoParquetFiles_ShouldSkipTable()
    {
        // Arrange
        _tempInputPath = TestDataFactory.CreateTempDirectory();
        _tempOutputPath = Path.Combine(Path.GetTempPath(), $"output-{Guid.NewGuid()}.csv");
        var reportInput = TestDataFactory.CreateGenerateReportInput();
        Directory.CreateDirectory(Path.Combine(_tempInputPath, "charges_events_by_created_at"));

        // Act
        var query = await ChargeListReportQuery.SelectChargesEventsAsync(
            _tempInputPath, _tempOutputPath, reportInput, false, true, _columnMappingService, _allowedCategoriesList);

        // Assert
        Assert.NotNull(query);
        Assert.Contains("COPY", query);
    }

    #endregion

    #region Helper Methods

    private void SetupColumnMappingMocks()
    {
        var columnMapping = new ColumnMapping
        {
            ColumnMappings = new Dictionary<string, string>()
        };
        var columnMappingTask = Task.FromResult<ColumnMapping?>(columnMapping);
        _columnMappingService.GetColumnMappingAsync(Arg.Any<string>())
            .Returns(columnMappingTask);

        var nullClauses = new List<string> { "NULL AS event_id" };
        var nullClausesTask = Task.FromResult<IEnumerable<string>>(nullClauses);
        _columnMappingService.GenerateNullClausesAsync(Arg.Any<string>(), Arg.Any<IEnumerable<DeltaTableColumnModel>>())
            .Returns(nullClausesTask);

        var sqlColumns = new List<string> { "event_id", "amount" };
        var sqlColumnsTask = Task.FromResult<IEnumerable<string>>(sqlColumns);
        _columnMappingService.GenerateSqlColumnsAsync(Arg.Any<string>(), Arg.Any<IEnumerable<DeltaTableColumnModel>>())
            .Returns(sqlColumnsTask);
    }

    private void CreateParquetTestFiles(string tableName)
    {
        var tableDir = Path.Combine(_tempInputPath!, tableName);
        Directory.CreateDirectory(tableDir);
        File.WriteAllText(Path.Combine(tableDir, "test.parquet"), "dummy");
    }

    #endregion
}

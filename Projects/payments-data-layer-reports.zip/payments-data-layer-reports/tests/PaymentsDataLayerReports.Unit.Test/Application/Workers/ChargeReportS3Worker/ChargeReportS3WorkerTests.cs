using Hangfire;
using Hangfire.Common;
using Hangfire.Server;
using Hangfire.Storage;
using NSubstitute;
using NSubstitute.ExceptionExtensions;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Exceptions;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Services.DeltaTablePartitionBuilder;
using PaymentsDataLayerReports.Application.Services.IdempotentJobManager;
using PaymentsDataLayerReports.Application.Types;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.Models;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;
using PaymentsDataLayerReports.Application.Workers.ChargeReportWorker;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.ChargeReportS3Worker;

public class ChargeReportS3WorkerTests
{
    private readonly IS3ClientWrapper _s3ClientWrapper;
    private readonly IReportTypeFactory _reportTypeFactory;
    private readonly IIdempotentJobManager _idempotentJobManager;
    private readonly PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker _worker;
    private readonly PerformContext _performContext;
    private readonly CancellationToken _cancellationToken;
    private readonly IReportGenerator<GenerateReportInput> _chargeListReportGenerator;
    private readonly IReportGenerator<GenerateReportInput> _chargesEventsReportGenerator;

    public ChargeReportS3WorkerTests()
    {
        // Arrange - Setup common mocks
        _s3ClientWrapper = Substitute.For<IS3ClientWrapper>();
        _idempotentJobManager = Substitute.For<IIdempotentJobManager>();
        _chargeListReportGenerator = Substitute.For<IReportGenerator<GenerateReportInput>>();
        _chargesEventsReportGenerator = Substitute.For<IReportGenerator<GenerateReportInput>>();

        // Create a substitute for the factory
        _reportTypeFactory = Substitute.For<IReportTypeFactory>();
        // Configure factory to return our interface mocks
        _reportTypeFactory.Create<GenerateReportInput>(Arg.Is<ReportTypeEnum>(r => r.Name == "charges_list"))
            .Returns(_chargeListReportGenerator);
        _reportTypeFactory.Create<GenerateReportInput>(Arg.Is<ReportTypeEnum>(r => r.Name == "charges_events"))
            .Returns(_chargesEventsReportGenerator);

        _worker = new PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.ChargeReportS3Worker(
            _reportTypeFactory,
            _s3ClientWrapper,
            _idempotentJobManager
        );

        // Setup PerformContext mock
        var backgroundJob = Substitute.For<BackgroundJob>("test-job-id", Job.FromExpression(() => Console.WriteLine()), DateTime.UtcNow);
        _performContext = Substitute.For<PerformContext>(
            Substitute.For<IStorageConnection>(),
            backgroundJob,
            Substitute.For<IJobCancellationToken>()
        );

        _cancellationToken = CancellationToken.None;
    }

    #region Success Scenarios

    [Fact]
    public async Task ProcessReport_WithValidParameters_ShouldCompleteSuccessfully()
    {
        // Arrange
        var reportId = "test-report-123";
        var partitionDate = DateTime.Today;
        var partitionSet = CreateValidPartitionSet();
        var metadata = CreateValidReportMetadata(reportId);

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _chargeListReportGenerator.Execute(Arg.Any<GenerateReportInput>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.TriggerConcatenationJobIfFinishedAsync(reportId, metadata.ProcessorQueueName)
            .Returns(Task.CompletedTask);

        // Act
        await _worker.ProcessReport(reportId, partitionDate, partitionSet, _performContext, _cancellationToken);

        // Assert
        await _s3ClientWrapper.Received(1).GetReportMetadataAsync(reportId);
        _reportTypeFactory.Received(1).Create<GenerateReportInput>(Arg.Is<ReportTypeEnum>(rt => rt.Name == metadata.ChargeReportParameters!.ReportType));
        await _chargeListReportGenerator.Received(1).Execute(Arg.Any<GenerateReportInput>());
        await _idempotentJobManager.Received(1).TriggerConcatenationJobIfFinishedAsync(reportId, metadata.ProcessorQueueName);
    }

    [Fact]
    public async Task ProcessReport_WithValidMetadata_ShouldCreateCorrectGenerateReportInput()
    {
        // Arrange
        var reportId = "test-report-456";
        var partitionDate = DateTime.Today.AddDays(-5);
        var partitionSet = CreateValidPartitionSet();
        var metadata = CreateValidReportMetadata(reportId);
        GenerateReportInput? capturedInput = null;

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _chargeListReportGenerator.When(x => x.Execute(Arg.Any<GenerateReportInput>()))
            .Do(call => capturedInput = call.Arg<GenerateReportInput>());

        // Act
        await _worker.ProcessReport(reportId, partitionDate, partitionSet, _performContext, _cancellationToken);

        // Assert
        Assert.NotNull(capturedInput);
        Assert.Equal(partitionDate, capturedInput.PartitionDate);
        Assert.Equal(partitionSet, capturedInput.PartitionSet);
        Assert.Equal(metadata, capturedInput.ReportMetadata);
        Assert.Equal(_cancellationToken, capturedInput.CancellationToken);
        Assert.Equal("test-job-id", capturedInput.JobId);
    }

    [Fact]
    public async Task ProcessReport_WhenSuccessful_ShouldCallCorrectReportGenerator()
    {
        // Arrange
        var reportId = "test-report-789";
        var partitionDate = DateTime.Today;
        var partitionSet = CreateValidPartitionSet();
        var metadata = CreateValidReportMetadata(reportId);
        metadata.ChargeReportParameters!.ReportType = ReportTypeEnum.ChargesList.Name;

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _chargeListReportGenerator.Execute(Arg.Any<GenerateReportInput>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.TriggerConcatenationJobIfFinishedAsync(Arg.Any<string>(), Arg.Any<string>())
            .Returns(Task.CompletedTask);

        // Act
        await _worker.ProcessReport(reportId, partitionDate, partitionSet, _performContext, _cancellationToken);

        // Assert
        await _chargeListReportGenerator.Received(1).Execute(Arg.Any<GenerateReportInput>());
        await _chargesEventsReportGenerator.DidNotReceive().Execute(Arg.Any<GenerateReportInput>());
        await _idempotentJobManager.Received(1).TriggerConcatenationJobIfFinishedAsync(reportId, metadata.ProcessorQueueName);
    }

    [Fact]
    public async Task ProcessReport_WhenSuccessful_ShouldTriggerConcatenationWithCorrectParameters()
    {
        // Arrange
        var reportId = "test-report-concat";
        var partitionDate = DateTime.Today;
        var partitionSet = CreateValidPartitionSet();
        var metadata = CreateValidReportMetadata(reportId);
        var queueName = "test-queue-name";
        metadata.ProcessorQueueName = queueName;

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _chargeListReportGenerator.Execute(Arg.Any<GenerateReportInput>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.TriggerConcatenationJobIfFinishedAsync(Arg.Any<string>(), Arg.Any<string>())
            .Returns(Task.CompletedTask);

        // Act
        await _worker.ProcessReport(reportId, partitionDate, partitionSet, _performContext, _cancellationToken);

        // Assert
        await _idempotentJobManager.Received(1).TriggerConcatenationJobIfFinishedAsync(reportId, queueName);
    }

    #endregion

    #region Error Handling - ReportMetadataNotFoundException

    [Fact]
    public async Task ProcessReport_WhenMetadataNotFound_ShouldThrowReportMetadataNotFoundException()
    {
        // Arrange
        var reportId = "non-existent-report";
        var partitionDate = DateTime.Today;
        var partitionSet = CreateValidPartitionSet();

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(null));

        // Act & Assert
        var exception = await Assert.ThrowsAsync<ReportMetadataNotFoundException>(
            () => _worker.ProcessReport(reportId, partitionDate, partitionSet, _performContext, _cancellationToken));

        Assert.Contains(reportId, exception.Message);
    }


    #endregion

    #region Error Handling - GetReportMetadataAsync Failures

    [Fact]
    public async Task ProcessReport_WhenGetMetadataThrowsException_ShouldPropagateException()
    {
        // Arrange
        var reportId = "test-report-s3-fail";
        var partitionDate = DateTime.Today;
        var partitionSet = CreateValidPartitionSet();
        var expectedException = new InvalidOperationException("S3 connection failed");

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Throws(expectedException);

        // Act & Assert
        var exception = await Assert.ThrowsAsync<InvalidOperationException>(
            () => _worker.ProcessReport(reportId, partitionDate, partitionSet, _performContext, _cancellationToken));

        Assert.Equal(expectedException.Message, exception.Message);
    }


    #endregion

    #region Error Handling - ReportTypeFactory Failures

    [Fact]
    public async Task ProcessReport_WhenReportTypeFactoryThrowsException_ShouldPropagateException()
    {
        // Arrange
        var reportId = "test-report-factory-fail";
        var partitionDate = DateTime.Today;
        var partitionSet = CreateValidPartitionSet();
        var metadata = CreateValidReportMetadata(reportId);
        var expectedException = new ArgumentException("Invalid report type");

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _reportTypeFactory.Create<GenerateReportInput>(Arg.Any<ReportTypeEnum>())
            .Throws(expectedException);

        // Act & Assert
        var exception = await Assert.ThrowsAsync<ArgumentException>(
            () => _worker.ProcessReport(reportId, partitionDate, partitionSet, _performContext, _cancellationToken));

        Assert.Equal(expectedException.Message, exception.Message);
    }


    #endregion

    #region Error Handling - ReportGenerator Execution Failures

    [Fact]
    public async Task ProcessReport_WhenReportGeneratorFails_ShouldPropagateException()
    {
        // Arrange
        var reportId = "test-report-generator-fail";
        var partitionDate = DateTime.Today;
        var partitionSet = CreateValidPartitionSet();
        var metadata = CreateValidReportMetadata(reportId);
        var expectedException = new InvalidOperationException("Report generation failed");

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _chargeListReportGenerator.Execute(Arg.Any<GenerateReportInput>())
            .Throws(expectedException);

        // Act & Assert
        var exception = await Assert.ThrowsAsync<InvalidOperationException>(
            () => _worker.ProcessReport(reportId, partitionDate, partitionSet, _performContext, _cancellationToken));

        Assert.Equal(expectedException.Message, exception.Message);
    }

    [Fact]
    public async Task ProcessReport_WhenReportGeneratorFails_ShouldNotTriggerConcatenation()
    {
        // Arrange
        var reportId = "test-report-generator-fail-2";
        var partitionDate = DateTime.Today;
        var partitionSet = CreateValidPartitionSet();
        var metadata = CreateValidReportMetadata(reportId);

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _chargeListReportGenerator.Execute(Arg.Any<GenerateReportInput>())
            .Throws(new InvalidOperationException("Report generation failed"));

        // Act & Assert
        await Assert.ThrowsAsync<InvalidOperationException>(
            () => _worker.ProcessReport(reportId, partitionDate, partitionSet, _performContext, _cancellationToken));

        await _idempotentJobManager.DidNotReceive().TriggerConcatenationJobIfFinishedAsync(
            Arg.Any<string>(),
            Arg.Any<string>());
    }


    #endregion

    #region Error Handling - TriggerConcatenationJobIfFinishedAsync Failures

    [Fact]
    public async Task ProcessReport_WhenTriggerConcatenationFails_ShouldPropagateException()
    {
        // Arrange
        var reportId = "test-report-concat-fail";
        var partitionDate = DateTime.Today;
        var partitionSet = CreateValidPartitionSet();
        var metadata = CreateValidReportMetadata(reportId);
        var expectedException = new InvalidOperationException("Redis connection failed");

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _chargeListReportGenerator.Execute(Arg.Any<GenerateReportInput>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.TriggerConcatenationJobIfFinishedAsync(Arg.Any<string>(), Arg.Any<string>())
            .Throws(expectedException);

        // Act & Assert
        var exception = await Assert.ThrowsAsync<InvalidOperationException>(
            () => _worker.ProcessReport(reportId, partitionDate, partitionSet, _performContext, _cancellationToken));

        Assert.Equal(expectedException.Message, exception.Message);
    }

    #endregion

    #region Edge Cases - Cancellation

    [Fact]
    public async Task ProcessReport_WithCancellationToken_ShouldPassTokenToReportGenerator()
    {
        // Arrange
        var reportId = "test-report-cancel";
        var partitionDate = DateTime.Today;
        var partitionSet = CreateValidPartitionSet();
        var metadata = CreateValidReportMetadata(reportId);
        using var cts = new CancellationTokenSource();
        GenerateReportInput? capturedInput = null;

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _chargeListReportGenerator.When(x => x.Execute(Arg.Any<GenerateReportInput>()))
            .Do(call => capturedInput = call.Arg<GenerateReportInput>());

        _idempotentJobManager.TriggerConcatenationJobIfFinishedAsync(Arg.Any<string>(), Arg.Any<string>())
            .Returns(Task.CompletedTask);

        // Act
        await _worker.ProcessReport(reportId, partitionDate, partitionSet, _performContext, cts.Token);

        // Assert
        Assert.NotNull(capturedInput);
        Assert.Equal(cts.Token, capturedInput.CancellationToken);
    }

    [Fact]
    public async Task ProcessReport_WhenReportGeneratorThrowsOperationCanceledException_ShouldPropagateException()
    {
        // Arrange
        var reportId = "test-report-canceled";
        var partitionDate = DateTime.Today;
        var partitionSet = CreateValidPartitionSet();
        var metadata = CreateValidReportMetadata(reportId);
        using var cts = new CancellationTokenSource();
        cts.Cancel();

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _chargeListReportGenerator.Execute(Arg.Any<GenerateReportInput>())
            .Throws(new OperationCanceledException("Operation was canceled"));

        // Act & Assert
        await Assert.ThrowsAsync<OperationCanceledException>(
            () => _worker.ProcessReport(reportId, partitionDate, partitionSet, _performContext, cts.Token));
    }

    #endregion

    #region Edge Cases - Different Report Types

    [Fact]
    public async Task ProcessReport_WithChargesEventsType_ShouldCallChargesEventsGenerator()
    {
        // Arrange
        var reportId = "test-report-charges-events";
        var partitionDate = DateTime.Today;
        var partitionSet = CreateValidPartitionSet();
        var metadata = CreateValidReportMetadata(reportId);
        metadata.ChargeReportParameters!.ReportType = "charges_events";

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _chargesEventsReportGenerator.Execute(Arg.Any<GenerateReportInput>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.TriggerConcatenationJobIfFinishedAsync(Arg.Any<string>(), Arg.Any<string>())
            .Returns(Task.CompletedTask);

        // Act
        await _worker.ProcessReport(reportId, partitionDate, partitionSet, _performContext, _cancellationToken);

        // Assert
        await _chargesEventsReportGenerator.Received(1).Execute(Arg.Any<GenerateReportInput>());
        await _chargeListReportGenerator.DidNotReceive().Execute(Arg.Any<GenerateReportInput>());
        await _idempotentJobManager.Received(1).TriggerConcatenationJobIfFinishedAsync(reportId, metadata.ProcessorQueueName);
    }

    #endregion

    #region Edge Cases - Boundary Values


    #endregion

    #region Edge Cases - Null Parameters

    [Fact]
    public async Task ProcessReport_WithNullPartitionSet_ShouldThrowArgumentNullException()
    {
        // Arrange
        var reportId = "test-report-null-partition";
        var partitionDate = DateTime.Today;
        DeltaTablePartitionSet partitionSet = null!;
        var metadata = CreateValidReportMetadata(reportId);

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _chargeListReportGenerator.Execute(Arg.Any<GenerateReportInput>())
            .Returns(Task.CompletedTask);

        // Act & Assert
        await _worker.ProcessReport(reportId, partitionDate, partitionSet, _performContext, _cancellationToken);

        await _chargeListReportGenerator.Received(1).Execute(
            Arg.Is<GenerateReportInput>(i => i.PartitionSet == null));
    }

    [Fact]
    public async Task ProcessReport_WithNullPerformContext_ShouldThrowNullReferenceException()
    {
        // Arrange
        var reportId = "test-report-null-context";
        var partitionDate = DateTime.Today;
        var partitionSet = CreateValidPartitionSet();
        var metadata = CreateValidReportMetadata(reportId);
        PerformContext nullContext = null!;

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        // Act & Assert
        await Assert.ThrowsAsync<NullReferenceException>(
            () => _worker.ProcessReport(reportId, partitionDate, partitionSet, nullContext, _cancellationToken));
    }

    [Fact]
    public async Task ProcessReport_WithNullReportParameters_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var reportId = "test-report-null-params";
        var partitionDate = DateTime.Today;
        var partitionSet = CreateValidPartitionSet();
        var metadata = CreateValidReportMetadata(reportId);
        metadata.ChargeReportParameters = null;

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        // Act & Assert
        var exception = await Assert.ThrowsAsync<InvalidOperationException>(
            () => _worker.ProcessReport(reportId, partitionDate, partitionSet, _performContext, _cancellationToken));

        Assert.Equal("Report type not found", exception.Message);
    }

    [Fact]
    public async Task ProcessReport_WithNullProcessorQueueName_ShouldPassNullToIdempotentJobManager()
    {
        // Arrange
        var reportId = "test-report-null-queue";
        var partitionDate = DateTime.Today;
        var partitionSet = CreateValidPartitionSet();
        var metadata = CreateValidReportMetadata(reportId);
        metadata.ProcessorQueueName = null!;

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _chargeListReportGenerator.Execute(Arg.Any<GenerateReportInput>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.TriggerConcatenationJobIfFinishedAsync(Arg.Any<string>(), Arg.Any<string>())
            .Returns(Task.CompletedTask);

        // Act
        await _worker.ProcessReport(reportId, partitionDate, partitionSet, _performContext, _cancellationToken);

        // Assert
        await _idempotentJobManager.Received(1).TriggerConcatenationJobIfFinishedAsync(reportId, null!);
    }

    [Fact]
    public async Task ProcessReport_WithInvalidReportType_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var reportId = "test-report-invalid-type";
        var partitionDate = DateTime.Today;
        var partitionSet = CreateValidPartitionSet();
        var metadata = CreateValidReportMetadata(reportId);
        metadata.ChargeReportParameters!.ReportType = "unsupported_report_type";

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        // Act & Assert
        await Assert.ThrowsAsync<InvalidOperationException>(
            () => _worker.ProcessReport(reportId, partitionDate, partitionSet, _performContext, _cancellationToken));
    }

    #endregion

    #region Edge Cases - Different Partition Sets

    [Fact]
    public async Task ProcessReport_WithEmptyPartitionSet_ShouldStillProcessCorrectly()
    {
        // Arrange
        var reportId = "test-report-empty-partition";
        var partitionDate = DateTime.Today;
        var partitionSet = new DeltaTablePartitionSet
        {
            PartitionIdReferences = new List<string>(),
            PartitionIdReferenceType = "organization_id",
            Partitions = Array.Empty<DeltaTablePartition>()
        };
        var metadata = CreateValidReportMetadata(reportId);

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _chargeListReportGenerator.Execute(Arg.Any<GenerateReportInput>())
            .Returns(Task.CompletedTask);

        _idempotentJobManager.TriggerConcatenationJobIfFinishedAsync(Arg.Any<string>(), Arg.Any<string>())
            .Returns(Task.CompletedTask);

        // Act
        await _worker.ProcessReport(reportId, partitionDate, partitionSet, _performContext, _cancellationToken);

        // Assert
        await _chargeListReportGenerator.Received(1).Execute(
            Arg.Is<GenerateReportInput>(i => i.PartitionSet == partitionSet));
    }

    [Fact]
    public async Task ProcessReport_WithMultiplePartitions_ShouldPassAllPartitionsToGenerator()
    {
        // Arrange
        var reportId = "test-report-multi-partition";
        var partitionDate = DateTime.Today;
        var partitionSet = new DeltaTablePartitionSet
        {
            PartitionIdReferences = new List<string> { "org1", "org2", "org3" },
            PartitionIdReferenceType = "organization_id",
            Partitions = new[]
            {
                new DeltaTablePartition("charges_events_by_created_at", "org1"),
                new DeltaTablePartition("charges_events_by_created_at", "org2"),
                new DeltaTablePartition("charges_events_by_created_at", "org3")
            }
        };
        var metadata = CreateValidReportMetadata(reportId);
        GenerateReportInput? capturedInput = null;

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _chargeListReportGenerator.When(x => x.Execute(Arg.Any<GenerateReportInput>()))
            .Do(call => capturedInput = call.Arg<GenerateReportInput>());

        _idempotentJobManager.TriggerConcatenationJobIfFinishedAsync(Arg.Any<string>(), Arg.Any<string>())
            .Returns(Task.CompletedTask);

        // Act
        await _worker.ProcessReport(reportId, partitionDate, partitionSet, _performContext, _cancellationToken);

        // Assert
        Assert.NotNull(capturedInput);
        Assert.Equal(partitionSet, capturedInput.PartitionSet);
    }

    #endregion

    #region Integration - Complete Flow Validation

    [Fact]
    public async Task ProcessReport_CompleteFlow_ShouldExecuteAllStepsInOrder()
    {
        // Arrange
        var reportId = "test-report-complete-flow";
        var partitionDate = DateTime.Today;
        var partitionSet = CreateValidPartitionSet();
        var metadata = CreateValidReportMetadata(reportId);
        var callOrder = new List<string>();

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(callInfo =>
            {
                callOrder.Add("GetMetadata");
                return Task.FromResult<ReportMetadata?>(metadata);
            });

        _chargeListReportGenerator.Execute(Arg.Any<GenerateReportInput>())
            .Returns(callInfo =>
            {
                callOrder.Add("GenerateReport");
                return Task.CompletedTask;
            });

        _idempotentJobManager.TriggerConcatenationJobIfFinishedAsync(Arg.Any<string>(), Arg.Any<string>())
            .Returns(callInfo =>
            {
                callOrder.Add("TriggerConcatenation");
                return Task.CompletedTask;
            });

        // Act
        await _worker.ProcessReport(reportId, partitionDate, partitionSet, _performContext, _cancellationToken);

        // Assert
        Assert.Equal(3, callOrder.Count);
        Assert.Equal("GetMetadata", callOrder[0]);
        Assert.Equal("GenerateReport", callOrder[1]);
        Assert.Equal("TriggerConcatenation", callOrder[2]);
    }

    [Fact]
    public async Task ProcessReport_WhenGetMetadataThrows_ShouldNotCallSubsequentMethods()
    {
        // Arrange
        var reportId = "test-report-early-fail";
        var partitionDate = DateTime.Today;
        var partitionSet = CreateValidPartitionSet();
        var expectedException = new InvalidOperationException("S3 connection failed");

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Throws(expectedException);

        // Act & Assert
        await Assert.ThrowsAsync<InvalidOperationException>(
            () => _worker.ProcessReport(reportId, partitionDate, partitionSet, _performContext, _cancellationToken));

        await _chargeListReportGenerator.DidNotReceive().Execute(Arg.Any<GenerateReportInput>());
        await _chargesEventsReportGenerator.DidNotReceive().Execute(Arg.Any<GenerateReportInput>());
        await _idempotentJobManager.DidNotReceive().TriggerConcatenationJobIfFinishedAsync(
            Arg.Any<string>(),
            Arg.Any<string>());
    }

    #endregion

    #region Edge Cases - PerformContext and JobId

    [Fact]
    public async Task ProcessReport_ShouldUseJobIdFromPerformContext()
    {
        // Arrange
        var reportId = "test-report-jobid";
        var partitionDate = DateTime.Today;
        var partitionSet = CreateValidPartitionSet();
        var metadata = CreateValidReportMetadata(reportId);
        var expectedJobId = "custom-job-id-123";
        GenerateReportInput? capturedInput = null;

        var backgroundJob = Substitute.For<BackgroundJob>(expectedJobId, Job.FromExpression(() => Console.WriteLine()), DateTime.UtcNow);
        var customPerformContext = Substitute.For<PerformContext>(
            Substitute.For<IStorageConnection>(),
            backgroundJob,
            Substitute.For<IJobCancellationToken>()
        );

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns(Task.FromResult<ReportMetadata?>(metadata));

        _chargeListReportGenerator.Execute(Arg.Any<GenerateReportInput>())
            .Returns(callInfo =>
            {
                capturedInput = callInfo.Arg<GenerateReportInput>();
                return Task.CompletedTask;
            });

        _idempotentJobManager.TriggerConcatenationJobIfFinishedAsync(Arg.Any<string>(), Arg.Any<string>())
            .Returns(Task.CompletedTask);

        // Act
        await _worker.ProcessReport(reportId, partitionDate, partitionSet, customPerformContext, _cancellationToken);

        // Assert
        Assert.NotNull(capturedInput);
        Assert.Equal(expectedJobId, capturedInput.JobId);
    }

    #endregion

    #region Helper Methods

    /// <summary>
    /// Creates a valid DeltaTablePartitionSet
    /// </summary>
    private static DeltaTablePartitionSet CreateValidPartitionSet()
    {
        return new DeltaTablePartitionSet
        {
            PartitionIdReferences = new List<string> { "org-123", "org-456" },
            PartitionIdReferenceType = "organization_id",
            Partitions = new[]
            {
                new DeltaTablePartition("charges_events_by_created_at", "org-123"),
                new DeltaTablePartition("charges_events_by_created_at", "org-456")
            }
        };
    }

    /// <summary>
    /// Creates a valid ReportMetadata object
    /// </summary>
    private static ReportMetadata CreateValidReportMetadata(string reportId)
    {
        return new ReportMetadata
        {
            ReportId = reportId,
            DispatchId = "dispatch-123",
            Status = "Processing",
            CreatedAt = DateTime.Now.AddMinutes(-10),
            ReportSortColumnIndex = 0,
            ProcessorQueueName = "test-queue",
            FileFormat = "csv",
            ChargeReportParameters = new ChargeReportsWorkerParameters
            {
                ReportType = "charges_list",
                Organizations = "org-123",
                Document = "12345678900",
                AccountId = "acc-123",
                MerchantId = "merch-123",
                IsSandbox = false,
                StartDate = DateTime.Today.AddDays(-7),
                EndDate = DateTime.Today
            }
        };
    }

    #endregion
}

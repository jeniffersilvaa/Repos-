using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.ChargeReportS3Worker.Utils;

public class CsvHelperTests
{
    #region GetHeader - Success Scenarios

    [Fact]
    public void GetHeader_WithValidFilePath_ShouldReturnHeaderLine()
    {
        // Arrange
        var tempFile = CreateTempCsvFile("Name,Age,City\nJohn,30,NYC");

        try
        {
            // Act
            var header = CsvHelper.GetHeader(tempFile);

            // Assert
            Assert.Equal("Name,Age,City", header);
        }
        finally
        {
            CleanupTempFile(tempFile);
        }
    }

    [Fact]
    public void GetHeader_WithMultipleLines_ShouldReturnOnlyFirstLine()
    {
        // Arrange
        var tempFile = CreateTempCsvFile("Header1,Header2,Header3\nData1,Data2,Data3\nData4,Data5,Data6");

        try
        {
            // Act
            var header = CsvHelper.GetHeader(tempFile);

            // Assert
            Assert.Equal("Header1,Header2,Header3", header);
        }
        finally
        {
            CleanupTempFile(tempFile);
        }
    }

    [Fact]
    public void GetHeader_WithComplexHeader_ShouldReturnFullHeader()
    {
        // Arrange
        var complexHeader = "id,name,\"quoted,field\",date,amount";
        var tempFile = CreateTempCsvFile($"{complexHeader}\n1,Test,Value,2024-01-01,100.50");

        try
        {
            // Act
            var header = CsvHelper.GetHeader(tempFile);

            // Assert
            Assert.Equal(complexHeader, header);
        }
        finally
        {
            CleanupTempFile(tempFile);
        }
    }

    #endregion

    #region GetHeader - Error Scenarios

    [Fact]
    public void GetHeader_WithEmptyFile_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var tempFile = CreateTempCsvFile("");

        try
        {
            // Act & Assert
            var exception = Assert.Throws<InvalidOperationException>(() => CsvHelper.GetHeader(tempFile));
            Assert.Contains("empty or does not have a header", exception.Message);
            Assert.Contains(tempFile, exception.Message);
        }
        finally
        {
            CleanupTempFile(tempFile);
        }
    }

    [Fact]
    public void GetHeader_WithNonExistentFile_ShouldThrowFileNotFoundException()
    {
        // Arrange
        var nonExistentFile = "/tmp/non-existent-file-" + Guid.NewGuid() + ".csv";

        // Act & Assert
        Assert.Throws<FileNotFoundException>(() => CsvHelper.GetHeader(nonExistentFile));
    }

    #endregion

    #region ExtractId - Success Scenarios

    [Fact]
    public void ExtractId_WithStandardCsvLine_ShouldExtractThirdField()
    {
        // Arrange
        var line = "field1,field2,ID123,field4,field5";

        // Act
        var id = CsvHelper.ExtractId(line);

        // Assert
        Assert.Equal("ID123", id);
    }


    [Fact]
    public void ExtractId_WithEmptyThirdField_ShouldReturnEmptyString()
    {
        // Arrange
        var line = "field1,field2,,field4,field5";

        // Act
        var id = CsvHelper.ExtractId(line);

        // Assert
        Assert.Equal("", id);
    }

    #endregion

    #region ExtractId - Edge Cases

    [Fact]
    public void ExtractId_WithOnlyTwoCommas_ShouldReturnRestOfLine()
    {
        // Arrange
        var line = "field1,field2,ID123WithNoCommaAfter";

        // Act
        var id = CsvHelper.ExtractId(line);

        // Assert
        Assert.Equal("ID123WithNoCommaAfter", id);
    }

    [Fact]
    public void ExtractId_WithEmptyString_ShouldReturnEmptyString()
    {
        // Arrange
        var line = "";

        // Act
        var id = CsvHelper.ExtractId(line);

        // Assert
        Assert.Equal(string.Empty, id);
    }

    [Fact]
    public void ExtractId_WithManyFields_ShouldExtractOnlyThirdField()
    {
        // Arrange
        var line = "f1,f2,TARGET_ID,f4,f5,f6,f7,f8,f9,f10";

        // Act
        var id = CsvHelper.ExtractId(line);

        // Assert
        Assert.Equal("TARGET_ID", id);
    }

    #endregion

    #region ParseCsvRow - Success Scenarios

    [Fact]
    public void ParseCsvRow_WithSimpleFields_ShouldParseCorrectly()
    {
        // Arrange
        var line = "field1,field2,field3";
        var fieldCount = 3;

        // Act
        var row = CsvHelper.ParseCsvRow(line, fieldCount);

        // Assert
        Assert.Equal("field1", row.GetField(CreateIndex("col0", "col1", "col2"), "col0"));
        Assert.Equal("field2", row.GetField(CreateIndex("col0", "col1", "col2"), "col1"));
        Assert.Equal("field3", row.GetField(CreateIndex("col0", "col1", "col2"), "col2"));
    }

    [Fact]
    public void ParseCsvRow_WithQuotedFields_ShouldRemoveOuterQuotes()
    {
        // Arrange
        var line = "\"field1\",\"field2\",\"field3\"";
        var fieldCount = 3;

        // Act
        var row = CsvHelper.ParseCsvRow(line, fieldCount);

        // Assert
        Assert.Equal("field1", row.GetField(CreateIndex("col0", "col1", "col2"), "col0"));
        Assert.Equal("field2", row.GetField(CreateIndex("col0", "col1", "col2"), "col1"));
        Assert.Equal("field3", row.GetField(CreateIndex("col0", "col1", "col2"), "col2"));
    }

    [Fact]
    public void ParseCsvRow_WithQuotedFieldContainingComma_ShouldParseCorrectly()
    {
        // Arrange
        var line = "field1,\"field2,with,commas\",field3";
        var fieldCount = 3;

        // Act
        var row = CsvHelper.ParseCsvRow(line, fieldCount);

        // Assert
        Assert.Equal("field1", row.GetField(CreateIndex("col0", "col1", "col2"), "col0"));
        Assert.Equal("field2,with,commas", row.GetField(CreateIndex("col0", "col1", "col2"), "col1"));
        Assert.Equal("field3", row.GetField(CreateIndex("col0", "col1", "col2"), "col2"));
    }

    [Fact]
    public void ParseCsvRow_WithEscapedQuotes_ShouldUnescapeCorrectly()
    {
        // Arrange
        var line = "field1,\"field with \"\"quotes\"\"\",field3";
        var fieldCount = 3;

        // Act
        var row = CsvHelper.ParseCsvRow(line, fieldCount);

        // Assert
        Assert.Equal("field1", row.GetField(CreateIndex("col0", "col1", "col2"), "col0"));
        Assert.Equal("field with \"quotes\"", row.GetField(CreateIndex("col0", "col1", "col2"), "col1"));
        Assert.Equal("field3", row.GetField(CreateIndex("col0", "col1", "col2"), "col2"));
    }

    [Fact]
    public void ParseCsvRow_WithEmptyFields_ShouldHandleCorrectly()
    {
        // Arrange
        var line = "field1,,field3";
        var fieldCount = 3;

        // Act
        var row = CsvHelper.ParseCsvRow(line, fieldCount);

        // Assert
        Assert.Equal("field1", row.GetField(CreateIndex("col0", "col1", "col2"), "col0"));
        Assert.Null(row.GetField(CreateIndex("col0", "col1", "col2"), "col1"));
        Assert.Equal("field3", row.GetField(CreateIndex("col0", "col1", "col2"), "col2"));
    }

    [Fact]
    public void ParseCsvRow_WithMixedQuotedAndUnquoted_ShouldParseCorrectly()
    {
        // Arrange
        var line = "unquoted,\"quoted\",unquoted2,\"quoted2\"";
        var fieldCount = 4;

        // Act
        var row = CsvHelper.ParseCsvRow(line, fieldCount);

        // Assert
        var index = CreateIndex("col0", "col1", "col2", "col3");
        Assert.Equal("unquoted", row.GetField(index, "col0"));
        Assert.Equal("quoted", row.GetField(index, "col1"));
        Assert.Equal("unquoted2", row.GetField(index, "col2"));
        Assert.Equal("quoted2", row.GetField(index, "col3"));
    }

    [Fact]
    public void ParseCsvRow_WithComplexEscapedContent_ShouldParseCorrectly()
    {
        // Arrange
        var line = "simple,\"complex \"\"with\"\" quotes, commas, and spaces\",another";
        var fieldCount = 3;

        // Act
        var row = CsvHelper.ParseCsvRow(line, fieldCount);

        // Assert
        Assert.Equal("simple", row.GetField(CreateIndex("col0", "col1", "col2"), "col0"));
        Assert.Equal("complex \"with\" quotes, commas, and spaces", row.GetField(CreateIndex("col0", "col1", "col2"), "col1"));
        Assert.Equal("another", row.GetField(CreateIndex("col0", "col1", "col2"), "col2"));
    }

    #endregion

    #region ParseCsvRow - Edge Cases

    [Fact]
    public void ParseCsvRow_WithEmptyString_ShouldReturnRowWithOneNullField()
    {
        // Arrange
        var line = "";
        var fieldCount = 1;

        // Act
        var row = CsvHelper.ParseCsvRow(line, fieldCount);

        // Assert
        Assert.Null(row.GetField(CreateIndex("col0"), "col0"));
    }

    [Fact]
    public void ParseCsvRow_WithOnlyCommas_ShouldReturnRowWithNullFields()
    {
        // Arrange
        var line = ",,,";
        var fieldCount = 4;

        // Act
        var row = CsvHelper.ParseCsvRow(line, fieldCount);

        // Assert
        var index = CreateIndex("col0", "col1", "col2", "col3");
        Assert.Null(row.GetField(index, "col0"));
        Assert.Null(row.GetField(index, "col1"));
        Assert.Null(row.GetField(index, "col2"));
        Assert.Null(row.GetField(index, "col3"));
    }

    [Fact]
    public void ParseCsvRow_WithTrailingComma_ShouldHandleCorrectly()
    {
        // Arrange
        var line = "field1,field2,";
        var fieldCount = 3;

        // Act
        var row = CsvHelper.ParseCsvRow(line, fieldCount);

        // Assert
        var index = CreateIndex("col0", "col1", "col2");
        Assert.Equal("field1", row.GetField(index, "col0"));
        Assert.Equal("field2", row.GetField(index, "col1"));
        Assert.Null(row.GetField(index, "col2"));
    }

    [Fact]
    public void ParseCsvRow_WithLeadingComma_ShouldHandleCorrectly()
    {
        // Arrange
        var line = ",field2,field3";
        var fieldCount = 3;

        // Act
        var row = CsvHelper.ParseCsvRow(line, fieldCount);

        // Assert
        var index = CreateIndex("col0", "col1", "col2");
        Assert.Null(row.GetField(index, "col0"));
        Assert.Equal("field2", row.GetField(index, "col1"));
        Assert.Equal("field3", row.GetField(index, "col2"));
    }

    [Fact]
    public void ParseCsvRow_WithSingleField_ShouldParseCorrectly()
    {
        // Arrange
        var line = "singlefield";
        var fieldCount = 1;

        // Act
        var row = CsvHelper.ParseCsvRow(line, fieldCount);

        // Assert
        Assert.Equal("singlefield", row.GetField(CreateIndex("col0"), "col0"));
    }

    [Fact]
    public void ParseCsvRow_WithQuotedEmptyString_ShouldReturnEmptyString()
    {
        // Arrange
        var line = "field1,\"\",field3";
        var fieldCount = 3;

        // Act
        var row = CsvHelper.ParseCsvRow(line, fieldCount);

        // Assert
        var index = CreateIndex("col0", "col1", "col2");
        Assert.Equal("field1", row.GetField(index, "col0"));
        Assert.Equal("", row.GetField(index, "col1"));
        Assert.Equal("field3", row.GetField(index, "col2"));
    }


    [Fact]
    public void ParseCsvRow_WithLargeFieldCount_ShouldHandleCorrectly()
    {
        // Arrange
        var fields = Enumerable.Range(1, 50).Select(i => $"field{i}");
        var line = string.Join(",", fields);
        var fieldCount = 50;

        // Act
        var row = CsvHelper.ParseCsvRow(line, fieldCount);

        // Assert
        var index = CreateIndex(Enumerable.Range(0, 50).Select(i => $"col{i}").ToArray());
        for (int i = 0; i < 50; i++)
        {
            Assert.Equal($"field{i + 1}", row.GetField(index, $"col{i}"));
        }
    }

    #endregion

    #region EscapeCsv - Success Scenarios

    [Fact]
    public void EscapeCsv_WithSimpleString_ShouldReturnUnmodified()
    {
        // Arrange
        var value = "simple text";

        // Act
        var result = CsvHelper.EscapeCsv(value);

        // Assert
        Assert.Equal("simple text", result);
    }

    [Fact]
    public void EscapeCsv_WithComma_ShouldQuoteString()
    {
        // Arrange
        var value = "text,with,commas";

        // Act
        var result = CsvHelper.EscapeCsv(value);

        // Assert
        Assert.Equal("\"text,with,commas\"", result);
    }

    [Fact]
    public void EscapeCsv_WithQuotes_ShouldEscapeAndQuote()
    {
        // Arrange
        var value = "text with \"quotes\"";

        // Act
        var result = CsvHelper.EscapeCsv(value);

        // Assert
        Assert.Equal("\"text with \"\"quotes\"\"\"", result);
    }

    [Fact]
    public void EscapeCsv_WithNewline_ShouldQuoteString()
    {
        // Arrange
        var value = "text\nwith\nnewlines";

        // Act
        var result = CsvHelper.EscapeCsv(value);

        // Assert
        Assert.Equal("\"text\nwith\nnewlines\"", result);
    }

    [Fact]
    public void EscapeCsv_WithCommaAndQuotes_ShouldEscapeAndQuote()
    {
        // Arrange
        var value = "text, with \"both\"";

        // Act
        var result = CsvHelper.EscapeCsv(value);

        // Assert
        Assert.Equal("\"text, with \"\"both\"\"\"", result);
    }

    [Fact]
    public void EscapeCsv_WithCommaQuotesAndNewline_ShouldEscapeAndQuote()
    {
        // Arrange
        var value = "complex,\"text\"\nwith all";

        // Act
        var result = CsvHelper.EscapeCsv(value);

        // Assert
        Assert.Equal("\"complex,\"\"text\"\"\nwith all\"", result);
    }

    #endregion

    #region EscapeCsv - Edge Cases

    [Fact]
    public void EscapeCsv_WithNull_ShouldReturnEmptyString()
    {
        // Arrange
        string? value = null;

        // Act
        var result = CsvHelper.EscapeCsv(value);

        // Assert
        Assert.Equal(string.Empty, result);
    }

    [Fact]
    public void EscapeCsv_WithEmptyString_ShouldReturnEmptyString()
    {
        // Arrange
        var value = "";

        // Act
        var result = CsvHelper.EscapeCsv(value);

        // Assert
        Assert.Equal(string.Empty, result);
    }

    [Fact]
    public void EscapeCsv_WithWhitespace_ShouldReturnUnmodified()
    {
        // Arrange
        var value = "   ";

        // Act
        var result = CsvHelper.EscapeCsv(value);

        // Assert
        Assert.Equal("   ", result);
    }

    [Fact]
    public void EscapeCsv_WithOnlyComma_ShouldQuote()
    {
        // Arrange
        var value = ",";

        // Act
        var result = CsvHelper.EscapeCsv(value);

        // Assert
        Assert.Equal("\",\"", result);
    }

    [Fact]
    public void EscapeCsv_WithOnlyQuote_ShouldEscapeAndQuote()
    {
        // Arrange
        var value = "\"";

        // Act
        var result = CsvHelper.EscapeCsv(value);

        // Assert
        Assert.Equal("\"\"\"\"", result);
    }

    [Fact]
    public void EscapeCsv_WithOnlyNewline_ShouldQuote()
    {
        // Arrange
        var value = "\n";

        // Act
        var result = CsvHelper.EscapeCsv(value);

        // Assert
        Assert.Equal("\"\n\"", result);
    }


    #endregion

    #region Integration Tests - Round Trip

    [Fact]
    public void RoundTrip_EscapeAndParse_ShouldPreserveData()
    {
        // Arrange
        var originalValues = new[] { "simple", "with,comma", "with\"quote", "with\nnewline" };
        var escapedLine = string.Join(",", originalValues.Select(CsvHelper.EscapeCsv));

        // Act
        var row = CsvHelper.ParseCsvRow(escapedLine, originalValues.Length);

        // Assert
        var index = CreateIndex("col0", "col1", "col2", "col3");
        Assert.Equal("simple", row.GetField(index, "col0"));
        Assert.Equal("with,comma", row.GetField(index, "col1"));
        Assert.Equal("with\"quote", row.GetField(index, "col2"));
        Assert.Equal("with\nnewline", row.GetField(index, "col3"));
    }

    [Fact]
    public void RoundTrip_ComplexData_ShouldPreserveAllFields()
    {
        // Arrange
        var originalValues = new[]
        {
            "ID123",
            "John \"Johnny\" Doe",
            "Address: 123 Main St, Apt 4B",
            "Notes:\nLine 1\nLine 2",
            "Email: john@example.com"
        };
        var escapedLine = string.Join(",", originalValues.Select(CsvHelper.EscapeCsv));

        // Act
        var row = CsvHelper.ParseCsvRow(escapedLine, originalValues.Length);

        // Assert
        var index = CreateIndex("col0", "col1", "col2", "col3", "col4");
        for (int i = 0; i < originalValues.Length; i++)
        {
            Assert.Equal(originalValues[i], row.GetField(index, $"col{i}"));
        }
    }

    #endregion

    #region Helper Methods

    /// <summary>
    /// Creates a temporary CSV file with the specified content.
    /// </summary>
    private static string CreateTempCsvFile(string content)
    {
        var tempFile = Path.Combine(Path.GetTempPath(), $"test-{Guid.NewGuid()}.csv");
        File.WriteAllText(tempFile, content);
        return tempFile;
    }

    /// <summary>
    /// Cleans up a temporary file.
    /// </summary>
    private static void CleanupTempFile(string? filePath)
    {
        try
        {
            if (filePath != null && File.Exists(filePath))
                File.Delete(filePath);
        }
        catch
        {
            // Best effort cleanup
        }
    }

    /// <summary>
    /// Creates a column index dictionary for testing CsvRow.GetField.
    /// </summary>
    private static Dictionary<string, int> CreateIndex(params string[] columnNames)
    {
        return columnNames.Select((name, index) => (name, index))
            .ToDictionary(x => x.name, x => x.index);
    }

    #endregion
}

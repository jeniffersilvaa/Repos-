using Amazon.S3;
using Microsoft.Extensions.Options;
using NSubstitute;
using PaymentsDataLayerReports.Application.Services.DeltaTableColumnMapping;
using PaymentsDataLayerReports.Application.Services.DeltaTablePartitionBuilder;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.Models;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.ChargeReportS3Worker;

public class DeltaLakeManagerTests
{
    private readonly IOptions<AwsSettings> _awsSettings;
    private readonly IColumnMappingService _columnMappingService;
    private const string TestWarehouseBucket = "test-warehouse-bucket";

    public DeltaLakeManagerTests()
    {
        _awsSettings = Options.Create(new AwsSettings
        {
            WarehouseBucket = TestWarehouseBucket,
            Region = "us-east-1"
        });

        _columnMappingService = Substitute.For<IColumnMappingService>();
    }

    #region ConvertToCsvAsync - Report Type Validation

    [Fact]
    public async Task ConvertToCsvAsync_WithUnsupportedReportType_ShouldThrowArgumentException()
    {
        // Arrange
        var deltaLakeManager = CreateDeltaLakeManager();
        var input = CreateGenerateReportInput(reportType: "unsupported_report_type");
        var inputDirPath = "/tmp/input-unsupported";
        var outputCsvPath = "/tmp/output-unsupported.csv";

        // Act & Assert
        var exception = await Assert.ThrowsAsync<ArgumentException>(
            () => deltaLakeManager.ConvertToCsvAsync(
                input, inputDirPath, outputCsvPath, hasRealTimeData: true, hasParquetData: true));

        Assert.Contains("Unsupported report type", exception.Message);
        Assert.Contains("unsupported_report_type", exception.Message);
    }

    [Fact]
    public async Task ConvertToCsvAsync_WithInvalidReportType_ShouldThrowArgumentException()
    {
        // Arrange
        var deltaLakeManager = CreateDeltaLakeManager();
        var input = CreateGenerateReportInput(reportType: "invalid_type_123");
        var inputDirPath = "/tmp/input-invalid";
        var outputCsvPath = "/tmp/output-invalid.csv";

        // Act & Assert
        await Assert.ThrowsAsync<ArgumentException>(
            () => deltaLakeManager.ConvertToCsvAsync(
                input, inputDirPath, outputCsvPath, hasRealTimeData: true, hasParquetData: true));
    }

    [Fact]
    public async Task ConvertToCsvAsync_WithEmptyReportType_ShouldThrowArgumentException()
    {
        // Arrange
        var deltaLakeManager = CreateDeltaLakeManager();
        var input = CreateGenerateReportInput(reportType: "");
        var inputDirPath = "/tmp/input-empty";
        var outputCsvPath = "/tmp/output-empty.csv";

        // Act & Assert
        await Assert.ThrowsAsync<ArgumentException>(
            () => deltaLakeManager.ConvertToCsvAsync(
                input, inputDirPath, outputCsvPath, hasRealTimeData: true, hasParquetData: true));
    }

    [Fact]
    public async Task ConvertToCsvAsync_WithNullReportType_ShouldThrowArgumentException()
    {
        // Arrange
        var deltaLakeManager = CreateDeltaLakeManager();
        var input = CreateGenerateReportInput(reportType: null!);
        var inputDirPath = "/tmp/input-null";
        var outputCsvPath = "/tmp/output-null.csv";

        // Act & Assert
        await Assert.ThrowsAsync<ArgumentException>(
            () => deltaLakeManager.ConvertToCsvAsync(
                input, inputDirPath, outputCsvPath, hasRealTimeData: true, hasParquetData: true));
    }

    #endregion


    #region Helper Methods

    /// <summary>
    /// Creates a DeltaLakeManager instance for testing.
    /// Note: Uses a minimal S3 client configuration that won't make actual AWS calls.
    /// </summary>
    private DeltaLakeManager CreateDeltaLakeManager()
    {
        var s3Client = Substitute.For<IAmazonS3>();

        return new DeltaLakeManager(s3Client, _awsSettings, _columnMappingService, Options.Create(new ReportSettings()));
    }

    /// <summary>
    /// Creates a GenerateReportInput object for testing purposes.
    /// </summary>
    private static GenerateReportInput CreateGenerateReportInput(
        int partitionCount = 1,
        DateTime? partitionDate = null,
        string reportType = "charges_list",
        DeltaTablePartition[]? customPartitions = null)
    {
        // If custom partitions are provided, create a custom partition set
        if (customPartitions != null)
        {
            var customPartitionSet = new DeltaTablePartitionSet
            {
                PartitionIdReferences = new List<string> { "ref-1" },
                PartitionIdReferenceType = "document",
                Partitions = customPartitions
            };

            return TestDataFactory.CreateGenerateReportInput(
                partitionDate: partitionDate,
                partitionSet: customPartitionSet,
                reportType: reportType);
        }

        // For simple cases with partition count, create partitions and use factory
        var partitions = Enumerable.Range(1, partitionCount)
            .Select(i => new DeltaTablePartition($"table_{i}", $"partition_{i}"))
            .ToArray();

        var partitionSet = new DeltaTablePartitionSet
        {
            PartitionIdReferences = new List<string> { "ref-1" },
            PartitionIdReferenceType = "document",
            Partitions = partitions
        };

        return TestDataFactory.CreateGenerateReportInput(
            partitionDate: partitionDate,
            partitionSet: partitionSet,
            reportType: reportType);
    }

    #endregion
}

using Microsoft.Extensions.Options;
using NSubstitute;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.ChargeList;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.ChargeReportS3Worker.Services.ChargeList;

public class ChargeListReportManagerTests : IDisposable
{
    private readonly IOptions<DataLayerReportsSettings> _settings;
    private readonly string _testTempDir;
    private readonly List<string> _tempFilesToCleanup;
    private readonly List<string> _tempDirsToCleanup;

    public ChargeListReportManagerTests()
    {
        // Arrange - Setup common mocks
        _settings = Substitute.For<IOptions<DataLayerReportsSettings>>();
        _settings.Value.Returns(new DataLayerReportsSettings
        {
            BashPath = "/bin/bash"
        });

        _testTempDir = Path.Combine(Path.GetTempPath(), $"test-{Guid.NewGuid()}");
        _tempFilesToCleanup = new List<string>();
        _tempDirsToCleanup = new List<string>();
    }

    #region Constructor Tests

    [Fact]
    public void Constructor_ShouldInitializeAllProperties()
    {
        // Act
        using var manager = new ChargeListReportManager(_settings);

        // Assert
        Assert.NotNull(manager.ChargesEventsRawParquetPath);
        Assert.NotNull(manager.ChargesEventsRawCsvFile);
        Assert.NotNull(manager.ChargesEventsSortedByIdCsvFile);
        Assert.NotNull(manager.ChargesRawCsvFile);
        Assert.NotNull(manager.ChargesFilteredCsvFile);
        Assert.NotNull(manager.ChargesSortedByCreatedAtCsvFile);
    }

    [Fact]
    public void Constructor_ShouldCreateParquetDirectory()
    {
        // Act
        using var manager = new ChargeListReportManager(_settings);

        // Assert
        Assert.True(Directory.Exists(manager.ChargesEventsRawParquetPath));

        // Cleanup
        _tempDirsToCleanup.Add(manager.ChargesEventsRawParquetPath);
    }

    [Fact]
    public void Constructor_ShouldCreateUniqueTempFiles()
    {
        // Act
        using var manager1 = new ChargeListReportManager(_settings);
        using var manager2 = new ChargeListReportManager(_settings);

        // Assert - Each instance should have unique file paths
        Assert.NotEqual(manager1.ChargesEventsRawCsvFile, manager2.ChargesEventsRawCsvFile);
        Assert.NotEqual(manager1.ChargesEventsSortedByIdCsvFile, manager2.ChargesEventsSortedByIdCsvFile);
        Assert.NotEqual(manager1.ChargesRawCsvFile, manager2.ChargesRawCsvFile);
        Assert.NotEqual(manager1.ChargesFilteredCsvFile, manager2.ChargesFilteredCsvFile);
        Assert.NotEqual(manager1.ChargesSortedByCreatedAtCsvFile, manager2.ChargesSortedByCreatedAtCsvFile);

        // Cleanup
        _tempDirsToCleanup.Add(manager1.ChargesEventsRawParquetPath);
        _tempDirsToCleanup.Add(manager2.ChargesEventsRawParquetPath);
    }

    #endregion

    #region SortEventsByChargeId Tests

    [Fact]
    public void SortEventsByChargeId_WithValidData_ShouldCreateSortedFile()
    {
        // Arrange
        using var manager = new ChargeListReportManager(_settings);
        _tempDirsToCleanup.Add(manager.ChargesEventsRawParquetPath);

        // Create test CSV with header and data
        var csvContent = @"sort_key,event_id,event_datetime,charge_id
    charge-2,event-3,2024-01-15T10:30:00Z,charge-2
    charge-1,event-1,2024-01-15T10:30:00Z,charge-1
    charge-1,event-2,2024-01-15T10:30:00Z,charge-1
    charge-2,event-4,2024-01-15T10:30:00Z,charge-2";
        File.WriteAllText(manager.ChargesEventsRawCsvFile, csvContent);

        var jobId = "test-job-123";
        var reportId = "test-report-456";
        var reportDate = DateTime.Today;

        // Act
        manager.SortEventsByChargeId(jobId, reportId, reportDate, 4);

        // Assert
        Assert.True(File.Exists(manager.ChargesEventsSortedByIdCsvFile));
        var sortedContent = File.ReadAllText(manager.ChargesEventsSortedByIdCsvFile);
        Assert.NotEmpty(sortedContent);

        // Verify header was skipped (output should not contain header)
        Assert.DoesNotContain("sort_key,event_id,event_datetime,charge_id", sortedContent);
    }

    [Fact]
    public void SortEventsByChargeId_WithDuplicateEventIds_ShouldDeduplicateByEventId()
    {
        // Arrange
        using var manager = new ChargeListReportManager(_settings);
        _tempDirsToCleanup.Add(manager.ChargesEventsRawParquetPath);

        // Create test CSV with duplicate event_ids (different event_datetime)
        var csvContent = @"sort_key,event_id,event_datetime,charge_id
    charge-1,event-1,2024-01-15T10:30:00Z,charge-1
    charge-1,event-1,2024-01-15T11:00:00Z,charge-1
    charge-2,event-2,2024-01-15T10:30:00Z,charge-2";
        File.WriteAllText(manager.ChargesEventsRawCsvFile, csvContent);

        var jobId = "test-job-dedup";
        var reportId = "test-report-dedup";
        var reportDate = DateTime.Today;

        // Act
        manager.SortEventsByChargeId(jobId, reportId, reportDate, 4);

        // Assert
        var sortedLines = File.ReadAllLines(manager.ChargesEventsSortedByIdCsvFile);

        // Should only have 2 lines (one for each unique event_id)
        Assert.Equal(2, sortedLines.Length);
    }

    [Fact]
    public void SortEventsByChargeId_WithDuplicateEventIds_ShouldKeepMostRecentProcessedAt()
    {
        // Arrange
        using var manager = new ChargeListReportManager(_settings);
        _tempDirsToCleanup.Add(manager.ChargesEventsRawParquetPath);

        // Create test CSV with duplicate event_ids and different processed_at values.
        // IMPORTANT: the row with NEWER processed_at has OLDER event_datetime to prove
        // that processed_at takes priority over event_datetime in the dedup sort.
        var csvContent = @"sort_key,event_id,event_datetime,charge_id,processed_at
charge-1,event-1,2024-01-15T11:00:00Z,charge-1,2026-01-01 10:00:00.000 UTC
charge-1,event-1,2024-01-15T10:30:00Z,charge-1,2026-03-30 01:52:43.300 UTC
charge-2,event-2,2024-01-15T10:30:00Z,charge-2,2026-03-30 01:00:00.000 UTC";
        File.WriteAllText(manager.ChargesEventsRawCsvFile, csvContent);

        var jobId = "test-job-dedup-processed-at";
        var reportId = "test-report-dedup-processed-at";
        var reportDate = DateTime.Today;

        // Act
        manager.SortEventsByChargeId(jobId, reportId, reportDate, 4);

        // Assert
        var sortedLines = File.ReadAllLines(manager.ChargesEventsSortedByIdCsvFile);

        // Should only have 2 lines (one for each unique event_id)
        Assert.Equal(2, sortedLines.Length);

        // event-1 should keep the row with most recent processed_at (2026-03-30),
        // even though its event_datetime (10:30) is older than the other row's (11:00)
        var event1Line = sortedLines.First(l => l.Contains("event-1,"));
        Assert.Contains("2024-01-15T10:30:00Z", event1Line);
        Assert.Contains("2026-03-30 01:52:43.300 UTC", event1Line);
    }

    [Fact]
    public void SortEventsByChargeId_WithEmptyProcessedAt_ShouldPreferFilledProcessedAt()
    {
        // Arrange
        using var manager = new ChargeListReportManager(_settings);
        _tempDirsToCleanup.Add(manager.ChargesEventsRawParquetPath);

        // Create test CSV with duplicate event_ids: one with processed_at, one without
        var csvContent = @"sort_key,event_id,event_datetime,charge_id,processed_at
charge-1,event-1,2024-01-15T11:00:00Z,charge-1,
charge-1,event-1,2024-01-15T10:30:00Z,charge-1,2026-01-01 10:00:00.000 UTC
charge-2,event-2,2024-01-15T10:30:00Z,charge-2,";
        File.WriteAllText(manager.ChargesEventsRawCsvFile, csvContent);

        var jobId = "test-job-dedup-empty-processed-at";
        var reportId = "test-report-dedup-empty-processed-at";
        var reportDate = DateTime.Today;

        // Act
        manager.SortEventsByChargeId(jobId, reportId, reportDate, 4);

        // Assert
        var sortedLines = File.ReadAllLines(manager.ChargesEventsSortedByIdCsvFile);

        // Should only have 2 lines (one for each unique event_id)
        Assert.Equal(2, sortedLines.Length);

        // event-1 should prefer the one WITH processed_at (even though its event_datetime is older)
        var event1Line = sortedLines.First(l => l.Contains("event-1,"));
        Assert.Contains("2026-01-01 10:00:00.000 UTC", event1Line);
    }

    [Fact]
    public void SortEventsByChargeId_WhenProcessFails_ShouldThrowException()
    {
        // Arrange
        var invalidSettings = Substitute.For<IOptions<DataLayerReportsSettings>>();
        invalidSettings.Value.Returns(new DataLayerReportsSettings
        {
            BashPath = "/invalid/bash/path"
        });

        using var manager = new ChargeListReportManager(invalidSettings);
        _tempDirsToCleanup.Add(manager.ChargesEventsRawParquetPath);

        File.WriteAllText(manager.ChargesEventsRawCsvFile, "event_id,charge_id\nevent-1,charge-1");

        var jobId = "test-job-fail";
        var reportId = "test-report-fail";
        var reportDate = DateTime.Today;

        // Act & Assert - Should throw any exception when process fails to start
        var exception = Assert.ThrowsAny<Exception>(() =>
            manager.SortEventsByChargeId(jobId, reportId, reportDate, 4));

        Assert.NotNull(exception);
    }

    [Fact]
    public void SortEventsByChargeId_WithEmptyFile_ShouldCreateEmptyOutput()
    {
        // Arrange
        using var manager = new ChargeListReportManager(_settings);
        _tempDirsToCleanup.Add(manager.ChargesEventsRawParquetPath);

        // Create CSV with only header
        File.WriteAllText(manager.ChargesEventsRawCsvFile, "sort_key,event_id,event_datetime,charge_id\n");

        var jobId = "test-job-empty";
        var reportId = "test-report-empty";
        var reportDate = DateTime.Today;

        // Act
        manager.SortEventsByChargeId(jobId, reportId, reportDate, 4);

        // Assert
        Assert.True(File.Exists(manager.ChargesEventsSortedByIdCsvFile));
        var content = File.ReadAllText(manager.ChargesEventsSortedByIdCsvFile);
        Assert.Empty(content);
    }

    #endregion

    #region SortChargesByCreatedAt Tests

    [Fact]
    public void SortChargesByCreatedAt_WithValidData_ShouldCreateSortedFile()
    {
        // Arrange
        using var manager = new ChargeListReportManager(_settings);
        _tempDirsToCleanup.Add(manager.ChargesEventsRawParquetPath);

        // Create test CSV with charges (column 9 is created_at)
        var csvContent = @"charge-3,100,card,succeeded,org-1,acc-1,merch-1,doc-1,2024-01-13T10:00:00Z
charge-1,200,pix,succeeded,org-1,acc-1,merch-1,doc-1,2024-01-15T10:00:00Z
charge-2,150,boleto,pending,org-1,acc-1,merch-1,doc-1,2024-01-14T10:00:00Z";
        File.WriteAllText(manager.ChargesFilteredCsvFile, csvContent);

        var jobId = "test-job-sort";
        var reportId = "test-report-sort";
        var reportDate = DateTime.Today;
        var inputFilePath = manager.ChargesFilteredCsvFile;
        var createdAtColumnPosition = 9;

        // Act
        manager.SortChargesByCreatedAt(jobId, reportId, reportDate, inputFilePath, createdAtColumnPosition, ',');

        // Assert
        Assert.True(File.Exists(manager.ChargesSortedByCreatedAtCsvFile));
        var sortedContent = File.ReadAllText(manager.ChargesSortedByCreatedAtCsvFile);
        Assert.NotEmpty(sortedContent);
    }

    [Fact]
    public void SortChargesByCreatedAt_WhenProcessFails_ShouldThrowException()
    {
        // Arrange
        var invalidSettings = Substitute.For<IOptions<DataLayerReportsSettings>>();
        invalidSettings.Value.Returns(new DataLayerReportsSettings
        {
            BashPath = "/invalid/bash/path"
        });

        using var manager = new ChargeListReportManager(invalidSettings);
        _tempDirsToCleanup.Add(manager.ChargesEventsRawParquetPath);

        File.WriteAllText(manager.ChargesFilteredCsvFile, "charge-1,100,card,succeeded,org-1,acc-1,merch-1,doc-1,2024-01-15T10:00:00Z");

        var jobId = "test-job-fail";
        var reportId = "test-report-fail";
        var reportDate = DateTime.Today;
        var inputFilePath = manager.ChargesFilteredCsvFile;
        var createdAtColumnPosition = 9;

        // Act & Assert - Should throw any exception when process fails to start
        var exception = Assert.ThrowsAny<Exception>(() =>
            manager.SortChargesByCreatedAt(jobId, reportId, reportDate, inputFilePath, createdAtColumnPosition, ','));

        Assert.NotNull(exception);
    }

    [Fact]
    public void SortChargesByCreatedAt_WithEmptyFile_ShouldCreateEmptyOutput()
    {
        // Arrange
        using var manager = new ChargeListReportManager(_settings);
        _tempDirsToCleanup.Add(manager.ChargesEventsRawParquetPath);

        File.WriteAllText(manager.ChargesFilteredCsvFile, "");

        var jobId = "test-job-empty";
        var reportId = "test-report-empty";
        var reportDate = DateTime.Today;
        var inputFilePath = manager.ChargesFilteredCsvFile;
        var createdAtColumnPosition = 9;

        // Act
        manager.SortChargesByCreatedAt(jobId, reportId, reportDate, inputFilePath, createdAtColumnPosition, ',');

        // Assert
        Assert.True(File.Exists(manager.ChargesSortedByCreatedAtCsvFile));
    }

    #endregion

    #region ParquetPathHasFiles Tests

    [Fact]
    public void ParquetPathHasFiles_WhenDirectoryHasParquetFiles_ShouldReturnTrue()
    {
        // Arrange
        using var manager = new ChargeListReportManager(_settings);
        _tempDirsToCleanup.Add(manager.ChargesEventsRawParquetPath);

        // Create a parquet file
        var parquetFile = Path.Combine(manager.ChargesEventsRawParquetPath, "test.parquet");
        File.WriteAllText(parquetFile, "dummy parquet content");

        // Act
        var result = manager.ParquetPathHasFiles();

        // Assert
        Assert.True(result);
    }

    [Fact]
    public void ParquetPathHasFiles_WhenDirectoryIsEmpty_ShouldReturnFalse()
    {
        // Arrange
        using var manager = new ChargeListReportManager(_settings);
        _tempDirsToCleanup.Add(manager.ChargesEventsRawParquetPath);

        // Act
        var result = manager.ParquetPathHasFiles();

        // Assert
        Assert.False(result);
    }

    [Fact]
    public void ParquetPathHasFiles_WhenDirectoryHasNonParquetFiles_ShouldReturnFalse()
    {
        // Arrange
        using var manager = new ChargeListReportManager(_settings);
        _tempDirsToCleanup.Add(manager.ChargesEventsRawParquetPath);

        // Create non-parquet files
        var csvFile = Path.Combine(manager.ChargesEventsRawParquetPath, "test.csv");
        var txtFile = Path.Combine(manager.ChargesEventsRawParquetPath, "test.txt");
        File.WriteAllText(csvFile, "csv content");
        File.WriteAllText(txtFile, "txt content");

        // Act
        var result = manager.ParquetPathHasFiles();

        // Assert
        Assert.False(result);
    }

    [Fact]
    public void ParquetPathHasFiles_WhenDirectoryDoesNotExist_ShouldReturnFalse()
    {
        // Arrange
        using var manager = new ChargeListReportManager(_settings);

        // Delete the directory
        Directory.Delete(manager.ChargesEventsRawParquetPath, true);

        // Act
        var result = manager.ParquetPathHasFiles();

        // Assert
        Assert.False(result);
    }

    [Fact]
    public void ParquetPathHasFiles_WithMultipleParquetFiles_ShouldReturnTrue()
    {
        // Arrange
        using var manager = new ChargeListReportManager(_settings);
        _tempDirsToCleanup.Add(manager.ChargesEventsRawParquetPath);

        // Create multiple parquet files
        for (int i = 0; i < 5; i++)
        {
            var parquetFile = Path.Combine(manager.ChargesEventsRawParquetPath, $"test-{i}.parquet");
            File.WriteAllText(parquetFile, $"dummy parquet content {i}");
        }

        // Act
        var result = manager.ParquetPathHasFiles();

        // Assert
        Assert.True(result);
    }

    #endregion

    #region TryDeleteParquetPath Tests

    [Fact]
    public void TryDeleteParquetPath_WhenDirectoryExists_ShouldDeleteDirectory()
    {
        // Arrange
        using var manager = new ChargeListReportManager(_settings);
        var parquetPath = manager.ChargesEventsRawParquetPath;

        // Create some files in the directory
        var testFile = Path.Combine(parquetPath, "test.parquet");
        File.WriteAllText(testFile, "test content");

        // Act
        manager.TryDeleteParquetPath();

        // Assert
        Assert.False(Directory.Exists(parquetPath));
    }

    [Fact]
    public void TryDeleteParquetPath_WhenDirectoryDoesNotExist_ShouldNotThrow()
    {
        // Arrange
        using var manager = new ChargeListReportManager(_settings);
        var parquetPath = manager.ChargesEventsRawParquetPath;

        // Delete directory first
        Directory.Delete(parquetPath, true);

        // Act & Assert - Should not throw
        manager.TryDeleteParquetPath();
    }

    [Fact]
    public void TryDeleteParquetPath_WithNestedDirectories_ShouldDeleteRecursively()
    {
        // Arrange
        using var manager = new ChargeListReportManager(_settings);
        var parquetPath = manager.ChargesEventsRawParquetPath;

        // Create nested structure
        var subDir = Path.Combine(parquetPath, "subdir");
        Directory.CreateDirectory(subDir);
        File.WriteAllText(Path.Combine(subDir, "nested.parquet"), "nested content");
        File.WriteAllText(Path.Combine(parquetPath, "root.parquet"), "root content");

        // Act
        manager.TryDeleteParquetPath();

        // Assert
        Assert.False(Directory.Exists(parquetPath));
    }

    #endregion

    #region TryDeleteFile Tests

    [Fact]
    public void TryDeleteFile_WhenFileExists_ShouldDeleteFile()
    {
        // Arrange
        using var manager = new ChargeListReportManager(_settings);
        _tempDirsToCleanup.Add(manager.ChargesEventsRawParquetPath);

        var testFile = Path.GetTempFileName();
        File.WriteAllText(testFile, "test content");

        // Act
        manager.TryDeleteFile(testFile);

        // Assert
        Assert.False(File.Exists(testFile));
    }

    [Fact]
    public void TryDeleteFile_WhenFileDoesNotExist_ShouldNotThrow()
    {
        // Arrange
        using var manager = new ChargeListReportManager(_settings);
        _tempDirsToCleanup.Add(manager.ChargesEventsRawParquetPath);

        var nonExistentFile = Path.Combine(Path.GetTempPath(), $"non-existent-{Guid.NewGuid()}.txt");

        // Act & Assert - Should not throw
        manager.TryDeleteFile(nonExistentFile);
    }

    [Fact]
    public void TryDeleteFile_WithNullPath_ShouldNotThrow()
    {
        // Arrange
        using var manager = new ChargeListReportManager(_settings);
        _tempDirsToCleanup.Add(manager.ChargesEventsRawParquetPath);

        // Act & Assert - Should not throw
        manager.TryDeleteFile(null!);
    }

    #endregion

    #region Dispose Tests

    [Fact]
    public void Dispose_ShouldDeleteAllTempFiles()
    {
        // Arrange
        var manager = new ChargeListReportManager(_settings);
        var parquetPath = manager.ChargesEventsRawParquetPath;
        var csvFile = manager.ChargesEventsRawCsvFile;
        var sortedFile = manager.ChargesEventsSortedByIdCsvFile;
        var rawFile = manager.ChargesRawCsvFile;
        var filteredFile = manager.ChargesFilteredCsvFile;
        var sortedByCreatedFile = manager.ChargesSortedByCreatedAtCsvFile;

        // Create some content in files
        File.WriteAllText(csvFile, "test");
        File.WriteAllText(sortedFile, "test");
        File.WriteAllText(rawFile, "test");
        File.WriteAllText(filteredFile, "test");
        File.WriteAllText(sortedByCreatedFile, "test");

        // Act
        manager.Dispose();

        // Assert
        Assert.False(Directory.Exists(parquetPath));
        Assert.False(File.Exists(csvFile));
        Assert.False(File.Exists(sortedFile));
        Assert.False(File.Exists(rawFile));
        Assert.False(File.Exists(filteredFile));
        Assert.False(File.Exists(sortedByCreatedFile));
    }

    [Fact]
    public void Dispose_WhenCalledMultipleTimes_ShouldNotThrow()
    {
        // Arrange
        var manager = new ChargeListReportManager(_settings);

        // Act & Assert - Should not throw
        manager.Dispose();
        manager.Dispose();
        manager.Dispose();
    }

    [Fact]
    public void Dispose_WhenFilesAlreadyDeleted_ShouldNotThrow()
    {
        // Arrange
        var manager = new ChargeListReportManager(_settings);

        // Manually delete everything first
        manager.TryDeleteParquetPath();
        manager.TryDeleteFile(manager.ChargesEventsRawCsvFile);
        manager.TryDeleteFile(manager.ChargesEventsSortedByIdCsvFile);
        manager.TryDeleteFile(manager.ChargesRawCsvFile);
        manager.TryDeleteFile(manager.ChargesFilteredCsvFile);
        manager.TryDeleteFile(manager.ChargesSortedByCreatedAtCsvFile);

        // Act & Assert - Should not throw
        manager.Dispose();
    }

    #endregion

    #region Integration Tests

    [Fact]
    public void CompleteFlow_SortAndCleanup_ShouldWorkCorrectly()
    {
        // Arrange
        var manager = new ChargeListReportManager(_settings);
        var parquetPath = manager.ChargesEventsRawParquetPath;

        // Create test data
        var csvContent = @"event_id,event_datetime,charge_id
event-1,2024-01-15T10:30:00Z,charge-1
event-2,2024-01-15T10:30:00Z,charge-2";
        File.WriteAllText(manager.ChargesEventsRawCsvFile, csvContent);

        var jobId = "integration-job";
        var reportId = "integration-report";
        var reportDate = DateTime.Today;

        // Act - Sort events
        manager.SortEventsByChargeId(jobId, reportId, reportDate, 4);

        // Assert - Sorted file should exist
        Assert.True(File.Exists(manager.ChargesEventsSortedByIdCsvFile));

        // Act - Create filtered charges
        var chargesContent = "charge-1,100,card,succeeded,org-1,acc-1,merch-1,doc-1,2024-01-15T10:00:00Z";
        File.WriteAllText(manager.ChargesFilteredCsvFile, chargesContent);

        // Act - Sort charges
        manager.SortChargesByCreatedAt(jobId, reportId, reportDate, manager.ChargesFilteredCsvFile, 8, ',');

        // Assert - Final sorted file should exist
        Assert.True(File.Exists(manager.ChargesSortedByCreatedAtCsvFile));

        // Act - Cleanup
        manager.Dispose();

        // Assert - All files should be deleted
        Assert.False(Directory.Exists(parquetPath));
        Assert.False(File.Exists(manager.ChargesEventsRawCsvFile));
        Assert.False(File.Exists(manager.ChargesEventsSortedByIdCsvFile));
        Assert.False(File.Exists(manager.ChargesFilteredCsvFile));
        Assert.False(File.Exists(manager.ChargesSortedByCreatedAtCsvFile));
    }

    #endregion

    #region Test Cleanup

    public void Dispose()
    {
        // Cleanup any remaining test files and directories
        foreach (var file in _tempFilesToCleanup)
        {
            try
            {
                if (File.Exists(file))
                    File.Delete(file);
            }
            catch { /* Best effort cleanup */ }
        }

        foreach (var dir in _tempDirsToCleanup)
        {
            try
            {
                if (Directory.Exists(dir))
                    Directory.Delete(dir, true);
            }
            catch { /* Best effort cleanup */ }
        }

        if (Directory.Exists(_testTempDir))
        {
            try
            {
                Directory.Delete(_testTempDir, true);
            }
            catch { /* Best effort cleanup */ }
        }
    }

    #endregion
}

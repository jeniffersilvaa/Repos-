using PaymentsDataLayerReports.Application.Services.DeltaTableColumnMapping;
using PaymentsDataLayerReports.Application.Services.DeltaTablePartitionBuilder;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.ChargeReportS3Worker.Utils;

public class ReportQueryFiltersTests
{
    [Fact]
    public void BuildBaseFilters_WithBasicFilters_ShouldReturnExpectedClauses()
    {
        // Arrange
        var reportInput = TestDataFactory.CreateGenerateReportInput(
            partitionSet: new DeltaTablePartitionSet
            {
                PartitionIdReferenceType = "document",
                PartitionIdReferences = [" doc-1 ", "doc-2"],
                Partitions = [new DeltaTablePartition("charges_events_by_created_at", "p-1")]
            },
            organizations: "org-1,org-2",
            accountId: "acc-1,acc-2",
            paymentMethods: "credit_card,pix",
            affiliationCodes: "aff-1,aff-2",
            startDate: new DateTimeOffset(2026, 03, 01, 0, 0, 0, TimeSpan.Zero).UtcDateTime,
            endDate: new DateTimeOffset(2026, 03, 02, 23, 59, 59, TimeSpan.Zero).UtcDateTime);

        var parameters = reportInput.ReportMetadata.ChargeReportParameters!;

        // Act
        var filters = ReportQueryFilters.BuildBaseFilters(reportInput, ["sale", "refund"]);

        // Assert
        Assert.Contains($"created_at::TIMESTAMPTZ >= '{parameters.StartDate:o}'::TIMESTAMPTZ", filters);
        Assert.Contains($"created_at::TIMESTAMPTZ <= '{parameters.EndDate:o}'::TIMESTAMPTZ", filters);
        Assert.Contains("merchant__document IN ('doc-1','doc-2')", filters);
        Assert.Contains("merchant__organization IN ('org-1','org-2')", filters);
        Assert.Contains("merchant__account_id IN ('acc-1','acc-2')", filters);
        Assert.Contains("payment_method IN ('credit_card','pix')", filters);
        Assert.Contains("merchant__affiliation_code IN ('aff-1','aff-2')", filters);
        Assert.Contains("(card_transaction__financial_movement__category IS NULL OR card_transaction__financial_movement__category = '' OR card_transaction__financial_movement__category IN ('sale','refund'))", filters);
        Assert.Contains("(boleto_transaction__financial_movement__category IS NULL OR boleto_transaction__financial_movement__category = '' OR boleto_transaction__financial_movement__category IN ('sale','refund'))", filters);
        Assert.Contains("(pix_transaction__financial_movement__category IS NULL OR pix_transaction__financial_movement__category = '' OR pix_transaction__financial_movement__category IN ('sale','refund'))", filters);
    }

    [Fact]
    public void BuildBaseFilters_WhenRealTime_ShouldSkipSandboxFilter()
    {
        // Arrange
        var reportInput = TestDataFactory.CreateGenerateReportInput();
        reportInput.ReportMetadata.ChargeReportParameters!.IsSandbox = true;

        // Act
        var filters = ReportQueryFilters.BuildBaseFilters(reportInput, [], isRealTime: true);

        // Assert
        Assert.DoesNotContain("merchant__is_sandbox = true", filters);
    }

    [Fact]
    public void BuildBaseFilters_WithColumnMapping_ShouldUseMappedColumns()
    {
        // Arrange
        var reportInput = TestDataFactory.CreateGenerateReportInput(organizations: "org-1", paymentMethods: "pix");
        var columnMapping = new ColumnMapping
        {
            TableName = "charges_events_by_created_at",
            ColumnMappings = new Dictionary<string, string>
            {
                ["merchant__document"] = "merchant-document",
                ["merchant__organization"] = "merchant-organization",
                ["payment_method"] = "payment-method",
                ["card_transaction__financial_movement__category"] = "card-category",
                ["boleto_transaction__financial_movement__category"] = "boleto-category",
                ["pix_transaction__financial_movement__category"] = "pix-category"
            }
        };

        // Act
        var filters = ReportQueryFilters.BuildBaseFilters(reportInput, ["sale"], columnMapping);

        // Assert
        Assert.Contains("\"merchant-document\" IN ('org-123','org-456')", filters);
        Assert.Contains("\"merchant-organization\" IN ('org-1')", filters);
        Assert.Contains("\"payment-method\" IN ('pix')", filters);
        Assert.Contains("(\"card-category\" IS NULL OR \"card-category\" = '' OR \"card-category\" IN ('sale'))", filters);
        Assert.Contains("(\"boleto-category\" IS NULL OR \"boleto-category\" = '' OR \"boleto-category\" IN ('sale'))", filters);
        Assert.Contains("(\"pix-category\" IS NULL OR \"pix-category\" = '' OR \"pix-category\" IN ('sale'))", filters);
    }

    [Fact]
    public void BuildBaseFilters_WithStoneAccountIdentity_ShouldIncludeOneStoneFilter()
    {
        // Arrange
        var reportInput = TestDataFactory.CreateGenerateReportInput(organizations: string.Empty);
        var parameters = reportInput.ReportMetadata.ChargeReportParameters!;
        parameters.StoneAccounts = "stone-1,stone-2";
        parameters.PoiTypes = "pos";
        parameters.PaymentProfiles = "profile-a,profile-b";

        // Act
        var filters = ReportQueryFilters.BuildBaseFilters(reportInput, []);

        // Assert
        Assert.Contains("merchant__stone_account IN ('stone-1','stone-2') AND point_of_interaction_type IN ('pos') AND merchant__payment_profile_id IN ('profile-a','profile-b')", filters);
    }

    [Fact]
    public void BuildBaseFilters_WithoutIdentityFilters_ShouldNotAddEmptyClause()
    {
        // Arrange
        var reportInput = TestDataFactory.CreateGenerateReportInput(organizations: string.Empty);
        var parameters = reportInput.ReportMetadata.ChargeReportParameters!;
        parameters.StoneAccounts = null;
        parameters.PoiTypes = null;
        parameters.PaymentProfiles = null;

        // Act
        var filters = ReportQueryFilters.BuildBaseFilters(reportInput, []);

        // Assert
        Assert.DoesNotContain(string.Empty, filters);
    }

    [Fact]
    public void BuildBaseFilters_WithEmptyAllowedCategories_ShouldOmitCategoryFilters()
    {
        // Arrange
        var reportInput = TestDataFactory.CreateGenerateReportInput();

        // Act
        var filters = ReportQueryFilters.BuildBaseFilters(reportInput, []);

        // Assert
        Assert.DoesNotContain(filters, clause => clause.Contains("financial_movement__category", StringComparison.Ordinal));
    }

    [Fact]
    public void BuildBaseFilters_WithInvalidPartitionType_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var reportInput = TestDataFactory.CreateGenerateReportInput(
            partitionSet: new DeltaTablePartitionSet
            {
                PartitionIdReferenceType = "invalid",
                PartitionIdReferences = ["value-1"],
                Partitions = [new DeltaTablePartition("charges_events_by_created_at", "p-1")]
            });

        // Act
        var action = () => ReportQueryFilters.BuildBaseFilters(reportInput, []);

        // Assert
        var exception = Assert.Throws<InvalidOperationException>(action);
        Assert.Equal("Unknown PartitionIdReferenceType: invalid", exception.Message);
    }
}
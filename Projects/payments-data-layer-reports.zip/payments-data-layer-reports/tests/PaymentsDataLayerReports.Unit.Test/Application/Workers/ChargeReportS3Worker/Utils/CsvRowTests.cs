using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.ChargeReportS3Worker.Utils;

public class CsvRowTests
{
    #region Constructor Tests

    [Fact]
    public void Constructor_WithFieldCount_ShouldInitializeEmptyArray()
    {
        // Arrange & Act
        var csvRow = new CsvRow(5);

        // Assert - All fields should be null initially
        var index = new Dictionary<string, int> { { "field0", 0 }, { "field1", 1 } };
        Assert.Null(csvRow.GetField(index, "field0"));
        Assert.Null(csvRow.GetField(index, "field1"));
    }

    [Fact]
    public void Constructor_WithDefaultValues_ShouldDeepCopyValues()
    {
        // Arrange
        var defaultValues = new object?[] { "value1", 42, null, "value4" };

        // Act
        var csvRow = new CsvRow(defaultValues);

        // Assert - Verify values are copied
        var index = new Dictionary<string, int>
        {
            { "field0", 0 },
            { "field1", 1 },
            { "field2", 2 },
            { "field3", 3 }
        };

        Assert.Equal("value1", csvRow.GetField(index, "field0"));
        Assert.Equal(42, csvRow.GetField(index, "field1"));
        Assert.Null(csvRow.GetField(index, "field2"));
        Assert.Equal("value4", csvRow.GetField(index, "field3"));
    }

    [Fact]
    public void Constructor_WithDefaultValues_ShouldNotShareReferenceWithOriginalArray()
    {
        // Arrange
        var defaultValues = new object?[] { "original" };
        var csvRow = new CsvRow(defaultValues);

        // Act - Modify original array
        defaultValues[0] = "modified";

        // Assert - CsvRow should still have original value (deep copy)
        var index = new Dictionary<string, int> { { "field0", 0 } };
        Assert.Equal("original", csvRow.GetField(index, "field0"));
    }

    [Fact]
    public void Constructor_WithEmptyDefaultValues_ShouldInitializeEmptyRow()
    {
        // Arrange & Act
        var csvRow = new CsvRow(Array.Empty<object?>());

        // Assert
        var result = csvRow.ToString();
        Assert.Equal(string.Empty, result);
    }

    #endregion

    #region SetField Tests

    [Fact]
    public void SetField_WithValidIndexAndValue_ShouldSetField()
    {
        // Arrange
        var csvRow = new CsvRow(3);

        // Act
        csvRow.SetField(0, "test");
        csvRow.SetField(1, 123);
        csvRow.SetField(2, 45.67m);

        // Assert
        var index = new Dictionary<string, int>
        {
            { "field0", 0 },
            { "field1", 1 },
            { "field2", 2 }
        };

        Assert.Equal("test", csvRow.GetField(index, "field0"));
        Assert.Equal(123, csvRow.GetField(index, "field1"));
        Assert.Equal(45.67m, csvRow.GetField(index, "field2"));
    }

    [Fact]
    public void SetField_WithNullValue_ShouldNotSetField()
    {
        // Arrange
        var csvRow = new CsvRow(2);
        csvRow.SetField(0, "initial");

        // Act
        csvRow.SetField(0, null);

        // Assert - Field should remain unchanged when setting null
        var index = new Dictionary<string, int> { { "field0", 0 } };
        Assert.Equal("initial", csvRow.GetField(index, "field0"));
    }

    [Fact]
    public void SetField_WithIndexOutOfBounds_ShouldNotSetValue()
    {
        // Arrange
        var csvRow = new CsvRow(2);
        csvRow.SetField(0, "initial");

        // Act & Assert - Index out of bounds should be ignored (>= length)
        csvRow.SetField(5, "value");

        // Verify original value is unchanged
        var index = new Dictionary<string, int> { { "field0", 0 } };
        Assert.Equal("initial", csvRow.GetField(index, "field0"));
    }

    [Fact]
    public void SetField_WithIndexAtBoundary_ShouldSetCorrectly()
    {
        // Arrange
        var csvRow = new CsvRow(3);

        // Act
        csvRow.SetField(0, "first");
        csvRow.SetField(2, "last");

        // Assert
        var index = new Dictionary<string, int>
        {
            { "first", 0 },
            { "last", 2 }
        };

        Assert.Equal("first", csvRow.GetField(index, "first"));
        Assert.Equal("last", csvRow.GetField(index, "last"));
    }

    [Fact]
    public void SetField_OverwritingExistingValue_ShouldReplaceValue()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "original");

        // Act
        csvRow.SetField(0, "updated");

        // Assert
        var index = new Dictionary<string, int> { { "field0", 0 } };
        Assert.Equal("updated", csvRow.GetField(index, "field0"));
    }

    #endregion

    #region GetField (Non-Generic) Tests

    [Fact]
    public void GetField_WithValidKey_ShouldReturnValue()
    {
        // Arrange
        var csvRow = new CsvRow(2);
        csvRow.SetField(0, "value1");
        csvRow.SetField(1, "value2");
        var index = new Dictionary<string, int>
        {
            { "key1", 0 },
            { "key2", 1 }
        };

        // Act
        var result1 = csvRow.GetField(index, "key1");
        var result2 = csvRow.GetField(index, "key2");

        // Assert
        Assert.Equal("value1", result1);
        Assert.Equal("value2", result2);
    }

    [Fact]
    public void GetField_WithNonExistentKey_ShouldReturnNull()
    {
        // Arrange
        var csvRow = new CsvRow(2);
        csvRow.SetField(0, "value");
        var index = new Dictionary<string, int> { { "key1", 0 } };

        // Act
        var result = csvRow.GetField(index, "nonExistentKey");

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public void GetField_WithEmptyIndex_ShouldReturnNull()
    {
        // Arrange
        var csvRow = new CsvRow(2);
        csvRow.SetField(0, "value");
        var index = new Dictionary<string, int>();

        // Act
        var result = csvRow.GetField(index, "anyKey");

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public void GetField_WithNullFieldValue_ShouldReturnNull()
    {
        // Arrange
        var csvRow = new CsvRow(2);
        // Field at index 0 is null by default
        var index = new Dictionary<string, int> { { "key1", 0 } };

        // Act
        var result = csvRow.GetField(index, "key1");

        // Assert
        Assert.Null(result);
    }

    #endregion

    #region GetField<T> - String Tests

    [Fact]
    public void GetFieldGeneric_String_WithValidValue_ShouldReturnString()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "test string");
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<string>(index, "field");

        // Assert
        Assert.Equal("test string", result);
    }

    [Fact]
    public void GetFieldGeneric_String_WithNumericValue_ShouldConvertToString()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, 123);
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<string>(index, "field");

        // Assert
        Assert.Equal("123", result);
    }

    [Fact]
    public void GetFieldGeneric_String_WithNullValue_ShouldReturnNull()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<string>(index, "field");

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public void GetFieldGeneric_String_WithNonExistentKey_ShouldReturnNull()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "value");
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<string>(index, "nonExistent");

        // Assert
        Assert.Null(result);
    }

    #endregion

    #region GetField<T> - Int Tests

    [Fact]
    public void GetFieldGeneric_Int_WithValidIntString_ShouldReturnInt()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "123");
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<int>(index, "field");

        // Assert
        Assert.Equal(123, result);
    }

    [Fact]
    public void GetFieldGeneric_Int_WithNegativeIntString_ShouldReturnNegativeInt()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "-456");
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<int>(index, "field");

        // Assert
        Assert.Equal(-456, result);
    }

    [Fact]
    public void GetFieldGeneric_Int_WithInvalidString_ShouldReturnNull()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "not a number");
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<int?>(index, "field");

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public void GetFieldGeneric_Int_WithNullValue_ShouldReturnNull()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<int?>(index, "field");

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public void GetFieldGeneric_NullableInt_WithValidValue_ShouldReturnInt()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "789");
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<int?>(index, "field");

        // Assert
        Assert.Equal(789, result);
    }

    [Fact]
    public void GetFieldGeneric_Int_WithZero_ShouldReturnZero()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "0");
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<int>(index, "field");

        // Assert
        Assert.Equal(0, result);
    }

    [Fact]
    public void GetFieldGeneric_Int_WithWhitespace_ShouldReturnNull()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "   ");
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<int?>(index, "field");

        // Assert
        Assert.Null(result);
    }

    #endregion

    #region GetField<T> - Decimal Tests

    [Fact]
    public void GetFieldGeneric_Decimal_WithValidDecimalString_ShouldReturnDecimal()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "123.45");
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<decimal>(index, "field");

        // Assert
        Assert.Equal(123.45m, result);
    }

    [Fact]
    public void GetFieldGeneric_Decimal_WithNegativeDecimal_ShouldReturnNegativeDecimal()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "-456.78");
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<decimal>(index, "field");

        // Assert
        Assert.Equal(-456.78m, result);
    }

    [Fact]
    public void GetFieldGeneric_Decimal_WithInvalidString_ShouldReturnNull()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "not a decimal");
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<decimal?>(index, "field");

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public void GetFieldGeneric_Decimal_WithNullValue_ShouldReturnNull()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<decimal?>(index, "field");

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public void GetFieldGeneric_NullableDecimal_WithValidValue_ShouldReturnDecimal()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "999.99");
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<decimal?>(index, "field");

        // Assert
        Assert.Equal(999.99m, result);
    }

    [Fact]
    public void GetFieldGeneric_Decimal_WithIntegerValue_ShouldReturnDecimal()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "100");
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<decimal>(index, "field");

        // Assert
        Assert.Equal(100m, result);
    }

    [Fact]
    public void GetFieldGeneric_Decimal_WithZero_ShouldReturnZero()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "0.00");
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<decimal>(index, "field");

        // Assert
        Assert.Equal(0m, result);
    }

    #endregion

    #region GetField<T> - DateTime Tests

    [Fact]
    public void GetFieldGeneric_DateTime_WithValidDateTimeString_ShouldReturnDateTime()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        var expectedDate = new DateTime(2023, 12, 25, 10, 30, 0);
        csvRow.SetField(0, expectedDate.ToString());
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<DateTime?>(index, "field");

        // Assert
        Assert.NotNull(result);
        Assert.Equal(expectedDate.Date, result!.Value.Date);
    }

    [Fact]
    public void GetFieldGeneric_DateTime_WithIso8601Format_ShouldReturnDateTime()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "2023-12-25T10:30:00");
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<DateTime?>(index, "field");

        // Assert
        Assert.NotNull(result);
        Assert.Equal(new DateTime(2023, 12, 25, 10, 30, 0), result!.Value);
    }

    [Fact]
    public void GetFieldGeneric_DateTime_WithInvalidString_ShouldReturnNull()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "not a date");
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<DateTime?>(index, "field");

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public void GetFieldGeneric_DateTime_WithNullValue_ShouldReturnNull()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<DateTime?>(index, "field");

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public void GetFieldGeneric_NullableDateTime_WithValidValue_ShouldReturnDateTime()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "2023-01-01");
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<DateTime?>(index, "field");

        // Assert
        Assert.NotNull(result);
        Assert.Equal(new DateTime(2023, 1, 1), result!.Value);
    }

    [Fact]
    public void GetFieldGeneric_DateTime_WithDateOnly_ShouldReturnDateTime()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "2023-06-15");
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<DateTime?>(index, "field");

        // Assert
        Assert.NotNull(result);
        Assert.Equal(new DateTime(2023, 6, 15), result!.Value);
    }

    #endregion

    #region GetField<T> - Bool Tests

    [Fact]
    public void GetFieldGeneric_Bool_WithTrueString_ShouldReturnTrue()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "true");
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<bool?>(index, "field");

        // Assert
        Assert.NotNull(result);
        Assert.True(result!.Value);
    }

    [Fact]
    public void GetFieldGeneric_Bool_WithFalseString_ShouldReturnFalse()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "false");
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<bool?>(index, "field");

        // Assert
        Assert.NotNull(result);
        Assert.False(result!.Value);
    }

    [Fact]
    public void GetFieldGeneric_Bool_WithInvalidString_ShouldReturnNull()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "not a boolean");
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<bool?>(index, "field");

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public void GetFieldGeneric_NullableBool_WithTrueString_ShouldReturnTrue()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "True");
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<bool?>(index, "field");

        // Assert
        Assert.NotNull(result);
        Assert.True(result!.Value);
    }

    [Fact]
    public void GetFieldGeneric_NullableBool_WithFalseString_ShouldReturnFalse()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "False");
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<bool?>(index, "field");

        // Assert
        Assert.NotNull(result);
        Assert.False(result!.Value);
    }

    [Fact]
    public void GetFieldGeneric_NullableBool_WithInvalidString_ShouldReturnNull()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "invalid");
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<bool?>(index, "field");

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public void GetFieldGeneric_NullableBool_WithNullValue_ShouldReturnNull()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act
        var result = csvRow.GetField<bool?>(index, "field");

        // Assert
        Assert.Null(result);
    }

    #endregion

    #region GetField<T> - Unsupported Type Tests

    [Fact]
    public void GetFieldGeneric_UnsupportedType_ShouldThrowNotImplementedException()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "value");
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act & Assert
        var exception = Assert.Throws<NotImplementedException>(() =>
            csvRow.GetField<double>(index, "field"));

        Assert.Contains("GetField<Double>", exception.Message);
        Assert.Contains("not implemented", exception.Message);
    }

    [Fact]
    public void GetFieldGeneric_CustomClass_ShouldThrowNotImplementedException()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "value");
        var index = new Dictionary<string, int> { { "field", 0 } };

        // Act & Assert
        var exception = Assert.Throws<NotImplementedException>(() =>
            csvRow.GetField<CustomTestClass>(index, "field"));

        Assert.Contains("GetField<CustomTestClass>", exception.Message);
    }

    #endregion

    #region ClearRow Tests

    [Fact]
    public void ClearRow_WithoutParameters_ShouldClearAllFields()
    {
        // Arrange
        var csvRow = new CsvRow(3);
        csvRow.SetField(0, "value1");
        csvRow.SetField(1, "value2");
        csvRow.SetField(2, "value3");

        // Act
        csvRow.ClearRow();

        // Assert
        var index = new Dictionary<string, int>
        {
            { "field0", 0 },
            { "field1", 1 },
            { "field2", 2 }
        };

        Assert.Null(csvRow.GetField(index, "field0"));
        Assert.Null(csvRow.GetField(index, "field1"));
        Assert.Null(csvRow.GetField(index, "field2"));
    }

    [Fact]
    public void ClearRow_WithDefaultValues_ShouldResetToDefaultValues()
    {
        // Arrange
        var defaultValues = new object?[] { "default1", 100, "default3" };
        var csvRow = new CsvRow(3);
        csvRow.SetField(0, "changed1");
        csvRow.SetField(1, "changed2");
        csvRow.SetField(2, "changed3");

        // Act
        csvRow.ClearRow(defaultValues);

        // Assert
        var index = new Dictionary<string, int>
        {
            { "field0", 0 },
            { "field1", 1 },
            { "field2", 2 }
        };

        Assert.Equal("default1", csvRow.GetField(index, "field0"));
        Assert.Equal(100, csvRow.GetField(index, "field1"));
        Assert.Equal("default3", csvRow.GetField(index, "field2"));
    }

    [Fact]
    public void ClearRow_WithDefaultValues_ShouldDeepCopyValues()
    {
        // Arrange
        var dict = new Dictionary<string, object> { { "key", "value" } };
        var defaultValues = new object?[] { dict };
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "changed");

        // Act
        csvRow.ClearRow(defaultValues);

        // Modify original dictionary
        dict["key"] = "modified";

        // Assert - CsvRow should have a deep copy (may be JsonElement after deserialization)
        var index = new Dictionary<string, int> { { "field0", 0 } };
        var retrievedValue = csvRow.GetField(index, "field0");
        Assert.NotNull(retrievedValue);
        // The deep copy uses JSON serialization, so the type may change to JsonElement
        // What matters is that modifying the original doesn't affect the copy
        Assert.NotSame(dict, retrievedValue);
    }

    [Fact]
    public void ClearRow_WithNullDefaultValues_ShouldSetFieldsToNull()
    {
        // Arrange
        var defaultValues = new object?[] { null, null, null };
        var csvRow = new CsvRow(3);
        csvRow.SetField(0, "value1");
        csvRow.SetField(1, "value2");
        csvRow.SetField(2, "value3");

        // Act
        csvRow.ClearRow(defaultValues);

        // Assert
        var index = new Dictionary<string, int>
        {
            { "field0", 0 },
            { "field1", 1 },
            { "field2", 2 }
        };

        Assert.Null(csvRow.GetField(index, "field0"));
        Assert.Null(csvRow.GetField(index, "field1"));
        Assert.Null(csvRow.GetField(index, "field2"));
    }

    #endregion

    #region ToString Tests

    [Fact]
    public void ToString_WithSimpleValues_ShouldReturnCommaSeparatedString()
    {
        // Arrange
        var csvRow = new CsvRow(3);
        csvRow.SetField(0, "value1");
        csvRow.SetField(1, "value2");
        csvRow.SetField(2, "value3");

        // Act
        var result = csvRow.ToString();

        // Assert
        Assert.Equal("value1,value2,value3", result);
    }

    [Fact]
    public void ToString_WithNullFields_ShouldReturnEmptyStringsForNulls()
    {
        // Arrange
        var csvRow = new CsvRow(3);
        csvRow.SetField(0, "value1");
        // Field 1 is null
        csvRow.SetField(2, "value3");

        // Act
        var result = csvRow.ToString();

        // Assert
        Assert.Equal("value1,,value3", result);
    }

    [Fact]
    public void ToString_WithAllNullFields_ShouldReturnEmptyStrings()
    {
        // Arrange
        var csvRow = new CsvRow(3);

        // Act
        var result = csvRow.ToString();

        // Assert
        Assert.Equal(",,", result);
    }

    [Fact]
    public void ToString_WithValuesContainingCommas_ShouldEscapeWithQuotes()
    {
        // Arrange
        var csvRow = new CsvRow(2);
        csvRow.SetField(0, "value,with,commas");
        csvRow.SetField(1, "normal");

        // Act
        var result = csvRow.ToString();

        // Assert
        Assert.Equal("\"value,with,commas\",normal", result);
    }

    [Fact]
    public void ToString_WithValuesContainingQuotes_ShouldEscapeQuotes()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "value\"with\"quotes");

        // Act
        var result = csvRow.ToString();

        // Assert
        Assert.Equal("\"value\"\"with\"\"quotes\"", result);
    }

    [Fact]
    public void ToString_WithValuesContainingNewlines_ShouldEscapeWithQuotes()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "value\nwith\nnewlines");

        // Act
        var result = csvRow.ToString();

        // Assert
        Assert.Equal("\"value\nwith\nnewlines\"", result);
    }

    [Fact]
    public void ToString_WithDictionary_ShouldSerializeAsJson()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        var dict = new Dictionary<string, object>
        {
            { "key1", "value1" },
            { "key2", 123 }
        };
        csvRow.SetField(0, dict);

        // Act
        var result = csvRow.ToString();

        // Assert - Should contain JSON representation with snake_case keys
        Assert.Contains("key1", result);
        Assert.Contains("value1", result);
        Assert.Contains("key2", result);
        Assert.Contains("123", result);
    }

    [Fact]
    public void ToString_WithListOfDictionaries_ShouldSerializeAsJsonArray()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        var list = new List<IDictionary<string, object>>
        {
            new Dictionary<string, object> { { "key1", "value1" } },
            new Dictionary<string, object> { { "key2", "value2" } }
        };
        csvRow.SetField(0, list);

        // Act
        var result = csvRow.ToString();

        // Assert - Should contain JSON array representation
        Assert.Contains("[", result);
        Assert.Contains("]", result);
        Assert.Contains("key1", result);
        Assert.Contains("value1", result);
    }

    [Fact]
    public void ToString_WithMixedTypes_ShouldHandleAllTypes()
    {
        // Arrange
        var csvRow = new CsvRow(5);
        csvRow.SetField(0, "string");
        csvRow.SetField(1, 123);
        csvRow.SetField(2, 45.67m);
        csvRow.SetField(3, new DateTime(2023, 1, 1));
        // Field 4 is null

        // Act
        var result = csvRow.ToString();

        // Assert - Check that all values are present (locale-independent)
        Assert.StartsWith("string,123,", result);
        Assert.Contains("45", result); // Decimal contains 45 regardless of separator
        Assert.Contains("67", result); // Decimal contains 67 regardless of separator
        Assert.Contains("2023", result); // DateTime contains year
        Assert.EndsWith(",", result); // Ends with comma for the null field
    }

    [Fact]
    public void ToString_WithEmptyRow_ShouldReturnEmptyString()
    {
        // Arrange
        var csvRow = new CsvRow(0);

        // Act
        var result = csvRow.ToString();

        // Assert
        Assert.Equal(string.Empty, result);
    }

    [Fact]
    public void ToString_WithSingleField_ShouldReturnValueWithoutComma()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        csvRow.SetField(0, "single");

        // Act
        var result = csvRow.ToString();

        // Assert
        Assert.Equal("single", result);
    }

    [Fact]
    public void ToString_WithComplexJsonInDictionary_ShouldEscapeCorrectly()
    {
        // Arrange
        var csvRow = new CsvRow(1);
        var dict = new Dictionary<string, object>
        {
            { "complex_key", "value,with,commas" }
        };
        csvRow.SetField(0, dict);

        // Act
        var result = csvRow.ToString();

        // Assert - The entire JSON should be escaped because it contains commas
        Assert.StartsWith("\"", result);
        Assert.EndsWith("\"", result);
    }

    #endregion

    #region Integration Tests - Real-World Scenarios

    [Fact]
    public void Integration_CreateRowSetFieldsAndSerialize_ShouldWorkEndToEnd()
    {
        // Arrange
        var csvRow = new CsvRow(4);
        var index = new Dictionary<string, int>
        {
            { "id", 0 },
            { "name", 1 },
            { "amount", 2 },
            { "date", 3 }
        };

        // Act - Simulate real CSV row processing
        csvRow.SetField(0, "12345");
        csvRow.SetField(1, "John Doe");
        csvRow.SetField(2, "1500.50");
        csvRow.SetField(3, "2023-12-25");

        var id = csvRow.GetField<string>(index, "id");
        var name = csvRow.GetField<string>(index, "name");
        var amount = csvRow.GetField<decimal?>(index, "amount");
        var date = csvRow.GetField<DateTime?>(index, "date");
        var csvOutput = csvRow.ToString();

        // Assert
        Assert.Equal("12345", id);
        Assert.Equal("John Doe", name);
        Assert.Equal(1500.50m, amount);
        Assert.NotNull(date);
        Assert.Equal("12345,John Doe,1500.50,2023-12-25", csvOutput);
    }

    [Fact]
    public void Integration_ReuseRowWithClearAndDefaultValues_ShouldWorkCorrectly()
    {
        // Arrange
        var defaultValues = new object?[] { "default_id", "default_name", 0m };
        var csvRow = new CsvRow(defaultValues);

        // Act - First use
        csvRow.SetField(0, "row1_id");
        csvRow.SetField(1, "row1_name");
        csvRow.SetField(2, 100m);
        var firstOutput = csvRow.ToString();

        // Clear and reuse
        csvRow.ClearRow(defaultValues);
        csvRow.SetField(0, "row2_id");
        csvRow.SetField(1, "row2_name");
        csvRow.SetField(2, 200m);
        var secondOutput = csvRow.ToString();

        // Assert
        Assert.Equal("row1_id,row1_name,100", firstOutput);
        Assert.Equal("row2_id,row2_name,200", secondOutput);
    }

    [Fact]
    public void Integration_HandleMissingFieldsGracefully_ShouldReturnNull()
    {
        // Arrange
        var csvRow = new CsvRow(3);
        csvRow.SetField(0, "value1");
        // Fields 1 and 2 are not set
        var index = new Dictionary<string, int>
        {
            { "field0", 0 },
            { "field1", 1 },
            { "field2", 2 }
        };

        // Act
        var field0 = csvRow.GetField<string>(index, "field0");
        var field1 = csvRow.GetField<string>(index, "field1");
        var field2 = csvRow.GetField<int?>(index, "field2");

        // Assert
        Assert.Equal("value1", field0);
        Assert.Null(field1);
        Assert.Null(field2);
    }

    [Fact]
    public void Integration_ParseAndReconstructCsvLine_ShouldMaintainDataIntegrity()
    {
        // Arrange - Simulate parsing a CSV line
        var csvRow = new CsvRow(5);
        csvRow.SetField(0, "id123");
        csvRow.SetField(1, "Product, Name");
        csvRow.SetField(2, "99.99");
        csvRow.SetField(3, "2023-01-15");
        csvRow.SetField(4, "Active");

        // Act
        var csvOutput = csvRow.ToString();

        // Assert - Verify CSV escaping for field with comma
        Assert.Contains("\"Product, Name\"", csvOutput);
        Assert.Contains("id123", csvOutput);
        Assert.Contains("99.99", csvOutput);
    }

    #endregion

    #region Helper Classes

    /// <summary>
    /// Custom test class for testing unsupported type handling
    /// </summary>
    private class CustomTestClass
    {
        public string? Value { get; set; }
    }

    #endregion
}

using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.RealtimeChargeEvents;

namespace PaymentsDataLayerReports.Unit.Test.Application.Workers.ChargeReportS3Worker.Services.RealtimeChargeEvents;

public class RealtimeChargeEventsMapperTests
{
    #region GetHeader Tests

    [Fact]
    public void GetHeader_ShouldReturnNonEmptyString()
    {
        // Act
        var header = RealtimeChargeEventsMapper.GetHeader();

        // Assert
        Assert.NotNull(header);
        Assert.NotEmpty(header);
    }

    [Fact]
    public void GetHeader_ShouldContainExpectedColumns()
    {
        // Act
        var header = RealtimeChargeEventsMapper.GetHeader();

        // Assert - Check for key columns
        Assert.Contains("event_id", header);
        Assert.Contains("event_datetime", header);
        Assert.Contains("id", header);
        Assert.Contains("amount", header);
        Assert.Contains("payment_method", header);
        Assert.Contains("status", header);
        Assert.Contains("merchant__document", header);
        Assert.Contains("card_transaction__type", header);
        Assert.Contains("boleto_transaction__type", header);
        Assert.Contains("pix_transaction__type", header);
        Assert.Contains("cash_transaction__description", header);
    }

    [Fact]
    public void GetHeader_ShouldReturnConsistentResult()
    {
        // Act
        var header1 = RealtimeChargeEventsMapper.GetHeader();
        var header2 = RealtimeChargeEventsMapper.GetHeader();

        // Assert - Header should be consistent across calls
        Assert.Equal(header1, header2);
    }

    [Fact]
    public void GetHeader_ShouldUseCsvFormat()
    {
        // Act
        var header = RealtimeChargeEventsMapper.GetHeader();

        // Assert - Should contain CSV separators
        Assert.Contains(",", header);
    }

    #endregion

    #region BuildRow Tests - Basic Scenarios

    [Fact]
    public void BuildRow_WithEmptyDictionary_ShouldReturnRowWithEmptyFields()
    {
        // Arrange
        var chargeEvent = new Dictionary<string, object>();
        var header = RealtimeChargeEventsMapper.GetHeader();
        var expectedFieldCount = header.Split(',').Length;

        // Act
        var row = RealtimeChargeEventsMapper.BuildRow(chargeEvent);

        // Assert
        Assert.NotNull(row);
        Assert.NotEmpty(row);
        // Row should contain commas for separators even with empty values
        Assert.Contains(",", row);
        // Verify the row has the same number of fields as the header
        var actualFieldCount = row.Split(',').Length;
        Assert.Equal(expectedFieldCount, actualFieldCount);
    }

    [Fact]
    public void BuildRow_WithBasicChargeData_ShouldMapCorrectly()
    {
        // Arrange
        var chargeEvent = new Dictionary<string, object>
        {
            ["id"] = "charge-123",
            ["amount"] = 10000,
            ["payment_method"] = "credit_card",
            ["status"] = "succeeded",
            ["created_at"] = "2024-01-15T10:30:00Z"
        };

        // Act
        var row = RealtimeChargeEventsMapper.BuildRow(chargeEvent);

        // Assert
        Assert.NotNull(row);
        Assert.Contains("charge-123", row);
        Assert.Contains("10000", row);
        Assert.Contains("credit_card", row);
        Assert.Contains("succeeded", row);
    }

    [Fact]
    public void BuildRow_WithNullValues_ShouldHandleGracefully()
    {
        // Arrange
        var chargeEvent = new Dictionary<string, object>
        {
            ["id"] = "charge-456",
            ["amount"] = null!,
            ["payment_method"] = null!,
            ["status"] = "pending"
        };

        // Act
        var row = RealtimeChargeEventsMapper.BuildRow(chargeEvent);

        // Assert
        Assert.NotNull(row);
        Assert.Contains("charge-456", row);
        Assert.Contains("pending", row);
    }

    #endregion

    #region BuildRow Tests - Merchant Data

    [Fact]
    public void BuildRow_WithMerchantData_ShouldMapAllMerchantFields()
    {
        // Arrange
        var chargeEvent = new Dictionary<string, object>
        {
            ["id"] = "charge-789",
            ["merchant"] = new Dictionary<string, object>
            {
                ["organization"] = "org-123",
                ["user_id"] = "user-456",
                ["document"] = "12345678900",
                ["affiliation_key"] = "aff-key-789",
                ["affiliation_code"] = "aff-code-012",
                ["account_id"] = "acc-345",
                ["merchant_id"] = "merch-678"
            }
        };

        // Act
        var row = RealtimeChargeEventsMapper.BuildRow(chargeEvent);

        // Assert
        Assert.NotNull(row);
        Assert.Contains("org-123", row);
        Assert.Contains("user-456", row);
        Assert.Contains("12345678900", row);
        Assert.Contains("aff-key-789", row);
        Assert.Contains("aff-code-012", row);
        Assert.Contains("acc-345", row);
        Assert.Contains("merch-678", row);
    }

    [Fact]
    public void BuildRow_WithPartialMerchantData_ShouldHandleMissingFields()
    {
        // Arrange
        var chargeEvent = new Dictionary<string, object>
        {
            ["id"] = "charge-partial",
            ["merchant"] = new Dictionary<string, object>
            {
                ["document"] = "98765432100",
                ["account_id"] = "acc-999"
            }
        };

        // Act
        var row = RealtimeChargeEventsMapper.BuildRow(chargeEvent);

        // Assert
        Assert.NotNull(row);
        Assert.Contains("98765432100", row);
        Assert.Contains("acc-999", row);
    }

    #endregion

    #region BuildRow Tests - Card Transaction

    [Fact]
    public void BuildRow_WithCardTransaction_ShouldMapCardFields()
    {
        // Arrange
        var chargeEvent = new Dictionary<string, object>
        {
            ["id"] = "charge-card-001",
            ["payment_method"] = "credit_card",
            ["card_transaction"] = new Dictionary<string, object>
            {
                ["type"] = "credit",
                ["transaction_id"] = "txn-card-123",
                ["authorization_code"] = "AUTH123",
                ["installments"] = 3,
                ["card"] = new Dictionary<string, object>
                {
                    ["brand"] = "visa",
                    ["brand_id"] = "001",
                    ["first_six_digits"] = "424242",
                    ["last_four_digits"] = "4242",
                    ["holder_name"] = "JOHN DOE"
                }
            }
        };

        // Act
        var row = RealtimeChargeEventsMapper.BuildRow(chargeEvent);

        // Assert
        Assert.NotNull(row);
        Assert.Contains("credit", row);
        Assert.Contains("txn-card-123", row);
        Assert.Contains("AUTH123", row);
        Assert.Contains("3", row);
        Assert.Contains("visa", row);
        Assert.Contains("424242", row);
        Assert.Contains("4242", row);
        Assert.Contains("JOHN DOE", row);
    }

    [Fact]
    public void BuildRow_WithCardCustomer_ShouldMapCustomerFields()
    {
        // Arrange
        var chargeEvent = new Dictionary<string, object>
        {
            ["id"] = "charge-card-002",
            ["card_transaction"] = new Dictionary<string, object>
            {
                ["customer"] = new Dictionary<string, object>
                {
                    ["name"] = "Jane Smith",
                    ["customer_id"] = "cust-123",
                    ["document_type"] = "CPF",
                    ["document"] = "11122233344",
                    ["email"] = "jane@example.com",
                    ["address"] = new Dictionary<string, object>
                    {
                        ["country"] = "BR",
                        ["city"] = "São Paulo",
                        ["street"] = "Rua Exemplo",
                        ["street_number"] = "123",
                        ["neighborhood"] = "Centro",
                        ["state"] = "SP",
                        ["postal_code"] = "01234-567"
                    }
                }
            }
        };

        // Act
        var row = RealtimeChargeEventsMapper.BuildRow(chargeEvent);

        // Assert
        Assert.NotNull(row);
        Assert.Contains("Jane Smith", row);
        Assert.Contains("cust-123", row);
        Assert.Contains("CPF", row);
        Assert.Contains("11122233344", row);
        Assert.Contains("jane@example.com", row);
        Assert.Contains("BR", row);
        Assert.Contains("São Paulo", row);
        Assert.Contains("Rua Exemplo", row);
        Assert.Contains("123", row);
        Assert.Contains("Centro", row);
        Assert.Contains("SP", row);
        Assert.Contains("01234-567", row);
    }

    [Fact]
    public void BuildRow_WithCardTransactionDetail_ShouldMapDetailFields()
    {
        // Arrange
        var chargeEvent = new Dictionary<string, object>
        {
            ["id"] = "charge-card-003",
            ["card_transaction"] = new Dictionary<string, object>
            {
                ["detail"] = new Dictionary<string, object>
                {
                    ["operation"] = "authorization",
                    ["operation_status"] = "approved",
                    ["operation_id"] = "op-123",
                    ["operation_amount"] = 5000,
                    ["pgid"] = "pg-456",
                    ["gateway_response"] = new Dictionary<string, object>
                    {
                        ["code"] = "00",
                        ["message"] = "Approved"
                    },
                    ["acquirer"] = new Dictionary<string, object>
                    {
                        ["name"] = "Stone",
                        ["nsu"] = "123456",
                        ["tid"] = "789012"
                    }
                }
            }
        };

        // Act
        var row = RealtimeChargeEventsMapper.BuildRow(chargeEvent);

        // Assert
        Assert.NotNull(row);
        Assert.Contains("authorization", row);
        Assert.Contains("approved", row);
        Assert.Contains("op-123", row);
        Assert.Contains("5000", row);
        Assert.Contains("pg-456", row);
        Assert.Contains("00", row);
        Assert.Contains("Approved", row);
        Assert.Contains("Stone", row);
        Assert.Contains("123456", row);
        Assert.Contains("789012", row);
    }

    #endregion

    #region BuildRow Tests - Boleto Transaction

    [Fact]
    public void BuildRow_WithBoletoTransaction_ShouldMapBoletoFields()
    {
        // Arrange
        var chargeEvent = new Dictionary<string, object>
        {
            ["id"] = "charge-boleto-001",
            ["payment_method"] = "boleto",
            ["boleto_transaction"] = new Dictionary<string, object>
            {
                ["type"] = "boleto",
                ["transaction_id"] = "txn-boleto-123",
                ["our_number"] = "12345678901",
                ["barcode"] = "34191234567890123456789012345678901234",
                ["writable_line"] = "34191.23456 78901.234567 89012.345678 9 01234567890123",
                ["expire_at"] = "2024-12-31",
                ["url"] = "https://example.com/boleto/123"
            }
        };

        // Act
        var row = RealtimeChargeEventsMapper.BuildRow(chargeEvent);

        // Assert
        Assert.NotNull(row);
        Assert.Contains("boleto", row);
        Assert.Contains("txn-boleto-123", row);
        Assert.Contains("12345678901", row);
        Assert.Contains("34191234567890123456789012345678901234", row);
    }

    [Fact]
    public void BuildRow_WithBoletoCustomer_ShouldMapCustomerFields()
    {
        // Arrange
        var chargeEvent = new Dictionary<string, object>
        {
            ["id"] = "charge-boleto-002",
            ["boleto_transaction"] = new Dictionary<string, object>
            {
                ["customer"] = new Dictionary<string, object>
                {
                    ["name"] = "Maria Silva",
                    ["customer_id"] = "cust-boleto-456",
                    ["document_type"] = "CPF",
                    ["document"] = "55566677788",
                    ["email"] = "maria@example.com"
                }
            }
        };

        // Act
        var row = RealtimeChargeEventsMapper.BuildRow(chargeEvent);

        // Assert
        Assert.NotNull(row);
        Assert.Contains("Maria Silva", row);
        Assert.Contains("cust-boleto-456", row);
        Assert.Contains("55566677788", row);
        Assert.Contains("maria@example.com", row);
    }

    [Fact]
    public void BuildRow_WithBoletoFineAndInterest_ShouldMapFeeFields()
    {
        // Arrange
        var chargeEvent = new Dictionary<string, object>
        {
            ["id"] = "charge-boleto-003",
            ["boleto_transaction"] = new Dictionary<string, object>
            {
                ["fine"] = new Dictionary<string, object>
                {
                    ["start_at"] = "2024-01-16",
                    ["type"] = "percentage",
                    ["value"] = 2.0
                },
                ["interest"] = new Dictionary<string, object>
                {
                    ["start_at"] = "2024-01-16",
                    ["type"] = "daily",
                    ["value"] = 0.033
                }
            }
        };

        // Act
        var row = RealtimeChargeEventsMapper.BuildRow(chargeEvent);

        // Assert
        Assert.NotNull(row);
        Assert.Contains("2024-01-16", row);
        Assert.Contains("percentage", row);
        Assert.Contains("2", row);
        Assert.Contains("daily", row);
        // The decimal value might be formatted with comma or dot depending on culture
        Assert.True(row.Contains("0.033") || row.Contains("0,033"), "Row should contain the interest value 0.033");
    }

    #endregion

    #region BuildRow Tests - PIX Transaction

    [Fact]
    public void BuildRow_WithPixTransaction_ShouldMapPixFields()
    {
        // Arrange
        var chargeEvent = new Dictionary<string, object>
        {
            ["id"] = "charge-pix-001",
            ["payment_method"] = "pix",
            ["pix_transaction"] = new Dictionary<string, object>
            {
                ["type"] = "pix",
                ["transaction_id"] = "txn-pix-123",
                ["e2e_id"] = "E12345678202401151030123456789012",
                ["pix_key"] = "11122233344",
                ["is_pix_sale_key"] = true,
                ["paid_amount"] = 15000
            }
        };

        // Act
        var row = RealtimeChargeEventsMapper.BuildRow(chargeEvent);

        // Assert
        Assert.NotNull(row);
        Assert.Contains("pix", row);
        Assert.Contains("txn-pix-123", row);
        Assert.Contains("E12345678202401151030123456789012", row);
        Assert.Contains("11122233344", row);
        Assert.Contains("True", row);
        Assert.Contains("15000", row);
    }

    [Fact]
    public void BuildRow_WithPixCustomer_ShouldMapCustomerFields()
    {
        // Arrange
        var chargeEvent = new Dictionary<string, object>
        {
            ["id"] = "charge-pix-002",
            ["pix_transaction"] = new Dictionary<string, object>
            {
                ["customer"] = new Dictionary<string, object>
                {
                    ["name"] = "Carlos Oliveira",
                    ["customer_id"] = "cust-pix-789",
                    ["document"] = "99988877766",
                    ["email"] = "carlos@example.com"
                }
            }
        };

        // Act
        var row = RealtimeChargeEventsMapper.BuildRow(chargeEvent);

        // Assert
        Assert.NotNull(row);
        Assert.Contains("Carlos Oliveira", row);
        Assert.Contains("cust-pix-789", row);
        Assert.Contains("99988877766", row);
        Assert.Contains("carlos@example.com", row);
    }

    [Fact]
    public void BuildRow_WithPixPayer_ShouldMapPayerFields()
    {
        // Arrange
        var chargeEvent = new Dictionary<string, object>
        {
            ["id"] = "charge-pix-003",
            ["pix_transaction"] = new Dictionary<string, object>
            {
                ["payer"] = new Dictionary<string, object>
                {
                    ["name"] = "Payer Name",
                    ["document_type"] = "CPF",
                    ["document"] = "12312312312",
                    ["ispb"] = "12345678",
                    ["institution_name"] = "Banco Exemplo"
                }
            }
        };

        // Act
        var row = RealtimeChargeEventsMapper.BuildRow(chargeEvent);

        // Assert
        Assert.NotNull(row);
        Assert.Contains("Payer Name", row);
        Assert.Contains("12312312312", row);
        Assert.Contains("12345678", row);
        Assert.Contains("Banco Exemplo", row);
    }

    [Fact]
    public void BuildRow_WithPixDetail_ShouldMapDetailFields()
    {
        // Arrange
        var chargeEvent = new Dictionary<string, object>
        {
            ["id"] = "charge-pix-004",
            ["pix_transaction"] = new Dictionary<string, object>
            {
                ["detail"] = new Dictionary<string, object>
                {
                    ["operation"] = "payment",
                    ["operation_status"] = "completed",
                    ["operation_id"] = "op-pix-123",
                    ["operation_amount"] = 20000,
                    ["qrcode_content"] = "00020126580014br.gov.bcb.pix...",
                    ["description"] = "Payment for services"
                }
            }
        };

        // Act
        var row = RealtimeChargeEventsMapper.BuildRow(chargeEvent);

        // Assert
        Assert.NotNull(row);
        Assert.Contains("payment", row);
        Assert.Contains("completed", row);
        Assert.Contains("op-pix-123", row);
        Assert.Contains("20000", row);
        Assert.Contains("Payment for services", row);
    }

    #endregion

    #region BuildRow Tests - Cash Transaction

    [Fact]
    public void BuildRow_WithCashTransaction_ShouldMapCashFields()
    {
        // Arrange
        var chargeEvent = new Dictionary<string, object>
        {
            ["id"] = "charge-cash-001",
            ["payment_method"] = "cash",
            ["cash_transaction"] = new Dictionary<string, object>
            {
                ["description"] = "Cash payment",
                ["transaction_id"] = "txn-cash-123",
                ["paid_amount"] = 5000,
                ["canceled_amount"] = 0
            }
        };

        // Act
        var row = RealtimeChargeEventsMapper.BuildRow(chargeEvent);

        // Assert
        Assert.NotNull(row);
        Assert.Contains("Cash payment", row);
        Assert.Contains("txn-cash-123", row);
        Assert.Contains("5000", row);
    }

    [Fact]
    public void BuildRow_WithCashCustomer_ShouldMapCustomerFields()
    {
        // Arrange
        var chargeEvent = new Dictionary<string, object>
        {
            ["id"] = "charge-cash-002",
            ["cash_transaction"] = new Dictionary<string, object>
            {
                ["customer"] = new Dictionary<string, object>
                {
                    ["name"] = "Ana Costa",
                    ["customer_id"] = "cust-cash-456",
                    ["document"] = "44455566677",
                    ["email"] = "ana@example.com"
                }
            }
        };

        // Act
        var row = RealtimeChargeEventsMapper.BuildRow(chargeEvent);

        // Assert
        Assert.NotNull(row);
        Assert.Contains("Ana Costa", row);
        Assert.Contains("cust-cash-456", row);
        Assert.Contains("44455566677", row);
        Assert.Contains("ana@example.com", row);
    }

    [Fact]
    public void BuildRow_WithCashDetail_ShouldMapDetailFields()
    {
        // Arrange
        var chargeEvent = new Dictionary<string, object>
        {
            ["id"] = "charge-cash-003",
            ["cash_transaction"] = new Dictionary<string, object>
            {
                ["detail"] = new Dictionary<string, object>
                {
                    ["operation"] = "payment",
                    ["operation_status"] = "completed",
                    ["operation_id"] = "op-cash-789",
                    ["operation_amount"] = 3000,
                    ["reason"] = "Cash payment received"
                }
            }
        };

        // Act
        var row = RealtimeChargeEventsMapper.BuildRow(chargeEvent);

        // Assert
        Assert.NotNull(row);
        Assert.Contains("payment", row);
        Assert.Contains("completed", row);
        Assert.Contains("op-cash-789", row);
        Assert.Contains("3000", row);
        Assert.Contains("Cash payment received", row);
    }

    #endregion

    #region BuildRow Tests - Event ID Priority Logic

    [Fact]
    public void BuildRow_EventIdPriority_ShouldFollowCorrectPrecedence()
    {
        // Test 1: Card fee ID has highest priority
        var chargeEvent1 = new Dictionary<string, object>
        {
            ["id"] = "charge-001",
            ["card_transaction"] = new Dictionary<string, object>
            {
                ["fee"] = new Dictionary<string, object> { ["id"] = "fee-id-123" },
                ["detail"] = new Dictionary<string, object> { ["operation_id"] = "op-id-456" }
            }
        };
        var row1 = RealtimeChargeEventsMapper.BuildRow(chargeEvent1);
        var firstField1 = row1.Split(',')[0].Trim('"');
        Assert.Equal("fee-id-123", firstField1);

        // Test 2: Card detail operation_id is second priority
        var chargeEvent2 = new Dictionary<string, object>
        {
            ["id"] = "charge-002",
            ["card_transaction"] = new Dictionary<string, object>
            {
                ["detail"] = new Dictionary<string, object> { ["operation_id"] = "op-card-789" }
            }
        };
        var row2 = RealtimeChargeEventsMapper.BuildRow(chargeEvent2);
        var firstField2 = row2.Split(',')[0].Trim('"');
        Assert.Equal("op-card-789", firstField2);

        // Test 3: PIX detail operation_id is third priority
        var chargeEvent3 = new Dictionary<string, object>
        {
            ["id"] = "charge-003",
            ["pix_transaction"] = new Dictionary<string, object>
            {
                ["detail"] = new Dictionary<string, object> { ["operation_id"] = "op-pix-012" }
            }
        };
        var row3 = RealtimeChargeEventsMapper.BuildRow(chargeEvent3);
        var firstField3 = row3.Split(',')[0].Trim('"');
        Assert.Equal("op-pix-012", firstField3);

        // Test 4: Charge ID is fallback (lowest priority)
        var chargeEvent4 = new Dictionary<string, object> { ["id"] = "charge-fallback-999" };
        var row4 = RealtimeChargeEventsMapper.BuildRow(chargeEvent4);
        var firstField4 = row4.Split(',')[0].Trim('"');
        Assert.Equal("charge-fallback-999", firstField4);
    }

    #endregion

    #region BuildRow Tests - Edge Cases

    [Fact]
    public void BuildRow_WithSpecialCharactersInValues_ShouldEscapeCorrectly()
    {
        // Arrange
        var chargeEvent = new Dictionary<string, object>
        {
            ["id"] = "charge-special-001",
            ["merchant"] = new Dictionary<string, object>
            {
                ["document"] = "12,345,678-900"
            },
            ["card_transaction"] = new Dictionary<string, object>
            {
                ["card"] = new Dictionary<string, object>
                {
                    ["holder_name"] = "JOHN \"JOHNNY\" DOE"
                }
            }
        };

        // Act
        var row = RealtimeChargeEventsMapper.BuildRow(chargeEvent);

        // Assert
        Assert.NotNull(row);
        // CSV should properly escape special characters
        Assert.Contains("12,345,678-900", row);
        Assert.Contains("JOHN", row);
    }

    [Fact]
    public void BuildRow_WithNumericValues_ShouldConvertToString()
    {
        // Arrange
        var chargeEvent = new Dictionary<string, object>
        {
            ["id"] = "charge-numeric-001",
            ["amount"] = 123456,
            ["card_transaction"] = new Dictionary<string, object>
            {
                ["installments"] = 12,
                ["card"] = new Dictionary<string, object>
                {
                    ["exp_month"] = 12,
                    ["exp_year"] = 2025
                }
            }
        };

        // Act
        var row = RealtimeChargeEventsMapper.BuildRow(chargeEvent);

        // Assert
        Assert.NotNull(row);
        Assert.Contains("123456", row);
        Assert.Contains("12", row);
        Assert.Contains("2025", row);
    }

    [Fact]
    public void BuildRow_WithBooleanValues_ShouldConvertToString()
    {
        // Arrange
        var chargeEvent = new Dictionary<string, object>
        {
            ["id"] = "charge-bool-001",
            ["pix_transaction"] = new Dictionary<string, object>
            {
                ["is_pix_sale_key"] = true,
                ["business_days_only"] = false
            }
        };

        // Act
        var row = RealtimeChargeEventsMapper.BuildRow(chargeEvent);

        // Assert
        Assert.NotNull(row);
        Assert.Contains("True", row);
        Assert.Contains("False", row);
    }

    [Fact]
    public void BuildRow_WithDeepNestedStructure_ShouldNavigateCorrectly()
    {
        // Arrange
        var chargeEvent = new Dictionary<string, object>
        {
            ["id"] = "charge-nested-001",
            ["card_transaction"] = new Dictionary<string, object>
            {
                ["customer"] = new Dictionary<string, object>
                {
                    ["address"] = new Dictionary<string, object>
                    {
                        ["country"] = "BR",
                        ["state"] = "SP",
                        ["city"] = "São Paulo"
                    }
                }
            }
        };

        // Act
        var row = RealtimeChargeEventsMapper.BuildRow(chargeEvent);

        // Assert
        Assert.NotNull(row);
        Assert.Contains("BR", row);
        Assert.Contains("SP", row);
        Assert.Contains("São Paulo", row);
    }

    [Fact]
    public void BuildRow_WithMixedTransactionTypes_ShouldMapAllAvailableFields()
    {
        // Arrange - Edge case: event with multiple transaction types (shouldn't happen in practice)
        var chargeEvent = new Dictionary<string, object>
        {
            ["id"] = "charge-mixed-001",
            ["card_transaction"] = new Dictionary<string, object>
            {
                ["type"] = "credit"
            },
            ["pix_transaction"] = new Dictionary<string, object>
            {
                ["type"] = "pix"
            }
        };

        // Act
        var row = RealtimeChargeEventsMapper.BuildRow(chargeEvent);

        // Assert - Should map both without errors
        Assert.NotNull(row);
        Assert.Contains("credit", row);
        Assert.Contains("pix", row);
    }


    [Fact]
    public void BuildRow_WithVeryLargeValues_ShouldHandleCorrectly()
    {
        // Arrange
        var chargeEvent = new Dictionary<string, object>
        {
            ["id"] = "charge-large-001",
            ["amount"] = long.MaxValue,
            ["card_transaction"] = new Dictionary<string, object>
            {
                ["card"] = new Dictionary<string, object>
                {
                    ["holder_name"] = new string('A', 1000) // Very long name
                }
            }
        };

        // Act
        var row = RealtimeChargeEventsMapper.BuildRow(chargeEvent);

        // Assert
        Assert.NotNull(row);
        Assert.Contains(long.MaxValue.ToString(), row);
    }

    #endregion

    #region BuildRow Tests - Complete Scenarios

    [Fact]
    public void BuildRow_WithCompleteCardTransaction_ShouldMapAllFields()
    {
        // Arrange - Comprehensive card transaction scenario
        var chargeEvent = TestDataFactory.CreateCompleteCardChargeEvent();
        var header = RealtimeChargeEventsMapper.GetHeader();

        // Act
        var row = RealtimeChargeEventsMapper.BuildRow(chargeEvent);

        // Assert
        Assert.NotNull(row);
        Assert.NotEmpty(row);

        // Verify field count matches header
        var headerFieldCount = header.Split(',').Length;
        var rowFieldCount = row.Split(',').Length;
        Assert.Equal(headerFieldCount, rowFieldCount);

        // Verify key fields are present
        Assert.Contains("charge-complete-card", row);
        Assert.Contains("credit_card", row);
        Assert.Contains("succeeded", row);
        Assert.Contains("12345678900", row); // merchant document
        Assert.Contains("visa", row); // card brand
        Assert.Contains("JOHN DOE", row); // cardholder name
    }

    [Fact]
    public void BuildRow_WithCompleteBoletoTransaction_ShouldMapAllFields()
    {
        // Arrange - Comprehensive boleto transaction scenario
        var chargeEvent = TestDataFactory.CreateCompleteBoletoChargeEvent();
        var header = RealtimeChargeEventsMapper.GetHeader();

        // Act
        var row = RealtimeChargeEventsMapper.BuildRow(chargeEvent);

        // Assert
        Assert.NotNull(row);
        Assert.NotEmpty(row);

        // Verify field count matches header
        var headerFieldCount = header.Split(',').Length;
        var rowFieldCount = row.Split(',').Length;
        Assert.Equal(headerFieldCount, rowFieldCount);

        Assert.Contains("charge-complete-boleto", row);
        Assert.Contains("boleto", row);
        Assert.Contains("98765432100", row); // merchant document
        Assert.Contains("Maria Silva", row); // customer name
    }

    [Fact]
    public void BuildRow_WithCompletePixTransaction_ShouldMapAllFields()
    {
        // Arrange - Comprehensive PIX transaction scenario
        var chargeEvent = TestDataFactory.CreateCompletePixChargeEvent();
        var header = RealtimeChargeEventsMapper.GetHeader();

        // Act
        var row = RealtimeChargeEventsMapper.BuildRow(chargeEvent);

        // Assert
        Assert.NotNull(row);
        Assert.NotEmpty(row);

        // Verify field count matches header
        var headerFieldCount = header.Split(',').Length;
        var rowFieldCount = row.Split(',').Length;
        Assert.Equal(headerFieldCount, rowFieldCount);

        Assert.Contains("charge-complete-pix", row);
        Assert.Contains("pix", row);
        Assert.Contains("11122233344", row); // merchant document
        Assert.Contains("Carlos Oliveira", row); // customer name
    }

    [Fact]
    public void BuildRow_HeaderAndRowFieldCount_ShouldAlwaysMatch()
    {
        // Arrange
        var header = RealtimeChargeEventsMapper.GetHeader();
        var expectedFieldCount = header.Split(',').Length;

        var testCases = new[]
        {
            new Dictionary<string, object>(), // Empty
            TestDataFactory.CreateCompleteCardChargeEvent(),
            TestDataFactory.CreateCompleteBoletoChargeEvent(),
            TestDataFactory.CreateCompletePixChargeEvent(),
            new Dictionary<string, object> { ["id"] = "simple-charge" } // Minimal
        };

        // Act & Assert
        foreach (var chargeEvent in testCases)
        {
            var row = RealtimeChargeEventsMapper.BuildRow(chargeEvent);
            var actualFieldCount = row.Split(',').Length;
            Assert.Equal(expectedFieldCount, actualFieldCount);
        }
    }

    #endregion
}

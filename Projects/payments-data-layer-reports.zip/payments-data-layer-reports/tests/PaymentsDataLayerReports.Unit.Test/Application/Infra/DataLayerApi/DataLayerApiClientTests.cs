using System.Net;
using System.Text;
using System.Text.Json;
using NSubstitute;
using PaymentsDataLayerReports.Application.Infra.DataLayerApi;
using PaymentsDataLayerReports.Application.Infra.DataLayerApi.Models;

namespace PaymentsDataLayerReports.Unit.Test.Application.Infra.DataLayerApi;

public class TestData
{
    public int X { get; set; }
    public string Y { get; set; } = string.Empty;
    public string Z { get; set; } = string.Empty;
}

public class MockHttpMessageHandler : HttpMessageHandler
{
    private HttpStatusCode _statusCode = HttpStatusCode.OK;
    private string _content = string.Empty;
    private Exception? _exception;

    public Uri? LastRequestUri { get; private set; }

    public void SetResponse(HttpStatusCode statusCode, string content)
    {
        _statusCode = statusCode;
        _content = content;
        _exception = null;
    }

    public void SetException(Exception exception)
    {
        _exception = exception;
    }

    protected override async Task<HttpResponseMessage> SendAsync(
        HttpRequestMessage request,
        CancellationToken cancellationToken)
    {
        LastRequestUri = request.RequestUri;

        if (_exception != null)
        {
            throw _exception;
        }

        var response = new HttpResponseMessage(_statusCode)
        {
            Content = new StringContent(_content, Encoding.UTF8, "application/json")
        };

        return await Task.FromResult(response);
    }
}

public class DataLayerApiClientTests
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly DataLayerApiClient _client;
    private readonly HttpClient _httpClient;
    private readonly MockHttpMessageHandler _mockHandler;

    private readonly JsonSerializerOptions _jsonSerializerOptions;

    private readonly string _defaultUri = "test-endpoint";

    public DataLayerApiClientTests()
    {
        _httpClientFactory = Substitute.For<IHttpClientFactory>();
        _mockHandler = new MockHttpMessageHandler();
        _httpClient = new HttpClient(_mockHandler)
        {
            BaseAddress = new Uri("https://api.test.com")
        };
        _httpClientFactory.CreateClient("dataLayerApiClientClient").Returns(_httpClient);
        _client = new DataLayerApiClient(_httpClientFactory);

        _jsonSerializerOptions = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower
        };
    }

    #region GetDataByCursor Tests

    [Fact]
    public async Task GetDataByCursor_WithValidRequest_ShouldReturnResponse()
    {
        // Arrange
        var cursor = "cursor123";
        var size = 100;
        var total = 1000;
        var request = new GetOrderByCursorRequestModel
        {
            Cursor = cursor,
            Size = size,
            FilterParameters = new Dictionary<string, string>
            {
                { "settlement_status", "paid" },
                { "documents", "123,456" },
            }
        };
        var reportId = "report-123";
        var cancellationToken = CancellationToken.None;

        var expectedResponse = new GetDataByCursorResponseModel<TestData>
        {
            Size = size,
            Cursor = cursor,
            Total = total,
            Data =
            [
                new TestData { X = 1, Y = "test1", Z = "test-1" },
                new TestData { X = 2, Y = "test2", Z = "test-2" }
            ]
        };

        var jsonResponse = JsonSerializer.Serialize(expectedResponse, _jsonSerializerOptions);

        _mockHandler.SetResponse(HttpStatusCode.OK, jsonResponse);

        // Act
        var result = await _client.GetDataByCursor<TestData>(_defaultUri, request, reportId, cancellationToken);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(size, result.Size);
        Assert.Equal(cursor, result.Cursor);
        Assert.Equal(total, result.Total);
        Assert.NotEmpty(result.Data);
    }

    [Fact]
    public async Task GetDataByCursor_WithMinimalRequest_ShouldReturnResponse()
    {
        // Arrange
        var cursor = "cursor456";
        var size = 50;
        var total = 50;
        var request = new GetOrderByCursorRequestModel
        {
            Cursor = cursor,
            Size = size,
            FilterParameters = new Dictionary<string, string>
            {
                { "start_date", DateTimeOffset.UtcNow.AddDays(-30).ToString("o") },
                { "end_date", DateTimeOffset.UtcNow.ToString("o") }
            }
        };
        var reportId = "report-456";
        var cancellationToken = CancellationToken.None;

        var expectedResponse = new GetDataByCursorResponseModel<TestData>
        {
            Size = size,
            Cursor = cursor,
            Total = total,
            Data = []
        };

        var jsonResponse = JsonSerializer.Serialize(expectedResponse, _jsonSerializerOptions);

        _mockHandler.SetResponse(HttpStatusCode.OK, jsonResponse);

        // Act
        var result = await _client.GetDataByCursor<TestData>(_defaultUri, request, reportId, cancellationToken);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(size, result.Size);
        Assert.Equal(cursor, result.Cursor);
        Assert.Equal(total, result.Total);
        Assert.Empty(result.Data);
    }

    [Fact]
    public async Task GetDataByCursor_ShouldIncludeMandatoryDateFields()
    {
        // Arrange
        var startDate = DateTimeOffset.UtcNow.AddDays(-30);
        var endDate = DateTimeOffset.UtcNow;
        var request = new GetOrderByCursorRequestModel
        {
            Size = 100,
            FilterParameters = new Dictionary<string, string>
            {
                { "start_date", startDate.ToString("o") },
                { "end_date", endDate.ToString("o") }
            }
        };
        var reportId = "report-dates";
        var cancellationToken = CancellationToken.None;

        var expectedResponse = new GetDataByCursorResponseModel<TestData>
        {
            Size = 100,
            Total = 0,
            Data = []
        };

        var jsonResponse = JsonSerializer.Serialize(expectedResponse, _jsonSerializerOptions);
        _mockHandler.SetResponse(HttpStatusCode.OK, jsonResponse);

        // Act
        await _client.GetDataByCursor<TestData>(_defaultUri, request, reportId, cancellationToken);

        // Assert
        var requestUri = _mockHandler.LastRequestUri?.ToString();
        Assert.NotNull(requestUri);
        Assert.Contains("start_date=", requestUri);
        Assert.Contains("end_date=", requestUri);
    }

    [Fact]
    public async Task GetDataByCursor_WhenApiReturnsNonOkStatus_ShouldThrowHttpRequestException()
    {
        // Arrange
        var request = new GetOrderByCursorRequestModel
        {
            Cursor = "cursor789",
            Size = 50
        };
        var reportId = "report-789";
        var cancellationToken = CancellationToken.None;

        _mockHandler.SetResponse(HttpStatusCode.BadRequest, "Bad Request Error");

        // Act & Assert
        var exception = await Assert.ThrowsAsync<HttpRequestException>(
            async () => await _client.GetDataByCursor<TestData>(_defaultUri, request, reportId, cancellationToken)
        );

        Assert.Contains("Request to Data Layer API failed", exception.Message);
        Assert.Equal(HttpStatusCode.BadRequest, exception.StatusCode);
    }

    [Fact]
    public async Task GetDataByCursor_WhenApiReturnsInternalServerError_ShouldThrowHttpRequestException()
    {
        // Arrange
        var request = new GetOrderByCursorRequestModel
        {
            Cursor = "cursor000"
        };
        var reportId = "report-000";
        var cancellationToken = CancellationToken.None;

        _mockHandler.SetResponse(HttpStatusCode.InternalServerError, "Internal Server Error");

        // Act & Assert
        var exception = await Assert.ThrowsAsync<HttpRequestException>(
            async () => await _client.GetDataByCursor<TestData>(_defaultUri, request, reportId, cancellationToken)
        );

        Assert.Contains("Request to Data Layer API failed", exception.Message);
        Assert.Equal(HttpStatusCode.InternalServerError, exception.StatusCode);
    }

    [Fact]
    public async Task GetDataByCursor_WhenDeserializationFails_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var request = new GetOrderByCursorRequestModel
        {
            Cursor = "cursor111"
        };
        var reportId = "report-111";
        var cancellationToken = CancellationToken.None;

        _mockHandler.SetResponse(HttpStatusCode.OK, "null");

        // Act & Assert
        var exception = await Assert.ThrowsAsync<InvalidOperationException>(
            async () => await _client.GetDataByCursor<TestData>(_defaultUri, request, reportId, cancellationToken)
        );

        Assert.Contains("Failed to deserialize response from Data Layer API", exception.Message);
    }


    [Fact]
    public async Task GetDataByCursor_ShouldBuildCorrectQueryString()
    {
        // Arrange
        var document = "12345678900";
        var status = "paid";
        var cursor = "cursor333";
        var size = 200;
        var request = new GetOrderByCursorRequestModel
        {
            Cursor = cursor,
            Size = size,
            FilterParameters = new Dictionary<string, string>
            {
                { "settlement_status", status },
                { "documents", document }
            }
        };
        var reportId = "report-333";
        var cancellationToken = CancellationToken.None;

        var expectedResponse = new GetDataByCursorResponseModel<TestData>
        {
            Size = size,
            Total = 0,
            Data = []
        };

        var jsonResponse = JsonSerializer.Serialize(expectedResponse, _jsonSerializerOptions);

        _mockHandler.SetResponse(HttpStatusCode.OK, jsonResponse);

        // Act
        await _client.GetDataByCursor<TestData>(_defaultUri, request, reportId, cancellationToken);

        // Assert
        var requestUri = _mockHandler.LastRequestUri?.ToString();
        Assert.NotNull(requestUri);
        Assert.Contains($"cursor={cursor}", requestUri);
        Assert.Contains($"size={size}", requestUri);
        Assert.Contains($"documents={document}", requestUri);
        Assert.Contains($"settlement_status={status}", requestUri);
    }

    #endregion
}


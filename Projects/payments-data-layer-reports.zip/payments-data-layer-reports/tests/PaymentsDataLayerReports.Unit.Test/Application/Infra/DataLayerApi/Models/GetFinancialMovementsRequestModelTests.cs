using PaymentsDataLayerReports.Application.Infra.DataLayerApi.Models;

namespace PaymentsDataLayerReports.Unit.Test.Application.Infra.DataLayerApi.Models;

public class GetFinancialMovementsRequestModelTests
{
    [Fact]
    public void ToQueryParameters_WithAllFields_ShouldIncludeAllParameters()
    {
        // Arrange
        var model = new GetFinancialMovementsRequestModel
        {
            Cursor = "cursor-123",
            Size = 100,
            StartDueDate = new DateOnly(2025, 1, 1),
            EndDueDate = new DateOnly(2025, 1, 31),
            Organizations = "stone,ton",
            Document = "12345678901",
            AffiliationCodes = "code1,code2",
            SettlementStatus = "settled",
            Products = "credit,debit",
            Brands = "visa,mastercard",
            WalletTypeIds = "wallet1,wallet2",
            Categories = "category1",
            WithPayments = true,
            StoneAccounts = "account1,account2",
            PaymentProfiles = "profile1,profile2",
            PoiTypes = "pos,ecommerce",
            AccountId = "acc-123",
            MerchantId = "merchant-456"
        };

        // Act
        var result = model.ToQueryParameters().Build();

        // Assert
        Assert.Contains("cursor=cursor-123", result);
        Assert.Contains("size=100", result);
        Assert.Contains("due_date_start=2025-01-01", result);
        Assert.Contains("due_date_end=2025-01-31", result);
        Assert.Contains("organizations=stone%2Cton", result);
        Assert.Contains("settlement_status=settled", result);
        Assert.Contains("products=credit%2Cdebit", result);
        Assert.Contains("brands=visa%2Cmastercard", result);
        Assert.Contains("wallet_type_ids=wallet1%2Cwallet2", result);
        Assert.Contains("categories=category1", result);
        Assert.Contains("with_payments=true", result);
        Assert.Contains("stone_accounts=account1%2Caccount2", result);
        Assert.Contains("payment_profile_ids=profile1%2Cprofile2", result);
        Assert.Contains("point_of_interaction_types=pos%2Cecommerce", result);
        Assert.Contains("account_id=acc-123", result);
        Assert.Contains("merchant_id=merchant-456", result);
    }

    [Fact]
    public void ToQueryParameters_WithAffiliationCodes_ShouldIncludeAffiliationCodesAndExcludeDocument()
    {
        // Arrange
        var model = new GetFinancialMovementsRequestModel
        {
            AffiliationCodes = "code1,code2",
            Document = "12345678901"
        };

        // Act
        var result = model.ToQueryParameters().Build();

        // Assert
        Assert.Contains("affiliation_codes=code1%2Ccode2", result);
        Assert.DoesNotContain("document", result);
    }

    [Fact]
    public void ToQueryParameters_WithoutAffiliationCodes_ShouldIncludeDocument()
    {
        // Arrange
        var model = new GetFinancialMovementsRequestModel
        {
            Document = "12345678901"
        };

        // Act
        var result = model.ToQueryParameters().Build();

        // Assert
        Assert.Contains("document=12345678901", result);
        Assert.DoesNotContain("affiliation_codes", result);
    }

    [Fact]
    public void ToQueryParameters_WithNullStoneAccounts_ShouldExcludeStoneAccounts()
    {
        // Arrange
        var model = new GetFinancialMovementsRequestModel
        {
            StoneAccounts = null,
            Size = 100
        };

        // Act
        var result = model.ToQueryParameters().Build();

        // Assert
        Assert.DoesNotContain("stone_accounts", result);
        Assert.Contains("size=100", result);
    }

    [Fact]
    public void ToQueryParameters_WithEmptyStoneAccounts_ShouldExcludeStoneAccounts()
    {
        // Arrange
        var model = new GetFinancialMovementsRequestModel
        {
            StoneAccounts = "",
            Size = 100
        };

        // Act
        var result = model.ToQueryParameters().Build();

        // Assert
        Assert.DoesNotContain("stone_accounts", result);
        Assert.Contains("size=100", result);
    }

    [Fact]
    public void ToQueryParameters_WithNullPaymentProfiles_ShouldExcludePaymentProfiles()
    {
        // Arrange
        var model = new GetFinancialMovementsRequestModel
        {
            PaymentProfiles = null,
            Size = 100
        };

        // Act
        var result = model.ToQueryParameters().Build();

        // Assert
        Assert.DoesNotContain("payment_profile_ids", result);
        Assert.Contains("size=100", result);
    }

    [Fact]
    public void ToQueryParameters_WithEmptyPaymentProfiles_ShouldExcludePaymentProfiles()
    {
        // Arrange
        var model = new GetFinancialMovementsRequestModel
        {
            PaymentProfiles = "",
            Size = 100
        };

        // Act
        var result = model.ToQueryParameters().Build();

        // Assert
        Assert.DoesNotContain("payment_profile_ids", result);
        Assert.Contains("size=100", result);
    }

    [Fact]
    public void ToQueryParameters_WithNullPoiTypes_ShouldExcludePoiTypes()
    {
        // Arrange
        var model = new GetFinancialMovementsRequestModel
        {
            PoiTypes = null,
            Size = 100
        };

        // Act
        var result = model.ToQueryParameters().Build();

        // Assert
        Assert.DoesNotContain("point_of_interaction_types", result);
        Assert.Contains("size=100", result);
    }

    [Fact]
    public void ToQueryParameters_WithEmptyPoiTypes_ShouldExcludePoiTypes()
    {
        // Arrange
        var model = new GetFinancialMovementsRequestModel
        {
            PoiTypes = "",
            Size = 100
        };

        // Act
        var result = model.ToQueryParameters().Build();

        // Assert
        Assert.DoesNotContain("point_of_interaction_types", result);
        Assert.Contains("size=100", result);
    }

    [Fact]
    public void ToQueryParameters_WithAllNewFieldsPopulated_ShouldIncludeAll()
    {
        // Arrange
        var model = new GetFinancialMovementsRequestModel
        {
            StoneAccounts = "acc1,acc2,acc3",
            PaymentProfiles = "prof1,prof2",
            PoiTypes = "pos,mobile,ecommerce"
        };

        // Act
        var result = model.ToQueryParameters().Build();

        // Assert
        Assert.Contains("stone_accounts=acc1%2Cacc2%2Cacc3", result);
        Assert.Contains("payment_profile_ids=prof1%2Cprof2", result);
        Assert.Contains("point_of_interaction_types=pos%2Cmobile%2Cecommerce", result);
    }

    [Fact]
    public void ToQueryParameters_WithAllNewFieldsNull_ShouldExcludeAll()
    {
        // Arrange
        var model = new GetFinancialMovementsRequestModel
        {
            StoneAccounts = null,
            PaymentProfiles = null,
            PoiTypes = null,
            Size = 100
        };

        // Act
        var result = model.ToQueryParameters().Build();

        // Assert
        Assert.DoesNotContain("stone_accounts", result);
        Assert.DoesNotContain("payment_profile_ids", result);
        Assert.DoesNotContain("point_of_interaction_types", result);
        Assert.Contains("size=100", result);
    }

    [Fact]
    public void ToQueryParameters_WithNullOptionalFields_ShouldExcludeThemFromQuery()
    {
        // Arrange
        var model = new GetFinancialMovementsRequestModel
        {
            Cursor = null,
            Size = null,
            StartDueDate = null,
            EndDueDate = null,
            Organizations = null,
            Document = null,
            AffiliationCodes = null,
            SettlementStatus = null,
            Products = null,
            Brands = null,
            WalletTypeIds = null,
            Categories = null,
            WithPayments = null,
            StoneAccounts = null,
            PaymentProfiles = null,
            PoiTypes = null,
            AccountId = null,
            MerchantId = null
        };

        // Act
        var result = model.ToQueryParameters().Build();

        // Assert
        Assert.Empty(result);
    }

    [Fact]
    public void ToQueryParameters_WithWithPaymentsFalse_ShouldIncludeParameter()
    {
        // Arrange
        var model = new GetFinancialMovementsRequestModel
        {
            WithPayments = false
        };

        // Act
        var result = model.ToQueryParameters().Build();

        // Assert
        Assert.Contains("with_payments=false", result);
    }

    [Fact]
    public void ToQueryParameters_WithWithPaymentsTrue_ShouldIncludeParameter()
    {
        // Arrange
        var model = new GetFinancialMovementsRequestModel
        {
            WithPayments = true
        };

        // Act
        var result = model.ToQueryParameters().Build();

        // Assert
        Assert.Contains("with_payments=true", result);
    }

    [Fact]
    public void ToQueryParameters_WithOrganizationsUpperCase_ShouldConvertToLowerCase()
    {
        // Arrange
        var model = new GetFinancialMovementsRequestModel
        {
            Organizations = "STONE,TON"
        };

        // Act
        var result = model.ToQueryParameters().Build();

        // Assert
        Assert.Contains("organizations=stone%2Cton", result);
    }

    [Fact]
    public void ToQueryParameters_WithAccountIdAndMerchantId_ShouldIncludeBoth()
    {
        // Arrange
        var model = new GetFinancialMovementsRequestModel
        {
            AccountId = "account-123",
            MerchantId = "merchant-456"
        };

        // Act
        var result = model.ToQueryParameters().Build();

        // Assert
        Assert.Contains("account_id=account-123", result);
        Assert.Contains("merchant_id=merchant-456", result);
    }

    [Fact]
    public void ToQueryParameters_WithSpecialCharacters_ShouldEncodeCorrectly()
    {
        // Arrange
        var model = new GetFinancialMovementsRequestModel
        {
            StoneAccounts = "acc@1,acc#2",
            PaymentProfiles = "prof$1,prof&2",
            PoiTypes = "type=1,type+2"
        };

        // Act
        var result = model.ToQueryParameters().Build();

        // Assert - verificar que caracteres especiais são codificados
        Assert.Contains("stone_accounts=", result);
        Assert.Contains("payment_profile_ids=", result);
        Assert.Contains("point_of_interaction_types=", result);
        // Caracteres especiais devem estar encoded
        Assert.DoesNotContain("@", result);
        Assert.DoesNotContain("#", result);
        Assert.DoesNotContain("$", result);
        Assert.DoesNotContain("&prof", result); // & sozinho não deve aparecer (a não ser como separador)
    }

    [Fact]
    public void ToQueryParameters_WithDateRanges_ShouldFormatDatesCorrectly()
    {
        // Arrange
        var model = new GetFinancialMovementsRequestModel
        {
            StartDueDate = new DateOnly(2024, 6, 15),
            EndDueDate = new DateOnly(2024, 12, 31)
        };

        // Act
        var result = model.ToQueryParameters().Build();

        // Assert
        Assert.Contains("due_date_start=2024-06-15", result);
        Assert.Contains("due_date_end=2024-12-31", result);
    }
}

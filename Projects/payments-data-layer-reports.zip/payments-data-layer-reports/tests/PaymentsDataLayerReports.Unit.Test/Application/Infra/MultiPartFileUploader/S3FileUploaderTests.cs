using Amazon.S3;
using Amazon.S3.Model;
using NSubstitute;
using NSubstitute.ExceptionExtensions;
using PaymentsDataLayerReports.Application.Infra.MultiPartFileUploader;

namespace PaymentsDataLayerReports.Unit.Test.Application.Infra.MultiPartFileUploader;

/// <summary>
/// Testes unitários para o S3FileUploader.
/// Valida o comportamento completo do upload multipart para S3,
/// incluindo inicialização, upload de partes, conclusão e cancelamento.
/// </summary>
public class S3FileUploaderTests
{
    private readonly IAmazonS3 _s3Client;
    private const string TestBucketName = "test-bucket";
    private const string TestFileName = "test-file.txt";
    private const string TestUploadId = "test-upload-id-123";

    public S3FileUploaderTests()
    {
        _s3Client = Substitute.For<IAmazonS3>();
    }

    [Fact]
    public async Task InitiateMultipartUploadAsync_WithValidParameters_ShouldInitializeUpload()
    {
        // Arrange
        var uploader = new S3FileUploader(_s3Client);
        var expectedResponse = new InitiateMultipartUploadResponse
        {
            UploadId = TestUploadId
        };

        _s3Client
            .InitiateMultipartUploadAsync(
                Arg.Is<InitiateMultipartUploadRequest>(r =>
                    r.BucketName == TestBucketName &&
                    r.Key == TestFileName),
                Arg.Any<CancellationToken>())
            .Returns(expectedResponse);

        // Act
        await uploader.InitiateMultipartUploadAsync(TestFileName, TestBucketName);

        // Assert
        await _s3Client.Received(1).InitiateMultipartUploadAsync(
            Arg.Is<InitiateMultipartUploadRequest>(r =>
                r.BucketName == TestBucketName &&
                r.Key == TestFileName),
            Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task UploadPartAsync_WithValidStream_ShouldUploadPartSuccessfully()
    {
        // Arrange
        var uploader = new S3FileUploader(_s3Client);
        var testData = "Test data for upload"u8.ToArray();
        using var partStream = new MemoryStream(testData);

        var initiateResponse = new InitiateMultipartUploadResponse
        {
            UploadId = TestUploadId
        };

        var uploadPartResponse = new UploadPartResponse
        {
            ETag = "test-etag-1"
        };

        _s3Client
            .InitiateMultipartUploadAsync(Arg.Any<InitiateMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(initiateResponse);

        _s3Client
            .UploadPartAsync(Arg.Any<UploadPartRequest>(), Arg.Any<CancellationToken>())
            .Returns(uploadPartResponse);

        await uploader.InitiateMultipartUploadAsync(TestFileName, TestBucketName);

        // Act
        await uploader.UploadPartAsync(partStream, CancellationToken.None);

        // Assert
        await _s3Client.Received(1).UploadPartAsync(
            Arg.Is<UploadPartRequest>(r =>
                r.BucketName == TestBucketName &&
                r.Key == TestFileName &&
                r.UploadId == TestUploadId &&
                r.PartNumber == 1 &&
                r.PartSize == testData.Length),
            Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task UploadPartAsync_WithMultipleParts_ShouldIncrementPartNumber()
    {
        // Arrange
        var uploader = new S3FileUploader(_s3Client);
        var testData1 = "First part"u8.ToArray();
        var testData2 = "Second part"u8.ToArray();
        using var partStream1 = new MemoryStream(testData1);
        using var partStream2 = new MemoryStream(testData2);

        var initiateResponse = new InitiateMultipartUploadResponse
        {
            UploadId = TestUploadId
        };

        _s3Client
            .InitiateMultipartUploadAsync(Arg.Any<InitiateMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(initiateResponse);

        _s3Client
            .UploadPartAsync(Arg.Any<UploadPartRequest>(), Arg.Any<CancellationToken>())
            .Returns(
                new UploadPartResponse { ETag = "etag-1" },
                new UploadPartResponse { ETag = "etag-2" }
            );

        await uploader.InitiateMultipartUploadAsync(TestFileName, TestBucketName);

        // Act
        await uploader.UploadPartAsync(partStream1, CancellationToken.None);
        await uploader.UploadPartAsync(partStream2, CancellationToken.None);

        // Assert
        await _s3Client.Received(1).UploadPartAsync(
            Arg.Is<UploadPartRequest>(r => r.PartNumber == 1),
            Arg.Any<CancellationToken>());

        await _s3Client.Received(1).UploadPartAsync(
            Arg.Is<UploadPartRequest>(r => r.PartNumber == 2),
            Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task CompleteMultipartUploadAsync_WithUploadedParts_ShouldCompleteSuccessfully()
    {
        // Arrange
        var uploader = new S3FileUploader(_s3Client);
        var testData = "Test data"u8.ToArray();
        using var partStream = new MemoryStream(testData);

        var initiateResponse = new InitiateMultipartUploadResponse
        {
            UploadId = TestUploadId
        };

        var uploadPartResponse = new UploadPartResponse
        {
            ETag = "test-etag"
        };

        var completeResponse = new CompleteMultipartUploadResponse
        {
            Key = TestFileName,
            Location = $"https://{TestBucketName}.s3.amazonaws.com/{TestFileName}"
        };

        CompleteMultipartUploadRequest? capturedRequest = null;

        _s3Client
            .InitiateMultipartUploadAsync(Arg.Any<InitiateMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(initiateResponse);

        _s3Client
            .UploadPartAsync(Arg.Any<UploadPartRequest>(), Arg.Any<CancellationToken>())
            .Returns(uploadPartResponse);

        _s3Client
            .CompleteMultipartUploadAsync(
                Arg.Do<CompleteMultipartUploadRequest>(r =>
                {
                    capturedRequest = new CompleteMultipartUploadRequest
                    {
                        BucketName = r.BucketName,
                        Key = r.Key,
                        UploadId = r.UploadId,
                        PartETags = r.PartETags.ToList() // Cópia da lista
                    };
                }),
                Arg.Any<CancellationToken>())
            .Returns(completeResponse);

        await uploader.InitiateMultipartUploadAsync(TestFileName, TestBucketName);
        await uploader.UploadPartAsync(partStream, CancellationToken.None);

        // Act
        var result = await uploader.CompleteMultipartUploadAsync(CancellationToken.None);

        // Assert
        Assert.Equal(completeResponse.Location, result);
        Assert.NotNull(capturedRequest);
        Assert.Equal(TestBucketName, capturedRequest!.BucketName);
        Assert.Equal(TestFileName, capturedRequest.Key);
        Assert.Equal(TestUploadId, capturedRequest.UploadId);
        Assert.NotNull(capturedRequest.PartETags);
        Assert.Single(capturedRequest.PartETags);
        Assert.Equal(1, capturedRequest.PartETags[0].PartNumber);
    }

    [Fact]
    public async Task CompleteMultipartUploadAsync_WithMultipleParts_ShouldIncludeAllETags()
    {
        // Arrange
        var uploader = new S3FileUploader(_s3Client);
        var testData1 = "Part 1"u8.ToArray();
        var testData2 = "Part 2"u8.ToArray();
        var testData3 = "Part 3"u8.ToArray();

        using var partStream1 = new MemoryStream(testData1);
        using var partStream2 = new MemoryStream(testData2);
        using var partStream3 = new MemoryStream(testData3);

        var initiateResponse = new InitiateMultipartUploadResponse
        {
            UploadId = TestUploadId
        };

        var completeResponse = new CompleteMultipartUploadResponse
        {
            Key = TestFileName
        };

        CompleteMultipartUploadRequest? capturedRequest = null;

        _s3Client
            .InitiateMultipartUploadAsync(Arg.Any<InitiateMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(initiateResponse);

        _s3Client
            .UploadPartAsync(Arg.Any<UploadPartRequest>(), Arg.Any<CancellationToken>())
            .Returns(
                new UploadPartResponse { ETag = "etag-1" },
                new UploadPartResponse { ETag = "etag-2" },
                new UploadPartResponse { ETag = "etag-3" }
            );

        _s3Client
            .CompleteMultipartUploadAsync(
                Arg.Do<CompleteMultipartUploadRequest>(r =>
                {
                    capturedRequest = new CompleteMultipartUploadRequest
                    {
                        BucketName = r.BucketName,
                        Key = r.Key,
                        UploadId = r.UploadId,
                        PartETags = r.PartETags.ToList()
                    };
                }),
                Arg.Any<CancellationToken>())
            .Returns(completeResponse);

        await uploader.InitiateMultipartUploadAsync(TestFileName, TestBucketName);
        await uploader.UploadPartAsync(partStream1, CancellationToken.None);
        await uploader.UploadPartAsync(partStream2, CancellationToken.None);
        await uploader.UploadPartAsync(partStream3, CancellationToken.None);

        // Act
        await uploader.CompleteMultipartUploadAsync(CancellationToken.None);

        // Assert
        Assert.NotNull(capturedRequest);
        Assert.NotNull(capturedRequest!.PartETags);
        Assert.Equal(3, capturedRequest.PartETags.Count);
        Assert.Equal(1, capturedRequest.PartETags[0].PartNumber);
        Assert.Equal("etag-1", capturedRequest.PartETags[0].ETag);
        Assert.Equal(2, capturedRequest.PartETags[1].PartNumber);
        Assert.Equal("etag-2", capturedRequest.PartETags[1].ETag);
        Assert.Equal(3, capturedRequest.PartETags[2].PartNumber);
        Assert.Equal("etag-3", capturedRequest.PartETags[2].ETag);
    }

    [Fact]
    public async Task AbortMultipartUploadAsync_WithInitiatedUpload_ShouldAbortSuccessfully()
    {
        // Arrange
        var uploader = new S3FileUploader(_s3Client);

        var initiateResponse = new InitiateMultipartUploadResponse
        {
            UploadId = TestUploadId
        };

        _s3Client
            .InitiateMultipartUploadAsync(Arg.Any<InitiateMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(initiateResponse);

        _s3Client
            .AbortMultipartUploadAsync(Arg.Any<AbortMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(new AbortMultipartUploadResponse());

        await uploader.InitiateMultipartUploadAsync(TestFileName, TestBucketName);

        // Act
        await uploader.AbortMultipartUploadAsync(CancellationToken.None);

        // Assert
        await _s3Client.Received(1).AbortMultipartUploadAsync(
            Arg.Is<AbortMultipartUploadRequest>(r =>
                r.BucketName == TestBucketName &&
                r.Key == TestFileName &&
                r.UploadId == TestUploadId),
            Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task CompleteMultipartUploadAsync_AfterCompletion_ShouldResetState()
    {
        // Arrange
        var uploader = new S3FileUploader(_s3Client);
        var testData = "Test data"u8.ToArray();
        using var partStream1 = new MemoryStream(testData);
        using var partStream2 = new MemoryStream(testData);

        var initiateResponse1 = new InitiateMultipartUploadResponse { UploadId = "upload-1" };
        var initiateResponse2 = new InitiateMultipartUploadResponse { UploadId = "upload-2" };

        var uploadPartResponse = new UploadPartResponse { ETag = "etag" };
        var completeResponse = new CompleteMultipartUploadResponse { Key = TestFileName };

        _s3Client
            .InitiateMultipartUploadAsync(Arg.Any<InitiateMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(initiateResponse1, initiateResponse2);

        _s3Client
            .UploadPartAsync(Arg.Any<UploadPartRequest>(), Arg.Any<CancellationToken>())
            .Returns(uploadPartResponse);

        _s3Client
            .CompleteMultipartUploadAsync(Arg.Any<CompleteMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(completeResponse);

        // Act
        await uploader.InitiateMultipartUploadAsync(TestFileName, TestBucketName);
        await uploader.UploadPartAsync(partStream1, CancellationToken.None);
        await uploader.CompleteMultipartUploadAsync(CancellationToken.None);

        // Act
        await uploader.InitiateMultipartUploadAsync(TestFileName, TestBucketName);
        await uploader.UploadPartAsync(partStream2, CancellationToken.None);

        // Assert
        await _s3Client.Received(1).UploadPartAsync(
            Arg.Is<UploadPartRequest>(r =>
                r.PartNumber == 1 &&
                r.UploadId == "upload-2"),
            Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task AbortMultipartUploadAsync_AfterAbort_ShouldResetState()
    {
        // Arrange
        var uploader = new S3FileUploader(_s3Client);
        var testData = "Test data"u8.ToArray();
        using var partStream1 = new MemoryStream(testData);
        using var partStream2 = new MemoryStream(testData);

        var initiateResponse1 = new InitiateMultipartUploadResponse { UploadId = "upload-1" };
        var initiateResponse2 = new InitiateMultipartUploadResponse { UploadId = "upload-2" };

        var uploadPartResponse = new UploadPartResponse { ETag = "etag" };
        var abortResponse = new AbortMultipartUploadResponse();

        _s3Client
            .InitiateMultipartUploadAsync(Arg.Any<InitiateMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(initiateResponse1, initiateResponse2);

        _s3Client
            .UploadPartAsync(Arg.Any<UploadPartRequest>(), Arg.Any<CancellationToken>())
            .Returns(uploadPartResponse);

        _s3Client
            .AbortMultipartUploadAsync(Arg.Any<AbortMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(abortResponse);

        // Act
        await uploader.InitiateMultipartUploadAsync(TestFileName, TestBucketName);
        await uploader.UploadPartAsync(partStream1, CancellationToken.None);
        await uploader.AbortMultipartUploadAsync(CancellationToken.None);

        // Act
        await uploader.InitiateMultipartUploadAsync(TestFileName, TestBucketName);
        await uploader.UploadPartAsync(partStream2, CancellationToken.None);

        // Assert
        await _s3Client.Received(1).UploadPartAsync(
            Arg.Is<UploadPartRequest>(r =>
                r.PartNumber == 1 &&
                r.UploadId == "upload-2"),
            Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task CompleteMultipartUploadAsync_WhenExceptionOccurs_ShouldStillResetState()
    {
        // Arrange
        var uploader = new S3FileUploader(_s3Client);
        var testData = "Test data"u8.ToArray();
        using var partStream1 = new MemoryStream(testData);
        using var partStream2 = new MemoryStream(testData);

        var initiateResponse1 = new InitiateMultipartUploadResponse { UploadId = "upload-1" };
        var initiateResponse2 = new InitiateMultipartUploadResponse { UploadId = "upload-2" };

        var uploadPartResponse = new UploadPartResponse { ETag = "etag" };

        _s3Client
            .InitiateMultipartUploadAsync(Arg.Any<InitiateMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(initiateResponse1, initiateResponse2);

        _s3Client
            .UploadPartAsync(Arg.Any<UploadPartRequest>(), Arg.Any<CancellationToken>())
            .Returns(uploadPartResponse);

        _s3Client
            .CompleteMultipartUploadAsync(Arg.Any<CompleteMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .ThrowsAsync(new AmazonS3Exception("S3 Error"));

        await uploader.InitiateMultipartUploadAsync(TestFileName, TestBucketName);
        await uploader.UploadPartAsync(partStream1, CancellationToken.None);

        // Act & Assert
        await Assert.ThrowsAsync<AmazonS3Exception>(async () =>
            await uploader.CompleteMultipartUploadAsync(CancellationToken.None));

        // Act
        _s3Client
            .CompleteMultipartUploadAsync(Arg.Any<CompleteMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(new CompleteMultipartUploadResponse { Key = TestFileName });

        await uploader.InitiateMultipartUploadAsync(TestFileName, TestBucketName);
        await uploader.UploadPartAsync(partStream2, CancellationToken.None);

        // Assert
        await _s3Client.Received(1).UploadPartAsync(
            Arg.Is<UploadPartRequest>(r =>
                r.PartNumber == 1 &&
                r.UploadId == "upload-2"),
            Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task AbortMultipartUploadAsync_WhenExceptionOccurs_ShouldStillResetState()
    {
        // Arrange
        var uploader = new S3FileUploader(_s3Client);
        var testData = "Test data"u8.ToArray();
        using var partStream1 = new MemoryStream(testData);
        using var partStream2 = new MemoryStream(testData);

        var initiateResponse1 = new InitiateMultipartUploadResponse { UploadId = "upload-1" };
        var initiateResponse2 = new InitiateMultipartUploadResponse { UploadId = "upload-2" };

        var uploadPartResponse = new UploadPartResponse { ETag = "etag" };

        _s3Client
            .InitiateMultipartUploadAsync(Arg.Any<InitiateMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(initiateResponse1, initiateResponse2);

        _s3Client
            .UploadPartAsync(Arg.Any<UploadPartRequest>(), Arg.Any<CancellationToken>())
            .Returns(uploadPartResponse);

        _s3Client
            .AbortMultipartUploadAsync(Arg.Any<AbortMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .ThrowsAsync(new AmazonS3Exception("S3 Error"));

        await uploader.InitiateMultipartUploadAsync(TestFileName, TestBucketName);
        await uploader.UploadPartAsync(partStream1, CancellationToken.None);

        // Act & Assert
        await Assert.ThrowsAsync<AmazonS3Exception>(async () =>
            await uploader.AbortMultipartUploadAsync(CancellationToken.None));

        // Act
        await uploader.InitiateMultipartUploadAsync(TestFileName, TestBucketName);
        await uploader.UploadPartAsync(partStream2, CancellationToken.None);

        // Assert
        await _s3Client.Received(1).UploadPartAsync(
            Arg.Is<UploadPartRequest>(r =>
                r.PartNumber == 1 &&
                r.UploadId == "upload-2"),
            Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task InitiateMultipartUploadAsync_WithCancellationToken_ShouldPassTokenToS3Client()
    {
        // Arrange
        var uploader = new S3FileUploader(_s3Client);
        var cts = new CancellationTokenSource();
        var cancellationToken = cts.Token;

        var initiateResponse = new InitiateMultipartUploadResponse
        {
            UploadId = TestUploadId
        };

        _s3Client
            .InitiateMultipartUploadAsync(Arg.Any<InitiateMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(initiateResponse);

        // Act
        await uploader.InitiateMultipartUploadAsync(TestFileName, TestBucketName, cancellationToken);

        // Assert
        await _s3Client.Received(1).InitiateMultipartUploadAsync(
            Arg.Any<InitiateMultipartUploadRequest>(),
            Arg.Is<CancellationToken>(ct => ct == cancellationToken));
    }

    [Fact]
    public async Task UploadPartAsync_WithCancellationToken_ShouldPassTokenToS3Client()
    {
        // Arrange
        var uploader = new S3FileUploader(_s3Client);
        var cts = new CancellationTokenSource();
        var cancellationToken = cts.Token;
        var testData = "Test data"u8.ToArray();
        using var partStream = new MemoryStream(testData);

        var initiateResponse = new InitiateMultipartUploadResponse
        {
            UploadId = TestUploadId
        };

        var uploadPartResponse = new UploadPartResponse
        {
            ETag = "test-etag"
        };

        _s3Client
            .InitiateMultipartUploadAsync(Arg.Any<InitiateMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(initiateResponse);

        _s3Client
            .UploadPartAsync(Arg.Any<UploadPartRequest>(), Arg.Any<CancellationToken>())
            .Returns(uploadPartResponse);

        await uploader.InitiateMultipartUploadAsync(TestFileName, TestBucketName);

        // Act
        await uploader.UploadPartAsync(partStream, cancellationToken);

        // Assert
        await _s3Client.Received(1).UploadPartAsync(
            Arg.Any<UploadPartRequest>(),
            Arg.Is<CancellationToken>(ct => ct == cancellationToken));
    }

    [Fact]
    public async Task CompleteMultipartUploadAsync_WithCancellationToken_ShouldPassTokenToS3Client()
    {
        // Arrange
        var uploader = new S3FileUploader(_s3Client);
        var cts = new CancellationTokenSource();
        var cancellationToken = cts.Token;
        var testData = "Test data"u8.ToArray();
        using var partStream = new MemoryStream(testData);

        var initiateResponse = new InitiateMultipartUploadResponse
        {
            UploadId = TestUploadId
        };

        var uploadPartResponse = new UploadPartResponse
        {
            ETag = "test-etag"
        };

        var completeResponse = new CompleteMultipartUploadResponse
        {
            Key = TestFileName
        };

        _s3Client
            .InitiateMultipartUploadAsync(Arg.Any<InitiateMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(initiateResponse);

        _s3Client
            .UploadPartAsync(Arg.Any<UploadPartRequest>(), Arg.Any<CancellationToken>())
            .Returns(uploadPartResponse);

        _s3Client
            .CompleteMultipartUploadAsync(Arg.Any<CompleteMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(completeResponse);

        await uploader.InitiateMultipartUploadAsync(TestFileName, TestBucketName);
        await uploader.UploadPartAsync(partStream, CancellationToken.None);

        // Act
        await uploader.CompleteMultipartUploadAsync(cancellationToken);

        // Assert
        await _s3Client.Received(1).CompleteMultipartUploadAsync(
            Arg.Any<CompleteMultipartUploadRequest>(),
            Arg.Is<CancellationToken>(ct => ct == cancellationToken));
    }

    [Fact]
    public async Task AbortMultipartUploadAsync_WithCancellationToken_ShouldPassTokenToS3Client()
    {
        // Arrange
        var uploader = new S3FileUploader(_s3Client);
        var cts = new CancellationTokenSource();
        var cancellationToken = cts.Token;

        var initiateResponse = new InitiateMultipartUploadResponse
        {
            UploadId = TestUploadId
        };

        _s3Client
            .InitiateMultipartUploadAsync(Arg.Any<InitiateMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(initiateResponse);

        _s3Client
            .AbortMultipartUploadAsync(Arg.Any<AbortMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(new AbortMultipartUploadResponse());

        await uploader.InitiateMultipartUploadAsync(TestFileName, TestBucketName);

        // Act
        await uploader.AbortMultipartUploadAsync(cancellationToken);

        // Assert
        await _s3Client.Received(1).AbortMultipartUploadAsync(
            Arg.Any<AbortMultipartUploadRequest>(),
            Arg.Is<CancellationToken>(ct => ct == cancellationToken));
    }
}

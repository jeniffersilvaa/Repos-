using System.Net;
using System.Text.Json;
using NSubstitute;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Infra.DataLayerReport;
using PaymentsDataLayerReports.Application.Routes.Reports.PostChargesReport;
using PaymentsDataLayerReports.Application.Routes.Reports.PostReports;
using PaymentsDataLayerReports.Application.Routes.Reports.PostReports.Models;

namespace PaymentsDataLayerReports.Unit.Test.Application.Infra.DataLayerReport;

public class DataLayerReportPreDeployClientTests
{
    private const string CorrelationId = "test-correlation";

    [Fact]
    public async Task PostChargesReport_ShouldSendCorrelationHeaderAndPayload()
    {
        // Arrange
        var handler = new TestHttpMessageHandler();
        var httpClient = new HttpClient(handler)
        {
            BaseAddress = new Uri("https://predeploy.test")
        };

        var httpClientFactory = Substitute.For<IHttpClientFactory>();
        httpClientFactory.CreateClient("dataLayerReportPreDeployClient").Returns(httpClient);

        var client = new DataLayerReportPreDeployClient(httpClientFactory);
        var request = new PostChargesReportRequest
        {
            Document = "123",
            ReportType = ReportTypeEnum.ChargesList.Name,
            StartDate = DateTimeOffset.UtcNow.AddDays(-1),
            EndDate = DateTimeOffset.UtcNow
        };

        // Act
        await client.PostChargesReport(request, CorrelationId);

        // Assert
        Assert.NotNull(handler.LastRequest);
        Assert.Equal(HttpMethod.Post, handler.LastRequest!.Method);
        Assert.Equal("/charges/report", handler.LastRequest.RequestUri!.AbsolutePath);
        Assert.Contains("document=123", handler.LastRequest.RequestUri.Query);
        Assert.True(handler.LastRequest.Headers.TryGetValues("X-Report-Correlation-Id", out IEnumerable<string>? values));
        Assert.Contains(CorrelationId, values!);

        var body = await handler.LastRequest.Content!.ReadAsStringAsync();
        Assert.Contains("\"reportType\":\"charges_list\"", body);
    }

    [Fact]
    public async Task PostChargesReport_ShouldSwallowExceptions()
    {
        // Arrange
        var handler = new TestHttpMessageHandler
        {
            ExceptionToThrow = new HttpRequestException("boom")
        };

        var httpClient = new HttpClient(handler)
        {
            BaseAddress = new Uri("https://predeploy.test")
        };

        var httpClientFactory = Substitute.For<IHttpClientFactory>();
        httpClientFactory.CreateClient("dataLayerReportPreDeployClient").Returns(httpClient);

        var client = new DataLayerReportPreDeployClient(httpClientFactory);
        var request = new PostChargesReportRequest
        {
            Document = "123",
            ReportType = ReportTypeEnum.ChargesList.Name,
            StartDate = DateTimeOffset.UtcNow.AddDays(-1),
            EndDate = DateTimeOffset.UtcNow
        };

        // Act & Assert
        await client.PostChargesReport(request, CorrelationId);
    }

    [Fact]
    public async Task PostReports_ShouldSendJsonBodyAndCorrelationHeader()
    {
        // Arrange
        var handler = new TestHttpMessageHandler();
        var httpClient = new HttpClient(handler)
        {
            BaseAddress = new Uri("https://predeploy.test")
        };

        var httpClientFactory = Substitute.For<IHttpClientFactory>();
        httpClientFactory.CreateClient("dataLayerReportPreDeployClient").Returns(httpClient);

        var client = new DataLayerReportPreDeployClient(httpClientFactory);
        var request = new PostReportsRequest
        {
            Type = "receivables",
            FileFormat = "csv",
            Filters = new ReportFilters
            {
                StartDate = new DateOnly(2025, 1, 1),
                FinalDate = new DateOnly(2025, 1, 31),
                Organizations = ["stone"],
                Identifiers = new Identifiers { Documents = ["12345678901"] }
            }
        };

        // Act
        await client.PostReports(request, CorrelationId);

        // Assert
        Assert.NotNull(handler.LastRequest);
        Assert.Equal(HttpMethod.Post, handler.LastRequest!.Method);
        Assert.Equal("/v1/reports", handler.LastRequest.RequestUri!.AbsolutePath);
        Assert.True(handler.LastRequest.Headers.TryGetValues("X-Report-Correlation-Id", out IEnumerable<string>? values));
        Assert.Contains(CorrelationId, values!);

        var body = await handler.LastRequest.Content!.ReadAsStringAsync();
        Assert.Contains("\"type\":\"receivables\"", body);
        Assert.Contains("\"file_format\":\"csv\"", body);
    }

    [Fact]
    public async Task PostReports_ShouldSwallowExceptions()
    {
        // Arrange
        var handler = new TestHttpMessageHandler
        {
            ExceptionToThrow = new HttpRequestException("boom")
        };

        var httpClient = new HttpClient(handler)
        {
            BaseAddress = new Uri("https://predeploy.test")
        };

        var httpClientFactory = Substitute.For<IHttpClientFactory>();
        httpClientFactory.CreateClient("dataLayerReportPreDeployClient").Returns(httpClient);

        var client = new DataLayerReportPreDeployClient(httpClientFactory);
        var request = new PostReportsRequest
        {
            Type = "receivables",
            FileFormat = "csv",
            Filters = new ReportFilters
            {
                StartDate = new DateOnly(2025, 1, 1),
                FinalDate = new DateOnly(2025, 1, 31),
                Organizations = ["stone"]
            }
        };

        // Act & Assert — should not throw
        await client.PostReports(request, CorrelationId);
    }

    private class TestHttpMessageHandler : HttpMessageHandler
    {
        public HttpRequestMessage? LastRequest { get; private set; }
        public HttpResponseMessage Response { get; set; } = new(HttpStatusCode.OK);
        public Exception? ExceptionToThrow { get; set; }

        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            LastRequest = request;

            if (ExceptionToThrow != null)
            {
                throw ExceptionToThrow;
            }

            return Task.FromResult(Response);
        }
    }
}

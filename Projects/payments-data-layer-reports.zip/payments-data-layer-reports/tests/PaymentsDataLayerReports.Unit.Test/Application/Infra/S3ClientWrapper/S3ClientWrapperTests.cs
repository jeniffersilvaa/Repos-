using Amazon.S3;
using Amazon.S3.Model;
using Microsoft.Extensions.Options;
using NSubstitute;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;
using S3ClientWrapperNs = PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;

namespace PaymentsDataLayerReports.Unit.Test.Application.Infra.S3ClientWrapper;

public class S3ClientWrapperTests
{
    private readonly IAmazonS3 _s3Client;
    private readonly IOptions<AwsSettings> _awsOptions;
    private readonly S3ClientWrapperNs.IS3ReportMergeService _s3ReportMergeService;
    private readonly S3ClientWrapperNs.IS3ReportMetadataHandlerService _s3ReportMetadataHandlerService;
    private readonly S3ClientWrapperNs.IS3ReportUploadService _s3ReportUploadService;
    private readonly S3ClientWrapperNs.IS3ReportFileQueryService _s3ReportFileQueryService;
    private readonly S3ClientWrapperNs.S3ClientWrapper _wrapper;

    public S3ClientWrapperTests()
    {
        _s3Client = Substitute.For<IAmazonS3>();
        _awsOptions = Options.Create(new AwsSettings { WorkgroupBucket = "test-bucket" });
        _s3ReportMergeService = Substitute.For<S3ClientWrapperNs.IS3ReportMergeService>();
        _s3ReportMetadataHandlerService = Substitute.For<S3ClientWrapperNs.IS3ReportMetadataHandlerService>();
        _s3ReportUploadService = Substitute.For<S3ClientWrapperNs.IS3ReportUploadService>();
        _s3ReportFileQueryService = Substitute.For<S3ClientWrapperNs.IS3ReportFileQueryService>();

        _wrapper = new S3ClientWrapperNs.S3ClientWrapper(
            _s3Client,
            _awsOptions,
            _s3ReportMergeService,
            _s3ReportMetadataHandlerService,
            _s3ReportUploadService,
            _s3ReportFileQueryService
        );
    }

    #region BuildReportUrl Tests

    [Fact]
    public void BuildReportUrl_WithReportId_ShouldCallS3ClientWithCorrectParameters()
    {
        // Arrange
        var reportId = "test-report-123";
        var expectedKey = $"reports/{reportId}.csv";

        _s3Client.GetPreSignedURL(Arg.Any<GetPreSignedUrlRequest>())
            .Returns("https://presigned-url.example.com");

        // Act
        var result = _wrapper.BuildReportUrl(reportId);

        // Assert
        _s3Client.Received(1).GetPreSignedURL(Arg.Is<GetPreSignedUrlRequest>(r =>
            r.BucketName == "test-bucket" &&
            r.Key == expectedKey
        ));
        Assert.NotNull(result);
    }

    [Fact]
    public void BuildReportUrl_WithCustomExpirationHours_ShouldSetCorrectExpiration()
    {
        // Arrange
        var reportId = "test-report-123";
        var expirationHours = 48.0;
        var beforeCall = DateTime.UtcNow;

        _s3Client.GetPreSignedURL(Arg.Any<GetPreSignedUrlRequest>())
            .Returns("https://presigned-url.example.com");

        // Act
        _wrapper.BuildReportUrl(reportId, expirationHours);

        // Assert
        _s3Client.Received(1).GetPreSignedURL(Arg.Is<GetPreSignedUrlRequest>(r =>
            r.Expires >= beforeCall.AddHours(expirationHours - 1) &&
            r.Expires <= DateTime.UtcNow.AddHours(expirationHours + 1)
        ));
    }

    [Fact]
    public void BuildReportUrl_WithFileName_ShouldSetContentDispositionHeader()
    {
        // Arrange
        var reportId = "test-report-123";
        var fileName = "my-report.csv";

        _s3Client.GetPreSignedURL(Arg.Any<GetPreSignedUrlRequest>())
            .Returns("https://presigned-url.example.com");

        // Act
        _wrapper.BuildReportUrl(reportId, fileName: fileName);

        // Assert
        _s3Client.Received(1).GetPreSignedURL(Arg.Is<GetPreSignedUrlRequest>(r =>
            r.ResponseHeaderOverrides != null &&
            r.ResponseHeaderOverrides.ContentDisposition == $"attachment; filename=\"{fileName}\""
        ));
    }

    [Fact]
    public void BuildReportUrl_WithoutFileName_ShouldNotSetContentDispositionHeader()
    {
        // Arrange
        var reportId = "test-report-123";

        _s3Client.GetPreSignedURL(Arg.Any<GetPreSignedUrlRequest>())
            .Returns("https://presigned-url.example.com");

        // Act
        _wrapper.BuildReportUrl(reportId);

        // Assert
        _s3Client.Received(1).GetPreSignedURL(Arg.Is<GetPreSignedUrlRequest>(r =>
            r.ResponseHeaderOverrides == null ||
            string.IsNullOrEmpty(r.ResponseHeaderOverrides.ContentDisposition)
        ));
    }

    [Fact]
    public void BuildReportUrl_WithXlsxFormat_ShouldUseXlsxExtension()
    {
        // Arrange
        var reportId = "test-report-123";
        var fileFormat = FileFormatEnum.Xlsx.Name;
        var expectedKey = $"reports/{reportId}.xlsx";

        _s3Client.GetPreSignedURL(Arg.Any<GetPreSignedUrlRequest>())
            .Returns("https://presigned-url.example.com");

        // Act
        _wrapper.BuildReportUrl(reportId, fileFormat: fileFormat);

        // Assert
        _s3Client.Received(1).GetPreSignedURL(Arg.Is<GetPreSignedUrlRequest>(r =>
            r.Key == expectedKey
        ));
    }

    [Fact]
    public void BuildReportUrl_WithNullFileFormat_ShouldDefaultToCsv()
    {
        // Arrange
        var reportId = "test-report-123";
        var expectedKey = $"reports/{reportId}.csv";

        _s3Client.GetPreSignedURL(Arg.Any<GetPreSignedUrlRequest>())
            .Returns("https://presigned-url.example.com");

        // Act
        _wrapper.BuildReportUrl(reportId, fileFormat: null);

        // Assert
        _s3Client.Received(1).GetPreSignedURL(Arg.Is<GetPreSignedUrlRequest>(r =>
            r.Key == expectedKey
        ));
    }

    [Theory]
    [InlineData("")]
    [InlineData("   ")]
    public void BuildReportUrl_WithEmptyOrWhitespaceFileName_ShouldNotSetContentDisposition(string fileName)
    {
        // Arrange
        var reportId = "test-report-123";

        _s3Client.GetPreSignedURL(Arg.Any<GetPreSignedUrlRequest>())
            .Returns("https://presigned-url.example.com");

        // Act
        _wrapper.BuildReportUrl(reportId, fileName: fileName);

        // Assert
        _s3Client.Received(1).GetPreSignedURL(Arg.Is<GetPreSignedUrlRequest>(r =>
            r.ResponseHeaderOverrides == null ||
            string.IsNullOrEmpty(r.ResponseHeaderOverrides.ContentDisposition)
        ));
    }

    #endregion

    #region Delegation Tests

    [Fact]
    public async Task MergeReportFilesAsync_ShouldDelegateToMergeService()
    {
        // Arrange
        var concatId = "concat-123";
        var metadata = CreateTestMetadata("report-123");
        var cancellationToken = CancellationToken.None;

        // Act
        await _wrapper.MergeReportFilesAsync(concatId, metadata, cancellationToken);

        // Assert
        await _s3ReportMergeService.Received(1).MergeReportFilesAsync(concatId, metadata, cancellationToken);
    }

    [Fact]
    public async Task GetReportMetadataAsync_ShouldDelegateToMetadataHandlerService()
    {
        // Arrange
        var reportId = "report-123";
        var expectedMetadata = CreateTestMetadata(reportId);
        _s3ReportMetadataHandlerService.GetReportMetadataAsync(reportId).Returns(expectedMetadata);

        // Act
        var result = await _wrapper.GetReportMetadataAsync(reportId);

        // Assert
        await _s3ReportMetadataHandlerService.Received(1).GetReportMetadataAsync(reportId);
        Assert.Equal(expectedMetadata, result);
    }

    [Fact]
    public async Task ReportFileExistsAsync_ShouldDelegateToFileQueryService()
    {
        // Arrange
        var reportId = "report-123";
        _s3ReportFileQueryService.ReportFileExistsAsync(reportId, null).Returns(true);

        // Act
        var result = await _wrapper.ReportFileExistsAsync(reportId);

        // Assert
        await _s3ReportFileQueryService.Received(1).ReportFileExistsAsync(reportId, null);
        Assert.True(result);
    }

    [Fact]
    public async Task GetReportFileWithFormatAsync_ShouldDelegateToFileQueryService()
    {
        // Arrange
        var reportId = "report-123";
        _s3ReportFileQueryService.GetReportFileWithFormatAsync(reportId).Returns((true, "csv"));

        // Act
        var (exists, fileFormat) = await _wrapper.GetReportFileWithFormatAsync(reportId);

        // Assert
        await _s3ReportFileQueryService.Received(1).GetReportFileWithFormatAsync(reportId);
        Assert.True(exists);
        Assert.Equal("csv", fileFormat);
    }

    [Fact]
    public async Task UploadReportMetadataAsync_ShouldDelegateToMetadataHandlerService()
    {
        // Arrange
        var metadata = CreateTestMetadata("report-123");

        // Act
        await _wrapper.UploadReportMetadataAsync(metadata);

        // Assert
        await _s3ReportMetadataHandlerService.Received(1).UploadReportMetadataAsync(metadata);
    }

    [Fact]
    public async Task UploadReportAsync_ShouldDelegateToUploadService()
    {
        // Arrange
        var sourcePath = "/path/to/file";
        var reportId = "report-123";
        var partitionIdGroup = "partition-1";
        var partitionDate = DateTime.UtcNow;

        // Act
        await _wrapper.UploadReportAsync(sourcePath, reportId, partitionIdGroup, partitionDate);

        // Assert
        await _s3ReportUploadService.Received(1).UploadReportAsync(sourcePath, reportId, partitionIdGroup, partitionDate, null);
    }

    [Fact]
    public async Task UploadReportHeaderAsync_ShouldDelegateToUploadService()
    {
        // Arrange
        var reportId = "report-123";
        var header = "col1,col2,col3";

        // Act
        await _wrapper.UploadReportHeaderAsync(reportId, header);

        // Assert
        await _s3ReportUploadService.Received(1).UploadReportHeaderAsync(reportId, header);
    }

    #endregion

    #region Helpers

    private static ReportMetadata CreateTestMetadata(string reportId)
    {
        return new ReportMetadata
        {
            ReportId = reportId,
            Status = "Processing",
            DispatchId = "dispatch-1",
            CreatedAt = DateTime.UtcNow,
            ReportSortColumnIndex = 0,
            ProcessorQueueName = "queue",
            FileFormat = "csv"
        };
    }

    #endregion
}

using System.Text;
using Amazon.S3;
using Amazon.S3.Model;
using Microsoft.Extensions.Options;
using NSubstitute;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Models;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;
using PaymentsDataLayerReports.Application.Workers.ChargeReportWorker;

namespace PaymentsDataLayerReports.Unit.Test.Application.Infra.S3ClientWrapper;

public class S3CsvPartialReportRecordSourceTests
{
    private readonly IAmazonS3 _s3Client;
    private readonly IOptions<AwsSettings> _awsOptions;
    private readonly S3CsvPartialReportRecordSource _source;

    public S3CsvPartialReportRecordSourceTests()
    {
        _s3Client = Substitute.For<IAmazonS3>();
        _awsOptions = Options.Create(new AwsSettings { WorkgroupBucket = "test-bucket" });
        _source = new S3CsvPartialReportRecordSource(_s3Client, _awsOptions);
    }

    private static ReportMetadata CreateMetadata(DateTime date, int sortColumnIndex = 0)
    {
        return new ReportMetadata
        {
            Status = "Processing",
            ReportId = "test-report",
            DispatchId = "dispatch-1",
            CreatedAt = DateTime.UtcNow,
            ReportSortColumnIndex = sortColumnIndex,
            ProcessorQueueName = "queue",
            FileFormat = "csv",
            ChargeReportParameters = new ChargeReportsWorkerParameters
            {
                ReportType = "charges_list",
                StartDate = date,
                EndDate = date
            }
        };
    }

    private static GetObjectResponse CreateGetObjectResponse(string content)
    {
        return new GetObjectResponse
        {
            ResponseStream = new MemoryStream(Encoding.UTF8.GetBytes(content))
        };
    }

    [Fact]
    public async Task GetPartitionStreamsForDateAsync_WithNoObjects_ShouldYieldNoPartitions()
    {
        // Arrange
        var date = new DateTime(2025, 1, 1);
        var metadata = CreateMetadata(date);

        _s3Client.ListObjectsV2Async(Arg.Any<ListObjectsV2Request>(), Arg.Any<CancellationToken>())
            .Returns(new ListObjectsV2Response
            {
                S3Objects = [],
                IsTruncated = false
            });

        // Act
        var partitions = new List<IAsyncEnumerable<ReportRecord>>();
        await foreach (var partition in _source.GetPartitionStreamsForDateAsync(metadata, date, CancellationToken.None))
        {
            partitions.Add(partition);
        }

        // Assert
        Assert.Empty(partitions);
    }

    [Fact]
    public async Task GetPartitionStreamsForDateAsync_WithEmptyObjects_ShouldSkipThem()
    {
        // Arrange
        var date = new DateTime(2025, 1, 1);
        var metadata = CreateMetadata(date);

        _s3Client.ListObjectsV2Async(Arg.Any<ListObjectsV2Request>(), Arg.Any<CancellationToken>())
            .Returns(new ListObjectsV2Response
            {
                S3Objects =
                [
                    new S3Object { Key = "empty-file.csv", Size = 0 }
                ],
                IsTruncated = false
            });

        // Act
        var partitions = new List<IAsyncEnumerable<ReportRecord>>();
        await foreach (var partition in _source.GetPartitionStreamsForDateAsync(metadata, date, CancellationToken.None))
        {
            partitions.Add(partition);
        }

        // Assert
        Assert.Empty(partitions);
    }

    [Fact]
    public async Task GetPartitionStreamsForDateAsync_WithValidObject_ShouldYieldPartition()
    {
        // Arrange
        var date = new DateTime(2025, 1, 1);
        var metadata = CreateMetadata(date);
        var csvContent = "2025-01-01,100\n2025-01-02,200";

        _s3Client.ListObjectsV2Async(Arg.Any<ListObjectsV2Request>(), Arg.Any<CancellationToken>())
            .Returns(new ListObjectsV2Response
            {
                S3Objects =
                [
                    new S3Object { Key = "partial-1.csv", Size = 100 }
                ],
                IsTruncated = false
            });

        _s3Client.GetObjectAsync(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(CreateGetObjectResponse(csvContent));

        // Act
        var partitions = new List<IAsyncEnumerable<ReportRecord>>();
        await foreach (var partition in _source.GetPartitionStreamsForDateAsync(metadata, date, CancellationToken.None))
        {
            partitions.Add(partition);
        }

        // Assert
        Assert.Single(partitions);
    }

    [Fact]
    public async Task GetPartitionStreamsForDateAsync_ShouldParseRecordsWithCorrectSortKey()
    {
        // Arrange
        var date = new DateTime(2025, 1, 1);
        var metadata = CreateMetadata(date, sortColumnIndex: 0);
        var csvContent = "2025-01-01,100\n2025-01-02,200";

        _s3Client.ListObjectsV2Async(Arg.Any<ListObjectsV2Request>(), Arg.Any<CancellationToken>())
            .Returns(new ListObjectsV2Response
            {
                S3Objects =
                [
                    new S3Object { Key = "partial-1.csv", Size = 100 }
                ],
                IsTruncated = false
            });

        _s3Client.GetObjectAsync(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(CreateGetObjectResponse(csvContent));

        // Act
        var records = new List<ReportRecord>();
        await foreach (var partition in _source.GetPartitionStreamsForDateAsync(metadata, date, CancellationToken.None))
        {
            await foreach (var record in partition)
            {
                records.Add(record);
            }
        }

        // Assert
        Assert.Equal(2, records.Count);
        Assert.Equal("2025-01-01", records[0].SortKey);
        Assert.Equal("2025-01-02", records[1].SortKey);
    }

    [Fact]
    public async Task GetPartitionStreamsForDateAsync_WithSecondColumnAsSortKey_ShouldParseCorrectly()
    {
        // Arrange
        var date = new DateTime(2025, 1, 1);
        var metadata = CreateMetadata(date, sortColumnIndex: 1);
        var csvContent = "col1,2025-01-01,col3\ncol1,2025-01-02,col3";

        _s3Client.ListObjectsV2Async(Arg.Any<ListObjectsV2Request>(), Arg.Any<CancellationToken>())
            .Returns(new ListObjectsV2Response
            {
                S3Objects =
                [
                    new S3Object { Key = "partial-1.csv", Size = 100 }
                ],
                IsTruncated = false
            });

        _s3Client.GetObjectAsync(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(CreateGetObjectResponse(csvContent));

        // Act
        var records = new List<ReportRecord>();
        await foreach (var partition in _source.GetPartitionStreamsForDateAsync(metadata, date, CancellationToken.None))
        {
            await foreach (var record in partition)
            {
                records.Add(record);
            }
        }

        // Assert
        Assert.Equal(2, records.Count);
        Assert.Equal("2025-01-01", records[0].SortKey);
        Assert.Equal("2025-01-02", records[1].SortKey);
    }

    [Fact]
    public async Task GetPartitionStreamsForDateAsync_WithInvalidLine_ShouldSkipIt()
    {
        // Arrange
        var date = new DateTime(2025, 1, 1);
        var metadata = CreateMetadata(date, sortColumnIndex: 2);
        var csvContent = "only,two\nvalid,line,here";

        _s3Client.ListObjectsV2Async(Arg.Any<ListObjectsV2Request>(), Arg.Any<CancellationToken>())
            .Returns(new ListObjectsV2Response
            {
                S3Objects =
                [
                    new S3Object { Key = "partial-1.csv", Size = 100 }
                ],
                IsTruncated = false
            });

        _s3Client.GetObjectAsync(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(CreateGetObjectResponse(csvContent));

        // Act
        var records = new List<ReportRecord>();
        await foreach (var partition in _source.GetPartitionStreamsForDateAsync(metadata, date, CancellationToken.None))
        {
            await foreach (var record in partition)
            {
                records.Add(record);
            }
        }

        // Assert
        Assert.Single(records);
        Assert.Equal("here", records[0].SortKey);
    }

    [Fact]
    public async Task GetPartitionStreamsForDateAsync_WithPaginatedResults_ShouldYieldAllPartitions()
    {
        // Arrange
        var date = new DateTime(2025, 1, 1);
        var metadata = CreateMetadata(date);

        var firstResponse = new ListObjectsV2Response
        {
            S3Objects = [new S3Object { Key = "partial-1.csv", Size = 100 }],
            IsTruncated = true,
            NextContinuationToken = "token-1"
        };

        var secondResponse = new ListObjectsV2Response
        {
            S3Objects = [new S3Object { Key = "partial-2.csv", Size = 100 }],
            IsTruncated = false
        };

        _s3Client.ListObjectsV2Async(
            Arg.Is<ListObjectsV2Request>(r => r.ContinuationToken == null),
            Arg.Any<CancellationToken>())
            .Returns(firstResponse);

        _s3Client.ListObjectsV2Async(
            Arg.Is<ListObjectsV2Request>(r => r.ContinuationToken == "token-1"),
            Arg.Any<CancellationToken>())
            .Returns(secondResponse);

        _s3Client.GetObjectAsync(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(CreateGetObjectResponse("2025-01-01,100"));

        // Act
        var partitions = new List<IAsyncEnumerable<ReportRecord>>();
        await foreach (var partition in _source.GetPartitionStreamsForDateAsync(metadata, date, CancellationToken.None))
        {
            partitions.Add(partition);
        }

        // Assert
        Assert.Equal(2, partitions.Count);
    }

    [Fact]
    public async Task GetPartitionStreamsForDateAsync_WhenCancelled_ShouldThrowOperationCanceledException()
    {
        // Arrange
        var date = new DateTime(2025, 1, 1);
        var metadata = CreateMetadata(date);
        using var cts = new CancellationTokenSource();
        cts.Cancel();

        _s3Client.ListObjectsV2Async(Arg.Any<ListObjectsV2Request>(), Arg.Any<CancellationToken>())
            .Returns(new ListObjectsV2Response
            {
                S3Objects = [new S3Object { Key = "partial-1.csv", Size = 100 }],
                IsTruncated = false
            });

        // Act & Assert
        await Assert.ThrowsAsync<OperationCanceledException>(async () =>
        {
            await foreach (var _ in _source.GetPartitionStreamsForDateAsync(metadata, date, cts.Token))
            {
                // Intentionally empty: just force full enumeration to trigger cancellation
            }
        });
    }
}

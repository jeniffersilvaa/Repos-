using Amazon.S3;
using Amazon.S3.Transfer;
using Microsoft.Extensions.Options;
using NSubstitute;
using NSubstitute.ExceptionExtensions;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Settings;

namespace PaymentsDataLayerReports.Unit.Test.Application.Infra.S3ClientWrapper;

public class S3ReportUploadServiceTests
{
    private readonly IAmazonS3 _s3Client;
    private readonly IOptions<AwsSettings> _awsOptions;
    private readonly ITransferUtility _transferUtility;
    private readonly S3ReportUploadService _service;

    public S3ReportUploadServiceTests()
    {
        _s3Client = Substitute.For<IAmazonS3>();
        _awsOptions = Options.Create(new AwsSettings { WorkgroupBucket = "test-bucket" });
        _transferUtility = Substitute.For<ITransferUtility>();
        _service = new S3ReportUploadService(_s3Client, _awsOptions, _transferUtility);
    }

    #region UploadReportAsync Tests

    [Fact]
    public async Task UploadReportAsync_WhenFileNotFound_ShouldThrowFileNotFoundException()
    {
        // Arrange
        var sourcePath = "/non/existent/path/file.csv";
        var reportId = "test-report";
        var partitionIdGroup = "partition-1";

        // Act & Assert
        var exception = await Assert.ThrowsAsync<FileNotFoundException>(() =>
            _service.UploadReportAsync(sourcePath, reportId, partitionIdGroup));

        Assert.Contains(sourcePath, exception.Message);
    }

    [Fact]
    public async Task UploadReportAsync_WithoutPartitionDate_ShouldUploadToReportBasePath()
    {
        // Arrange
        var tempFile = Path.GetTempFileName();
        try
        {
            var reportId = "test-report";
            var partitionIdGroup = "partition-1";

            // Act
            await _service.UploadReportAsync(tempFile, reportId, partitionIdGroup);

            // Assert
            await _transferUtility.Received(1).UploadAsync(
                tempFile,
                "test-bucket",
                $"reports/{reportId}.csv");
        }
        finally
        {
            File.Delete(tempFile);
        }
    }

    [Fact]
    public async Task UploadReportAsync_WithPartitionDateAndXlsxFormat_ShouldStillUseCsvExtensionForPartials()
    {
        // Arrange
        var tempFile = Path.GetTempFileName();
        try
        {
            var reportId = "test-report";
            var partitionIdGroup = "partition-1";
            var partitionDate = new DateTime(2025, 1, 15);
            var fileFormat = FileFormatEnum.Xlsx.Name;

            // Act
            await _service.UploadReportAsync(tempFile, reportId, partitionIdGroup, partitionDate, fileFormat);

            // Assert - Partial files are always CSV regardless of fileFormat
            await _transferUtility.Received(1).UploadAsync(
                tempFile,
                "test-bucket",
                $"reports/partial/{reportId}/2025-01-15/{partitionIdGroup}.csv");
        }
        finally
        {
            File.Delete(tempFile);
        }
    }

    [Fact]
    public async Task UploadReportAsync_WithPartitionDate_ShouldUploadToPartialReportPath()
    {
        // Arrange
        var tempFile = Path.GetTempFileName();
        try
        {
            var reportId = "test-report";
            var partitionIdGroup = "partition-1";
            var partitionDate = new DateTime(2025, 1, 15);

            // Act
            await _service.UploadReportAsync(tempFile, reportId, partitionIdGroup, partitionDate);

            // Assert
            await _transferUtility.Received(1).UploadAsync(
                tempFile,
                "test-bucket",
                $"reports/partial/{reportId}/2025-01-15/{partitionIdGroup}.csv");
        }
        finally
        {
            File.Delete(tempFile);
        }
    }

    [Fact]
    public async Task UploadReportAsync_WithXlsxFormat_ShouldUseXlsxExtension()
    {
        // Arrange
        var tempFile = Path.GetTempFileName();
        try
        {
            var reportId = "test-report";
            var partitionIdGroup = "partition-1";
            var fileFormat = FileFormatEnum.Xlsx.Name;

            // Act
            await _service.UploadReportAsync(tempFile, reportId, partitionIdGroup, fileFormat: fileFormat);

            // Assert
            await _transferUtility.Received(1).UploadAsync(
                tempFile,
                "test-bucket",
                $"reports/{reportId}.xlsx");
        }
        finally
        {
            File.Delete(tempFile);
        }
    }

    [Fact]
    public async Task UploadReportAsync_WhenTransferUtilityThrows_ShouldRethrowException()
    {
        // Arrange
        var tempFile = Path.GetTempFileName();
        try
        {
            var reportId = "test-report";
            var partitionIdGroup = "partition-1";

            _transferUtility.UploadAsync(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<string>())
                .ThrowsAsync(new Exception("Upload failed"));

            // Act & Assert
            await Assert.ThrowsAsync<Exception>(() =>
                _service.UploadReportAsync(tempFile, reportId, partitionIdGroup));
        }
        finally
        {
            File.Delete(tempFile);
        }
    }

    #endregion

    #region UploadReportHeaderAsync Tests

    [Fact]
    public async Task UploadReportHeaderAsync_ShouldUploadToCorrectPath()
    {
        // Arrange
        var reportId = "test-report";
        var header = "col1,col2,col3";

        // Act
        await _service.UploadReportHeaderAsync(reportId, header);

        // Assert - Verify WriteStringAsync extension method was called on S3 client
        // Since WriteStringAsync is an extension method, we verify PutObjectAsync was called
        await _s3Client.Received(1).PutObjectAsync(
            Arg.Is<Amazon.S3.Model.PutObjectRequest>(r =>
                r.BucketName == "test-bucket" &&
                r.Key == $"reports/partial/{reportId}/header.csv" &&
                r.ContentType == "text/csv"),
            Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task UploadReportHeaderAsync_WhenS3Throws_ShouldRethrowException()
    {
        // Arrange
        var reportId = "test-report";
        var header = "col1,col2,col3";

        _s3Client.PutObjectAsync(Arg.Any<Amazon.S3.Model.PutObjectRequest>(), Arg.Any<CancellationToken>())
            .ThrowsAsync(new Exception("S3 error"));

        // Act & Assert
        await Assert.ThrowsAsync<Exception>(() =>
            _service.UploadReportHeaderAsync(reportId, header));
    }

    #endregion
}

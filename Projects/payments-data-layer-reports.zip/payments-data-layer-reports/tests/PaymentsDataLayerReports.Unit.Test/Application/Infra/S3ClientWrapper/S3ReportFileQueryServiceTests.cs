using System.Net;
using Amazon.S3;
using Amazon.S3.Model;
using Microsoft.Extensions.Options;
using NSubstitute;
using NSubstitute.ExceptionExtensions;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Settings;

namespace PaymentsDataLayerReports.Unit.Test.Application.Infra.S3ClientWrapper;

public class S3ReportFileQueryServiceTests
{
    private readonly IAmazonS3 _s3Client;
    private readonly IOptions<AwsSettings> _awsOptions;
    private readonly S3ReportFileQueryService _service;

    public S3ReportFileQueryServiceTests()
    {
        _s3Client = Substitute.For<IAmazonS3>();
        _awsOptions = Options.Create(new AwsSettings { WorkgroupBucket = "test-bucket" });
        _service = new S3ReportFileQueryService(_s3Client, _awsOptions);
    }

    [Fact]
    public async Task ReportFileExistsAsync_WhenFileExists_ShouldReturnTrue()
    {
        // Arrange
        var reportId = "test-report-123";
        _s3Client.GetObjectMetadataAsync(Arg.Any<GetObjectMetadataRequest>(), Arg.Any<CancellationToken>())
            .Returns(new GetObjectMetadataResponse());

        // Act
        var result = await _service.ReportFileExistsAsync(reportId);

        // Assert
        Assert.True(result);
        await _s3Client.Received(1).GetObjectMetadataAsync(
            Arg.Is<GetObjectMetadataRequest>(r =>
                r.BucketName == "test-bucket" &&
                r.Key == $"reports/{reportId}.csv"),
            Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task ReportFileExistsAsync_WhenFileNotFound_ShouldReturnFalse()
    {
        // Arrange
        var reportId = "non-existent-report";
        var notFoundException = new AmazonS3Exception("Not Found")
        {
            StatusCode = HttpStatusCode.NotFound
        };
        _s3Client.GetObjectMetadataAsync(Arg.Any<GetObjectMetadataRequest>(), Arg.Any<CancellationToken>())
            .ThrowsAsync(notFoundException);

        // Act
        var result = await _service.ReportFileExistsAsync(reportId);

        // Assert
        Assert.False(result);
    }

    [Fact]
    public async Task ReportFileExistsAsync_WhenOtherS3Error_ShouldReturnFalse()
    {
        // Arrange
        var reportId = "test-report-123";
        var s3Exception = new AmazonS3Exception("Internal Server Error")
        {
            StatusCode = HttpStatusCode.InternalServerError
        };
        _s3Client.GetObjectMetadataAsync(Arg.Any<GetObjectMetadataRequest>(), Arg.Any<CancellationToken>())
            .ThrowsAsync(s3Exception);

        // Act
        var result = await _service.ReportFileExistsAsync(reportId);

        // Assert
        Assert.False(result);
    }

    [Fact]
    public async Task ReportFileExistsAsync_WithXlsxFormat_ShouldUseXlsxExtension()
    {
        // Arrange
        var reportId = "test-report-123";
        var fileFormat = FileFormatEnum.Xlsx.Name;
        _s3Client.GetObjectMetadataAsync(Arg.Any<GetObjectMetadataRequest>(), Arg.Any<CancellationToken>())
            .Returns(new GetObjectMetadataResponse());

        // Act
        var result = await _service.ReportFileExistsAsync(reportId, fileFormat);

        // Assert
        Assert.True(result);
        await _s3Client.Received(1).GetObjectMetadataAsync(
            Arg.Is<GetObjectMetadataRequest>(r =>
                r.Key == $"reports/{reportId}.xlsx"),
            Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task ReportFileExistsAsync_WithNullFormat_ShouldDefaultToCsv()
    {
        // Arrange
        var reportId = "test-report-123";
        _s3Client.GetObjectMetadataAsync(Arg.Any<GetObjectMetadataRequest>(), Arg.Any<CancellationToken>())
            .Returns(new GetObjectMetadataResponse());

        // Act
        var result = await _service.ReportFileExistsAsync(reportId, null);

        // Assert
        Assert.True(result);
        await _s3Client.Received(1).GetObjectMetadataAsync(
            Arg.Is<GetObjectMetadataRequest>(r =>
                r.Key == $"reports/{reportId}.csv"),
            Arg.Any<CancellationToken>());
    }

    [Theory]
    [InlineData("csv")]
    [InlineData("xlsx")]
    public async Task ReportFileExistsAsync_WithDifferentFormats_ShouldUseCorrectExtension(string fileFormat)
    {
        // Arrange
        var reportId = "test-report-123";
        _s3Client.GetObjectMetadataAsync(Arg.Any<GetObjectMetadataRequest>(), Arg.Any<CancellationToken>())
            .Returns(new GetObjectMetadataResponse());

        // Act
        var result = await _service.ReportFileExistsAsync(reportId, fileFormat);

        // Assert
        Assert.True(result);
        await _s3Client.Received(1).GetObjectMetadataAsync(
            Arg.Is<GetObjectMetadataRequest>(r =>
                r.Key == $"reports/{reportId}.{fileFormat}"),
            Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task GetReportFileWithFormatAsync_WhenCsvFileExists_ShouldReturnTrueWithCsvFormat()
    {
        // Arrange
        var reportId = "test-report-123";
        var response = new ListObjectsV2Response
        {
            S3Objects = new List<S3Object>
            {
                new S3Object { Key = $"reports/{reportId}.csv" }
            }
        };
        _s3Client.ListObjectsV2Async(Arg.Any<ListObjectsV2Request>(), Arg.Any<CancellationToken>())
            .Returns(response);

        // Act
        var (exists, fileFormat) = await _service.GetReportFileWithFormatAsync(reportId);

        // Assert
        Assert.True(exists);
        Assert.Equal("csv", fileFormat);
        await _s3Client.Received(1).ListObjectsV2Async(
            Arg.Is<ListObjectsV2Request>(r =>
                r.BucketName == "test-bucket" &&
                r.Prefix == $"reports/{reportId}." &&
                r.MaxKeys == 1),
            Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task GetReportFileWithFormatAsync_WhenXlsxFileExists_ShouldReturnTrueWithXlsxFormat()
    {
        // Arrange
        var reportId = "test-report-123";
        var response = new ListObjectsV2Response
        {
            S3Objects = new List<S3Object>
            {
                new S3Object { Key = $"reports/{reportId}.xlsx" }
            }
        };
        _s3Client.ListObjectsV2Async(Arg.Any<ListObjectsV2Request>(), Arg.Any<CancellationToken>())
            .Returns(response);

        // Act
        var (exists, fileFormat) = await _service.GetReportFileWithFormatAsync(reportId);

        // Assert
        Assert.True(exists);
        Assert.Equal("xlsx", fileFormat);
    }

    [Fact]
    public async Task GetReportFileWithFormatAsync_WhenNoFileExists_ShouldReturnFalseWithNullFormat()
    {
        // Arrange
        var reportId = "non-existent-report";
        var response = new ListObjectsV2Response
        {
            S3Objects = new List<S3Object>()
        };
        _s3Client.ListObjectsV2Async(Arg.Any<ListObjectsV2Request>(), Arg.Any<CancellationToken>())
            .Returns(response);

        // Act
        var (exists, fileFormat) = await _service.GetReportFileWithFormatAsync(reportId);

        // Assert
        Assert.False(exists);
        Assert.Null(fileFormat);
    }

    [Fact]
    public async Task GetReportFileWithFormatAsync_WhenS3ErrorOccurs_ShouldReturnFalseWithNullFormat()
    {
        // Arrange
        var reportId = "test-report-123";
        var s3Exception = new AmazonS3Exception("Internal Server Error")
        {
            StatusCode = System.Net.HttpStatusCode.InternalServerError
        };
        _s3Client.ListObjectsV2Async(Arg.Any<ListObjectsV2Request>(), Arg.Any<CancellationToken>())
            .ThrowsAsync(s3Exception);

        // Act
        var (exists, fileFormat) = await _service.GetReportFileWithFormatAsync(reportId);

        // Assert
        Assert.False(exists);
        Assert.Null(fileFormat);
    }
}

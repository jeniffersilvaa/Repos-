using System.Text;
using Amazon.S3;
using Amazon.S3.Model;
using Microsoft.Extensions.Options;
using NSubstitute;
using NSubstitute.ExceptionExtensions;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;
using PaymentsDataLayerReports.Application.Workers.ChargeReportWorker;

namespace PaymentsDataLayerReports.Unit.Test.Application.Infra.S3ClientWrapper;

public class S3ReportMergeServiceTests
{
    private readonly IAmazonS3 _s3Client;
    private readonly IOptions<AwsSettings> _awsOptions;
    private readonly S3ReportMergeService _service;

    public S3ReportMergeServiceTests()
    {
        _s3Client = Substitute.For<IAmazonS3>();
        _awsOptions = Options.Create(new AwsSettings { WorkgroupBucket = "test-bucket" });
        _service = new S3ReportMergeService(_s3Client, _awsOptions);
    }

    private static ReportMetadata CreateTestMetadata(DateTime startDate, DateTime endDate, int sortColumnIndex = 0)
    {
        return new ReportMetadata
        {
            ReportId = "test-report",
            Status = "Processing",
            DispatchId = "dispatch-1",
            CreatedAt = DateTime.UtcNow,
            ReportSortColumnIndex = sortColumnIndex,
            ProcessorQueueName = "queue",
            FileFormat = "csv",
            ChargeReportParameters = new ChargeReportsWorkerParameters
            {
                ReportType = "charges_list",
                StartDate = startDate,
                EndDate = endDate
            }
        };
    }

    private static GetObjectResponse CreateGetObjectResponse(string content)
    {
        return new GetObjectResponse
        {
            ResponseStream = new MemoryStream(Encoding.UTF8.GetBytes(content))
        };
    }

    [Fact]
    public async Task MergeReportFilesAsync_ShouldInitiateMultipartUpload()
    {
        // Arrange
        var metadata = CreateTestMetadata(new DateTime(2025, 1, 1), new DateTime(2025, 1, 1));
        var concatId = "concat-123";

        _s3Client.InitiateMultipartUploadAsync(Arg.Any<InitiateMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(new InitiateMultipartUploadResponse { UploadId = "upload-123" });

        _s3Client.GetObjectAsync(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(CreateGetObjectResponse("header1,header2\n"));

        _s3Client.ListObjectsV2Async(Arg.Any<ListObjectsV2Request>(), Arg.Any<CancellationToken>())
            .Returns(new ListObjectsV2Response { S3Objects = [], IsTruncated = false });

        _s3Client.UploadPartAsync(Arg.Any<UploadPartRequest>(), Arg.Any<CancellationToken>())
            .Returns(new UploadPartResponse { ETag = "etag-1" });

        _s3Client.CompleteMultipartUploadAsync(Arg.Any<CompleteMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(new CompleteMultipartUploadResponse());

        // Act
        await _service.MergeReportFilesAsync(concatId, metadata, CancellationToken.None);

        // Assert
        await _s3Client.Received(1).InitiateMultipartUploadAsync(
            Arg.Is<InitiateMultipartUploadRequest>(r =>
                r.BucketName == "test-bucket" &&
                r.Key == "reports/test-report.csv"),
            Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task MergeReportFilesAsync_ShouldReadHeaderFile()
    {
        // Arrange
        var metadata = CreateTestMetadata(new DateTime(2025, 1, 1), new DateTime(2025, 1, 1));
        var concatId = "concat-123";

        _s3Client.InitiateMultipartUploadAsync(Arg.Any<InitiateMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(new InitiateMultipartUploadResponse { UploadId = "upload-123" });

        _s3Client.GetObjectAsync(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(CreateGetObjectResponse("header1,header2\n"));

        _s3Client.ListObjectsV2Async(Arg.Any<ListObjectsV2Request>(), Arg.Any<CancellationToken>())
            .Returns(new ListObjectsV2Response { S3Objects = [], IsTruncated = false });

        _s3Client.UploadPartAsync(Arg.Any<UploadPartRequest>(), Arg.Any<CancellationToken>())
            .Returns(new UploadPartResponse { ETag = "etag-1" });

        _s3Client.CompleteMultipartUploadAsync(Arg.Any<CompleteMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(new CompleteMultipartUploadResponse());

        // Act
        await _service.MergeReportFilesAsync(concatId, metadata, CancellationToken.None);

        // Assert
        await _s3Client.Received(1).GetObjectAsync(
            "test-bucket",
            "reports/partial/test-report/header.csv",
            Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task MergeReportFilesAsync_ShouldCompleteMultipartUpload()
    {
        // Arrange
        var metadata = CreateTestMetadata(new DateTime(2025, 1, 1), new DateTime(2025, 1, 1));
        var concatId = "concat-123";

        _s3Client.InitiateMultipartUploadAsync(Arg.Any<InitiateMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(new InitiateMultipartUploadResponse { UploadId = "upload-123" });

        _s3Client.GetObjectAsync(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(CreateGetObjectResponse("header1,header2\n"));

        _s3Client.ListObjectsV2Async(Arg.Any<ListObjectsV2Request>(), Arg.Any<CancellationToken>())
            .Returns(new ListObjectsV2Response { S3Objects = [], IsTruncated = false });

        _s3Client.UploadPartAsync(Arg.Any<UploadPartRequest>(), Arg.Any<CancellationToken>())
            .Returns(new UploadPartResponse { ETag = "etag-1" });

        _s3Client.CompleteMultipartUploadAsync(Arg.Any<CompleteMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(new CompleteMultipartUploadResponse());

        // Act
        await _service.MergeReportFilesAsync(concatId, metadata, CancellationToken.None);

        // Assert
        await _s3Client.Received(1).CompleteMultipartUploadAsync(
            Arg.Is<CompleteMultipartUploadRequest>(r =>
                r.BucketName == "test-bucket" &&
                r.Key == "reports/test-report.csv" &&
                r.UploadId == "upload-123"),
            Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task MergeReportFilesAsync_WhenExceptionOccurs_ShouldAbortMultipartUpload()
    {
        // Arrange
        var metadata = CreateTestMetadata(new DateTime(2025, 1, 1), new DateTime(2025, 1, 1));
        var concatId = "concat-123";

        _s3Client.InitiateMultipartUploadAsync(Arg.Any<InitiateMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(new InitiateMultipartUploadResponse { UploadId = "upload-123" });

        _s3Client.GetObjectAsync(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .ThrowsAsync(new Exception("S3 error"));

        _s3Client.AbortMultipartUploadAsync(Arg.Any<AbortMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(new AbortMultipartUploadResponse());

        // Act & Assert
        await Assert.ThrowsAsync<Exception>(() =>
            _service.MergeReportFilesAsync(concatId, metadata, CancellationToken.None));

        await _s3Client.Received(1).AbortMultipartUploadAsync(
            Arg.Is<AbortMultipartUploadRequest>(r =>
                r.BucketName == "test-bucket" &&
                r.Key == "reports/test-report.csv" &&
                r.UploadId == "upload-123"),
            Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task MergeReportFilesAsync_WithMultipleDates_ShouldListObjectsForEachDate()
    {
        // Arrange
        var startDate = new DateTime(2025, 1, 1);
        var endDate = new DateTime(2025, 1, 3);
        var metadata = CreateTestMetadata(startDate, endDate);
        var concatId = "concat-123";

        _s3Client.InitiateMultipartUploadAsync(Arg.Any<InitiateMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(new InitiateMultipartUploadResponse { UploadId = "upload-123" });

        _s3Client.GetObjectAsync(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(CreateGetObjectResponse("header1,header2\n"));

        _s3Client.ListObjectsV2Async(Arg.Any<ListObjectsV2Request>(), Arg.Any<CancellationToken>())
            .Returns(new ListObjectsV2Response { S3Objects = [], IsTruncated = false });

        _s3Client.UploadPartAsync(Arg.Any<UploadPartRequest>(), Arg.Any<CancellationToken>())
            .Returns(new UploadPartResponse { ETag = "etag-1" });

        _s3Client.CompleteMultipartUploadAsync(Arg.Any<CompleteMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(new CompleteMultipartUploadResponse());

        // Act
        await _service.MergeReportFilesAsync(concatId, metadata, CancellationToken.None);

        // Assert - Should list objects for each of the 3 dates
        await _s3Client.Received(3).ListObjectsV2Async(
            Arg.Any<ListObjectsV2Request>(),
            Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task MergeReportFilesAsync_WithXlsxFormat_ShouldStillUseCsvForMerge()
    {
        // Arrange - merge sempre trabalha com CSV internamente,
        // a conversão para xlsx acontece na entrega final
        var metadata = CreateTestMetadata(new DateTime(2025, 1, 1), new DateTime(2025, 1, 1));
        metadata = metadata with { FileFormat = "xlsx" };
        var concatId = "concat-123";

        _s3Client.InitiateMultipartUploadAsync(Arg.Any<InitiateMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(new InitiateMultipartUploadResponse { UploadId = "upload-123" });

        _s3Client.GetObjectAsync(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(CreateGetObjectResponse("header1,header2\n"));

        _s3Client.ListObjectsV2Async(Arg.Any<ListObjectsV2Request>(), Arg.Any<CancellationToken>())
            .Returns(new ListObjectsV2Response { S3Objects = [], IsTruncated = false });

        _s3Client.UploadPartAsync(Arg.Any<UploadPartRequest>(), Arg.Any<CancellationToken>())
            .Returns(new UploadPartResponse { ETag = "etag-1" });

        _s3Client.CompleteMultipartUploadAsync(Arg.Any<CompleteMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(new CompleteMultipartUploadResponse());

        // Act
        await _service.MergeReportFilesAsync(concatId, metadata, CancellationToken.None);

        // Assert - mesmo com FileFormat=xlsx, o merge usa csv
        await _s3Client.Received(1).InitiateMultipartUploadAsync(
            Arg.Is<InitiateMultipartUploadRequest>(r => r.Key == "reports/test-report.csv"),
            Arg.Any<CancellationToken>());

        await _s3Client.Received(1).GetObjectAsync(
            "test-bucket",
            "reports/partial/test-report/header.csv",
            Arg.Any<CancellationToken>());
    }
}

public class S3MergeContextTests
{
    [Fact]
    public void Constructor_ShouldInitializeProperties()
    {
        // Arrange & Act
        using var context = new S3MergeContext("upload-123", "destination-key", "bucket-name");

        // Assert
        Assert.Equal("upload-123", context.UploadId);
        Assert.Equal("destination-key", context.DestinationKey);
        Assert.Equal("bucket-name", context.BucketName);
        Assert.Empty(context.UploadedParts);
        Assert.NotNull(context.UploadBuffer);
        Assert.Equal(1, context.PartNumber);
    }

    [Fact]
    public void AddDisposable_ShouldTrackDisposables()
    {
        // Arrange
        using var context = new S3MergeContext("upload-123", "destination-key", "bucket-name");
        var disposable = Substitute.For<IDisposable>();

        // Act
        context.AddDisposable(disposable);

        // Assert - Dispose should be called when context is disposed
        context.Dispose();
        disposable.Received(1).Dispose();
    }

    [Fact]
    public void Dispose_ShouldDisposeBufferAndTrackedDisposables()
    {
        // Arrange
        var context = new S3MergeContext("upload-123", "destination-key", "bucket-name");
        var disposable1 = Substitute.For<IDisposable>();
        var disposable2 = Substitute.For<IDisposable>();
        context.AddDisposable(disposable1);
        context.AddDisposable(disposable2);

        // Act
        context.Dispose();

        // Assert
        disposable1.Received(1).Dispose();
        disposable2.Received(1).Dispose();
    }

    [Fact]
    public void PartNumber_ShouldBeIncrementable()
    {
        // Arrange
        using var context = new S3MergeContext("upload-123", "destination-key", "bucket-name");

        // Act
        context.PartNumber++;
        context.PartNumber++;

        // Assert
        Assert.Equal(3, context.PartNumber);
    }
}

public class DescendingStringComparerTests
{
    private readonly DescendingStringComparer _comparer = new();

    [Fact]
    public void Compare_WithBothNull_ShouldReturnZero()
    {
        // Act
        var result = _comparer.Compare(null, null);

        // Assert
        Assert.Equal(0, result);
    }

    [Fact]
    public void Compare_WithFirstNull_ShouldReturnPositive()
    {
        // Act
        var result = _comparer.Compare(null, "value");

        // Assert
        Assert.True(result > 0);
    }

    [Fact]
    public void Compare_WithSecondNull_ShouldReturnNegative()
    {
        // Act
        var result = _comparer.Compare("value", null);

        // Assert
        Assert.True(result < 0);
    }

    [Fact]
    public void Compare_WithDescendingOrder_ShouldReturnCorrectOrder()
    {
        // Act
        var resultAB = _comparer.Compare("A", "B");
        var resultBA = _comparer.Compare("B", "A");
        var resultAA = _comparer.Compare("A", "A");

        // Assert - Descending order: B should come before A
        Assert.True(resultAB > 0); // A comes after B in descending
        Assert.True(resultBA < 0); // B comes before A in descending
        Assert.Equal(0, resultAA); // Equal values
    }

    [Theory]
    [InlineData("2025-01-03", "2025-01-01", -1)] // 03 comes before 01 in descending
    [InlineData("2025-01-01", "2025-01-03", 1)]  // 01 comes after 03 in descending
    [InlineData("2025-01-02", "2025-01-02", 0)]  // Equal
    public void Compare_WithDates_ShouldSortDescending(string x, string y, int expectedSign)
    {
        // Act
        var result = _comparer.Compare(x, y);

        // Assert
        Assert.Equal(expectedSign, Math.Sign(result));
    }
}

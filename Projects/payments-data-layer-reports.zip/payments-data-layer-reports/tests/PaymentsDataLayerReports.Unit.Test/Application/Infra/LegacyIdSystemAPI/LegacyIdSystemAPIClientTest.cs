using System.Net;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Options;
using NSubstitute;
using PaymentsDataLayerReports.Application.Infra.LegacyIdSystemAPI;
using PaymentsDataLayerReports.Application.Infra.LegacyIdSystemAPI.Models;
using PaymentsDataLayerReports.Application.Settings;

namespace PaymentsDataLayerReports.Unit.Test.Application.Infra.LegacyIdSystemAPI;

public class MockHttpMessageHandler : HttpMessageHandler
{
    private HttpStatusCode _statusCode = HttpStatusCode.OK;
    private string _content = string.Empty;
    private Exception? _exception;

    public Uri? LastRequestUri { get; private set; }

    public void SetResponse(HttpStatusCode statusCode, string content)
    {
        _statusCode = statusCode;
        _content = content;
        _exception = null;
    }

    public void SetException(Exception exception)
    {
        _exception = exception;
    }

    protected override async Task<HttpResponseMessage> SendAsync(
        HttpRequestMessage request,
        CancellationToken cancellationToken)
    {
        LastRequestUri = request.RequestUri;

        if (_exception != null)
        {
            throw _exception;
        }

        var response = new HttpResponseMessage(_statusCode)
        {
            Content = new StringContent(_content, Encoding.UTF8, "application/json")
        };

        return await Task.FromResult(response);
    }
}

public class LegacyIdSystemAPIClientTest
{
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly IOptions<LegacyIdSystemAPISettings> _settings;
    private readonly LegacyIdSystemAPIClient _client;
    private readonly HttpClient _httpClient;
    private readonly MockHttpMessageHandler _mockHandler;

    private readonly JsonSerializerOptions _jsonSerializerOptions;

    public LegacyIdSystemAPIClientTest()
    {
        _httpClientFactory = Substitute.For<IHttpClientFactory>();
        _settings = Substitute.For<IOptions<LegacyIdSystemAPISettings>>();
        _mockHandler = new MockHttpMessageHandler();
        _httpClient = new HttpClient(_mockHandler)
        {
            BaseAddress = new Uri("https://api.test.com")
        };

        _httpClientFactory.CreateClient("legacyIdSystemApiClient").Returns(_httpClient);
        _settings.Value.Returns(new LegacyIdSystemAPISettings());

        _client = new LegacyIdSystemAPIClient(_httpClientFactory, _settings);

        _jsonSerializerOptions = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        };
    }

    [Fact]
    public async Task GetClients_WithValidRequest_ShouldReturnDistinctDocuments()
    {
        var firstDocument = "12345678901";
        var secondDocument = "98765432109";
        // Arrange
        var request = new LegacyIdSystemRequest
        {
            Document = new[] { firstDocument },
            StoneAccount = new[] { "123456" },
            AffiliationKey = new[] { "affiliation123" }
        };

        var response = new List<LegacyIdSystemResponse>
        {
            new() { Document = firstDocument, StoneAccount = "123456" },
            new() { Document = secondDocument, StoneAccount = "123456" },
        };

        var jsonResponse = JsonSerializer.Serialize(response, _jsonSerializerOptions);
        _mockHandler.SetResponse(HttpStatusCode.OK, jsonResponse);

        // Act
        var result = await _client.GetClients(request, CancellationToken.None);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(2, result.Count);
        Assert.Contains(result, r => r.Document == firstDocument);
        Assert.Contains(result, r => r.Document == secondDocument);
    }

    [Fact]
    public async Task GetClients_WithNullDocuments_ShouldReturnResponseWithNullDocument()
    {
        // Arrange
        var request = new LegacyIdSystemRequest
        {
            StoneAccount = new[] { "123456" }
        };

        var response = new List<LegacyIdSystemResponse>
        {
            new() { Document = null }
        };

        var jsonResponse = JsonSerializer.Serialize(response, _jsonSerializerOptions);
        _mockHandler.SetResponse(HttpStatusCode.OK, jsonResponse);

        // Act
        var result = await _client.GetClients(request, CancellationToken.None);

        // Assert
        Assert.NotNull(result);
        Assert.Single(result);
        Assert.Null(result[0].Document);
    }

    [Fact]
    public async Task GetClients_WithEmptyResponse_ShouldReturnEmptyList()
    {
        // Arrange
        var request = new LegacyIdSystemRequest
        {
            StoneAccount = new[] { "123456" }
        };

        var response = new List<LegacyIdSystemResponse>();
        var jsonResponse = JsonSerializer.Serialize(response, _jsonSerializerOptions);
        _mockHandler.SetResponse(HttpStatusCode.OK, jsonResponse);

        // Act
        var result = await _client.GetClients(request, CancellationToken.None);

        // Assert
        Assert.NotNull(result);
        Assert.Empty(result);
    }

    [Fact]
    public async Task GetClients_WhenApiBadRequest_ShouldThrowHttpRequestException()
    {
        // Arrange
        var request = new LegacyIdSystemRequest
        {
            StoneAccount = new[] { "123456" }
        };

        _mockHandler.SetResponse(HttpStatusCode.BadRequest, "Bad Request Error");

        // Act & Assert
        var exception = await Assert.ThrowsAsync<HttpRequestException>(
            async () => await _client.GetClients(request, CancellationToken.None)
        );

        Assert.Contains("Request to Legacy Id System API failed", exception.Message);
        Assert.Equal(HttpStatusCode.BadRequest, exception.StatusCode);
    }

    [Fact]
    public async Task GetClients_WhenApiInternalServerError_ShouldThrowHttpRequestException()
    {
        // Arrange
        var request = new LegacyIdSystemRequest
        {
            StoneAccount = new[] { "123456" }
        };

        _mockHandler.SetResponse(HttpStatusCode.InternalServerError, "Internal Server Error");

        // Act & Assert
        var exception = await Assert.ThrowsAsync<HttpRequestException>(
            async () => await _client.GetClients(request, CancellationToken.None)
        );

        Assert.Contains("Request to Legacy Id System API failed", exception.Message);
        Assert.Equal(HttpStatusCode.InternalServerError, exception.StatusCode);
    }

    [Fact]
    public async Task GetClients_WhenExceptionOccurs_ShouldThrowException()
    {
        // Arrange
        var request = new LegacyIdSystemRequest
        {
            StoneAccount = new[] { "123456" }
        };

        _mockHandler.SetException(new Exception("Network error"));

        // Act & Assert
        var exception = await Assert.ThrowsAsync<Exception>(
            async () => await _client.GetClients(request, CancellationToken.None)
        );

        Assert.Equal("Network error", exception.Message);
    }

    [Fact]
    public async Task GetClients_ShouldBuildCorrectQueryString()
    {
        // Arrange
        var document = "12345678901";
        var stoneAccount = "123456";
        var affiliationKey = "affiliation123";

        var request = new LegacyIdSystemRequest
        {
            Document = new[] { document },
            StoneAccount = new[] { stoneAccount },
            AffiliationKey = new[] { affiliationKey }
        };

        var response = new List<LegacyIdSystemResponse>
        {
            new() { Document = document }
        };

        var jsonResponse = JsonSerializer.Serialize(response, _jsonSerializerOptions);
        _mockHandler.SetResponse(HttpStatusCode.OK, jsonResponse);

        // Act
        await _client.GetClients(request, CancellationToken.None);

        // Assert
        var requestUri = _mockHandler.LastRequestUri?.ToString();
        Assert.NotNull(requestUri);
        Assert.Contains("clients?", requestUri);
    }

    [Fact]
    public async Task GetClients_WithCompleteResponse_ShouldReturnAllIdentifiers()
    {
        // Arrange
        var request = new LegacyIdSystemRequest
        {
            Document = new[] { "12345678901" }
        };

        var response = new List<LegacyIdSystemResponse>
        {
            new()
            {
                Document = "12345678901",
                StoneAccount = "123456",
                PaymentProfile = "STONE",
                PoiType = "POS",
                AffiliationKey = "AFF123",
                MerchantId = "MERCH001",
                AccountId = "ACC789",
                Organization = "ORG456"
            }
        };

        var jsonResponse = JsonSerializer.Serialize(response, _jsonSerializerOptions);
        _mockHandler.SetResponse(HttpStatusCode.OK, jsonResponse);

        // Act
        var result = await _client.GetClients(request, CancellationToken.None);

        // Assert
        Assert.NotNull(result);
        Assert.Single(result);
        var client = result[0];
        Assert.Equal("12345678901", client.Document);
        Assert.Equal("123456", client.StoneAccount);
        Assert.Equal("STONE", client.PaymentProfile);
        Assert.Equal("POS", client.PoiType);
        Assert.Equal("AFF123", client.AffiliationKey);
        Assert.Equal("MERCH001", client.MerchantId);
        Assert.Equal("ACC789", client.AccountId);
        Assert.Equal("ORG456", client.Organization);
    }

    [Fact]
    public async Task GetClients_WithMultipleStoneAccounts_ShouldReturnAllAccounts()
    {
        // Arrange
        var request = new LegacyIdSystemRequest
        {
            Document = new[] { "12345678901" }
        };

        var response = new List<LegacyIdSystemResponse>
        {
            new()
            {
                Document = "12345678901",
                StoneAccount = "123456",
                MerchantId = "MERCH001"
            },
            new()
            {
                Document = "12345678901",
                StoneAccount = "789012",
                MerchantId = "MERCH002"
            },
            new()
            {
                Document = "12345678901",
                StoneAccount = "345678",
                MerchantId = "MERCH003"
            }
        };

        var jsonResponse = JsonSerializer.Serialize(response, _jsonSerializerOptions);
        _mockHandler.SetResponse(HttpStatusCode.OK, jsonResponse);

        // Act
        var result = await _client.GetClients(request, CancellationToken.None);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(3, result.Count);
        Assert.Contains(result, r => r.StoneAccount == "123456");
        Assert.Contains(result, r => r.StoneAccount == "789012");
        Assert.Contains(result, r => r.StoneAccount == "345678");
    }

    [Fact]
    public async Task GetClients_WithMultipleMerchantIds_ShouldReturnDistinctMerchants()
    {
        // Arrange
        var request = new LegacyIdSystemRequest
        {
            AffiliationKey = new[] { "AFF123" }
        };

        var response = new List<LegacyIdSystemResponse>
        {
            new()
            {
                Document = "12345678901",
                MerchantId = "MERCH001",
                AffiliationKey = "AFF123"
            },
            new()
            {
                Document = "98765432109",
                MerchantId = "MERCH002",
                AffiliationKey = "AFF123"
            }
        };

        var jsonResponse = JsonSerializer.Serialize(response, _jsonSerializerOptions);
        _mockHandler.SetResponse(HttpStatusCode.OK, jsonResponse);

        // Act
        var result = await _client.GetClients(request, CancellationToken.None);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(2, result.Count);
        Assert.Contains(result, r => r.MerchantId == "MERCH001");
        Assert.Contains(result, r => r.MerchantId == "MERCH002");
        Assert.All(result, r => Assert.Equal("AFF123", r.AffiliationKey));
    }

    [Fact]
    public async Task GetClients_WithDifferentPaymentProfiles_ShouldReturnAllProfiles()
    {
        // Arrange
        var request = new LegacyIdSystemRequest
        {
            Document = new[] { "12345678901" }
        };

        var response = new List<LegacyIdSystemResponse>
        {
            new()
            {
                Document = "12345678901",
                StoneAccount = "123456",
                PaymentProfile = "STONE"
            },
            new()
            {
                Document = "12345678901",
                StoneAccount = "789012",
                PaymentProfile = "TON"
            }
        };

        var jsonResponse = JsonSerializer.Serialize(response, _jsonSerializerOptions);
        _mockHandler.SetResponse(HttpStatusCode.OK, jsonResponse);

        // Act
        var result = await _client.GetClients(request, CancellationToken.None);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(2, result.Count);
        Assert.Contains(result, r => r.PaymentProfile == "STONE");
        Assert.Contains(result, r => r.PaymentProfile == "TON");
    }

    [Fact]
    public async Task GetClients_WithDifferentPoiTypes_ShouldReturnAllTypes()
    {
        // Arrange
        var request = new LegacyIdSystemRequest
        {
            StoneAccount = new[] { "123456" }
        };

        var response = new List<LegacyIdSystemResponse>
        {
            new()
            {
                StoneAccount = "123456",
                PoiType = "POS",
                AccountId = "ACC001"
            },
            new()
            {
                StoneAccount = "123456",
                PoiType = "ECOMMERCE",
                AccountId = "ACC002"
            },
            new()
            {
                StoneAccount = "123456",
                PoiType = "MOBILE",
                AccountId = "ACC003"
            }
        };

        var jsonResponse = JsonSerializer.Serialize(response, _jsonSerializerOptions);
        _mockHandler.SetResponse(HttpStatusCode.OK, jsonResponse);

        // Act
        var result = await _client.GetClients(request, CancellationToken.None);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(3, result.Count);
        Assert.Contains(result, r => r.PoiType == "POS");
        Assert.Contains(result, r => r.PoiType == "ECOMMERCE");
        Assert.Contains(result, r => r.PoiType == "MOBILE");
    }

    [Fact]
    public async Task GetClients_WithOrganizationFilter_ShouldReturnClientsFromOrganization()
    {
        // Arrange
        var request = new LegacyIdSystemRequest
        {
            Document = new[] { "12345678901", "98765432109" }
        };

        var response = new List<LegacyIdSystemResponse>
        {
            new()
            {
                Document = "12345678901",
                Organization = "STONE",
                AccountId = "ACC001"
            },
            new()
            {
                Document = "98765432109",
                Organization = "STONE",
                AccountId = "ACC002"
            }
        };

        var jsonResponse = JsonSerializer.Serialize(response, _jsonSerializerOptions);
        _mockHandler.SetResponse(HttpStatusCode.OK, jsonResponse);

        // Act
        var result = await _client.GetClients(request, CancellationToken.None);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(2, result.Count);
        Assert.All(result, r => Assert.Equal("STONE", r.Organization));
    }

    [Fact]
    public async Task GetClients_WithPartialData_ShouldReturnAvailableFields()
    {
        // Arrange
        var request = new LegacyIdSystemRequest
        {
            StoneAccount = new[] { "123456" }
        };

        var response = new List<LegacyIdSystemResponse>
        {
            new()
            {
                Document = "12345678901",
                StoneAccount = "123456",
                MerchantId = null,
                AccountId = null,
                Organization = "STONE"
            }
        };

        var jsonResponse = JsonSerializer.Serialize(response, _jsonSerializerOptions);
        _mockHandler.SetResponse(HttpStatusCode.OK, jsonResponse);

        // Act
        var result = await _client.GetClients(request, CancellationToken.None);

        // Assert
        Assert.NotNull(result);
        Assert.Single(result);
        var client = result[0];
        Assert.Equal("12345678901", client.Document);
        Assert.Equal("123456", client.StoneAccount);
        Assert.Null(client.MerchantId);
        Assert.Null(client.AccountId);
        Assert.Equal("STONE", client.Organization);
    }
}

using PaymentsDataLayerReports.Application.Constants;
using PaymentsDataLayerReports.Application.Enums;

namespace PaymentsDataLayerReports.Unit.Test.Application.Constants;

public class CsvSeparatorConstantsTests
{
    [Fact]
    public void GetSeparator_WithComma_ShouldReturnCommaChar()
    {
        // Act
        var result = CsvSeparatorConstants.GetSeparator(CsvSeparatorEnum.Comma);

        // Assert
        Assert.Equal(',', result);
    }

    [Fact]
    public void GetSeparator_WithSemicolon_ShouldReturnSemicolonChar()
    {
        // Act
        var result = CsvSeparatorConstants.GetSeparator(CsvSeparatorEnum.Semicolon);

        // Assert
        Assert.Equal(';', result);
    }

    [Theory]
    [InlineData(CsvSeparatorEnum.Comma, ',')]
    [InlineData(CsvSeparatorEnum.Semicolon, ';')]
    public void GetSeparator_ShouldReturnExpectedCharForEachEnum(CsvSeparatorEnum separator, char expected)
    {
        // Act
        var result = CsvSeparatorConstants.GetSeparator(separator);

        // Assert
        Assert.Equal(expected, result);
    }

    [Fact]
    public void Constants_ShouldHaveCorrectValues()
    {
        // Assert
        Assert.Equal(',', CsvSeparatorConstants.Comma);
        Assert.Equal(';', CsvSeparatorConstants.Semicolon);
    }
}

using PaymentsDataLayerReports.Application.Extensions;

namespace PaymentsDataLayerReports.Unit.Test.Application.Extensions;

public class EnumerableExtensionsTests
{
    [Theory]
    [InlineData(null, "")]
    [InlineData(new string[] { }, "")]
    [InlineData(new string[] { "value1" }, "value1")]
    [InlineData(new string[] { "value1", "value2" }, "value1,value2")]
    [InlineData(new string[] { "value1", " ", "value3" }, "value1, ,value3")]
    [InlineData(new string[] { "value1", "", "value3" }, "value1,,value3")]
    [InlineData(new string?[] { "value1", null, "value3" }, "value1,,value3")]
    public void ToCommaSeparatedString_ShouldReturnCorrectFormat_ForVariousListSizes(IEnumerable<string> input, string expected)
    {
        // Act
        var result = input.ToCommaSeparatedString();

        // Assert
        Assert.Equal(expected, result);
    }
}

using System.Reflection;
using Hangfire;
using Hangfire.Redis.StackExchange;
using Hangfire.Storage;
using Hangfire.Storage.Monitoring;
using NSubstitute;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Extensions;

namespace PaymentsDataLayerReports.Unit.Test.Application.Extensions;

public class HangfireServiceExtensionsTests
{
    [Theory]
    [InlineData(null, "hangfire:DataLayerReports:")]
    [InlineData(false, "hangfire:DataLayerReports:")]
    [InlineData(true, "hangfire:DataLayerReportsPreDeploy:")]
    public void GetRedisOptions_ShouldRespectPrefixByWorkerFlag(bool? isPreDeployWorker, string expectedPrefix)
    {
        // Act
        var options = InvokeGetRedisOptions(isPreDeployWorker);

        // Assert
        Assert.Equal(expectedPrefix, options.Prefix);
    }

    [Fact]
    public void GetStateById_ShouldReturnNull_WhenJobNotFound()
    {
        // Arrange
        var monitoringApi = Substitute.For<IMonitoringApi>();
        monitoringApi.JobDetails("job").Returns((JobDetailsDto?)null);
        var jobStorage = new TestJobStorage(monitoringApi);

        // Act
        var result = HangfireServiceExtensions.GetStateById(jobStorage, "job");

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public void GetStateById_ShouldReturnProcessing_WhenRetryingJob()
    {
        // Arrange
        var jobDetails = CreateJobDetails(WorkerStatesEnum.Enqueued.ToString(), includeRetryProperty: true);
        var monitoringApi = Substitute.For<IMonitoringApi>();
        monitoringApi.JobDetails("job").Returns(jobDetails);
        var jobStorage = new TestJobStorage(monitoringApi);

        // Act
        var result = HangfireServiceExtensions.GetStateById(jobStorage, "job");

        // Assert
        Assert.Equal(WorkerStatesEnum.Processing.ToString(), result);
    }

    [Fact]
    public void GetStateById_ShouldReturnFailed_WhenRetryDeleted()
    {
        // Arrange
        var jobDetails = CreateJobDetails(WorkerStatesEnum.Deleted.ToString(), includeRetryProperty: true);
        var monitoringApi = Substitute.For<IMonitoringApi>();
        monitoringApi.JobDetails("job").Returns(jobDetails);
        var jobStorage = new TestJobStorage(monitoringApi);

        // Act
        var result = HangfireServiceExtensions.GetStateById(jobStorage, "job");

        // Assert
        Assert.Equal(WorkerStatesEnum.Failed.ToString(), result);
    }

    private static RedisStorageOptions InvokeGetRedisOptions(bool? isPreDeployWorker)
    {
        var method = typeof(HangfireServiceExtensions)
            .GetMethod("GetRedisOptions", BindingFlags.Static | BindingFlags.NonPublic)
            ?? throw new InvalidOperationException("Method GetRedisOptions not found");

        return (RedisStorageOptions)method.Invoke(null, [isPreDeployWorker])!;
    }

    private static JobDetailsDto CreateJobDetails(string stateName, bool includeRetryProperty)
    {
        return new JobDetailsDto
        {
            Properties = includeRetryProperty
                ? new Dictionary<string, string> { { "RetryCount", "1" } }
                : [],
            History =
            [
                new()
                {
                    StateName = stateName,
                    Data = new Dictionary<string, string>()
                }
            ]
        };
    }

    private class TestJobStorage(IMonitoringApi monitoringApi) : JobStorage
    {
        private readonly IMonitoringApi _monitoringApi = monitoringApi;

        public override IStorageConnection GetConnection() => throw new NotSupportedException();
        public override IMonitoringApi GetMonitoringApi() => _monitoringApi;
    }
}

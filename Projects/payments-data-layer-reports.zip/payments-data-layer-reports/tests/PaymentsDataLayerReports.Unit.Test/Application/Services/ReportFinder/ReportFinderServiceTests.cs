using NSubstitute;
using NSubstitute.ExceptionExtensions;
using PaymentsDataLayerReports.Application.Exceptions;
using PaymentsDataLayerReports.Application.Infra.Hangfire;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Services.ReportFinder;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;

namespace PaymentsDataLayerReports.Unit.Test.Application.Services.ReportFinder;

public class ReportFinderServiceTests
{
    private readonly IS3ClientWrapper _s3ClientWrapper;
    private readonly IJobStorageProvider _jobStorageProvider;
    private readonly ReportFinderService _service;
    private const string ValidReportId = "550e8400-e29b-41d4-a716-446655440000";

    public ReportFinderServiceTests()
    {
        _s3ClientWrapper = Substitute.For<IS3ClientWrapper>();
        _jobStorageProvider = Substitute.For<IJobStorageProvider>();
        _jobStorageProvider.GetStateById(Arg.Any<string>()).Returns((string?)null);
        _service = new ReportFinderService(_s3ClientWrapper, _jobStorageProvider);
    }

    #region FindReport Tests

    [Fact]
    public async Task FindReport_WhenFileExistsAndSucceeded_ShouldReturnSuccessStatusAndUrl()
    {
        // Arrange
        var reportId = ValidReportId;
        var fileFormat = "csv";

        _s3ClientWrapper.GetReportFileWithFormatAsync(reportId)
            .Returns((true, fileFormat));
        _s3ClientWrapper.BuildReportUrl(reportId, Arg.Any<double>(), null, fileFormat)
            .Returns("https://presigned-url.example.com");

        // Act
        var (status, url) = await _service.FindReport(reportId);

        // Assert
        Assert.Equal("Succeeded", status);
        Assert.NotNull(url);
    }

    [Fact]
    public async Task FindReport_WhenFileNotExistsAndMetadataExists_ShouldReturnMetadataStatus()
    {
        // Arrange
        var reportId = ValidReportId;
        var metadataStatus = "Completed";
        var metadataFormat = "xlsx";

        _s3ClientWrapper.GetReportFileWithFormatAsync(reportId)
            .Returns((false, (string?)null));

        var metadata = new ReportMetadata
        {
            ReportId = reportId,
            Status = metadataStatus,
            FileFormat = metadataFormat,
            DispatchId = "dispatch-1",
            CreatedAt = DateTime.UtcNow,
            ReportSortColumnIndex = 0,
            ProcessorQueueName = "queue"
        };
        _s3ClientWrapper.GetReportMetadataAsync(reportId).Returns(metadata);

        // Act
        var (status, url) = await _service.FindReport(reportId);

        // Assert
        Assert.Equal(metadataStatus, status);
        Assert.Null(url);
    }

    [Fact]
    public async Task FindReport_WhenFileNotExistsAndMetadataNotFound_ShouldReturnNullStatus()
    {
        // Arrange
        var reportId = ValidReportId;

        _s3ClientWrapper.GetReportFileWithFormatAsync(reportId)
            .Returns((false, (string?)null));

        _s3ClientWrapper.GetReportMetadataAsync(reportId).Returns((ReportMetadata?)null);

        // Act
        var (status, url) = await _service.FindReport(reportId);

        // Assert
        Assert.Null(status);
        Assert.Null(url);
    }

    [Fact]
    public async Task FindReport_WhenMetadataThrowsS3FileNotFoundException_ShouldReturnNullStatus()
    {
        // Arrange
        var reportId = ValidReportId;

        _s3ClientWrapper.GetReportFileWithFormatAsync(reportId)
            .Returns((false, (string?)null));

        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .ThrowsAsync(new S3FileNotFoundException("Metadata not found"));

        // Act
        var (status, url) = await _service.FindReport(reportId);

        // Assert
        Assert.Null(status);
        Assert.Null(url);
    }

    [Fact]
    public async Task FindReport_WhenMetadataHasNullFileFormat_ShouldDefaultToCsv()
    {
        // Arrange
        var reportId = ValidReportId;
        var metadataStatus = "Pending";

        _s3ClientWrapper.GetReportFileWithFormatAsync(reportId)
            .Returns((false, (string?)null));

        var metadata = new ReportMetadata
        {
            ReportId = reportId,
            Status = metadataStatus,
            FileFormat = "csv",
            DispatchId = "dispatch-1",
            CreatedAt = DateTime.UtcNow,
            ReportSortColumnIndex = 0,
            ProcessorQueueName = "queue"
        };
        _s3ClientWrapper.GetReportMetadataAsync(reportId).Returns(metadata);

        // Act
        var (status, url) = await _service.FindReport(reportId);

        // Assert
        Assert.Equal(metadataStatus, status);
        Assert.Null(url);
    }

    [Fact]
    public async Task FindReport_WhenStatusIsSucceeded_ShouldBuildUrlWithCorrectParameters()
    {
        // Arrange
        var reportId = ValidReportId;
        var fileFormat = "csv";
        var expectedUrl = "https://presigned-url.example.com";

        _s3ClientWrapper.GetReportFileWithFormatAsync(reportId)
            .Returns((true, fileFormat));
        _s3ClientWrapper.BuildReportUrl(reportId, Arg.Any<double>(), null, fileFormat)
            .Returns(expectedUrl);

        // Act
        var (status, url) = await _service.FindReport(reportId);

        // Assert
        Assert.Equal(expectedUrl, url);
        _s3ClientWrapper.Received(1).BuildReportUrl(
            reportId,
            S3ReportsConstants.UrlDefaultExpirationHours,
            null,
            fileFormat);
    }

    [Fact]
    public async Task FindReport_WhenStatusIsNotSucceeded_ShouldNotBuildUrl()
    {
        // Arrange
        var reportId = ValidReportId;

        _s3ClientWrapper.GetReportFileWithFormatAsync(reportId)
            .Returns((false, (string?)null));

        var metadata = new ReportMetadata
        {
            ReportId = reportId,
            Status = "Processing",
            FileFormat = "csv",
            DispatchId = "dispatch-1",
            CreatedAt = DateTime.UtcNow,
            ReportSortColumnIndex = 0,
            ProcessorQueueName = "queue"
        };
        _s3ClientWrapper.GetReportMetadataAsync(reportId).Returns(metadata);

        // Act
        var (status, url) = await _service.FindReport(reportId);

        // Assert
        Assert.Null(url);
        _s3ClientWrapper.DidNotReceive().BuildReportUrl(Arg.Any<string>(), Arg.Any<double>(), Arg.Any<string>(), Arg.Any<string>());
    }

    #endregion

    #region GetReportFileWithFormatAsync Integration Tests

    [Fact]
    public async Task FindReport_ShouldCallGetReportFileWithFormatAsync()
    {
        // Arrange
        var reportId = ValidReportId;

        _s3ClientWrapper.GetReportFileWithFormatAsync(reportId)
            .Returns((false, (string?)null));
        _s3ClientWrapper.GetReportMetadataAsync(reportId)
            .Returns((ReportMetadata?)null);

        // Act
        await _service.FindReport(reportId);

        // Assert
        await _s3ClientWrapper.Received(1).GetReportFileWithFormatAsync(reportId);
    }

    [Fact]
    public async Task FindReport_WhenFileExistsWithXlsxFormat_ShouldReturnXlsxFormat()
    {
        // Arrange
        var reportId = ValidReportId;
        var fileFormat = "xlsx";

        _s3ClientWrapper.GetReportFileWithFormatAsync(reportId)
            .Returns((true, fileFormat));
        _s3ClientWrapper.BuildReportUrl(reportId, Arg.Any<double>(), null, fileFormat)
            .Returns("https://presigned-url.example.com");

        // Act
        var (status, url) = await _service.FindReport(reportId);

        // Assert
        Assert.Equal("Succeeded", status);
        _s3ClientWrapper.Received(1).BuildReportUrl(
            reportId,
            Arg.Any<double>(),
            null,
            "xlsx");
    }

    #endregion
}

using Hangfire;
using Hangfire.Common;
using Hangfire.States;
using NSubstitute;
using PaymentsDataLayerReports.Application.Routes.Reports.PostReports;
using PaymentsDataLayerReports.Application.Routes.Reports.PostReports.Models;
using PaymentsDataLayerReports.Application.Services.IdMapper;
using PaymentsDataLayerReports.Application.Services.ReportEnqueue;
using PaymentsDataLayerReports.Application.Workers.ChargeReportWorker;

namespace PaymentsDataLayerReports.Unit.Test.Application.Services.ReportEnqueue;

public class ESChargeReportEnqueueServiceTests
{
    private readonly IBackgroundJobClient _backgroundJobClient;
    private readonly IMerchantIdSummaryAggregator _aggregator;
    private readonly ESChargeReportEnqueueService _service;

    public ESChargeReportEnqueueServiceTests()
    {
        _backgroundJobClient = Substitute.For<IBackgroundJobClient>();
        _backgroundJobClient.Create(Arg.Any<Job>(), Arg.Any<IState>()).Returns("job-123");
        _aggregator = Substitute.For<IMerchantIdSummaryAggregator>();
        _service = new ESChargeReportEnqueueService(_backgroundJobClient, _aggregator);
    }

    private static PostReportsRequest CreateValidRequest() => new()
    {
        Type = "charges_list",
        FileFormat = "csv",
        Filters = new ReportFilters
        {
            StartDate = new DateOnly(2025, 1, 1),
            FinalDate = new DateOnly(2025, 1, 31),
            Organizations = ["stone"],
            Identifiers = new Identifiers { Documents = ["12345678901"] }
        }
    };

    private static List<MerchantIdSummary> CreateValidIdsMapped() =>
    [
        new MerchantIdSummary
        {
            Document = "12345678901",
            Organization = "stone"
        }
    ];

    private ChargeReportsWorkerParameters? CaptureParameters()
    {
        ChargeReportsWorkerParameters? captured = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo =>
            {
                var job = callInfo.ArgAt<Job>(0);
                captured = job.Args[0] as ChargeReportsWorkerParameters;
            });
        return captured;
    }

    [Fact]
    public void EnqueueReport_ShouldCallAggregatorProcessWithIdsMapped()
    {
        // Arrange
        var request = CreateValidRequest();
        var idsMapped = CreateValidIdsMapped();

        // Act
        _service.EnqueueReport(request, idsMapped);

        // Assert
        _aggregator.Received(1).Process(idsMapped);
    }

    [Fact]
    public void EnqueueReport_ShouldReturnJobId()
    {
        // Arrange
        var request = CreateValidRequest();

        // Act
        var result = _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.Equal("job-123", result);
    }

    [Fact]
    public void EnqueueReport_ShouldCallBackgroundJobClient()
    {
        // Arrange
        var request = CreateValidRequest();

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        _backgroundJobClient.Received(1).Create(Arg.Any<Job>(), Arg.Any<IState>());
    }

    [Fact]
    public void EnqueueReport_ShouldSetPaymentMethodsToBoletoCardPix()
    {
        // Arrange
        var request = CreateValidRequest();
        ChargeReportsWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo => capturedParameters = callInfo.ArgAt<Job>(0).Args[0] as ChargeReportsWorkerParameters);

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("boleto,card,pix", capturedParameters.PaymentMethods);
    }

    [Fact]
    public void EnqueueReport_ShouldMapDocumentFromAggregator()
    {
        // Arrange
        var request = CreateValidRequest();
        _aggregator.GetField("document").Returns("11111111111,22222222222");
        ChargeReportsWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo => capturedParameters = callInfo.ArgAt<Job>(0).Args[0] as ChargeReportsWorkerParameters);

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("11111111111,22222222222", capturedParameters.Document);
    }

    [Fact]
    public void EnqueueReport_ShouldMapMerchantIdFromAggregator()
    {
        // Arrange
        var request = CreateValidRequest();
        _aggregator.GetField("merchantId").Returns("merchant-1,merchant-2");
        ChargeReportsWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo => capturedParameters = callInfo.ArgAt<Job>(0).Args[0] as ChargeReportsWorkerParameters);

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("merchant-1,merchant-2", capturedParameters.MerchantId);
    }

    [Fact]
    public void EnqueueReport_ShouldMapOrganizationsFromAggregator()
    {
        // Arrange
        var request = CreateValidRequest();
        _aggregator.GetField("organizations").Returns("stone,ton");
        ChargeReportsWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo => capturedParameters = callInfo.ArgAt<Job>(0).Args[0] as ChargeReportsWorkerParameters);

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("stone,ton", capturedParameters.Organizations);
    }

    [Fact]
    public void EnqueueReport_ShouldMapAccountIdFromAggregator()
    {
        // Arrange
        var request = CreateValidRequest();
        _aggregator.GetField("accountIds").Returns("acc-1,acc-2");
        ChargeReportsWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo => capturedParameters = callInfo.ArgAt<Job>(0).Args[0] as ChargeReportsWorkerParameters);

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("acc-1,acc-2", capturedParameters.AccountId);
    }

    [Fact]
    public void EnqueueReport_ShouldMapAffiliationCodesFromAggregator()
    {
        // Arrange
        var request = CreateValidRequest();
        _aggregator.GetField("affiliationCodes").Returns("aff-1,aff-2");
        ChargeReportsWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo => capturedParameters = callInfo.ArgAt<Job>(0).Args[0] as ChargeReportsWorkerParameters);

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("aff-1,aff-2", capturedParameters.AffiliationCodes);
    }

    [Fact]
    public void EnqueueReport_ShouldMapStoneAccountsFromAggregator()
    {
        // Arrange
        var request = CreateValidRequest();
        _aggregator.GetField("stoneAccounts").Returns("sa-1,sa-2");
        ChargeReportsWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo => capturedParameters = callInfo.ArgAt<Job>(0).Args[0] as ChargeReportsWorkerParameters);

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("sa-1,sa-2", capturedParameters.StoneAccounts);
    }

    [Fact]
    public void EnqueueReport_ShouldMapPaymentProfilesFromAggregator()
    {
        // Arrange
        var request = CreateValidRequest();
        _aggregator.GetField("paymentProfiles").Returns("pp-1,pp-2");
        ChargeReportsWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo => capturedParameters = callInfo.ArgAt<Job>(0).Args[0] as ChargeReportsWorkerParameters);

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("pp-1,pp-2", capturedParameters.PaymentProfiles);
    }

    [Fact]
    public void EnqueueReport_ShouldMapPoiTypesFromAggregator()
    {
        // Arrange
        var request = CreateValidRequest();
        _aggregator.GetField("poiTypes").Returns("pos,ecommerce");
        ChargeReportsWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo => capturedParameters = callInfo.ArgAt<Job>(0).Args[0] as ChargeReportsWorkerParameters);

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("pos,ecommerce", capturedParameters.PoiTypes);
    }

    [Fact]
    public void EnqueueReport_ShouldMapAllNewFieldsTogether()
    {
        // Arrange
        var request = CreateValidRequest();
        _aggregator.GetField("stoneAccounts").Returns("sa-1,sa-2");
        _aggregator.GetField("paymentProfiles").Returns("pp-1,pp-2");
        _aggregator.GetField("poiTypes").Returns("pos,ecommerce");
        ChargeReportsWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo => capturedParameters = callInfo.ArgAt<Job>(0).Args[0] as ChargeReportsWorkerParameters);

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("sa-1,sa-2", capturedParameters.StoneAccounts);
        Assert.Equal("pp-1,pp-2", capturedParameters.PaymentProfiles);
        Assert.Equal("pos,ecommerce", capturedParameters.PoiTypes);
    }

    [Fact]
    public void EnqueueReport_WhenAggregatorReturnsNullForNewFields_ShouldSetNewFieldsToNull()
    {
        // Arrange
        var request = CreateValidRequest();
        _aggregator.GetField("stoneAccounts").Returns((string?)null);
        _aggregator.GetField("paymentProfiles").Returns((string?)null);
        _aggregator.GetField("poiTypes").Returns((string?)null);
        ChargeReportsWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo => capturedParameters = callInfo.ArgAt<Job>(0).Args[0] as ChargeReportsWorkerParameters);

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Null(capturedParameters.StoneAccounts);
        Assert.Null(capturedParameters.PaymentProfiles);
        Assert.Null(capturedParameters.PoiTypes);
    }

    [Fact]
    public void EnqueueReport_ShouldSetDateRangeFromRequest()
    {
        // Arrange
        var request = CreateValidRequest();
        request.Filters.StartDate = new DateOnly(2024, 6, 1);
        request.Filters.FinalDate = new DateOnly(2024, 6, 30);
        ChargeReportsWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo => capturedParameters = callInfo.ArgAt<Job>(0).Args[0] as ChargeReportsWorkerParameters);

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal(new DateOnly(2024, 6, 1), DateOnly.FromDateTime(capturedParameters.StartDate.Date));
        Assert.Equal(new DateOnly(2024, 6, 30), DateOnly.FromDateTime(capturedParameters.EndDate.Date));
    }

    [Fact]
    public void EnqueueReport_ShouldSetReportTypeFromRequest()
    {
        // Arrange
        var request = CreateValidRequest();
        request.Type = "charges_list";
        ChargeReportsWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo => capturedParameters = callInfo.ArgAt<Job>(0).Args[0] as ChargeReportsWorkerParameters);

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("charges_list", capturedParameters.ReportType);
    }

    [Fact]
    public void EnqueueReport_ShouldSetFileFormatFromRequest()
    {
        // Arrange
        var request = CreateValidRequest();
        request.FileFormat = "xlsx";
        ChargeReportsWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo => capturedParameters = callInfo.ArgAt<Job>(0).Args[0] as ChargeReportsWorkerParameters);

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("xlsx", capturedParameters.FileFormat);
    }

    [Fact]
    public void EnqueueReport_WithCorrelationId_ShouldPassCorrelationIdToWorker()
    {
        // Arrange
        var request = CreateValidRequest();
        ChargeReportsWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo => capturedParameters = callInfo.ArgAt<Job>(0).Args[0] as ChargeReportsWorkerParameters);

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped(), "test-correlation-123");

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("test-correlation-123", capturedParameters.ReportId);
    }

    [Fact]
    public void EnqueueReport_WithNullCorrelationId_ShouldPassNullToWorker()
    {
        // Arrange
        var request = CreateValidRequest();
        ChargeReportsWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo => capturedParameters = callInfo.ArgAt<Job>(0).Args[0] as ChargeReportsWorkerParameters);

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Null(capturedParameters.ReportId);
    }
}

using System.Reflection;
using NSubstitute;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Routes.Reports.PostReports;
using PaymentsDataLayerReports.Application.Routes.Reports.PostReports.Models;
using PaymentsDataLayerReports.Application.Services.IdMapper;
using PaymentsDataLayerReports.Application.Services.ReportEnqueue;
using PaymentsDataLayerReports.Application.Services.ReportEnqueue.Helpers;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;
using PaymentsDataLayerReports.Application.Workers.ChargeReportWorker;
using ConfigProvider = PaymentsDataLayerReports.Application.Services.ReportTypeConfiguration.ReportTypeConfigurationProvider;

namespace PaymentsDataLayerReports.Unit.Test.Application.Services.ReportEnqueue;

public class S3ReportEnqueueServiceTests
{
    private readonly IMerchantIdSummaryAggregator _aggregator;

    public S3ReportEnqueueServiceTests()
    {
        _aggregator = Substitute.For<IMerchantIdSummaryAggregator>();
    }

    private static PostReportsRequest CreateBasicRequest()
    {
        return new PostReportsRequest
        {
            Type = ReportTypeEnum.ChargesList.Name,
            FileFormat = FileFormatEnum.Csv.Name,
            Filters = new ReportFilters
            {
                StartDate = DateOnly.FromDateTime(DateTime.UtcNow.Date.AddDays(-1)),
                FinalDate = DateOnly.FromDateTime(DateTime.UtcNow.Date),
                Organizations = ["stone"],
                Identifiers = new Identifiers
                {
                    Documents = ["123", "456"],
                    MerchantIds = null
                }
            }
        };
    }

    private static List<MerchantIdSummary> CreateBasicIdsMapped() => [
        new() { Document = "123", Organization = "stone" },
        new() { Document = "456", Organization = "stone" }
    ];

    private static ReportMetadata InvokeCreateReportMetadata(
        IMerchantIdSummaryAggregator aggregator,
        PostReportsRequest request,
        string? parentJobId,
        List<MerchantIdSummary>? idsMapped = null,
        string? correlationId = null)
    {
        var method = typeof(S3ReportEnqueueService)
            .GetMethod("CreateReportMetadata", BindingFlags.NonPublic | BindingFlags.Static)!;

        var result = method.Invoke(null, new object?[] { request, parentJobId, correlationId, aggregator, idsMapped });
        return Assert.IsType<ReportMetadata>(result);
    }

    [Fact]
    public void CreateReportMetadata_WithNullParentJobId_ShouldSetEmptyReportIdAndCorrectFields()
    {
        var request = CreateBasicRequest();

        List<MerchantIdSummary>? idsMapped = [
            new() { Document = "123", Organization = "stone" },
            new() { Document = "456", Organization = "stone" }
        ];

        _aggregator.GetField("document").Returns("123,456");
        _aggregator.GetField("merchantId").Returns((string?)null);
        _aggregator.GetField("organizations").Returns("stone");

        var metadata = InvokeCreateReportMetadata(_aggregator, request, null, idsMapped);

        Assert.Equal(string.Empty, metadata.ReportId);
        Assert.Equal(string.Empty, metadata.DispatchId);
        Assert.Equal(WorkerStatesEnum.Processing.ToString(), metadata.Status);
        Assert.Equal(QueuesEnum.S3Reports.Name, metadata.ProcessorQueueName);
        Assert.Equal(request.FileFormat, metadata.FileFormat);

        Assert.NotNull(metadata.ChargeReportParameters);
        Assert.Equal(request.Type, metadata.ChargeReportParameters!.ReportType);

        var expectedStart = DateTimeConverter.ToDateTimeOffset(request.Filters.StartDate, endOfDay: false).ToUniversalTime();
        var expectedEnd = DateTimeConverter.ToDateTimeOffset(request.Filters.FinalDate, endOfDay: true).ToUniversalTime();

        Assert.Equal(expectedStart, metadata.ChargeReportParameters.StartDate);
        Assert.Equal(expectedEnd, metadata.ChargeReportParameters.EndDate);

        Assert.Equal("123,456", metadata.ChargeReportParameters.Document);
        Assert.Null(metadata.ChargeReportParameters.MerchantId);
        Assert.Equal("boleto,card,pix", metadata.ChargeReportParameters.PaymentMethods);
        Assert.Equal("stone", metadata.ChargeReportParameters.Organizations);
    }

    [Fact]
    public void CreateReportMetadata_WithParentJobId_ShouldPropagateReportId()
    {
        var request = CreateBasicRequest();

        var metadata = InvokeCreateReportMetadata(_aggregator, request, "parent-123");

        Assert.Equal("parent-123", metadata.ReportId);
        Assert.Equal(WorkerStatesEnum.Processing.ToString(), metadata.Status);
    }

    [Fact]
    public void CreateReportMetadata_WithCorrelationId_ShouldUseCorrelationIdAsReportId()
    {
        var request = CreateBasicRequest();

        var metadata = InvokeCreateReportMetadata(_aggregator, request, "parent-123", CreateBasicIdsMapped(), "correlation-456");

        Assert.Equal("correlation-456", metadata.ReportId);
    }

    [Fact]
    public void CreateReportMetadata_WithCorrelationIdAndNullParentJobId_ShouldUseCorrelationId()
    {
        var request = CreateBasicRequest();

        var metadata = InvokeCreateReportMetadata(_aggregator, request, null, CreateBasicIdsMapped(), "correlation-789");

        Assert.Equal("correlation-789", metadata.ReportId);
    }

    [Fact]
    public void CreateReportMetadata_ShouldUseReportConfigurationSortIndex()
    {
        var request = CreateBasicRequest();

        var expectedConfig = ConfigProvider
            .GetConfiguration(request.Type) ?? throw new InvalidOperationException("Config not found for test");

        var metadata = InvokeCreateReportMetadata(_aggregator, request, null);

        Assert.Equal(expectedConfig.ReportSortColumnIndex, metadata.ReportSortColumnIndex);
    }

    [Fact]
    public void CreateReportMetadata_ShouldPropagateFileFormatToParametersAndNotification()
    {
        var request = CreateBasicRequest();
        request.FileFormat = FileFormatEnum.Xlsx.Name;

        var metadata = InvokeCreateReportMetadata(_aggregator, request, null);

        Assert.Equal(FileFormatEnum.Xlsx.Name, metadata.FileFormat);
        Assert.Equal(FileFormatEnum.Xlsx.Name, metadata.ChargeReportParameters!.FileFormat);
        Assert.Equal(FileFormatEnum.Xlsx.Name, metadata.NotificationParameters!.FileFormat);
    }

    [Fact]
    public void CreateReportMetadata_WithIdsMapped_ShouldMapStoneAccounts()
    {
        var request = CreateBasicRequest();
        var idsMapped = new List<MerchantIdSummary>
        {
            new() { StoneAccount = "account1" },
            new() { StoneAccount = "account2" }
        };

        _aggregator.GetField("stoneAccounts").Returns("account1,account2");

        var metadata = InvokeCreateReportMetadata(_aggregator, request, null, idsMapped);

        Assert.NotNull(metadata.ChargeReportParameters);
        Assert.Equal("account1,account2", metadata.ChargeReportParameters.StoneAccounts);
    }

    [Fact]
    public void CreateReportMetadata_WithIdsMapped_ShouldMapPaymentProfiles()
    {
        var request = CreateBasicRequest();
        var idsMapped = new List<MerchantIdSummary>
        {
            new() { PaymentProfileIds = "profile1" },
            new() { PaymentProfileIds = "profile2" }
        };

        _aggregator.GetField("paymentProfiles").Returns("profile1,profile2");

        var metadata = InvokeCreateReportMetadata(_aggregator, request, null, idsMapped);

        Assert.NotNull(metadata.ChargeReportParameters);
        Assert.Equal("profile1,profile2", metadata.ChargeReportParameters.PaymentProfiles);
    }

    [Fact]
    public void CreateReportMetadata_WithIdsMapped_ShouldMapPoiTypes()
    {
        var request = CreateBasicRequest();
        var idsMapped = new List<MerchantIdSummary>
        {
            new() { PointOfInteractionTypes = "pos" },
            new() { PointOfInteractionTypes = "ecommerce" }
        };

        _aggregator.GetField("poiTypes").Returns("pos,ecommerce");

        var metadata = InvokeCreateReportMetadata(_aggregator, request, null, idsMapped);

        Assert.NotNull(metadata.ChargeReportParameters);
        Assert.Equal("pos,ecommerce", metadata.ChargeReportParameters.PoiTypes);
    }

    [Fact]
    public void CreateReportMetadata_WithIdsMappedAllFields_ShouldMapAllCorrectly()
    {
        var request = CreateBasicRequest();
        var idsMapped = new List<MerchantIdSummary>
        {
            new()
            {
                Document = "doc1",
                MerchantId = "merch1",
                AccountIds = "acc1",
                AffiliationCodes = "aff1",
                Organization = "org1",
                StoneAccount = "stone1",
                PaymentProfileIds = "prof1",
                PointOfInteractionTypes = "pos"
            },
            new()
            {
                Document = "doc2",
                MerchantId = "merch2",
                AccountIds = "acc2",
                AffiliationCodes = "aff2",
                Organization = "org2",
                StoneAccount = "stone2",
                PaymentProfileIds = "prof2",
                PointOfInteractionTypes = "mobile"
            }
        };

        _aggregator.GetField("document").Returns("doc1,doc2");
        _aggregator.GetField("merchantId").Returns("merch1,merch2");
        _aggregator.GetField("accountIds").Returns("acc1,acc2");
        _aggregator.GetField("affiliationCodes").Returns("aff1,aff2");
        _aggregator.GetField("organizations").Returns("org1,org2");
        _aggregator.GetField("stoneAccounts").Returns("stone1,stone2");
        _aggregator.GetField("paymentProfiles").Returns("prof1,prof2");
        _aggregator.GetField("poiTypes").Returns("pos,mobile");

        var metadata = InvokeCreateReportMetadata(_aggregator, request, null, idsMapped);

        Assert.NotNull(metadata.ChargeReportParameters);
        Assert.Equal("doc1,doc2", metadata.ChargeReportParameters.Document);
        Assert.Equal("merch1,merch2", metadata.ChargeReportParameters.MerchantId);
        Assert.Equal("acc1,acc2", metadata.ChargeReportParameters.AccountId);
        Assert.Equal("aff1,aff2", metadata.ChargeReportParameters.AffiliationCodes);
        Assert.Equal("org1,org2", metadata.ChargeReportParameters.Organizations);
        Assert.Equal("stone1,stone2", metadata.ChargeReportParameters.StoneAccounts);
        Assert.Equal("prof1,prof2", metadata.ChargeReportParameters.PaymentProfiles);
        Assert.Equal("pos,mobile", metadata.ChargeReportParameters.PoiTypes);
    }

    [Fact]
    public void CreateReportMetadata_WithNullIdsMapped_ShouldSetFieldsToNull()
    {
        var request = CreateBasicRequest();
        request.Filters.Identifiers = new Identifiers();

        _aggregator.GetField("stoneAccounts").Returns((string?)null);
        _aggregator.GetField("paymentProfiles").Returns((string?)null);
        _aggregator.GetField("poiTypes").Returns((string?)null);

        var metadata = InvokeCreateReportMetadata(_aggregator, request, null, null);

        Assert.NotNull(metadata.ChargeReportParameters);
        Assert.Null(metadata.ChargeReportParameters.StoneAccounts);
        Assert.Null(metadata.ChargeReportParameters.PaymentProfiles);
        Assert.Null(metadata.ChargeReportParameters.PoiTypes);
    }

    [Fact]
    public void CreateReportMetadata_WithEmptyIdsMapped_ShouldSetFieldsToNull()
    {
        var request = CreateBasicRequest();
        var idsMapped = new List<MerchantIdSummary>();

        _aggregator.GetField("stoneAccounts").Returns((string?)null);
        _aggregator.GetField("paymentProfiles").Returns((string?)null);
        _aggregator.GetField("poiTypes").Returns((string?)null);

        var metadata = InvokeCreateReportMetadata(_aggregator, request, null, idsMapped);

        Assert.NotNull(metadata.ChargeReportParameters);
        Assert.Null(metadata.ChargeReportParameters.StoneAccounts);
        Assert.Null(metadata.ChargeReportParameters.PaymentProfiles);
        Assert.Null(metadata.ChargeReportParameters.PoiTypes);
    }

    [Fact]
    public void CreateReportMetadata_WithIdsMappedPartialNulls_ShouldSkipNullValues()
    {
        var request = CreateBasicRequest();
        var idsMapped = new List<MerchantIdSummary>
        {
            new() { StoneAccount = "account1", PaymentProfileIds = null, PointOfInteractionTypes = "pos" },
            new() { StoneAccount = null, PaymentProfileIds = "profile2", PointOfInteractionTypes = null }
        };

        _aggregator.GetField("stoneAccounts").Returns("account1");
        _aggregator.GetField("paymentProfiles").Returns("profile2");
        _aggregator.GetField("poiTypes").Returns("pos");

        var metadata = InvokeCreateReportMetadata(_aggregator, request, null, idsMapped);

        Assert.NotNull(metadata.ChargeReportParameters);
        Assert.Equal("account1", metadata.ChargeReportParameters.StoneAccounts);
        Assert.Equal("profile2", metadata.ChargeReportParameters.PaymentProfiles);
        Assert.Equal("pos", metadata.ChargeReportParameters.PoiTypes);
    }

    [Fact]
    public void CreateReportMetadata_WithEmailNotification_ShouldMapCorrectly()
    {
        var request = CreateBasicRequest();
        request.Notification = new Notification
        {
            Type = "email",
            Email = new EmailNotification { Address = "test@example.com" }
        };

        var metadata = InvokeCreateReportMetadata(_aggregator, request, null);

        Assert.NotNull(metadata.NotificationParameters);
        Assert.NotNull(metadata.NotificationParameters.Channel);
        Assert.NotNull(metadata.NotificationParameters.Channel.Email);
        Assert.Equal("test@example.com", metadata.NotificationParameters.Channel.Email.Address);
    }

    [Fact]
    public void CreateReportMetadata_WithWebhookNotification_ShouldMapCorrectly()
    {
        var request = CreateBasicRequest();
        request.Notification = new Notification
        {
            Type = "webhook",
            Webhook = new WebhookNotification
            {
                Url = "https://example.com/webhook",
                Headers = new Dictionary<string, string> { { "Authorization", "Bearer token" } }
            }
        };

        var metadata = InvokeCreateReportMetadata(_aggregator, request, null);

        Assert.NotNull(metadata.NotificationParameters);
        Assert.NotNull(metadata.NotificationParameters.Channel);
        Assert.NotNull(metadata.NotificationParameters.Channel.Webhook);
        Assert.Equal("https://example.com/webhook", metadata.NotificationParameters.Channel.Webhook.Url);
        Assert.NotNull(metadata.NotificationParameters.Channel.Webhook.Headers);
        Assert.Equal("Bearer token", metadata.NotificationParameters.Channel.Webhook.Headers["Authorization"]);
    }

    [Fact]
    public void CreateReportMetadata_WithReceivablesType_ShouldPopulateFinMovParametersAndNullChargeParameters()
    {
        var request = CreateBasicRequest();
        request.Type = ReportTypeEnum.Receivables.Name;

        var metadata = InvokeCreateReportMetadata(_aggregator, request, null);

        Assert.Null(metadata.ChargeReportParameters);
        Assert.NotNull(metadata.FinMovReportParameters);
        Assert.Equal(ReportTypeEnum.Receivables.Name, metadata.FinMovReportParameters!.ReportType);
    }

    [Fact]
    public void CreateReportMetadata_WithReceivablesAndNoParentJob_ShouldIncludeNotificationInFinMovParameters()
    {
        var request = CreateBasicRequest();
        request.Type = ReportTypeEnum.Receivables.Name;
        request.Notification = new Notification
        {
            Type = "email",
            Email = new EmailNotification { Address = "test@example.com" }
        };

        var metadata = InvokeCreateReportMetadata(_aggregator, request, parentJobId: null);

        Assert.Equal("test@example.com", metadata.FinMovReportParameters!.Email);
    }

    [Fact]
    public void CreateReportMetadata_WithReceivablesAndParentJob_ShouldSuppressNotificationInFinMovParameters()
    {
        // In a hybrid report, ES is the first leg (parentJobId == null for ES, but S3 continuation
        // uses parentJobId). When parentJobId != null, it's a hybrid continuation and the ES
        // partial job should NOT send a notification — only the S3 concat step does.
        var request = CreateBasicRequest();
        request.Type = ReportTypeEnum.Receivables.Name;
        request.Notification = new Notification
        {
            Type = "email",
            Email = new EmailNotification { Address = "should-not-appear@example.com" },
            Webhook = new WebhookNotification
            {
                Url = "https://should-not-appear.com",
                Headers = new Dictionary<string, string> { { "X-Token", "secret" } }
            }
        };

        var metadata = InvokeCreateReportMetadata(_aggregator, request, parentJobId: "parent-job-123");

        Assert.Null(metadata.FinMovReportParameters!.Email);
        Assert.Null(metadata.FinMovReportParameters!.WebhookUrl);
        Assert.Null(metadata.FinMovReportParameters!.Headers);
    }
}


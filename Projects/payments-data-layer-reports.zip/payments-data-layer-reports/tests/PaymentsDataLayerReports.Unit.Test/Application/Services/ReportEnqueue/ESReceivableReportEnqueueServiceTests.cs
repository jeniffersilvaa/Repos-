using System.Text.Json;
using Hangfire;
using Hangfire.Common;
using Hangfire.States;
using NSubstitute;
using PaymentsDataLayerReports.Application.Routes.Reports.PostReports;
using PaymentsDataLayerReports.Application.Routes.Reports.PostReports.Models;
using PaymentsDataLayerReports.Application.Services.IdMapper;
using PaymentsDataLayerReports.Application.Services.ReportEnqueue;
using PaymentsDataLayerReports.Application.Workers.FinMovReportESWorker;

namespace PaymentsDataLayerReports.Unit.Test.Application.Services.ReportEnqueue;

public class ESReceivableReportEnqueueServiceTests
{
    private readonly IBackgroundJobClient _backgroundJobClient;
    private readonly IMerchantIdSummaryAggregator _aggregator = new MerchantIdAggregator();
    private readonly ESReceivableReportEnqueueService _service;

    public ESReceivableReportEnqueueServiceTests()
    {
        _backgroundJobClient = Substitute.For<IBackgroundJobClient>();
        _backgroundJobClient.Create(Arg.Any<Job>(), Arg.Any<IState>()).Returns("job-123");
        _service = new ESReceivableReportEnqueueService(_backgroundJobClient, _aggregator);
    }

    private static PostReportsRequest CreateValidRequest()
    {
        return new PostReportsRequest
        {
            Type = "receivables",
            FileFormat = "csv",
            Filters = new ReportFilters
            {
                StartDate = new DateOnly(2025, 1, 1),
                FinalDate = new DateOnly(2025, 1, 31),
                Organizations = ["stone"],
                Identifiers = new Identifiers { Documents = ["12345678901"] }
            }
        };
    }

    private static List<MerchantIdSummary> CreateValidIdsMapped()
    {
        return
        [
            new MerchantIdSummary
            {
                Document = "12345678901",
                Organization = "stone"
            }
        ];
    }

    [Fact]
    public void EnqueueReport_WithValidRequest_ShouldReturnJobId()
    {
        // Arrange
        var request = CreateValidRequest();

        // Act
        var result = _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.Equal("job-123", result);
    }

    [Fact]
    public void EnqueueReport_WithValidRequest_ShouldCallBackgroundJobClient()
    {
        // Arrange
        var request = CreateValidRequest();

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        _backgroundJobClient.Received(1).Create(Arg.Any<Job>(), Arg.Any<IState>());
    }

    [Fact]
    public void EnqueueReport_WithIsSandboxTrue_ShouldParseCorrectly()
    {
        // Arrange
        var request = CreateValidRequest();
        request.Extra = new ReportExtra
        {
            { "is_sandbox", JsonDocument.Parse("true").RootElement }
        };

        // Act
        var result = _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.Equal("job-123", result);
        _backgroundJobClient.Received(1).Create(Arg.Any<Job>(), Arg.Any<IState>());
    }

    [Fact]
    public void EnqueueReport_WithWithPaymentsTrue_ShouldParseCorrectly()
    {
        // Arrange
        var request = CreateValidRequest();
        request.Extra = new ReportExtra
        {
            { "with_payments", JsonDocument.Parse("true").RootElement }
        };

        // Act
        var result = _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.Equal("job-123", result);
    }

    [Fact]
    public void EnqueueReport_WithCardBrandsArray_ShouldParseCorrectly()
    {
        // Arrange
        var request = CreateValidRequest();
        request.Extra = new ReportExtra
        {
            { "card_brands", JsonDocument.Parse("[\"visa\", \"mastercard\"]").RootElement }
        };

        // Act
        var result = _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.Equal("job-123", result);
    }

    [Fact]
    public void EnqueueReport_WithEmailNotification_ShouldParseCorrectly()
    {
        // Arrange
        var request = CreateValidRequest();
        request.Notification = new Notification
        {
            Type = "email",
            Email = new EmailNotification { Address = "test@example.com" }
        };

        // Act
        var result = _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.Equal("job-123", result);
    }

    [Fact]
    public void EnqueueReport_WithWebhookNotification_ShouldParseCorrectly()
    {
        // Arrange
        var request = CreateValidRequest();
        request.Notification = new Notification
        {
            Type = "webhook",
            Webhook = new WebhookNotification
            {
                Url = "https://example.com/webhook",
                Headers = new Dictionary<string, string> { { "Authorization", "Bearer token" } }
            }
        };

        // Act
        var result = _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.Equal("job-123", result);
    }

    [Fact]
    public void EnqueueReport_WithXlsxFormat_ShouldParseCorrectly()
    {
        // Arrange
        var request = CreateValidRequest();
        request.FileFormat = "xlsx";

        // Act
        var result = _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.Equal("job-123", result);
    }

    [Fact]
    public void EnqueueReport_WithMultipleDocuments_ShouldJoinWithComma()
    {
        // Arrange
        var request = CreateValidRequest();
        request.Filters.Identifiers = new Identifiers
        {
            Documents = ["12345678901", "98765432100"]
        };

        // Act
        var result = _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.Equal("job-123", result);
    }

    [Fact]
    public void EnqueueReport_WithMultipleOrganizations_ShouldJoinWithComma()
    {
        // Arrange
        var request = CreateValidRequest();
        request.Filters.Organizations = ["stone", "ton"];

        // Act
        var result = _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.Equal("job-123", result);
    }

    [Fact]
    public void EnqueueReport_WithNullExtra_ShouldNotThrow()
    {
        // Arrange
        var request = CreateValidRequest();
        request.Extra = null;

        // Act
        var result = _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.Equal("job-123", result);
    }

    [Fact]
    public void EnqueueReport_WithIdsMapped_ShouldMapStoneAccounts()
    {
        // Arrange
        var request = CreateValidRequest();
        var idsMapped = new List<MerchantIdSummary>
        {
            new() { StoneAccount = "account1" },
            new() { StoneAccount = "account2" }
        };
        FinMovESWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo =>
            {
                var job = callInfo.ArgAt<Job>(0);
                capturedParameters = job.Args[0] as FinMovESWorkerParameters;
            });

        // Act
        _service.EnqueueReport(request, idsMapped);

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("account1,account2", capturedParameters.StoneAccounts);
    }

    [Fact]
    public void EnqueueReport_WithIdsMapped_ShouldMapPaymentProfiles()
    {
        // Arrange
        var request = CreateValidRequest();
        var idsMapped = new List<MerchantIdSummary>
        {
            new() { PaymentProfileIds = "profile1" },
            new() { PaymentProfileIds = "profile2" }
        };
        FinMovESWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo =>
            {
                var job = callInfo.ArgAt<Job>(0);
                capturedParameters = job.Args[0] as FinMovESWorkerParameters;
            });

        // Act
        _service.EnqueueReport(request, idsMapped);

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("profile1,profile2", capturedParameters.PaymentProfiles);
    }

    [Fact]
    public void EnqueueReport_WithIdsMapped_ShouldMapPoiTypes()
    {
        // Arrange
        var request = CreateValidRequest();
        var idsMapped = new List<MerchantIdSummary>
        {
            new() { PointOfInteractionTypes = "pos" },
            new() { PointOfInteractionTypes = "ecommerce" }
        };
        FinMovESWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo =>
            {
                var job = callInfo.ArgAt<Job>(0);
                capturedParameters = job.Args[0] as FinMovESWorkerParameters;
            });

        // Act
        _service.EnqueueReport(request, idsMapped);

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("pos,ecommerce", capturedParameters.PoiTypes);
    }

    [Fact]
    public void EnqueueReport_WithIdsMappedAllNewFields_ShouldMapAllCorrectly()
    {
        // Arrange
        var request = CreateValidRequest();
        var idsMapped = new List<MerchantIdSummary>
        {
            new()
            {
                StoneAccount = "account1",
                PaymentProfileIds = "profile1",
                PointOfInteractionTypes = "pos"
            },
            new()
            {
                StoneAccount = "account2",
                PaymentProfileIds = "profile2",
                PointOfInteractionTypes = "mobile"
            }
        };
        FinMovESWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo =>
            {
                var job = callInfo.ArgAt<Job>(0);
                capturedParameters = job.Args[0] as FinMovESWorkerParameters;
            });

        // Act
        _service.EnqueueReport(request, idsMapped);

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("account1,account2", capturedParameters.StoneAccounts);
        Assert.Equal("profile1,profile2", capturedParameters.PaymentProfiles);
        Assert.Equal("pos,mobile", capturedParameters.PoiTypes);
    }

    [Fact]
    public void EnqueueReport_WithIdsMappedNullValues_ShouldSkipNulls()
    {
        // Arrange
        var request = CreateValidRequest();
        var idsMapped = new List<MerchantIdSummary>
        {
            new() { StoneAccount = "account1", PaymentProfileIds = null },
            new() { StoneAccount = null, PaymentProfileIds = "profile2" }
        };
        FinMovESWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo =>
            {
                var job = callInfo.ArgAt<Job>(0);
                capturedParameters = job.Args[0] as FinMovESWorkerParameters;
            });

        // Act
        _service.EnqueueReport(request, idsMapped);

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("account1", capturedParameters.StoneAccounts);
        Assert.Equal("profile2", capturedParameters.PaymentProfiles);
    }

    [Fact]
    public void EnqueueReport_WithEmailNotification_ShouldSetEmailParameter()
    {
        // Arrange
        var request = CreateValidRequest();
        request.Notification = new Notification
        {
            Type = "email",
            Email = new EmailNotification { Address = "user@example.com" }
        };
        FinMovESWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo =>
            {
                var job = callInfo.ArgAt<Job>(0);
                capturedParameters = job.Args[0] as FinMovESWorkerParameters;
            });

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("user@example.com", capturedParameters.Email);
    }

    [Fact]
    public void EnqueueReport_WithWebhookNotification_ShouldSetWebhookParameters()
    {
        // Arrange
        var request = CreateValidRequest();
        request.Notification = new Notification
        {
            Type = "webhook",
            Webhook = new WebhookNotification
            {
                Url = "https://example.com/hook",
                Headers = new Dictionary<string, string> { { "X-Token", "abc" } }
            }
        };
        FinMovESWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo =>
            {
                var job = callInfo.ArgAt<Job>(0);
                capturedParameters = job.Args[0] as FinMovESWorkerParameters;
            });

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("https://example.com/hook", capturedParameters.WebhookUrl);
        Assert.Equal("abc", capturedParameters.Headers!["X-Token"]);
    }

    [Fact]
    public void EnqueueReport_ShouldSetDateRangeCorrectly()
    {
        // Arrange
        var request = CreateValidRequest();
        request.Filters.StartDate = new DateOnly(2024, 3, 1);
        request.Filters.FinalDate = new DateOnly(2024, 3, 31);
        FinMovESWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo =>
            {
                var job = callInfo.ArgAt<Job>(0);
                capturedParameters = job.Args[0] as FinMovESWorkerParameters;
            });

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal(new DateOnly(2024, 3, 1), capturedParameters.StartDate);
        Assert.Equal(new DateOnly(2024, 3, 31), capturedParameters.EndDate);
    }

    [Fact]
    public void EnqueueReport_ShouldSetFileFormatCorrectly()
    {
        // Arrange
        var request = CreateValidRequest();
        request.FileFormat = "xlsx";
        FinMovESWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo =>
            {
                var job = callInfo.ArgAt<Job>(0);
                capturedParameters = job.Args[0] as FinMovESWorkerParameters;
            });

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("xlsx", capturedParameters.FileFormat);
    }

    [Fact]
    public void EnqueueReport_WithCorrelationId_ShouldSetReportIdOnParameters()
    {
        // Arrange
        var request = CreateValidRequest();
        FinMovESWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo =>
            {
                var job = callInfo.ArgAt<Job>(0);
                capturedParameters = job.Args[0] as FinMovESWorkerParameters;
            });

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped(), "test-correlation-123");

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("test-correlation-123", capturedParameters.ReportId);
    }

    [Fact]
    public void EnqueueReport_WithNullCorrelationId_ShouldNotSetReportId()
    {
        // Arrange
        var request = CreateValidRequest();
        FinMovESWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo =>
            {
                var job = callInfo.ArgAt<Job>(0);
                capturedParameters = job.Args[0] as FinMovESWorkerParameters;
            });

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Null(capturedParameters.ReportId);
    }

    [Fact]
    public void EnqueueReport_WithMultipleCalls_ShouldNotAccumulateDocumentsFromPreviousCalls()
    {
        // Arrange
        var request = CreateValidRequest();

        _service.EnqueueReport(request,
        [
            new() { Document = "doc1" },
            new() { Document = "doc2" }
        ]);

        var idsMapped = new List<MerchantIdSummary>
        {
            new() { Document = "doc3" },
            new() { Document = "doc4" }
        };

        FinMovESWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo =>
            {
                var job = callInfo.ArgAt<Job>(0);
                capturedParameters = job.Args[0] as FinMovESWorkerParameters;
            });

        // Act
        _service.EnqueueReport(request, idsMapped);

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("doc3,doc4", capturedParameters.Document);
    }
}

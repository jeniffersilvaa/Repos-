using Hangfire;
using Hangfire.Common;
using Hangfire.States;
using NSubstitute;
using PaymentsDataLayerReports.Application.Routes.Reports.PostReports;
using PaymentsDataLayerReports.Application.Routes.Reports.PostReports.Models;
using PaymentsDataLayerReports.Application.Services.IdMapper;
using PaymentsDataLayerReports.Application.Services.ReportEnqueue;
using PaymentsDataLayerReports.Application.Workers.OrderReportESWorker;

namespace PaymentsDataLayerReports.Unit.Test.Application.Services.ReportEnqueue;

public class ESOrderReportEnqueueServiceTests
{
    private readonly IBackgroundJobClient _backgroundJobClient;
    private readonly IMerchantIdSummaryAggregator _aggregator;
    private readonly ESOrderReportEnqueueService _service;

    public ESOrderReportEnqueueServiceTests()
    {
        _backgroundJobClient = Substitute.For<IBackgroundJobClient>();
        _backgroundJobClient.Create(Arg.Any<Job>(), Arg.Any<IState>()).Returns("job-123");

        _aggregator = Substitute.For<IMerchantIdSummaryAggregator>();

        _service = new ESOrderReportEnqueueService(_backgroundJobClient, _aggregator);
    }

    private static PostReportsRequest CreateValidRequest()
    {
        return new PostReportsRequest
        {
            Type = "orders",
            FileFormat = "csv",
            Filters = new ReportFilters
            {
                StartDate = new DateOnly(2025, 1, 1),
                FinalDate = new DateOnly(2025, 1, 31),
                Organizations = ["stone"],
                Identifiers = new Identifiers { Documents = ["12345678901"] }
            }
        };
    }

    private static List<MerchantIdSummary> CreateValidIdsMapped()
    {
        return
        [
            new MerchantIdSummary
            {
                Document = "12345678901",
                Organization = "stone"
            }
        ];
    }

    [Fact]
    public void EnqueueReport_WithValidRequest_ShouldReturnJobId()
    {
        // Arrange
        var request = CreateValidRequest();

        // Act
        var result = _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.Equal("job-123", result);
    }

    [Fact]
    public void EnqueueReport_WithValidRequest_ShouldCallBackgroundJobClientOnce()
    {
        // Arrange
        var request = CreateValidRequest();

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        _backgroundJobClient.Received(1).Create(Arg.Any<Job>(), Arg.Any<IState>());
    }

    [Fact]
    public void EnqueueReport_WithIdsMapped_ShouldCallAggregatorProcess()
    {
        // Arrange
        var request = CreateValidRequest();
        var idsMapped = CreateValidIdsMapped();

        // Act
        _service.EnqueueReport(request, idsMapped);

        // Assert
        _aggregator.Received(1).Process(idsMapped);
    }

    [Fact]
    public void EnqueueReport_WithDocumentField_ShouldPassDocumentsToWorker()
    {
        // Arrange
        var request = CreateValidRequest();
        _aggregator.GetField("document").Returns("12345678901");

        OrderReportWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo =>
            {
                var job = callInfo.ArgAt<Job>(0);
                capturedParameters = job.Args[0] as OrderReportWorkerParameters;
            });

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("12345678901", capturedParameters.Documents);
    }

    [Fact]
    public void EnqueueReport_WithMerchantIdField_ShouldPassMerchantIdsToWorker()
    {
        // Arrange
        var request = CreateValidRequest();
        _aggregator.GetField("merchantId").Returns("merchant-1,merchant-2");

        OrderReportWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo =>
            {
                var job = callInfo.ArgAt<Job>(0);
                capturedParameters = job.Args[0] as OrderReportWorkerParameters;
            });

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("merchant-1,merchant-2", capturedParameters.MerchantId);
    }

    [Fact]
    public void EnqueueReport_WithStoneAccountsField_ShouldPassStoneAccountsToWorker()
    {
        // Arrange
        var request = CreateValidRequest();
        _aggregator.GetField("stoneAccounts").Returns("account1,account2");

        OrderReportWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo =>
            {
                var job = callInfo.ArgAt<Job>(0);
                capturedParameters = job.Args[0] as OrderReportWorkerParameters;
            });

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("account1,account2", capturedParameters.StoneAccounts);
    }

    [Fact]
    public void EnqueueReport_WithPaymentProfilesField_ShouldPassPaymentProfilesToWorker()
    {
        // Arrange
        var request = CreateValidRequest();
        _aggregator.GetField("paymentProfiles").Returns("profile1,profile2");

        OrderReportWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo =>
            {
                var job = callInfo.ArgAt<Job>(0);
                capturedParameters = job.Args[0] as OrderReportWorkerParameters;
            });

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("profile1,profile2", capturedParameters.PaymentProfiles);
    }

    [Fact]
    public void EnqueueReport_WithPoiTypesField_ShouldPassPoiTypesToWorker()
    {
        // Arrange
        var request = CreateValidRequest();
        _aggregator.GetField("poiTypes").Returns("pos,ecommerce");

        OrderReportWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo =>
            {
                var job = callInfo.ArgAt<Job>(0);
                capturedParameters = job.Args[0] as OrderReportWorkerParameters;
            });

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("pos,ecommerce", capturedParameters.PoiTypes);
    }

    [Fact]
    public void EnqueueReport_WithAllAggregatedFields_ShouldPassAllToWorker()
    {
        // Arrange
        var request = CreateValidRequest();
        _aggregator.GetField("document").Returns("12345678901");
        _aggregator.GetField("merchantId").Returns("merchant-1");
        _aggregator.GetField("stoneAccounts").Returns("account1");
        _aggregator.GetField("paymentProfiles").Returns("profile1");
        _aggregator.GetField("poiTypes").Returns("pos");

        OrderReportWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo =>
            {
                var job = callInfo.ArgAt<Job>(0);
                capturedParameters = job.Args[0] as OrderReportWorkerParameters;
            });

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("12345678901", capturedParameters.Documents);
        Assert.Equal("merchant-1", capturedParameters.MerchantId);
        Assert.Equal("account1", capturedParameters.StoneAccounts);
        Assert.Equal("profile1", capturedParameters.PaymentProfiles);
        Assert.Equal("pos", capturedParameters.PoiTypes);
    }

    [Fact]
    public void EnqueueReport_WithNullAggregatedFields_ShouldPassNullsToWorker()
    {
        // Arrange
        var request = CreateValidRequest();
        _aggregator.GetField(Arg.Any<string>()).Returns((string?)null);

        OrderReportWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo =>
            {
                var job = callInfo.ArgAt<Job>(0);
                capturedParameters = job.Args[0] as OrderReportWorkerParameters;
            });

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Null(capturedParameters.Documents);
        Assert.Null(capturedParameters.MerchantId);
        Assert.Null(capturedParameters.StoneAccounts);
        Assert.Null(capturedParameters.PaymentProfiles);
        Assert.Null(capturedParameters.PoiTypes);
    }

    [Fact]
    public void EnqueueReport_WithIsTestAccountTrue_ShouldSetFlagOnWorker()
    {
        // Arrange
        var request = CreateValidRequest();
        request.Extra = new ReportExtra
        {
            { "is_test_account", System.Text.Json.JsonDocument.Parse("true").RootElement }
        };

        OrderReportWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo =>
            {
                var job = callInfo.ArgAt<Job>(0);
                capturedParameters = job.Args[0] as OrderReportWorkerParameters;
            });

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.True(capturedParameters.IsTestAccount);
    }

    [Fact]
    public void EnqueueReport_WithIsTestAccountFalse_ShouldSetFlagOnWorker()
    {
        // Arrange
        var request = CreateValidRequest();
        request.Extra = new ReportExtra
        {
            { "is_test_account", System.Text.Json.JsonDocument.Parse("false").RootElement }
        };

        OrderReportWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo =>
            {
                var job = callInfo.ArgAt<Job>(0);
                capturedParameters = job.Args[0] as OrderReportWorkerParameters;
            });

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.False(capturedParameters.IsTestAccount);
    }

    [Fact]
    public void EnqueueReport_WithNullExtra_ShouldNotThrowAndIsTestAccountFalse()
    {
        // Arrange
        var request = CreateValidRequest();
        request.Extra = null;

        OrderReportWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo =>
            {
                var job = callInfo.ArgAt<Job>(0);
                capturedParameters = job.Args[0] as OrderReportWorkerParameters;
            });

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.False(capturedParameters.IsTestAccount);
    }

    [Fact]
    public void EnqueueReport_WithEmailNotification_ShouldSetNotificationOnWorker()
    {
        // Arrange
        var request = CreateValidRequest();
        request.Notification = new Notification
        {
            Type = "email",
            Email = new EmailNotification { Address = "user@example.com" }
        };

        OrderReportWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo =>
            {
                var job = callInfo.ArgAt<Job>(0);
                capturedParameters = job.Args[0] as OrderReportWorkerParameters;
            });

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.NotNull(capturedParameters.Notification);
        Assert.Equal("email", capturedParameters.Notification.Type);
        Assert.Equal("user@example.com", capturedParameters.Notification.Email?.Address);
    }

    [Fact]
    public void EnqueueReport_WithWebhookNotification_ShouldSetNotificationOnWorker()
    {
        // Arrange
        var request = CreateValidRequest();
        request.Notification = new Notification
        {
            Type = "webhook",
            Webhook = new WebhookNotification
            {
                Url = "https://example.com/hook",
                Headers = new Dictionary<string, string> { { "X-Token", "abc" } }
            }
        };

        OrderReportWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo =>
            {
                var job = callInfo.ArgAt<Job>(0);
                capturedParameters = job.Args[0] as OrderReportWorkerParameters;
            });

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.NotNull(capturedParameters.Notification);
        Assert.Equal("webhook", capturedParameters.Notification.Type);
        Assert.Equal("https://example.com/hook", capturedParameters.Notification.Webhook?.Url);
    }

    [Fact]
    public void EnqueueReport_ShouldSetDateRangeCorrectly()
    {
        // Arrange
        var request = CreateValidRequest();
        request.Filters.StartDate = new DateOnly(2024, 3, 1);
        request.Filters.FinalDate = new DateOnly(2024, 3, 31);

        OrderReportWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo =>
            {
                var job = callInfo.ArgAt<Job>(0);
                capturedParameters = job.Args[0] as OrderReportWorkerParameters;
            });

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal(new DateTimeOffset(2024, 3, 1, 0, 0, 0, 0, TimeSpan.FromHours(-3)), capturedParameters.StartDueDate);
        Assert.Equal(new DateTimeOffset(2024, 3, 31, 23, 59, 59, 999, TimeSpan.FromHours(-3)), capturedParameters.EndDueDate);
    }

    [Fact]
    public void EnqueueReport_ShouldSetFileFormatCorrectly()
    {
        // Arrange
        var request = CreateValidRequest();
        request.FileFormat = "xlsx";

        OrderReportWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo =>
            {
                var job = callInfo.ArgAt<Job>(0);
                capturedParameters = job.Args[0] as OrderReportWorkerParameters;
            });

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("xlsx", capturedParameters.FileFormat);
    }

    [Fact]
    public void EnqueueReport_WithXlsxFormat_ShouldReturnJobId()
    {
        // Arrange
        var request = CreateValidRequest();
        request.FileFormat = "xlsx";

        // Act
        var result = _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.Equal("job-123", result);
    }

    [Fact]
    public void EnqueueReport_WithCorrelationId_ShouldPassCorrelationIdToWorker()
    {
        // Arrange
        var request = CreateValidRequest();
        OrderReportWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo => capturedParameters = callInfo.ArgAt<Job>(0).Args[0] as OrderReportWorkerParameters);

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped(), "test-correlation-123");

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Equal("test-correlation-123", capturedParameters.ReportId);
    }

    [Fact]
    public void EnqueueReport_WithNullCorrelationId_ShouldPassNullToWorker()
    {
        // Arrange
        var request = CreateValidRequest();
        OrderReportWorkerParameters? capturedParameters = null;
        _backgroundJobClient.When(x => x.Create(Arg.Any<Job>(), Arg.Any<IState>()))
            .Do(callInfo => capturedParameters = callInfo.ArgAt<Job>(0).Args[0] as OrderReportWorkerParameters);

        // Act
        _service.EnqueueReport(request, CreateValidIdsMapped());

        // Assert
        Assert.NotNull(capturedParameters);
        Assert.Null(capturedParameters.ReportId);
    }
}

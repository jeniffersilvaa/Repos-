using PaymentsDataLayerReports.Application.Services.ReportEnqueue.Helpers;

namespace PaymentsDataLayerReports.Unit.Test.Application.Services.ReportEnqueue;

public class DateRangeSplitterTests
{
    private const int UTCOffset = 0;
    private const int BRTOffset = -3;

    [Fact]
    public void SplitIntoColdAndHotRanges_WhenOnlyHotRange_ShouldReturnNullColdAndHotValues()
    {
        var startDate = DateOnly.FromDateTime(DateTime.UtcNow.Date);
        var finalDate = startDate.AddDays(5);

        var (coldStart, coldEnd, hotStart, hotEnd) = DateRangeSplitter.SplitIntoColdAndHotRanges(startDate, finalDate);

        Assert.Null(coldStart);
        Assert.Null(coldEnd);
        Assert.NotNull(hotStart);
        Assert.NotNull(hotEnd);
    }

    [Fact]
    public void SplitIntoColdAndHotRanges_WhenOnlyHotRange_WithUTCOffset_HotEndDateShouldMatchFinalDate()
    {
        var startDate = DateOnly.FromDateTime(DateTime.UtcNow.Date);
        var finalDate = startDate.AddDays(5);

        var (_, _, _, hotEnd) = DateRangeSplitter.SplitIntoColdAndHotRanges(startDate, finalDate, UTCOffset);

        Assert.Equal(finalDate, DateOnly.FromDateTime(hotEnd!.Value.Date));
    }

    [Fact]
    public void SplitIntoColdAndHotRanges_WhenOnlyHotRange_WithBRTOffset_HotEndUtcDateShouldBeNextDayDueToBRTConversion()
    {
        var startDate = DateOnly.FromDateTime(DateTime.UtcNow.Date);
        var finalDate = startDate.AddDays(5);

        var (_, _, _, hotEnd) = DateRangeSplitter.SplitIntoColdAndHotRanges(startDate, finalDate, BRTOffset);

        // BRT 23:59:59 -3 -> UTC 02:59:59 next day
        Assert.Equal(finalDate.AddDays(1).ToDateTime(TimeOnly.MinValue).Date, hotEnd!.Value.Date);
    }

    [Fact]
    public void SplitIntoColdAndHotRanges_WhenOnlyColdRange_ShouldReturnNullHotAndColdValues()
    {
        var finalDate = DateOnly.FromDateTime(DateTime.UtcNow.Date).AddMonths(-7);
        var startDate = finalDate.AddDays(-30);

        var (coldStart, coldEnd, hotStart, hotEnd) = DateRangeSplitter.SplitIntoColdAndHotRanges(startDate, finalDate);

        Assert.NotNull(coldStart);
        Assert.NotNull(coldEnd);
        Assert.Null(hotStart);
        Assert.Null(hotEnd);
    }

    [Fact]
    public void SplitIntoColdAndHotRanges_WhenOnlyColdRange_WithUTCOffset_ColdEndDateShouldMatchFinalDate()
    {
        var finalDate = DateOnly.FromDateTime(DateTime.UtcNow.Date).AddMonths(-7);
        var startDate = finalDate.AddDays(-30);

        var (_, coldEnd, _, _) = DateRangeSplitter.SplitIntoColdAndHotRanges(startDate, finalDate, UTCOffset);

        Assert.Equal(finalDate, DateOnly.FromDateTime(coldEnd!.Value.Date));
    }

    [Fact]
    public void SplitIntoColdAndHotRanges_WhenHybrid_ShouldReturnAllFourValues()
    {
        var hotCutoffDate = DateOnly.FromDateTime(DateTime.UtcNow.Date).AddMonths(-6);
        var startDate = hotCutoffDate.AddDays(-30);
        var finalDate = hotCutoffDate.AddDays(5);

        var (coldStart, coldEnd, hotStart, hotEnd) = DateRangeSplitter.SplitIntoColdAndHotRanges(startDate, finalDate);

        Assert.NotNull(coldStart);
        Assert.NotNull(coldEnd);
        Assert.NotNull(hotStart);
        Assert.NotNull(hotEnd);
    }

    [Fact]
    public void SplitIntoColdAndHotRanges_WhenHybrid_WithUTCOffset_HotEndDateShouldMatchFinalDate()
    {
        var hotCutoffDate = DateOnly.FromDateTime(DateTime.UtcNow.Date).AddMonths(-6);
        var startDate = hotCutoffDate.AddDays(-30);
        var finalDate = hotCutoffDate.AddDays(5);

        var (_, _, _, hotEnd) = DateRangeSplitter.SplitIntoColdAndHotRanges(startDate, finalDate, UTCOffset);

        Assert.Equal(finalDate, DateOnly.FromDateTime(hotEnd!.Value.Date));
    }

    [Fact]
    public void SplitIntoColdAndHotRanges_WhenHybrid_ColdEndShouldBeHotCutoffDateAndHotStartShouldBeNextDay()
    {
        var hotCutoffDate = DateOnly.FromDateTime(DateTime.UtcNow.Date).AddMonths(-6);
        var startDate = hotCutoffDate.AddDays(-30);
        var finalDate = hotCutoffDate.AddDays(5);

        var (_, coldEnd, hotStart, _) = DateRangeSplitter.SplitIntoColdAndHotRanges(startDate, finalDate);

        Assert.Equal(hotCutoffDate.ToDateTime(TimeOnly.MinValue).Date, coldEnd!.Value.Date);
        Assert.Equal(hotCutoffDate.AddDays(1).ToDateTime(TimeOnly.MinValue).Date, hotStart!.Value.Date);
    }

    [Fact]
    public void SplitIntoColdAndHotRanges_WhenHybrid_WithBRTOffset_HotEndUtcDateShouldBeNextDayDueToBRTConversion()
    {
        var hotCutoffDate = DateOnly.FromDateTime(DateTime.UtcNow.Date).AddMonths(-6);
        var startDate = hotCutoffDate.AddDays(-30);
        var finalDate = hotCutoffDate.AddDays(5);

        var (_, _, _, hotEnd) = DateRangeSplitter.SplitIntoColdAndHotRanges(startDate, finalDate, BRTOffset);

        Assert.Equal(finalDate.AddDays(1).ToDateTime(TimeOnly.MinValue).Date, hotEnd!.Value.Date);
    }
}

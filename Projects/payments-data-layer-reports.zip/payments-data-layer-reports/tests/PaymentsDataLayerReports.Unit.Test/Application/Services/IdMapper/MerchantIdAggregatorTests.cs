using PaymentsDataLayerReports.Application.Services.IdMapper;

namespace PaymentsDataLayerReports.Unit.Test.Application.Services.IdMapper;

public class MerchantIdAggregatorTests
{
    [Fact]
    public void Process_WithSingleItem_ShouldExtractAllFields()
    {
        // Arrange
        var aggregator = new MerchantIdAggregator();
        var items = new List<MerchantIdSummary>
        {
            new()
            {
                Document = "12345678900",
                AffiliationCodes = "AFF001",
                AccountIds = "ACC001",
                MerchantId = "MERCH001",
                Organization = "ORG001",
                StoneAccount = "STONE001",
                PaymentProfileIds = "PAY001",
                PointOfInteractionTypes = "POI001"
            }
        };

        // Act
        aggregator.Process(items);

        // Assert
        Assert.Equal("12345678900", aggregator.GetField("document"));
        Assert.Equal("AFF001", aggregator.GetField("affiliationCodes"));
        Assert.Equal("ACC001", aggregator.GetField("accountIds"));
        Assert.Equal("MERCH001", aggregator.GetField("merchantId"));
        Assert.Equal("ORG001", aggregator.GetField("organizations"));
        Assert.Equal("STONE001", aggregator.GetField("stoneAccounts"));
        Assert.Equal("PAY001", aggregator.GetField("paymentProfiles"));
        Assert.Equal("POI001", aggregator.GetField("poiTypes"));
    }

    [Fact]
    public void Process_WithMultipleItems_ShouldAggregateAllFields()
    {
        // Arrange
        var aggregator = new MerchantIdAggregator();
        var items = new List<MerchantIdSummary>
        {
            new()
            {
                Document = "11111111111",
                MerchantId = "MERCH001",
                StoneAccount = "STONE001"
            },
            new()
            {
                Document = "22222222222",
                MerchantId = "MERCH002",
                StoneAccount = "STONE002"
            }
        };

        // Act
        aggregator.Process(items);

        // Assert
        Assert.Equal("11111111111,22222222222", aggregator.GetField("document"));
        Assert.Equal("MERCH001,MERCH002", aggregator.GetField("merchantId"));
        Assert.Equal("STONE001,STONE002", aggregator.GetField("stoneAccounts"));
    }

    [Fact]
    public void Process_WithPartiallyPopulatedItems_ShouldOnlyAggregateNonEmptyValues()
    {
        // Arrange
        var aggregator = new MerchantIdAggregator();
        var items = new List<MerchantIdSummary>
        {
            new() { Document = "11111111111", MerchantId = "MERCH001" },
            new() { Document = null, MerchantId = "MERCH002" },
            new() { Document = "33333333333", MerchantId = null }
        };

        // Act
        aggregator.Process(items);

        // Assert
        Assert.Equal("11111111111,33333333333", aggregator.GetField("document"));
        Assert.Equal("MERCH001,MERCH002", aggregator.GetField("merchantId"));
    }

    [Fact]
    public void Process_WithEmptyList_ShouldReturnNullForAllFields()
    {
        // Arrange
        var aggregator = new MerchantIdAggregator();
        var items = new List<MerchantIdSummary>();

        // Act
        aggregator.Process(items);

        // Assert
        Assert.Null(aggregator.GetField("document"));
        Assert.Null(aggregator.GetField("affiliationCodes"));
        Assert.Null(aggregator.GetField("accountIds"));
        Assert.Null(aggregator.GetField("merchantId"));
        Assert.Null(aggregator.GetField("organizations"));
        Assert.Null(aggregator.GetField("stoneAccounts"));
        Assert.Null(aggregator.GetField("paymentProfiles"));
        Assert.Null(aggregator.GetField("poiTypes"));
    }

    [Fact]
    public void GetField_WithInvalidKey_ShouldReturnNull()
    {
        // Arrange
        var aggregator = new MerchantIdAggregator();
        var items = new List<MerchantIdSummary>
        {
            new() { Document = "12345678900" }
        };
        aggregator.Process(items);

        // Act
        var result = aggregator.GetField("invalidKey");

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public void GetField_BeforeProcess_ShouldReturnNull()
    {
        // Arrange
        var aggregator = new MerchantIdAggregator();

        // Act
        var result = aggregator.GetField("document");

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public void Process_WithAllFieldsPopulated_ShouldPreserveOrder()
    {
        // Arrange
        var aggregator = new MerchantIdAggregator();
        var items = new List<MerchantIdSummary>
        {
            new()
            {
                Document = "AAA",
                AffiliationCodes = "BBB",
                AccountIds = "CCC"
            },
            new()
            {
                Document = "DDD",
                AffiliationCodes = "EEE",
                AccountIds = "FFF"
            }
        };

        // Act
        aggregator.Process(items);

        // Assert
        Assert.Equal("AAA,DDD", aggregator.GetField("document"));
        Assert.Equal("BBB,EEE", aggregator.GetField("affiliationCodes"));
        Assert.Equal("CCC,FFF", aggregator.GetField("accountIds"));
    }

    [Fact]
    public void Process_WithLargeNumberOfItems_ShouldHandleCorrectly()
    {
        // Arrange
        var aggregator = new MerchantIdAggregator();
        var items = Enumerable.Range(1, 100)
            .Select(i => new MerchantIdSummary { Document = $"DOC{i:D3}" })
            .ToList();

        // Act
        aggregator.Process(items);
        var result = aggregator.GetField("document");

        // Assert
        Assert.NotNull(result);
        var documents = result.Split(',');
        Assert.Equal(100, documents.Length);
        Assert.Equal("DOC001", documents[0]);
        Assert.Equal("DOC100", documents[99]);
    }

    [Fact]
    public void Process_WithAllNullValues_ShouldReturnNull()
    {
        // Arrange
        var aggregator = new MerchantIdAggregator();
        var items = new List<MerchantIdSummary>
        {
            new() { Document = null },
            new() { Document = null },
            new() { Document = null }
        };

        // Act
        aggregator.Process(items);
        var result = aggregator.GetField("document");

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public void Process_CalledMultipleTimes_ShouldNotAccumulateData()
    {
        // Arrange
        var aggregator = new MerchantIdAggregator();
        var firstRequest = new List<MerchantIdSummary>
        {
            new() { Document = "11111111111", MerchantId = "MERCH001" }
        };
        var secondRequest = new List<MerchantIdSummary>
        {
            new() { Document = "22222222222", MerchantId = "MERCH002" }
        };

        // Act
        aggregator.Process(firstRequest);
        aggregator.Process(secondRequest);

        // Assert - apenas dados da última chamada estão presentes
        var documents = aggregator.GetField("document");
        var merchantIds = aggregator.GetField("merchantId");
        Assert.Equal("22222222222", documents);
        Assert.Equal("MERCH002", merchantIds);
        Assert.DoesNotContain("11111111111", documents!);
        Assert.DoesNotContain("MERCH001", merchantIds!);
    }

    [Fact]
    public void Process_NewInstancePerRequest_ShouldNotAccumulateData()
    {
        // Arrange
        var firstItems = new List<MerchantIdSummary>
        {
            new() { Document = "11111111111", MerchantId = "MERCH001" }
        };
        var secondItems = new List<MerchantIdSummary>
        {
            new() { Document = "22222222222", MerchantId = "MERCH002" }
        };

        // Act - simula o comportamento correto com Transient: nova instância por requisição
        var firstAggregator = new MerchantIdAggregator();
        firstAggregator.Process(firstItems);

        var secondAggregator = new MerchantIdAggregator();
        secondAggregator.Process(secondItems);

        // Assert - cada instância contém apenas seus próprios dados
        Assert.Equal("11111111111", firstAggregator.GetField("document"));
        Assert.Equal("MERCH001", firstAggregator.GetField("merchantId"));
        Assert.DoesNotContain("22222222222", firstAggregator.GetField("document")!);

        Assert.Equal("22222222222", secondAggregator.GetField("document"));
        Assert.Equal("MERCH002", secondAggregator.GetField("merchantId"));
        Assert.DoesNotContain("11111111111", secondAggregator.GetField("document")!);
    }

    [Fact]
    public void Process_ReusingInstance_ShouldNotAccumulateAcrossAllFields()
    {
        // Arrange
        var aggregator = new MerchantIdAggregator();
        var firstRequest = new List<MerchantIdSummary>
        {
            new()
            {
                Document = "DOC1",
                AffiliationCodes = "AFF1",
                AccountIds = "ACC1",
                MerchantId = "MERCH1",
                Organization = "ORG1",
                StoneAccount = "STONE1",
                PaymentProfileIds = "PAY1",
                PointOfInteractionTypes = "POI1"
            }
        };
        var secondRequest = new List<MerchantIdSummary>
        {
            new()
            {
                Document = "DOC2",
                AffiliationCodes = "AFF2",
                AccountIds = "ACC2",
                MerchantId = "MERCH2",
                Organization = "ORG2",
                StoneAccount = "STONE2",
                PaymentProfileIds = "PAY2",
                PointOfInteractionTypes = "POI2"
            }
        };

        // Act
        aggregator.Process(firstRequest);
        aggregator.Process(secondRequest);

        // Assert - apenas dados da última chamada estão presentes em todos os campos
        Assert.Equal("DOC2", aggregator.GetField("document"));
        Assert.Equal("AFF2", aggregator.GetField("affiliationCodes"));
        Assert.Equal("ACC2", aggregator.GetField("accountIds"));
        Assert.Equal("MERCH2", aggregator.GetField("merchantId"));
        Assert.Equal("ORG2", aggregator.GetField("organizations"));
        Assert.Equal("STONE2", aggregator.GetField("stoneAccounts"));
        Assert.Equal("PAY2", aggregator.GetField("paymentProfiles"));
        Assert.Equal("POI2", aggregator.GetField("poiTypes"));
    }

    [Fact]
    public void Process_ReusingInstance_ShouldOnlyRetainLastProcessedData()
    {
        // Arrange
        var aggregator = new MerchantIdAggregator();

        // Act - simula 3 requisições reusando a mesma instância
        for (var i = 1; i <= 3; i++)
        {
            aggregator.Process(
            [
                new MerchantIdSummary { Document = $"DOC{i}" }
            ]);
        }

        // Assert - apenas dados da última chamada estão presentes
        var result = aggregator.GetField("document");
        Assert.NotNull(result);
        Assert.Equal("DOC3", result);
        Assert.DoesNotContain("DOC1", result);
        Assert.DoesNotContain("DOC2", result);
    }
}

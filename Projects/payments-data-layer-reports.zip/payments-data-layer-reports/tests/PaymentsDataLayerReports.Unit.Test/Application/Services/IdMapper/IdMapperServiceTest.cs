using NSubstitute;
using PaymentsDataLayerReports.Application.Infra.LegacyIdSystemAPI;
using PaymentsDataLayerReports.Application.Infra.LegacyIdSystemAPI.Models;
using PaymentsDataLayerReports.Application.Services.IdMapper;

namespace PaymentsDataLayerReports.Unit.Test.Application.Services.IdMapper;

public class IdMapperServiceTest
{
    private readonly ILegacyIdSystemAPIClient _legacyIdSystemAPIClient;
    private readonly IdMapperService _idMapperService;

    public IdMapperServiceTest()
    {
        _legacyIdSystemAPIClient = Substitute.For<ILegacyIdSystemAPIClient>();
        _idMapperService = new IdMapperService(_legacyIdSystemAPIClient);
    }

    [Fact]
    public async Task Map_WithOrganizations_ShouldReturnOriginalRequestWithoutCallingAPI()
    {
        // Arrange
        var stoneAccounts = "123456";
        var documents = "12345678901";
        var organizations = "stone";
        var affiliationCodes = "AFF001";
        var accountIds = "ACC001";
        var merchantId = "MERCH001";
        var paymentProfileIds = "STONE";
        var pointOfInteractionTypes = "pos";

        // Act
        var result = await _idMapperService.Map(
            stoneAccounts,
            documents,
            organizations,
            affiliationCodes,
            accountIds,
            merchantId,
            paymentProfileIds,
            pointOfInteractionTypes,
            CancellationToken.None
        );

        // Assert
        Assert.NotNull(result);
        Assert.Single(result);
        var summary = result[0];
        Assert.Equal(documents, summary.Document);
        Assert.Equal(organizations, summary.Organization);
        Assert.Equal(affiliationCodes, summary.AffiliationCodes);
        Assert.Equal(accountIds, summary.AccountIds);
        Assert.Equal(merchantId, summary.MerchantId);
        Assert.Equal(paymentProfileIds, summary.PaymentProfileIds);
        Assert.Equal(pointOfInteractionTypes, summary.PointOfInteractionTypes);

        await _legacyIdSystemAPIClient.DidNotReceive().GetClients(
            Arg.Any<LegacyIdSystemRequest>(),
            Arg.Any<CancellationToken>()
        );
    }

    [Fact]
    public async Task Map_WithoutOrganizations_ShouldCallAPIAndReturnSummaries()
    {
        // Arrange
        var stoneAccounts = "123456";
        var documents = "12345678901";
        var apiResponse = new List<LegacyIdSystemResponse>
        {
            new()
            {
                Document = "12345678901",
                StoneAccount = "123456",
                Organization = "stone",
                MerchantId = "MERCH001",
                AffiliationKey = "AFF001",
                AffiliationCode = "CODE001",
                PaymentProfile = "STONE",
                PoiType = "POS",
                AccountId = "ACC001"
            }
        };

        _legacyIdSystemAPIClient
            .GetClients(Arg.Any<LegacyIdSystemRequest>(), Arg.Any<CancellationToken>())
            .Returns(apiResponse);

        // Act
        var result = await _idMapperService.Map(
            stoneAccounts,
            documents,
            null,
            null,
            null,
            null,
            null,
            null,
            CancellationToken.None
        );

        // Assert
        Assert.NotNull(result);
        Assert.Single(result);

        var summary = result[0];
        Assert.Equal("12345678901", summary.Document);
        Assert.Equal("123456", summary.StoneAccount);
        Assert.Equal("pagarme", summary.Organization);
        Assert.Equal("MERCH001", summary.MerchantId);
    }

    [Fact]
    public async Task Map_WhenAPIReturnsNull_ShouldThrowArgumentNullException()
    {
        // Arrange
        _legacyIdSystemAPIClient
            .GetClients(Arg.Any<LegacyIdSystemRequest>(), Arg.Any<CancellationToken>())
            .Returns((List<LegacyIdSystemResponse>?)null);

        // Act & Assert
        await Assert.ThrowsAsync<ArgumentNullException>(async () =>
            await _idMapperService.Map(
                "123456",
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                CancellationToken.None
            )
        );
    }

    [Fact]
    public async Task Map_WhenAPIReturnsEmptyList_ShouldThrowArgumentNullException()
    {
        // Arrange
        _legacyIdSystemAPIClient
            .GetClients(Arg.Any<LegacyIdSystemRequest>(), Arg.Any<CancellationToken>())
            .Returns(new List<LegacyIdSystemResponse>());

        // Act & Assert
        await Assert.ThrowsAsync<ArgumentNullException>(async () =>
            await _idMapperService.Map(
                "123456",
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                CancellationToken.None
            )
        );
    }

    [Fact]
    public async Task Map_WithPointOfInteractionTypes_ShouldConvertToFieldNames()
    {
        // Arrange
        var pointOfInteractionTypes = "pos,link,ecommerce";
        var apiResponse = new List<LegacyIdSystemResponse>
        {
            new()
            {
                Document = "12345678901",
                StoneAccount = "123456",
                Organization = "stone",
                MerchantId = "MERCH001",
                PoiType = "POS"
            }
        };

        _legacyIdSystemAPIClient
            .GetClients(Arg.Any<LegacyIdSystemRequest>(), Arg.Any<CancellationToken>())
            .Returns(apiResponse);

        // Act
        await _idMapperService.Map(
            "123456",
            null,
            null,
            null,
            null,
            null,
            null,
            pointOfInteractionTypes,
            CancellationToken.None
        );

        // Assert
        await _legacyIdSystemAPIClient.Received(1).GetClients(
            Arg.Is<LegacyIdSystemRequest>(r =>
                r.PoiType != null &&
                r.PoiType.Contains("POS") &&
                r.PoiType.Contains("Link") &&
                r.PoiType.Contains("Ecommerce")
            ),
            Arg.Any<CancellationToken>()
        );
    }

    [Fact]
    public async Task Map_WithPoiTypeConversion_ShouldConvertBackToNames()
    {
        // Arrange
        var apiResponse = new List<LegacyIdSystemResponse>
        {
            new()
            {
                Document = "12345678901",
                StoneAccount = "123456",
                Organization = "stone",
                MerchantId = "MERCH001",
                PoiType = "POS"
            }
        };

        _legacyIdSystemAPIClient
            .GetClients(Arg.Any<LegacyIdSystemRequest>(), Arg.Any<CancellationToken>())
            .Returns(apiResponse);

        // Act
        var result = await _idMapperService.Map(
            "123456",
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            CancellationToken.None
        );

        // Assert
        Assert.NotNull(result);
        var summary = result[0];
        Assert.Equal("pos", summary.PointOfInteractionTypes);
    }

    [Fact]
    public async Task Map_WithMultipleClientsForSameGroup_ShouldGroupAndConcatenateFields()
    {
        // Arrange
        var apiResponse = new List<LegacyIdSystemResponse>
        {
            new()
            {
                Document = "12345678901",
                StoneAccount = "123456",
                Organization = "stone",
                MerchantId = "MERCH001",
                AffiliationKey = "AFF001",
                AffiliationCode = "CODE001",
                PaymentProfile = "STONE",
                PoiType = "POS",
                AccountId = "ACC001"
            },
            new()
            {
                Document = "12345678901",
                StoneAccount = "123456",
                Organization = "stone",
                MerchantId = "MERCH001",
                AffiliationKey = "AFF002",
                AffiliationCode = "CODE002",
                PaymentProfile = "TON",
                PoiType = "Link",
                AccountId = "ACC002"
            }
        };

        _legacyIdSystemAPIClient
            .GetClients(Arg.Any<LegacyIdSystemRequest>(), Arg.Any<CancellationToken>())
            .Returns(apiResponse);

        // Act
        var result = await _idMapperService.Map(
            "123456",
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            CancellationToken.None
        );

        // Assert
        Assert.NotNull(result);
        Assert.Single(result);

        var summary = result[0];
        Assert.Equal("12345678901", summary.Document);
        Assert.Equal("123456", summary.StoneAccount);
        Assert.Equal("pagarme", summary.Organization);
        Assert.Equal("MERCH001", summary.MerchantId);
        Assert.Contains("AFF001", summary.AffiliationKeys);
        Assert.Contains("AFF002", summary.AffiliationKeys);
        Assert.Contains("CODE001", summary.AffiliationCodes);
        Assert.Contains("CODE002", summary.AffiliationCodes);
        Assert.Contains("STONE", summary.PaymentProfileIds);
        Assert.Contains("TON", summary.PaymentProfileIds);
        Assert.Contains("ACC001", summary.AccountIds);
        Assert.Contains("ACC002", summary.AccountIds);
    }

    [Fact]
    public async Task Map_WithMultipleDocuments_ShouldReturnMultipleSummaries()
    {
        // Arrange
        var apiResponse = new List<LegacyIdSystemResponse>
        {
            new()
            {
                Document = "12345678901",
                StoneAccount = "123456",
                Organization = "stone",
                MerchantId = "MERCH001"
            },
            new()
            {
                Document = "98765432109",
                StoneAccount = "789012",
                Organization = "ton",
                MerchantId = "MERCH002"
            }
        };

        _legacyIdSystemAPIClient
            .GetClients(Arg.Any<LegacyIdSystemRequest>(), Arg.Any<CancellationToken>())
            .Returns(apiResponse);

        // Act
        var result = await _idMapperService.Map(
            "123456,789012",
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            CancellationToken.None
        );

        // Assert
        Assert.NotNull(result);
        Assert.Equal(2, result.Count);
        Assert.Contains(result, s => s.Document == "12345678901");
        Assert.Contains(result, s => s.Document == "98765432109");
    }

    [Fact]
    public async Task Map_WithPagarmeClients_ShouldApplyChangeOrganizationTransformation()
    {
        // Arrange
        var apiResponse = new List<LegacyIdSystemResponse>
        {
            new()
            {
                Document = "12345678901",
                StoneAccount = "123456",
                Organization = "stone",
                MerchantId = "MERCH001",
                AccountId = "ACC001"
            }
        };

        _legacyIdSystemAPIClient
            .GetClients(Arg.Any<LegacyIdSystemRequest>(), Arg.Any<CancellationToken>())
            .Returns(apiResponse);

        // Act
        var result = await _idMapperService.Map(
            "123456",
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            CancellationToken.None
        );

        // Assert
        Assert.NotNull(result);
        var summary = result[0];
        Assert.Equal("pagarme", summary.Organization);
    }

    [Fact]
    public async Task Map_WithLinkAndStonePoiTypes_ShouldRemoveLinkWhenStone()
    {
        // Arrange
        var apiResponse = new List<LegacyIdSystemResponse>
        {
            new()
            {
                Document = "12345678901",
                StoneAccount = "123456",
                Organization = "stone",
                MerchantId = "MERCH001",
                PoiType = "POS",
                AccountId = null
            },
            new()
            {
                Document = "12345678901",
                StoneAccount = "123456",
                Organization = "pagarme",
                MerchantId = "MERCH002",
                PoiType = "Link",
                AccountId = "ACC001"
            }
        };

        _legacyIdSystemAPIClient
            .GetClients(Arg.Any<LegacyIdSystemRequest>(), Arg.Any<CancellationToken>())
            .Returns(apiResponse);

        // Act
        var result = await _idMapperService.Map(
            "123456",
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            CancellationToken.None
        );

        // Assert
        Assert.NotNull(result);
        Assert.Single(result);
        Assert.DoesNotContain(result, s => s.PointOfInteractionTypes == "link");
    }

    [Fact]
    public async Task Map_WithGatewayOnStone_ShouldRemoveGatewayClients()
    {
        // Arrange
        var apiResponse = new List<LegacyIdSystemResponse>
        {
            new()
            {
                Document = "12345678901",
                StoneAccount = "123456",
                Organization = "stone",
                MerchantId = "MERCH001",
                PoiType = "POS",
                AccountId = null
            },
            new()
            {
                Document = "12345678901",
                StoneAccount = "123456",
                Organization = "pagarme",
                MerchantId = "MERCH002",
                PoiType = "Ecommerce",
                AccountId = "ACC001"
            }
        };

        _legacyIdSystemAPIClient
            .GetClients(Arg.Any<LegacyIdSystemRequest>(), Arg.Any<CancellationToken>())
            .Returns(apiResponse);

        // Act
        var result = await _idMapperService.Map(
            "123456",
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            CancellationToken.None
        );

        // Assert
        Assert.NotNull(result);
        Assert.Single(result);
        Assert.All(result, s => Assert.NotNull(s.AccountIds));
    }

    [Fact]
    public async Task Map_WithAllParameters_ShouldPassCorrectRequestToAPI()
    {
        // Arrange
        var stoneAccounts = "123456,789012";
        var documents = "12345678901,98765432109";
        var paymentProfileIds = "STONE,TON";
        var pointOfInteractionTypes = "pos,link";

        var apiResponse = new List<LegacyIdSystemResponse>
        {
            new()
            {
                Document = "12345678901",
                StoneAccount = "123456",
                Organization = "stone",
                MerchantId = "MERCH001"
            }
        };

        _legacyIdSystemAPIClient
            .GetClients(Arg.Any<LegacyIdSystemRequest>(), Arg.Any<CancellationToken>())
            .Returns(apiResponse);

        // Act
        await _idMapperService.Map(
            stoneAccounts,
            documents,
            null,
            null,
            null,
            null,
            paymentProfileIds,
            pointOfInteractionTypes,
            CancellationToken.None
        );

        // Assert
        await _legacyIdSystemAPIClient.Received(1).GetClients(
            Arg.Is<LegacyIdSystemRequest>(r =>
                r.Document != null && r.Document.Count() == 2 &&
                r.StoneAccount != null && r.StoneAccount.Count() == 2 &&
                r.PaymentProfile != null && r.PaymentProfile.Count() == 2 &&
                r.PoiType != null && r.PoiType.Count() == 2
            ),
            Arg.Any<CancellationToken>()
        );
    }

    [Fact]
    public async Task Map_WithDistinctAffiliationKeys_ShouldConcatenateDistinctValues()
    {
        // Arrange
        var apiResponse = new List<LegacyIdSystemResponse>
        {
            new()
            {
                Document = "12345678901",
                StoneAccount = "123456",
                Organization = "stone",
                MerchantId = "MERCH001",
                AffiliationKey = "AFF001"
            },
            new()
            {
                Document = "12345678901",
                StoneAccount = "123456",
                Organization = "stone",
                MerchantId = "MERCH001",
                AffiliationKey = "AFF001"
            },
            new()
            {
                Document = "12345678901",
                StoneAccount = "123456",
                Organization = "stone",
                MerchantId = "MERCH001",
                AffiliationKey = "AFF002"
            }
        };

        _legacyIdSystemAPIClient
            .GetClients(Arg.Any<LegacyIdSystemRequest>(), Arg.Any<CancellationToken>())
            .Returns(apiResponse);

        // Act
        var result = await _idMapperService.Map(
            "123456",
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            CancellationToken.None
        );

        // Assert
        Assert.NotNull(result);
        Assert.Single(result);

        var summary = result[0];
        var keys = summary.AffiliationKeys?.Split(',');
        Assert.NotNull(keys);
        Assert.Equal(2, keys.Length);
        Assert.Contains("AFF001", keys);
        Assert.Contains("AFF002", keys);
    }

    [Fact]
    public async Task Map_WithNullOptionalFields_ShouldHandleGracefully()
    {
        // Arrange
        var apiResponse = new List<LegacyIdSystemResponse>
        {
            new()
            {
                Document = "12345678901",
                StoneAccount = "123456",
                Organization = "stone",
                MerchantId = "MERCH001",
                AffiliationKey = null,
                AffiliationCode = null,
                PaymentProfile = null,
                PoiType = null,
                AccountId = null
            }
        };

        _legacyIdSystemAPIClient
            .GetClients(Arg.Any<LegacyIdSystemRequest>(), Arg.Any<CancellationToken>())
            .Returns(apiResponse);

        // Act
        var result = await _idMapperService.Map(
            "123456",
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            CancellationToken.None
        );

        // Assert
        Assert.NotNull(result);
        Assert.Single(result);

        var summary = result[0];
        Assert.Equal("12345678901", summary.Document);
        Assert.Equal("123456", summary.StoneAccount);
        Assert.Equal("MERCH001", summary.MerchantId);
    }

    [Fact]
    public async Task Map_WithEmptyStrings_ShouldTreatAsNull()
    {
        // Arrange
        var apiResponse = new List<LegacyIdSystemResponse>
        {
            new()
            {
                Document = "12345678901",
                StoneAccount = "123456",
                Organization = "stone",
                MerchantId = "MERCH001"
            }
        };

        _legacyIdSystemAPIClient
            .GetClients(Arg.Any<LegacyIdSystemRequest>(), Arg.Any<CancellationToken>())
            .Returns(apiResponse);

        // Act
        var result = await _idMapperService.Map(
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            CancellationToken.None
        );

        // Assert
        Assert.NotNull(result);
    }

    [Fact]
    public async Task Map_WithWhitespaceOrganizations_ShouldCallAPI()
    {
        // Arrange
        var apiResponse = new List<LegacyIdSystemResponse>
        {
            new()
            {
                Document = "12345678901",
                StoneAccount = "123456",
                Organization = "stone",
                MerchantId = "MERCH001"
            }
        };

        _legacyIdSystemAPIClient
            .GetClients(Arg.Any<LegacyIdSystemRequest>(), Arg.Any<CancellationToken>())
            .Returns(apiResponse);

        // Act
        var result = await _idMapperService.Map(
            "123456",
            null,
            "   ",
            null,
            null,
            null,
            null,
            null,
            CancellationToken.None
        );

        // Assert
        Assert.NotNull(result);
        await _legacyIdSystemAPIClient.Received(1).GetClients(
            Arg.Any<LegacyIdSystemRequest>(),
            Arg.Any<CancellationToken>()
        );
    }
}

using PaymentsDataLayerReports.Application.Services.IdMapper;

namespace PaymentsDataLayerReports.Unit.Test.Application.Services.IdMapper;

public class FieldExtractorTests
{
    [Fact]
    public void Extract_WithValidValue_ShouldAddToList()
    {
        // Arrange
        var extractor = new FieldExtractor(x => x.Document);
        var item = new MerchantIdSummary { Document = "12345678900" };

        // Act
        extractor.Extract(item);
        var result = extractor.GetResult();

        // Assert
        Assert.Equal("12345678900", result);
    }

    [Fact]
    public void Extract_WithMultipleValues_ShouldJoinWithComma()
    {
        // Arrange
        var extractor = new FieldExtractor(x => x.Document);
        var items = new[]
        {
            new MerchantIdSummary { Document = "11111111111" },
            new MerchantIdSummary { Document = "22222222222" },
            new MerchantIdSummary { Document = "33333333333" }
        };

        // Act
        foreach (var item in items)
            extractor.Extract(item);
        var result = extractor.GetResult();

        // Assert
        Assert.Equal("11111111111,22222222222,33333333333", result);
    }

    [Fact]
    public void Extract_WithNullValue_ShouldSkip()
    {
        // Arrange
        var extractor = new FieldExtractor(x => x.Document);
        var item = new MerchantIdSummary { Document = null };

        // Act
        extractor.Extract(item);
        var result = extractor.GetResult();

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public void Extract_WithEmptyString_ShouldSkip()
    {
        // Arrange
        var extractor = new FieldExtractor(x => x.Document);
        var item = new MerchantIdSummary { Document = "" };

        // Act
        extractor.Extract(item);
        var result = extractor.GetResult();

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public void Extract_WithWhitespace_ShouldSkip()
    {
        // Arrange
        var extractor = new FieldExtractor(x => x.Document);
        var item = new MerchantIdSummary { Document = "   " };

        // Act
        extractor.Extract(item);
        var result = extractor.GetResult();

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public void Extract_WithMixedValidAndInvalidValues_ShouldOnlyIncludeValid()
    {
        // Arrange
        var extractor = new FieldExtractor(x => x.Document);
        var items = new[]
        {
            new MerchantIdSummary { Document = "11111111111" },
            new MerchantIdSummary { Document = null },
            new MerchantIdSummary { Document = "22222222222" },
            new MerchantIdSummary { Document = "" },
            new MerchantIdSummary { Document = "33333333333" }
        };

        // Act
        foreach (var item in items)
            extractor.Extract(item);
        var result = extractor.GetResult();

        // Assert
        Assert.Equal("11111111111,22222222222,33333333333", result);
    }

    [Fact]
    public void GetResult_WhenNoValuesExtracted_ShouldReturnNull()
    {
        // Arrange
        var extractor = new FieldExtractor(x => x.Document);

        // Act
        var result = extractor.GetResult();

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public void Extract_WithMultipleValues_ShouldJoinWithCommaWithoutDuplicates()
    {
        // Arrange
        var extractor = new FieldExtractor(x => x.Document);
        var items = new[]
        {
            new MerchantIdSummary { Document = "11111111111" },
            new MerchantIdSummary { Document = "22222222222" },
            new MerchantIdSummary { Document = "22222222222" },
            new MerchantIdSummary { Document = "33333333333" }
        };

        // Act
        foreach (var item in items)
            extractor.Extract(item);
        var result = extractor.GetResult();

        // Assert
        Assert.Equal("11111111111,22222222222,33333333333", result);
    }

    [Fact]
    public void Clear_AfterExtractingValues_ShouldReturnNullOnGetResult()
    {
        // Arrange
        var extractor = new FieldExtractor(x => x.Document);
        extractor.Extract(new MerchantIdSummary { Document = "11111111111" });
        extractor.Extract(new MerchantIdSummary { Document = "22222222222" });

        // Act
        extractor.Clear();
        var result = extractor.GetResult();

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public void Clear_AfterClearing_ShouldAllowNewExtractions()
    {
        // Arrange
        var extractor = new FieldExtractor(x => x.Document);
        extractor.Extract(new MerchantIdSummary { Document = "11111111111" });
        extractor.Clear();

        // Act
        extractor.Extract(new MerchantIdSummary { Document = "99999999999" });
        var result = extractor.GetResult();

        // Assert
        Assert.Equal("99999999999", result);
    }
}

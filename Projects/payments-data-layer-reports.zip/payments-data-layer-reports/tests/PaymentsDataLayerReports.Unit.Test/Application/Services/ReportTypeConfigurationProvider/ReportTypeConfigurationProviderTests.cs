using PaymentsDataLayerReports.Application.Enums;
using ConfigProvider = PaymentsDataLayerReports.Application.Services.ReportTypeConfiguration.ReportTypeConfigurationProvider;

namespace PaymentsDataLayerReports.Unit.Test.Application.Services.ReportTypeConfigurationProvider;

public class ReportTypeConfigurationProviderTests
{
    #region GetConfiguration Tests

    [Theory]
    [InlineData("sales_stone")]
    [InlineData("sales_ton")]
    [InlineData("orders")]
    [InlineData("receivables")]
    [InlineData("charges_list")]
    [InlineData("charges_events")]
    public void GetConfiguration_WithKnownReportType_ShouldReturnConfiguration(string reportType)
    {
        // Act
        var result = ConfigProvider.GetConfiguration(reportType);

        // Assert
        Assert.NotNull(result);
    }

    [Fact]
    public void GetConfiguration_WithUnknownReportType_ShouldReturnNull()
    {
        // Act
        var result = ConfigProvider.GetConfiguration("unknown_type");

        // Assert
        Assert.Null(result);
    }

    [Theory]
    [InlineData("SALES_STONE")]
    [InlineData("Sales_stonE")]
    [InlineData("sAlEs_StonE")]
    public void GetConfiguration_ShouldBeCaseInsensitive(string reportType)
    {
        // Act
        var result = ConfigProvider.GetConfiguration(reportType);

        // Assert
        Assert.NotNull(result);
    }

    #endregion

    #region GetCsvSeparator Tests

    [Theory]
    [InlineData("sales_stone", CsvSeparatorEnum.Semicolon)]
    [InlineData("sales_ton", CsvSeparatorEnum.Semicolon)]
    [InlineData("orders", CsvSeparatorEnum.Semicolon)]
    [InlineData("receivables", CsvSeparatorEnum.Semicolon)]
    [InlineData("charges_list", CsvSeparatorEnum.Comma)]
    [InlineData("charges_events", CsvSeparatorEnum.Comma)]
    public void GetCsvSeparator_ShouldReturnCorrectSeparator(string reportType, CsvSeparatorEnum expectedSeparator)
    {
        // Act
        var result = ConfigProvider.GetCsvSeparator(reportType);

        // Assert
        Assert.Equal(expectedSeparator, result);
    }

    [Fact]
    public void GetCsvSeparator_WithUnknownReportType_ShouldReturnCommaAsDefault()
    {
        // Act
        var result = ConfigProvider.GetCsvSeparator("unknown_type");

        // Assert
        Assert.Equal(CsvSeparatorEnum.Comma, result);
    }

    #endregion

    #region GetSeparatorChar Tests

    [Theory]
    [InlineData("sales_stone", ';')]
    [InlineData("sales_ton", ';')]
    [InlineData("orders", ';')]
    [InlineData("receivables", ';')]
    [InlineData("charges_list", ',')]
    [InlineData("charges_events", ',')]
    public void GetSeparatorChar_ShouldReturnCorrectChar(string reportType, char expectedChar)
    {
        // Act
        var result = ConfigProvider.GetSeparatorChar(reportType);

        // Assert
        Assert.Equal(expectedChar, result);
    }

    [Fact]
    public void GetSeparatorChar_WithUnknownReportType_ShouldReturnCommaAsDefault()
    {
        // Act
        var result = ConfigProvider.GetSeparatorChar("unknown_type");

        // Assert
        Assert.Equal(',', result);
    }

    #endregion

    #region IsFileFormatSupported Tests

    [Theory]
    [InlineData("sales_stone", "csv", true)]
    [InlineData("orders", "csv", true)]
    [InlineData("receivables", "csv", true)]
    [InlineData("charges_list", "csv", true)]
    [InlineData("charges_events", "csv", true)]
    public void IsFileFormatSupported_CsvFormat_ShouldAlwaysReturnTrue(string reportType, string fileFormat, bool expected)
    {
        // Act
        var result = ConfigProvider.IsFileFormatSupported(reportType, fileFormat);

        // Assert
        Assert.Equal(expected, result);
    }

    [Theory]
    [InlineData("sales_stone", "xlsx", true)]
    [InlineData("sales_ton", "xlsx", true)]
    [InlineData("orders", "xlsx", true)]
    [InlineData("receivables", "xlsx", true)]
    [InlineData("charges_list", "xlsx", false)]
    [InlineData("charges_events", "xlsx", false)]
    public void IsFileFormatSupported_XlsxFormat_ShouldReturnBasedOnConfiguration(string reportType, string fileFormat, bool expected)
    {
        // Act
        var result = ConfigProvider.IsFileFormatSupported(reportType, fileFormat);

        // Assert
        Assert.Equal(expected, result);
    }

    [Theory]
    [InlineData("CSV")]
    [InlineData("Csv")]
    [InlineData("XLSX")]
    [InlineData("Xlsx")]
    public void IsFileFormatSupported_ShouldBeCaseInsensitive(string fileFormat)
    {
        // Act
        var result = ConfigProvider.IsFileFormatSupported("receivables", fileFormat);

        // Assert
        Assert.True(result);
    }

    [Fact]
    public void IsFileFormatSupported_WithUnknownFormat_ShouldReturnFalse()
    {
        // Act
        var result = ConfigProvider.IsFileFormatSupported("receivables", "pdf");

        // Assert
        Assert.False(result);
    }

    #endregion

    #region SupportsXlsx Tests

    [Theory]
    [InlineData("sales_stone", true)]
    [InlineData("sales_ton", true)]
    [InlineData("orders", true)]
    [InlineData("receivables", true)]
    [InlineData("receivables_legacy", true)]
    [InlineData("sales", true)]
    [InlineData("charges_list", false)]
    [InlineData("charges_events", false)]
    public void SupportsXlsx_ShouldReturnCorrectValue(string reportType, bool expected)
    {
        // Act
        var result = ConfigProvider.SupportsXlsx(reportType);

        // Assert
        Assert.Equal(expected, result);
    }

    [Fact]
    public void SupportsXlsx_WithUnknownReportType_ShouldReturnFalse()
    {
        // Act
        var result = ConfigProvider.SupportsXlsx("unknown_type");

        // Assert
        Assert.False(result);
    }

    #endregion

    #region UsesOneStoneLayout Tests

    [Theory]
    [InlineData("receivables", true)]
    [InlineData("RECEIVABLES", true)]
    [InlineData("Receivables", true)]
    [InlineData("receivables_legacy", false)]
    [InlineData("sales", false)]
    [InlineData("sales_stone", false)]
    [InlineData("orders", false)]
    [InlineData("charges_list", false)]
    [InlineData(null, false)]
    public void UsesOneStoneLayout_ShouldReturnTrueOnlyForReceivables(string? reportType, bool expected)
    {
        var result = ConfigProvider.UsesOneStoneLayout(reportType);

        Assert.Equal(expected, result);
    }

    #endregion

    #region ReportSortColumnIndex Tests

    [Theory]
    [InlineData("sales_stone", 2)]
    [InlineData("sales_ton", 1)]
    [InlineData("orders", 999)]
    [InlineData("receivables", 3)]
    [InlineData("receivables_legacy", 4)]
    [InlineData("sales", 6)]
    [InlineData("charges_list", 10)]
    [InlineData("charges_events", 0)]
    public void GetConfiguration_ShouldReturnCorrectSortColumnIndex(string reportType, int expectedIndex)
    {
        // Act
        var result = ConfigProvider.GetConfiguration(reportType);

        // Assert
        Assert.NotNull(result);
        Assert.Equal(expectedIndex, result.ReportSortColumnIndex);
    }

    #endregion
}

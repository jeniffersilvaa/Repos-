using System.Text;
using Microsoft.Extensions.Options;
using NSubstitute;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Sinks;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.StreamWriters;
using PaymentsDataLayerReports.Application.Settings;

namespace PaymentsDataLayerReports.Unit.Test.Application.Services.ReportStreamWriterService;

public class CsvReportStreamWriterTests
{
    [Fact]
    public async Task InitializeAsync_ShouldInitializeSinkWithBucketAndKey()
    {
        // Arrange
        var mockStream = new MemoryStream();
        var sink = Substitute.For<IReportOutputSink>();
        sink.InitializeAsync(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(Task.FromResult<Stream>(mockStream));

        var awsSettings = new AwsSettings { WorkgroupBucket = "bucket-test" };
        var options = Options.Create(awsSettings);
        var writer = new CsvReportStreamWriter(sink, options);

        // Act
        await writer.InitializeAsync("test-report", CancellationToken.None);

        // Assert
        var expectedKey = string.Format(S3ReportsConstants.ReportBasePath, "test-report", FileFormatEnum.Csv.Name);
        await sink.Received(1).InitializeAsync(expectedKey, "bucket-test", Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task WriteRecordAsync_ShouldWriteToStream()
    {
        // Arrange
        var mockStream = new MemoryStream();
        var sink = Substitute.For<IReportOutputSink>();
        sink.InitializeAsync(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(Task.FromResult<Stream>(mockStream));

        var awsSettings = new AwsSettings { WorkgroupBucket = "bucket-test" };
        var options = Options.Create(awsSettings);
        var writer = new CsvReportStreamWriter(sink, options);
        var record = "line1,value1";

        // Act
        await writer.InitializeAsync("test-report", CancellationToken.None);
        await writer.WriteRecordAsync(record, CancellationToken.None);
        await writer.CompleteAsync(CancellationToken.None);

        // Assert
        mockStream.Seek(0, SeekOrigin.Begin);
        using var reader = new StreamReader(mockStream);
        var content = await reader.ReadToEndAsync();
        Assert.Equal("line1,value1\n", content);
    }

    [Fact]
    public async Task WriteHeaderAsync_ShouldWriteToStream()
    {
        // Arrange
        var mockStream = new MemoryStream();
        var sink = Substitute.For<IReportOutputSink>();
        sink.InitializeAsync(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(Task.FromResult<Stream>(mockStream));

        var awsSettings = new AwsSettings { WorkgroupBucket = "bucket-test" };
        var options = Options.Create(awsSettings);
        var writer = new CsvReportStreamWriter(sink, options);
        var header = "col1,col2";

        // Act
        await writer.InitializeAsync("test-report", CancellationToken.None);
        await writer.WriteHeaderAsync(header, CancellationToken.None);
        await writer.CompleteAsync(CancellationToken.None);

        // Assert
        mockStream.Seek(0, SeekOrigin.Begin);
        using var reader = new StreamReader(mockStream);
        var content = await reader.ReadToEndAsync();
        Assert.Equal("col1,col2\n", content);
    }

    [Fact]
    public async Task CompleteAsync_ShouldDelegateToSink()
    {
        // Arrange
        var sink = Substitute.For<IReportOutputSink>();
        var awsSettings = new AwsSettings { WorkgroupBucket = "bucket-test" };
        var options = Options.Create(awsSettings);
        var writer = new CsvReportStreamWriter(sink, options);

        // Act
        await writer.CompleteAsync(CancellationToken.None);

        // Assert
        await sink.Received(1).CompleteAsync(Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task AbortAsync_ShouldDelegateToSink()
    {
        // Arrange
        var sink = Substitute.For<IReportOutputSink>();
        var awsSettings = new AwsSettings { WorkgroupBucket = "bucket-test" };
        var options = Options.Create(awsSettings);
        var writer = new CsvReportStreamWriter(sink, options);

        // Act
        await writer.AbortAsync(CancellationToken.None);

        // Assert
        await sink.Received(1).AbortAsync(Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task WriteRecordAsync_BeforeInitialize_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var sink = Substitute.For<IReportOutputSink>();
        var awsSettings = new AwsSettings { WorkgroupBucket = "bucket-test" };
        var options = Options.Create(awsSettings);
        var writer = new CsvReportStreamWriter(sink, options);

        // Act & Assert
        await Assert.ThrowsAsync<InvalidOperationException>(
            () => writer.WriteRecordAsync("record", CancellationToken.None));
    }
}

using System.Text;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Helpers;
using SpreadCheetah;

namespace PaymentsDataLayerReports.Unit.Test.Application.Services.ReportStreamWriterService.Helpers;

public class CsvParserHelperTests
{
    private readonly StringBuilder _valueBuilder = new();

    [Fact]
    public void ParseRowToBuffer_WithSimpleCsv_ShouldReturnCorrectColumnCount()
    {
        // Arrange
        var csvLine = "value1,value2,value3";
        var targetCells = new DataCell[3];

        // Act
        var columnCount = CsvParserHelper.ParseRowToBuffer(csvLine, ',', targetCells, _valueBuilder);

        // Assert
        Assert.Equal(3, columnCount);
    }

    [Fact]
    public void ParseRowToBuffer_WithSemicolonSeparator_ShouldReturnCorrectColumnCount()
    {
        // Arrange
        var csvLine = "value1;value2;value3";
        var targetCells = new DataCell[3];

        // Act
        var columnCount = CsvParserHelper.ParseRowToBuffer(csvLine, ';', targetCells, _valueBuilder);

        // Assert
        Assert.Equal(3, columnCount);
    }

    [Fact]
    public void ParseRowToBuffer_WithQuotedField_ShouldReturnCorrectColumnCount()
    {
        // Arrange
        var csvLine = "\"quoted value\",normal,\"another quoted\"";
        var targetCells = new DataCell[3];

        // Act
        var columnCount = CsvParserHelper.ParseRowToBuffer(csvLine, ',', targetCells, _valueBuilder);

        // Assert
        Assert.Equal(3, columnCount);
    }

    [Fact]
    public void ParseRowToBuffer_WithEscapedQuotes_ShouldReturnCorrectColumnCount()
    {
        // Arrange
        var csvLine = "\"value with \"\"escaped\"\" quotes\",normal";
        var targetCells = new DataCell[2];

        // Act
        var columnCount = CsvParserHelper.ParseRowToBuffer(csvLine, ',', targetCells, _valueBuilder);

        // Assert
        Assert.Equal(2, columnCount);
    }

    [Fact]
    public void ParseRowToBuffer_WithSeparatorInsideQuotes_ShouldNotSplit()
    {
        // Arrange - comma inside quotes should not split
        var csvLine = "\"value,with,commas\",normal";
        var targetCells = new DataCell[2];

        // Act
        var columnCount = CsvParserHelper.ParseRowToBuffer(csvLine, ',', targetCells, _valueBuilder);

        // Assert - should be 2 columns, not 4
        Assert.Equal(2, columnCount);
    }

    [Fact]
    public void ParseRowToBuffer_WithEmptyFields_ShouldReturnCorrectColumnCount()
    {
        // Arrange
        var csvLine = "value1,,value3";
        var targetCells = new DataCell[3];

        // Act
        var columnCount = CsvParserHelper.ParseRowToBuffer(csvLine, ',', targetCells, _valueBuilder);

        // Assert
        Assert.Equal(3, columnCount);
    }

    [Fact]
    public void ParseRowToBuffer_WithSingleField_ShouldReturnOne()
    {
        // Arrange
        var csvLine = "single_value";
        var targetCells = new DataCell[1];

        // Act
        var columnCount = CsvParserHelper.ParseRowToBuffer(csvLine, ',', targetCells, _valueBuilder);

        // Assert
        Assert.Equal(1, columnCount);
    }

    [Fact]
    public void ParseRowToBuffer_WithMoreColumnsThanBuffer_ShouldThrowException()
    {
        // Arrange
        var csvLine = "value1,value2,value3,value4";
        var targetCells = new DataCell[2]; // Buffer too small

        // Act & Assert
        var exception = Assert.Throws<InvalidOperationException>(() =>
            CsvParserHelper.ParseRowToBuffer(csvLine, ',', targetCells, _valueBuilder));

        Assert.Contains("more columns than the header", exception.Message);
    }

    [Fact]
    public void ParseRowToBuffer_WithEmptyLine_ShouldReturnOneColumn()
    {
        // Arrange
        var csvLine = "";
        var targetCells = new DataCell[1];

        // Act
        var columnCount = CsvParserHelper.ParseRowToBuffer(csvLine, ',', targetCells, _valueBuilder);

        // Assert
        Assert.Equal(1, columnCount);
    }

    [Fact]
    public void ParseRowToBuffer_WithQuotedEmptyField_ShouldReturnCorrectColumnCount()
    {
        // Arrange
        var csvLine = "\"\",value2";
        var targetCells = new DataCell[2];

        // Act
        var columnCount = CsvParserHelper.ParseRowToBuffer(csvLine, ',', targetCells, _valueBuilder);

        // Assert
        Assert.Equal(2, columnCount);
    }

    [Fact]
    public void ParseRowToBuffer_WithNewlineInsideQuotes_ShouldNotSplit()
    {
        // Arrange - newlines inside quotes should not split
        var csvLine = "\"value\nwith\nnewlines\",normal";
        var targetCells = new DataCell[2];

        // Act
        var columnCount = CsvParserHelper.ParseRowToBuffer(csvLine, ',', targetCells, _valueBuilder);

        // Assert - should be 2 columns
        Assert.Equal(2, columnCount);
    }

    [Fact]
    public void ParseRowToBuffer_WithSpecialCharacters_ShouldReturnCorrectColumnCount()
    {
        // Arrange
        var csvLine = "value@#$%,another!&*()";
        var targetCells = new DataCell[2];

        // Act
        var columnCount = CsvParserHelper.ParseRowToBuffer(csvLine, ',', targetCells, _valueBuilder);

        // Assert
        Assert.Equal(2, columnCount);
    }

    [Fact]
    public void ParseRowToBuffer_WithUnicodeCharacters_ShouldReturnCorrectColumnCount()
    {
        // Arrange
        var csvLine = "café,日本語,emoji😀";
        var targetCells = new DataCell[3];

        // Act
        var columnCount = CsvParserHelper.ParseRowToBuffer(csvLine, ',', targetCells, _valueBuilder);

        // Assert
        Assert.Equal(3, columnCount);
    }

    [Fact]
    public void ParseRowToBuffer_WithTrailingComma_ShouldIncludeEmptyLastField()
    {
        // Arrange
        var csvLine = "value1,value2,";
        var targetCells = new DataCell[3];

        // Act
        var columnCount = CsvParserHelper.ParseRowToBuffer(csvLine, ',', targetCells, _valueBuilder);

        // Assert - trailing comma means 3 columns
        Assert.Equal(3, columnCount);
    }

    [Fact]
    public void ParseRowToBuffer_WithLeadingComma_ShouldIncludeEmptyFirstField()
    {
        // Arrange
        var csvLine = ",value2,value3";
        var targetCells = new DataCell[3];

        // Act
        var columnCount = CsvParserHelper.ParseRowToBuffer(csvLine, ',', targetCells, _valueBuilder);

        // Assert - leading comma means 3 columns
        Assert.Equal(3, columnCount);
    }

    [Theory]
    [InlineData("a,b,c", ',', 3)]
    [InlineData("a;b;c", ';', 3)]
    [InlineData("a,b,c,d,e", ',', 5)]
    [InlineData("single", ',', 1)]
    public void ParseRowToBuffer_WithVariousInputs_ShouldReturnExpectedColumnCount(string csvLine, char separator, int expectedCount)
    {
        // Arrange
        var targetCells = new DataCell[expectedCount];

        // Act
        var columnCount = CsvParserHelper.ParseRowToBuffer(csvLine, separator, targetCells, _valueBuilder);

        // Assert
        Assert.Equal(expectedCount, columnCount);
    }

    [Fact]
    public void ParseRowToBuffer_WithComplexQuotedCsv_ShouldHandleCorrectly()
    {
        // Arrange - complex case with quotes, commas inside quotes, and escaped quotes
        var csvLine = "\"Hello, World\",\"Say \"\"Hi\"\"\",normal";
        var targetCells = new DataCell[3];

        // Act
        var columnCount = CsvParserHelper.ParseRowToBuffer(csvLine, ',', targetCells, _valueBuilder);

        // Assert
        Assert.Equal(3, columnCount);
    }
}

using Microsoft.Extensions.DependencyInjection;
using NSubstitute;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Interfaces;

namespace PaymentsDataLayerReports.Unit.Test.Application.Services.ReportStreamWriterService;

public class ReportStreamWriterFactoryTests
{
    [Fact]
    public void Create_WithRegisteredWriter_ShouldReturnWriter()
    {
        // Arrange
        var mockWriter = Substitute.For<IReportStreamWriter<string>>();
        var services = new ServiceCollection();
        services.AddKeyedSingleton<IReportStreamWriter<string>>("csv", mockWriter);
        var serviceProvider = services.BuildServiceProvider();

        var factory = new ReportStreamWriterFactory(serviceProvider);

        // Act
        var result = factory.Create<string>("csv");

        // Assert
        Assert.Same(mockWriter, result);
    }

    [Fact]
    public void Create_WithUpperCaseFormat_ShouldNormalizeToLowerCase()
    {
        // Arrange
        var mockWriter = Substitute.For<IReportStreamWriter<string>>();
        var services = new ServiceCollection();
        services.AddKeyedSingleton<IReportStreamWriter<string>>("csv", mockWriter);
        var serviceProvider = services.BuildServiceProvider();

        var factory = new ReportStreamWriterFactory(serviceProvider);

        // Act
        var result = factory.Create<string>("CSV");

        // Assert
        Assert.Same(mockWriter, result);
    }

    [Fact]
    public void Create_WithMixedCaseFormat_ShouldNormalizeToLowerCase()
    {
        // Arrange
        var mockWriter = Substitute.For<IReportStreamWriter<string>>();
        var services = new ServiceCollection();
        services.AddKeyedSingleton<IReportStreamWriter<string>>("xlsx", mockWriter);
        var serviceProvider = services.BuildServiceProvider();

        var factory = new ReportStreamWriterFactory(serviceProvider);

        // Act
        var result = factory.Create<string>("XlSx");

        // Assert
        Assert.Same(mockWriter, result);
    }

    [Fact]
    public void Create_WithUnregisteredFormat_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var services = new ServiceCollection();
        var serviceProvider = services.BuildServiceProvider();

        var factory = new ReportStreamWriterFactory(serviceProvider);

        // Act & Assert
        var exception = Assert.Throws<InvalidOperationException>(() =>
            factory.Create<string>("unknown"));

        Assert.Contains("unknown", exception.Message);
        Assert.Contains("String", exception.Message);
    }

    [Fact]
    public void Create_WithUnregisteredRecordType_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var mockWriter = Substitute.For<IReportStreamWriter<string>>();
        var services = new ServiceCollection();
        services.AddKeyedSingleton<IReportStreamWriter<string>>("csv", mockWriter);
        var serviceProvider = services.BuildServiceProvider();

        var factory = new ReportStreamWriterFactory(serviceProvider);

        // Act & Assert - Try to get writer for string[] when only string is registered
        var exception = Assert.Throws<InvalidOperationException>(() =>
            factory.Create<string[]>("csv"));

        Assert.Contains("csv", exception.Message);
        Assert.Contains("String[]", exception.Message);
    }

    [Fact]
    public void Create_WithDifferentRecordTypes_ShouldReturnCorrectWriter()
    {
        // Arrange
        var stringWriter = Substitute.For<IReportStreamWriter<string>>();
        var arrayWriter = Substitute.For<IReportStreamWriter<string[]>>();

        var services = new ServiceCollection();
        services.AddKeyedSingleton<IReportStreamWriter<string>>("csv", stringWriter);
        services.AddKeyedSingleton<IReportStreamWriter<string[]>>("csv", arrayWriter);
        var serviceProvider = services.BuildServiceProvider();

        var factory = new ReportStreamWriterFactory(serviceProvider);

        // Act
        var resultString = factory.Create<string>("csv");
        var resultArray = factory.Create<string[]>("csv");

        // Assert
        Assert.Same(stringWriter, resultString);
        Assert.Same(arrayWriter, resultArray);
    }

    [Fact]
    public void Create_WithMultipleFormats_ShouldReturnCorrectWriter()
    {
        // Arrange
        var csvWriter = Substitute.For<IReportStreamWriter<string>>();
        var xlsxWriter = Substitute.For<IReportStreamWriter<string>>();

        var services = new ServiceCollection();
        services.AddKeyedSingleton<IReportStreamWriter<string>>("csv", csvWriter);
        services.AddKeyedSingleton<IReportStreamWriter<string>>("xlsx", xlsxWriter);
        var serviceProvider = services.BuildServiceProvider();

        var factory = new ReportStreamWriterFactory(serviceProvider);

        // Act
        var resultCsv = factory.Create<string>("csv");
        var resultXlsx = factory.Create<string>("xlsx");

        // Assert
        Assert.Same(csvWriter, resultCsv);
        Assert.Same(xlsxWriter, resultXlsx);
    }

    [Fact]
    public void Create_ExceptionMessage_ShouldContainFormatAndRecordType()
    {
        // Arrange
        var services = new ServiceCollection();
        var serviceProvider = services.BuildServiceProvider();

        var factory = new ReportStreamWriterFactory(serviceProvider);

        // Act & Assert
        var exception = Assert.Throws<InvalidOperationException>(() =>
            factory.Create<int>("pdf"));

        Assert.Contains("pdf", exception.Message);
        Assert.Contains("Int32", exception.Message);
        Assert.Contains("No writer implementation found", exception.Message);
    }
}

using Microsoft.Extensions.Options;
using NSubstitute;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Sinks;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.StreamWriters;
using PaymentsDataLayerReports.Application.Settings;

namespace PaymentsDataLayerReports.Unit.Test.Application.Services.ReportStreamWriterService.StreamWriters;

public class XlsxReportStreamWriterTests
{
    private readonly IReportOutputSink _outputSink;
    private readonly IOptions<AwsSettings> _awsOptions;
    private readonly MemoryStream _outputStream;

    public XlsxReportStreamWriterTests()
    {
        _outputSink = Substitute.For<IReportOutputSink>();
        _awsOptions = Options.Create(new AwsSettings { WorkgroupBucket = "test-bucket" });
        _outputStream = new MemoryStream();

        _outputSink.InitializeAsync(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(_outputStream);
    }

    [Fact]
    public async Task InitializeAsync_ShouldCallOutputSinkInitialize()
    {
        // Arrange
        var writer = new XlsxReportStreamWriter(_outputSink, _awsOptions);

        // Act
        await writer.InitializeAsync("report-123", CancellationToken.None);

        // Assert
        await _outputSink.Received(1).InitializeAsync(
            Arg.Is<string>(k => k.Contains("report-123") && k.EndsWith(".xlsx")),
            "test-bucket",
            Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task WriteHeaderAsync_BeforeInitialize_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var writer = new XlsxReportStreamWriter(_outputSink, _awsOptions);

        // Act & Assert
        await Assert.ThrowsAsync<InvalidOperationException>(
            () => writer.WriteHeaderAsync("header", CancellationToken.None));
    }

    [Fact]
    public async Task WriteRecordAsync_String_BeforeInitialize_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var writer = new XlsxReportStreamWriter(_outputSink, _awsOptions);

        // Act & Assert
        await Assert.ThrowsAsync<InvalidOperationException>(
            () => writer.WriteRecordAsync("data", CancellationToken.None));
    }

    [Fact]
    public async Task WriteRecordAsync_StringArray_BeforeInitialize_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var writer = new XlsxReportStreamWriter(_outputSink, _awsOptions);

        // Act & Assert
        await Assert.ThrowsAsync<InvalidOperationException>(
            () => writer.WriteRecordAsync(new[] { "col1", "col2" }, CancellationToken.None));
    }

    [Fact]
    public async Task WriteRecordAsync_String_BeforeWriteHeader_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var writer = new XlsxReportStreamWriter(_outputSink, _awsOptions);
        await writer.InitializeAsync("report-123", CancellationToken.None);

        // Act & Assert - Buffer not initialized because header not written
        await Assert.ThrowsAsync<InvalidOperationException>(
            () => writer.WriteRecordAsync("data", CancellationToken.None));
    }

    [Fact]
    public async Task WriteRecordAsync_StringArray_BeforeWriteHeader_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var writer = new XlsxReportStreamWriter(_outputSink, _awsOptions);
        await writer.InitializeAsync("report-123", CancellationToken.None);

        // Act & Assert - Buffer not initialized because header not written
        await Assert.ThrowsAsync<InvalidOperationException>(
            () => writer.WriteRecordAsync(new[] { "col1", "col2" }, CancellationToken.None));
    }

    [Fact]
    public async Task WriteHeaderAsync_ShouldInitializeBufferAndWriteHeader()
    {
        // Arrange
        var writer = new XlsxReportStreamWriter(_outputSink, _awsOptions);
        await writer.InitializeAsync("report-123", CancellationToken.None);

        // Act - Should not throw
        await writer.WriteHeaderAsync("col1;col2;col3", CancellationToken.None);

        // Assert - If we can write a record after header, buffer was initialized
        await writer.WriteRecordAsync("val1;val2;val3", CancellationToken.None);
    }

    [Fact]
    public async Task WriteRecordAsync_StringArray_WithMoreColumnsThanHeader_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var writer = new XlsxReportStreamWriter(_outputSink, _awsOptions);
        await writer.InitializeAsync("report-123", CancellationToken.None);
        await writer.WriteHeaderAsync("col1;col2", CancellationToken.None); // 2 columns

        // Act & Assert - Try to write 3 columns
        var exception = await Assert.ThrowsAsync<InvalidOperationException>(
            () => writer.WriteRecordAsync(new[] { "val1", "val2", "val3" }, CancellationToken.None));

        Assert.Contains("malformed", exception.Message);
    }

    [Fact]
    public async Task CompleteAsync_BeforeInitialize_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var writer = new XlsxReportStreamWriter(_outputSink, _awsOptions);

        // Act & Assert
        await Assert.ThrowsAsync<InvalidOperationException>(
            () => writer.CompleteAsync(CancellationToken.None));
    }

    [Fact]
    public async Task CompleteAsync_ShouldCallOutputSinkComplete()
    {
        // Arrange
        var writer = new XlsxReportStreamWriter(_outputSink, _awsOptions);
        await writer.InitializeAsync("report-123", CancellationToken.None);
        await writer.WriteHeaderAsync("col1;col2", CancellationToken.None);

        // Act
        await writer.CompleteAsync(CancellationToken.None);

        // Assert
        await _outputSink.Received(1).CompleteAsync(Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task AbortAsync_ShouldCallOutputSinkAbort()
    {
        // Arrange
        var writer = new XlsxReportStreamWriter(_outputSink, _awsOptions);
        await writer.InitializeAsync("report-123", CancellationToken.None);

        // Act
        await writer.AbortAsync(CancellationToken.None);

        // Assert
        await _outputSink.Received(1).AbortAsync(Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task WriteRecordAsync_String_WithValidCsvLine_ShouldNotThrow()
    {
        // Arrange
        var writer = new XlsxReportStreamWriter(_outputSink, _awsOptions);
        await writer.InitializeAsync("report-123", CancellationToken.None);
        await writer.WriteHeaderAsync("col1;col2;col3", CancellationToken.None);

        // Act - Should not throw
        await writer.WriteRecordAsync("val1;val2;val3", CancellationToken.None);
    }

    [Fact]
    public async Task WriteRecordAsync_StringArray_WithValidColumns_ShouldNotThrow()
    {
        // Arrange
        var writer = new XlsxReportStreamWriter(_outputSink, _awsOptions);
        await writer.InitializeAsync("report-123", CancellationToken.None);
        await writer.WriteHeaderAsync("col1;col2;col3", CancellationToken.None);

        // Act - Should not throw
        await writer.WriteRecordAsync(new[] { "val1", "val2", "val3" }, CancellationToken.None);
    }

    [Fact]
    public async Task WriteRecordAsync_StringArray_WithFewerColumnsThanHeader_ShouldNotThrow()
    {
        // Arrange
        var writer = new XlsxReportStreamWriter(_outputSink, _awsOptions);
        await writer.InitializeAsync("report-123", CancellationToken.None);
        await writer.WriteHeaderAsync("col1;col2;col3", CancellationToken.None); // 3 columns

        // Act - Should not throw (2 columns is OK)
        await writer.WriteRecordAsync(new[] { "val1", "val2" }, CancellationToken.None);
    }
}

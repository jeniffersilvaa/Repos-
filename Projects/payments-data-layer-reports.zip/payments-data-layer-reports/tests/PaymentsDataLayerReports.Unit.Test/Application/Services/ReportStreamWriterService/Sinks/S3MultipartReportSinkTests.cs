using System.Text;
using NSubstitute;
using PaymentsDataLayerReports.Application.Infra.MultiPartFileUploader.Interfaces;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Sinks;

namespace PaymentsDataLayerReports.Unit.Test.Application.Services.ReportStreamWriterService.Sinks;

public class S3MultipartReportSinkTests
{
    #region Initialization

    [Fact]
    public async Task InitializeAsync_ShouldInitiateMultipartUploadAndReturnStream()
    {
        // Arrange
        var uploader = Substitute.For<IMultiPartFileUploader>();
        var sink = new S3MultipartReportSink(uploader);

        // Act
        var stream = await sink.InitializeAsync("report-key", "bucket-name", CancellationToken.None);

        // Assert
        await uploader.Received(1).InitiateMultipartUploadAsync("report-key", "bucket-name", Arg.Any<CancellationToken>());
        Assert.NotNull(stream);
        Assert.True(stream.CanWrite);
    }

    [Fact]
    public async Task InitializeAsync_WhenCalledTwice_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var uploader = Substitute.For<IMultiPartFileUploader>();
        var sink = new S3MultipartReportSink(uploader);

        await sink.InitializeAsync("report-key", "bucket-name", CancellationToken.None);

        // Act & Assert
        await Assert.ThrowsAsync<InvalidOperationException>(
            () => sink.InitializeAsync("report-key", "bucket-name", CancellationToken.None));
    }

    #endregion

    #region Stream Write

    [Fact]
    public async Task Stream_WriteSmallData_ShouldBufferWithoutUploading()
    {
        // Arrange
        var uploader = Substitute.For<IMultiPartFileUploader>();
        var sink = new S3MultipartReportSink(uploader);

        var stream = await sink.InitializeAsync("report-key", "bucket-name", CancellationToken.None);

        // Act
        await stream.WriteAsync(Encoding.UTF8.GetBytes("small data"), CancellationToken.None);

        // Assert - Should not upload part yet (data is buffered)
        await uploader.DidNotReceive().UploadPartAsync(Arg.Any<MemoryStream>(), Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task Stream_WriteMultipleSmallWrites_ShouldAccumulateInBuffer()
    {
        // Arrange
        var uploader = Substitute.For<IMultiPartFileUploader>();
        var sink = new S3MultipartReportSink(uploader);

        var stream = await sink.InitializeAsync("report-key", "bucket-name", CancellationToken.None);

        // Act
        await stream.WriteAsync(Encoding.UTF8.GetBytes("line1\n"), CancellationToken.None);
        await stream.WriteAsync(Encoding.UTF8.GetBytes("line2\n"), CancellationToken.None);
        await stream.WriteAsync(Encoding.UTF8.GetBytes("line3\n"), CancellationToken.None);

        // Assert - Should not upload part yet (data is buffered)
        await uploader.DidNotReceive().UploadPartAsync(Arg.Any<MemoryStream>(), Arg.Any<CancellationToken>());
    }

    #endregion

    #region CompleteAsync

    [Fact]
    public async Task CompleteAsync_BeforeInitialization_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var uploader = Substitute.For<IMultiPartFileUploader>();
        var sink = new S3MultipartReportSink(uploader);

        // Act & Assert
        await Assert.ThrowsAsync<InvalidOperationException>(
            () => sink.CompleteAsync(CancellationToken.None));
    }

    [Fact]
    public async Task CompleteAsync_ShouldUploadRemainingBufferAndCompleteMultipart()
    {
        // Arrange
        var uploader = Substitute.For<IMultiPartFileUploader>();
        var sink = new S3MultipartReportSink(uploader);

        var stream = await sink.InitializeAsync("report-key", "bucket-name", CancellationToken.None);
        await stream.WriteAsync(Encoding.UTF8.GetBytes("line1\n"), CancellationToken.None);

        // Act
        await sink.CompleteAsync(CancellationToken.None);

        // Assert
        await uploader.Received(1).InitiateMultipartUploadAsync("report-key", "bucket-name", Arg.Any<CancellationToken>());
        await uploader.Received(1).UploadPartAsync(Arg.Any<MemoryStream>(), Arg.Any<CancellationToken>());
        await uploader.Received(1).CompleteMultipartUploadAsync(Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task CompleteAsync_WithEmptyBuffer_ShouldNotUploadPart()
    {
        // Arrange
        var uploader = Substitute.For<IMultiPartFileUploader>();
        var sink = new S3MultipartReportSink(uploader);

        await sink.InitializeAsync("report-key", "bucket-name", CancellationToken.None);

        // Act
        await sink.CompleteAsync(CancellationToken.None);

        // Assert
        await uploader.DidNotReceive().UploadPartAsync(Arg.Any<MemoryStream>(), Arg.Any<CancellationToken>());
        await uploader.Received(1).CompleteMultipartUploadAsync(Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task CompleteAsync_WhenCalledTwice_ShouldBeIdempotent()
    {
        // Arrange
        var uploader = Substitute.For<IMultiPartFileUploader>();
        var sink = new S3MultipartReportSink(uploader);

        var stream = await sink.InitializeAsync("report-key", "bucket-name", CancellationToken.None);
        await stream.WriteAsync(Encoding.UTF8.GetBytes("data"), CancellationToken.None);

        // Act
        await sink.CompleteAsync(CancellationToken.None);
        await sink.CompleteAsync(CancellationToken.None);

        // Assert - Should only complete once
        await uploader.Received(1).CompleteMultipartUploadAsync(Arg.Any<CancellationToken>());
    }

    #endregion

    #region AbortAsync

    [Fact]
    public async Task AbortAsync_BeforeInitialization_ShouldNotThrow()
    {
        // Arrange
        var uploader = Substitute.For<IMultiPartFileUploader>();
        var sink = new S3MultipartReportSink(uploader);

        // Act and Assert - Should not throw
        await sink.AbortAsync(CancellationToken.None);

        // Should not call abort since not initialized
        await uploader.DidNotReceive().AbortMultipartUploadAsync(Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task AbortAsync_AfterInitialization_ShouldAbortMultipartUpload()
    {
        // Arrange
        var uploader = Substitute.For<IMultiPartFileUploader>();
        var sink = new S3MultipartReportSink(uploader);

        await sink.InitializeAsync("report-key", "bucket-name", CancellationToken.None);

        // Act
        await sink.AbortAsync(CancellationToken.None);

        // Assert
        await uploader.Received(1).AbortMultipartUploadAsync(Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task AbortAsync_AfterComplete_ShouldNotAbort()
    {
        // Arrange
        var uploader = Substitute.For<IMultiPartFileUploader>();
        var sink = new S3MultipartReportSink(uploader);

        await sink.InitializeAsync("report-key", "bucket-name", CancellationToken.None);
        await sink.CompleteAsync(CancellationToken.None);

        // Act
        await sink.AbortAsync(CancellationToken.None);

        // Assert - Should not abort since already completed
        await uploader.DidNotReceive().AbortMultipartUploadAsync(Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task AbortAsync_WhenCalledTwice_ShouldBeIdempotent()
    {
        // Arrange
        var uploader = Substitute.For<IMultiPartFileUploader>();
        var sink = new S3MultipartReportSink(uploader);

        await sink.InitializeAsync("report-key", "bucket-name", CancellationToken.None);

        // Act
        await sink.AbortAsync(CancellationToken.None);
        await sink.AbortAsync(CancellationToken.None);

        // Assert - Should only abort once
        await uploader.Received(1).AbortMultipartUploadAsync(Arg.Any<CancellationToken>());
    }

    #endregion
}

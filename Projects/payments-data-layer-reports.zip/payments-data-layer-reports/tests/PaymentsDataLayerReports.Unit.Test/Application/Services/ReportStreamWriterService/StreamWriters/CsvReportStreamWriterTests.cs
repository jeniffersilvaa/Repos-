using System.Text;
using Microsoft.Extensions.Options;
using NSubstitute;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Sinks;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.StreamWriters;
using PaymentsDataLayerReports.Application.Settings;

namespace PaymentsDataLayerReports.Unit.Test.Application.Services.ReportStreamWriterService.StreamWriters;

public class CsvReportStreamWriterTests
{
    private readonly IReportOutputSink _outputSink;
    private readonly IOptions<AwsSettings> _awsOptions;
    private readonly MemoryStream _outputStream;

    public CsvReportStreamWriterTests()
    {
        _outputSink = Substitute.For<IReportOutputSink>();
        _awsOptions = Options.Create(new AwsSettings { WorkgroupBucket = "test-bucket" });
        _outputStream = new MemoryStream();

        _outputSink.InitializeAsync(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(_outputStream);
    }

    [Fact]
    public async Task InitializeAsync_ShouldCallOutputSinkInitialize()
    {
        // Arrange
        var writer = new CsvReportStreamWriter(_outputSink, _awsOptions);

        // Act
        await writer.InitializeAsync("report-123", CancellationToken.None);

        // Assert
        await _outputSink.Received(1).InitializeAsync(
            Arg.Is<string>(k => k.Contains("report-123") && k.EndsWith(".csv")),
            "test-bucket",
            Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task WriteHeaderAsync_BeforeInitialize_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var writer = new CsvReportStreamWriter(_outputSink, _awsOptions);

        // Act & Assert
        await Assert.ThrowsAsync<InvalidOperationException>(
            () => writer.WriteHeaderAsync("header", CancellationToken.None));
    }

    [Fact]
    public async Task WriteHeaderAsync_ShouldWriteToStream()
    {
        // Arrange
        var writer = new CsvReportStreamWriter(_outputSink, _awsOptions);
        await writer.InitializeAsync("report-123", CancellationToken.None);

        // Act
        await writer.WriteHeaderAsync("col1,col2,col3", CancellationToken.None);
        await writer.CompleteAsync(CancellationToken.None);

        // Assert
        _outputStream.Seek(0, SeekOrigin.Begin);
        var content = Encoding.UTF8.GetString(_outputStream.ToArray());
        Assert.Contains("col1,col2,col3", content);
    }

    [Fact]
    public async Task WriteRecordAsync_BeforeInitialize_ShouldThrowInvalidOperationException()
    {
        // Arrange
        var writer = new CsvReportStreamWriter(_outputSink, _awsOptions);

        // Act & Assert
        await Assert.ThrowsAsync<InvalidOperationException>(
            () => writer.WriteRecordAsync("data", CancellationToken.None));
    }

    [Fact]
    public async Task WriteRecordAsync_ShouldWriteToStream()
    {
        // Arrange
        var writer = new CsvReportStreamWriter(_outputSink, _awsOptions);
        await writer.InitializeAsync("report-123", CancellationToken.None);

        // Act
        await writer.WriteRecordAsync("value1,value2,value3", CancellationToken.None);
        await writer.CompleteAsync(CancellationToken.None);

        // Assert
        _outputStream.Seek(0, SeekOrigin.Begin);
        var content = Encoding.UTF8.GetString(_outputStream.ToArray());
        Assert.Contains("value1,value2,value3", content);
    }

    [Fact]
    public async Task WriteRecordAsync_WithMultipleRecords_ShouldWriteAllToStream()
    {
        // Arrange
        var writer = new CsvReportStreamWriter(_outputSink, _awsOptions);
        await writer.InitializeAsync("report-123", CancellationToken.None);

        // Act
        await writer.WriteRecordAsync("line1", CancellationToken.None);
        await writer.WriteRecordAsync("line2", CancellationToken.None);
        await writer.WriteRecordAsync("line3", CancellationToken.None);
        await writer.CompleteAsync(CancellationToken.None);

        // Assert
        _outputStream.Seek(0, SeekOrigin.Begin);
        var content = Encoding.UTF8.GetString(_outputStream.ToArray());
        Assert.Contains("line1", content);
        Assert.Contains("line2", content);
        Assert.Contains("line3", content);
    }

    [Fact]
    public async Task WriteRecordAsync_WithNewlinesInRecord_ShouldTrimToFirstLine()
    {
        // Arrange
        var writer = new CsvReportStreamWriter(_outputSink, _awsOptions);
        await writer.InitializeAsync("report-123", CancellationToken.None);

        // Act
        await writer.WriteRecordAsync("line1\nline2\nline3", CancellationToken.None);
        await writer.CompleteAsync(CancellationToken.None);

        // Assert
        _outputStream.Seek(0, SeekOrigin.Begin);
        var content = Encoding.UTF8.GetString(_outputStream.ToArray());
        Assert.Contains("line1", content);
        Assert.DoesNotContain("line2", content);
    }

    [Fact]
    public async Task WriteRecordAsync_WithCarriageReturn_ShouldTrimToFirstLine()
    {
        // Arrange
        var writer = new CsvReportStreamWriter(_outputSink, _awsOptions);
        await writer.InitializeAsync("report-123", CancellationToken.None);

        // Act
        await writer.WriteRecordAsync("line1\r\nline2", CancellationToken.None);
        await writer.CompleteAsync(CancellationToken.None);

        // Assert
        _outputStream.Seek(0, SeekOrigin.Begin);
        var content = Encoding.UTF8.GetString(_outputStream.ToArray());
        Assert.Contains("line1", content);
        Assert.DoesNotContain("line2", content);
    }

    [Fact]
    public async Task CompleteAsync_ShouldCallOutputSinkComplete()
    {
        // Arrange
        var writer = new CsvReportStreamWriter(_outputSink, _awsOptions);
        await writer.InitializeAsync("report-123", CancellationToken.None);

        // Act
        await writer.CompleteAsync(CancellationToken.None);

        // Assert
        await _outputSink.Received(1).CompleteAsync(Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task AbortAsync_ShouldCallOutputSinkAbort()
    {
        // Arrange
        var writer = new CsvReportStreamWriter(_outputSink, _awsOptions);
        await writer.InitializeAsync("report-123", CancellationToken.None);

        // Act
        await writer.AbortAsync(CancellationToken.None);

        // Assert
        await _outputSink.Received(1).AbortAsync(Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task WriteRecordAsync_WithEmptyString_ShouldWriteEmptyLine()
    {
        // Arrange
        var writer = new CsvReportStreamWriter(_outputSink, _awsOptions);
        await writer.InitializeAsync("report-123", CancellationToken.None);

        // Act
        await writer.WriteRecordAsync("", CancellationToken.None);
        await writer.CompleteAsync(CancellationToken.None);

        // Assert - Should not throw
        await _outputSink.Received(1).CompleteAsync(Arg.Any<CancellationToken>());
    }

    [Fact]
    public async Task WriteRecordAsync_WithWhitespaceOnly_ShouldTrim()
    {
        // Arrange
        var writer = new CsvReportStreamWriter(_outputSink, _awsOptions);
        await writer.InitializeAsync("report-123", CancellationToken.None);

        // Act
        await writer.WriteRecordAsync("  data  ", CancellationToken.None);
        await writer.CompleteAsync(CancellationToken.None);

        // Assert
        _outputStream.Seek(0, SeekOrigin.Begin);
        var content = Encoding.UTF8.GetString(_outputStream.ToArray());
        Assert.Contains("data", content);
    }
}

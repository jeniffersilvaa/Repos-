using FluentValidation.TestHelper;
using PaymentsDataLayerReports.Application.Routes.Reports.PostReports;
using PaymentsDataLayerReports.Application.Routes.Reports.PostReports.Models;

namespace PaymentsDataLayerReports.Unit.Test.Application.Routes.Reports.PostReports.Models;

public class IdentifiersValidatorTests
{
    private readonly IdentifiersValidator _validator = new();

    [Fact]
    public void Validate_WithOnlyDocuments_ShouldBeValid()
    {
        // Arrange
        var identifiers = new Identifiers { Documents = ["12345678901"] };

        // Act
        var result = _validator.TestValidate(identifiers);

        // Assert
        result.ShouldNotHaveAnyValidationErrors();
    }

    [Fact]
    public void Validate_WithOnlyMerchantIds_ShouldBeValid()
    {
        // Arrange
        var identifiers = new Identifiers { MerchantIds = ["merchant-1"] };

        // Act
        var result = _validator.TestValidate(identifiers);

        // Assert
        result.ShouldNotHaveAnyValidationErrors();
    }

    [Fact]
    public void Validate_WithBothDocumentsAndMerchantIds_ShouldBeInvalid()
    {
        // Arrange
        var identifiers = new Identifiers
        {
            Documents = ["12345678901"],
            MerchantIds = ["merchant-1"]
        };

        // Act
        var result = _validator.TestValidate(identifiers);

        // Assert
        result.ShouldHaveAnyValidationError();
    }

    [Fact]
    public void Validate_WithNeitherDocumentsNorMerchantIds_ShouldBeInvalid()
    {
        // Arrange
        var identifiers = new Identifiers();

        // Act
        var result = _validator.TestValidate(identifiers);

        // Assert
        result.ShouldHaveAnyValidationError()
            .WithErrorMessage("Either 'documents' or 'merchant_ids' or 'stone_accounts' must be provided.");
    }

    [Fact]
    public void Validate_WithExactly50Documents_ShouldBeValid()
    {
        // Arrange
        var identifiers = new Identifiers
        {
            Documents = Enumerable.Range(1, 50).Select(i => i.ToString("D11")).ToList()
        };

        // Act
        var result = _validator.TestValidate(identifiers);

        // Assert
        result.ShouldNotHaveValidationErrorFor(x => x.Documents);
    }

    [Fact]
    public void Validate_With51Documents_ShouldBeInvalid()
    {
        // Arrange
        var identifiers = new Identifiers
        {
            Documents = Enumerable.Range(1, 51).Select(i => i.ToString("D11")).ToList()
        };

        // Act
        var result = _validator.TestValidate(identifiers);

        // Assert
        result.ShouldHaveValidationErrorFor(x => x.Documents)
            .WithErrorMessage("'documents' must not exceed 50 items.");
    }

    [Fact]
    public void Validate_WithMoreThan50Documents_ShouldBeInvalid()
    {
        // Arrange
        var identifiers = new Identifiers
        {
            Documents = Enumerable.Range(1, 100).Select(i => i.ToString("D11")).ToList()
        };

        // Act
        var result = _validator.TestValidate(identifiers);

        // Assert
        result.ShouldHaveValidationErrorFor(x => x.Documents)
            .WithErrorMessage("'documents' must not exceed 50 items.");
    }
}

public class EmailNotificationValidatorTests
{
    private readonly EmailNotificationValidator _validator = new();

    [Fact]
    public void Validate_WithValidEmail_ShouldBeValid()
    {
        // Arrange
        var email = new EmailNotification { Address = "test@example.com" };

        // Act
        var result = _validator.TestValidate(email);

        // Assert
        result.ShouldNotHaveAnyValidationErrors();
    }

    [Fact]
    public void Validate_WithEmptyEmail_ShouldBeInvalid()
    {
        // Arrange
        var email = new EmailNotification { Address = "" };

        // Act
        var result = _validator.TestValidate(email);

        // Assert
        result.ShouldHaveValidationErrorFor(e => e.Address);
    }

    [Fact]
    public void Validate_WithInvalidEmail_ShouldBeInvalid()
    {
        // Arrange
        var email = new EmailNotification { Address = "invalid-email" };

        // Act
        var result = _validator.TestValidate(email);

        // Assert
        result.ShouldHaveValidationErrorFor(e => e.Address)
            .WithErrorMessage("'email.address' must be a valid email address.");
    }
}

public class WebhookNotificationValidatorTests
{
    private readonly WebhookNotificationValidator _validator = new();

    [Fact]
    public void Validate_WithValidUrlAndHeaders_ShouldBeValid()
    {
        // Arrange
        var webhook = new WebhookNotification
        {
            Url = "https://example.com/webhook",
            Headers = new Dictionary<string, string> { { "Authorization", "Bearer token" } }
        };

        // Act
        var result = _validator.TestValidate(webhook);

        // Assert
        result.ShouldNotHaveAnyValidationErrors();
    }

    [Fact]
    public void Validate_WithEmptyUrl_ShouldBeInvalid()
    {
        // Arrange
        var webhook = new WebhookNotification { Url = "" };

        // Act
        var result = _validator.TestValidate(webhook);

        // Assert
        result.ShouldHaveValidationErrorFor(w => w.Url);
    }

    [Fact]
    public void Validate_WithInvalidUrl_ShouldBeInvalid()
    {
        // Arrange
        var webhook = new WebhookNotification { Url = "not-a-url" };

        // Act
        var result = _validator.TestValidate(webhook);

        // Assert
        result.ShouldHaveValidationErrorFor(w => w.Url)
            .WithErrorMessage("'webhook.url' must be a valid URL.");
    }

    [Fact]
    public void Validate_WithUrlButNoHeaders_ShouldBeInvalid()
    {
        // Arrange
        var webhook = new WebhookNotification { Url = "https://example.com/webhook" };

        // Act
        var result = _validator.TestValidate(webhook);

        // Assert
        result.ShouldHaveValidationErrorFor(w => w.Headers);
    }
}

public class NotificationValidatorTests
{
    private readonly NotificationValidator _validator = new();

    [Fact]
    public void Validate_WithValidEmailNotification_ShouldBeValid()
    {
        // Arrange
        var notification = new Notification
        {
            Type = "email",
            Email = new EmailNotification { Address = "test@example.com" }
        };

        // Act
        var result = _validator.TestValidate(notification);

        // Assert
        result.ShouldNotHaveAnyValidationErrors();
    }

    [Fact]
    public void Validate_WithValidWebhookNotification_ShouldBeValid()
    {
        // Arrange
        var notification = new Notification
        {
            Type = "webhook",
            Webhook = new WebhookNotification
            {
                Url = "https://example.com/webhook",
                Headers = new Dictionary<string, string> { { "Authorization", "Bearer token" } }
            }
        };

        // Act
        var result = _validator.TestValidate(notification);

        // Assert
        result.ShouldNotHaveAnyValidationErrors();
    }

    [Fact]
    public void Validate_WithInvalidType_ShouldBeInvalid()
    {
        // Arrange
        var notification = new Notification { Type = "invalid" };

        // Act
        var result = _validator.TestValidate(notification);

        // Assert
        result.ShouldHaveValidationErrorFor(n => n.Type);
    }

    [Fact]
    public void Validate_WithEmailTypeButNoEmailConfig_ShouldBeInvalid()
    {
        // Arrange
        var notification = new Notification { Type = "email" };

        // Act
        var result = _validator.TestValidate(notification);

        // Assert
        result.ShouldHaveValidationErrorFor(n => n.Email);
    }

    [Fact]
    public void Validate_WithWebhookTypeButNoWebhookConfig_ShouldBeInvalid()
    {
        // Arrange
        var notification = new Notification { Type = "webhook" };

        // Act
        var result = _validator.TestValidate(notification);

        // Assert
        result.ShouldHaveValidationErrorFor(n => n.Webhook);
    }

    [Fact]
    public void Validate_WithEmailTypeAndWebhookConfig_ShouldBeInvalid()
    {
        // Arrange
        var notification = new Notification
        {
            Type = "email",
            Email = new EmailNotification { Address = "test@example.com" },
            Webhook = new WebhookNotification { Url = "https://example.com" }
        };

        // Act
        var result = _validator.TestValidate(notification);

        // Assert
        result.ShouldHaveValidationErrorFor(n => n.Webhook);
    }
}

public class ReportFiltersValidatorTests
{
    private readonly ReportFiltersValidator _validator = new();

    [Fact]
    public void Validate_WithValidFilters_ShouldBeValid()
    {
        // Arrange
        var filters = new ReportFilters
        {
            StartDate = new DateOnly(2025, 1, 1),
            FinalDate = new DateOnly(2025, 1, 31),
            Organizations = ["stone"],
            Identifiers = new Identifiers { Documents = ["12345678901"] }
        };

        // Act
        var result = _validator.TestValidate(filters);

        // Assert
        result.ShouldNotHaveAnyValidationErrors();
    }

    [Fact]
    public void Validate_WithFinalDateBeforeStartDate_ShouldBeInvalid()
    {
        // Arrange
        var filters = new ReportFilters
        {
            StartDate = new DateOnly(2025, 1, 31),
            FinalDate = new DateOnly(2025, 1, 1),
            Organizations = ["stone"],
            Identifiers = new Identifiers { Documents = ["12345678901"] }
        };

        // Act
        var result = _validator.TestValidate(filters);

        // Assert
        result.ShouldHaveValidationErrorFor(f => f.FinalDate);
    }

    [Fact]
    public void Validate_WithInvalidOrganization_ShouldBeInvalid()
    {
        // Arrange
        var filters = new ReportFilters
        {
            StartDate = new DateOnly(2025, 1, 1),
            FinalDate = new DateOnly(2025, 1, 31),
            Organizations = ["invalid-org"],
            Identifiers = new Identifiers { Documents = ["12345678901"] }
        };

        // Act
        var result = _validator.TestValidate(filters);

        // Assert
        result.ShouldHaveValidationErrorFor(f => f.Organizations);
    }

    [Theory]
    [InlineData("stone")]
    [InlineData("ton")]
    [InlineData("pagarme")]
    public void Validate_WithValidOrganization_ShouldBeValid(string org)
    {
        // Arrange
        var filters = new ReportFilters
        {
            StartDate = new DateOnly(2025, 1, 1),
            FinalDate = new DateOnly(2025, 1, 31),
            Organizations = [org],
            Identifiers = new Identifiers { Documents = ["12345678901"] }
        };

        // Act
        var result = _validator.TestValidate(filters);

        // Assert
        result.ShouldNotHaveValidationErrorFor(f => f.Organizations);
    }
}

public class PostReportsRequestValidatorTests
{
    private readonly PostReportsRequestValidator _validator = new();

    [Fact]
    public void Validate_WithValidCsvRequest_ShouldBeValid()
    {
        // Arrange
        var request = new PostReportsRequest
        {
            Type = "receivables",
            FileFormat = "csv",
            Filters = new ReportFilters
            {
                StartDate = new DateOnly(2025, 1, 1),
                FinalDate = new DateOnly(2025, 1, 31),
                Organizations = ["stone"],
                Identifiers = new Identifiers { Documents = ["12345678901"] }
            }
        };

        // Act
        var result = _validator.TestValidate(request);

        // Assert
        result.ShouldNotHaveAnyValidationErrors();
    }

    [Fact]
    public void Validate_WithValidXlsxReceivablesRequest_ShouldBeValid()
    {
        // Arrange
        var request = new PostReportsRequest
        {
            Type = "receivables",
            FileFormat = "xlsx",
            Filters = new ReportFilters
            {
                StartDate = new DateOnly(2025, 1, 1),
                FinalDate = new DateOnly(2025, 1, 31),
                Organizations = ["stone"],
                Identifiers = new Identifiers { Documents = ["12345678901"] }
            }
        };

        // Act
        var result = _validator.TestValidate(request);

        // Assert
        result.ShouldNotHaveAnyValidationErrors();
    }

    [Fact]
    public void Validate_WithValidXlsxSaleRequest_ShouldBeValid()
    {
        // Arrange
        var request = new PostReportsRequest
        {
            Type = "sales",
            FileFormat = "xlsx",
            Filters = new ReportFilters
            {
                StartDate = new DateOnly(2025, 1, 1),
                FinalDate = new DateOnly(2025, 1, 31),
                Organizations = ["stone"],
                Identifiers = new Identifiers { Documents = ["12345678901"] }
            }
        };

        // Act
        var result = _validator.TestValidate(request);

        // Assert
        result.ShouldNotHaveAnyValidationErrors();
    }

    [Fact]
    public void Validate_WithValidXlsxReceivablesLegacyRequest_ShouldBeValid()
    {
        // Arrange
        var request = new PostReportsRequest
        {
            Type = "receivables_legacy",
            FileFormat = "xlsx",
            Filters = new ReportFilters
            {
                StartDate = new DateOnly(2025, 1, 1),
                FinalDate = new DateOnly(2025, 1, 31),
                Organizations = ["stone"],
                Identifiers = new Identifiers { Documents = ["12345678901"] }
            }
        };

        // Act
        var result = _validator.TestValidate(request);

        // Assert
        result.ShouldNotHaveAnyValidationErrors();
    }

    [Fact]
    public void Validate_WithInvalidReportType_ShouldBeInvalid()
    {
        // Arrange
        var request = new PostReportsRequest
        {
            Type = "invalid-type",
            FileFormat = "csv",
            Filters = new ReportFilters
            {
                StartDate = new DateOnly(2025, 1, 1),
                FinalDate = new DateOnly(2025, 1, 31),
                Organizations = ["stone"],
                Identifiers = new Identifiers { Documents = ["12345678901"] }
            }
        };

        // Act
        var result = _validator.TestValidate(request);

        // Assert
        result.ShouldHaveValidationErrorFor(r => r.Type);
    }

    [Fact]
    public void Validate_WithInvalidFileFormat_ShouldBeInvalid()
    {
        // Arrange
        var request = new PostReportsRequest
        {
            Type = "receivables",
            FileFormat = "pdf",
            Filters = new ReportFilters
            {
                StartDate = new DateOnly(2025, 1, 1),
                FinalDate = new DateOnly(2025, 1, 31),
                Organizations = ["stone"],
                Identifiers = new Identifiers { Documents = ["12345678901"] }
            }
        };

        // Act
        var result = _validator.TestValidate(request);

        // Assert
        result.ShouldHaveValidationErrorFor(r => r.FileFormat)
            .WithErrorMessage("File format must be: csv or xlsx");
    }

    [Fact]
    public void Validate_WithXlsxForChargesList_ShouldBeInvalid()
    {
        // Arrange
        var request = new PostReportsRequest
        {
            Type = "charges_list",
            FileFormat = "xlsx",
            Filters = new ReportFilters
            {
                StartDate = new DateOnly(2025, 1, 1),
                FinalDate = new DateOnly(2025, 1, 31),
                Organizations = ["stone"],
                Identifiers = new Identifiers { Documents = ["12345678901"] }
            }
        };

        // Act
        var result = _validator.TestValidate(request);

        // Assert
        result.ShouldHaveValidationErrorFor(r => r.FileFormat);
    }

    [Theory]
    [InlineData("receivables")]
    [InlineData("receivables_legacy")]
    [InlineData("sales")]
    [InlineData("orders")]
    [InlineData("charges_list")]
    [InlineData("sales_stone")]
    [InlineData("sales_ton")]
    public void Validate_WithValidReportTypes_ShouldBeValid(string reportType)
    {
        // Arrange
        var request = new PostReportsRequest
        {
            Type = reportType,
            FileFormat = "csv",
            Filters = new ReportFilters
            {
                StartDate = new DateOnly(2025, 1, 1),
                FinalDate = new DateOnly(2025, 1, 31),
                Organizations = ["stone"],
                Identifiers = new Identifiers { Documents = ["12345678901"] }
            }
        };

        // Act
        var result = _validator.TestValidate(request);

        // Assert
        result.ShouldNotHaveValidationErrorFor(r => r.Type);
    }
}

using Hangfire;
using Hangfire.Common;
using Hangfire.States;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using NSubstitute;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Infra.DataLayerReport;
using PaymentsDataLayerReports.Application.Routes.Reports.PostChargesReport;
using PaymentsDataLayerReports.Application.Settings;

namespace PaymentsDataLayerReports.Unit.Test.Application.Routes.Reports.PostChargesReport;

public class PostChargesReportEndpointTests
{
    private readonly IDataLayerReportPreDeployClient _preDeployClient = Substitute.For<IDataLayerReportPreDeployClient>();
    private readonly IOptions<DataLayerReportPreDeploySettings> _preDeploySettings;
    private readonly HttpContext _httpContext = new DefaultHttpContext();
    private readonly IBackgroundJobClient _backgroundJobClient = Substitute.For<IBackgroundJobClient>();

    public PostChargesReportEndpointTests()
    {
        _preDeploySettings = Options.Create(new DataLayerReportPreDeploySettings
        {
            EnabledReports = string.Join(',', ReportTypeEnum.ChargesList.Name, ReportTypeEnum.ChargesEvents.Name),
            IsPreDeployWorker = false
        });

        _httpContext.Request.Headers["X-Report-Correlation-Id"] = "corr-id";
    }

    [Fact]
    public void PostHandler_WithElasticRequest_ShouldReturnElasticJobId()
    {
        // Arrange
        var request = CreateRequest(s3Flag: null);
        _backgroundJobClient.Create(Arg.Any<Job>(), Arg.Any<IState>()).Returns("job-123");

        // Act
        var result = InvokeHandler(request);

        // Assert
        var ok = Assert.IsType<Microsoft.AspNetCore.Http.HttpResults.Ok<PostChargesReportResponse>>(result);
        var payload = ok.Value ?? throw new InvalidOperationException("Missing response payload");
        Assert.False(string.IsNullOrEmpty(payload.ReportId));
        _preDeployClient.DidNotReceiveWithAnyArgs().PostChargesReport(default!, default!, default);
    }

    [Fact]
    public void PostHandler_WithS3Flag_ShouldReturnDispatchFormattedId()
    {
        // Arrange
        var request = CreateRequest(s3Flag: "true");
        _backgroundJobClient.Create(Arg.Any<Job>(), Arg.Any<IState>()).Returns("dispatch-1");

        // Act
        var result = InvokeHandler(request);

        // Assert
        var ok = Assert.IsType<Microsoft.AspNetCore.Http.HttpResults.Ok<PostChargesReportResponse>>(result);
        var payload = ok.Value ?? throw new InvalidOperationException("Missing response payload");
        Assert.EndsWith("-s3", payload.ReportId);
    }

    [Fact]
    public void PostHandler_WithS3Flag_ShouldInvokePreDeployWhenEnabled()
    {
        // Arrange
        var request = CreateRequest(s3Flag: "true");
        _backgroundJobClient.Create(Arg.Any<Job>(), Arg.Any<IState>()).Returns("dispatch-2");

        // Act
        InvokeHandler(request);

        // Assert
        _preDeployClient.Received(1).PostChargesReport(
            request,
            Arg.Is<string>(id => id.EndsWith("-s3-preDeploy")),
            Arg.Any<CancellationToken>());
    }

    [Fact]
    public void PostHandler_ShouldSkipPreDeployWhenWorkerIsPreDeploy()
    {
        // Arrange
        var request = CreateRequest(s3Flag: "true");
        _backgroundJobClient.Create(Arg.Any<Job>(), Arg.Any<IState>()).Returns("dispatch-3");

        var preDeployOptions = Options.Create(new DataLayerReportPreDeploySettings
        {
            IsPreDeployWorker = true,
            EnabledReports = ReportTypeEnum.ChargesList.Name
        });

        // Act
        InvokeHandler(request, preDeployOptions);

        // Assert
        _preDeployClient.DidNotReceiveWithAnyArgs().PostChargesReport(default!, default!, default);
    }

    private IResult InvokeHandler(PostChargesReportRequest request, IOptions<DataLayerReportPreDeploySettings>? options = null)
    {
        options ??= _preDeploySettings;

        return typeof(PostChargesReportEndpoint)
            .GetMethod("PostHandler", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static)!
            .Invoke(null, new object[] { request, _preDeployClient, options, _backgroundJobClient, _httpContext }) as IResult
            ?? throw new InvalidOperationException("Handler invocation failed");
    }

    private static PostChargesReportRequest CreateRequest(string? s3Flag)
    {
        return new PostChargesReportRequest
        {
            StartDate = DateTimeOffset.UtcNow.AddDays(-1),
            EndDate = DateTimeOffset.UtcNow,
            Document = "123",
            Organizations = "stone",
            ReportType = ReportTypeEnum.ChargesList.Name,
            S3Flag = s3Flag,
            MerchantId = "merchant",
            IsSandbox = true
        };
    }
}

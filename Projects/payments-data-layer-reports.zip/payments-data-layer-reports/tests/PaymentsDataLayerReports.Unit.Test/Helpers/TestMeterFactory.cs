using System.Diagnostics.Metrics;

namespace PaymentsDataLayerReports.Unit.Test.Helpers;

/// <summary>
/// Test implementation of IMeterFactory for unit testing.
/// Provides a simple factory that creates real Meter instances for testing purposes.
/// </summary>
public class TestMeterFactory : IMeterFactory
{
    public Meter Create(MeterOptions options)
    {
        return new Meter(options);
    }

    public void Dispose()
    {
        // No-op for testing - no resources to clean up
    }
}

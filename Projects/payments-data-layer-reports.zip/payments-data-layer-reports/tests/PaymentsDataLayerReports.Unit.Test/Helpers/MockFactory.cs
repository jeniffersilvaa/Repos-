using Hangfire;
using Hangfire.Common;
using Hangfire.Server;
using Hangfire.Storage;
using NSubstitute;

namespace PaymentsDataLayerReports.Unit.Test.Helpers;

/// <summary>
/// Factory class for creating Hangfire mock objects used across multiple test classes.
/// Centralizes the creation of common mocks to avoid duplication.
/// </summary>
public static class MockFactory
{
    /// <summary>
    /// Creates a mock PerformContext with a specified job ID.
    /// </summary>
    /// <param name="jobId">The job ID to use. Default is "test-job-id".</param>
    /// <returns>A configured mock PerformContext.</returns>
    public static PerformContext CreatePerformContext(string jobId = "test-job-id")
    {
        var backgroundJob = CreateBackgroundJob(jobId);

        return Substitute.For<PerformContext>(
            Substitute.For<IStorageConnection>(),
            backgroundJob,
            Substitute.For<IJobCancellationToken>()
        );
    }

    /// <summary>
    /// Creates a mock BackgroundJob with a specified job ID.
    /// </summary>
    /// <param name="jobId">The job ID to use. Default is "test-job-id".</param>
    /// <param name="createdAt">The creation timestamp. Default is DateTime.UtcNow.</param>
    /// <returns>A configured mock BackgroundJob.</returns>
    public static BackgroundJob CreateBackgroundJob(
        string jobId = "test-job-id",
        DateTime? createdAt = null)
    {
        var job = Job.FromExpression(() => Console.WriteLine());
        var timestamp = createdAt ?? DateTime.UtcNow;

        return Substitute.For<BackgroundJob>(jobId, job, timestamp);
    }

    /// <summary>
    /// Creates a pair of mock PerformContext and BackgroundJob with the same job ID.
    /// Useful when you need both objects with matching IDs.
    /// </summary>
    /// <param name="jobId">The job ID to use. Default is "test-job-id".</param>
    /// <returns>A tuple containing the BackgroundJob and PerformContext.</returns>
    public static (BackgroundJob BackgroundJob, PerformContext PerformContext) CreatePerformContextPair(
        string jobId = "test-job-id")
    {
        var backgroundJob = CreateBackgroundJob(jobId);
        var performContext = Substitute.For<PerformContext>(
            Substitute.For<IStorageConnection>(),
            backgroundJob,
            Substitute.For<IJobCancellationToken>()
        );

        return (backgroundJob, performContext);
    }
}

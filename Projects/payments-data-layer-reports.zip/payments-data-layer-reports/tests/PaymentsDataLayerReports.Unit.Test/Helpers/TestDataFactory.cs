using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Services.DeltaTablePartitionBuilder;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.Models;
using PaymentsDataLayerReports.Application.Workers.ChargeReportWorker;

namespace PaymentsDataLayerReports.Unit.Test.Helpers;

public static class TestDataFactory
{
    #region ReportMetadata

    /// <summary>
    /// Cria um objeto ReportMetadata válido para testes com valores padrão configuráveis.
    /// </summary>
    /// <param name="reportId">ID único do relatório. Se null, usa "test-report-123"</param>
    /// <param name="dispatchId">ID do dispatch associado ao relatório</param>
    /// <param name="status">Status do relatório. Se null, usa WorkerStatesEnum.Processing</param>
    /// <param name="processorQueueName">Nome da fila de processamento</param>
    /// <param name="reportType">Tipo do relatório (ex: "charges_list")</param>
    /// <param name="startDate">Data inicial do período do relatório</param>
    /// <param name="endDate">Data final do período do relatório</param>
    /// <param name="reportSortColumnIndex">Índice da coluna de ordenação do relatório</param>
    /// <returns>Instância de ReportMetadata configurada para testes</returns>
    public static ReportMetadata CreateValidReportMetadata(
        string? reportId = null,
        string dispatchId = "dispatch-123",
        string? status = null,
        string processorQueueName = "test-queue",
        string reportType = "charges_list",
        DateTime? startDate = null,
        DateTime? endDate = null,
        int reportSortColumnIndex = 0)
    {
        var chargeParams = CreateChargeReportsWorkerParameters(
            reportType: reportType
        );

        return new ReportMetadata
        {
            ReportId = reportId ?? "test-report-123",
            DispatchId = dispatchId,
            Status = status ?? WorkerStatesEnum.Processing.ToString(),
            CreatedAt = DateTime.Now.AddMinutes(-10),
            ReportSortColumnIndex = reportSortColumnIndex,
            FileFormat = "csv",
            ProcessorQueueName = processorQueueName,
            ChargeReportParameters = chargeParams
        };
    }

    #endregion

    #region ChargeReportsWorkerParameters

    /// <summary>
    /// Cria um objeto ChargeReportsWorkerParameters com parâmetros de filtro configuráveis para testes.
    /// </summary>
    /// <param name="reportType">Tipo do relatório (ex: "charges_list")</param>
    /// <param name="startDate">Data inicial do período. Se null, usa 7 dias atrás</param>
    /// <param name="endDate">Data final do período. Se null, usa hoje</param>
    /// <param name="organizations">IDs das organizações separados por vírgula</param>
    /// <param name="document">Documento (CPF/CNPJ) para filtro</param>
    /// <param name="accountId">ID da conta para filtro</param>
    /// <param name="merchantId">ID do merchant para filtro</param>
    /// <param name="isSandbox">Indica se é ambiente sandbox</param>
    /// <param name="withFailed">Indica se deve incluir transações falhadas</param>
    /// <param name="allIds">IDs diversos para filtro</param>
    /// <param name="lastOperationStatus">Status da última operação</param>
    /// <param name="minAmount">Valor mínimo em centavos</param>
    /// <param name="maxAmount">Valor máximo em centavos</param>
    /// <param name="customers">IDs de clientes para filtro</param>
    /// <param name="acquirers">Adquirentes para filtro</param>
    /// <param name="bankNames">Nomes de bancos para filtro</param>
    /// <param name="cardBrands">Bandeiras de cartão para filtro</param>
    /// <param name="fundingSources">Fontes de funding para filtro</param>
    /// <param name="platformName">Nome da plataforma</param>
    /// <param name="antifraudStatus">Status do antifraude</param>
    /// <param name="paymentMethods">Métodos de pagamento para filtro</param>
    /// <param name="affiliationCodes">Códigos de afiliação para filtro</param>
    /// <returns>Instância de ChargeReportsWorkerParameters configurada para testes</returns>
    public static ChargeReportsWorkerParameters CreateChargeReportsWorkerParameters(
        string reportType = "charges_list",
        string organizations = "org-123",
        string? document = "12345678900",
        string? accountId = "acc-123",
        string? merchantId = "merch-123",
        bool? isSandbox = false,
        bool? withFailed = null,
        string? allIds = null,
        string? lastOperationStatus = null,
        int? minAmount = null,
        int? maxAmount = null,
        string? customers = null,
        string? acquirers = null,
        string? bankNames = null,
        string? cardBrands = null,
        string? fundingSources = null,
        string? platformName = null,
        string? antifraudStatus = null,
        string? paymentMethods = null,
        string? affiliationCodes = null)
    {
        return new ChargeReportsWorkerParameters
        {
            ReportType = reportType,
            Organizations = organizations,
            Document = document,
            AccountId = accountId,
            MerchantId = merchantId,
            IsSandbox = isSandbox,
            WithFailed = withFailed,
            AllIds = allIds,
            LastOperationStatus = lastOperationStatus,
            MinAmount = minAmount,
            MaxAmount = maxAmount,
            Customers = customers,
            Acquirers = acquirers,
            BankNames = bankNames,
            CardBrands = cardBrands,
            FundingSources = fundingSources,
            PlatformName = platformName,
            AntifraudStatus = antifraudStatus,
            PaymentMethods = paymentMethods,
            AffiliationCodes = affiliationCodes
        };
    }

    #endregion


    #region DeltaTablePartitionSet

    /// <summary>
    /// Cria um DeltaTablePartitionSet válido com partições configuráveis para testes.
    /// </summary>
    /// <param name="partitionIdReferences">Lista de referências de IDs de partição. Se null, usa ["org-123", "org-456"]</param>
    /// <param name="partitionIdReferenceType">Tipo de referência da partição (ex: "document", "organization")</param>
    /// <param name="tableName">Nome da tabela Delta (ex: "charges_events_by_created_at")</param>
    /// <returns>Instância de DeltaTablePartitionSet configurada para testes</returns>
    public static DeltaTablePartitionSet CreateValidPartitionSet(
        List<string>? partitionIdReferences = null,
        string partitionIdReferenceType = "document",
        string tableName = "charges_events_by_created_at")
    {
        var references = partitionIdReferences ?? ["org-123", "org-456"];

        return new DeltaTablePartitionSet
        {
            PartitionIdReferences = references,
            PartitionIdReferenceType = partitionIdReferenceType,
            Partitions = [.. references.Select(reference => new DeltaTablePartition(tableName, reference))]
        };
    }

    /// <summary>
    /// Cria um DeltaTablePartitionSet vazio para testes de cenários sem partições.
    /// </summary>
    /// <param name="partitionIdReferenceType">Tipo de referência da partição</param>
    /// <returns>Instância de DeltaTablePartitionSet vazia</returns>
    public static DeltaTablePartitionSet CreateEmptyPartitionSet(
        string partitionIdReferenceType = "document")
    {
        return new DeltaTablePartitionSet
        {
            PartitionIdReferences = [],
            PartitionIdReferenceType = partitionIdReferenceType,
            Partitions = []
        };
    }

    #endregion

    #region GenerateReportInput

    /// <summary>
    /// Cria um objeto GenerateReportInput completo para testes de geração de relatórios.
    /// Combina ReportMetadata, PartitionSet e parâmetros de filtro em um único input.
    /// </summary>
    /// <param name="reportId">ID único do relatório</param>
    /// <param name="partitionDate">Data da partição a ser processada. Se null, usa hoje</param>
    /// <param name="partitionSet">Conjunto de partições. Se null, cria um conjunto válido padrão</param>
    /// <param name="reportType">Tipo do relatório</param>
    /// <param name="jobId">ID do job Hangfire</param>
    /// <param name="cancellationToken">Token de cancelamento. Se null, usa CancellationToken.None</param>
    /// <param name="withFailed">Indica se deve incluir transações falhadas</param>
    /// <param name="allIds">IDs diversos para filtro</param>
    /// <param name="lastOperationStatus">Status da última operação</param>
    /// <param name="minAmount">Valor mínimo em centavos</param>
    /// <param name="maxAmount">Valor máximo em centavos</param>
    /// <param name="customers">IDs de clientes para filtro</param>
    /// <param name="acquirers">Adquirentes para filtro</param>
    /// <param name="bankNames">Nomes de bancos para filtro</param>
    /// <param name="cardBrands">Bandeiras de cartão para filtro</param>
    /// <param name="fundingSources">Fontes de funding para filtro</param>
    /// <param name="platformName">Nome da plataforma</param>
    /// <param name="antifraudStatus">Status do antifraude</param>
    /// <param name="paymentMethods">Métodos de pagamento para filtro</param>
    /// <param name="affiliationCodes">Códigos de afiliação para filtro</param>
    /// <param name="accountId">ID da conta para filtro</param>
    /// <param name="organizations">IDs das organizações</param>
    /// <param name="startDate">Data inicial do período</param>
    /// <param name="endDate">Data final do período</param>
    /// <returns>Instância de GenerateReportInput configurada para testes</returns>
    public static GenerateReportInput CreateGenerateReportInput(
        string? reportId = null,
        DateTime? partitionDate = null,
        DeltaTablePartitionSet? partitionSet = null,
        string reportType = "charges_list",
        string jobId = "job-123",
        CancellationToken? cancellationToken = null,
        bool? withFailed = null,
        string? allIds = null,
        string? lastOperationStatus = null,
        int? minAmount = null,
        int? maxAmount = null,
        string? customers = null,
        string? acquirers = null,
        string? bankNames = null,
        string? cardBrands = null,
        string? fundingSources = null,
        string? platformName = null,
        string? antifraudStatus = null,
        string? paymentMethods = null,
        string? affiliationCodes = null,
        string? accountId = null,
        string? organizations = null,
        DateTime? startDate = null,
        DateTime? endDate = null)
    {
        var date = partitionDate ?? DateTime.Today;
        var actualReportId = reportId ?? $"test-report-{Guid.NewGuid()}";

        var chargeReportsWorkerParameters = CreateChargeReportsWorkerParameters(
            reportType: reportType,
            organizations: organizations ?? "org-123",
            accountId: accountId,
            withFailed: withFailed,
            allIds: allIds,
            lastOperationStatus: lastOperationStatus,
            minAmount: minAmount,
            maxAmount: maxAmount,
            customers: customers,
            acquirers: acquirers,
            bankNames: bankNames,
            cardBrands: cardBrands,
            fundingSources: fundingSources,
            platformName: platformName,
            antifraudStatus: antifraudStatus,
            paymentMethods: paymentMethods,
            affiliationCodes: affiliationCodes);

        var reportMetadata = CreateValidReportMetadata(
            reportId: actualReportId,
            reportType: reportType,
            startDate: startDate,
            endDate: endDate);

        // Update the ChargeReportParameters with the custom parameters
        reportMetadata.ChargeReportParameters = chargeReportsWorkerParameters;

        return new GenerateReportInput
        {
            PartitionDate = date,
            PartitionSet = partitionSet ?? CreateValidPartitionSet(),
            ReportMetadata = reportMetadata,
            CancellationToken = cancellationToken ?? CancellationToken.None,
            JobId = jobId
        };
    }

    #endregion

    #region Charge Events

    /// <summary>
    /// Cria um evento de cobrança completo com transação de cartão de crédito para testes.
    /// Inclui todos os campos necessários: merchant, card_transaction, customer, etc.
    /// </summary>
    /// <returns>Dicionário representando um evento de cobrança com cartão completo</returns>
    public static Dictionary<string, object> CreateCompleteCardChargeEvent()
    {
        return new Dictionary<string, object>
        {
            ["id"] = "charge-complete-card",
            ["event_datetime"] = "2024-01-15T10:30:00Z",
            ["initiator_id"] = "initiator-123",
            ["attempt_count"] = 1,
            ["product"] = "payment",
            ["origin"] = "api",
            ["origin_id"] = "origin-456",
            ["amount"] = 10000,
            ["payment_method"] = "credit_card",
            ["created_at"] = "2024-01-15T10:30:00Z",
            ["platform_name"] = "stone",
            ["code"] = "00",
            ["status"] = "succeeded",
            ["gateway"] = "stone",
            ["merchant"] = new Dictionary<string, object>
            {
                ["organization"] = "org-123",
                ["user_id"] = "user-456",
                ["document"] = "12345678900",
                ["affiliation_key"] = "aff-key-789",
                ["account_id"] = "acc-123",
                ["merchant_id"] = "merch-456"
            },
            ["card_transaction"] = new Dictionary<string, object>
            {
                ["type"] = "credit",
                ["transaction_id"] = "txn-card-123",
                ["authorization_code"] = "AUTH123",
                ["installments"] = 3,
                ["card"] = new Dictionary<string, object>
                {
                    ["brand"] = "visa",
                    ["first_six_digits"] = "424242",
                    ["last_four_digits"] = "4242",
                    ["holder_name"] = "JOHN DOE"
                },
                ["customer"] = new Dictionary<string, object>
                {
                    ["name"] = "John Doe",
                    ["document"] = "11122233344",
                    ["email"] = "john@example.com"
                }
            }
        };
    }

    /// <summary>
    /// Cria um evento de cobrança completo com transação de boleto para testes.
    /// Inclui campos específicos de boleto: barcode, our_number, expire_at, etc.
    /// </summary>
    /// <returns>Dicionário representando um evento de cobrança com boleto completo</returns>
    public static Dictionary<string, object> CreateCompleteBoletoChargeEvent()
    {
        return new Dictionary<string, object>
        {
            ["id"] = "charge-complete-boleto",
            ["amount"] = 5000,
            ["payment_method"] = "boleto",
            ["created_at"] = "2024-01-15T10:30:00Z",
            ["status"] = "pending",
            ["merchant"] = new Dictionary<string, object>
            {
                ["document"] = "98765432100",
                ["account_id"] = "acc-789"
            },
            ["boleto_transaction"] = new Dictionary<string, object>
            {
                ["type"] = "boleto",
                ["transaction_id"] = "txn-boleto-456",
                ["our_number"] = "12345678901",
                ["barcode"] = "34191234567890123456789012345678901234",
                ["expire_at"] = "2024-12-31",
                ["customer"] = new Dictionary<string, object>
                {
                    ["name"] = "Maria Silva",
                    ["document"] = "55566677788",
                    ["email"] = "maria@example.com"
                }
            }
        };
    }

    /// <summary>
    /// Cria um evento de cobrança completo com transação PIX para testes.
    /// Inclui campos específicos de PIX: e2e_id, pix_key, paid_amount, etc.
    /// </summary>
    /// <returns>Dicionário representando um evento de cobrança com PIX completo</returns>
    public static Dictionary<string, object> CreateCompletePixChargeEvent()
    {
        return new Dictionary<string, object>
        {
            ["id"] = "charge-complete-pix",
            ["amount"] = 15000,
            ["payment_method"] = "pix",
            ["created_at"] = "2024-01-15T10:30:00Z",
            ["status"] = "succeeded",
            ["merchant"] = new Dictionary<string, object>
            {
                ["document"] = "11122233344",
                ["account_id"] = "acc-pix-123"
            },
            ["pix_transaction"] = new Dictionary<string, object>
            {
                ["type"] = "pix",
                ["transaction_id"] = "txn-pix-789",
                ["e2e_id"] = "E12345678202401151030123456789012",
                ["pix_key"] = "11122233344",
                ["paid_amount"] = 15000,
                ["customer"] = new Dictionary<string, object>
                {
                    ["name"] = "Carlos Oliveira",
                    ["document"] = "99988877766",
                    ["email"] = "carlos@example.com"
                }
            }
        };
    }

    /// <summary>
    /// Cria uma lista de eventos de cobrança simplificados para testes de volume.
    /// Útil para testar processamento em lote e performance.
    /// </summary>
    /// <param name="count">Quantidade de eventos a serem criados</param>
    /// <param name="startIndex">Índice inicial para geração de IDs únicos</param>
    /// <returns>Lista de dicionários representando eventos de cobrança</returns>
    public static List<Dictionary<string, object>> CreateChargeEventsList(int count, int startIndex = 0)
    {
        var events = new List<Dictionary<string, object>>();

        for (int i = 0; i < count; i++)
        {
            var index = startIndex + i;
            events.Add(new Dictionary<string, object>
            {
                ["id"] = $"charge-{index}",
                ["amount"] = 1000 + index,
                ["payment_method"] = "credit_card",
                ["status"] = "succeeded",
                ["created_at"] = DateTime.UtcNow.AddMinutes(-index).ToString("o")
            });
        }

        return events;
    }

    #endregion

    #region Utility Methods

    /// <summary>
    /// Cria um diretório temporário único para testes de I/O.
    /// O diretório é criado em Path.GetTempPath() com um GUID único.
    /// </summary>
    /// <returns>Caminho completo do diretório temporário criado</returns>
    public static string CreateTempDirectory()
    {
        var tempDir = Path.Combine(Path.GetTempPath(), $"test-{Guid.NewGuid()}");
        Directory.CreateDirectory(tempDir);
        return tempDir;
    }

    /// <summary>
    /// Remove arquivos e diretórios de teste de forma segura (best effort).
    /// Não lança exceções se a limpeza falhar.
    /// </summary>
    /// <param name="inputDir">Diretório de entrada a ser removido</param>
    /// <param name="outputFile">Arquivo de saída a ser removido</param>
    public static void CleanupTestFiles(string? inputDir, string? outputFile)
    {
        try
        {
            if (inputDir != null && Directory.Exists(inputDir))
                Directory.Delete(inputDir, true);

            if (outputFile != null && File.Exists(outputFile))
                File.Delete(outputFile);
        }
        catch
        {
            // Best effort cleanup
        }
    }

    #endregion
}

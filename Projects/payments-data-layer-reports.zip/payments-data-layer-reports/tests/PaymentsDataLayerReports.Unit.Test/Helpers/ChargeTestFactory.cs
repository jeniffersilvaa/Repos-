using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Entities.Models.Charge;

namespace PaymentsDataLayerReports.Unit.Test.Helpers;

public static class ChargeTestFactory
{
    private static readonly DateTimeOffset DefaultCreatedAt =
        new(2025, 6, 15, 15, 30, 0, TimeSpan.Zero);

    public static Merchant CreateMerchant(
        string document = "12345678000199",
        string affiliationCode = "STONE123")
    {
        return new Merchant(
            Organization: "OrgTest",
            Document: document,
            UserId: "user-001",
            AffiliationKey: "aff-key-001",
            AffiliationCode: affiliationCode,
            AccountId: "acc-001",
            MerchantId: "merchant-001"
        );
    }

    public static Card CreateCard(
        string brand = "Visa",
        string firstSixDigits = "411111",
        string lastFourDigits = "1111",
        string entryMode = "emv",
        string holderName = "JOAO SILVA")
    {
        return new Card(
            Brand: brand,
            BrandId: 1,
            FirstSixDigits: firstSixDigits,
            LastFourDigits: lastFourDigits,
            EntryMode: entryMode,
            HolderName: holderName,
            ExpMonth: "12",
            ExpYear: "2030",
            CountryCode: 76,
            CurrencyCode: 986,
            NumberToken: null,
            Label: null
        );
    }

    public static CardTerminal CreateCardTerminal(
        string type = "standalone_device",
        string serialNumber = "SN-12345")
    {
        return new CardTerminal(Type: type, SerialNumber: serialNumber);
    }

    public static PixTerminal CreatePixTerminal(
        string? type = "standalone_device",
        string? serialNumber = "SN-PIX-001")
    {
        return new PixTerminal(Type: type, SerialNumber: serialNumber);
    }

    public static Payer CreatePayer(string? name = "Maria Oliveira")
    {
        return new Payer(
            Name: name,
            DocumentType: "cpf",
            Document: "99988877766",
            Ispb: null,
            InstitutionName: "Banco Teste"
        );
    }

    public static Bank CreateBank(string name = "Banco do Brasil", string code = "001")
    {
        return new Bank(Code: code, Name: name);
    }

    public static CardTransaction CreateCardTransaction(
        int? installments = 3,
        string type = "credit",
        string fundingSource = "credit",
        int? feeAmount = 500,
        decimal? fullMdrAmount = 300m,
        decimal? fullMdrRefundAmount = 0m,
        decimal? fullRavAmount = 200m,
        decimal? fullRavRefundAmount = 0m,
        int? chargebackAmount = 0,
        int? chargebackRefundAmount = 0,
        int canceledAmount = 0,
        Card? card = null,
        CardTerminal? terminal = null,
        IReadOnlyList<CardDetail>? details = null,
        List<ChargeFinancialMovement>? financialMovements = null)
    {
        return new CardTransaction(
            Type: type,
            FundingSource: fundingSource,
            TransactionId: "txn-card-001",
            FailedAmount: null,
            AuthorizedAmount: 10000,
            CapturedAmount: 10000,
            CanceledAmount: canceledAmount,
            ChargebackAmount: chargebackAmount,
            ChargebackRefundAmount: chargebackRefundAmount,
            AuthorizationCode: "AUTH001",
            AuthorizedState: null,
            Installments: installments,
            InstallmentsType: "with_interest",
            SchemeBusinessModel: "default",
            FeeAmount: feeAmount,
            FullFeeAmount: null,
            MdrAmount: null,
            FullMdrAmount: fullMdrAmount,
            MdrRefundAmount: null,
            FullMdrRefundAmount: fullMdrRefundAmount,
            FullFcAmount: null,
            FullFcRefundAmount: null,
            RavAmount: null,
            FullRavAmount: fullRavAmount,
            RavRefundAmount: null,
            FullRavRefundAmount: fullRavRefundAmount,
            Customer: null,
            Card: card ?? CreateCard(),
            Terminal: terminal ?? CreateCardTerminal(),
            Last: null,
            Details: details ?? new List<CardDetail>(),
            FinancialMovements: financialMovements
        );
    }

    public static PixTransaction CreatePixTransaction(
        int paidAmount = 5000,
        int feeAmount = 100,
        string type = "dynamic",
        string e2eId = "E2E-PIX-001",
        int? canceledAmount = 0,
        Payer? payer = null,
        PixTerminal? terminal = null,
        IReadOnlyList<PixDetail>? details = null)
    {
        return new PixTransaction(
            Type: type,
            TransactionId: "txn-pix-001",
            E2eId: e2eId,
            PixKey: "chave-pix-123",
            IsPixSaleKey: true,
            PixKeyNickname: null,
            PaidAmount: paidAmount,
            FineAmount: null,
            InterestAmount: null,
            DiscountAmount: null,
            ReductionAmount: null,
            CanceledAmount: canceledAmount,
            FeeAmount: feeAmount,
            FullFeeAmount: null,
            FullMdrAmount: null,
            FullMdrRefundAmount: null,
            FullRavAmount: null,
            FullRavRefundAmount: null,
            FullFcAmount: null,
            FullFcRefundAmount: null,
            ExpireAt: null,
            PaymentLimitPeriodDays: null,
            BusinessDaysOnly: null,
            ExpiresIn: null,
            Fine: null,
            Interest: null,
            Discounts: null,
            Reduction: null,
            RequestForPayer: null,
            AdditionalData: null,
            Customer: new PixCustomer(null, null, null, null, null, null),
            Payer: payer ?? CreatePayer(),
            Terminal: terminal ?? CreatePixTerminal(),
            Last: null,
            Details: details ?? new List<PixDetail>()
        );
    }

    public static BoletoTransaction CreateBoletoTransaction(
        int? feeAmount = 350,
        int canceledAmount = 0,
        Bank? bank = null,
        IReadOnlyList<BoletoDetail>? details = null)
    {
        return new BoletoTransaction(
            Type: "normal",
            TransactionId: "txn-boleto-001",
            OurNumber: "123456",
            PaidAmount: 10000,
            FineAmount: null,
            InterestAmount: null,
            DiscountAmount: null,
            CanceledAmount: canceledAmount,
            FeeAmount: feeAmount,
            FullFeeAmount: null,
            FullMdrAmount: null,
            FullMdrRefundAmount: null,
            FullRavAmount: null,
            FullRavRefundAmount: null,
            FullFcAmount: null,
            FullFcRefundAmount: null,
            ExpireAt: "2025-07-15",
            LimitDate: null,
            Barcode: null,
            WritableLine: null,
            Instructions: null,
            Url: null,
            Bank: bank ?? CreateBank(),
            Receiver: null,
            Fine: null,
            Interest: null,
            Discounts: null,
            DocumentNumber: null,
            PaidAt: null,
            Customer: null,
            Last: null,
            Details: details ?? new List<BoletoDetail>()
        );
    }

    public static Charge CreateCardCharge(
        int amount = 10000,
        string status = "paid",
        DateTimeOffset? createdAt = null,
        Merchant? merchant = null,
        CardTransaction? cardTransaction = null)
    {
        return new Charge(
            Id: "charge-card-001",
            InitiatorId: "initiator-001",
            Product: null,
            Origin: null,
            OriginId: null,
            Amount: amount,
            UpdatedAmount: null,
            NetAmount: null,
            FullNetAmount: null,
            Status: status,
            PaymentMethod: "card",
            CreatedAt: createdAt ?? DefaultCreatedAt,
            PlatformName: null,
            AttemptCount: null,
            Gateway: null,
            GatewayOrderId: null,
            Code: null,
            AllIds: null,
            Merchant: merchant ?? CreateMerchant(),
            Split: new List<Split>(),
            CardTransaction: cardTransaction ?? CreateCardTransaction(),
            PixTransaction: null,
            BoletoTransaction: null,
            CashTransaction: null
        );
    }

    public static Charge CreatePixCharge(
        int amount = 5000,
        string status = "paid",
        DateTimeOffset? createdAt = null,
        Merchant? merchant = null,
        PixTransaction? pixTransaction = null)
    {
        return new Charge(
            Id: "charge-pix-001",
            InitiatorId: "initiator-001",
            Product: null,
            Origin: null,
            OriginId: null,
            Amount: amount,
            UpdatedAmount: null,
            NetAmount: null,
            FullNetAmount: null,
            Status: status,
            PaymentMethod: "pix",
            CreatedAt: createdAt ?? DefaultCreatedAt,
            PlatformName: null,
            AttemptCount: null,
            Gateway: null,
            GatewayOrderId: null,
            Code: null,
            AllIds: null,
            Merchant: merchant ?? CreateMerchant(),
            Split: new List<Split>(),
            CardTransaction: null,
            PixTransaction: pixTransaction ?? CreatePixTransaction(),
            BoletoTransaction: null,
            CashTransaction: null
        );
    }

    public static Charge CreateBoletoCharge(
        int amount = 10000,
        string status = "paid",
        DateTimeOffset? createdAt = null,
        Merchant? merchant = null,
        BoletoTransaction? boletoTransaction = null)
    {
        return new Charge(
            Id: "charge-boleto-001",
            InitiatorId: "initiator-001",
            Product: null,
            Origin: null,
            OriginId: null,
            Amount: amount,
            UpdatedAmount: null,
            NetAmount: null,
            FullNetAmount: null,
            Status: status,
            PaymentMethod: "boleto",
            CreatedAt: createdAt ?? DefaultCreatedAt,
            PlatformName: null,
            AttemptCount: null,
            Gateway: null,
            GatewayOrderId: null,
            Code: null,
            AllIds: null,
            Merchant: merchant ?? CreateMerchant(),
            Split: new List<Split>(),
            CardTransaction: null,
            PixTransaction: null,
            BoletoTransaction: boletoTransaction ?? CreateBoletoTransaction(),
            CashTransaction: null
        );
    }

    public static Charge CreateUnsupportedCharge()
    {
        return new Charge(
            Id: "charge-unsupported-001",
            InitiatorId: "initiator-001",
            Product: null,
            Origin: null,
            OriginId: null,
            Amount: 1000,
            UpdatedAmount: null,
            NetAmount: null,
            FullNetAmount: null,
            Status: "paid",
            PaymentMethod: "crypto",
            CreatedAt: DefaultCreatedAt,
            PlatformName: null,
            AttemptCount: null,
            Gateway: null,
            GatewayOrderId: null,
            Code: null,
            AllIds: null,
            Merchant: CreateMerchant(),
            Split: new List<Split>(),
            CardTransaction: null,
            PixTransaction: null,
            BoletoTransaction: null,
            CashTransaction: null
        );
    }

    public static List<ChargeFinancialMovement> CreateFinancialMovements(
        decimal mdrAmount = -150m,
        decimal ravAmount = -50m,
        decimal cetDiscountRateAmount = -30m,
        decimal cetPrepaymentFeeAmount = -20m,
        decimal? turboAmount = null)
    {
        return
        [
            new ChargeFinancialMovement(
                Operation: "capture",
                OperationId: "op-001",
                DetailOperationId: null,
                CurrentDueDate: null,
                OriginalDueDate: null,
                PaymentOwnerDocument: null,
                SettlementStatus: null,
                Category: null,
                InstallmentNumber: 1,
                Amount: new FinancialMovementAmount(
                    Gross: 10000m,
                    Net: 9500m,
                    DiscountRate: new FinancialMovementFee(
                        FeeType: "mdr",
                        Fee: 1.5m,
                        EffectiveFee: 1.5m,
                        Amount: mdrAmount
                    ),
                    PrepaymentFee: new FinancialMovementFee(
                        FeeType: "rav",
                        Fee: 0.5m,
                        EffectiveFee: 0.5m,
                        Amount: ravAmount
                    ),
                    FraudCoverage: null,
                    PrepaymentFeeTurbo: turboAmount.HasValue
                        ? new FinancialMovementFee("turbo", 2.5m, 2.5m, turboAmount)
                        : null
                ),
                Id: "fm-001",
                PaymentMethod: "card",
                SplitRuleId: null,
                BulkAnticipationId: null,
                PaymentOwnerId: null,
                RecipientId: null,
                PaymentOwnerStoneAccount: null,
                CreatedAt: null,
                LatestEventDatetime: null
            ),
            new ChargeFinancialMovement(
                Operation: "capture",
                OperationId: "op-002",
                DetailOperationId: null,
                CurrentDueDate: null,
                OriginalDueDate: null,
                PaymentOwnerDocument: null,
                SettlementStatus: null,
                Category: null,
                InstallmentNumber: 2,
                Amount: new FinancialMovementAmount(
                    Gross: 10000m,
                    Net: 9500m,
                    DiscountRate: new FinancialMovementFee(
                        FeeType: "cet",
                        Fee: 0.3m,
                        EffectiveFee: 0.3m,
                        Amount: cetDiscountRateAmount
                    ),
                    PrepaymentFee: new FinancialMovementFee(
                        FeeType: "cet",
                        Fee: 0.2m,
                        EffectiveFee: 0.2m,
                        Amount: cetPrepaymentFeeAmount
                    ),
                    FraudCoverage: null,
                    PrepaymentFeeTurbo: null
                ),
                Id: "fm-002",
                PaymentMethod: "card",
                SplitRuleId: null,
                BulkAnticipationId: null,
                PaymentOwnerId: null,
                RecipientId: null,
                PaymentOwnerStoneAccount: null,
                CreatedAt: null,
                LatestEventDatetime: null
            )
        ];
    }
}

using System.IO;
using Amazon.S3;
using Amazon.S3.Model;
using NSubstitute;

namespace PaymentsDataLayerReports.Benchmark.Mocks;

/// <summary>Factory for creating mock IAmazonS3 that discards all data (null sink).</summary>
public static class NullSinkS3ClientFactory
{
    public static IAmazonS3 Create()
    {
        var mock = Substitute.For<IAmazonS3>();
        var partCounter = 0;

        mock.InitiateMultipartUploadAsync(
            Arg.Any<InitiateMultipartUploadRequest>(),
            Arg.Any<CancellationToken>()
        ).Returns(callInfo =>
        {
            partCounter = 0;
            var request = callInfo.Arg<InitiateMultipartUploadRequest>();
            return Task.FromResult(new InitiateMultipartUploadResponse
            {
                UploadId = Guid.NewGuid().ToString(),
                BucketName = request.BucketName,
                Key = request.Key
            });
        });

        mock.UploadPartAsync(
            Arg.Any<UploadPartRequest>(),
            Arg.Any<CancellationToken>()
        ).Returns(callInfo =>
        {
            var request = callInfo.Arg<UploadPartRequest>();

            request.InputStream?.CopyTo(Stream.Null);

            partCounter++;
            return Task.FromResult(new UploadPartResponse
            {
                ETag = $"\"etag-{partCounter}\"",
                PartNumber = request.PartNumber
            });
        });

        mock.CompleteMultipartUploadAsync(
            Arg.Any<CompleteMultipartUploadRequest>(),
            Arg.Any<CancellationToken>()
        ).Returns(callInfo =>
        {
            var request = callInfo.Arg<CompleteMultipartUploadRequest>();
            return Task.FromResult(new CompleteMultipartUploadResponse
            {
                Location = $"https://{request.BucketName}.s3.amazonaws.com/{request.Key}",
                BucketName = request.BucketName,
                Key = request.Key,
                ETag = "\"final-etag\""
            });
        });

        mock.AbortMultipartUploadAsync(
            Arg.Any<AbortMultipartUploadRequest>(),
            Arg.Any<CancellationToken>()
        ).Returns(Task.FromResult(new AbortMultipartUploadResponse()));

        return mock;
    }
}

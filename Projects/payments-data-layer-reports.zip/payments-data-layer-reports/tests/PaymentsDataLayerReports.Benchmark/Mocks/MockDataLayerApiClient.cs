using PaymentsDataLayerReports.Application.Infra.DataLayerApi;
using PaymentsDataLayerReports.Application.Infra.DataLayerApi.Models;
using PaymentsDataLayerReports.Benchmark.Generators;

namespace PaymentsDataLayerReports.Benchmark.Mocks;

/// <summary>Mock IDataLayerApiClient that returns in-memory generated data with cursor pagination.</summary>
public class MockDataLayerApiClient : IDataLayerApiClient
{
    private readonly int _totalRecords;
    private readonly int _batchSize;
    private int _finMovRecordsReturned;
    private int _chargeRecordsReturned;
    private int _cursorRecordsReturned;

    public MockDataLayerApiClient(int totalRecords, int batchSize = 5000)
    {
        _totalRecords = totalRecords;
        _batchSize = batchSize;
        Reset();
    }

    public void Reset()
    {
        _finMovRecordsReturned = 0;
        _chargeRecordsReturned = 0;
        _cursorRecordsReturned = 0;
    }

    public Task<GetFinancialMovementsResponseModel> GetFinancialMovements(
        GetFinancialMovementsRequestModel request,
        string reportId,
        CancellationToken cancellationToken)
    {
        var remaining = _totalRecords - _finMovRecordsReturned;

        if (remaining <= 0)
        {
            return Task.FromResult(new GetFinancialMovementsResponseModel
            {
                Size = 0,
                Cursor = null,
                Total = _totalRecords,
                Data = []
            });
        }

        var countToReturn = Math.Min(_batchSize, remaining);
        var data = FinancialMovementGenerator.GenerateBatch(countToReturn);
        _finMovRecordsReturned += countToReturn;

        var hasMore = _finMovRecordsReturned < _totalRecords;

        return Task.FromResult(new GetFinancialMovementsResponseModel
        {
            Size = countToReturn,
            Cursor = hasMore ? Guid.NewGuid().ToString() : null,
            Total = _totalRecords,
            Data = data
        });
    }

    public Task<GetChargesResponseModel> GetCharges(
        GetChargesRequestModel request,
        string reportId,
        CancellationToken cancellationToken)
    {
        var remaining = _totalRecords - _chargeRecordsReturned;

        if (remaining <= 0)
        {
            return Task.FromResult(new GetChargesResponseModel
            {
                Size = 0,
                Cursor = null,
                Total = _totalRecords,
                Data = []
            });
        }

        var countToReturn = Math.Min(_batchSize, remaining);
        var data = ChargeGenerator.GenerateBatch(countToReturn);
        _chargeRecordsReturned += countToReturn;

        var hasMore = _chargeRecordsReturned < _totalRecords;

        return Task.FromResult(new GetChargesResponseModel
        {
            Size = countToReturn,
            Cursor = hasMore ? Guid.NewGuid().ToString() : null,
            Total = _totalRecords,
            Data = data
        });
    }

    public Task<GetDataByCursorResponseModel<T>> GetDataByCursor<T>(
        string uri,
        IGetDataByCursorRequestModel request,
        string reportId,
        CancellationToken cancellationToken)
    {
        var remaining = _totalRecords - _cursorRecordsReturned;

        if (remaining <= 0)
        {
            return Task.FromResult(new GetDataByCursorResponseModel<T>
            {
                Size = 0,
                Cursor = null,
                Total = _totalRecords,
                Data = []
            });
        }

        var countToReturn = Math.Min(_batchSize, remaining);
        _cursorRecordsReturned += countToReturn;

        var hasMore = _cursorRecordsReturned < _totalRecords;

        IEnumerable<T> data = typeof(T).Name switch
        {
            nameof(Application.Entities.Charge) => (IEnumerable<T>)ChargeGenerator.GenerateBatch(countToReturn),
            nameof(Application.Entities.FinancialMovement) => (IEnumerable<T>)FinancialMovementGenerator.GenerateBatch(countToReturn),
            _ => Enumerable.Empty<T>()
        };

        return Task.FromResult(new GetDataByCursorResponseModel<T>
        {
            Size = countToReturn,
            Cursor = hasMore ? Guid.NewGuid().ToString() : null,
            Total = _totalRecords,
            Data = data
        });
    }
}

using Hangfire;
using Hangfire.Server;
using Hangfire.Storage;
using NSubstitute;

namespace PaymentsDataLayerReports.Benchmark.Mocks;

/// <summary>Factory for creating mock Hangfire PerformContext.</summary>
public static class MockPerformContextFactory
{
    public static PerformContext Create(string jobId)
    {
        var storage = Substitute.For<JobStorage>();
        var connection = Substitute.For<IStorageConnection>();
        var backgroundJob = new BackgroundJob(jobId, new Hangfire.Common.Job(typeof(object), typeof(object).GetMethod("ToString")!), DateTime.UtcNow);
        var cancellationToken = Substitute.For<IJobCancellationToken>();

        cancellationToken.ShutdownToken.Returns(CancellationToken.None);
        storage.GetConnection().Returns(connection);

        return new PerformContext(storage, connection, backgroundJob, cancellationToken);
    }
}

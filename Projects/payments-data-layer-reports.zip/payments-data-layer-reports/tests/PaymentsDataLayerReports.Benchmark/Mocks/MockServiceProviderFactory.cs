using Microsoft.Extensions.DependencyInjection;
using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Workers.Shared;
using PaymentsDataLayerReports.Application.Workers.Shared.Mappers.Charges;

namespace PaymentsDataLayerReports.Benchmark.Mocks;

public static class MockServiceProviderFactory
{
    public static IServiceProvider Create()
    {
        var services = new ServiceCollection();

        services.AddKeyedScoped<ISaleCsvMapper<Charge>, ChargeCsvMapper>("charges_list");
        services.AddKeyedScoped<ISaleCsvMapper<Charge>, SaleStoneCsvMapper>("sales_stone");
        services.AddKeyedScoped<ISaleCsvMapper<Charge>, SaleTonCsvMapper>("sales_ton");

        return services.BuildServiceProvider();
    }
}

using System.IO;
using NSubstitute;
using PaymentsDataLayerReports.Application.Infra.MultiPartFileUploader.Interfaces;

namespace PaymentsDataLayerReports.Benchmark.Mocks;

/// <summary>Factory for creating mock IMultiPartFileUploader that discards all data (null sink).</summary>
public static class NullSinkMultiPartFileUploaderFactory
{
    public static IMultiPartFileUploader Create()
    {
        var mock = Substitute.For<IMultiPartFileUploader>();

        mock.InitiateMultipartUploadAsync(
            Arg.Any<string>(),
            Arg.Any<string>(),
            Arg.Any<CancellationToken>()
        ).Returns(Task.CompletedTask);

        mock.UploadPartAsync(
            Arg.Any<MemoryStream>(),
            Arg.Any<CancellationToken>()
        ).Returns(callInfo =>
        {
            var stream = callInfo.Arg<MemoryStream>();
            stream?.CopyTo(Stream.Null);
            return Task.CompletedTask;
        });

        mock.CompleteMultipartUploadAsync(
            Arg.Any<CancellationToken>()
        ).Returns(callInfo =>
        {
            return Task.FromResult("https://benchmark-bucket.s3.amazonaws.com/test-file");
        });

        mock.AbortMultipartUploadAsync(
            Arg.Any<CancellationToken>()
        ).Returns(Task.CompletedTask);

        return mock;
    }
}

using Microsoft.IO;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Sinks;

namespace PaymentsDataLayerReports.Benchmark.Mocks;

/// <summary>
/// Simple in-memory implementation of <see cref="IReportOutputSink"/> used to isolate writer benchmarks
/// from the real S3 multipart uploader.
/// </summary>
public sealed class InMemoryReportOutputSink : IReportOutputSink
{
    private readonly RecyclableMemoryStreamManager _memoryStreamManager = new();
    private MemoryStream? _stream;
    private bool _completedOrAborted;

    public long BytesWritten => _stream?.Length ?? 0;

    public Task<Stream> InitializeAsync(string destinationKey, string bucketName, CancellationToken cancellationToken)
    {
        if (_stream != null)
        {
            throw new InvalidOperationException("Sink already initialized.");
        }

        _stream = _memoryStreamManager.GetStream($"report-stream-writer-benchmark-{Guid.NewGuid():N}");
        return Task.FromResult<Stream>(_stream);
    }

    public Task CompleteAsync(CancellationToken cancellationToken)
    {
        _completedOrAborted = true;
        return Task.CompletedTask;
    }

    public Task AbortAsync(CancellationToken cancellationToken)
    {
        _completedOrAborted = true;
        DisposeStream();
        return Task.CompletedTask;
    }

    public ValueTask DisposeAsync()
    {
        if (!_completedOrAborted)
        {
            DisposeStream();
        }

        GC.SuppressFinalize(this);
        return ValueTask.CompletedTask;
    }

    private void DisposeStream()
    {
        _stream?.Dispose();
        _stream = null;
    }
}

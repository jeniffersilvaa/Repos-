using BenchmarkDotNet.Attributes;
using Hangfire;
using Hangfire.Server;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Microsoft.IO;
using NSubstitute;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Infra.MultiPartFileUploader;
using PaymentsDataLayerReports.Application.Infra.MultiPartFileUploader.Interfaces;
using PaymentsDataLayerReports.Application.Routes.Reports.PostReports.Models;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Interfaces;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Sinks;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.StreamWriters;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Workers.OrderReportESWorker;
using PaymentsDataLayerReports.Benchmark.Mocks;
using PaymentsDataLayerReports.Benchmark.Settings;

namespace PaymentsDataLayerReports.Benchmark.Benchmarks.Order;

/// <summary>Stress test for OrderReportESWorker with higher volumes (10K-100K records).</summary>
[Config(typeof(StressTestBenchmarkConfig))]
public class OrderReportESWorkerStressBenchmark : OrderReportESWorkerBaseBenchmark
{
    [Params(10_000, 50_000, 100_000)]
    public override int RecordCount { get; set; }
}

/// <summary>Measures memory allocation of the real OrderReportESWorker with mocked dependencies.</summary>
[Config(typeof(BatchProcessingBenchmarkConfig))]
public class OrderReportESWorkerBaseBenchmark
{
    protected const int BATCH_SIZE = 1000; // Same as DALAPI_BATCH_SIZE in worker

    private const string CsvFormat = "csv";
    private const string XlsxFormat = "xlsx";

    protected OrderReportESWorker _worker = null!;
    protected MockDataLayerApiClient _mockApiClient = null!;
    protected OrderReportWorkerParameters _parameters = null!;
    protected PerformContext _performContext = null!;
    private ServiceProvider? _serviceProvider;

    [Params(1_000, 5_000, 10_000)]
    public virtual int RecordCount { get; set; }

    [Params(CsvFormat, XlsxFormat)]
    public string FileFormat { get; set; } = CsvFormat;

    [GlobalSetup]
    public void Setup()
    {
        _mockApiClient = new MockDataLayerApiClient(RecordCount, batchSize: BATCH_SIZE);
        IOptions<AwsSettings> awsSettings = Options.Create(new AwsSettings { WorkgroupBucket = "benchmark-bucket" });
        IBackgroundJobClient backgroundJobClient = Substitute.For<IBackgroundJobClient>();
        IMultiPartFileUploader multiPartFileUploader = NullSinkMultiPartFileUploaderFactory.Create();
        RecyclableMemoryStreamManager recyclableMemoryStreamManager = new RecyclableMemoryStreamManager();

        var services = new ServiceCollection();
        services.AddSingleton(awsSettings);
        services.AddSingleton<IMultiPartFileUploader>(_ => multiPartFileUploader);
        services.AddTransient<IReportOutputSink, S3MultipartReportSink>();
        services.AddKeyedTransient<IReportStreamWriter<string>, CsvReportStreamWriter>(FileFormatEnum.Csv.Name.ToLowerInvariant());
        services.AddKeyedTransient<IReportStreamWriter<string>, XlsxReportStreamWriter>(FileFormatEnum.Xlsx.Name.ToLowerInvariant());
        services.AddKeyedTransient<IReportStreamWriter<string[]>, XlsxReportStreamWriter>(FileFormatEnum.Xlsx.Name.ToLowerInvariant());
        services.AddSingleton<IReportStreamWriterFactory, ReportStreamWriterFactory>();

        _serviceProvider = services.BuildServiceProvider();
        var reportStreamWriterFactory = _serviceProvider.GetRequiredService<IReportStreamWriterFactory>();

        _worker = new OrderReportESWorker(
            _mockApiClient,
            reportStreamWriterFactory,
            backgroundJobClient
        );

        _parameters = new OrderReportWorkerParameters
        {
            StartDueDate = DateTimeOffset.UtcNow.AddDays(-30),
            EndDueDate = DateTimeOffset.UtcNow,
            Documents = "12345678901234",
            FileFormat = FileFormat,
            Notification = new Notification
            {
                Email = new EmailNotification
                {
                    Address = "benchmark@example.com"
                }
            }
        };

        _performContext = MockPerformContextFactory.Create("benchmark-job-id");
    }

    [IterationSetup]
    public void IterationSetup()
    {
        _mockApiClient.Reset();
    }

    [GlobalCleanup]
    public async Task Cleanup()
    {
        if (_serviceProvider is IAsyncDisposable asyncDisposable)
        {
            await asyncDisposable.DisposeAsync();
        }
        else
        {
            _serviceProvider?.Dispose();
        }

        _serviceProvider = null;
    }

    /// <summary>Full pipeline using the real OrderReportESWorker: Fetch → Transform → Write → Upload.</summary>
    [Benchmark(Description = "OrderReportESWorker.ProcessReport")]
    public async Task ProcessReport()
    {
        await _worker.ProcessReport(_parameters, _performContext, CancellationToken.None);
    }
}

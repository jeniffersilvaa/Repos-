using Amazon.S3;
using BenchmarkDotNet.Attributes;
using Hangfire;
using Hangfire.Server;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using NSubstitute;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Infra.MultiPartFileUploader;
using PaymentsDataLayerReports.Application.Infra.MultiPartFileUploader.Interfaces;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Metrics;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Interfaces;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Sinks;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.StreamWriters;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Concat;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;
using PaymentsDataLayerReports.Benchmark.Mocks;
using PaymentsDataLayerReports.Benchmark.Settings;

namespace PaymentsDataLayerReports.Benchmark.Benchmarks.Concat;

/// <summary>Stress test for ChargeReportS3ConcatWorker with higher volumes (10K-100K records) and extended dataset (30 days, 10 partitions).</summary>
[Config(typeof(StressTestBenchmarkConfig))]
public class S3ConcatWorkerStressBenchmark : S3ConcatWorkerBaseBenchmark
{
    protected override int DaysCount => 30;
    protected override int PartitionsPerDay => 10;

    [Params(10_000, 100_000, 500_000)]
    public override int RecordCount { get; set; }
}

/// <summary>Measures memory allocation of the real ChargeReportS3ConcatWorker comparing two concatenation flows:
/// 1. New flow: IReportConcatenationService.ConcatAsync (KWayMergeEngine + ReportStreamWriter)
/// 2. Legacy flow: IS3ClientWrapper.MergeReportFilesAsync (S3ReportMergeService)
/// </summary>
[Config(typeof(BatchProcessingBenchmarkConfig))]
public class S3ConcatWorkerBaseBenchmark
{
    protected virtual int DaysCount => 5;
    protected virtual int PartitionsPerDay => 4;

    private const string CsvFormat = "csv";
    private const string XlsxFormat = "xlsx";

    protected ChargeReportS3ConcatWorker _worker = null!;
    protected IS3ClientWrapper _s3ClientWrapper = null!;
    protected IReportConcatenationService _reportConcatenationService = null!;
    protected IReportingTimeMetrics _reportingTimeMetrics = null!;
    protected ConcatBenchmarkDataset _dataset = null!;
    protected InMemoryS3Storage _storage = null!;
    protected PerformContext _performContext = null!;
    private ServiceProvider? _writerServiceProvider;

    // Dependencies that need fresh instances per iteration
    protected IAmazonS3 _s3Client = null!;
    protected IOptions<AwsSettings> _awsSettings = null!;

    [Params(1_000, 5_000, 10_000)]
    public virtual int RecordCount { get; set; }

    [Params(CsvFormat, XlsxFormat)]
    public string FileFormat { get; set; } = CsvFormat;

    [GlobalSetup]
    public void Setup()
    {
        var recordsPerPartition = RecordCount / (DaysCount * PartitionsPerDay);
        _dataset = ConcatBenchmarkDataset.Create(DaysCount, PartitionsPerDay, recordsPerPartition, FileFormat);

        _reportingTimeMetrics = Substitute.For<IReportingTimeMetrics>();

        _performContext = MockPerformContextFactory.Create("benchmark-job-id");
    }

    [IterationSetup]
    public void IterationSetup()
    {
        _writerServiceProvider?.Dispose();
        _writerServiceProvider = null;

        // Create fresh storage and dependencies for each iteration
        _storage = new InMemoryS3Storage();
        _dataset.Seed(_storage, "benchmark-bucket");

        _awsSettings = Options.Create(new AwsSettings { WorkgroupBucket = "benchmark-bucket" });
        _s3Client = _storage.Client;

        // Setup S3ClientWrapper with mocked dependencies
        var s3ReportMergeService = new S3ReportMergeService(_s3Client, _awsSettings);
        var s3ReportMetadataHandlerService = Substitute.For<IS3ReportMetadataHandlerService>();
        var s3ReportUploadService = Substitute.For<IS3ReportUploadService>();
        var s3ReportFileQueryService = Substitute.For<IS3ReportFileQueryService>();

        _s3ClientWrapper = new S3ClientWrapper(
            _s3Client,
            _awsSettings,
            s3ReportMergeService,
            s3ReportMetadataHandlerService,
            s3ReportUploadService,
            s3ReportFileQueryService
        );

        // Setup metadata handler to return our test metadata
        s3ReportMetadataHandlerService
            .GetReportMetadataAsync(Arg.Any<string>())
            .Returns(Task.FromResult<ReportMetadata?>(_dataset.Metadata));

        s3ReportMetadataHandlerService
            .UploadReportMetadataAsync(Arg.Any<ReportMetadata>())
            .Returns(Task.CompletedTask);

        // Setup new concatenation service with fresh instances
        var partitionedRecordSource = new S3CsvPartialReportRecordSource(_s3Client, _awsSettings);
        var mergeEngine = new KWayMergeEngine();

        var services = new ServiceCollection();
        services.AddSingleton(_s3Client);
        services.AddSingleton(_awsSettings);
        services.AddTransient<IMultiPartFileUploader, S3FileUploader>();
        services.AddTransient<IReportOutputSink, S3MultipartReportSink>();
        services.AddKeyedTransient<IReportStreamWriter<string>, CsvReportStreamWriter>(FileFormatEnum.Csv.Name.ToLowerInvariant());
        services.AddKeyedTransient<IReportStreamWriter<string>, XlsxReportStreamWriter>(FileFormatEnum.Xlsx.Name.ToLowerInvariant());
        services.AddKeyedTransient<IReportStreamWriter<string[]>, XlsxReportStreamWriter>(FileFormatEnum.Xlsx.Name.ToLowerInvariant());
        services.AddSingleton<IReportStreamWriterFactory, ReportStreamWriterFactory>();

        _writerServiceProvider = services.BuildServiceProvider();
        var writerFactory = _writerServiceProvider.GetRequiredService<IReportStreamWriterFactory>();

        _reportConcatenationService = new S3ReportConcatenationService(
            _s3Client,
            _awsSettings,
            partitionedRecordSource,
            mergeEngine,
            writerFactory
        );
    }

    [IterationCleanup]
    public void IterationCleanup()
    {
        DisposeWriterServiceProviderAsync().GetAwaiter().GetResult();
    }

    private async Task DisposeWriterServiceProviderAsync()
    {
        if (_writerServiceProvider is IAsyncDisposable asyncDisposable)
        {
            await asyncDisposable.DisposeAsync();
        }
        else
        {
            _writerServiceProvider?.Dispose();
        }

        _writerServiceProvider = null;
    }

    /// <summary>Legacy concatenation flow: S3ReportMergeService with string-based CSV parsing and buffering.</summary>
    [Benchmark(Description = "ChargeReportS3ConcatWorker.ConcatReport (Legacy: MergeReportFilesAsync)")]
    public async Task ConcatReportLegacy()
    {
        _dataset.Metadata.FileFormat = CsvFormat;
        var backgroundJobClient = Substitute.For<IBackgroundJobClient>();
        var preDeploySettings = Options.Create(new DataLayerReportPreDeploySettings { IsPreDeployWorker = false });
        _worker = new ChargeReportS3ConcatWorker(
            _s3ClientWrapper,
            _reportConcatenationService,
            _reportingTimeMetrics,
            preDeploySettings,
            backgroundJobClient
        );

        await _worker.ConcatReport(_dataset.Metadata.ReportId, _performContext, CancellationToken.None);
    }

    /// <summary>New concatenation flow: IReportConcatenationService with KWayMergeEngine and ReportStreamWriter.</summary>
    [Benchmark(Description = "ChargeReportS3ConcatWorker.ConcatReport (New: ConcatAsync)")]
    public async Task ConcatReportNew()
    {
        _dataset.Metadata.FileFormat = FileFormat;
        var backgroundJobClient = Substitute.For<IBackgroundJobClient>();
        var preDeploySettings = Options.Create(new DataLayerReportPreDeploySettings { IsPreDeployWorker = true });
        _worker = new ChargeReportS3ConcatWorker(
            _s3ClientWrapper,
            _reportConcatenationService,
            _reportingTimeMetrics,
            preDeploySettings,
            backgroundJobClient
        );

        await _worker.ConcatReport(_dataset.Metadata.ReportId, _performContext, CancellationToken.None);
    }
}

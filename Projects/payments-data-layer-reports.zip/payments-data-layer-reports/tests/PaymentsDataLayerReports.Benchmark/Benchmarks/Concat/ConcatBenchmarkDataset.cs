using System.Text;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;
using PaymentsDataLayerReports.Application.Workers.ChargeReportWorker;

namespace PaymentsDataLayerReports.Benchmark.Benchmarks.Concat;

public sealed class ConcatBenchmarkDataset
{
    private readonly string _header;
    private readonly IReadOnlyList<PartitionPayload> _partitions;

    private ConcatBenchmarkDataset(ReportMetadata metadata, string header, IReadOnlyList<PartitionPayload> partitions)
    {
        Metadata = metadata;
        _header = header;
        _partitions = partitions;
    }

    public ReportMetadata Metadata { get; }

    public static ConcatBenchmarkDataset Create(int dayCount, int partitionsPerDay, int rowsPerPartition, string fileFormat = "csv")
    {
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(dayCount);
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(partitionsPerDay);
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(rowsPerPartition);

        var header = "date,amount,partition,sequence";
        var endDate = DateOnly.FromDateTime(DateTime.UtcNow.Date);
        var startDate = endDate.AddDays(-(dayCount - 1));
        var reportId = $"concat-{dayCount}d-{partitionsPerDay}p-{rowsPerPartition}r";

        var rng = new Random(HashCode.Combine(dayCount, partitionsPerDay, rowsPerPartition));
        var partitions = new List<PartitionPayload>(dayCount * partitionsPerDay);

        for (var dayIndex = 0; dayIndex < dayCount; dayIndex++)
        {
            var date = startDate.AddDays(dayIndex);
            var dateTime = date.ToDateTime(TimeOnly.MinValue, DateTimeKind.Utc);

            for (var partitionIndex = 0; partitionIndex < partitionsPerDay; partitionIndex++)
            {
                var partitionId = $"part-{partitionIndex + 1}";
                var builder = new StringBuilder(rowsPerPartition * 32);

                for (var row = 0; row < rowsPerPartition; row++)
                {
                    var amount = rng.Next(100, 100_000);
                    var sequence = dayIndex * rowsPerPartition * partitionsPerDay + partitionIndex * rowsPerPartition + row;
                    builder.Append(dateTime.ToString("yyyy-MM-dd"))
                           .Append(',')
                           .Append(amount)
                           .Append(',')
                           .Append(partitionId)
                           .Append(',')
                           .Append(sequence)
                           .Append('\n');
                }

                partitions.Add(new PartitionPayload(dateTime, partitionId, builder.ToString()));
            }
        }

        var metadata = new ReportMetadata
        {
            Status = WorkerStatesEnum.Processing.ToString(),
            ReportId = reportId,
            DispatchId = $"dispatch-{reportId}",
            CreatedAt = DateTime.UtcNow,
            ReportSortColumnIndex = 0,
            ProcessorQueueName = QueuesEnum.S3Reports.Name,
            FileFormat = fileFormat,
            ChargeReportParameters = new ChargeReportsWorkerParameters
            {
                ReportType = ReportTypeEnum.ChargesList.Name,
                StartDate = startDate.ToDateTime(TimeOnly.MinValue, DateTimeKind.Utc),
                EndDate = endDate.ToDateTime(TimeOnly.MinValue, DateTimeKind.Utc),
                Organizations = "org-benchmark",
                Document = "00000000000000",
                MerchantId = "merchant-benchmark",
                PaymentMethods = "card",
                AccountId = "benchmark-account",
                IsSandbox = false
            }
        };

        return new ConcatBenchmarkDataset(metadata, header, partitions);
    }

    public void Seed(InMemoryS3Storage storage, string bucketName)
    {
        ArgumentNullException.ThrowIfNull(storage);
        var fileFormat = string.IsNullOrWhiteSpace(Metadata.FileFormat)
            ? FileFormatEnum.Csv.Name
            : Metadata.FileFormat.ToLowerInvariant();
        var headerKey = string.Format(S3ReportsConstants.PartialReportHeaderPath, Metadata.ReportId, fileFormat);
        storage.PutObject(bucketName, headerKey, _header + "\n");

        foreach (var partition in _partitions)
        {
            var key = string.Format(S3ReportsConstants.PartialReportFilePath, Metadata.ReportId, partition.Date, partition.PartitionId, fileFormat);
            storage.PutObject(bucketName, key, partition.Content);
        }
    }

    private sealed record PartitionPayload(DateTime Date, string PartitionId, string Content);
}

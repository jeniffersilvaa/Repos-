using System.Globalization;
using System.Text;
using Amazon.S3;
using Amazon.S3.Model;
using NSubstitute;

namespace PaymentsDataLayerReports.Benchmark.Benchmarks.Concat;

public sealed class InMemoryS3Storage
{
    private readonly IAmazonS3 _client;
    private readonly Dictionary<string, byte[]> _objects = new(StringComparer.Ordinal);
    private readonly Dictionary<string, UploadSession> _uploads = new();

    public InMemoryS3Storage()
    {
        _client = Substitute.For<IAmazonS3>();

        _client.ListObjectsV2Async(Arg.Any<ListObjectsV2Request>(), Arg.Any<CancellationToken>())
            .Returns(call => Task.FromResult(ListObjects(call.Arg<ListObjectsV2Request>())));

        _client.GetObjectAsync(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(call => Task.FromResult(CreateGetObjectResponse(
                call.ArgAt<string>(0),
                call.ArgAt<string>(1),
                null,
                null)));

        _client.GetObjectAsync(Arg.Any<GetObjectRequest>(), Arg.Any<CancellationToken>())
            .Returns(call =>
            {
                var request = call.Arg<GetObjectRequest>();
                var (start, end) = ParseRange(request.ByteRange);
                return Task.FromResult(CreateGetObjectResponse(request.BucketName, request.Key, start, end));
            });

        _client.InitiateMultipartUploadAsync(Arg.Any<InitiateMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(call => Task.FromResult(StartUpload(call.Arg<InitiateMultipartUploadRequest>())));

        _client.UploadPartAsync(Arg.Any<UploadPartRequest>(), Arg.Any<CancellationToken>())
            .Returns(call => Task.FromResult(UploadPart(call.Arg<UploadPartRequest>())));

        _client.CompleteMultipartUploadAsync(Arg.Any<CompleteMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(call => Task.FromResult(CompleteUpload(call.Arg<CompleteMultipartUploadRequest>())));

        _client.AbortMultipartUploadAsync(Arg.Any<AbortMultipartUploadRequest>(), Arg.Any<CancellationToken>())
            .Returns(call => Task.FromResult(AbortUpload(call.Arg<AbortMultipartUploadRequest>())));
    }

    public IAmazonS3 Client => _client;

    public void PutObject(string bucketName, string key, string content)
    {
        _objects[BuildKey(bucketName, key)] = Encoding.UTF8.GetBytes(content);
    }

    public void DeleteObject(string bucketName, string key)
    {
        _objects.Remove(BuildKey(bucketName, key));
    }

    public void Clear()
    {
        _objects.Clear();
        _uploads.Clear();
    }

    private ListObjectsV2Response ListObjects(ListObjectsV2Request request)
    {
        var prefix = request.Prefix ?? string.Empty;
        var objects = _objects
            .Where(kvp => KeyMatches(kvp.Key, request.BucketName, prefix))
            .Select(kvp => new S3Object
            {
                BucketName = request.BucketName,
                Key = ExtractObjectKey(kvp.Key),
                Size = kvp.Value.LongLength
            })
            .ToList();

        return new ListObjectsV2Response
        {
            S3Objects = objects,
            IsTruncated = false
        };
    }

    private GetObjectResponse CreateGetObjectResponse(string bucketName, string key, long? start, long? end)
    {
        var storageKey = BuildKey(bucketName, key);
        if (!_objects.TryGetValue(storageKey, out var bytes))
        {
            throw new AmazonS3Exception($"Object {key} not found in bucket {bucketName}.");
        }

        var slice = SliceBytes(bytes, start, end);
        return new GetObjectResponse
        {
            BucketName = bucketName,
            Key = key,
            ResponseStream = new MemoryStream(slice, writable: false),
            ContentLength = slice.Length
        };
    }

    private InitiateMultipartUploadResponse StartUpload(InitiateMultipartUploadRequest request)
    {
        var uploadId = Guid.NewGuid().ToString("N");
        _uploads[uploadId] = new UploadSession(request.BucketName, request.Key);
        return new InitiateMultipartUploadResponse
        {
            UploadId = uploadId,
            BucketName = request.BucketName,
            Key = request.Key
        };
    }

    private UploadPartResponse UploadPart(UploadPartRequest request)
    {
        if (!_uploads.TryGetValue(request.UploadId, out var session))
        {
            throw new InvalidOperationException($"Upload session {request.UploadId} not found");
        }

        var partBytes = ReadAllBytes(request.InputStream);
        session.Parts[request.PartNumber] = partBytes;

        return new UploadPartResponse
        {
            PartNumber = request.PartNumber,
            ETag = $"etag-{request.PartNumber}"
        };
    }

    private CompleteMultipartUploadResponse CompleteUpload(CompleteMultipartUploadRequest request)
    {
        if (!_uploads.TryGetValue(request.UploadId, out var session))
        {
            throw new InvalidOperationException($"Upload session {request.UploadId} not found");
        }

        var orderedParts = request.PartETags
            .OrderBy(part => part.PartNumber)
            .Select(part => session.Parts.TryGetValue(part.PartNumber, out var bytes) ? bytes : Array.Empty<byte>())
            .ToList();

        var totalLength = orderedParts.Sum(part => part.Length);
        var combined = new byte[totalLength];
        var offset = 0;
        foreach (var part in orderedParts)
        {
            Buffer.BlockCopy(part, 0, combined, offset, part.Length);
            offset += part.Length;
        }

        _objects[BuildKey(session.BucketName, session.Key)] = combined;
        _uploads.Remove(request.UploadId);

        return new CompleteMultipartUploadResponse
        {
            BucketName = session.BucketName,
            Key = session.Key,
            Location = $"https://{session.BucketName}.s3.amazonaws.com/{session.Key}"
        };
    }

    private AbortMultipartUploadResponse AbortUpload(AbortMultipartUploadRequest request)
    {
        _uploads.Remove(request.UploadId);
        return new AbortMultipartUploadResponse();
    }

    private static byte[] ReadAllBytes(Stream stream)
    {
        if (stream.CanSeek)
        {
            stream.Seek(0, SeekOrigin.Begin);
        }

        using var buffer = new MemoryStream();
        stream.CopyTo(buffer);

        if (stream.CanSeek)
        {
            stream.Seek(0, SeekOrigin.Begin);
        }

        return buffer.ToArray();
    }

    private static (long? Start, long? End) ParseRange(ByteRange? range)
    {
        var value = range?.ToString();
        if (string.IsNullOrWhiteSpace(value))
        {
            return (null, null);
        }

        if (!value.StartsWith("bytes=", StringComparison.Ordinal))
        {
            throw new InvalidOperationException($"Unsupported range format: {value}");
        }

        var parts = value[6..].Split('-', 2);
        var start = parts[0].Length > 0 ? long.Parse(parts[0], CultureInfo.InvariantCulture) : (long?)null;
        var end = parts.Length > 1 && parts[1].Length > 0 ? long.Parse(parts[1], CultureInfo.InvariantCulture) : (long?)null;
        return (start, end);
    }

    private static byte[] SliceBytes(byte[] source, long? start, long? end)
    {
        var actualStart = (int)(start ?? 0);
        var actualEnd = (int)(end ?? source.Length - 1);
        actualStart = Math.Clamp(actualStart, 0, source.Length);
        actualEnd = Math.Clamp(actualEnd, actualStart, source.Length - 1);
        var length = actualEnd - actualStart + 1;

        var result = new byte[length];
        Buffer.BlockCopy(source, actualStart, result, 0, length);
        return result;
    }

    private static bool KeyMatches(string storageKey, string bucketName, string prefix)
    {
        var (bucket, key) = SplitKey(storageKey);
        if (!string.Equals(bucket, bucketName, StringComparison.Ordinal))
        {
            return false;
        }

        return key.StartsWith(prefix, StringComparison.Ordinal);
    }

    private static string ExtractObjectKey(string storageKey) => SplitKey(storageKey).key;

    private static (string bucket, string key) SplitKey(string storageKey)
    {
        var separatorIndex = storageKey.IndexOf('\u001F');
        return (storageKey[..separatorIndex], storageKey[(separatorIndex + 1)..]);
    }

    private static string BuildKey(string bucketName, string key) => $"{bucketName}\u001F{key}";

    private sealed class UploadSession
    {
        public UploadSession(string bucketName, string key)
        {
            BucketName = bucketName;
            Key = key;
        }

        public string BucketName { get; }
        public string Key { get; }
        public Dictionary<int, byte[]> Parts { get; } = new();
    }
}

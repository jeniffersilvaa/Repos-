using BenchmarkDotNet.Attributes;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Interfaces;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Sinks;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.StreamWriters;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Workers.Shared.Modifiers.FinMov;
using PaymentsDataLayerReports.Benchmark.Generators;
using PaymentsDataLayerReports.Benchmark.Mocks;
using PaymentsDataLayerReports.Benchmark.Settings;

namespace PaymentsDataLayerReports.Benchmark.Benchmarks.ReportStreamWriter;

/// <summary>Stress test for ReportStreamWriter with higher volumes (10K-100K records).</summary>
[Config(typeof(StressTestBenchmarkConfig))]
public class ReportStreamWriterStressBenchmark : ReportStreamWriterBaseBenchmark
{
    [Params(10_000, 50_000, 100_000)]
    public override int RecordCount { get; set; }
}

/// <summary>
/// Micro-benchmark that isolates the ReportStreamWriter implementations from the rest of the pipeline.
/// Helps detect allocation regressions when touching CSV/XLSX writers or the generic writer factory.
/// </summary>
[Config(typeof(BatchProcessingBenchmarkConfig))]
public class ReportStreamWriterBaseBenchmark
{
    private const string CsvFormat = "csv";
    private const string XlsxFormat = "xlsx";

    private ServiceProvider? _serviceProvider;
    private IReportStreamWriterFactory _writerFactory = null!;
    private string _header = null!;
    private string[] _csvRows = [];
    private string[][] _columnRows = [];

    [Params(1_000, 5_000, 10_000)]
    public virtual int RecordCount { get; set; }

    [GlobalSetup]
    public void Setup()
    {
        _header = ReceivablesModifier.GetHeader();
        _csvRows = [.. FinancialMovementGenerator
            .GenerateBatch(RecordCount)
            .Select(ReceivablesModifier.BuildRow)];

        _columnRows = [.. _csvRows.Select(row => row.Split(';'))];

        var awsSettings = Options.Create(new AwsSettings { WorkgroupBucket = "benchmark-bucket" });

        var services = new ServiceCollection();
        services.AddSingleton(awsSettings);
        services.AddTransient<IReportOutputSink, InMemoryReportOutputSink>();
        services.AddKeyedTransient<IReportStreamWriter<string>, CsvReportStreamWriter>(FileFormatEnum.Csv.Name.ToLowerInvariant());
        services.AddKeyedTransient<IReportStreamWriter<string>, XlsxReportStreamWriter>(FileFormatEnum.Xlsx.Name.ToLowerInvariant());
        services.AddKeyedTransient<IReportStreamWriter<string[]>, XlsxReportStreamWriter>(FileFormatEnum.Xlsx.Name.ToLowerInvariant());
        services.AddSingleton<IReportStreamWriterFactory, ReportStreamWriterFactory>();

        _serviceProvider = services.BuildServiceProvider();
        _writerFactory = _serviceProvider.GetRequiredService<IReportStreamWriterFactory>();
    }

    [GlobalCleanup]
    public async Task Cleanup()
    {
        if (_serviceProvider is IAsyncDisposable asyncDisposable)
        {
            await asyncDisposable.DisposeAsync();
        }
        else
        {
            _serviceProvider?.Dispose();
        }

        _serviceProvider = null;
    }

    /// <summary>Measures CSV writer throughput when fed with pre-built string rows (FinMov layout).</summary>
    [Benchmark(Description = "CsvReportStreamWriter.WriteRecord (string)")]
    public Task CsvWriter_StringRecords()
    {
        var writer = _writerFactory.Create<string>(CsvFormat);
        return WriteRecordsAsync(writer, _header, _csvRows);
    }

    /// <summary>Measures XLSX writer using the CSV parsing pathway (string input).</summary>
    [Benchmark(Description = "XlsxReportStreamWriter.WriteRecord (string)")]
    public Task XlsxWriter_FromCsvStrings()
    {
        var writer = _writerFactory.Create<string>(XlsxFormat);
        return WriteRecordsAsync(writer, _header, _csvRows);
    }

    /// <summary>Measures XLSX writer when fed with column arrays (string[] input).</summary>
    [Benchmark(Description = "XlsxReportStreamWriter.WriteRecord (string[])")]
    public Task XlsxWriter_FromStringArray()
    {
        var writer = _writerFactory.Create<string[]>(XlsxFormat);
        return WriteRecordsAsync(writer, _header, _columnRows);
    }

    private static async Task WriteRecordsAsync<T>(IReportStreamWriter<T> writer, string header, IReadOnlyList<T> records)
    {
        await using (writer)
        {
            var cancellationToken = CancellationToken.None;
            var reportId = $"report-stream-writer-{records.Count}-{Guid.NewGuid():N}";

            await writer.InitializeAsync(reportId, cancellationToken);
            await writer.WriteHeaderAsync(header, cancellationToken);

            foreach (var record in records)
            {
                await writer.WriteRecordAsync(record, cancellationToken);
            }

            await writer.CompleteAsync(cancellationToken);
        }
    }
}

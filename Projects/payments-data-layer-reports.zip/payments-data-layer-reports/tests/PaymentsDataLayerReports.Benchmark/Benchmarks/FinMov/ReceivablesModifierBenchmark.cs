using BenchmarkDotNet.Attributes;
using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;
using PaymentsDataLayerReports.Application.Workers.Shared.Modifiers.FinMov;
using PaymentsDataLayerReports.Benchmark.Generators;
using PaymentsDataLayerReports.Benchmark.Settings;

namespace PaymentsDataLayerReports.Benchmark.Benchmarks.FinMov;

/// <summary>Stress test for ReceivablesModifier with higher volumes (10K-100K records).</summary>
[Config(typeof(StressTestBenchmarkConfig))]
public class ReceivablesModifierStressBenchmark : ReceivablesModifierBaseBenchmark
{
    [Params(10_000, 50_000, 100_000)]
    public override int RecordCount { get; set; }
}

/// <summary>Measures memory allocation of ReceivablesModifier.BuildRow.</summary>
[Config(typeof(BatchProcessingBenchmarkConfig))]
public class ReceivablesModifierBaseBenchmark
{
    protected List<FinancialMovement> _batchRecords = null!;
    protected List<CsvRow> _csvRowRecords = null!;

    [Params(1_000, 5_000, 10_000)]
    public virtual int RecordCount { get; set; }

    [GlobalSetup]
    public void Setup()
    {
        _batchRecords = FinancialMovementGenerator.GenerateBatch(RecordCount);
        _csvRowRecords = CsvRowGenerator.GenerateFinMovBatch(RecordCount);
    }

    [Benchmark(Description = "BuildRow from FinancialMovement")]
    public int BuildRowFromObject()
    {
        var totalLength = 0;
        foreach (var record in _batchRecords)
        {
            var row = ReceivablesModifier.BuildRow(record);
            totalLength += row.Length;
        }
        return totalLength;
    }

    [Benchmark(Description = "BuildRow from CsvRow")]
    public int BuildRowFromCsvRow()
    {
        var totalLength = 0;
        foreach (var csvRow in _csvRowRecords)
        {
            var row = ReceivablesModifier.BuildRow(csvRow);
            totalLength += row.Length;
        }
        return totalLength;
    }
}

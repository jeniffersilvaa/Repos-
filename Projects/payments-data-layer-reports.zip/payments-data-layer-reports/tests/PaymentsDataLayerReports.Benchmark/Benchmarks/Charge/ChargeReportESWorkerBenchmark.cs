using BenchmarkDotNet.Attributes;
using Hangfire;
using Hangfire.Server;
using NSubstitute;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService;
using PaymentsDataLayerReports.Application.Workers.ChargeReportWorker;
using PaymentsDataLayerReports.Application.Workers.Shared;
using PaymentsDataLayerReports.Benchmark.Mocks;
using PaymentsDataLayerReports.Benchmark.Settings;

namespace PaymentsDataLayerReports.Benchmark.Benchmarks.Charge;

/// <summary>Stress test for ChargeReportWorker with higher volumes (10K-100K records).</summary>
[Config(typeof(StressTestBenchmarkConfig))]
public class ChargeReportESWorkerStressBenchmark : ChargeReportESWorkerBaseBenchmark
{
    [Params(10_000, 50_000, 100_000)]
    public override int RecordCount { get; set; }
}

/// <summary>Measures memory allocation of the real ChargeReportESWorker with mocked dependencies.</summary>
[Config(typeof(BatchProcessingBenchmarkConfig))]
public class ChargeReportESWorkerBaseBenchmark
{
    protected const int BATCH_SIZE = 1000; // Same as DALAPI_BATCH_SIZE in worker

    protected ChargeReportWorker _worker = null!;
    protected MockDataLayerApiClient _mockApiClient = null!;
    protected ChargeReportsWorkerParameters _parameters = null!;
    protected PerformContext _performContext = null!;

    [Params(1_000, 5_000, 10_000)]
    public virtual int RecordCount { get; set; }

    [GlobalSetup]
    public void Setup()
    {
        _mockApiClient = new MockDataLayerApiClient(RecordCount, batchSize: BATCH_SIZE);
        IS3ClientWrapper s3ClientWrapper = Substitute.For<IS3ClientWrapper>();
        IBackgroundJobClient backgroundJobClient = Substitute.For<IBackgroundJobClient>();
        ICetFeatureManager cetFeatureManager = Substitute.For<ICetFeatureManager>();
        IServiceProvider serviceProvider = MockServiceProviderFactory.Create();
        var reportStreamWriterFactory = Substitute.For<IReportStreamWriterFactory>();

        _worker = new ChargeReportWorker(
            s3ClientWrapper,
            _mockApiClient,
            backgroundJobClient,
            cetFeatureManager,
            reportStreamWriterFactory,
            serviceProvider
        );

        _parameters = new ChargeReportsWorkerParameters
        {
            StartDate = DateTimeOffset.UtcNow.AddDays(-30),
            EndDate = DateTimeOffset.UtcNow,
            Document = "12345678901234",
            ReportType = "sales_stone"
        };

        _performContext = MockPerformContextFactory.Create("benchmark-job-id");
    }

    [IterationSetup]
    public void IterationSetup()
    {
        _mockApiClient.Reset();
    }

    /// <summary>Full pipeline using the real ChargeReportWorker: Fetch → Transform → Write → Upload.</summary>
    [Benchmark(Description = "ChargeReportWorker.ProcessReport")]
    public async Task ProcessReport()
    {
        await _worker.ProcessReport(_parameters, notificationChannel: null, isPartialReport: false, _performContext, CancellationToken.None);
    }
}

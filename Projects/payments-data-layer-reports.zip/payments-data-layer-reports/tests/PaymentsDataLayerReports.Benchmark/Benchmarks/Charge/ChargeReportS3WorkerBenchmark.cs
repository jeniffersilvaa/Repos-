using System.IO;
using BenchmarkDotNet.Attributes;
using Hangfire;
using Hangfire.Server;
using Microsoft.Extensions.Options;
using NSubstitute;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Services.DeltaTablePartitionBuilder;
using PaymentsDataLayerReports.Application.Services.IdempotentJobManager;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.ChargeList;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.Models;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.RealtimeChargeEvents;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;
using PaymentsDataLayerReports.Application.Workers.ChargeReportWorker;
using PaymentsDataLayerReports.Application.Workers.Shared;
using PaymentsDataLayerReports.Benchmark.Mocks;
using PaymentsDataLayerReports.Benchmark.Settings;

namespace PaymentsDataLayerReports.Benchmark.Benchmarks.Charge;

/// <summary>Stress test for ChargeReportS3Worker with higher volumes (10K-100K records).</summary>
[Config(typeof(StressTestBenchmarkConfig))]
public class ChargeReportS3WorkerStressBenchmark : ChargeReportS3WorkerBaseBenchmark
{
    [Params(10_000, 50_000, 100_000)]
    public override int RecordCount { get; set; }
}

/// <summary>Measures memory allocation of the real ChargeReportS3Worker with mocked dependencies.</summary>
[Config(typeof(BatchProcessingBenchmarkConfig))]
public class ChargeReportS3WorkerBaseBenchmark
{
    protected ChargeReportS3Worker _worker = null!;
    protected ChargeListReportGenerator _generator = null!;
    protected GenerateReportInput _input = null!;

    [Params(1_000, 5_000, 10_000)]
    public virtual int RecordCount { get; set; }

    [GlobalSetup]
    public void Setup()
    {
        var s3Client = NullSinkS3ClientFactory.Create();
        var s3ClientWrapper = Substitute.For<IS3ClientWrapper>();
        var deltaLakeManager = Substitute.For<IDeltaLakeManager>();
        var chargeListReportManager = Substitute.For<IChargeListReportManager>();
        var realtimeChargeEventsService = Substitute.For<IRealtimeChargeEventsService>();
        var reportTypeFactory = Substitute.For<IReportTypeFactory>();
        var idempotentJobManager = Substitute.For<IIdempotentJobManager>();
        var cetFeatureManager = Substitute.For<ICetFeatureManager>();
        var serviceProvider = MockServiceProviderFactory.Create();

        // Setup mocks
        deltaLakeManager.DownloadAsync(Arg.Any<GenerateReportInput>(), Arg.Any<string>()).Returns(1000L);
        deltaLakeManager.ConvertToCsvAsync(Arg.Any<GenerateReportInput>(), Arg.Any<string>(), Arg.Any<string>(), Arg.Any<bool>(), Arg.Any<bool>()).Returns((RecordCount, 1000L));
        deltaLakeManager.FilterCharges(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<ChargeReportsWorkerParameters>());

        // Create temporary files with mock data
        var tempDir = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString());
        Directory.CreateDirectory(tempDir);

        var rawCsvPath = Path.Combine(tempDir, "raw.csv");
        var sortedCsvPath = Path.Combine(tempDir, "sorted.csv");
        var rawChargesPath = Path.Combine(tempDir, "raw_charges.csv");
        var filteredCsvPath = Path.Combine(tempDir, "filtered.csv");
        var finalCsvPath = Path.Combine(tempDir, "final.csv");

        // Create mock CSV files with headers
        File.WriteAllText(rawCsvPath, "charge_id,event_type,amount\n");
        File.WriteAllText(sortedCsvPath, "charge_id,event_type,amount\n");
        File.WriteAllText(rawChargesPath, "charge_id,amount\n");
        File.WriteAllText(filteredCsvPath, "charge_id,amount\n");
        File.WriteAllText(finalCsvPath, "charge_id,amount\n");

        chargeListReportManager.ChargesEventsRawParquetPath.Returns(tempDir);
        chargeListReportManager.ChargesEventsRawCsvFile.Returns(rawCsvPath);
        chargeListReportManager.ChargesEventsSortedByIdCsvFile.Returns(sortedCsvPath);
        chargeListReportManager.ChargesRawCsvFile.Returns(rawChargesPath);
        chargeListReportManager.ChargesFilteredCsvFile.Returns(filteredCsvPath);
        chargeListReportManager.ChargesSortedByCreatedAtCsvFile.Returns(finalCsvPath);

        realtimeChargeEventsService.BuildRealtimeFileAsync(Arg.Any<GenerateReportInput>(), Arg.Any<string>()).Returns(true);

        s3ClientWrapper.UploadReportHeaderAsync(Arg.Any<string>(), Arg.Any<string>()).Returns(Task.CompletedTask);
        s3ClientWrapper.UploadReportAsync(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<string>(), Arg.Any<DateTime>(), Arg.Any<string?>()).Returns(Task.CompletedTask);

        _generator = new ChargeListReportGenerator(
            deltaLakeManager,
            s3ClientWrapper,
            chargeListReportManager,
            realtimeChargeEventsService,
            cetFeatureManager,
            serviceProvider
        );

        reportTypeFactory.Create<GenerateReportInput>(Arg.Any<ReportTypeEnum>()).Returns(_generator);

        _worker = new ChargeReportS3Worker(
            reportTypeFactory,
            s3ClientWrapper,
            idempotentJobManager
        );

        var partitionSet = new DeltaTablePartitionSet
        {
            PartitionIdReferences = ["test-org"],
            PartitionIdReferenceType = "document",
            Partitions = [new DeltaTablePartition("charges_events_by_created_at", "test-org")]
        };
        var reportMetadata = new ReportMetadata
        {
            Status = "processing",
            ReportId = "test-report",
            DispatchId = "test-dispatch",
            CreatedAt = DateTime.UtcNow,
            ReportSortColumnIndex = 0,
            ProcessorQueueName = "test-queue",
            FileFormat = "csv",
            ChargeReportParameters = new ChargeReportsWorkerParameters
            {
                StartDate = DateTimeOffset.UtcNow.AddDays(-30),
                EndDate = DateTimeOffset.UtcNow,
                Document = "12345678901234",
                ReportType = "charges_list"
            }
        };

        _input = new GenerateReportInput
        {
            PartitionDate = DateTime.UtcNow,
            PartitionSet = partitionSet,
            ReportMetadata = reportMetadata,
            CancellationToken = CancellationToken.None,
            JobId = "test-job"
        };
    }

    [IterationSetup]
    public void IterationSetup()
    {
    }

    [Benchmark(Description = "ChargeListReportGenerator.Execute")]
    public async Task ExecuteReport()
    {
        await _generator.Execute(_input);
    }
}
using Bogus;
using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Entities.Models.FinMov;

namespace PaymentsDataLayerReports.Benchmark.Generators;

/// <summary>Generates fake FinancialMovement data for benchmarks.</summary>
public static class FinancialMovementGenerator
{
    private static readonly string[] Operations =
    [
        "sale",
        "prepayment_sale",
        "chargeback",
        "chargeback_refund",
        "reversal",
        "partial_reversal",
        "financial_adjustment",
        "transaction_split",
        "prepayment_transaction_split",
        "partial_chargeback",
        "charge",
        "charge_refund"
    ];

    private static readonly string[] WalletDescriptions =
    [
        "VisaCredit",
        "VisaDebit",
        "MasterCredit",
        "MasterDebit",
        "EloCredit",
        "EloDebit",
        "HiperCredit",
        "AmexCredit",
        "CabalCredit",
        "Default"
    ];

    private static readonly string[] Brands =
    [
        "Visa",
        "MasterCard",
        "Elo",
        "Hipercard",
        "AmericanExpress",
        "Cabal",
        "BancoDoBrasil",
        "Bradesco",
        "ItauUnibanco"
    ];

    private static readonly string[] SettlementStatuses =
    [
        "open",
        "scheduled",
        "paid",
        "rejected"
    ];

    private static readonly string[] FeeTypes = ["MDR", "CET"];

    private static readonly Faker Faker = new("pt_BR");

    public static FinancialMovement Generate()
    {
        var captureDate = Faker.Date.Recent(30);
        var currentDueDate = captureDate.AddDays(Faker.Random.Int(1, 30));
        var originalDueDate = currentDueDate.AddDays(Faker.Random.Int(0, 5));

        return new FinancialMovement(
            Id: Faker.Random.Guid().ToString(),
            OperationId: Faker.Random.Guid().ToString(),
            Operation: Faker.PickRandom(Operations),
            OriginalDueDate: originalDueDate.ToString("yyyy-MM-ddTHH:mm:ss"),
            CurrentDueDate: currentDueDate.ToString("yyyy-MM-ddTHH:mm:ss"),
            LatestEventTimestamp: DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss"),
            UpdatedAt: DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss"),
            Amount: GenerateAmount(),
            Merchant: GenerateMerchant(),
            PaymentOwner: GenerateMerchant(),
            Transaction: GenerateTransaction(captureDate),
            Settlement: GenerateSettlement(),
            Movements: null
        );
    }

    public static List<FinancialMovement> GenerateBatch(int count)
    {
        var list = new List<FinancialMovement>(count);
        for (int i = 0; i < count; i++)
        {
            list.Add(Generate());
        }
        return list;
    }


    public static IEnumerable<FinancialMovement> GenerateInfinite()
    {
        while (true)
        {
            yield return Generate();
        }
    }

    private static Amount GenerateAmount()
    {
        var gross = Faker.Random.Decimal(100, 100000);
        var discountRateAmount = gross * Faker.Random.Decimal(0.01m, 0.05m);
        var prepaymentAmount = Faker.Random.Bool() ? gross * Faker.Random.Decimal(0.005m, 0.02m) : 0;
        var net = gross - discountRateAmount - prepaymentAmount;

        return new Amount(
            Gross: gross,
            Net: net,
            DiscountRate: new FeeModel(
                Amount: discountRateAmount,
                Fee: Faker.Random.Decimal(0.01m, 0.05m),
                EffectiveFee: Faker.Random.Decimal(0.01m, 0.05m),
                FeeType: Faker.PickRandom(FeeTypes)
            ),
            PrepaymentFee: prepaymentAmount > 0 ? new FeeModel(
                Amount: prepaymentAmount,
                Fee: Faker.Random.Decimal(0.005m, 0.02m),
                EffectiveFee: Faker.Random.Decimal(0.005m, 0.02m),
                FeeType: Faker.PickRandom(FeeTypes)
            ) : null,
            PrepaymentFeeTurbo: null
        );
    }

    private static Merchant GenerateMerchant()
    {
        var isCnpj = Faker.Random.Bool();
        var document = isCnpj
            ? Faker.Random.Long(10000000000000, 99999999999999).ToString()
            : Faker.Random.Long(10000000000, 99999999999).ToString();

        return new Merchant(
            AffiliationCode: Faker.Random.Long(100000, 999999).ToString(),
            UserId: Faker.Random.Guid().ToString(),
            Organization: Faker.Company.CompanyName(),
            Document: document,
            AffiliationKey: Faker.Random.Guid().ToString(),
            PaymentProfileId: ""
        );
    }

    private static Transaction GenerateTransaction(DateTime captureDate)
    {
        var installmentQuantity = Faker.Random.Int(1, 12);
        var installmentNumber = Faker.Random.Int(1, installmentQuantity);

        return new Transaction(
            Product: Faker.PickRandom(new[] { "Crédito", "Débito", "Voucher" }),
            AuthorizationDate: captureDate.AddMinutes(-Faker.Random.Int(1, 60)).ToString("yyyy-MM-ddTHH:mm:ss"),
            InstallmentNumber: installmentNumber,
            InstallmentQuantity: installmentQuantity,
            CaptureDate: captureDate.ToString("yyyy-MM-ddTHH:mm:ss"),
            OperationKey: Faker.Random.Guid().ToString(),
            AccountFundingSource: Faker.Random.Bool() ? "prepaid" : "credit",
            Brand: Faker.PickRandom(Brands),
            Key: Faker.Random.AlphaNumeric(20),
            PointOfInteractionType: Faker.PickRandom(new[] { "Crédito", "Débito", "Voucher" })
        );
    }

    private static Settlement GenerateSettlement()
    {
        var paymentDate = Faker.Date.Recent(5);

        return new Settlement(
            Wallet: new Wallet(
                Description: Faker.PickRandom(WalletDescriptions),
                Nature: "credit",
                TypeId: Faker.Random.Int(1, 10)
            ),
            BalanceDueDate: paymentDate.AddDays(1).ToString("yyyy-MM-ddTHH:mm:ss"),
            Key: Faker.Random.Guid().ToString(),
            PaymentDate: paymentDate.ToString("yyyy-MM-ddTHH:mm:ss"),
            Status: Faker.PickRandom(SettlementStatuses),
            Payment: null
        );
    }
}

using Bogus;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.FinMovList;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;

namespace PaymentsDataLayerReports.Benchmark.Generators;

/// <summary>Generates fake CsvRow data for benchmarks.</summary>
public static class CsvRowGenerator
{
    private static readonly string[] Operations =
    [
        "sale",
        "prepayment_sale",
        "chargeback",
        "chargeback_refund",
        "reversal",
        "partial_reversal",
        "financial_adjustment"
    ];

    private static readonly string[] WalletDescriptions =
    [
        "VisaCredit",
        "VisaDebit",
        "MasterCredit",
        "MasterDebit",
        "EloCredit",
        "EloDebit",
        "HiperCredit",
        "AmexCredit"
    ];

    private static readonly string[] Brands =
    [
        "Visa",
        "MasterCard",
        "Elo",
        "Hipercard",
        "AmericanExpress"
    ];

    private static readonly string[] SettlementStatuses =
    [
        "open",
        "scheduled",
        "paid",
        "rejected"
    ];

    private static readonly string[] FeeTypes = ["MDR", "CET"];

    private static readonly Faker Faker = new("pt_BR");

    private static readonly Dictionary<string, int> HeaderIndex = FinMovListReportHeader.HeaderIndex;

    public static CsvRow GenerateFinMov()
    {
        var csvRow = new CsvRow(FinMovListReportHeader.HeaderFields.Length);

        var captureDate = Faker.Date.Recent(30);
        var currentDueDate = captureDate.AddDays(Faker.Random.Int(1, 30));
        var originalDueDate = currentDueDate.AddDays(Faker.Random.Int(0, 5));
        var isCnpj = Faker.Random.Bool();
        var document = isCnpj
            ? Faker.Random.Long(10000000000000, 99999999999999).ToString()
            : Faker.Random.Long(10000000000, 99999999999).ToString();

        SetField(csvRow, "id", Faker.Random.Guid().ToString());
        SetField(csvRow, "operation_id", Faker.Random.Guid().ToString());
        SetField(csvRow, "operation", Faker.PickRandom(Operations));
        SetField(csvRow, "original_due_date", originalDueDate.ToString("yyyy-MM-ddTHH:mm:ss"));
        SetField(csvRow, "current_due_date", currentDueDate.ToString("yyyy-MM-ddTHH:mm:ss"));
        SetField(csvRow, "latest_event_timestamp", DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss"));
        SetField(csvRow, "updated_at", DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss"));

        // Amount fields
        var gross = Faker.Random.Decimal(100, 100000);
        var discountRateAmount = gross * Faker.Random.Decimal(0.01m, 0.05m);
        var prepaymentAmount = Faker.Random.Bool() ? gross * Faker.Random.Decimal(0.005m, 0.02m) : 0;
        var net = gross - discountRateAmount - prepaymentAmount;

        SetField(csvRow, "amount__gross", gross);
        SetField(csvRow, "amount__net", net);
        SetField(csvRow, "amount__discount_rate__amount", discountRateAmount);
        SetField(csvRow, "amount__discount_rate__fee", Faker.Random.Decimal(0.01m, 0.05m));
        SetField(csvRow, "amount__discount_rate__effective_fee", Faker.Random.Decimal(0.01m, 0.05m));
        SetField(csvRow, "amount__discount_rate__fee_type", Faker.PickRandom(FeeTypes));

        if (prepaymentAmount > 0)
        {
            SetField(csvRow, "amount__prepayment_fee__amount", prepaymentAmount);
            SetField(csvRow, "amount__prepayment_fee__fee", Faker.Random.Decimal(0.005m, 0.02m));
            SetField(csvRow, "amount__prepayment_fee__effective_fee", Faker.Random.Decimal(0.005m, 0.02m));
            SetField(csvRow, "amount__prepayment_fee__fee_type", Faker.PickRandom(FeeTypes));
        }

        // Payment owner fields
        SetField(csvRow, "payment_owner__document", document);
        SetField(csvRow, "payment_owner__affiliation_code", Faker.Random.Long(100000, 999999).ToString());

        // Transaction fields
        var installmentQuantity = Faker.Random.Int(1, 12);
        var installmentNumber = Faker.Random.Int(1, installmentQuantity);

        SetField(csvRow, "transaction__capture_date", captureDate.ToString("yyyy-MM-ddTHH:mm:ss"));
        SetField(csvRow, "transaction__brand", Faker.PickRandom(Brands));
        SetField(csvRow, "transaction__account_funding_source", Faker.Random.Bool() ? "prepaid" : "credit");
        SetField(csvRow, "transaction__key", Faker.Random.AlphaNumeric(20));
        SetField(csvRow, "transaction__installment_quantity", installmentQuantity);
        SetField(csvRow, "transaction__installment_number", installmentNumber);

        // Settlement fields
        SetField(csvRow, "settlement__status", Faker.PickRandom(SettlementStatuses));
        SetField(csvRow, "settlement__wallet__description", Faker.PickRandom(WalletDescriptions));

        return csvRow;
    }

    public static List<CsvRow> GenerateFinMovBatch(int count)
    {
        var list = new List<CsvRow>(count);
        for (int i = 0; i < count; i++)
        {
            list.Add(GenerateFinMov());
        }
        return list;
    }

    private static void SetField(CsvRow csvRow, string key, object? value)
    {
        if (HeaderIndex.TryGetValue(key, out int index))
        {
            csvRow.SetField(index, value);
        }
    }
}

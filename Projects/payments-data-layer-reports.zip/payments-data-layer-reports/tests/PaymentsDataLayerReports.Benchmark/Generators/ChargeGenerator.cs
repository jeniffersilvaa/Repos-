using Bogus;
using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Entities.Models.Charge;

namespace PaymentsDataLayerReports.Benchmark.Generators;

/// <summary>Generates fake Charge data for benchmarks.</summary>
public static class ChargeGenerator
{
    private static readonly string[] Products = ["credit", "debit", "pix", "boleto"];
    private static readonly string[] Origins = ["api", "checkout", "link", "pos"];
    private static readonly string[] Statuses = ["paid", "pending", "failed", "refunded"];
    private static readonly string[] PaymentMethods = ["credit_card", "debit_card", "pix", "boleto"];
    private static readonly string[] Gateways = ["stone", "cielo", "rede", "getnet"];
    private static readonly string[] Brands = ["visa", "mastercard", "elo", "amex", "hipercard"];
    private static readonly string[] EntryModes = ["chip", "contactless", "magstripe", "manual"];
    private static readonly string[] InstallmentTypes = ["none", "merchant", "issuer"];

    private static readonly Faker Faker = new("pt_BR");

    public static Charge Generate()
    {
        var amount = Faker.Random.Int(1000, 1000000);
        var netAmount = (int)(amount * 0.97m);
        var createdAt = Faker.Date.RecentOffset(30);

        return new Charge(
            Id: Faker.Random.Guid().ToString(),
            InitiatorId: Faker.Random.Guid().ToString(),
            Product: Faker.PickRandom(Products),
            Origin: Faker.PickRandom(Origins),
            OriginId: Faker.Random.Guid().ToString(),
            Amount: amount,
            UpdatedAmount: amount,
            NetAmount: netAmount,
            FullNetAmount: netAmount,
            Status: Faker.PickRandom(Statuses),
            PaymentMethod: Faker.PickRandom(PaymentMethods),
            CreatedAt: createdAt,
            PlatformName: Faker.Company.CompanyName(),
            AttemptCount: Faker.Random.Int(1, 3),
            Gateway: Faker.PickRandom(Gateways),
            GatewayOrderId: Faker.Random.AlphaNumeric(20),
            Code: Faker.Random.AlphaNumeric(10),
            AllIds: null,
            Merchant: GenerateMerchant(),
            Split: GenerateSplits(),
            CardTransaction: GenerateCardTransaction(amount),
            PixTransaction: null,
            BoletoTransaction: null,
            CashTransaction: null,
            Metadata: null
        );
    }

    public static List<Charge> GenerateBatch(int count)
    {
        var list = new List<Charge>(count);
        for (int i = 0; i < count; i++)
        {
            list.Add(Generate());
        }
        return list;
    }

    private static Merchant GenerateMerchant()
    {
        var isCnpj = Faker.Random.Bool();
        var document = isCnpj
            ? Faker.Random.Long(10000000000000, 99999999999999).ToString()
            : Faker.Random.Long(10000000000, 99999999999).ToString();

        return new Merchant(
            Organization: Faker.Company.CompanyName(),
            Document: document,
            UserId: Faker.Random.Guid().ToString(),
            AffiliationKey: Faker.Random.Guid().ToString(),
            AffiliationCode: Faker.Random.Long(100000, 999999).ToString(),
            AccountId: Faker.Random.Guid().ToString(),
            MerchantId: Faker.Random.Guid().ToString()
        );
    }

    private static List<Split> GenerateSplits()
    {
        var splitCount = Faker.Random.Int(0, 2);
        var splits = new List<Split>(splitCount);

        for (int i = 0; i < splitCount; i++)
        {
            splits.Add(new Split(
                Id: Faker.Random.Guid().ToString(),
                RecipientId: Faker.Random.Guid().ToString(),
                GatewayRecipientId: Faker.Random.Guid().ToString()
            ));
        }

        return splits;
    }

    private static CardTransaction GenerateCardTransaction(int amount)
    {
        var installments = Faker.Random.Int(1, 12);
        var feeAmount = (int)(amount * 0.03m);

        return new CardTransaction(
            Type: "credit",
            FundingSource: "credit",
            TransactionId: Faker.Random.Guid().ToString(),
            FailedAmount: null,
            AuthorizedAmount: amount,
            CapturedAmount: amount,
            CanceledAmount: 0,
            ChargebackAmount: null,
            ChargebackRefundAmount: null,
            AuthorizationCode: Faker.Random.AlphaNumeric(6),
            AuthorizedState: "Full",
            Installments: installments,
            InstallmentsType: Faker.PickRandom(InstallmentTypes),
            SchemeBusinessModel: "credit",
            FeeAmount: feeAmount,
            FullFeeAmount: feeAmount,
            MdrAmount: feeAmount,
            FullMdrAmount: feeAmount,
            MdrRefundAmount: null,
            FullMdrRefundAmount: null,
            RavAmount: null,
            FullRavAmount: null,
            RavRefundAmount: null,
            FullRavRefundAmount: null,
            FullFcAmount: null,
            FullFcRefundAmount: null,
            Customer: null,
            Card: GenerateCard(),
            Terminal: GenerateTerminal(),
            Last: null,
            Details: [],
            FinancialMovements: null
        );
    }

    private static Card GenerateCard()
    {
        return new Card(
            Brand: Faker.PickRandom(Brands),
            BrandId: (byte)Faker.Random.Int(1, 10),
            FirstSixDigits: Faker.Random.Long(100000, 999999).ToString(),
            LastFourDigits: Faker.Random.Long(1000, 9999).ToString(),
            EntryMode: Faker.PickRandom(EntryModes),
            HolderName: Faker.Name.FullName(),
            ExpMonth: Faker.Random.Int(1, 12).ToString("D2"),
            ExpYear: Faker.Random.Int(2024, 2030).ToString(),
            CountryCode: 76,
            CurrencyCode: 986,
            NumberToken: null,
            Label: null
        );
    }

    private static CardTerminal GenerateTerminal()
    {
        return new CardTerminal(
            Type: "pos",
            SerialNumber: Faker.Random.AlphaNumeric(10)
        );
    }
}

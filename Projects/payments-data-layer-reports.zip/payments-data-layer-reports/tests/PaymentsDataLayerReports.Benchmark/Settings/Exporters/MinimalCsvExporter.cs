using System.Text;
using BenchmarkDotNet.Exporters;
using BenchmarkDotNet.Exporters.Csv;
using BenchmarkDotNet.Loggers;
using BenchmarkDotNet.Reports;
using BenchmarkDotNet.Running;

namespace PaymentsDataLayerReports.Benchmark.Settings.Exporters;

/// <summary>Exporter that generates a trimmed CSV keeping only the relevant columns.</summary>
public class MinimalCsvExporter : IExporter
{
    private static readonly string NamespacePrefix = "PaymentsDataLayerReports.Benchmark.Benchmarks.";
    private static readonly string[] LeadingColumns =
    [
        "Method",
        "Job"
    ];

    private static readonly string[] TrailingColumns =
    [
        "Mean",
        "Error",
        "StdDev",
        "Median",
        "Rank",
        "Alloc/Record",
        "Records/Sec",
        "Time/Record",
        "Gen0",
        "Gen1",
        "Gen2",
        "Allocated"
    ];

    public string Name => "MinimalCsv";

    public void ExportToLog(Summary summary, ILogger logger)
    {
        foreach (var file in ExportToFiles(summary, logger))
        {
            logger.WriteLineInfo($"Minimal CSV exported to {file}");
        }
    }

    public IEnumerable<string> ExportToFiles(Summary summary, ILogger consoleLogger)
    {
        var generatedFiles = CsvExporter.Default.ExportToFiles(summary, consoleLogger).ToList();
        var processedFiles = new List<string>();

        foreach (var file in generatedFiles)
        {
            if (!File.Exists(file))
            {
                continue;
            }

            TrimColumns(file, summary);
            var simplified = SimplifyFileName(file);
            processedFiles.Add(simplified);
        }

        return processedFiles;
    }

    private static void TrimColumns(string filePath, Summary summary)
    {
        var lines = File.ReadAllLines(filePath);
        if (lines.Length == 0)
        {
            return;
        }

        var orderedColumns = BuildColumnOrder(summary);
        var headerCells = SplitCsvLine(lines[0]);
        var selectedIndexes = orderedColumns
            .Select(column => FindColumnIndex(headerCells, column))
            .Where(index => index >= 0)
            .ToArray();

        if (selectedIndexes.Length == 0)
        {
            return;
        }

        var trimmedLines = new string[lines.Length];
        trimmedLines[0] = string.Join(';', selectedIndexes.Select(index => headerCells[index]));

        for (var i = 1; i < lines.Length; i++)
        {
            if (string.IsNullOrWhiteSpace(lines[i]))
            {
                trimmedLines[i] = lines[i];
                continue;
            }

            var cells = SplitCsvLine(lines[i]);
            trimmedLines[i] = string.Join(';', selectedIndexes.Select(index => index < cells.Count ? cells[index] : string.Empty));
        }

        File.WriteAllLines(filePath, trimmedLines);
    }

    private static List<string> BuildColumnOrder(Summary summary)
    {
        var ordered = new List<string>();
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        void AddColumn(string name)
        {
            if (string.IsNullOrWhiteSpace(name)) return;
            if (seen.Add(name))
            {
                ordered.Add(name);
            }
        }

        // Ensure leading columns first
        foreach (var leading in LeadingColumns)
        {
            AddColumn(leading);
        }

        // Insert parameter names right after Method/Job
        foreach (var benchmarkCase in summary.BenchmarksCases)
        {
            foreach (var parameter in benchmarkCase.Parameters.Items)
            {
                AddColumn(parameter.Name);
            }
        }

        foreach (var trailing in TrailingColumns)
        {
            AddColumn(trailing);
        }

        return ordered;
    }

    private static int FindColumnIndex(IReadOnlyList<string> headers, string columnName)
    {
        for (var i = 0; i < headers.Count; i++)
        {
            if (string.Equals(headers[i], columnName, StringComparison.OrdinalIgnoreCase))
            {
                return i;
            }
        }

        return -1;
    }

    private static string SimplifyFileName(string filePath)
    {
        var directory = Path.GetDirectoryName(filePath);
        if (string.IsNullOrEmpty(directory))
        {
            return filePath;
        }
        var fileName = Path.GetFileName(filePath);
        var simplifiedName = fileName.Replace(NamespacePrefix, string.Empty, StringComparison.Ordinal);

        if (simplifiedName == fileName)
        {
            return filePath;
        }

        var newPath = Path.Combine(directory, simplifiedName);
        File.Move(filePath, newPath, overwrite: true);
        return newPath;
    }

    private static List<string> SplitCsvLine(string line)
    {
        var values = new List<string>();
        var current = new StringBuilder();
        var inQuotes = false;

        for (var i = 0; i < line.Length; i++)
        {
            var c = line[i];

            if (c == '"')
            {
                inQuotes = !inQuotes;
                current.Append(c);
                continue;
            }

            if (c == ';' && !inQuotes)
            {
                values.Add(current.ToString());
                current.Clear();
                continue;
            }

            current.Append(c);
        }

        values.Add(current.ToString());
        return values;
    }
}
using BenchmarkDotNet.Columns;
using BenchmarkDotNet.Reports;
using BenchmarkDotNet.Running;

namespace PaymentsDataLayerReports.Benchmark.Settings.CustomColumns;

/// <summary>Custom column showing bytes allocated per record processed.</summary>
public class AllocationPerRecordColumn : RecordBasedColumn
{
    public override string Id => "AllocPerRecord";
    public override string ColumnName => "Alloc/Record";
    public override int PriorityInCategory => 0;
    public override bool IsNumeric => true;
    public override UnitType UnitType => UnitType.Size;
    public override string Legend => "Bytes allocated per record processed";

    public override string GetValue(Summary summary, BenchmarkCase benchmarkCase)
    {
        var report = summary[benchmarkCase];
        if (report?.ResultStatistics == null || report.GcStats.GetBytesAllocatedPerOperation(benchmarkCase) == null)
            return "N/A";

        var recordCount = GetRecordCountParameter(benchmarkCase);
        if (recordCount == null)
            return "N/A";

        var totalAllocated = report.GcStats.GetBytesAllocatedPerOperation(benchmarkCase) ?? 0;
        var allocPerRecord = totalAllocated / (double)recordCount.Value;

        return $"{allocPerRecord:N2} B";
    }
}

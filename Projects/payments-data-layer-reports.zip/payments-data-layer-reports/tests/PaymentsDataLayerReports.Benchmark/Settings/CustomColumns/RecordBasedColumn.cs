using BenchmarkDotNet.Columns;
using BenchmarkDotNet.Reports;
using BenchmarkDotNet.Running;

namespace PaymentsDataLayerReports.Benchmark.Settings.CustomColumns;

/// <summary>Base class for custom columns that need record count parameter.</summary>
public abstract class RecordBasedColumn : IColumn
{
    public abstract string Id { get; }
    public abstract string ColumnName { get; }
    public bool AlwaysShow => true;
    public ColumnCategory Category => ColumnCategory.Custom;
    public abstract int PriorityInCategory { get; }
    public abstract bool IsNumeric { get; }
    public abstract UnitType UnitType { get; }
    public abstract string Legend { get; }

    public abstract string GetValue(Summary summary, BenchmarkCase benchmarkCase);

    public string GetValue(Summary summary, BenchmarkCase benchmarkCase, SummaryStyle style)
        => GetValue(summary, benchmarkCase);

    public bool IsDefault(Summary summary, BenchmarkCase benchmarkCase) => false;
    public bool IsAvailable(Summary summary) => true;

    protected static int? GetRecordCountParameter(BenchmarkCase benchmarkCase)
    {
        var paramNames = new[] { "RecordCount", "BatchSize", "Count", "Size" };

        foreach (var name in paramNames)
        {
            var param = benchmarkCase.Parameters[name];
            if (param is int intValue)
                return intValue;
        }

        return null;
    }
}

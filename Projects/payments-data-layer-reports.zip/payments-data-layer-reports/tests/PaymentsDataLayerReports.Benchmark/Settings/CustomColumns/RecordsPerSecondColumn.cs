using BenchmarkDotNet.Columns;
using BenchmarkDotNet.Reports;
using BenchmarkDotNet.Running;

namespace PaymentsDataLayerReports.Benchmark.Settings.CustomColumns;

/// <summary>Custom column showing records processed per second.</summary>
public class RecordsPerSecondColumn : RecordBasedColumn
{
    public override string Id => "RecordsPerSec";
    public override string ColumnName => "Records/Sec";
    public override int PriorityInCategory => 1;
    public override bool IsNumeric => true;
    public override UnitType UnitType => UnitType.Dimensionless;
    public override string Legend => "Records processed per second";

    public override string GetValue(Summary summary, BenchmarkCase benchmarkCase)
    {
        var report = summary[benchmarkCase];
        if (report?.ResultStatistics == null)
            return "N/A";

        var recordCount = GetRecordCountParameter(benchmarkCase);
        if (recordCount == null)
            return "N/A";

        var meanNs = report.ResultStatistics.Mean;
        var meanSeconds = meanNs / 1_000_000_000.0;

        if (meanSeconds <= 0)
            return "N/A";

        var recordsPerSecond = recordCount.Value / meanSeconds;

        return recordsPerSecond switch
        {
            >= 1_000_000 => $"{recordsPerSecond / 1_000_000:N2}M",
            >= 1_000 => $"{recordsPerSecond / 1_000:N2}K",
            _ => $"{recordsPerSecond:N2}"
        };
    }
}

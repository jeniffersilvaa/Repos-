using BenchmarkDotNet.Columns;
using BenchmarkDotNet.Reports;
using BenchmarkDotNet.Running;

namespace PaymentsDataLayerReports.Benchmark.Settings.CustomColumns;

/// <summary>Custom column showing time per record in appropriate unit.</summary>
public class TimePerRecordColumn : RecordBasedColumn
{
    public override string Id => "TimePerRecord";
    public override string ColumnName => "Time/Record";
    public override int PriorityInCategory => 2;
    public override bool IsNumeric => true;
    public override UnitType UnitType => UnitType.Time;
    public override string Legend => "Time spent per record processed";

    public override string GetValue(Summary summary, BenchmarkCase benchmarkCase)
    {
        var report = summary[benchmarkCase];
        if (report?.ResultStatistics == null)
            return "N/A";

        var recordCount = GetRecordCountParameter(benchmarkCase);
        if (recordCount == null)
            return "N/A";

        var meanNs = report.ResultStatistics.Mean;
        var timePerRecordNs = meanNs / recordCount.Value;

        return timePerRecordNs switch
        {
            >= 1_000_000_000 => $"{timePerRecordNs / 1_000_000_000:N2} s",
            >= 1_000_000 => $"{timePerRecordNs / 1_000_000:N2} ms",
            >= 1_000 => $"{timePerRecordNs / 1_000:N2} μs",
            _ => $"{timePerRecordNs:N2} ns"
        };
    }
}

using System.Runtime.CompilerServices;
using BenchmarkDotNet.Analysers;
using BenchmarkDotNet.Columns;
using BenchmarkDotNet.Configs;
using BenchmarkDotNet.Diagnosers;
using BenchmarkDotNet.Jobs;
using BenchmarkDotNet.Loggers;
using BenchmarkDotNet.Order;
using BenchmarkDotNet.Reports;
using BenchmarkDotNet.Validators;
using PaymentsDataLayerReports.Benchmark.Settings.CustomColumns;
using PaymentsDataLayerReports.Benchmark.Settings.Exporters;

namespace PaymentsDataLayerReports.Benchmark.Settings;

/// <summary>Base benchmark configuration. Results saved to .Results/ folder.</summary>
public abstract class BaseBenchmarkConfig : ManualConfig
{
    private static string GetProjectDirectory([CallerFilePath] string sourceFilePath = "")
    {
        var directoryName = Path.GetDirectoryName(sourceFilePath);
        if (string.IsNullOrEmpty(directoryName))
        {
            throw new ArgumentException("Unable to determine benchmark project directory.", nameof(sourceFilePath));
        }

        return Path.GetFullPath(Path.Combine(directoryName, ".."));
    }

    protected BaseBenchmarkConfig()
    {
        var projectDir = GetProjectDirectory();
        var baseResultsPath = Path.Combine(projectDir, ".Results");
        WithArtifactsPath(baseResultsPath);
        WithOption(ConfigOptions.DontOverwriteResults, true);
        WithOptions(ConfigOptions.DisableLogFile);

        AddExporter(new MinimalCsvExporter());

        AddExporter(SuppressExporter.Html);
        AddExporter(SuppressExporter.CsvMeasurements);
        AddExporter(SuppressExporter.MarkdownGitHub);

        AddLogger(ConsoleLogger.Default);

        AddDiagnoser(MemoryDiagnoser.Default);

        AddAnalyser(EnvironmentAnalyser.Default);
        AddAnalyser(OutliersAnalyser.Default);
        AddAnalyser(MinIterationTimeAnalyser.Default);

        AddValidator(JitOptimizationsValidator.FailOnError);

        WithOrderer(new DefaultOrderer(SummaryOrderPolicy.Declared));

        AddColumn(TargetMethodColumn.Method);
        AddColumn(StatisticColumn.Mean);
        AddColumn(StatisticColumn.Error);
        AddColumn(StatisticColumn.StdDev);
        AddColumn(StatisticColumn.Median);
        AddColumn(RankColumn.Arabic);

        WithSummaryStyle(SummaryStyle.Default);
    }
}

/// <summary>Default configuration for simple benchmarks.</summary>
public class DefaultBenchmarkConfig : BaseBenchmarkConfig
{
    public DefaultBenchmarkConfig()
    {
        AddJob(Job.ShortRun
            .WithWarmupCount(3)
            .WithIterationCount(5)
            .WithId("Default"));
    }
}

/// <summary>Configuration for batch processing benchmarks (quick CI runs).</summary>
public class BatchProcessingBenchmarkConfig : BaseBenchmarkConfig
{
    public BatchProcessingBenchmarkConfig()
    {
        AddJob(Job.ShortRun
            .WithWarmupCount(3)
            .WithIterationCount(5)
            .WithId("Quick"));

        // Custom columns for batch processing analysis
        AddColumn(new AllocationPerRecordColumn());
        AddColumn(new RecordsPerSecondColumn());
        AddColumn(new TimePerRecordColumn());
    }
}

/// <summary>Configuration for stress testing (longer runs, more iterations).</summary>
public class StressTestBenchmarkConfig : BaseBenchmarkConfig
{
    public StressTestBenchmarkConfig()
    {
        AddJob(Job.MediumRun
            .WithWarmupCount(5)
            .WithIterationCount(10)
            .WithId("Stress"));

        // Custom columns for batch processing analysis
        AddColumn(new AllocationPerRecordColumn());
        AddColumn(new RecordsPerSecondColumn());
        AddColumn(new TimePerRecordColumn());
    }
}

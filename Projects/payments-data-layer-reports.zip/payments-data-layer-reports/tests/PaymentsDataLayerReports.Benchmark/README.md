# Suite de Benchmarks PaymentsDataLayerReports

Suite de benchmarks para medir **alocação de memória** dos fluxos de relatórios.

## Objetivo

Validar que o desempenho da aplicação se mantém estável entre versões, com foco principal em **alocações de memória**.

### Metodologia: Comparação Cross-Execuções

O fluxo de trabalho consiste em comparar resultados de benchmark entre duas versões do código:

```
┌─────────────────────────────────────────────────────────────────────────┐
│  1. BASELINE                        2. ALTERAÇÃO                        │
│  ─────────────────────────────────  ─────────────────────────────────── │
│  Branch estável (main/develop)      Branch com suas mudanças            │
│  ↓                                  ↓                                   │
│  Executar benchmarks                Executar benchmarks                 │
│  ↓                                  ↓                                   │
│  Salvar resultados                  Salvar resultados                   │
│  (.Results/YYYYMMDD-hhmmss/)        (.Results/YYYYMMDD-hhmmss/)         │
│                                                                         │
│                     3. COMPARAR RESULTADOS                              │
│                     ──────────────────────                              │
│                     Alloc/Record deve ser ≈ igual                       │
│                     Allocated não deve aumentar significativamente      │
└─────────────────────────────────────────────────────────────────────────┘
```

### Workflow Prático

```bash
# 1. Na branch estável (baseline)
git checkout main
dotnet run -c Release -- --filter *SeuFluxo* --exporters csv
# Resultado salvo em .Results/20241219-140000/

# 2. Na branch com alterações
git checkout feature/sua-feature
dotnet run -c Release -- --filter *SeuFluxo* --exporters csv
# Resultado salvo em .Results/20241219-143000/

# 3. Comparar os CSVs gerados
# Foco: colunas "Allocated" e "Alloc/Record"
```

### Critérios de Aceitação

| Métrica | Critério |
|---------|----------|
| **Alloc/Record** | Deve permanecer igual ou menor |
| **Allocated** | Variação aceitável < 5% |
| **Gen0/Gen1** | Não deve aumentar significativamente |
| **Gen2** | Deve permanecer 0 (ou muito baixo) |

> **Importante**: Regressões de memória são críticas em aplicações de streaming. Um aumento de alocação por registro se multiplica pelo volume total de dados processados.

## Estrutura do Projeto

```
PaymentsDataLayerReports.Benchmark/
├── Program.cs                      # Entry point (usa BenchmarkSwitcher)
├── .Results/                       # Resultados de benchmarks (gitignored)
├── Benchmarks/                     # Benchmarks por fluxo
│   ├── FinMov/
│   │   ├── FinMovESWorkerBenchmark.cs
│   │   ├── FinMovESWorkerStressBenchmark.cs
│   │   └── ReceivablesModifierBenchmark.cs
│   ├── Charge/
│   │   └── ChargeReportESWorkerBenchmark.cs
│   ├── Concat/
│   │   ├── S3ConcatWorkerBenchmark.cs
│   │   ├── ConcatBenchmarkDataset.cs
│   │   └── InMemoryS3Storage.cs
│   └── Order/
│       └── OrderReportESWorkerBenchmark.cs
├── Generators/                     # Geradores de dados fake
│   ├── FinancialMovementGenerator.cs
│   ├── ChargeGenerator.cs
│   └── CsvRowGenerator.cs
├── Mocks/                          # Mocks reutilizáveis
│   ├── MockDataLayerApiClient.cs
│   ├── MockPerformContext.cs
│   ├── NullSinkS3Client.cs
│   └── NullSinkMultiPartFileUploaderFactory.cs
└── Settings/                       # Configurações e colunas customizadas
    ├── BenchmarkConfig.cs          # Configs: Default, BatchProcessing, StressTest
    ├── CustomColumns/              # Colunas customizadas (Alloc/Record, etc.)
    └── Exporters/                  # Exportadores customizados
```

## Benchmarks Disponíveis

### FinMov (Fluxo API → S3)
- **FinMovESWorkerBenchmark**: Teste padrão com 1K-10K registros
- **FinMovESWorkerStressBenchmark**: Teste de stress com 10K-100K registros
- **ReceivablesModifierBenchmark**: Teste isolado do transformador de dados

### Charge (Fluxo S3 → Merge → S3)
- **ChargeReportESWorkerBenchmark**: Teste do worker de relatório de cobranças

### Concat (Fluxo de Concatenação)
- **S3ConcatWorkerBenchmark**: Teste do worker de concatenação S3

### Order (Fluxo de Ordenação)
- **OrderReportESWorkerBenchmark**: Teste do worker de ordenação

## Como Executar

```bash
cd tests/PaymentsDataLayerReports.Benchmark

# Menu interativo do BenchmarkDotNet
dotnet run -c Release

# Listar todos os benchmarks disponíveis
dotnet run -c Release -- --list flat

# Filtrar por fluxo
dotnet run -c Release -- --filter *FinMov*
dotnet run -c Release -- --filter *Charge*
dotnet run -c Release -- --filter *Concat*
dotnet run -c Release -- --filter *Order*

# Filtrar por tipo de benchmark
dotnet run -c Release -- --filter *Worker*
dotnet run -c Release -- --filter *Modifier*
dotnet run -c Release -- --filter *Stress*

# Executar um benchmark específico
dotnet run -c Release -- --filter FinMovESWorkerBenchmark.ProcessReport
```

## Configurações de Benchmark

O projeto oferece 3 configurações predefinidas:

| Config | Uso | Warmup | Iterações | Quando Usar |
|--------|-----|--------|-----------|------------|
| **DefaultBenchmarkConfig** | Testes simples e rápidos | 3 | 5 | Desenvolvimento local |
| **BatchProcessingBenchmarkConfig** | Testes padrão (com colunas customizadas) | 3 | 5 | CI/CD e comparações |
| **StressTestBenchmarkConfig** | Testes de carga com volumes altos | 5 | 10 | Validação de escalabilidade |

Colunas customizadas adicionadas automaticamente em BatchProcessing e StressTest:
- **Alloc/Record**: Bytes alocados por registro (métrica crítica)
- **Records/Second**: Throughput do processamento
- **Time/Record**: Latência por registro

## Interpretando Resultados

### Métricas Principais

| Métrica | Descrição |
|---------|-----------|
| **Mean** | Tempo médio de execução |
| **Allocated** | Total de bytes alocados por operação |
| **Alloc/Record** | Bytes alocados por registro processado (métrica crítica) |
| **Gen0/Gen1/Gen2** | Coletas de GC por 1000 operações |

### Exemplo de Output Real
```
| Method                            | RecordCount | Mean      | Alloc/Record | Allocated |
|---------------------------------- |------------ |----------:|-------------:|----------:|
| 'Transform Only (BuildRow loop)'  | 1000        |  6.13 ms  |   1,818 B    |   1.73 MB |
| 'Transform Only (BuildRow loop)'  | 5000        | 69.75 ms  |   1,818 B    |   8.67 MB |
| 'Transform Only (BuildRow loop)'  | 10000       | 52.59 ms  |   1,819 B    |  17.35 MB |
```

### O que Observar

1. **Alloc/Record constante**: Indica alocação linear (bom)
2. **Alloc/Record crescente**: Indica vazamento ou alocação quadrática (ruim)
3. **Gen2 > 0**: Indica objetos de longa duração sendo coletados (investigar)

## Output e Comparação de Resultados

Os resultados são salvos em `.Results/{YYYYMMDD-hhmmss}/`:

| Arquivo | Uso |
|---------|-----|
| `*-report.csv` | **Principal** - Resumo para comparações |
| `*-measurements.csv` | Medições detalhadas de cada iteração |

### Como Comparar Duas Execuções

```bash
# 1. Executar benchmark na branch estável (baseline)
git checkout main
dotnet run -c Release -- --filter *FinMov* --exporters csv
# Salva em: .Results/20241222-140000/

# 2. Mudar para branch com alterações
git checkout feature/sua-feature
dotnet run -c Release -- --filter *FinMov* --exporters csv
# Salva em: .Results/20241222-143000/

# 3. Comparar os CSVs
# Abrir em Excel/Sheets e comparar colunas:
# - Alloc/Record (deve ser igual ou menor)
# - Allocated (variação < 5%)
# - Gen0/Gen1 (não deve aumentar)
```

## Como Adicionar Novos Benchmarks

### 1. Criar a classe de benchmark

Crie um arquivo em `Benchmarks/{Fluxo}/` seguindo a convenção `{Componente}Benchmark.cs`:

```csharp
using BenchmarkDotNet.Attributes;
using PaymentsDataLayerReports.Benchmark.Settings;

namespace PaymentsDataLayerReports.Benchmark.Benchmarks.SeuFluxo;

/// <summary>
/// Descrição do que está sendo medido.
/// </summary>
[Config(typeof(BatchProcessingBenchmarkConfig))]
public class SeuComponenteBenchmark
{
    private SeuTipo _dados = null!;

    [Params(100, 1000)]  // Tamanhos de batch para testar
    public int BatchSize { get; set; }

    [GlobalSetup]
    public void Setup()
    {
        // Inicializa dados de teste (não é medido)
        _dados = SeuGenerator.Generate(BatchSize);
    }

    [Benchmark(Description = "Nome descritivo do cenário")]
    public int SeuMetodo()
    {
        // Código a ser medido
        // Retorne algo para evitar otimização do compilador
        return _dados.Count;
    }
}
```

### 2. Convenções

| Item | Convenção |
|------|----------|
| **Namespace** | `PaymentsDataLayerReports.Benchmark.Benchmarks.{Fluxo}` |
| **Classe** | `{Componente}Benchmark` |
| **Config** | Usar `BatchProcessingBenchmarkConfig` para consistência |
| **Setup** | Inicializar dados em `[GlobalSetup]`, não no benchmark |
| **Retorno** | Sempre retornar algo para evitar dead code elimination |

### 3. Criar generator (se necessário)

Se precisar de dados fake, crie em `Generators/{Tipo}Generator.cs`.

## Troubleshooting

### Erro: "Assembly not found" ou benchmark não aparece

**Causa**: Classe não é pública ou não tem métodos `[Benchmark]`.

```bash
# Verificar se o benchmark está visível
dotnet run -c Release -- --list flat
```

### Resultados inconsistentes ou muito rápidos

**Causa**: Executando em modo Debug.

```bash
# SEMPRE usar Release
dotnet run -c Release -- --filter *SeuBenchmark*
```

### Erro: "Allocated" mostra 0 B

**Causa**: O método está sendo otimizado pelo JIT (dead code elimination).

**Solução**: Retorne um valor derivado do resultado:

```csharp
// ❌ Errado - pode ser otimizado
[Benchmark]
public void ProcessarDados()
{
    var resultado = Processar(_dados);
}

// ✅ Correto - retorno evita otimização
[Benchmark]
public int ProcessarDados()
{
    var resultado = Processar(_dados);
    return resultado.Length;
}
```

### Benchmark demora muito

**Causa**: BenchmarkDotNet executa múltiplas iterações para precisão estatística.

```bash
# Para testes rápidos durante desenvolvimento (menos preciso)
dotnet run -c Release -- --filter *SeuBenchmark* --job short
```

### Permissão negada ao salvar resultados

**Causa**: Diretório `.Results/` sem permissão de escrita.

```bash
chmod -R 755 .Results/
```

## Boas Práticas

### Ao Criar Novos Benchmarks

1. **Sempre use Release**: Benchmarks em Debug são inúteis
   ```bash
   dotnet run -c Release -- --filter *SeuBenchmark*
   ```

2. **Isolamento**: Cada benchmark deve testar um componente específico
   - FinMovESWorker: pipeline completo (Fetch → Transform → Write)
   - ReceivablesModifier: apenas transformação de dados
   - S3ConcatWorker: apenas concatenação

3. **Dados realistas**: Use generators que simulem dados de produção
   - FinancialMovementGenerator: registros financeiros
   - ChargeGenerator: registros de cobranças
   - CsvRowGenerator: linhas CSV genéricas

4. **Parâmetros variados**: Teste com múltiplos tamanhos
   ```csharp
   [Params(1_000, 5_000, 10_000)]
   public int RecordCount { get; set; }
   ```

5. **Setup vs Benchmark**: Inicialização vai em `[GlobalSetup]`, não no método medido
   ```csharp
   [GlobalSetup]
   public void Setup() { /* não é medido */ }
   
   [Benchmark]
   public void MeuBenchmark() { /* é medido */ }
   ```

### Ao Analisar Resultados

1. **Foco em Alloc/Record**: Esta é a métrica mais crítica para streaming
2. **Tendência linear**: Alloc/Record deve ser constante (não crescente)
3. **Gen2 = 0**: Objetos não devem sobreviver a Gen1
4. **Comparar com baseline**: Sempre compare com a branch estável antes de mergear

### Ao Otimizar

1. **Medir antes de otimizar**: Sempre execute benchmarks antes e depois
2. **Regressão de memória é crítica**: Um aumento de 1 byte por registro × 1M registros = 1MB extra
3. **Considerar o trade-off**: Às vezes um pouco mais de alocação vale a pena por melhor legibilidade
4. **Validar com stress test**: Use `StressTestBenchmarkConfig` para volumes altos (10K-100K)

---
auto_execution_mode: 3
description: Review code changes for bugs, security issues, and improvements
inputs:
  PR_NUMBER: "Número ou URL da PR a ser revisada"
---

You are a senior software engineer performing a thorough code review to identify potential bugs.

Workflow com PR_NUMBER usando GitHub CLI:

1) Preparar contexto da PR
   - Rode `gh pr view ${PR_NUMBER} --json title,body,author,headRefName,baseRefName,comments,reviews,files --jq . > /tmp/pr_view.json` para evitar truncamento e coletar descrição, base/head, arquivos alterados, comentários e revisões já existentes. Não repita feedback já dado.
   - Rode `gh pr diff ${PR_NUMBER} --color=never > /tmp/pr_diff.patch` para obter o diff completo sem truncamento. Esse comando já compara head vs base da PR (não assume main).
   - (Opcional) `gh pr checkout ${PR_NUMBER}` para inspecionar arquivos localmente.

2) Revisar considerando o estilo do repositório
   - Consulte arquivos de estilo/padrões locais (ex.: `.editorconfig`, `README.md`, `docs/`, `CONTRIBUTING.md`).

3) Critérios do review
   - Encontre bugs, riscos de regressão, edge cases não cobertos, problemas de concorrência, segurança, violação de contratos de API, uso incorreto de cache, naming e logging fora do padrão.
   - Cite arquivos e linhas quando possível e ordene achados por severidade (Alta/Média/Baixa).
   - Verifique cobertura de testes e caminhos de erro.
   - Verifique a documentação de BREAKING_CHANGES e se está aplicando os critérios definidos por ela quando a alterçaão for breaking change

4) Formato de saída
   - Contexto: resumo da PR (objetivo, escopo, base/head).
   - Achados por severidade com referências.
   - Gaps de testes.
   - Sugestões opcionais.

Sua tarefa é encontrar possíveis bugs e melhorias nas mudanças de código. Foque em:
1. Erros de lógica e comportamento incorreto
2. Edge cases não tratados
3. Problemas de referência nula/indefinida
4. Condições de corrida ou concorrência
5. Vulnerabilidades de segurança
6. Mau uso de recursos ou vazamentos
7. Violações de contratos de API
8. Problemas de cache (staleness, chave errada, invalidação incorreta ou cache inefetivo)
9. Violações de padrões/convencões existentes

Certifique-se de:
1. Se precisar explorar o codebase, use ferramentas em paralelo para ser eficiente e não gastar tempo demais explorando.
2. Reportar bugs preexistentes também, para manter a qualidade geral.
3. Não reportar itens especulativos ou de baixa confiança; conclua apenas com entendimento completo do código.
4. Lembrar que, se um commit específico foi mencionado, ele pode não estar checado localmente e o estado do código pode ser diferente.

namespace PaymentsDataLayerReports.Application.Middlewares;

public class OriginMiddleware
{
    private readonly RequestDelegate _next;

    public OriginMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task InvokeAsync(HttpContext httpContext)
    {
        var origin = httpContext.Request.Headers.Origin.ToString();
        var userAgent = httpContext.Request.Headers.UserAgent.ToString();

        httpContext.Request.Headers["Origin"] = !string.IsNullOrEmpty(origin) ? origin : userAgent;

        await _next(httpContext);
    }
}

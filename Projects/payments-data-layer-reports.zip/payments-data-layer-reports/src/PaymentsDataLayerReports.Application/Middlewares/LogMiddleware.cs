using Serilog.Context;

namespace PaymentsDataLayerReports.Application.Middlewares;

public class LogMiddleware
{
    private readonly RequestDelegate _next;

    public LogMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task InvokeAsync(HttpContext httpContext)
    {
        var requestId = Guid.NewGuid().ToString();

        LogContext.PushProperty("RequestId", requestId);

        httpContext.Response.Headers["RequestId"] = new string[] { requestId };
        httpContext.Response.Headers["Protocol"] = new string[] { httpContext.Request.Protocol };
        httpContext.Response.Headers["Method"] = new string[] { httpContext.Request.Method };
        httpContext.Response.Headers["Scheme"] = new string[] { httpContext.Request.Scheme };
        httpContext.Response.Headers["PathBase"] = new string[] { httpContext.Request.PathBase };
        httpContext.Response.Headers["Path"] = new string[] { httpContext.Request.Path };
        httpContext.Response.Headers["QueryString"] = new string[] { httpContext.Request.QueryString.ToString() };
        httpContext.Response.Headers["Accept"] = new string[] { httpContext.Request.Headers.Accept.ToString() };
        httpContext.Response.Headers["Host"] = new string[] { httpContext.Request.Headers.Host.ToString() };
        httpContext.Response.Headers["UserAgent"] = new string[] { httpContext.Request.Headers.UserAgent.ToString() };

        await _next(httpContext);
    }
}

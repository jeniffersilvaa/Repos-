using System.Diagnostics;

namespace PaymentsDataLayerReports.Application.Types;

internal readonly struct BetterStopwatch
{
    private static readonly double _timestampToTicks = TimeSpan.TicksPerSecond / (double)Stopwatch.Frequency;

    internal static long GetTimestamp() => Stopwatch.GetTimestamp();

    internal static TimeSpan GetElapsedTime(long startTimestamp, long endTimestamp)
    {
        var timestampDelta = endTimestamp - startTimestamp;
        return GetTicks(timestampDelta);
    }

    internal static TimeSpan GetElapsedTime(long startTimestamp)
    {
        var timestampDelta = GetTimestamp() - startTimestamp;
        return GetTicks(timestampDelta);
    }

    private static TimeSpan GetTicks(long timestampDelta)
    {
        var ticks = (long)(_timestampToTicks * timestampDelta);
        return new TimeSpan(ticks);
    }
}
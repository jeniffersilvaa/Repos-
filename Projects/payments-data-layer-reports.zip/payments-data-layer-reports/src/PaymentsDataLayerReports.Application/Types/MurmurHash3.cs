using System.Text;

namespace PaymentsDataLayerReports.Application.Types;

public class MurmurHash3
{
    private const int C1 = unchecked((int)0xcc9e2d51);
    private const int C2 = unchecked((int)0x1b873593);
    private const int SEED = 42;

    public static int HashUnsafeBytes(string input)
    {
        byte[] baseArray = Encoding.UTF8.GetBytes(input);
        int lengthInBytes = baseArray.Length;

        int lengthAligned = lengthInBytes - (lengthInBytes % 4);
        int h1 = HashBytesByInt(baseArray, lengthAligned);

        for (int i = lengthAligned; i < lengthInBytes; i++)
        {
            int halfWord = baseArray[i] & 0xFF;
            int k1 = MixK1(halfWord);
            h1 = MixH1(h1, k1);
        }

        return Fmix(h1, lengthInBytes);
    }

    private static int HashBytesByInt(byte[] baseArray, int lengthInBytes)
    {
        if (lengthInBytes % 4 != 0) throw new ArgumentException("lengthInBytes must be a multiple of 4");

        int h1 = SEED;
        for (int i = 0; i < lengthInBytes; i += 4)
        {
            byte[] fourBytes = new byte[4];
            Array.Copy(baseArray, i, fourBytes, 0, 4);

            if (!BitConverter.IsLittleEndian)
            {
                Array.Reverse(fourBytes);
            }

            int halfWord = BitConverter.ToInt32(fourBytes, 0);
            h1 = MixH1(h1, MixK1(halfWord));
        }
        return h1;
    }

    private static int MixK1(int k1)
    {
        k1 *= C1;
        k1 = RotateLeft(k1, 15);
        k1 *= C2;
        return k1;
    }

    private static int MixH1(int h1, int k1)
    {
        h1 ^= k1;
        h1 = RotateLeft(h1, 13);
        h1 = h1 * 5 + unchecked((int)0xe6546b64);
        return h1;
    }

    private static int Fmix(int h1, int length)
    {
        h1 ^= length;
        h1 ^= h1 >>> 16;
        h1 *= unchecked((int)0x85ebca6b);
        h1 ^= h1 >>> 13;
        h1 *= unchecked((int)0xc2b2ae35);
        h1 ^= h1 >>> 16;
        return h1;
    }

    private static int RotateLeft(int value, int shift)
    {
        return (value << shift) | (int)((uint)value >> (32 - shift));
    }
}

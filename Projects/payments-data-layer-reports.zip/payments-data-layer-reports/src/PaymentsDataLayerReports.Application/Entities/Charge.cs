using PaymentsDataLayerReports.Application.Entities.Models.Charge;

namespace PaymentsDataLayerReports.Application.Entities;

public record Charge(
    string Id,
    string InitiatorId,
    string? Product,
    string? Origin,
    string? OriginId,
    int? Amount,
    int? UpdatedAmount,
    int? NetAmount,
    decimal? FullNetAmount,
    string Status,
    string PaymentMethod,
    DateTimeOffset CreatedAt,
    string? PlatformName,
    int? AttemptCount,
    string? Gateway,
    string? GatewayOrderId,
    string? Code,
    string? AllIds,
    Merchant Merchant,
    IReadOnlyList<Split> Split,
    CardTransaction? CardTransaction,
    PixTransaction? PixTransaction,
    BoletoTransaction? BoletoTransaction,
    CashTransaction? CashTransaction,
    string? ChargeId = null,
    string? PointOfInteractionType = null,
    Dictionary<string, string>? Metadata = null
);

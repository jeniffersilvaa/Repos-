﻿namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record CashDetail(
    string? Operation,
    string? OperationId,
    DateTime? LocalDateTime,
    DateTime? ProviderDatetime,
    long? OperationAmount,
    string? OperationReason,
    Legacy? Legacy,
    string? OperationStatus,
    string? Pgid
);
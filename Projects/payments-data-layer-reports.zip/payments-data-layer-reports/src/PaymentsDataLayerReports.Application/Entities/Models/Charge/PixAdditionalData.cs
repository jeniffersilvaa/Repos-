namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record PixAdditionalData(
    string Name,
    string Value
);

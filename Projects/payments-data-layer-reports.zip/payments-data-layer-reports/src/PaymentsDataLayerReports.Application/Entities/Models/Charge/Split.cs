namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record Split(
    string Id,
    string RecipientId,
    string GatewayRecipientId
    );
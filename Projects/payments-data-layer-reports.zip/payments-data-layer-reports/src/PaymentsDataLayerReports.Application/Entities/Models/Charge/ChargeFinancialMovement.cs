namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record ChargeFinancialMovement(
    string? Operation,
    string? OperationId,
    string? DetailOperationId,
    DateOnly? CurrentDueDate,
    DateOnly? OriginalDueDate,
    string? PaymentOwnerDocument,
    string? SettlementStatus,
    string? Category,
    short? InstallmentNumber,
    FinancialMovementAmount? Amount,
    string? Id,
    string? PaymentMethod,
    string? SplitRuleId,
    string? BulkAnticipationId,
    string? PaymentOwnerId,
    string? RecipientId,
    string? PaymentOwnerStoneAccount,
    DateTime? CreatedAt,
    DateTime? LatestEventDatetime
);

public record FinancialMovementAmount(
    decimal? Gross,
    decimal? Net,
    FinancialMovementFee? DiscountRate,
    FinancialMovementFee? PrepaymentFee,
    FinancialMovementFee? FraudCoverage,
    FinancialMovementFee? PrepaymentFeeTurbo
);

public record FinancialMovementFee(
    string? FeeType,
    decimal? Fee,
    decimal? EffectiveFee,
    decimal? Amount
);
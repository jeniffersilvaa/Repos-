namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record ChargeOperation(
    string ChargeId,
    DateTimeOffset CreatedAt,
    string PaymentMethod,
    Merchant Merchant,
    string? Type,
    string FundingSource,
    string Brand,
    int Installments,
    string Operation,
    string OperationId,
    int OperationAmount,
    DateTime OperationDatetime,
    string? OperationReason,
    string AcquirerReturnCode
);

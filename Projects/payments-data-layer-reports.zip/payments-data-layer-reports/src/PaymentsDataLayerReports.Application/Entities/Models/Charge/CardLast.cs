namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record CardLast(
    string? OperationStatus,
    string? AntifraudStatus,
    string? AcquirerName,
    string? AcquirerReturnCode,
    string? LegacyStatus
);
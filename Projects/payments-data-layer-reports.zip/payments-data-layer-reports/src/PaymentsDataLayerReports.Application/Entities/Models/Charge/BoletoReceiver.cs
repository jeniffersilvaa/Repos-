namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record BoletoReceiver(
    string? Name,
    string? DocumentType,
    string? Document
);

namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record PixFine(
    string? StartAt,
    string? Type,
    string? Value
);

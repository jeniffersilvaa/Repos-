namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record Last(
    string? OperationStatus,
    string? LegacyStatus
);
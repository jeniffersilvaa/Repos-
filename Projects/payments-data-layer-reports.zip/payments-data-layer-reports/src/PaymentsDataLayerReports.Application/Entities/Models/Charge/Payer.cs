namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record Payer(
    string? Name,
    string? DocumentType,
    string? Document,
    string? Ispb,
    string? InstitutionName
);

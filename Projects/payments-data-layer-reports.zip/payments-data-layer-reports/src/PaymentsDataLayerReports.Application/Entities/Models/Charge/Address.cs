namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record Address(
    string? Street,
    string? StreetNumber,
    string? Extra,
    string? Neighborhood,
    string? PostalCode,
    string? City,
    string? State,
    string? Country
);

namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record Penalty(
    string? StartAt,
    string? Type,
    string? Value
);

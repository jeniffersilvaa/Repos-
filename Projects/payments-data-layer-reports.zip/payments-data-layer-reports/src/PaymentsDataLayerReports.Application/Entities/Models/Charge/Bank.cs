namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record Bank(
    string Code,
    string Name
);

namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record PixCustomer(
    string? Name,
    string? DocumentType,
    string? Document,
    string? Email,
    string? CustomerId,
    Address? Address
);

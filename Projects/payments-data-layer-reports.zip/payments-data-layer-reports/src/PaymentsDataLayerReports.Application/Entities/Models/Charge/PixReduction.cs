namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record PixReduction(
    string? StartAt,
    string? Value
);

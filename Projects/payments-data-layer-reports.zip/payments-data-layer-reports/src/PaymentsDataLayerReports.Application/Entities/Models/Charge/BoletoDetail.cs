namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record BoletoDetail(
    string Operation,
    string OperationId,
    DateTime? ProviderDatetime,
    DateTime? LocalDatetime,
    int? OperationAmount,
    string Reason,
    GatewayResponse? GatewayResponse,
    Legacy? Legacy,
    string OperationStatus,
    AntifraudResponse? AntifraudResponse,
    string Pgid
);

namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record CardDetail(
    string Operation,
    string OperationId,
    int OperationAmount,
    DateTime ProviderDatetime,
    DateTime? LocalDatetime,
    string AcquirerMessage,
    string? AcquirerReturnCode,
    string? OperationReason,
    string? Pgid,
    Acquirer? Acquirer,
    GatewayResponse? GatewayResponse,
    AntifraudResponse? AntifraudResponse,
    Legacy? Legacy,
    string? OperationStatus
);
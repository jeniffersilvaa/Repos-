namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record Acquirer(
    string? Name,
    string? Nsu,
    string? Tid
);

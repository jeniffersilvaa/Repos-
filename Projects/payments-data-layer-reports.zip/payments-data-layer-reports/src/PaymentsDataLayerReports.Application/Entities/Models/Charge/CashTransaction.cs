namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record CashTransaction(
    string? Description,
    string? TransactionId,
    long? PaidAmount,
    long? CanceledAmount,
    Customer Customer,
    Last? Last,
    IReadOnlyList<CashDetail> Details
);
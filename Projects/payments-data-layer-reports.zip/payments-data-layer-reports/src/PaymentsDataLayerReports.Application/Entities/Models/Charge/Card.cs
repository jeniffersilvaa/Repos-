namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record Card(
    string Brand,
    byte? BrandId,
    string FirstSixDigits,
    string LastFourDigits,
    string EntryMode,
    string HolderName,
    string ExpMonth,
    string ExpYear,
    short? CountryCode,
    short? CurrencyCode,
    string? NumberToken,
    string? Label
);
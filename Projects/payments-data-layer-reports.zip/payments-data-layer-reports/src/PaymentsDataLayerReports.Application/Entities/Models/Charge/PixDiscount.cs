namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record PixDiscount(
    string? ExpireAt,
    string? Type,
    string? Value,
    string? CalculationMode
);

﻿namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record Merchant(
    string Organization,
    string Document,
    string UserId,
    string AffiliationKey,
    string AffiliationCode,
    string AccountId,
    string MerchantId,
    string? StoneAccount = null,
    string? PaymentProfileId = null
);
namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record PixDetail(
    string Operation,
    string OperationId,
    DateTime? LocalDatetime,
    DateTime ProviderDatetime,
    int OperationAmount,
    string? QrcodeContent,
    string? Description,
    string? RefundId,
    string? Reason,
    GatewayResponse? GatewayResponse,
    Legacy? Legacy,
    AntifraudResponse? AntifraudResponse,
    string? Pgid
);

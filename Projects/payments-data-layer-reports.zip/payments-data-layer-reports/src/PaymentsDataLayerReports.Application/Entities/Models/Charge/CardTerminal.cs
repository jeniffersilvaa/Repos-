namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record CardTerminal(
    string Type,
    string SerialNumber
);
namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record PixInterest(
    string? StartAt,
    string? Type,
    string? Value,
    string? Period
);

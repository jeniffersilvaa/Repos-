﻿
namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record AntifraudResponse(
    string? ProviderName,
    string? Score,
    string? Status
);
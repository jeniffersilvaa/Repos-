namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record GatewayResponse(
    string? Code,
    string? Message
);
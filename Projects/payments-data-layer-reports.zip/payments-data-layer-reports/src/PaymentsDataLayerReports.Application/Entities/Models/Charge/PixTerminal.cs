namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record PixTerminal(
    string? Type,
    string? SerialNumber
);

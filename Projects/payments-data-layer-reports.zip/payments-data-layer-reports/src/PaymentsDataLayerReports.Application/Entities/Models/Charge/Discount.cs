namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record Discount(
    string? ExpireAt,
    string? Type,
    string? Value
);

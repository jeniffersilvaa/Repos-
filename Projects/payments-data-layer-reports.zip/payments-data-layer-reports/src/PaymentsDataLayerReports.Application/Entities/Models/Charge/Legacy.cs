namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record Legacy(
    string Status,
    string? Operation,
    string TransactionStatus,
    int? CanceledAmount,
    string AccountName
);


namespace PaymentsDataLayerReports.Application.Entities.Models.Charge;

public record Customer
{
    public string? Name { get; set; }
    public string? DocumentType { get; set; }
    public string? Document { get; set; }
    public string? CustomerId { get; set; }
    public Address? Address { get; set; }
    public IList<string>? Telephones { get; set; }
    public string? Email { get; set; }
}
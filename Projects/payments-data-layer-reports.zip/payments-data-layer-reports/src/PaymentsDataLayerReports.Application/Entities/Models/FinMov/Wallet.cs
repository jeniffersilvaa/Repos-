namespace PaymentsDataLayerReports.Application.Entities.Models.FinMov;

public record Wallet(
    string? Description,
    string? Nature,
    int? TypeId
);

namespace PaymentsDataLayerReports.Application.Entities.Models.FinMov;

public record Settlement(
    Wallet? Wallet,
    string? BalanceDueDate,
    string? Key,
    string? PaymentDate,
    string? Status,
    Payment? Payment
);

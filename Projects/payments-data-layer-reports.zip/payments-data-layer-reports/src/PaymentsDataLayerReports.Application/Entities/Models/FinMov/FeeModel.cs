namespace PaymentsDataLayerReports.Application.Entities.Models.FinMov;

public record FeeModel(
    decimal? Amount,
    decimal? Fee,
    decimal? EffectiveFee,
    string? FeeType
);

namespace PaymentsDataLayerReports.Application.Entities.Models.FinMov;

public record Movement(
    string? EventId,
    string? Category,
    decimal? Amount,
    decimal? Fee,
    decimal? EffectiveFee,
    string? FeeType,
    DateTime? CreationDate
);

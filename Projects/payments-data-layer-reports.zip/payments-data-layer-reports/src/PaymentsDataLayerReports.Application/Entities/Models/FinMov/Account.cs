namespace PaymentsDataLayerReports.Application.Entities.Models.FinMov;

public record Account(
    string? AccountCheckDigit,
    string? AccountNumber,
    string? AccountType,
    string? BankCode,
    string? BranchNumber,
    string? BranchCheckDigit,
    string? Ispb
);

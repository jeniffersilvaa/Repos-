namespace PaymentsDataLayerReports.Application.Entities.Models.FinMov;

public record Amount(
    decimal? Gross,
    decimal? Net,
    FeeModel? DiscountRate,
    FeeModel? PrepaymentFee,
    FeeModel? PrepaymentFeeTurbo
);

namespace PaymentsDataLayerReports.Application.Entities.Models.FinMov;

public record Merchant(
    string? AffiliationCode,
    string? UserId,
    string? Organization,
    string? Document,
    string? AffiliationKey,
    string? PaymentProfileId
);

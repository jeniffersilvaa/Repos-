namespace PaymentsDataLayerReports.Application.Entities.Models.FinMov;

public record Payment(
    string? PaymentDate,
    string? Status,
    Account? Account
);

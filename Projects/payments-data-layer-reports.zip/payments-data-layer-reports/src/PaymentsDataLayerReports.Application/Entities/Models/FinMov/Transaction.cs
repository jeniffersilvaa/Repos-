namespace PaymentsDataLayerReports.Application.Entities.Models.FinMov;

public record Transaction(
    string? Product,
    string? AuthorizationDate,
    int? InstallmentNumber,
    int? InstallmentQuantity,
    string? CaptureDate,
    string? OperationKey,
    string? AccountFundingSource,
    string? Brand,
    string? Key,
    string? PointOfInteractionType
);

namespace PaymentsDataLayerReports.Application.Entities.Models.Order;

public record Device(string Platform);
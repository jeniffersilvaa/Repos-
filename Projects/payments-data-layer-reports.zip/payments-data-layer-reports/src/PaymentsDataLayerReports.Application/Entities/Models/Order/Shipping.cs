namespace PaymentsDataLayerReports.Application.Entities.Models.Order;

public record Shipping(
    int Amount,
    string Description,
    string RecipientName,
    string RecipientPhone,
    Address Address
);

public record Address(
    string Id,
    string Street,
    string Neighborhood,
    string Number,
    string City,
    string State,
    string Country,
    string ZipCode
);
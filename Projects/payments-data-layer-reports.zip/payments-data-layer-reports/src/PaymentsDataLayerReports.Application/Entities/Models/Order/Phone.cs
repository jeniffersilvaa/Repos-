namespace PaymentsDataLayerReports.Application.Entities.Models.Order;


public record Phone(
     string AreaCode,
     string CountryCode,
     string Number
);
namespace PaymentsDataLayerReports.Application.Entities.Models.Order;

public record Customer(
     string Name,
     string Email,
     string Document,
     string Type,
     string Id,
     Address Address,
     Phones Phones
);
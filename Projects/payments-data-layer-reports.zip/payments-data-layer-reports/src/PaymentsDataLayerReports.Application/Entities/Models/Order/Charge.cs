namespace PaymentsDataLayerReports.Application.Entities.Models.Order;

public record Charge(
     string Id
);
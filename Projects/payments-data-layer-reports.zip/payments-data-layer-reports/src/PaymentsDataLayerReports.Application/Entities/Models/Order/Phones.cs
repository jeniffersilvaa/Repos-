namespace PaymentsDataLayerReports.Application.Entities.Models.Order;


public class Phones
{
    public Phone? HomePhone { get; init; }
    public Phone? MobilePhone { get; init; }


    private static string FormatPhone(Phone? phone)
    {
        return $"{phone?.CountryCode ?? string.Empty}{phone?.AreaCode ?? string.Empty}{phone?.Number ?? string.Empty}";
    }

    public string GetHomePhoneString()
    {
        return FormatPhone(HomePhone);
    }

    public string GetMobilePhoneString()
    {
        return FormatPhone(MobilePhone);
    }
}
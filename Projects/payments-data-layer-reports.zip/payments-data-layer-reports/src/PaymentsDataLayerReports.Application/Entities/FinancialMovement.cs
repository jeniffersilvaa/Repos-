using PaymentsDataLayerReports.Application.Entities.Models.FinMov;

namespace PaymentsDataLayerReports.Application.Entities;

public record FinancialMovement(
    string? Id,
    string? OperationId,
    string? Operation,
    string? OriginalDueDate,
    string? CurrentDueDate,
    string? LatestEventTimestamp,
    string? UpdatedAt,
    Amount? Amount,
    Merchant? Merchant,
    Merchant? PaymentOwner,
    Transaction? Transaction,
    Settlement? Settlement,
    List<Movement>? Movements
);
using PaymentsDataLayerReports.Application.Entities.Models.Order;

namespace PaymentsDataLayerReports.Application.Entities;

public record Order(
    int Amount,
    Models.Order.Charge[] Charges,
    string Code,
    Customer Customer,
    Device? Device,
    Shipping? Shipping,
    string Status,
    string Id,
    Dictionary<string, object>? Metadata,
    DateTime CreatedAt,
    DateTime UpdatedAt,
    DateTime? ClosedAt,
    int CheckoutsCount
);
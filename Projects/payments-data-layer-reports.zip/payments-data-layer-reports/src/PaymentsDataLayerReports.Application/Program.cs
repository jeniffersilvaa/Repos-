using System.Globalization;
using System.Text.Json;
using Amazon;
using Amazon.Runtime;
using Amazon.S3;
using Amazon.S3.Transfer;
using Elastic.Clients.Elasticsearch;
using Elastic.Clients.Elasticsearch.Serialization;
using Elastic.Transport;
using FluentValidation;
using Hangfire;
using HealthChecks.UI.Client;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.AspNetCore.Http.Json;
using Microsoft.Extensions.FileProviders;
using Microsoft.IO;
using PaymentsDataLayerReports.Application.Authentication;
using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Extensions;
using PaymentsDataLayerReports.Application.Infra.DataLayerApi;
using PaymentsDataLayerReports.Application.Infra.DataLayerReport;
using PaymentsDataLayerReports.Application.Infra.LegacyIdSystemAPI;
using PaymentsDataLayerReports.Application.Infra.MultiPartFileUploader;
using PaymentsDataLayerReports.Application.Infra.MultiPartFileUploader.Interfaces;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Metrics;
using PaymentsDataLayerReports.Application.Middlewares;
using PaymentsDataLayerReports.Application.Routes.Management;
using PaymentsDataLayerReports.Application.Routes.Reports;
using PaymentsDataLayerReports.Application.Services.DeltaTableColumnMapping;
using PaymentsDataLayerReports.Application.Services.IdempotentJobManager;
using PaymentsDataLayerReports.Application.Services.IdMapper;
using PaymentsDataLayerReports.Application.Services.ReportEnqueue;
using PaymentsDataLayerReports.Application.Services.ReportEnqueue.Interfaces;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Interfaces;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Sinks;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.StreamWriters;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Concat;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.ChargeList;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.ChargesEvents;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.FinMovList;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.RealtimeChargeEvents;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;
using PaymentsDataLayerReports.Application.Workers.NotificationWorkerV2.Services;
using PaymentsDataLayerReports.Application.Workers.Shared;
using PaymentsDataLayerReports.Application.Workers.Shared.Mappers.Charges;
using Serilog;
using StackExchange.Redis;


CultureInfo.DefaultThreadCurrentCulture = CultureInfo.InvariantCulture;
CultureInfo.DefaultThreadCurrentUICulture = CultureInfo.InvariantCulture;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRouting();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new() { Title = "PaymentsDataLayerReports", Version = "v1" });
    c.SchemaFilter<SnakeCaseSchemaFilter>();
});

builder.Services.AddProblemDetails();
builder.Services.Configure<RouteHandlerOptions>(o => o.ThrowOnBadRequest = true);
builder.Services.AddHealthChecks();
builder.Services.AddHttpContextAccessor();

// Add Singleton Services
builder.Services.AddSingleton<IConnectionMultiplexer>(ConnectionMultiplexer.Connect(builder.Configuration.GetValue<string>($"{RedisSettings.RedisSettingsSection}:Url")!));
builder.Services.AddSingleton<IS3ClientWrapper, S3ClientWrapper>();
builder.Services.AddSingleton<IS3ReportMergeService, S3ReportMergeService>();
builder.Services.AddSingleton<IS3ReportMetadataHandlerService, S3ReportMetadataHandlerService>();
builder.Services.AddSingleton<IS3ReportUploadService, S3ReportUploadService>();
builder.Services.AddSingleton<IS3ReportFileQueryService, S3ReportFileQueryService>();
builder.Services.AddSingleton<IDataLayerApiClient, DataLayerApiClient>();
builder.Services.AddSingleton<ILegacyIdSystemAPIClient, LegacyIdSystemAPIClient>();
builder.Services.AddSingleton<IDataLayerReportPreDeployClient, DataLayerReportPreDeployClient>();
builder.Services.AddSingleton<IRealtimeChargeEventsService, RealtimeChargeEventsService>();
builder.Services.AddSingleton<HangfireAuthorizationFilter>();
builder.Services.AddSingleton<IColumnMappingService, ColumnMappingService>();
builder.Services.AddSingleton<ITransferUtility>(sp => new TransferUtility(sp.GetRequiredService<IAmazonS3>()));
builder.Services.AddSingleton<IIdempotentJobManager, IdempotentJobManager>();
builder.Services.AddSingleton<RecyclableMemoryStreamManager>();
builder.Services.AddSingleton<IIdMapperService, IdMapperService>();
builder.Services.AddKeyedScoped<IESReportEnqueueService, ESReceivableReportEnqueueService>("receivable");
builder.Services.AddKeyedSingleton<ISaleCsvMapper<Charge>, ChargeCsvMapper>("charges_list");
builder.Services.AddKeyedSingleton<ISaleCsvMapper<Charge>, SaleStoneCsvMapper>("sales_stone");
builder.Services.AddKeyedSingleton<ISaleCsvMapper<Charge>, SaleTonCsvMapper>("sales_ton");
builder.Services.AddKeyedSingleton<ISaleCsvMapper<Charge>, SaleCsvMapper>("sales");

// Add Scoped Services
builder.Services.AddScoped<IDeltaLakeManager, DeltaLakeManager>();
builder.Services.AddScoped<ChargeListReportGenerator>();
builder.Services.AddScoped<ChargesEventsReportGenerator>();
builder.Services.AddScoped<FinMovListReportGenerator>();
builder.Services.AddScoped<IReportTypeFactory, ReportTypeFactory>();
builder.Services.AddScoped<IEmailService, EmailService>();
builder.Services.AddScoped<ICetFeatureManager, CetFeatureManager>();
builder.Services.AddScoped<IHybridReportEnqueueService, HybridReportEnqueueService>();
builder.Services.AddScoped<IS3ReportEnqueueService, S3ReportEnqueueService>();
builder.Services.AddScoped<IReportConcatenationService, S3ReportConcatenationService>();
builder.Services.AddScoped<IS3CsvPartialReportRecordSource, S3CsvPartialReportRecordSource>();
builder.Services.AddScoped<IReportMergeEngine, KWayMergeEngine>();
builder.Services.AddScoped<IReportStreamWriterFactory, ReportStreamWriterFactory>();
builder.Services.AddKeyedScoped<IESReportEnqueueService, ESChargeReportEnqueueService>("charge");
builder.Services.AddKeyedScoped<IESReportEnqueueService, ESOrderReportEnqueueService>("order");

// Add Transient Services
builder.Services.AddTransient<IChargeListReportManager, ChargeListReportManager>();
builder.Services.AddTransient<ChargeEventsReportManager>();
builder.Services.AddTransient<IMultiPartFileUploader, S3FileUploader>();
builder.Services.AddTransient<IReportOutputSink, S3MultipartReportSink>();
builder.Services.AddKeyedTransient<IReportStreamWriter<string>, CsvReportStreamWriter>("csv");
builder.Services.AddKeyedTransient<IReportStreamWriter<string>, XlsxReportStreamWriter>("xlsx");
builder.Services.AddKeyedTransient<IReportStreamWriter<string[]>, XlsxReportStreamWriter>("xlsx");
builder.Services.AddTransient<IMerchantIdSummaryAggregator, MerchantIdAggregator>();

builder.Services.AddSingleton<IReportingTimeMetrics, ReportingTimeMetrics>();
//opentelemetry config
builder.ConfigureOpenTelemetry();

// Get Environment Variables Settings
builder.Services.Configure<DataLayerReportsSettings>(builder.Configuration.GetSection(DataLayerReportsSettings.DataLayerApiSection));
builder.Services.Configure<DataLayerApiSettings>(builder.Configuration.GetSection(DataLayerApiSettings.DataLayerApiSection));
builder.Services.Configure<DataLayerReportPreDeploySettings>(builder.Configuration.GetSection(DataLayerReportPreDeploySettings.DataLayerReportPreDeploySection));
builder.Services.Configure<LegacyIdSystemAPISettings>(builder.Configuration.GetSection(LegacyIdSystemAPISettings.LegacyIdSystemAPISection));
builder.Services.Configure<AwsSettings>(builder.Configuration.GetSection(AwsSettings.AwsSection));
builder.Services.Configure<RedisSettings>(builder.Configuration.GetSection(RedisSettings.RedisSettingsSection));
builder.Services.Configure<HangfireSettings>(builder.Configuration.GetSection(HangfireSettings.HangfireSection));
builder.Services.Configure<ElasticSearchSettings>(builder.Configuration.GetSection(ElasticSearchSettings.ElasticSearchSection));
builder.Services.Configure<AcquirerReportsApiSettings>(builder.Configuration.GetSection(AcquirerReportsApiSettings.AcquirerReportsApiSection));
builder.Services.Configure<ReportSettings>(builder.Configuration.GetSection(ReportSettings.ReportSection));

// Add HTTP Clients
builder.Services.AddHttpClient<IWebhookService, WebhookService>(client => { client.Timeout = TimeSpan.FromSeconds(10); });
builder.Services.AddHttpClient("dataLayerApiClientClient", client =>
{
    client.BaseAddress = new Uri(builder.Configuration.GetValue<string>($"{DataLayerApiSettings.DataLayerApiSection}:DataLayerApiUrl")!);
    client.DefaultRequestHeaders.Add("Referer", "PaymentsDataLayerReports");
    client.DefaultRequestHeaders.Add(
        "Authorization",
        $"Bearer {builder.Configuration.GetValue<string>($"{DataLayerApiSettings.DataLayerApiSection}:AuthToken")}"
    );
});

builder.Services.AddHttpClient("legacyIdSystemApiClient", client =>
{
    client.BaseAddress = new Uri(builder.Configuration.GetValue<string>($"{LegacyIdSystemAPISettings.LegacyIdSystemAPISection}:LegacyIdSystemApiUrl")!);
});

builder.Services.AddHttpClient("dataLayerReportPreDeployClient", client =>
{
    client.BaseAddress = new Uri(builder.Configuration.GetValue<string>($"{DataLayerReportPreDeploySettings.DataLayerReportPreDeploySection}:Url")!);
    client.DefaultRequestHeaders.Add("Referer", "PaymentsDataLayerReports");
});

// Add AWS S3 Client
builder.Services.AddSingleton<IAmazonS3>(sp =>
{
    var accessKey = builder.Configuration.GetValue<string>($"{AwsSettings.AwsSection}:AccessKey")!;
    var secretKey = builder.Configuration.GetValue<string>($"{AwsSettings.AwsSection}:SecretKey")!;
    var sessionToken = builder.Configuration.GetValue<string>($"{AwsSettings.AwsSection}:SessionToken");
    var region = builder.Configuration.GetValue<string>($"{AwsSettings.AwsSection}:Region")!;

    AWSCredentials credentials = string.IsNullOrEmpty(sessionToken)
        ? new BasicAWSCredentials(accessKey, secretKey)
        : new SessionAWSCredentials(accessKey, secretKey, sessionToken);

    return new AmazonS3Client(credentials, RegionEndpoint.GetBySystemName(region));
});

//Add elastic client
if (builder.Configuration.GetSection(ElasticSearchSettings.ElasticSearchSection).Get<ElasticSearchSettings>() is { CloudId: not null })
{
    builder.Services.AddSingleton(
            new ElasticsearchClient(
                new ElasticsearchClientSettings(
                    new CloudNodePool(builder.Configuration.GetValue<string>($"{ElasticSearchSettings.ElasticSearchSection}:CloudId"),
                        new BasicAuthentication(builder.Configuration.GetValue<string>($"{ElasticSearchSettings.ElasticSearchSection}:User"),
                                            builder.Configuration.GetValue<string>($"{ElasticSearchSettings.ElasticSearchSection}:Password")))
                , sourceSerializer: (defaultSerializer, settings) => new DefaultSourceSerializer(settings, t => t.PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower)
            )
        )
    );
}




// Add Hangfire
builder.Services.AddHangfireConfig(builder.Configuration);


// Add Modules
builder.Services.AddReportsModule();
builder.Services.AddManagementModule();


builder.Services.Configure<JsonOptions>(options =>
{
    options.SerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower;
});

builder.AddLogger();

ValidatorOptions.Global.PropertyNameResolver = (a, b, c) => b?.Name.ToSnakeCase();


var app = builder.Build();
app.UseMiddleware<LogMiddleware>();
app.UseHttpLogging();
app.UseProblemDetailsExceptionHandler();
app.UseStatusCodePages();
app.UseRouting();

// Serve diagrams as static files
var diagramsPath = Path.Combine(builder.Environment.ContentRootPath, "..", "..", "diagrams");
if (Directory.Exists(diagramsPath))
{
    app.UseStaticFiles(new StaticFileOptions
    {
        FileProvider = new PhysicalFileProvider(diagramsPath),
        RequestPath = "/diagrams"
    });
}

app.UseSwagger();
app.UseSwaggerUI();
app.UseHangfireDashboard("/hangfire", new DashboardOptions
{
    Authorization = [app.Services.GetRequiredService<HangfireAuthorizationFilter>()]
});

app.MapHealthChecks("/health", new HealthCheckOptions
{
    Predicate = _ => true,
    ResponseWriter = UIResponseWriter.WriteHealthCheckUIResponse
});

app.MapHealthChecks("/health/live", new HealthCheckOptions
{
    Predicate = _ => false,
    ResponseWriter = UIResponseWriter.WriteHealthCheckUIResponse
});

app.MapHealthChecks("/health/ready", new HealthCheckOptions
{
    Predicate = _ => false,
    ResponseWriter = UIResponseWriter.WriteHealthCheckUIResponse
});


#pragma warning disable ASP0014
app.UseEndpoints(endpoints =>
{
    endpoints
        .AddReportsEndpoints()
        .AddManagementEndpoints();
});
#pragma warning restore ASP0014


app.Services.GetRequiredService<HangfireMetrics>();

var hostApplicationLifetime = app.Services.GetRequiredService<IHostApplicationLifetime>();

Console.CancelKeyPress += (_, args) =>
{
    Log.Information("Application is stopping gracefully");
};

hostApplicationLifetime.ApplicationStopping.Register(() =>
{
    Log.Information("Application is stopping gracefully");
});

AppDomain.CurrentDomain.ProcessExit += (_, _)
    => Log.Information("Application has been forced to shut down");

AppDomain.CurrentDomain.UnhandledException += (_, args) =>
{
    if (args.ExceptionObject is not Exception ex) return;
    Log.ForContext("Exception", ex)
       .Error("An unhandled exception occurred, the application will now terminate");
};

app.Run();

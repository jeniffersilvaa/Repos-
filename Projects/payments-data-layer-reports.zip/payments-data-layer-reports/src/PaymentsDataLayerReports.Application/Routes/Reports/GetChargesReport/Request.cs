using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using PaymentsDataLayerReports.Application.Extensions;

namespace PaymentsDataLayerReports.Application.Routes.Reports.GetChargesReport;

public record GetChargesReportRequest
{
    public string? ReportId { get; set; }

    [FromQuery(Name = "document")]
    public string? Document { get; set; }

    [FromQuery(Name = "account_id")]
    public string? AccountId { get; set; }

    [FromQuery(Name = "merchant_id")]
    public string? MerchantId { get; set; }

    [FromQuery(Name = "is_sandbox")]
    public string? IsSandbox { get; set; }

    [FromQuery(Name = "affiliation_codes")]
    public string? AffiliationCodes { get; set; }

    [FromQuery(Name = "organizations")]
    public string? Organizations { get; set; }

    [FromHeader]
    public string? UserAgent { get; set; }

    [FromHeader]
    public string? Origin { get; set; }

    [FromHeader]
    public string? Referer { get; set; }

    public class Validator : AbstractValidator<GetChargesReportRequest>
    {
        public Validator()
        {
            RuleFor(q => q)
                .Must(q => !string.IsNullOrEmpty(q.Document) || !string.IsNullOrEmpty(q.AccountId) || !string.IsNullOrEmpty(q.MerchantId))
                .WithMessage("At least one of required fields 'document', 'account_id' or 'merchant_id' must be provided.");

            RuleFor(q => q.ReportId)
                .NotEmpty()
                .WithMessage("Required field");

            RuleFor(q => q.Organizations)
                .NotEmpty()
                .WithMessage("Required field");

            When(q => q.AccountId.HasValue(), () =>
            {
                RuleFor(q => q.MerchantId)
                    .NotEmpty()
                    .WithMessage("Required field");
            });

            When(q => q.AccountId!.HasValue() || q.MerchantId!.HasValue(), () =>
            {
                RuleFor(q => q.IsSandbox)
                    .NotEmpty()
                    .WithMessage("Required field");
            });
        }
    }
}



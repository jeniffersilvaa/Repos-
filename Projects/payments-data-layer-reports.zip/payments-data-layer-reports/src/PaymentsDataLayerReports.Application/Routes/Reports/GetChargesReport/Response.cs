namespace PaymentsDataLayerReports.Application.Routes.Reports.GetChargesReport;

public record GetChargesReportResponse
{
    public required string Status { get; set; }
    public required string? Url { get; set; }
}

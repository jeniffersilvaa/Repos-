using Hangfire;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Extensions;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Routes.Shared;
using PaymentsDataLayerReports.Application.Services.ReportFinder;
using PaymentsDataLayerReports.Application.Settings;
using Serilog;

namespace PaymentsDataLayerReports.Application.Routes.Reports.GetChargesReport;

internal static class GetChargesReportEndpoint
{
    internal static IEndpointRouteBuilder GetChargesReport(this IEndpointRouteBuilder endpoints)
    {
        endpoints.MapGet("/charges/report/{ReportId}", Handler)
            .WithTags("Charges")
            .Produces<GetChargesReportResponse>()
            .ProducesValidationProblem()
            .ProducesProblem(StatusCodes.Status500InternalServerError)
            .AddEndpointFilter<ValidationFilter<GetChargesReportRequest>>()
            .WithSummary("Busca status de um relatório por ReportId")
            .WithDescription("**[Fluxograma do endpoint](/diagrams/GetChargesReport.png)**");

        return endpoints;
    }

    private static async Task<IResult> Handler(
        [AsParameters] GetChargesReportRequest request,
        [FromServices] IReportFinderService reportService
    )
    {
        Log.ForContext("ReportId", request.ReportId)
            .ForContext("Document", request.Document)
            .ForContext("MerchantId", request.MerchantId)
            .ForContext("AccountId", request.AccountId)
            .ForContext("IsSandbox", request.IsSandbox)
            .ForContext("UserAgent", request.UserAgent)
            .ForContext("Origin", request.Origin)
            .ForContext("Referer", request.Referer)
            .Information("[GetChargesReportEndpoint.Handler] - Request received.");

        (string? status, string? url) = await reportService.FindReport(request.ReportId!);
        if (status == null) { return Results.NotFound(); }

        GetChargesReportResponse response = new() { Status = status, Url = url };
        return Results.Ok(response);
    }
}

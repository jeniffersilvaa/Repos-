namespace PaymentsDataLayerReports.Application.Routes.Reports.PostChargesReport;

public record PostChargesReportResponse
{
    public required string ReportId { get; set; }
}

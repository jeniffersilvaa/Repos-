using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Extensions;
using PaymentsDataLayerReports.Application.Infra.Shared;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker;
using PaymentsDataLayerReports.Application.Workers.ChargeReportWorker;

namespace PaymentsDataLayerReports.Application.Routes.Reports.PostChargesReport;

public record PostChargesReportRequest
{
    [FromQuery(Name = "start_date")]
    public DateTimeOffset? StartDate { get; set; }

    [FromQuery(Name = "end_date")]
    public DateTimeOffset? EndDate { get; set; }

    [FromQuery(Name = "document")]
    public string? Document { get; set; }

    [FromQuery(Name = "account_id")]
    public string? AccountId { get; set; }

    [FromQuery(Name = "merchant_id")]
    public string? MerchantId { get; set; }

    [FromQuery(Name = "is_sandbox")]
    public bool? IsSandbox { get; set; }

    [FromQuery(Name = "affiliation_codes")]
    public string? AffiliationCodes { get; set; }

    [FromQuery(Name = "payment_methods")]
    public string? PaymentMethods { get; set; }

    [FromQuery(Name = "organizations")]
    public string? Organizations { get; set; }

    [FromQuery(Name = "report_type")]
    public string? ReportType { get; set; }

    [FromQuery(Name = "s3_flag")]
    public string? S3Flag { get; set; }

    [FromQuery(Name = "all_ids")]
    public string? AllIds { get; set; }

    [FromQuery(Name = "customers")]
    public string? Customers { get; set; }

    [FromQuery(Name = "acquirers")]
    public string? Acquirers { get; set; }

    [FromQuery(Name = "bank_names")]
    public string? BankNames { get; set; }

    [FromQuery(Name = "card_brands")]
    public string? CardBrands { get; set; }

    [FromQuery(Name = "paid_at")]
    public DateTime? PaidAt { get; set; }

    [FromQuery(Name = "funding_sources")]
    public string? FundingSources { get; set; }

    [FromQuery(Name = "platform_name")]
    public string? PlatformName { get; set; }

    [FromQuery(Name = "status")]
    public string? Status { get; set; }

    [FromQuery(Name = "antifraud_status")]
    public string? AntifraudStatus { get; set; }

    [FromQuery(Name = "last_operation_status")]
    public string? LastOperationStatus { get; set; }

    [FromQuery(Name = "last_legacy_status")]
    public string? LastLegacyStatus { get; set; }

    [FromQuery(Name = "min_amount")]
    public long? MinAmount { get; set; }

    [FromQuery(Name = "max_amount")]
    public long? MaxAmount { get; set; }

    [FromQuery(Name = "with_failed")]
    public bool? WithFailed { get; set; }

    [FromHeader]
    public string? UserAgent { get; set; }

    [FromHeader]
    public string? Origin { get; set; }

    [FromHeader]
    public string? Referer { get; set; }

    public ChargeReportsWorkerParameters ToWorkerParameters()
    {
        return new ChargeReportsWorkerParameters
        {
            StartDate = StartDate!.Value.ToUniversalTime(),
            EndDate = EndDate!.Value.ToUniversalTime(),
            Document = Document,
            AccountId = AccountId,
            MerchantId = MerchantId,
            IsSandbox = IsSandbox,
            AffiliationCodes = AffiliationCodes,
            PaymentMethods = PaymentMethods,
            Organizations = Organizations!,
            ReportType = ReportType!,
            Acquirers = Acquirers,
            AllIds = AllIds,
            AntifraudStatus = AntifraudStatus,
            BankNames = BankNames,
            CardBrands = CardBrands,
            Customers = Customers,
            FundingSources = FundingSources,
            LastOperationStatus = LastOperationStatus,
            LastLegacyStatus = LastLegacyStatus,
            MaxAmount = MaxAmount,
            MinAmount = MinAmount,
            PaidAt = PaidAt != null ? PaidAt.Value.ToUniversalTime() : null,
            PlatformName = PlatformName,
            Status = Status,
            WithFailed = WithFailed

        };
    }

    public IQueryBuilder ToQueryParameters()
    {
        var queryBuilder = new QueryBuilder()
            .Add("document", Document)
            .AddDateTime("start_date", StartDate)
            .AddDateTime("end_date", EndDate)
            .Add("account_id", AccountId)
            .Add("merchant_id", MerchantId)
            .Add("is_sandbox", IsSandbox.ToString())
            .Add("affiliation_codes", AffiliationCodes)
            .Add("organizations", Organizations)
            .Add("status", Status)
            .Add("report_type", ReportType)
            .Add("s3_flag", S3Flag)
            .Add("user_agent", UserAgent)
            .Add("origin", Origin)
            .Add("referer", Referer)
            .Add("all_ids", AllIds)
            .Add("customers", Customers)
            .Add("acquirers", Acquirers)
            .Add("bank_names", BankNames)
            .Add("card_brands", CardBrands)
            .AddDateTime("paid_at", PaidAt)
            .Add("funding_sources", FundingSources)
            .Add("platform_name", PlatformName)
            .Add("antifraud_status", AntifraudStatus)
            .Add("last_operation_status", LastOperationStatus)
            .Add("last_legacy_status", LastLegacyStatus)
            .Add("min_amount", MinAmount)
            .Add("max_amount", MaxAmount)
            .Add("with_failed", WithFailed);

        return queryBuilder;
    }

    public class Validator : AbstractValidator<PostChargesReportRequest>
    {
        public Validator()
        {
            RuleFor(q => q)
                .Must(q => !string.IsNullOrEmpty(q.Document) || !string.IsNullOrEmpty(q.MerchantId))
                .WithMessage("At least one of required fields 'document' or 'merchant_id' must be provided.");

            RuleFor(q => q.StartDate)
                .Cascade(CascadeMode.Stop)
                .NotEmpty()
                .WithMessage("Required field");

            RuleFor(q => q.EndDate)
                .Cascade(CascadeMode.Stop)
                .NotEmpty()
                .WithMessage("Required field")
                .GreaterThanOrEqualTo(q => q.StartDate)
                .WithMessage("End date must be greater than or equal to start date");

            RuleFor(q => q.ReportType)
                .Cascade(CascadeMode.Stop)
                .NotEmpty()
                .WithMessage("Required field")
                .Must((t) => new[] { ReportTypeEnum.ChargesList.Name, ReportTypeEnum.ChargesEvents.Name }.Contains(t))
                .WithMessage($"The report type must be one of the following: {ReportTypeEnum.ChargesList.Name}, {ReportTypeEnum.ChargesEvents.Name}");

            RuleFor(q => q.Organizations)
                .Cascade(CascadeMode.Stop)
                .NotEmpty()
                .WithMessage("Required field");

            When(q => !string.IsNullOrWhiteSpace(q.LastLegacyStatus), () =>
            {
                RuleFor(q => q.LastLegacyStatus!)
                    .Must(value =>
                    {
                        var allowed = LegacyStatusEnum.GetAll<LegacyStatusEnum>().Select(x => x.Name).ToList();
                        var parts = value!.Split(',').Select(v => v.Trim()).Where(v => !string.IsNullOrEmpty(v));
                        return parts.All(p => allowed.Any(a => string.Equals(a, p, StringComparison.OrdinalIgnoreCase)));
                    })
                    .WithMessage($"legacy_status must contain only the following values (comma-separated allowed): {string.Join(", ", LegacyStatusEnum.GetAll<LegacyStatusEnum>().Select(x => x.Name))}");
            });

            When(q => q.MerchantId!.HasValue(), () =>
            {
                RuleFor(q => q.IsSandbox)
                    .NotEmpty()
                    .WithMessage("Required field");
            });
        }
    }
}

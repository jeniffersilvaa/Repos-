using Hangfire;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Infra.DataLayerReport;
using PaymentsDataLayerReports.Application.Routes.Shared;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Versioning;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;
using PaymentsDataLayerReports.Application.Workers.ChargeReportWorker;
using Serilog;

namespace PaymentsDataLayerReports.Application.Routes.Reports.PostChargesReport;

internal static class PostChargesReportEndpoint
{
    private const string _dispatchIdToS3ReportIdFormat = $"{{0}}-s3";
    private const string _dispatchIdToPredeployReportIdFormat = $"{{0}}-s3-preDeploy";

    internal static IEndpointRouteBuilder PostChargesReport(this IEndpointRouteBuilder endpoints)
    {
        endpoints.MapPost("/charges/report", PostHandler)
            .WithTags("Charges")
            .Produces<PostChargesReportResponse>()
            .ProducesValidationProblem()
            .ProducesProblem(StatusCodes.Status500InternalServerError)
            .AddEndpointFilter<ValidationFilter<PostChargesReportRequest>>()
            .WithSummary("Solicita relatório de charges");

        return endpoints;
    }

    private static IResult PostHandler(
        [AsParameters] PostChargesReportRequest request,
        [FromServices] IDataLayerReportPreDeployClient preDeployClient,
        [FromServices] IOptions<DataLayerReportPreDeploySettings> preDeploySettings,
        [FromServices] IBackgroundJobClient backgroundJobClient,
        HttpContext httpContext
    )
    {
        var correlationId = httpContext.Request.Headers["X-Report-Correlation-Id"].FirstOrDefault();

        Log.ForContext("ReportCorrelationId", correlationId)
            .ForContext("UserAgent", request.UserAgent)
            .ForContext("Origin", request.Origin)
            .ForContext("Referer", request.Referer)
            .ForContext("Document", request.Document)
            .ForContext("MerchantId", request.MerchantId)
            .ForContext("AccountId", request.AccountId)
            .ForContext("IsSandbox", request.IsSandbox)
            .ForContext("AffiliationCodes", request.AffiliationCodes)
            .ForContext("StartCreationDate", request.StartDate)
            .ForContext("EndCreationDate", request.EndDate)
            .ForContext("Organizations", request.Organizations)
            .ForContext("PaymentMethods", request.PaymentMethods)
            .ForContext("ReportType", request.ReportType)
            .ForContext("AllIds", request.AllIds)
            .ForContext("Customers", request.Customers)
            .ForContext("Acquirers", request.Acquirers)
            .ForContext("BankNames", request.BankNames)
            .ForContext("CardBrands", request.CardBrands)
            .ForContext("PaidAt", request.PaidAt)
            .ForContext("FundingSources", request.FundingSources)
            .ForContext("PlatformName", request.PlatformName)
            .ForContext("Status", request.Status)
            .ForContext("AntifraudStatus", request.AntifraudStatus)
            .ForContext("LastOperationStatus", request.LastOperationStatus)
            .ForContext("LastLegacyStatus", request.LastLegacyStatus)
            .ForContext("MinAmount", request.MinAmount)
            .ForContext("MaxAmount", request.MaxAmount)
            .ForContext("WithFailed", request.WithFailed)
            .Information("[PostChargesReportEndpoint.Handler] - Request received.");

        DateTime startedAt = DateTime.Now;

        string reportId;
        if (request.S3Flag is null)
        {
            reportId = ProcessReportWithElasticSearch(request, backgroundJobClient);
            return Results.Ok(new PostChargesReportResponse { ReportId = reportId });
        }

        reportId = ProcessReportWithS3(correlationId, startedAt, request, backgroundJobClient, preDeployClient, preDeploySettings.Value);
        return Results.Ok(new PostChargesReportResponse { ReportId = reportId });
    }

    private static string ProcessReportWithElasticSearch(PostChargesReportRequest request, IBackgroundJobClient backgroundJobClient)
    {
        var reportId = backgroundJobClient.Enqueue<ChargeReportWorker>(
            queue: QueuesEnum.ESReports.Name,
            methodCall: job => job.ProcessReport(request.ToWorkerParameters(), null, false, null!, CancellationToken.None)
        );

        return reportId;
    }

    private static string ProcessReportWithS3(
        string? correlationId,
        DateTime startedAt,
        PostChargesReportRequest request,
        IBackgroundJobClient backgroundJobClient,
        IDataLayerReportPreDeployClient preDeployClient,
        DataLayerReportPreDeploySettings preDeploySettings
    )
    {
        var parameters = request.ToWorkerParameters();
        var dispatchId = backgroundJobClient.Enqueue<ChargeReportS3DispatchWorker>(
            queue: QueuesEnum.S3ReportsDispatch.Name,
            methodCall: job => job.DispatchReport(
                string.IsNullOrWhiteSpace(correlationId) ? null : correlationId,
                QueuesEnum.S3Reports.Name,
                parameters,
                null,
                startedAt,
                null!,
                CancellationToken.None,
                new AppVersion1320()
            )
        );

        if (preDeploySettings.IsPreDeployWorker != true && preDeploySettings.EnabledReports?.Contains(request.ReportType!) == true)
        {
            _ = preDeployClient.PostChargesReport(request, string.Format(_dispatchIdToPredeployReportIdFormat, dispatchId))
                .ContinueWith(t => { var ignored = t.Exception; }, TaskContinuationOptions.OnlyOnFaulted);
        }

        return string.Format(_dispatchIdToS3ReportIdFormat, dispatchId);
    }
}

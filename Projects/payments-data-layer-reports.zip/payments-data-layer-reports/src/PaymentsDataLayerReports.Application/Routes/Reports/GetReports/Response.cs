namespace PaymentsDataLayerReports.Application.Routes.Reports.GetReports;

public record GetReportsResponse
{
    public required string Status { get; set; }
    public required string? Url { get; set; }
}

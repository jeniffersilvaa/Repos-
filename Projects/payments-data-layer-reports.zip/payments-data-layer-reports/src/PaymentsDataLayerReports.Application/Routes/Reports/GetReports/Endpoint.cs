using Microsoft.AspNetCore.Mvc;
using PaymentsDataLayerReports.Application.Routes.Shared;
using PaymentsDataLayerReports.Application.Services.ReportFinder;
using Serilog;

namespace PaymentsDataLayerReports.Application.Routes.Reports.GetReports;

internal static class GetReportsEndpoint
{
    internal static IEndpointRouteBuilder GetReports(this IEndpointRouteBuilder endpoints)
    {
        endpoints.MapGet("/v1/reports/{ReportId}", Execute)
            .WithTags("Reports")
            .Produces<GetReportsResponse>()
            .ProducesValidationProblem()
            .ProducesProblem(StatusCodes.Status500InternalServerError)
            .AddEndpointFilter<ValidationFilter<GetReportsRequest>>()
            .WithSummary("Busca status de um relatório por ReportId")
            .WithDescription("**[Fluxograma do endpoint](/diagrams/GetChargesReport.png)**");

        return endpoints;
    }

    private static async Task<IResult> Execute(
        [AsParameters] GetReportsRequest request,
        [FromServices] IReportFinderService reportService
    )
    {
        Log.ForContext("ReportId", request.ReportId)
            .ForContext("Document", request.Document)
            .ForContext("MerchantId", request.MerchantId)
            .ForContext("AccountId", request.AccountId)
            .ForContext("IsSandbox", request.IsSandbox)
            .ForContext("UserAgent", request.UserAgent)
            .ForContext("Origin", request.Origin)
            .ForContext("Referer", request.Referer)
            .Information("[GetReportsEndpoint.Execute] - Request received.");

        (string? status, string? url) = await reportService.FindReport(request.ReportId!);
        if (status == null) { return Results.NotFound(); }

        GetReportsResponse response = new() { Status = status, Url = url };
        return Results.Ok(response);
    }
}

using FluentValidation;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Services.ReportTypeConfiguration;

namespace PaymentsDataLayerReports.Application.Routes.Reports.PostReports.Models;

public class IdentifiersValidator : AbstractValidator<Identifiers>
{
    private const int MaxDocumentsCount = 50;

    public IdentifiersValidator()
    {
        RuleFor(x => x.Documents)
            .Must(documents => documents is null || documents.Count() <= MaxDocumentsCount)
            .WithMessage($"'documents' must not exceed {MaxDocumentsCount} items.");

        RuleFor(x => x.Documents)
            .Empty()
            .When(x => x.MerchantIds is not null && x.MerchantIds.Any())
            .WithMessage("'documents' and 'merchant_ids' cannot be provided at the same time.");

        RuleFor(x => x.MerchantIds)
            .Empty()
            .When(x => x.Documents is not null && x.Documents.Any())
            .WithMessage("'documents' and 'merchant_ids' cannot be provided at the same time.");

        RuleFor(x => x.StoneAccounts)
            .Empty()
            .When(x => x.Documents is null || !x.Documents.Any())
            .WithMessage("'documents' and 'stone_accounts' must be provided at the same time.");

        RuleFor(x => x)
            .Must(x => (x.Documents is not null && x.Documents.Any()) || (x.MerchantIds is not null && x.MerchantIds.Any()) || (x.StoneAccounts is not null && x.StoneAccounts.Any()))
            .WithName("Identifiers")
            .WithMessage("Either 'documents' or 'merchant_ids' or 'stone_accounts' must be provided.");
    }
}

public class EmailNotificationValidator : AbstractValidator<EmailNotification>
{
    public EmailNotificationValidator()
    {
        RuleFor(e => e.Address)
            .NotEmpty()
            .WithMessage("'email.address' is required.")
            .EmailAddress()
            .WithMessage("'email.address' must be a valid email address.");
    }
}

public class WebhookNotificationValidator : AbstractValidator<WebhookNotification>
{
    public WebhookNotificationValidator()
    {
        RuleFor(w => w.Url)
            .NotEmpty()
            .WithMessage("'webhook.url' is required.")
            .Must(uri => Uri.TryCreate(uri, UriKind.Absolute, out _))
            .WithMessage("'webhook.url' must be a valid URL.");

        RuleFor(w => w.Headers)
            .NotEmpty()
            .WithMessage("'webhook.headers' is required when webhook is configured.")
            .When(w => w.Url is not null);
    }
}

public class NotificationValidator : AbstractValidator<Notification>
{
    public NotificationValidator()
    {
        RuleFor(n => n.Type)
            .NotEmpty()
            .Must(type => type is "email" or "webhook")
            .WithMessage("'type' must be either 'email' or 'webhook'.");

        RuleFor(n => n.Email)
            .NotNull()
            .WithMessage("'email' configuration is required when type is 'email'.")
            .SetValidator(new EmailNotificationValidator()!)
            .When(n => n.Type == "email");

        RuleFor(n => n.Webhook)
            .NotNull()
            .WithMessage("'webhook' configuration is required when type is 'webhook'.")
            .SetValidator(new WebhookNotificationValidator()!)
            .When(n => n.Type == "webhook");

        RuleFor(n => n.Email)
            .Null()
            .WithMessage("'email' should not be provided when type is 'webhook'.")
            .When(n => n.Type == "webhook");

        RuleFor(n => n.Webhook)
            .Null()
            .WithMessage("'webhook' should not be provided when type is 'email'.")
            .When(n => n.Type == "email");
    }
}

public class ReportFiltersValidator : AbstractValidator<ReportFilters>
{
    public ReportFiltersValidator()
    {
        RuleFor(f => f.StartDate).NotEmpty();

        RuleFor(f => f.FinalDate)
            .NotEmpty()
            .GreaterThanOrEqualTo(f => f.StartDate)
            .WithMessage("'finalDate' must be equal to or after 'startDate'.");

        RuleFor(f => f.Organizations)
            .NotEmpty()
            .WithMessage("Organizations list cannot be empty.")
            .When(f => f.Identifiers?.StoneAccounts is null)
            .Must(orgs => orgs.All(org => org is "stone" or "ton" or "pagarme"))
            .WithMessage("All organizations must be 'stone', 'ton', or 'pagarme'.");

        RuleFor(f => f.Identifiers).NotEmpty().SetValidator(new IdentifiersValidator());
    }
}

public class ReportExtraValidator : AbstractValidator<ReportExtra?>
{
    public ReportExtraValidator(string reportType)
    {
        switch (reportType)
        {
            case "receivables":
                {
                    RuleFor(x => x)
                        .Must(extra => extra == null || !extra.ContainsKey("is_sandbox") || extra["is_sandbox"].ValueKind == System.Text.Json.JsonValueKind.True || extra["is_sandbox"].ValueKind == System.Text.Json.JsonValueKind.False)
                        .WithMessage("'extra.is_sandbox' must be a boolean value.");

                    RuleFor(x => x)
                        .Must(extra => extra == null || !extra.ContainsKey("with_payments") || extra["with_payments"].ValueKind == System.Text.Json.JsonValueKind.True || extra["with_payments"].ValueKind == System.Text.Json.JsonValueKind.False)
                        .WithMessage("'extra.with_payments' must be a boolean value.");

                    RuleFor(x => x)
                        .Must(extra => extra == null || !extra.ContainsKey("card_brands") || extra["card_brands"].ValueKind == System.Text.Json.JsonValueKind.Array)
                        .WithMessage("'extra.card_brands' must be an array.");

                    RuleFor(x => x)
                        .Must(extra =>
                        {
                            if (extra == null || !extra.TryGetValue("card_brands", out System.Text.Json.JsonElement value) || value.ValueKind != System.Text.Json.JsonValueKind.Array)
                                return true;

                            return value.EnumerateArray().All(item => item.ValueKind == System.Text.Json.JsonValueKind.String);
                        })
                        .WithMessage("'extra.card_brands' must be an array of strings.");

                    break;
                }
            default: break;
        }
    }
}

public class PostReportsRequestValidator : AbstractValidator<PostReportsRequest>
{
    private static readonly string[] AllowedReportTypes =
    [
        ReportTypeEnum.ChargesList.Name,
        ReportTypeEnum.Orders.Name,
        ReportTypeEnum.Receivables.Name,
        ReportTypeEnum.SalesStone.Name,
        ReportTypeEnum.SalesTon.Name,
        ReportTypeEnum.Sales.Name,
        ReportTypeEnum.ReceivablesLegacy.Name
    ];
    private static readonly string[] AllowedFileFormats = [FileFormatEnum.Csv.Name, FileFormatEnum.Xlsx.Name];
    private static readonly string[] AllowedReportTypesForXlsx =
    [
        ReportTypeEnum.Orders.Name,
        ReportTypeEnum.Receivables.Name,
        ReportTypeEnum.SalesStone.Name,
        ReportTypeEnum.SalesTon.Name,
        ReportTypeEnum.Sales.Name,
        ReportTypeEnum.ReceivablesLegacy.Name
    ];

    public PostReportsRequestValidator()
    {
        RuleFor(r => r.Type)
            .NotEmpty()
            .Must((t) => AllowedReportTypes.Contains(t))
            .WithMessage($"Report type must be: {string.Join(" or ", AllowedReportTypes)}");

        RuleFor(r => r.FileFormat)
            .NotEmpty()
            .Must((f) => AllowedFileFormats.Contains(f))
            .WithMessage($"File format must be: {string.Join(" or ", AllowedFileFormats)}")
            .DependentRules(() =>
            {
                RuleFor(r => r.FileFormat)
                    .Must((r, f) => ReportTypeConfigurationProvider.IsFileFormatSupported(r.Type, f))
                    .WithMessage($"xlsx is only supported for: {string.Join(" or ", AllowedReportTypesForXlsx)}.");
            });

        RuleFor(r => r.Filters)
            .NotEmpty()
            .SetValidator(r => new ReportFiltersValidator());

        RuleFor(r => r.Notification)
            .SetValidator(new NotificationValidator()!)
            .When(r => r.Notification is not null);

        RuleFor(r => r.Extra)
            .SetValidator(r => new ReportExtraValidator(r.Type))
            .When(r => r.Extra is not null);
    }
}


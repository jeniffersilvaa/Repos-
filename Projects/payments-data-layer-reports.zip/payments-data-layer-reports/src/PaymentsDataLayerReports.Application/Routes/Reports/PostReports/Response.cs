namespace PaymentsDataLayerReports.Application.Routes.Reports.PostReports;

public record PostReportsResponse
{
    public required string ReportId { get; set; }
}

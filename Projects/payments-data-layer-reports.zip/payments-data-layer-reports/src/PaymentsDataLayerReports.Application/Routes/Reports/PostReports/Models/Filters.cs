namespace PaymentsDataLayerReports.Application.Routes.Reports.PostReports.Models;

public class ReportFilters
{
    public DateOnly StartDate { get; set; }
    public DateOnly FinalDate { get; set; }
    public IEnumerable<string> Organizations { get; set; } = []; // Possivelmente não deve existir no onestone
    public Identifiers Identifiers { get; set; } = new();
}
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using PaymentsDataLayerReports.Application.Extensions;
using PaymentsDataLayerReports.Application.Infra.DataLayerReport;
using PaymentsDataLayerReports.Application.Routes.Shared;
using PaymentsDataLayerReports.Application.Services.IdMapper;
using PaymentsDataLayerReports.Application.Services.ReportEnqueue.Interfaces;
using PaymentsDataLayerReports.Application.Settings;
using Serilog;

namespace PaymentsDataLayerReports.Application.Routes.Reports.PostReports;

internal static class PostReportsEndpoint
{
    private const string _reportIdToPredeployReportIdFormat = "{0}-preDeploy";

    internal static IEndpointRouteBuilder PostReports(this IEndpointRouteBuilder endpoints)
    {
        endpoints.MapPost("/v1/reports", PostHandler)
            .WithTags("Reports")
            .Produces<PostReportsResponse>()
            .ProducesValidationProblem()
            .ProducesProblem(StatusCodes.Status500InternalServerError)
            .AddEndpointFilter<ValidationFilter<PostReportsRequest>>()
            .WithSummary("Solicitação de relatórios");

        return endpoints;
    }

    private static async Task<IResult> PostHandler(
        [FromBody] PostReportsRequest request,
        [FromServices] IHybridReportEnqueueService hybridService,
        [FromKeyedServices("receivable")] IESReportEnqueueService esReceivableReportService,
        [FromKeyedServices("charge")] IESReportEnqueueService esChargeService,
        [FromKeyedServices("order")] IESReportEnqueueService esOrderService,
        [FromServices] IS3ReportEnqueueService s3Service,
        [FromServices] IIdMapperService idMapperService,
        [FromServices] IDataLayerReportPreDeployClient preDeployClient,
        [FromServices] IOptions<DataLayerReportPreDeploySettings> preDeploySettings,
        HttpContext httpContext
    )
    {
        var correlationId = httpContext.Request.Headers["X-Report-Correlation-Id"].FirstOrDefault()
            ?.Replace("\r", "").Replace("\n", "");

        var normalizedCorrelationId = string.IsNullOrWhiteSpace(correlationId) ? null : correlationId.Trim();

        Log.ForContext("ReportCorrelationId", normalizedCorrelationId)
          .ForContext("UserAgent", request.UserAgent)
          .ForContext("TraceKey", request.TraceKey)
          .ForContext("Origin", request.Origin)
          .ForContext("Referer", request.Referer)
          .ForContext("Type", request.Type)
          .ForContext("Filters", request.Filters, true)
          .ForContext("Notification", request.Notification, true)
          .ForContext("Extra", request.Extra, true)
          .Information("[PostReportsEndpoint.PostHandler] - Request received.");

        var merchantIdSummary = await idMapperService.Map(
            request.Filters.Identifiers?.StoneAccounts.ToCommaSeparatedString(),
            request.Filters.Identifiers?.Documents.ToCommaSeparatedString(),
            request.Filters.Organizations.ToCommaSeparatedString(),
            request.Filters.Identifiers?.AffiliationCodes.ToCommaSeparatedString(),
            null,
            request.Filters.Identifiers?.MerchantIds.ToCommaSeparatedString(),
            request.Filters.Identifiers?.PaymentProfiles.ToCommaSeparatedString(),
            request.Filters.Identifiers?.PoiTypes.ToCommaSeparatedString(),
            CancellationToken.None
        );

        var reportId = request.Type switch
        {
            "sales_stone" or "sales_ton" or "sales" => hybridService.EnqueueReport(request, esChargeService, s3Service, merchantIdSummary, normalizedCorrelationId),
            "receivables" or "receivables_legacy" => hybridService.EnqueueReport(request, esReceivableReportService, s3Service, merchantIdSummary, normalizedCorrelationId),
            "orders" => esOrderService.EnqueueReport(request, merchantIdSummary, normalizedCorrelationId),
            _ => throw new ArgumentException($"Invalid report type: {request.Type}")
        };

        var settings = preDeploySettings.Value;
        if (settings.IsPreDeployWorker != true && settings.IsReportEnabled(request.Type))
        {
            _ = preDeployClient.PostReports(request, string.Format(_reportIdToPredeployReportIdFormat, normalizedCorrelationId ?? reportId))
                .ContinueWith(t => { var _ = t.Exception; }, TaskContinuationOptions.OnlyOnFaulted);
        }

        return Results.Ok(new PostReportsResponse { ReportId = reportId });
    }
}
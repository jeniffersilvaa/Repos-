using System.Text.Json;

namespace PaymentsDataLayerReports.Application.Routes.Reports.PostReports.Models;

public class ReportExtra : Dictionary<string, JsonElement> { }
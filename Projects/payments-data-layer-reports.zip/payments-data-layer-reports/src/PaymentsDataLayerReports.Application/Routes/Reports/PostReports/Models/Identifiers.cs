namespace PaymentsDataLayerReports.Application.Routes.Reports.PostReports.Models;

public record Identifiers
{
    public IEnumerable<string>? Documents { get; set; }
    public IEnumerable<string>? MerchantIds { get; set; }
    public IEnumerable<string>? StoneAccounts { get; set; }
    public IEnumerable<string>? PaymentProfiles { get; set; }
    public IEnumerable<string>? AffiliationCodes { get; set; }
    public IEnumerable<string>? PoiTypes { get; set; }
}
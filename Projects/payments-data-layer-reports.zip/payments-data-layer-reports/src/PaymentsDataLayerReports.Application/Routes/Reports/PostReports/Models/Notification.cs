namespace PaymentsDataLayerReports.Application.Routes.Reports.PostReports.Models;

public record Notification
{
    public string Type { get; set; } = string.Empty;
    public EmailNotification? Email { get; set; } = null;
    public WebhookNotification? Webhook { get; set; } = null;
}

public record EmailNotification
{
    public string Address { get; set; } = string.Empty;
}

public record WebhookNotification
{
    public string Url { get; set; } = string.Empty;
    public IDictionary<string, string>? Headers { get; set; }
}
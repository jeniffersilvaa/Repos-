using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using PaymentsDataLayerReports.Application.Routes.Reports.PostReports.Models;

namespace PaymentsDataLayerReports.Application.Routes.Reports.PostReports;

public record PostReportsRequest
{

    [FromHeader]
    public string? UserAgent { get; set; }

    [FromHeader]
    public string? Origin { get; set; }

    [FromHeader]
    public string? Referer { get; set; }

    [FromHeader]
    public string? TraceKey { get; set; }

    public string Type { get; set; } = string.Empty;
    public string FileFormat { get; set; } = string.Empty;
    public ReportFilters Filters { get; set; } = new();
    public Notification? Notification { get; set; } = null;
    public ReportExtra? Extra { get; set; }
}

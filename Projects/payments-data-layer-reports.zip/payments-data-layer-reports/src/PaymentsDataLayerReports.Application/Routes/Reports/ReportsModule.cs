using FluentValidation;
using PaymentsDataLayerReports.Application.Infra.Hangfire;
using PaymentsDataLayerReports.Application.Routes.Reports.GetChargesReport;
using PaymentsDataLayerReports.Application.Routes.Reports.GetReports;
using PaymentsDataLayerReports.Application.Routes.Reports.PostChargesReport;
using PaymentsDataLayerReports.Application.Routes.Reports.PostReports;
using PaymentsDataLayerReports.Application.Routes.Reports.PostReports.Models;
using PaymentsDataLayerReports.Application.Services.ReportFinder;

namespace PaymentsDataLayerReports.Application.Routes.Reports;

public static class ReportsModule
{
    public static IServiceCollection AddReportsModule(this IServiceCollection services)
    {
        // Validators
        services.AddScoped<IValidator<PostChargesReportRequest>, PostChargesReportRequest.Validator>();
        services.AddScoped<IValidator<GetChargesReportRequest>, GetChargesReportRequest.Validator>();
        services.AddScoped<IValidator<GetReportsRequest>, GetReportsRequest.Validator>();
        services.AddScoped<IValidator<PostReportsRequest>, PostReportsRequestValidator>();

        // Services
        services.AddScoped<IJobStorageProvider, HangfireJobStorageProvider>();
        services.AddScoped<IReportFinderService, ReportFinderService>();

        return services;
    }

    internal static IEndpointRouteBuilder AddReportsEndpoints(this IEndpointRouteBuilder endpoints)
    {
        endpoints
            .GetChargesReport()
            .PostChargesReport()
            .GetReports()
            .PostReports();

        return endpoints;
    }
}
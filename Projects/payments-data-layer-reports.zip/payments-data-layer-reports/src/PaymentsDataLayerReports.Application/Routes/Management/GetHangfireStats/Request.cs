using FluentValidation;
using Microsoft.AspNetCore.Mvc;

using PaymentsDataLayerReports.Application.Extensions;
using PaymentsDataLayerReports.Application.Types;

namespace PaymentsDataLayerReports.Application.Routes.Management.GetHangfireStats;

public record GetHangfireStatsRequest
{
    [FromQuery(Name = "stats")]
    public string? Stats { get; set; }

    [FromQuery(Name = "job_id")]
    public string? JobId { get; set; }

    [FromQuery(Name = "queue_name")]
    public string? QueueName { get; set; }

    [FromQuery(Name = "skip")]
    public int? Skip { get; set; }

    [FromQuery(Name = "limit")]
    public int? Limit { get; set; }

    public class Validator : AbstractValidator<GetHangfireStatsRequest>
    {
        public Validator()
        {
            RuleFor(q => q.Stats!)
                .NotEmpty()
                .WithMessage("Required field")
                .Must((t) => !t!.SplitToList().Except(Enumeration.GetAll<StatsEnum>().Select(e => e.Name)).Any())
                .WithMessage($"Must be one or more stats separated by comma: {string.Join(", ", Enumeration.GetAll<StatsEnum>().Select(e => e.Name))}");


            When(q => q.Stats!.SplitToList().Contains(StatsEnum.JobDetails.Name), () =>
            {
                RuleFor(q => q.JobId)
                    .NotEmpty()
                    .WithMessage("Required field");
            });

            When(q => q.Stats!.SplitToList().Contains(StatsEnum.EnqueuedByQueueList.Name), () =>
            {
                RuleFor(q => q.QueueName)
                    .NotEmpty()
                    .WithMessage("Required field");
            });

            When(q => q.Stats!.SplitToList().Any(s => StatsEnum.StatsWithPagination().Contains(s)), () =>
            {
                RuleFor(q => q.Skip)
                    .NotEmpty()
                    .WithMessage("Required field");

                RuleFor(q => q.Limit)
                    .NotEmpty()
                    .WithMessage("Required field");

            });
        }
    }
}



using PaymentsDataLayerReports.Application.Types;

namespace PaymentsDataLayerReports.Application.Routes.Management.GetHangfireStats;

public class StatsEnum : Enumeration
{
    public static readonly StatsEnum Resume = new(0, "Resume");
    public static readonly StatsEnum QueueList = new(1, "QueueList");
    public static readonly StatsEnum EnqueuedByQueueList = new(2, "EnqueuedByQueueList");
    public static readonly StatsEnum ScheduledList = new(3, "ScheduledList");
    public static readonly StatsEnum ProcessingList = new(4, "ProcessingList");
    public static readonly StatsEnum SucceededList = new(5, "SucceededList");
    public static readonly StatsEnum FailedList = new(6, "FailedList");
    public static readonly StatsEnum DeletedList = new(7, "DeletedList");
    public static readonly StatsEnum ServersList = new(8, "ServersList");
    public static readonly StatsEnum JobDetails = new(9, "JobDetails");

    public StatsEnum(int id, string name) : base(id, name)
    { }

    public static string[] StatsWithPagination() => [
        EnqueuedByQueueList.Name,
        ScheduledList.Name,
        ProcessingList.Name,
        SucceededList.Name,
        FailedList.Name,
        DeletedList.Name
    ];
}
using Hangfire;
using Hangfire.Storage;
using PaymentsDataLayerReports.Application.Extensions;
using PaymentsDataLayerReports.Application.Routes.Shared;
using Serilog;

namespace PaymentsDataLayerReports.Application.Routes.Management.GetHangfireStats;


internal static class GetHangfireStatsEndpoint
{
    internal static IEndpointRouteBuilder GetHangfireStats(this IEndpointRouteBuilder endpoints)
    {
        endpoints.MapGet("/management/hangfire/stats", Handler)
            .WithTags("Hangfire")
            .Produces<GetHangfireStatsResponse>()
            .ProducesValidationProblem()
            .ProducesProblem(StatusCodes.Status500InternalServerError)
            .AddEndpointFilter<ValidationFilter<GetHangfireStatsRequest>>();

        return endpoints;
    }

    private static IResult Handler(
        [AsParameters] GetHangfireStatsRequest request
    )
    {
        Log.ForContext("Stats", request.Stats)
            .Information("[GetHangfireStatsEndpoint.Handler] - Request received.");

        var monitor = JobStorage.Current.GetMonitoringApi();

        var splitStats = request.Stats!.SplitToList();
        var result = new
        {
            Resume = splitStats.Contains(StatsEnum.Resume.Name) ? monitor.GetStatistics() : null,
            QueueList = splitStats.Contains(StatsEnum.QueueList.Name) ? BuildQueueList(monitor) : null,
            EnqueuedByQueueList = splitStats.Contains(StatsEnum.EnqueuedByQueueList.Name) ? BuildEnqueuedByQueueList(monitor, request) : null,
            ScheduledList = splitStats.Contains(StatsEnum.ScheduledList.Name) ? BuildScheduledList(monitor, request) : null,
            ProcessingList = splitStats.Contains(StatsEnum.ProcessingList.Name) ? BuildProcessingList(monitor, request) : null,
            SucceededList = splitStats.Contains(StatsEnum.SucceededList.Name) ? BuildSucceededList(monitor, request) : null,
            FailedList = splitStats.Contains(StatsEnum.FailedList.Name) ? BuildFailedList(monitor, request) : null,
            DeletedList = splitStats.Contains(StatsEnum.DeletedList.Name) ? BuildDeletedList(monitor, request) : null,
            ServersList = splitStats.Contains(StatsEnum.ServersList.Name) ? BuildServersList(monitor) : null,
            JobDetails = splitStats.Contains(StatsEnum.JobDetails.Name) ? BuildJobDetails(monitor, request.JobId) : null
        };

        return Results.Ok(result);
    }


    private static List<object> BuildQueueList(IMonitoringApi monitor)
    {
        var queues = monitor.Queues();

        var result = new List<object>();
        foreach (var queue in queues)
        {
            var firstJobs = new List<object>();
            foreach (var (jobId, job) in queue.FirstJobs)
            {
                firstJobs.Add(new
                {
                    Id = jobId,
                    Job = job.Job.ToString(),
                    Queue = job.Job.Queue,
                    State = job.State,
                    EnqueueAt = job.EnqueuedAt,
                    InEnqueuedState = job.InEnqueuedState,
                    StateData = job.StateData
                });
            }

            result.Add(new
            {
                Name = queue.Name,
                Length = queue.Length,
                Fetched = queue.Fetched,
                FirstJobs = firstJobs

            });
        }

        return result;
    }

    private static List<object> BuildEnqueuedByQueueList(IMonitoringApi monitor, GetHangfireStatsRequest request)
    {
        var enqueuedJobs = monitor.EnqueuedJobs(request.QueueName, request.Skip!.Value, request.Limit!.Value);

        var result = new List<object>();
        foreach (var (jobId, job) in enqueuedJobs)
        {
            result.Add(new
            {
                Id = jobId,
                Job = job.Job.ToString(),
                Queue = job.Job.Queue,
                EnqueueAt = job.EnqueuedAt,
                InEnqueuedState = job.InEnqueuedState,
                StateData = job.StateData
            });
        }

        return result;
    }

    private static List<object> BuildScheduledList(IMonitoringApi monitor, GetHangfireStatsRequest request)
    {
        var scheduledJobs = monitor.ScheduledJobs(request.Skip!.Value, request.Limit!.Value);

        var result = new List<object>();
        foreach (var (jobId, job) in scheduledJobs)
        {
            result.Add(new
            {
                Id = jobId,
                Job = job.Job.ToString(),
                Queue = job.Job.Queue,
                EnqueueAt = job.EnqueueAt,
                ScheduledAt = job.ScheduledAt,
                InScheduledState = job.InScheduledState,
                StateData = job.StateData
            });
        }

        return result;
    }

    private static List<object> BuildProcessingList(IMonitoringApi monitor, GetHangfireStatsRequest request)
    {
        var processingJobs = monitor.ProcessingJobs(request.Skip!.Value, request.Limit!.Value);

        var result = new List<object>();
        foreach (var (jobId, job) in processingJobs)
        {
            result.Add(new
            {
                Id = jobId,
                Job = job.Job.ToString(),
                Queue = job.Job.Queue,
                InProcessingState = job.InProcessingState,
                ServerId = job.ServerId,
                StartedAt = job.StartedAt,
                StateData = job.StateData
            });
        }

        return result;
    }

    private static List<object> BuildSucceededList(IMonitoringApi monitor, GetHangfireStatsRequest request)
    {
        var succeededList = monitor.SucceededJobs(request.Skip!.Value, request.Limit!.Value);

        var result = new List<object>();
        foreach (var (jobId, job) in succeededList)
        {
            result.Add(new
            {
                Id = jobId,
                Job = job.Job.ToString(),
                Queue = job.Job.Queue,
                Result = job.Result,
                TotalDuration = job.TotalDuration,
                SucceededAt = job.SucceededAt,
                InSucceededState = job.InSucceededState,
                StateData = job.StateData
            });
        }

        return result;
    }

    private static List<object> BuildFailedList(IMonitoringApi monitor, GetHangfireStatsRequest request)
    {
        var failedList = monitor.FailedJobs(request.Skip!.Value, request.Limit!.Value);

        var result = new List<object>();
        foreach (var (jobId, job) in failedList)
        {
            result.Add(new
            {
                Id = jobId,
                Job = job.Job.ToString(),
                Queue = job.Job.Queue,
                Reason = job.Reason,
                FailedAt = job.FailedAt,
                ExceptionType = job.ExceptionType,
                ExceptionMessage = job.ExceptionMessage,
                ExceptionDetails = job.ExceptionDetails,
                InFailedState = job.InFailedState,
                StateData = job.StateData
            });
        }

        return result;
    }

    private static List<object> BuildDeletedList(IMonitoringApi monitor, GetHangfireStatsRequest request)
    {
        var deletedList = monitor.DeletedJobs(request.Skip!.Value, request.Limit!.Value);

        var result = new List<object>();
        foreach (var (jobId, job) in deletedList)
        {
            result.Add(new
            {
                Id = jobId,
                Job = job.Job.ToString(),
                Queue = job.Job.Queue,
                DeletedAt = job.DeletedAt,
                InDeletedState = job.InDeletedState,
                StateData = job.StateData
            });
        }

        return result;
    }

    private static List<object> BuildServersList(IMonitoringApi monitor)
    {
        var serversList = monitor.Servers();

        var result = new List<object>();
        foreach (var server in serversList)
        {
            result.Add(new
            {
                Name = server.Name,
                WorkersCount = server.WorkersCount,
                StartedAt = server.StartedAt,
                Queues = server.Queues,
                Heartbeat = server.Heartbeat
            });
        }

        return result;
    }

    private static object BuildJobDetails(IMonitoringApi monitor, string jobId)
    {
        var jobDetails = monitor.JobDetails(jobId);

        return new
        {
            Id = jobId,
            Job = jobDetails.Job.ToString(),
            Queue = jobDetails.Job.Queue,
            CreatedAt = jobDetails.CreatedAt,
            Properties = jobDetails.Properties,
            History = jobDetails.History,
            ExpireAt = jobDetails.ExpireAt
        };
    }
}
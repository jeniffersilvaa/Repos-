namespace PaymentsDataLayerReports.Application.Routes.Management.GetHangfireStats;

public record GetHangfireStatsResponse
{
    public required object? Resume { get; set; }
    public required object? QueueList { get; set; }
    public required object? EnqueuedByQueueList { get; set; }
    public required object? ScheduledList { get; set; }
    public required object? ProcessingList { get; set; }
    public required object? SucceededList { get; set; }
    public required object? FailedList { get; set; }
    public required object? DeletedList { get; set; }
    public required object? ServersList { get; set; }
    public required object? JobDetails { get; set; }
}

using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using PaymentsDataLayerReports.Application.Constants;
using Serilog;

namespace PaymentsDataLayerReports.Application.Routes.Management.GetResourceUsage;


internal static class GetResourceUsageEndpoint
{
    internal static IEndpointRouteBuilder GetResourceUsage(this IEndpointRouteBuilder endpoints)
    {
        endpoints.MapGet("/management/hangfire/resource/usage", Handler)
            .WithTags("Hangfire")
            .Produces<IResult>()
            .ProducesValidationProblem()
            .ProducesProblem(StatusCodes.Status500InternalServerError);

        return endpoints;
    }

    private static IResult Handler(
        [FromQuery] int count = 10
    )
    {
        Log.Information("[GetResourceUsageEndpoint.Handler] - Request received.");

        try
        {
            var topProcesses = GetTopMemoryProcesses(count);
            return Results.Ok(topProcesses);
        }
        catch (Exception ex)
        {
            Log.Error(ex, "[GetResourceUsageEndpoint.Handler] - Error getting resource usage.");
            return Results.Problem(
                title: "Error getting resource usage",
                detail: ex.Message,
                statusCode: StatusCodes.Status500InternalServerError);
        }
    }

    public static List<ProcessResourceInfo> GetTopMemoryProcesses(int count)
    {
        var processes = Process.GetProcesses();
        var currentProcess = Process.GetCurrentProcess();

        // Get total memory usage for all processes
        double totalMemoryUsageMB = processes.Sum(p => p.WorkingSet64) / ByteSizeConstants.MB;

        // Create a list to hold all process information
        var result = new List<ProcessResourceInfo>();

        // Process each individual process
        foreach (var p in processes)
        {
            try
            {
                result.Add(new ProcessResourceInfo
                {
                    process_id = p.Id,
                    process_name = p.ProcessName,
                    memory_usage_mb = Math.Round(p.WorkingSet64 / (double)ByteSizeConstants.MB, 2),
                    private_memory_mb = Math.Round(p.PrivateMemorySize64 / (double)ByteSizeConstants.MB, 2),
                    virtual_memory_mb = Math.Round(p.VirtualMemorySize64 / (double)ByteSizeConstants.MB, 2),
                    paged_memory_mb = Math.Round(p.PagedMemorySize64 / (double)ByteSizeConstants.MB, 2),
                    is_current_process = p.Id == currentProcess.Id
                });
            }
            catch
            {
                // Some processes may throw access denied exceptions
                result.Add(new ProcessResourceInfo
                {
                    process_id = p.Id,
                    process_name = p.ProcessName,
                    memory_usage_mb = 0,
                    private_memory_mb = 0,
                    virtual_memory_mb = 0,
                    paged_memory_mb = 0,
                    is_current_process = p.Id == currentProcess.Id
                });
            }
        }

        // Order by memory usage and take the top N
        result = result
            .OrderByDescending(p => p.memory_usage_mb)
            .Take(count)
            .ToList();

        // Add total memory information to the current process info
        var currentProcessInfo = result.FirstOrDefault(p => p.is_current_process);
        if (currentProcessInfo != null)
        {
            currentProcessInfo.total_system_memory_mb = Math.Round(totalMemoryUsageMB, 2);
            currentProcessInfo.gc_total_memory_mb = Math.Round(GC.GetTotalMemory(false) / (double)ByteSizeConstants.MB, 2);
        }

        return result;
    }
}

public class ProcessResourceInfo
{
    public int process_id { get; set; }
    public string process_name { get; set; } = string.Empty;
    public double memory_usage_mb { get; set; }
    public double private_memory_mb { get; set; }
    public double virtual_memory_mb { get; set; }
    public double paged_memory_mb { get; set; }
    public double? total_system_memory_mb { get; set; }
    public double? gc_total_memory_mb { get; set; }
    public bool is_current_process { get; set; }

    public override string ToString()
    {
        return $"Process: {process_name} (ID: {process_id}) - Memory Usage: {memory_usage_mb}MB, Private Memory: {private_memory_mb}MB, Virtual Memory: {virtual_memory_mb}MB, Paged Memory: {paged_memory_mb}MB, Total System Memory: {total_system_memory_mb}MB, GC Total Memory: {gc_total_memory_mb}MB, Is Current Process: {is_current_process}";
    }
}
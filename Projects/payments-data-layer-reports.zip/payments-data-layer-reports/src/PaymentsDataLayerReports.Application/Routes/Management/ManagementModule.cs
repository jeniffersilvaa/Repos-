using FluentValidation;
using PaymentsDataLayerReports.Application.Routes.Management.DeletePreDeployJobs;
using PaymentsDataLayerReports.Application.Routes.Management.GetHangfireStats;
using PaymentsDataLayerReports.Application.Routes.Management.GetResourceUsage;
using PaymentsDataLayerReports.Application.Routes.Management.PostDeleteHangfireJob;

namespace PaymentsDataLayerReports.Application.Routes.Management;

public static class ManagementModule
{
    public static IServiceCollection AddManagementModule(this IServiceCollection services)
    {
        // Validators
        services.AddScoped<IValidator<GetHangfireStatsRequest>, GetHangfireStatsRequest.Validator>();

        return services;
    }

    internal static IEndpointRouteBuilder AddManagementEndpoints(this IEndpointRouteBuilder endpoints)
    {
        endpoints
            .GetHangfireStats()
            .GetResourceUsage()
            .PostDeleteHangfireJob()
            .PostDeletePreDeployJobs();

        return endpoints;
    }
}
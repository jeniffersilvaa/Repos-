using Hangfire;
using Microsoft.AspNetCore.Mvc;
using Serilog;

namespace PaymentsDataLayerReports.Application.Routes.Management.PostDeleteHangfireJob;


internal static class PostDeleteHangfireJobEndpoint
{
    internal static IEndpointRouteBuilder PostDeleteHangfireJob(this IEndpointRouteBuilder endpoints)
    {
        endpoints.MapPost("/management/hangfire/jobs/{JobId}/delete", Handler)
            .WithTags("Hangfire")
            .Produces<IResult>()
            .ProducesValidationProblem()
            .ProducesProblem(StatusCodes.Status500InternalServerError);

        endpoints.MapPost("/management/hangfire/jobs/delete-multiple", HandlerMultiple)
           .WithTags("Hangfire")
           .Produces<IResult>()
           .ProducesValidationProblem()
           .ProducesProblem(StatusCodes.Status500InternalServerError);

        return endpoints;
    }

    private static IResult Handler(
        [FromRoute] string jobId
    )
    {
        Log.ForContext("JobId", jobId)
            .Information("[PostDeleteHangfireJobEndpoint.Handler] - Request received.");

        try
        {
            BackgroundJob.Delete(jobId);
        }
        catch (Exception ex)
        {
            Log.Error(ex, "[PostDeleteHangfireJobEndpoint.Handler] - Error deleting job");
            throw;
        }

        return Results.Ok();
    }


    private static IResult HandlerMultiple(
        [FromBody] List<string> jobIds)
    {
        Log.ForContext("JobIds", jobIds)
          .Information("[PostDeleteHangfireJobEndpoint.HandlerMultiple] - Request received.");

        var failedDeletes = new List<string>();
        foreach (var id in jobIds)
        {
            try
            {
                BackgroundJob.Delete(id);
            }
            catch (Exception ex)
            {
                Log.Error(ex, "[PostDeleteHangfireJobEndpoint.HandlerMultiple] - Failed to delete job {JobId}", id);
                failedDeletes.Add(id);
            }
        }

        if (failedDeletes.Any())
        {
            return Results.Problem($"Failed to delete the following job IDs: {string.Join(", ", failedDeletes)}");
        }

        return Results.Ok();
    }
}
using Hangfire;
using StackExchange.Redis;

namespace PaymentsDataLayerReports.Application.Routes.Management.DeletePreDeployJobs;

internal static class DeletePreDeployJobsEndpoint
{
    internal static IEndpointRouteBuilder PostDeletePreDeployJobs(this IEndpointRouteBuilder endpoints)
    {
        endpoints.MapPost("/management/hangfire/jobs/pre-deploy/delete", Handler)
            .WithTags("Hangfire")
            .ProducesValidationProblem()
            .ProducesProblem(StatusCodes.Status500InternalServerError)
            .WithSummary("Deleta jobs de pre-deploy do Hangfire")
            .WithDescription("Remove jobs das filas de 'pre_deploy'.");

        return endpoints;
    }

    private static async Task<IResult> Handler(IConnectionMultiplexer redis)
    {
        const int hangfireDbIndex = 1;
        const string searchTerm = "pre_deploy";
        const string queuesSetKey = "hangfire:DataLayerReports:queues";
        const string queuePrefix = "hangfire:DataLayerReports:queue:";

        var db = redis.GetDatabase(hangfireDbIndex);

        // List all queues and filter by searchTerm
        var allQueues = await db.SetMembersAsync(queuesSetKey);
        var preDeployQueues = allQueues
            .Where(q => q.ToString().Contains(searchTerm, StringComparison.OrdinalIgnoreCase))
            .Select(q => new { QueueName = q, QueueKey = (RedisKey)$"{queuePrefix}{q}" })
            .ToList();

        if (preDeployQueues.Count == 0)
            return Results.NoContent();

        var batch = db.CreateBatch();
        var keysToDelete = new List<RedisKey>();

        // List all jobs from the filtered queues
        var listTasks = preDeployQueues.Select(q => db.ListRangeAsync(q.QueueKey)).ToList();
        var allJobIds = await Task.WhenAll(listTasks);

        // Delete each job
        foreach (var jobIds in allJobIds)
        {
            foreach (var jobId in jobIds)
            {
                BackgroundJob.Delete(jobId);
            }
        }

        return Results.Ok();
    }
};
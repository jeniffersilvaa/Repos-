using System.Diagnostics.Metrics;
using Hangfire.Storage;

namespace PaymentsDataLayerReports.Application.Metrics;

public class HangfireMetrics
{
    public const string MeterName = "Hangfire.Metrics";

    public HangfireMetrics(IMonitoringApi monitoringApi, IMeterFactory meterFactory)
    {
        var meter = meterFactory.Create(MeterName);

        meter.CreateObservableGauge("payments_data_layer_reports.hangfire.queue.length", () =>
        {
            var result = monitoringApi.Queues()
                .Select(q => new Measurement<long>(
                    q.Length,
                    new KeyValuePair<string, object?>("queue", q.Name)))
                .ToList();
            return result;
        }, "{job}", "The number of jobs in a specific Hangfire queue.");
    }
}
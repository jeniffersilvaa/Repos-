using System.Diagnostics.Metrics;
using PaymentsDataLayerReports.Application.Enums;

namespace PaymentsDataLayerReports.Application.Metrics;

public interface IReportingTimeMetrics
{
    void SendMetric(SendMetricInput input);
}

public class SendMetricInput()
{
    public DateTime StartedAt { get; init; }
    public DateTime EndedAt { get; init; }
    public TimeSpan TimeSpent => EndedAt - StartedAt;
    public required ReportTypeEnum ReportType { get; init; }
    public required string? Status { get; set; }
}

public class ReportingTimeMetrics : IReportingTimeMetrics
{
    public const string MeterName = "ReportingTime.Metrics";
    private readonly Histogram<double> _reportTimeHistogram;

    public ReportingTimeMetrics(IMeterFactory meterFactory)
    {
        var meter = meterFactory.Create(MeterName);

        _reportTimeHistogram = meter.CreateHistogram<double>(
            name: "payments_data_layer_reports.reporting.time",
            unit: "s",
            description: "Time spent when generating reports"
        );
    }

    public void SendMetric(SendMetricInput input)
    {
        var labels = new KeyValuePair<string, object?>[]
        {
            new("report_type", input.ReportType.Name),
            new("report_status", input.Status)
        };

        _reportTimeHistogram.Record(input.TimeSpent.TotalSeconds, labels);
    }
}

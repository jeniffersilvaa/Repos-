using PaymentsDataLayerReports.Application.Types;

namespace PaymentsDataLayerReports.Application.Enums;

public class OrganizationEnum(int id, string name) : Enumeration(id, name)
{
    public static readonly OrganizationEnum Stone = new(1, "stone");
    public static readonly OrganizationEnum Ton = new(2, "ton");
    public static readonly OrganizationEnum Pagarme = new(3, "pagarme");
}

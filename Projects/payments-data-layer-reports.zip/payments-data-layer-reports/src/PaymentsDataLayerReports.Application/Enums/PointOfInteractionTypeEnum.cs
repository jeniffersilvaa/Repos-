using System.Reflection;
using PaymentsDataLayerReports.Application.Types;

namespace PaymentsDataLayerReports.Application.Enums;

public class PointOfInteractionTypeEnum(int id, string name) : Enumeration(id, name)
{
    public static readonly PointOfInteractionTypeEnum POS = new(1, "pos");
    public static readonly PointOfInteractionTypeEnum TEF = new(2, "tef");
    public static readonly PointOfInteractionTypeEnum Link = new(3, "link");
    public static readonly PointOfInteractionTypeEnum TapOnPhone = new(4, "tap_on_phone");
    public static readonly PointOfInteractionTypeEnum WhatsAppPay = new(5, "whatsapp_pay");
    public static readonly PointOfInteractionTypeEnum Ecommerce = new(6, "ecommerce");
    public static readonly PointOfInteractionTypeEnum MicroPOS = new(7, "micro_pos");
    public static readonly PointOfInteractionTypeEnum ManualEntry = new(8, "manual_entry");

    private static readonly Dictionary<string, string> _nameAndFieldMapping =
        typeof(PointOfInteractionTypeEnum)
        .GetFields(BindingFlags.Public | BindingFlags.Static)
        .Where(f => f.GetValue(null) is PointOfInteractionTypeEnum)
        .ToDictionary(
            f => ((PointOfInteractionTypeEnum)f.GetValue(null)!).Name,
            f => f.Name,
            StringComparer.OrdinalIgnoreCase
        );

    public static string? GetFieldByName(string? name)
    {
        if (!string.IsNullOrWhiteSpace(name) && _nameAndFieldMapping.TryGetValue(name, out var variable))
        {
            return variable;
        }

        return name;
    }

    public static string? GetNameByField(string? field)
    {
        if (string.IsNullOrWhiteSpace(field)) return null;

        var poiType = typeof(PointOfInteractionTypeEnum).GetField(field, BindingFlags.Public | BindingFlags.Static | BindingFlags.IgnoreCase);

        if (poiType?.GetValue(null) is PointOfInteractionTypeEnum pointOfInteractionType)
        {
            return pointOfInteractionType.Name;
        }

        return field;
    }
}


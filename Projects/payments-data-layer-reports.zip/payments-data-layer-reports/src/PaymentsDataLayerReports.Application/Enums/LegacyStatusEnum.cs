using PaymentsDataLayerReports.Application.Types;

namespace PaymentsDataLayerReports.Application.Enums;

public class LegacyStatusEnum(int id, string name) : Enumeration(id, name)
{
    public static readonly LegacyStatusEnum Pending = new(1, "pending");
    public static readonly LegacyStatusEnum Paid = new(2, "paid");
    public static readonly LegacyStatusEnum Canceled = new(3, "canceled");
    public static readonly LegacyStatusEnum Processing = new(4, "processing");
    public static readonly LegacyStatusEnum Failed = new(5, "failed");
    public static readonly LegacyStatusEnum Overpaid = new(6, "overpaid");
    public static readonly LegacyStatusEnum Underpaid = new(7, "underpaid");
    public static readonly LegacyStatusEnum PendingRefund = new(8, "pending_refund");
    public static readonly LegacyStatusEnum Expired = new(9, "expired");
    public static readonly LegacyStatusEnum ChargedBack = new(10, "chargedback");
}

using PaymentsDataLayerReports.Application.Types;

namespace PaymentsDataLayerReports.Application.Enums;

public class FileFormatEnum(int id, string name) : Enumeration(id, name)
{
    public static readonly FileFormatEnum Csv = new(1, "csv");
    public static readonly FileFormatEnum Xlsx = new(2, "xlsx");
}

namespace PaymentsDataLayerReports.Application.Enums;

public enum CsvSeparatorEnum
{
    Comma,
    Semicolon
}
namespace PaymentsDataLayerReports.Application.Enums;

public enum WorkerStatesEnum
{
    Awaiting,
    Enqueued,
    Scheduled,
    Processing,
    Succeeded,
    Failed,
    Deleted
}
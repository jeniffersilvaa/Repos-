using PaymentsDataLayerReports.Application.Types;

namespace PaymentsDataLayerReports.Application.Enums;

public class ReportTypeEnum(int id, string name) : Enumeration(id, name)
{
    public static readonly ReportTypeEnum ChargesEvents = new(1, "charges_events");
    public static readonly ReportTypeEnum PixChargesEvents = new(2, "pix_charges_events");
    public static readonly ReportTypeEnum ChargesResume = new(3, "charges_resume");
    public static readonly ReportTypeEnum ChargesList = new(4, "charges_list");
    public static readonly ReportTypeEnum ReceivablesLegacy = new(5, "receivables_legacy");
    public static readonly ReportTypeEnum Orders = new(6, "orders");
    public static readonly ReportTypeEnum SalesStone = new(7, "sales_stone");
    public static readonly ReportTypeEnum SalesTon = new(8, "sales_ton");
    public static readonly ReportTypeEnum Sales = new(9, "sales");
    public static readonly ReportTypeEnum Receivables = new(10, "receivables");

    public static bool IsFinMovReport(string? reportType) =>
        string.Equals(reportType, Receivables.Name, StringComparison.OrdinalIgnoreCase)
        || string.Equals(reportType, ReceivablesLegacy.Name, StringComparison.OrdinalIgnoreCase);
}

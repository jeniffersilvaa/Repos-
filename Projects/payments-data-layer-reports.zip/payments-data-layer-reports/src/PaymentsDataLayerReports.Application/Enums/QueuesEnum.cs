using PaymentsDataLayerReports.Application.Types;

namespace PaymentsDataLayerReports.Application.Enums;

public class QueuesEnum(int id, string name) : Enumeration(id, name)
{
    public static readonly QueuesEnum ESReports = new(0, "reports");
    public static readonly QueuesEnum S3Reports = new(1, "s3_reports");
    public static readonly QueuesEnum S3ReportsDispatch = new(2, "s3_reports_dispatch");
    public static readonly QueuesEnum Notifications = new(6, "notifications");
}

public class PreDeployQueuesEnum(int id, string name) : Enumeration(id, name)
{
    public static readonly PreDeployQueuesEnum S3Reports = new(0, "s3_reports_pre_deploy");
    public static readonly PreDeployQueuesEnum ESReports = new(1, "reports_pre_deploy");
    public static readonly PreDeployQueuesEnum S3ReportsDispatch = new(2, "s3_reports_dispatch_pre_deploy");
}

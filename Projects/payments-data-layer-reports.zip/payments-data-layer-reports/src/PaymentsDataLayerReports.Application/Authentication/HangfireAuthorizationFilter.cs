using Hangfire.Dashboard;
using Microsoft.Extensions.Options;
using PaymentsDataLayerReports.Application.Settings;

namespace PaymentsDataLayerReports.Application.Authentication;

public class HangfireAuthorizationFilter(
    IOptions<HangfireSettings> settings
) : IDashboardAuthorizationFilter
{
    private readonly HangfireSettings _settings = settings.Value;

    public bool Authorize(DashboardContext context)
    {
        ValidateCredentials();

        var httpContext = context.GetHttpContext();
        var header = httpContext.Request.Headers.Authorization.ToString();

        bool isValidHeader = ValidateHeader(httpContext, header);
        if (!isValidHeader) return false;

        bool isValidAuthorization = ValidateAuthorization(httpContext, header);
        if (isValidAuthorization) return true;

        return false;
    }

    private void ValidateCredentials()
    {
        if (string.IsNullOrEmpty(_settings.DashUsername) || string.IsNullOrEmpty(_settings.DashPassword))
        {
            throw new InvalidOperationException("Hangfire authentication credentials are not configured");
        }
    }

    private static bool ValidateHeader(HttpContext httpContext, string header)
    {
        if (string.IsNullOrWhiteSpace(header) || !header.StartsWith("Basic "))
        {
            httpContext.Response.Headers.Append("WWW-Authenticate", "Basic realm=\"Hangfire Dashboard\"");
            return false;
        }
        return true;
    }

    private bool ValidateAuthorization(HttpContext httpContext, string header)
    {
        byte[] credentialBytes = Convert.FromBase64String(header.Replace("Basic ", ""));
        string[] credentials = System.Text.Encoding.UTF8.GetString(credentialBytes).Split(':', 2);

        if (!(credentials.Length == 2 && credentials[0] == _settings.DashUsername && credentials[1] == _settings.DashPassword))
        {
            httpContext.Response.Headers.Append("WWW-Authenticate", "Basic realm=\"Hangfire Dashboard\"");
            return false;
        }
        return true;
    }
}

using Hangfire;
using PaymentsDataLayerReports.Application.Extensions;

namespace PaymentsDataLayerReports.Application.Infra.Hangfire;

public interface IJobStorageProvider
{
    string? GetStateById(string jobId);
}

public class HangfireJobStorageProvider : IJobStorageProvider
{
    public string? GetStateById(string jobId)
    {
        return JobStorage.Current.GetStateById(jobId);
    }
}

namespace PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;

public static class S3ReportsConstants
{
    private const string _reportPath = "reports";
    private const string _reportPartialPath = "reports/partial";
    public const int UrlDefaultExpirationHours = 24;
    public const string ReportBasePath = $"{_reportPath}/{{0}}.{{1}}";
    public const string PartialESReportPath = $"{_reportPartialPath}/{{0}}.csv";
    public const string PartialReportDatePath = $"{_reportPartialPath}/{{0}}/{{1:yyyy-MM-dd}}/";
    public const string PartialReportFilePath = $"{_reportPartialPath}/{{0}}/{{1:yyyy-MM-dd}}/{{2}}.csv";
    public const string PartialReportHeaderPath = $"{_reportPartialPath}/{{0}}/header.csv";
    public const string PartialReportMetadataPath = $"{_reportPartialPath}/{{0}}/metadata.json";
}
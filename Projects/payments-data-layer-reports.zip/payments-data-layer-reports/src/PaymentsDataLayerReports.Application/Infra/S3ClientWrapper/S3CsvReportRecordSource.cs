using System.Runtime.CompilerServices;
using System.Text;
using Amazon.S3;
using Amazon.S3.Model;
using Microsoft.Extensions.Options;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Models;
using PaymentsDataLayerReports.Application.Services.ReportTypeConfiguration;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;
using Serilog;

namespace PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;

public interface IS3CsvPartialReportRecordSource
{
    IAsyncEnumerable<IAsyncEnumerable<ReportRecord>> GetPartitionStreamsForDateAsync(
        ReportMetadata metadata,
        DateTime date,
        CancellationToken cancellationToken
    );
}

public class S3CsvPartialReportRecordSource(
    IAmazonS3 s3Client,
    IOptions<AwsSettings> awsSettings
) : IS3CsvPartialReportRecordSource
{
    private readonly IAmazonS3 _s3Client = s3Client;
    private readonly AwsSettings _awsSettings = awsSettings.Value;

    public async IAsyncEnumerable<IAsyncEnumerable<ReportRecord>> GetPartitionStreamsForDateAsync(
        ReportMetadata metadata,
        DateTime date,
        [EnumeratorCancellation] CancellationToken cancellationToken)
    {
        var bucketName = _awsSettings.WorkgroupBucket!;

        var prefix = string.Format(S3ReportsConstants.PartialReportDatePath, metadata.ReportId, date);

        var listRequest = new ListObjectsV2Request
        {
            BucketName = bucketName,
            Prefix = prefix
        };

        ListObjectsV2Response listResponse;
        do
        {
            listResponse = await _s3Client.ListObjectsV2Async(listRequest, cancellationToken);

            foreach (var s3Object in listResponse.S3Objects.Where(o => o.Size > 0))
            {
                var key = s3Object.Key;
                cancellationToken.ThrowIfCancellationRequested();
                yield return ReadPartitionAsync(bucketName, key, metadata, cancellationToken);
            }

            listRequest.ContinuationToken = listResponse.NextContinuationToken;
        } while (listResponse.IsTruncated);
    }

    private async IAsyncEnumerable<ReportRecord> ReadPartitionAsync(
        string bucketName,
        string key,
        ReportMetadata metadata,
        [EnumeratorCancellation] CancellationToken cancellationToken)
    {
        Amazon.S3.Model.GetObjectResponse? response = null;
        Stream? responseStream = null;
        StreamReader? reader = null;
        long bytesRead = 0;

        async Task OpenReaderAsync(long startOffset, CancellationToken ct)
        {
            reader?.Dispose();
            responseStream?.Dispose();
            response?.Dispose();

            if (startOffset > 0)
            {
                var rangeRequest = new GetObjectRequest
                {
                    BucketName = bucketName,
                    Key = key,
                    ByteRange = new ByteRange($"bytes={startOffset}-")
                };

                response = await _s3Client.GetObjectAsync(rangeRequest, ct);
            }
            else
            {
                response = await _s3Client.GetObjectAsync(bucketName, key, ct);
            }

            responseStream = response.ResponseStream;
            reader = new StreamReader(responseStream, Encoding.UTF8);
        }

        try
        {
            await OpenReaderAsync(0, cancellationToken);

            var reportType = metadata.ChargeReportParameters?.ReportType
                             ?? metadata.FinMovReportParameters?.ReportType
                             ?? throw new InvalidOperationException("Report type not found in metadata");

            var separator = ReportTypeConfigurationProvider.GetSeparatorChar(reportType);

            while (true)
            {
                string? line;

                try
                {
                    line = await reader!.ReadLineAsync(cancellationToken);
                }
                catch (IOException ex) when (ex.Message.Contains("unexpected EOF"))
                {
                    Log.ForContext("S3Key", key)
                        .ForContext("BytesRead", bytesRead)
                        .Warning(
                            "[S3CsvPartialReportRecordSource.ReadPartitionAsync] Caught unexpected EOF. Reopening stream with range request.");

                    await OpenReaderAsync(bytesRead, cancellationToken);
                    continue;
                }

                if (line == null) break;

                var columns = line.Split(separator);
                if (columns.Length <= metadata.ReportSortColumnIndex)
                {
                    Log.ForContext("Line", line)
                        .ForContext("DateSortColumnIndex", metadata.ReportSortColumnIndex)
                        .Warning(
                            "[S3CsvPartialReportRecordSource.ReadPartitionAsync] Failed to parse line or create ReportRecord");
                    continue;
                }

                var textWithNewLine = line + "\n";
                bytesRead += Encoding.UTF8.GetByteCount(textWithNewLine);

                var sortKey = columns[metadata.ReportSortColumnIndex];
                cancellationToken.ThrowIfCancellationRequested();
                yield return new ReportRecord(line, sortKey);
            }
        }
        finally
        {
            reader?.Dispose();
            responseStream?.Dispose();
            response?.Dispose();
        }
    }
}
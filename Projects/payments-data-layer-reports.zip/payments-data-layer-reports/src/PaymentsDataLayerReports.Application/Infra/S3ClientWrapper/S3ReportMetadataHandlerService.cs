using System.Text.Json;
using Amazon.S3;
using Microsoft.Extensions.Options;
using PaymentsDataLayerReports.Application.Extensions;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;
using Serilog;

namespace PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;

public interface IS3ReportMetadataHandlerService
{
    Task<ReportMetadata?> GetReportMetadataAsync(string reportId);
    Task UploadReportMetadataAsync(ReportMetadata reportMetadata);
}

public class S3ReportMetadataHandlerService(
    IAmazonS3 s3Client,
    IOptions<AwsSettings> awsSettings
) : IS3ReportMetadataHandlerService
{
    private readonly IAmazonS3 _s3Client = s3Client;
    private readonly AwsSettings _awsSettings = awsSettings.Value;

    public async Task<ReportMetadata?> GetReportMetadataAsync(string reportId)
    {
        Log.Debug("[S3ReportMetadataHandlerService.GetReportMetadataAsync] Starting");

        var metadataPath = string.Format(S3ReportsConstants.PartialReportMetadataPath, reportId);
        var content = await _s3Client.ReadStringAsync(_awsSettings.WorkgroupBucket!, metadataPath);

        if (string.IsNullOrEmpty(content))
        {
            Log.ForContext("Bucket", _awsSettings.WorkgroupBucket)
                .ForContext("Path", metadataPath)
                .Warning("[S3ReportMetadataHandlerService.GetReportMetadataAsync] File was empty or not found");
            return null;
        }

        var metadata = JsonSerializer.Deserialize<ReportMetadata>(content);
        Log.ForContext("Bucket", _awsSettings.WorkgroupBucket)
            .ForContext("Path", metadataPath)
            .Debug("[S3ReportMetadataHandlerService.GetReportMetadataAsync] Successfully read metadata");
        return metadata;
    }

    public async Task UploadReportMetadataAsync(ReportMetadata reportMetadata)
    {
        Log.Debug("[S3ReportMetadataHandlerService.UploadReportMetadataAsync] Starting");

        try
        {
            var metadataPath = string.Format(S3ReportsConstants.PartialReportMetadataPath, reportMetadata.ReportId);
            await _s3Client.WriteStringAsync(
                _awsSettings.WorkgroupBucket!,
                metadataPath,
                JsonSerializer.Serialize(reportMetadata),
                "application/json"
            );

            Log.ForContext("Path", metadataPath)
                .ForContext("Bucket", _awsSettings.WorkgroupBucket)
                .Debug("[S3ReportMetadataHandlerService.UploadReportMetadataAsync] Successfully uploaded file");
        }
        catch (Exception ex)
        {
            Log.Error(ex, "[S3ReportMetadataHandlerService.UploadReportMetadataAsync] Error uploading file");
            throw;
        }
    }
}
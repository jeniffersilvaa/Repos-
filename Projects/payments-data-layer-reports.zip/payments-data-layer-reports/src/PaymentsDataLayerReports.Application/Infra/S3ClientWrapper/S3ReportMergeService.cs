using System.Text;
using Amazon.S3;
using Amazon.S3.Model;
using Datadog.Trace;
using Microsoft.Extensions.Options;
using PaymentsDataLayerReports.Application.Constants;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;
using Serilog;

namespace PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;

public interface IS3ReportMergeService
{
    Task MergeReportFilesAsync(string concatId, ReportMetadata reportMetadata, CancellationToken cancellationToken);
}

public class S3MergeContext(string uploadId, string destinationKey, string bucketName) : IDisposable
{
    public string UploadId { get; } = uploadId;
    public string DestinationKey { get; } = destinationKey;
    public string BucketName { get; } = bucketName;
    public List<PartETag> UploadedParts { get; } = [];
    public MemoryStream UploadBuffer { get; } = new(10 * ByteSizeConstants.MB);
    public int PartNumber { get; set; } = 1;

    private readonly List<IDisposable> _disposables = [];

    public void AddDisposable(IDisposable disposable)
    {
        _disposables.Add(disposable);
    }

    public void Dispose()
    {
        UploadBuffer.Dispose();
        foreach (var disposable in _disposables)
        {
            disposable.Dispose();
        }

        GC.SuppressFinalize(this);
    }
}

public class S3ReportMergeService(
    IAmazonS3 s3Client,
    IOptions<AwsSettings> awsSettings
) : IS3ReportMergeService
{
    private readonly IAmazonS3 _s3Client = s3Client;
    private readonly AwsSettings _awsSettings = awsSettings.Value;

    public async Task MergeReportFilesAsync(string concatId, ReportMetadata reportMetadata,
        CancellationToken cancellationToken)
    {
        using var scope = Tracer.Instance.StartActive("S3ReportMergeService.MergeReportFilesAsync");
        Log.ForContext("JobId", concatId)
            .ForContext("ReportId", reportMetadata.ReportId)
            .Debug("[S3ReportMergeService.MergeReportFilesAsync] Starting");

        var destinationKey = string.Format(S3ReportsConstants.ReportBasePath, reportMetadata.ReportId,
            FileFormatEnum.Csv.Name.ToLowerInvariant());
        var bucketName = _awsSettings.WorkgroupBucket!;

        var initResponse = await _s3Client.InitiateMultipartUploadAsync(
            new InitiateMultipartUploadRequest
            {
                BucketName = bucketName,
                Key = destinationKey
            },
            cancellationToken
        );

        using var context = new S3MergeContext(initResponse.UploadId, destinationKey, bucketName);

        using var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        cts.CancelAfter(TimeSpan.FromMinutes(30));

        try
        {
            await WriteHeaderToBufferAsync(context, reportMetadata.ReportId, cts.Token);

            var orderedDates = reportMetadata.GetDateRangeDescending();

            foreach (var date in orderedDates)
            {
                await MergeFilesForDateAsync(context, reportMetadata, date, cts.Token);
            }

            if (context.UploadBuffer.Length > 0)
            {
                await UploadPartAsync(context, cts.Token);
            }

            await FinalizeMergeAsync(context, cts.Token);

            Log.ForContext("JobId", concatId)
                .ForContext("ReportId", reportMetadata.ReportId)
                .Debug("[S3ReportMergeService.MergeReportFilesAsync] Completed");
        }
        catch (Exception ex)
        {
            await AbortMergeAsync(context, CancellationToken.None);
            Log.ForContext("Exception", ex)
                .ForContext("JobId", concatId)
                .ForContext("ReportId", reportMetadata.ReportId)
                .Error("[S3ReportMergeService.MergeReportFilesAsync] Error merging files");
            throw;
        }
    }

    private async Task WriteHeaderToBufferAsync(S3MergeContext context, string reportId,
        CancellationToken cancellationToken)
    {
        var headerKey = string.Format(S3ReportsConstants.PartialReportHeaderPath, reportId);
        using var response = await _s3Client.GetObjectAsync(context.BucketName, headerKey, cancellationToken);
        using var reader = new StreamReader(response.ResponseStream);
        var header = await reader.ReadToEndAsync(cancellationToken);

        var headerBytes = Encoding.UTF8.GetBytes(header.Trim() + "\n");
        await context.UploadBuffer.WriteAsync(headerBytes, cancellationToken);
    }

    private async Task MergeFilesForDateAsync(S3MergeContext context, ReportMetadata reportMetadata, DateTime date,
        CancellationToken cancellationToken)
    {
        var priorityQueue = await InitializePriorityQueueForDateAsync(context, reportMetadata, date, cancellationToken);
        await ProcessMergeQueueAsync(context, reportMetadata, priorityQueue, cancellationToken);
    }

    private async Task<PriorityQueue<S3CsvRecordModel, string>> InitializePriorityQueueForDateAsync(
        S3MergeContext context, ReportMetadata reportMetadata, DateTime date, CancellationToken cancellationToken)
    {
        var listRequest = new ListObjectsV2Request
        {
            BucketName = context.BucketName,
            Prefix = string.Format(S3ReportsConstants.PartialReportDatePath, reportMetadata.ReportId, date)
        };

        var priorityQueue = new PriorityQueue<S3CsvRecordModel, string>(new DescendingStringComparer());

        ListObjectsV2Response listObjectsResponse;
        do
        {
            listObjectsResponse = await _s3Client.ListObjectsV2Async(listRequest, cancellationToken);
            foreach (var s3Object in listObjectsResponse.S3Objects.Where(o => o.Size > 0))
            {
                var getObjectResponse =
                    await _s3Client.GetObjectAsync(context.BucketName, s3Object.Key, cancellationToken);
                context.AddDisposable(getObjectResponse);

                var reader = new StreamReader(getObjectResponse.ResponseStream, leaveOpen: true);
                context.AddDisposable(reader);

                var line = await reader.ReadLineAsync(cancellationToken);
                if (line == null) continue;

                var bytesRead = Encoding.UTF8.GetByteCount(line + "\n");
                var record = S3CsvRecordModel.TryCreate(line, reader, reportMetadata.ReportSortColumnIndex,
                    s3Object.Key, bytesRead);
                if (record != null) priorityQueue.Enqueue(record, record.SortKey);
            }

            listRequest.ContinuationToken = listObjectsResponse.NextContinuationToken;
        } while (listObjectsResponse.IsTruncated);

        return priorityQueue;
    }

    private async Task ProcessMergeQueueAsync(S3MergeContext context, ReportMetadata reportMetadata,
        PriorityQueue<S3CsvRecordModel, string> priorityQueue, CancellationToken cancellationToken)
    {
        while (priorityQueue.Count > 0)
        {
            var record = priorityQueue.Dequeue();
            var lineBytes = Encoding.UTF8.GetBytes(record.Line + "\n");

            if (context.UploadBuffer.Position + lineBytes.Length > context.UploadBuffer.Capacity)
            {
                await UploadPartAsync(context, cancellationToken);
            }

            await context.UploadBuffer.WriteAsync(lineBytes, cancellationToken);

            await TryReadNextLineAndEnqueueAsync(record, priorityQueue, context, reportMetadata, cancellationToken);
        }
    }

    private async Task TryReadNextLineAndEnqueueAsync(S3CsvRecordModel record,
        PriorityQueue<S3CsvRecordModel, string> priorityQueue, S3MergeContext context, ReportMetadata reportMetadata,
        CancellationToken cancellationToken)
    {
        try
        {
            var nextLine = await record.Reader.ReadLineAsync(cancellationToken);
            if (nextLine != null)
            {
                var bytesInNextLine = Encoding.UTF8.GetByteCount(nextLine + "\n");
                var totalBytesRead = record.BytesRead + bytesInNextLine;
                var nextRecord = S3CsvRecordModel.TryCreate(nextLine, record.Reader,
                    reportMetadata.ReportSortColumnIndex, record.S3Key, totalBytesRead);
                if (nextRecord != null) priorityQueue.Enqueue(nextRecord, nextRecord.SortKey);
            }
        }
        catch (IOException ex) when (ex.Message.Contains("unexpected EOF"))
        {
            Log.ForContext("S3Key", record.S3Key)
                .ForContext("BytesRead", record.BytesRead)
                .Warning("[S3ReportMergeService] Caught unexpected EOF. Reconnecting with Range request...");

            var rangeRequest = new GetObjectRequest
            {
                BucketName = context.BucketName,
                Key = record.S3Key,
                ByteRange = new ByteRange($"bytes={record.BytesRead}-")
            };

            var getObjectResponse = await _s3Client.GetObjectAsync(rangeRequest, cancellationToken);
            context.AddDisposable(getObjectResponse);
            var newReader = new StreamReader(getObjectResponse.ResponseStream, leaveOpen: true);
            context.AddDisposable(newReader);

            var nextLine = await newReader.ReadLineAsync(cancellationToken);
            if (nextLine != null)
            {
                var bytesInNextLine = Encoding.UTF8.GetByteCount(nextLine + "\n");
                var totalBytesRead = record.BytesRead + bytesInNextLine;
                var nextRecord = S3CsvRecordModel.TryCreate(nextLine, newReader, reportMetadata.ReportSortColumnIndex,
                    record.S3Key, totalBytesRead);
                if (nextRecord != null) priorityQueue.Enqueue(nextRecord, nextRecord.SortKey);
            }
        }
    }

    private async Task UploadPartAsync(S3MergeContext context, CancellationToken cancellationToken)
    {
        context.UploadBuffer.Seek(0, SeekOrigin.Begin);
        var uploadRequest = new UploadPartRequest
        {
            BucketName = context.BucketName,
            Key = context.DestinationKey,
            UploadId = context.UploadId,
            PartNumber = context.PartNumber,
            InputStream = context.UploadBuffer,
            PartSize = context.UploadBuffer.Length
        };

        var response = await _s3Client.UploadPartAsync(uploadRequest, cancellationToken);
        context.UploadedParts.Add(new PartETag(context.PartNumber, response.ETag));
        context.PartNumber++;
        context.UploadBuffer.SetLength(0);
    }

    private async Task FinalizeMergeAsync(S3MergeContext context, CancellationToken cancellationToken)
    {
        var completeRequest = new CompleteMultipartUploadRequest
        {
            BucketName = context.BucketName,
            Key = context.DestinationKey,
            UploadId = context.UploadId,
            PartETags = context.UploadedParts
        };
        await _s3Client.CompleteMultipartUploadAsync(completeRequest, cancellationToken);
    }

    private async Task AbortMergeAsync(S3MergeContext context, CancellationToken cancellationToken)
    {
        var abortRequest = new AbortMultipartUploadRequest
        {
            BucketName = context.BucketName,
            Key = context.DestinationKey,
            UploadId = context.UploadId
        };
        await _s3Client.AbortMultipartUploadAsync(abortRequest, cancellationToken);
    }
}
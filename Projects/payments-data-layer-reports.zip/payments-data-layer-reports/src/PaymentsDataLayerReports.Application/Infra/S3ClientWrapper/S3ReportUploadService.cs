using Amazon.S3;
using Amazon.S3.Transfer;
using Microsoft.Extensions.Options;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Extensions;
using PaymentsDataLayerReports.Application.Settings;
using Serilog;

namespace PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;

public interface IS3ReportUploadService
{
    Task UploadReportAsync(string sourcePath, string reportId, string partitionIdGroup, DateTime? partitionDate = null, string? fileFormat = null);
    Task UploadReportHeaderAsync(string reportId, string header);
}

public class S3ReportUploadService(
    IAmazonS3 s3Client,
    IOptions<AwsSettings> awsSettings,
    ITransferUtility transferUtility
) : IS3ReportUploadService
{
    private readonly IAmazonS3 _s3Client = s3Client;
    private readonly AwsSettings _awsSettings = awsSettings.Value;
    private readonly ITransferUtility _transferUtility = transferUtility;

    public async Task UploadReportAsync(string sourcePath, string reportId, string partitionIdGroup, DateTime? partitionDate = null, string? fileFormat = null)
    {
        Log.Debug("[S3ReportUploadService.UploadReportAsync] Starting");

        try
        {
            if (!File.Exists(sourcePath))
            {
                throw new FileNotFoundException($"Local file not found: {sourcePath}");
            }

            var resolvedFileFormat = string.IsNullOrWhiteSpace(fileFormat)
                ? FileFormatEnum.Csv.Name
                : fileFormat.ToLowerInvariant();

            var destinationPath = partitionDate == null ?
                string.Format(S3ReportsConstants.ReportBasePath, reportId, resolvedFileFormat) :
                string.Format(S3ReportsConstants.PartialReportFilePath, reportId, partitionDate.Value, partitionIdGroup);

            await _transferUtility.UploadAsync(sourcePath, _awsSettings.WorkgroupBucket!, destinationPath);

            Log.ForContext("DestinationPath", destinationPath)
                .ForContext("bucketName", _awsSettings.WorkgroupBucket)
                .Debug("[S3ReportUploadService.UploadReportAsync] Successfully uploaded file");
        }
        catch (Exception ex)
        {
            Log.Error(ex, "[S3ReportUploadService.UploadReportAsync] Error uploading file");
            throw;
        }
    }

    public async Task UploadReportHeaderAsync(string reportId, string header)
    {
        Log.ForContext("ReportId", reportId)
            .Debug("[S3ReportUploadService.UploadReportHeaderAsync] Starting");

        try
        {
            var headerPath = string.Format(S3ReportsConstants.PartialReportHeaderPath, reportId);
            await _s3Client.WriteStringAsync(_awsSettings.WorkgroupBucket!, headerPath, header, "text/csv");

            Log.ForContext("Path", headerPath)
                .ForContext("Bucket", _awsSettings.WorkgroupBucket)
                .Debug("[S3ReportUploadService.UploadReportHeaderAsync] Completed");
        }
        catch (Exception ex)
        {
            Log.Error(ex, "[S3ReportUploadService.UploadReportHeaderAsync] Error uploading file");
            throw;
        }
    }
}

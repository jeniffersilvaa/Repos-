using Amazon.S3;
using Amazon.S3.Model;
using Microsoft.Extensions.Options;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;
using Serilog;

namespace PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;

public interface IS3ClientWrapper
{
    string? BuildReportUrl(string reportId, double expirationHours = S3ReportsConstants.UrlDefaultExpirationHours, string? fileName = null, string? fileFormat = null);
    Task MergeReportFilesAsync(string concatId, ReportMetadata reportMetadata, CancellationToken cancellationToken);
    Task<ReportMetadata?> GetReportMetadataAsync(string reportId);
    Task UploadReportMetadataAsync(ReportMetadata reportMetadata);
    Task UploadReportAsync(string sourcePath, string reportId, string partitionIdGroup, DateTime? partitionDate = null, string? fileFormat = null);
    Task UploadReportHeaderAsync(string reportId, string header);
    Task<bool> ReportFileExistsAsync(string reportId, string? fileFormat = null);
    Task<(bool Exists, string? FileFormat)> GetReportFileWithFormatAsync(string reportId);
}

public class S3ClientWrapper(
    IAmazonS3 s3Client,
    IOptions<AwsSettings> awsSettings,
    IS3ReportMergeService s3ReportMergeService,
    IS3ReportMetadataHandlerService s3ReportMetadataHandlerService,
    IS3ReportUploadService s3ReportUploadService,
    IS3ReportFileQueryService s3ReportFileQueryService
) : IS3ClientWrapper
{
    private readonly IAmazonS3 _s3Client = s3Client;
    private readonly AwsSettings _awsSettings = awsSettings.Value;
    private readonly IS3ReportMergeService _s3ReportMergeService = s3ReportMergeService;
    private readonly IS3ReportMetadataHandlerService _s3ReportMetadataHandlerService = s3ReportMetadataHandlerService;
    private readonly IS3ReportUploadService _s3ReportUploadService = s3ReportUploadService;
    private readonly IS3ReportFileQueryService _s3ReportFileQueryService = s3ReportFileQueryService;

    public string? BuildReportUrl(string reportId, double expirationHours = S3ReportsConstants.UrlDefaultExpirationHours, string? fileName = null, string? fileFormat = null)
    {
        Log.Debug("[S3ClientWrapper.BuildReportUrl] Starting");

        var filePath = string.Format(S3ReportsConstants.ReportBasePath, reportId, fileFormat ?? FileFormatEnum.Csv.Name);
        var preSignedUrlRequest = new GetPreSignedUrlRequest()
        {
            BucketName = _awsSettings.WorkgroupBucket,
            Key = filePath,
            Expires = DateTime.UtcNow.AddHours(expirationHours),
        };
        if (!string.IsNullOrWhiteSpace(fileName))
        {
            preSignedUrlRequest.ResponseHeaderOverrides = new ResponseHeaderOverrides { ContentDisposition = $"attachment; filename=\"{fileName}\"" };
        }
        return _s3Client.GetPreSignedURL(preSignedUrlRequest);
    }

    public async Task MergeReportFilesAsync(string concatId, ReportMetadata reportMetadata, CancellationToken cancellationToken)
    {
        await _s3ReportMergeService.MergeReportFilesAsync(concatId, reportMetadata, cancellationToken);
    }

    public async Task<ReportMetadata?> GetReportMetadataAsync(string reportId)
    {
        return await _s3ReportMetadataHandlerService.GetReportMetadataAsync(reportId);
    }

    public async Task<bool> ReportFileExistsAsync(string reportId, string? fileFormat = null)
    {
        return await _s3ReportFileQueryService.ReportFileExistsAsync(reportId, fileFormat);
    }

    public async Task<(bool Exists, string? FileFormat)> GetReportFileWithFormatAsync(string reportId)
    {
        return await _s3ReportFileQueryService.GetReportFileWithFormatAsync(reportId);
    }

    public async Task UploadReportMetadataAsync(ReportMetadata reportMetadata)
    {
        await _s3ReportMetadataHandlerService.UploadReportMetadataAsync(reportMetadata);
    }

    public async Task UploadReportAsync(string sourcePath, string reportId, string partitionIdGroup, DateTime? partitionDate = null, string? fileFormat = null)
    {
        await _s3ReportUploadService.UploadReportAsync(sourcePath, reportId, partitionIdGroup, partitionDate, fileFormat);
    }

    public async Task UploadReportHeaderAsync(string reportId, string header)
    {
        await _s3ReportUploadService.UploadReportHeaderAsync(reportId, header);
    }
}

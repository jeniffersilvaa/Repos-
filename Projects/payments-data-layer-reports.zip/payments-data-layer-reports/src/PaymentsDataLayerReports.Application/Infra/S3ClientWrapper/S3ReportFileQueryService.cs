using Amazon.S3;
using Amazon.S3.Model;
using Microsoft.Extensions.Options;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Settings;
using Serilog;

namespace PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;

public interface IS3ReportFileQueryService
{
    Task<bool> ReportFileExistsAsync(string reportId, string? fileFormat = null);
    Task<(bool Exists, string? FileFormat)> GetReportFileWithFormatAsync(string reportId);
}

public class S3ReportFileQueryService(
    IAmazonS3 s3Client,
    IOptions<AwsSettings> awsSettings
) : IS3ReportFileQueryService
{
    private readonly IAmazonS3 _s3Client = s3Client;
    private readonly AwsSettings _awsSettings = awsSettings.Value;
    private const string _emptyFormat = "";

    public async Task<bool> ReportFileExistsAsync(string reportId, string? fileFormat = null)
    {
        var key = string.Format(S3ReportsConstants.ReportBasePath, reportId, fileFormat ?? FileFormatEnum.Csv.Name);
        try
        {
            var request = new GetObjectMetadataRequest
            {
                BucketName = _awsSettings.WorkgroupBucket,
                Key = key
            };
            await _s3Client.GetObjectMetadataAsync(request);
            return true;
        }
        catch (AmazonS3Exception ex) when (ex.StatusCode == System.Net.HttpStatusCode.NotFound)
        {
            return false;
        }
        catch (AmazonS3Exception ex)
        {
            Log.Warning(ex, "[S3ReportFileQueryService.ReportFileExistsAsync] Error checking object metadata for {Key}", key);
            return false;
        }
    }

    public async Task<(bool Exists, string? FileFormat)> GetReportFileWithFormatAsync(string reportId)
    {
        try
        {
            var prefix = string.Format(S3ReportsConstants.ReportBasePath, reportId, _emptyFormat);
            var request = new ListObjectsV2Request
            {
                BucketName = _awsSettings.WorkgroupBucket,
                Prefix = prefix,
                MaxKeys = 1
            };

            var response = await _s3Client.ListObjectsV2Async(request);

            if (response.S3Objects.Count == 0)
            {
                return (false, null);
            }

            var objectKey = response.S3Objects[0].Key;
            var fileFormat = objectKey.Split('.').Last();

            return (true, fileFormat);
        }
        catch (AmazonS3Exception ex)
        {
            Log.Warning(ex, "[S3ReportFileQueryService.GetReportFileWithFormatAsync] Error listing objects with prefix reports/{ReportId}.", reportId);
            return (false, null);
        }
    }
}
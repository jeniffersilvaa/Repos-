using Serilog;

namespace PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;

public class S3CsvRecordModel
{
    public string Line { get; }
    public StreamReader Reader { get; }
    public string SortKey { get; }
    public string S3Key { get; }
    public long BytesRead { get; }

    private S3CsvRecordModel(string line, StreamReader reader, string sortKey, string s3Key, long bytesRead)
    {
        Line = line;
        Reader = reader;
        SortKey = sortKey;
        S3Key = s3Key;
        BytesRead = bytesRead;
    }

    public static S3CsvRecordModel? TryCreate(string line, StreamReader reader, int dateSortColumnIndex, string s3Key, long bytesRead = 0)
    {
        var columns = line.Split(',');
        if (columns.Length > dateSortColumnIndex)
        {
            return new S3CsvRecordModel(line, reader, columns[dateSortColumnIndex], s3Key, bytesRead);
        }

        Log.ForContext("Line", line)
            .ForContext("DateSortColumnIndex", dateSortColumnIndex)
            .Warning("[S3CsvRecordModel.TryCreate] Failed to parse line or create S3CsvRecordModel");
        return null;
    }
}

public class DescendingStringComparer : IComparer<string>
{
    public int Compare(string? x, string? y)
    {
        // If both are null, they are considered equal
        if (x == null && y == null) return 0;

        // A null value is considered less than any non-null value
        // For descending order, this places nulls at the end
        if (x == null) return 1;
        if (y == null) return -1;

        // Perform a descending ordinal comparison for non-null strings
        return string.Compare(y, x, StringComparison.OrdinalIgnoreCase);
    }
}

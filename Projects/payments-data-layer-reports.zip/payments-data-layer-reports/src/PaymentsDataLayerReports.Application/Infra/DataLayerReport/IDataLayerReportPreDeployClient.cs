using PaymentsDataLayerReports.Application.Routes.Reports.PostChargesReport;
using PaymentsDataLayerReports.Application.Routes.Reports.PostReports;

namespace PaymentsDataLayerReports.Application.Infra.DataLayerReport;

public interface IDataLayerReportPreDeployClient
{
    Task PostChargesReport(PostChargesReportRequest request, string correlationId, CancellationToken cancellationToken = default);
    Task PostReports(PostReportsRequest request, string correlationId, CancellationToken cancellationToken = default);
}
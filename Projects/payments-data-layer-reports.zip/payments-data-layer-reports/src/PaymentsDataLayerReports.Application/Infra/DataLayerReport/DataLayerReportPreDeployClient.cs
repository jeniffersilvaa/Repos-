using System.Text;
using System.Text.Json;
using PaymentsDataLayerReports.Application.Routes.Reports.PostChargesReport;
using PaymentsDataLayerReports.Application.Routes.Reports.PostReports;

namespace PaymentsDataLayerReports.Application.Infra.DataLayerReport;

public class DataLayerReportPreDeployClient : IDataLayerReportPreDeployClient
{
    private const string _clientName = "dataLayerReportPreDeployClient";
    private const string _correlationIdHeaderName = "X-Report-Correlation-Id";
    private readonly IHttpClientFactory _httpClientFactory;
    private readonly JsonSerializerOptions _jsonOptions;
    private static readonly JsonSerializerOptions _snakeCaseJsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower,
        WriteIndented = false
    };

    public DataLayerReportPreDeployClient(IHttpClientFactory httpClientFactory)
    {
        _httpClientFactory = httpClientFactory;
        _jsonOptions = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            WriteIndented = false
        };
    }

    public async Task PostChargesReport(PostChargesReportRequest request, string correlationId, CancellationToken cancellationToken = default)
    {
        var requestUri = $"/charges/report";

        try
        {
            var queryParametersBuilder = request.ToQueryParameters();
            var requestUriWithParams = requestUri + queryParametersBuilder.Build();

            using var client = _httpClientFactory.CreateClient(_clientName);
            var content = new StringContent(
                JsonSerializer.Serialize(request, _jsonOptions),
                Encoding.UTF8,
                "application/json"
            );
            var httpRequest = new HttpRequestMessage(HttpMethod.Post, requestUriWithParams)
            {
                Content = content
            };

            httpRequest.Headers.Add(_correlationIdHeaderName, correlationId);

            await client.SendAsync(httpRequest, cancellationToken);
        }
        catch
        {
            // Fire and forget - no logging needed
        }

        return;
    }

    public async Task PostReports(PostReportsRequest request, string correlationId, CancellationToken cancellationToken = default)
    {
        var requestUri = "/v1/reports";

        try
        {
            using var client = _httpClientFactory.CreateClient(_clientName);
            var content = new StringContent(
                JsonSerializer.Serialize(request, _snakeCaseJsonOptions),
                Encoding.UTF8,
                "application/json"
            );
            var httpRequest = new HttpRequestMessage(HttpMethod.Post, requestUri)
            {
                Content = content
            };

            httpRequest.Headers.Add(_correlationIdHeaderName, correlationId);

            await client.SendAsync(httpRequest, cancellationToken);
        }
        catch
        {
            // Fire and forget - no logging needed
        }

        return;
    }
}
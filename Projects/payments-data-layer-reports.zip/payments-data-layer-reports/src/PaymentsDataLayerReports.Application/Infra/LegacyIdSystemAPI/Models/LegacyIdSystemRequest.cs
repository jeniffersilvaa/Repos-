using System.Web;

namespace PaymentsDataLayerReports.Application.Infra.LegacyIdSystemAPI.Models
{
    public class LegacyIdSystemRequest
    {
        public IEnumerable<string>? Document { get; set; }
        public IEnumerable<string>? StoneAccount { get; set; }
        public IEnumerable<string>? AffiliationKey { get; set; }
        public IEnumerable<string>? PaymentProfile { get; set; }
        public IEnumerable<string>? PoiType { get; set; }

        public string ToQueryString()
        {
            var query = HttpUtility.ParseQueryString(string.Empty);

            if (Document != null)
                query["document"] = string.Join(",", Document);

            if (StoneAccount != null)
                query["stoneAccount"] = string.Join(",", StoneAccount);

            if (AffiliationKey != null)
                query["affiliationKey"] = string.Join(",", AffiliationKey);

            if (PaymentProfile != null)
                query["paymentProfile"] = string.Join(",", PaymentProfile);

            if (PoiType != null)
                query["poiType"] = string.Join(",", PoiType);

            return query.ToString() ?? string.Empty;
        }
    }
}

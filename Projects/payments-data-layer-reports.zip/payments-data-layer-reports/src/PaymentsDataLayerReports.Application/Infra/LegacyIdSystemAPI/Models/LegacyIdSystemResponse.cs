namespace PaymentsDataLayerReports.Application.Infra.LegacyIdSystemAPI.Models
{
    public class LegacyIdSystemResponse
    {
        public string? Document { get; set; }
        public string? StoneAccount { get; set; }
        public string? PaymentProfile { get; set; }
        public string? PoiType { get; set; }
        public string? AffiliationKey { get; set; }
        public string? AffiliationCode { get; set; }
        public string? MerchantId { get; set; }
        public string? AccountId { get; set; }
        public string? Organization { get; set; }
    }
}

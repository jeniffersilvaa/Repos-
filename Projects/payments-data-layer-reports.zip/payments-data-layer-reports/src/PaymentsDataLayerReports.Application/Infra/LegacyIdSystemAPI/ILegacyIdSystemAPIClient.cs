using PaymentsDataLayerReports.Application.Infra.LegacyIdSystemAPI.Models;

namespace PaymentsDataLayerReports.Application.Infra.LegacyIdSystemAPI
{
    public interface ILegacyIdSystemAPIClient
    {
        Task<List<LegacyIdSystemResponse>?> GetClients(LegacyIdSystemRequest legacyIdSystemRequest, CancellationToken cancellationToken);
    }
}

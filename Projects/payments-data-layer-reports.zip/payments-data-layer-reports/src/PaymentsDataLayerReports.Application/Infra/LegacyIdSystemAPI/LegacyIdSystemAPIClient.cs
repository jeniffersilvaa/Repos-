using System.Text.Json;
using Microsoft.Extensions.Options;
using PaymentsDataLayerReports.Application.Infra.LegacyIdSystemAPI.Models;
using PaymentsDataLayerReports.Application.Settings;
using Serilog;

namespace PaymentsDataLayerReports.Application.Infra.LegacyIdSystemAPI;

public class LegacyIdSystemAPIClient : ILegacyIdSystemAPIClient
{
    private const string _clientName = "legacyIdSystemApiClient";
    private readonly IHttpClientFactory _factory;

    private readonly JsonSerializerOptions _jsonDeserializerOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    public LegacyIdSystemAPIClient(
        IHttpClientFactory factory,
        IOptions<LegacyIdSystemAPISettings> settings)
    {
        _factory = factory;
    }

    public async Task<List<LegacyIdSystemResponse>?> GetClients(LegacyIdSystemRequest legacyIdSystemRequest, CancellationToken cancellationToken)
    {
        using var client = _factory.CreateClient(_clientName);
        var queryString = legacyIdSystemRequest.ToQueryString();
        var requestUri = $"clients?{queryString}";

        try
        {
            Log.ForContext("Document", legacyIdSystemRequest.Document)
                .ForContext("StoneAccount", legacyIdSystemRequest.StoneAccount)
                .ForContext("AffiliationKey", legacyIdSystemRequest.AffiliationKey)
                .ForContext("PaymentProfile", legacyIdSystemRequest.PaymentProfile)
                .ForContext("PoiType", legacyIdSystemRequest.PoiType)
                .ForContext("requestUri", requestUri)
                .ForContext("queryString", queryString)
                .Information("[LegacyIdSystemAPIClient.GetClients] - Sending Request");

            using var response = await client.GetAsync(requestUri, cancellationToken);

            if (response.IsSuccessStatusCode)
            {
                await using var stream = await response.Content.ReadAsStreamAsync(cancellationToken);
                return await JsonSerializer.DeserializeAsync<List<LegacyIdSystemResponse>>(
                    stream,
                    _jsonDeserializerOptions,
                    cancellationToken);
            }

            Log.ForContext("Document", legacyIdSystemRequest.Document)
                .ForContext("StoneAccount", legacyIdSystemRequest.StoneAccount)
                .ForContext("AffiliationKey", legacyIdSystemRequest.AffiliationKey)
                .ForContext("StatusCode", response.StatusCode)
                .ForContext("ReasonPhrase", response.ReasonPhrase)
                .Warning($"[LegacyIdSystemAPIClient.GetClients] - Legacy Id System API returned a non-success status code.");

            throw new HttpRequestException($"Request to Legacy Id System API failed: {response.ReasonPhrase}", null, response.StatusCode);
        }
        catch (Exception ex)
        {
            Log.ForContext("Document", legacyIdSystemRequest.Document)
                .ForContext("StoneAccount", legacyIdSystemRequest.StoneAccount)
                .ForContext("AffiliationKey", legacyIdSystemRequest.AffiliationKey)
                .Error(ex, "[LegacyIdSystemAPIClient.GetClients] - Error");
            throw;
        }
    }
}

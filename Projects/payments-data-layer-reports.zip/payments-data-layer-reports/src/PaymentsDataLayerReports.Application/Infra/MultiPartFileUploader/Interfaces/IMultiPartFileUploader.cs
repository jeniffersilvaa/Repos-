namespace PaymentsDataLayerReports.Application.Infra.MultiPartFileUploader.Interfaces;

public interface IMultiPartFileUploader
{
    Task InitiateMultipartUploadAsync(string fileName, string bucketName, CancellationToken cancellationToken);

    Task UploadPartAsync(MemoryStream partStream, CancellationToken cancellationToken);

    Task<string> CompleteMultipartUploadAsync(CancellationToken cancellationToken);

    Task AbortMultipartUploadAsync(CancellationToken cancellationToken);

}
using Amazon.S3;
using Amazon.S3.Model;
using PaymentsDataLayerReports.Application.Infra.MultiPartFileUploader.Interfaces;

namespace PaymentsDataLayerReports.Application.Infra.MultiPartFileUploader;

public class S3FileUploader(IAmazonS3 s3Client) : IMultiPartFileUploader
{
    private readonly IAmazonS3 _s3Client = s3Client;
    private string _uploadId = string.Empty;
    private string _bucketName = string.Empty;
    private string _fileName = string.Empty;

    private List<PartETag> _partETags = [];
    private int _partNumber = 1;

    public async Task InitiateMultipartUploadAsync(string fileName, string bucketName, CancellationToken cancellationToken = default)
    {
        var response = await _s3Client.InitiateMultipartUploadAsync(
                     new InitiateMultipartUploadRequest
                     {
                         BucketName = bucketName,
                         Key = fileName
                     },
                     cancellationToken
                 );

        _uploadId = response.UploadId;
        _bucketName = bucketName;
        _fileName = fileName;
    }

    public async Task UploadPartAsync(MemoryStream partStream, CancellationToken cancellationToken)
    {
        partStream.Position = 0;

        var uploadPartRequest = new UploadPartRequest
        {
            BucketName = _bucketName,
            Key = _fileName,
            UploadId = _uploadId,
            PartNumber = _partNumber,
            PartSize = partStream.Length,
            InputStream = partStream
        };

        var response = await _s3Client.UploadPartAsync(uploadPartRequest, cancellationToken);

        _partETags.Add(new PartETag
        {
            PartNumber = _partNumber,
            ETag = response.ETag
        });

        _partNumber++;

        partStream.SetLength(0);
    }

    public async Task<string> CompleteMultipartUploadAsync(CancellationToken cancellationToken)
    {
        try
        {
            var completeRequest = new CompleteMultipartUploadRequest
            {
                BucketName = _bucketName,
                Key = _fileName,
                UploadId = _uploadId,
                PartETags = _partETags
            };

            var response = await _s3Client.CompleteMultipartUploadAsync(completeRequest, cancellationToken);
            Complete();

            return response.Location;

        }
        finally
        {
            Complete();
        }

    }

    public async Task AbortMultipartUploadAsync(CancellationToken cancellationToken)
    {
        if (string.IsNullOrEmpty(_uploadId))
        {
            return;
        }

        try
        {
            var abortRequest = new AbortMultipartUploadRequest
            {
                BucketName = _bucketName,
                Key = _fileName,
                UploadId = _uploadId
            };

            await _s3Client.AbortMultipartUploadAsync(abortRequest, cancellationToken);
        }
        finally
        {
            Complete();
        }
    }

    private void Complete()
    {
        _partETags.Clear();
        _partNumber = 1;
        _uploadId = string.Empty;
        _bucketName = string.Empty;
        _fileName = string.Empty;
    }
}
namespace PaymentsDataLayerReports.Application.Infra.DataLayerApi.Models;

public record GetDataByCursorResponseModel<T>
{
    public int Size { get; set; }

    public string? Cursor { get; set; }

    public long Total { get; set; }

    public IEnumerable<T> Data { get; set; } = [];
}
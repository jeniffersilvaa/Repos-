using PaymentsDataLayerReports.Application.Infra.Shared;

namespace PaymentsDataLayerReports.Application.Infra.DataLayerApi.Models;

public class GetOrderByCursorRequestModel : IGetDataByCursorRequestModel
{
    public string? Cursor { get; set; }
    public int? Size { get; set; }

    public Dictionary<string, string>? FilterParameters { get; set; }

    public IQueryBuilder ToQueryParameters()
    {
        var queryBuilder = new QueryBuilder()
            .Add("cursor", Cursor?.ToString())
            .Add("size", Size?.ToString())
            .Add("is_test_account", FilterParameters?.GetValueOrDefault("is_test_account"))
            .AddDateTime("start_date", ParseDateTimeOrNull(FilterParameters?.GetValueOrDefault("start_date")))
            .AddDateTime("end_date", ParseDateTimeOrNull(FilterParameters?.GetValueOrDefault("end_date")))
            .Add("settlement_status", FilterParameters?.GetValueOrDefault("settlement_status"))
            .Add("merchant_id", FilterParameters?.GetValueOrDefault("merchant_id"))
            .Add("stone_accounts", FilterParameters?.GetValueOrDefault("stone_accounts"))
            .Add("payment_profile_ids", FilterParameters?.GetValueOrDefault("payment_profile_ids"))
            .Add("documents", FilterParameters?.GetValueOrDefault("documents"))
            .Add("point_of_interaction_types", FilterParameters?.GetValueOrDefault("point_of_interaction_types"));

        return queryBuilder;
    }

    private static DateTime? ParseDateTimeOrNull(string? dateString)
    {
        if (string.IsNullOrEmpty(dateString) || !DateTime.TryParse(dateString, out var result))
        {
            return null;
        }

        return result;
    }
}
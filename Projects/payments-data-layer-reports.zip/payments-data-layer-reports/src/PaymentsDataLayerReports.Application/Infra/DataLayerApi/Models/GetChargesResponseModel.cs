using PaymentsDataLayerReports.Application.Entities;

namespace PaymentsDataLayerReports.Application.Infra.DataLayerApi.Models;

public record GetChargesResponseModel
{
    public int Size { get; set; }

    public long? Current { get; set; }

    public string? Cursor { get; set; }

    public long? Next { get; set; }

    public long Total { get; set; }

    public IEnumerable<Charge> Data { get; set; } = [];
}
using PaymentsDataLayerReports.Application.Infra.Shared;

namespace PaymentsDataLayerReports.Application.Infra.DataLayerApi.Models;

public class GetFinancialMovementsRequestModel
{
    public string? Cursor { get; set; }
    public int? Size { get; set; }
    public DateOnly? StartDueDate { get; set; }
    public DateOnly? EndDueDate { get; set; }
    public string? Organizations { get; set; }
    public string? Document { get; set; }
    public string? AffiliationCodes { get; set; }
    public string? SettlementStatus { get; set; }
    public string? Products { get; set; }
    public string? Brands { get; set; }
    public string? WalletTypeIds { get; set; }
    public string? Categories { get; set; }
    public bool? WithPayments { get; set; }
    public string? StoneAccounts { get; set; }
    public string? PaymentProfiles { get; set; }
    public string? PoiTypes { get; set; }
    public string? AccountId { get; set; }
    public string? MerchantId { get; set; }

    public IQueryBuilder ToQueryParameters()
    {
        var queryBuilder = new QueryBuilder()
            .Add("cursor", Cursor?.ToString())
            .Add("size", Size?.ToString())
            .AddDateOnly("due_date_start", StartDueDate!)
            .AddDateOnly("due_date_end", EndDueDate!)
            .Add("organizations", Organizations?.ToLower())
            .Add("settlement_status", SettlementStatus)
            .Add("products", Products)
            .Add("brands", Brands)
            .Add("wallet_type_ids", WalletTypeIds)
            .Add("categories", Categories)
            .Add("with_payments", WithPayments?.ToString().ToLower())
            .Add("stone_accounts", StoneAccounts)
            .Add("payment_profile_ids", PaymentProfiles)
            .Add("point_of_interaction_types", PoiTypes)
            .Add("account_id", AccountId)
            .Add("merchant_id", MerchantId);

        // DALAPI ignores filter by "affiliation_codes" when both identifiers ("document" and "affiliation_codes") is provided
        if (!string.IsNullOrWhiteSpace(AffiliationCodes))
        {
            queryBuilder.Add("affiliation_codes", AffiliationCodes);
            return queryBuilder;
        }

        queryBuilder.Add("document", Document);

        return queryBuilder;
    }
}
using PaymentsDataLayerReports.Application.Infra.Shared;

namespace PaymentsDataLayerReports.Application.Infra.DataLayerApi.Models;

public interface IGetDataByCursorRequestModel
{
    public string? Cursor { get; set; }
    public int? Size { get; set; }

    public Dictionary<string, string>? FilterParameters { get; set; }
    public IQueryBuilder ToQueryParameters();
}
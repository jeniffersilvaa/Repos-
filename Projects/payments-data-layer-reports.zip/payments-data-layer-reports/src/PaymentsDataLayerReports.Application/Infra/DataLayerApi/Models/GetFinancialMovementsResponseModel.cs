using PaymentsDataLayerReports.Application.Entities;

namespace PaymentsDataLayerReports.Application.Infra.DataLayerApi.Models;

public record GetFinancialMovementsResponseModel
{
    public int Size { get; set; }
    public string? Cursor { get; set; }
    public int Total { get; set; }
    public IEnumerable<FinancialMovement> Data { get; set; } = [];
}
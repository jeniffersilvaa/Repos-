using PaymentsDataLayerReports.Application.Infra.Shared;

namespace PaymentsDataLayerReports.Application.Infra.DataLayerApi.Models;

public class GetChargesRequestModel
{
    public string? Cursor { get; set; }
    public int? Size { get; set; }
    public DateTimeOffset? StartCreationDate { get; set; }
    public DateTimeOffset? EndCreationDate { get; set; }
    public string? Document { get; set; }
    public string? AccountId { get; set; }
    public string? MerchantId { get; set; }
    public bool? IsSandbox { get; set; }
    public string? AffiliationCodes { get; set; }
    public string? Organizations { get; set; }
    public string? Status { get; set; }
    public string? ChargeId { get; set; }
    public string? TransactionId { get; set; }
    public string? OurNumber { get; set; }
    public string? E2EId { get; set; }
    public string? AuthorizationCode { get; set; }
    public string? PaymentMethods { get; set; }
    public string? PaymentMethodTypes { get; set; }
    public string? FundingSources { get; set; }
    public string? CardBrands { get; set; }
    public byte? NumberOfInstallments { get; set; }
    public string? TerminalTypes { get; set; }
    public string? TerminalSerialNumber { get; set; }
    public string? SchemeBusinessModels { get; set; }
    public string? CardFirstSixDigits { get; set; }
    public string? CardLastFourDigits { get; set; }
    public string? CustomerName { get; set; }
    public string? PayerName { get; set; }
    public long? MinAmount { get; set; }
    public long? MaxAmount { get; set; }
    public long? MinUpdatedAmount { get; set; }
    public long? MaxUpdatedAmount { get; set; }
    public bool? WithDetails { get; set; }
    public bool? WithFailed { get; set; }
    public bool? WithFullAmounts { get; set; }
    public bool? DalarRequest { get; set; }
    public string? Products { get; set; }
    public string? AllIds { get; set; }
    public string? Customers { get; set; }
    public string? Acquirers { get; set; }
    public string? BankNames { get; set; }
    public DateTime? PaidAt { get; set; }
    public string? PlatformNames { get; set; }
    public string? AntifraudStatus { get; set; }
    public string? LastOperationStatus { get; set; }
    public string? LastLegacyStatus { get; set; }
    public string? StoneAccounts { get; set; }
    public string? PaymentProfiles { get; set; }
    public string? PoiTypes { get; set; }

    public IQueryBuilder ToQueryParameters()
    {
        var queryBuilder = new QueryBuilder()
            .Add("cursor", Cursor)
            .Add("size", Size.ToString())
            .AddDateTime("start_creation_date", StartCreationDate)
            .AddDateTime("end_creation_date", EndCreationDate)
            .Add("document", Document)
            .Add("account_id", AccountId)
            .Add("merchant_id", MerchantId)
            .Add("is_sandbox", IsSandbox.ToString())
            .Add("affiliation_codes", AffiliationCodes)
            .Add("organizations", Organizations)
            .Add("status", Status)
            .Add("charge_id", ChargeId)
            .Add("transaction_id", TransactionId)
            .Add("our_number", OurNumber)
            .Add("e2e_id", E2EId)
            .Add("authorization_code", AuthorizationCode)
            .Add("payment_methods", PaymentMethods)
            .Add("payment_method_types", PaymentMethodTypes)
            .Add("funding_sources", FundingSources)
            .Add("card_brands", CardBrands)
            .Add("number_of_installments", NumberOfInstallments.ToString())
            .Add("terminal_types", TerminalTypes)
            .Add("terminal_serial_number", TerminalSerialNumber)
            .Add("scheme_business_models", SchemeBusinessModels)
            .Add("card_first_six_digits", CardFirstSixDigits)
            .Add("card_last_four_digits", CardLastFourDigits)
            .Add("customer_name", CustomerName)
            .Add("payer_name", PayerName)
            .Add("min_amount", MinAmount.ToString())
            .Add("max_amount", MaxAmount.ToString())
            .Add("min_updated_amount", MinUpdatedAmount.ToString())
            .Add("max_updated_amount", MaxUpdatedAmount.ToString())
            .Add("with_details", WithDetails?.ToString().ToLower())
            .Add("with_failed", WithFailed?.ToString().ToLower())
            .Add("with_full_amounts", WithFullAmounts?.ToString().ToLower())
            .Add("dalar_request", DalarRequest?.ToString().ToLower())
            .Add("products", Products)
            .Add("all_ids", AllIds)
            .Add("customer", Customers)
            .Add("acquirer", Acquirers)
            .Add("bank_name", BankNames)
            .AddDateTime("paid_at", PaidAt)
            .Add("platform_names", PlatformNames)
            .Add("antifraud_status", AntifraudStatus)
            .Add("last_operation_status", LastOperationStatus)
            .Add("last_legacy_status", LastLegacyStatus)
            .Add("stone_account", StoneAccounts)
            .Add("payment_profile_ids", PaymentProfiles)
            .Add("point_of_interaction_types", PoiTypes);

        return queryBuilder;
    }
}

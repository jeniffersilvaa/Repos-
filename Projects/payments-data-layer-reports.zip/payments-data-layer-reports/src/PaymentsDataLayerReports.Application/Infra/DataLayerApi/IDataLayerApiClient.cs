﻿using PaymentsDataLayerReports.Application.Infra.DataLayerApi.Models;

namespace PaymentsDataLayerReports.Application.Infra.DataLayerApi;

public interface IDataLayerApiClient
{
    Task<GetChargesResponseModel> GetCharges(GetChargesRequestModel request, string reportId, CancellationToken cancellationToken);
    Task<GetFinancialMovementsResponseModel> GetFinancialMovements(GetFinancialMovementsRequestModel request, string reportId, CancellationToken cancellationToken);

    Task<GetDataByCursorResponseModel<T>> GetDataByCursor<T>(string uri, IGetDataByCursorRequestModel request, string reportId, CancellationToken cancellationToken);
}

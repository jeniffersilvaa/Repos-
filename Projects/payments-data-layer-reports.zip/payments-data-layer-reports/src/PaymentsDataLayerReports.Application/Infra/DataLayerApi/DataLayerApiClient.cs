using System.Net;
using System.Text.Json;
using PaymentsDataLayerReports.Application.Infra.DataLayerApi.Models;
using Serilog;

namespace PaymentsDataLayerReports.Application.Infra.DataLayerApi;

public class DataLayerApiClient(
    IHttpClientFactory factory
) : IDataLayerApiClient
{
    private const string _clientName = "dataLayerApiClientClient";

    private readonly JsonSerializerOptions jsonDeserializerSnakeCase = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower
    };

    public async Task<GetChargesResponseModel> GetCharges(GetChargesRequestModel request, string reportId, CancellationToken cancellationToken)
    {
        var requestUri = $"charges";

        try
        {
            var queryParametersBuilder = request.ToQueryParameters();
            var requestUriWithParams = requestUri + queryParametersBuilder.Build();

            using HttpClient client = factory.CreateClient(_clientName);
            using var response = await client.GetAsync(requestUriWithParams, HttpCompletionOption.ResponseHeadersRead, cancellationToken);

            if (response.StatusCode != HttpStatusCode.OK)
            {
                var errorContent = await response.Content.ReadAsStringAsync(cancellationToken);
                throw new HttpRequestException($"Request to Data Layer API failed: {errorContent}", null, response.StatusCode);
            }

            await using var stream = await response.Content.ReadAsStreamAsync(cancellationToken);

            return await JsonSerializer.DeserializeAsync<GetChargesResponseModel>(stream, jsonDeserializerSnakeCase, cancellationToken)
                ?? throw new InvalidOperationException("Failed to deserialize response from Data Layer API");
        }
        catch (Exception ex)
        {
            Log.ForContext("Document", request.Document)
                .ForContext("StartDate", request.StartCreationDate)
                .ForContext("EndDate", request.EndCreationDate)
                .ForContext("ReportId", reportId)
                .Error($"[DataLayerApiClient.GetCharges] - Error: {ex.Message}");
            throw;
        }
    }

    public async Task<GetDataByCursorResponseModel<T>> GetDataByCursor<T>(string uri, IGetDataByCursorRequestModel request, string reportId, CancellationToken cancellationToken)
    {
        try
        {
            var queryParametersBuilder = request.ToQueryParameters();
            var requestUriWithParams = uri + queryParametersBuilder.Build();

            using HttpClient client = factory.CreateClient(_clientName);
            using var response = await client.GetAsync(requestUriWithParams, HttpCompletionOption.ResponseHeadersRead, cancellationToken);

            if (response.StatusCode != HttpStatusCode.OK)
            {
                var errorContent = await response.Content.ReadAsStringAsync(cancellationToken);
                throw new HttpRequestException($"Request to Data Layer API failed: {errorContent}", null, response.StatusCode);
            }

            await using var stream = await response.Content.ReadAsStreamAsync(cancellationToken);

            return await JsonSerializer.DeserializeAsync<GetDataByCursorResponseModel<T>>(stream, jsonDeserializerSnakeCase, cancellationToken)
                ?? throw new InvalidOperationException("Failed to deserialize response from Data Layer API");
        }
        catch (Exception ex)
        {
            Log.ForContext("Parameters", request)
                .ForContext("ReportId", reportId)
                .Error($"[DataLayerApiClient.GetDataByCursor] - Error: {ex.Message}");
            throw;
        }
    }

    public async Task<GetFinancialMovementsResponseModel> GetFinancialMovements(GetFinancialMovementsRequestModel request, string reportId, CancellationToken cancellationToken)
    {
        var requestUri = $"financial-movements";

        try
        {
            var queryParametersBuilder = request.ToQueryParameters();
            var requestUriWithParams = requestUri + queryParametersBuilder.Build();

            using HttpClient client = factory.CreateClient(_clientName);
            using var response = await client.GetAsync(requestUriWithParams, HttpCompletionOption.ResponseHeadersRead, cancellationToken);

            if (response.StatusCode != HttpStatusCode.OK)
            {
                var errorContent = await response.Content.ReadAsStringAsync(cancellationToken);
                throw new HttpRequestException($"Request to Data Layer API failed: {errorContent}", null, response.StatusCode);
            }

            await using var stream = await response.Content.ReadAsStreamAsync(cancellationToken);

            return await JsonSerializer.DeserializeAsync<GetFinancialMovementsResponseModel>(stream, jsonDeserializerSnakeCase, cancellationToken)
                ?? throw new InvalidOperationException("Failed to deserialize response from Data Layer API");
        }
        catch (Exception ex)
        {
            Log.ForContext("Document", request.Document)
                .ForContext("StartDate", request.StartDueDate)
                .ForContext("EndDate", request.EndDueDate)
                .ForContext("ReportId", reportId)
                .Error($"[DataLayerApiClient.GetFinancialMovements] - Error: {ex.Message}");
            throw;
        }
    }
}
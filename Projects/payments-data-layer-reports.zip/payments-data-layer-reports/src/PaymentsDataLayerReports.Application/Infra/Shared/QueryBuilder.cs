using System.Globalization;
using System.Text;

namespace PaymentsDataLayerReports.Application.Infra.Shared;

internal class QueryBuilder : IQueryBuilder
{
    private readonly StringBuilder _stringBuilder = new();

    public IQueryBuilder Add(string key, string? value)
    {
        if (string.IsNullOrEmpty(value))
        {
            return this;
        }

        var separator = GetSeparator();

        _stringBuilder.Append(separator);
        _stringBuilder.Append(key);
        _stringBuilder.Append('=');
        _stringBuilder.Append(Uri.EscapeDataString(value));
        return this;
    }

    public IQueryBuilder Add(string key, bool? value)
    {
        if (value == null)
        {
            return this;
        }

        var separator = GetSeparator();

        _stringBuilder.Append(separator);
        _stringBuilder.Append(key);
        _stringBuilder.Append('=');
        _stringBuilder.Append(Uri.EscapeDataString(value.ToString()));
        return this;
    }

    public IQueryBuilder Add(string key, long? value)
    {
        if (value == null)
        {
            return this;
        }

        var separator = GetSeparator();

        _stringBuilder.Append(separator);
        _stringBuilder.Append(key);
        _stringBuilder.Append('=');
        _stringBuilder.Append(Uri.EscapeDataString(value.ToString()));
        return this;
    }

    public IQueryBuilder Add<T>(string key, T? value) where T : class
    {
        if (value == null)
        {
            return this;
        }

        return Add(key, value.ToString());
    }

    public IQueryBuilder AddDateTime(string key, DateTime? value)
    {
        if (value == null)
        {
            return this;
        }

        return Add(key, value.Value.ToString("yyyy-MM-ddTHH:mm:ss.fffffff", CultureInfo.InvariantCulture));
    }

    public IQueryBuilder AddDateTime(string key, DateTimeOffset? value)
    {
        if (value == null)
        {
            return this;
        }

        return Add(key, value.Value.ToString("yyyy-MM-ddTHH:mm:ss.fffffffzzz", CultureInfo.InvariantCulture));
    }

    public IQueryBuilder AddDateOnly(string key, DateOnly? value)
    {
        if (value == null)
        {
            return this;
        }

        return Add(key, value.Value.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture));
    }

    public string Build() => _stringBuilder.ToString();

    private char GetSeparator() => _stringBuilder.Length == 0 ? '?' : '&';
}

public interface IQueryBuilder
{
    IQueryBuilder Add(string key, string? value);
    IQueryBuilder Add(string key, bool? value);
    IQueryBuilder Add(string key, long? value);
    IQueryBuilder Add<T>(string key, T? value) where T : class;
    IQueryBuilder AddDateOnly(string key, DateOnly? value);
    IQueryBuilder AddDateTime(string key, DateTime? value);
    IQueryBuilder AddDateTime(string key, DateTimeOffset? value);
    string Build();
}

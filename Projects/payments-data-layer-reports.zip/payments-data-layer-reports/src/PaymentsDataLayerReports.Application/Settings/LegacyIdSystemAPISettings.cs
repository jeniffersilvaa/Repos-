namespace PaymentsDataLayerReports.Application.Settings;

public class LegacyIdSystemAPISettings
{
    public const string LegacyIdSystemAPISection = "LegacyIdSystemApi";
    public string? LegacyIdSystemAPIUrl { get; set; }
}
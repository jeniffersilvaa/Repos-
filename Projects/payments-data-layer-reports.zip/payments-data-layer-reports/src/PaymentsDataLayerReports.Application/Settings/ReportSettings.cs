using PaymentsDataLayerReports.Application.Extensions;

namespace PaymentsDataLayerReports.Application.Settings;

public class ReportSettings
{
    public const string ReportSection = "ReportSettings";
    public SaleReportConfig SaleReport { get; set; } = new SaleReportConfig();
}

public class SaleReportConfig
{
    private const string DefaultAllowedCategories = "sale,reversal,partial_reversal,refund_reversal,antecipacao";

    public string AllowedFinancialMovementCategories { get; set; } = DefaultAllowedCategories;

    public List<string> GetAllowedFinancialMovementCategories() =>
        (AllowedFinancialMovementCategories ?? DefaultAllowedCategories)
            .SplitToList()
            .Select(c => c.Trim())
            .Where(c => c.Length > 0)
            .ToList();
}

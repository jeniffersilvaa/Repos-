namespace PaymentsDataLayerReports.Application.Settings;


public class AspNetCoreInstrumentationSettings
{
    public bool? RecordException { get; set; }
}

public class HangfireInstrumentationSettings
{
    public bool? RecordException { get; set; }
}

public class OtlpSettings
{
    public string? Endpoint { get; set; }
}

public class OpenTelemetrySettings
{
    public const string OpenTelemetrySection = "OpenTelemetry";
    public string? ServiceName { get; set; }
    public AspNetCoreInstrumentationSettings AspNetCoreInstrumentation { get; set; } = new();

    public HangfireInstrumentationSettings HangfireInstrumentation { get; set; } = new();
    public OtlpSettings Otlp { get; set; } = new();
}



namespace PaymentsDataLayerReports.Application.Settings;

public class HangfireSettings
{
    public const string HangfireSection = "Hangfire";
    public string? DashUsername { get; set; }
    public string? DashPassword { get; set; }
    public ServerSettings? Server { get; set; }
}


public class ServerSettings
{
    private static readonly int DefaultWorkerCount = Math.Min(Environment.ProcessorCount * 5, 20);
    public string Name { get; set; } = string.Empty;
    public string Queues { get; set; } = string.Empty;
    public int WorkerCount { get; set; } = DefaultWorkerCount;
}
﻿namespace PaymentsDataLayerReports.Application.Settings;

public class ElasticSearchSettings
{
    public const string ElasticSearchSection = "ElasticSearch";
    public const string Charges = "charges";
    public string? CloudId { get; set; }
    public string? User { get; set; }
    public string? Password { get; set; }
    public int DaysPerIndex { get; set; } = 10;

}

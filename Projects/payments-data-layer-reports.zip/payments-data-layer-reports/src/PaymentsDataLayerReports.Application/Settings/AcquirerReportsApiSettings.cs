namespace PaymentsDataLayerReports.Application.Settings;

public class AcquirerReportsApiSettings
{
    public const string AcquirerReportsApiSection = "AcquirerReportsApi";
    public string? Url { get; set; }
    public string? AuthToken { get; set; }
}
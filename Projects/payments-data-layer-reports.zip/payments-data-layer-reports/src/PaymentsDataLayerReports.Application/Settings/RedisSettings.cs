namespace PaymentsDataLayerReports.Application.Settings;

public class RedisSettings
{
    public const string RedisSettingsSection = "RedisSettings";
    public required string Url { get; set; }
}
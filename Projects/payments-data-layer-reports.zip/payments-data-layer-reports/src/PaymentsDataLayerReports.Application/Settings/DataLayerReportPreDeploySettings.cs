namespace PaymentsDataLayerReports.Application.Settings;

public class DataLayerReportPreDeploySettings
{
    public const string DataLayerReportPreDeploySection = "DataLayerReportPreDeploy";
    public bool? IsPreDeployWorker { get; set; }
    public string? EnabledReports { get; set; }
    public string? Url { get; set; }

    public bool IsReportEnabled(string reportType) =>
        EnabledReports?.Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries)
            .Any(r => r.Equals(reportType, StringComparison.OrdinalIgnoreCase)) == true;
}
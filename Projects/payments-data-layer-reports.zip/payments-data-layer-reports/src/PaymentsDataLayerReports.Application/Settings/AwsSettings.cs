namespace PaymentsDataLayerReports.Application.Settings;

public class AwsSettings
{
    public const string AwsSection = "AwsAuthentication";
    public string? AccessKey { get; set; }
    public string? SecretKey { get; set; }
    public string? SessionToken { get; set; }
    public string? Region { get; set; }
    public string? WarehouseBucket { get; set; }
    public string? WorkgroupBucket { get; set; }
}

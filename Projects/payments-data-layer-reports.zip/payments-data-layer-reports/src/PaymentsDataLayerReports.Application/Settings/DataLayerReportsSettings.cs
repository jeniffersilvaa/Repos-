namespace PaymentsDataLayerReports.Application.Settings;

public class DataLayerReportsSettings
{
    public const string DataLayerApiSection = "DataLayerReports";
    public string BashPath { get; set; } = "/bin/bash";
    public string MerchantsForShowCetFee { get; set; } = "all";
}
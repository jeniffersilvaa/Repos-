namespace PaymentsDataLayerReports.Application.Settings;

public class DataLayerApiSettings
{
    public const string DataLayerApiSection = "DataLayerApi";
    public string? DataLayerApiUrl { get; set; }
    public string? AuthToken { get; set; }
}
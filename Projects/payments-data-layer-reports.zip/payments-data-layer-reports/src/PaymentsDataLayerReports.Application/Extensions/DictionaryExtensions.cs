namespace PaymentsDataLayerReports.Application.Extensions;

using System.Text.Json;

public static class DictionaryExtensions
{
    public static object? SafeGetValue(this Dictionary<string, object> dict, string path)
    {
        if (dict is null || string.IsNullOrEmpty(path))
            return null;

        var keys = path.Split('.');
        object current = dict;

        foreach (var key in keys)
        {
            if (current is Dictionary<string, object> currentDict)
            {
                if (!currentDict.TryGetValue(key, out var value))
                    return null;
                current = value;
            }
            else if (current is JsonElement jsonElement)
            {
                if (!jsonElement.TryGetProperty(key, out var property))
                    return null;
                current = property;
            }
            else
            {
                return null;
            }

            if (current == null)
                return null;
        }

        return current;
    }
}
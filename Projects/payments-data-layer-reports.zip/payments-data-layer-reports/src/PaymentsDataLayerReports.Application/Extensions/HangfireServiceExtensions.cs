using System.Globalization;
using Hangfire;
using Hangfire.Redis.StackExchange;
using PaymentsDataLayerReports.Application.Constants;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Settings;
using StackExchange.Redis;

namespace PaymentsDataLayerReports.Application.Extensions;

public static class HangfireServiceExtensions
{
    private const string RETRY_COUNT_KEY = "RetryCount";
    private const string DEFAULT_PREFIX = "hangfire:DataLayerReports:";
    private const string PREDEPLOY_PREFIX = "hangfire:DataLayerReportsPreDeploy:";

    private static RedisStorageOptions GetRedisOptions(bool? isPreDeployWorker)
    {
        var prefix = isPreDeployWorker != true ? DEFAULT_PREFIX : PREDEPLOY_PREFIX;
        var redisOptions = new RedisStorageOptions
        {
            Db = RedisConstants.DB,
            Prefix = prefix,
            InvisibilityTimeout = TimeSpan.FromMinutes(30),
            SucceededListSize = 1000,
            DeletedListSize = 1000,
        };
        return redisOptions;
    }

    private static void AddHangfireServer(
        IServiceCollection services,
        IConfiguration configuration
    )
    {
        var hangfireSettings = configuration.GetSection(HangfireSettings.HangfireSection).Get<HangfireSettings>()
            ?? throw new Exception("HangfireSettings cannot be null");

        if (!string.IsNullOrEmpty(hangfireSettings.Server?.Name) && !string.IsNullOrEmpty(hangfireSettings.Server?.Queues))
        {
            services.AddHangfireServer(
                options =>
                {
                    options.ServerName = hangfireSettings.Server.Name;
                    options.Queues = [.. hangfireSettings.Server.Queues.SplitToList()];
                    options.WorkerCount = hangfireSettings.Server.WorkerCount;
                }
            );
        }
    }

    public static IServiceCollection AddHangfireConfig(this IServiceCollection services, IConfiguration configuration)
    {
        var redisUrl = configuration.GetValue<string>($"{RedisSettings.RedisSettingsSection}:Url");
        var isPreDeployWorker = configuration.GetValue<bool?>($"{DataLayerReportPreDeploySettings.DataLayerReportPreDeploySection}:IsPreDeployWorker");
        if (string.IsNullOrEmpty(redisUrl))
        {
            throw new Exception("Redis URL cannot be null");
        }

        // Add Hangfire Client
        services.AddHangfire(config => config
            .SetDataCompatibilityLevel(CompatibilityLevel.Version_180)
            .UseDefaultCulture(CultureInfo.InvariantCulture)
            .UseSimpleAssemblyNameTypeSerializer()
            .UseRecommendedSerializerSettings()
            .UseRedisStorage(
                connectionMultiplexer: ConnectionMultiplexer.Connect(redisUrl),
                options: GetRedisOptions(isPreDeployWorker)
            )
        );

        // Add Hangfire Server
        AddHangfireServer(services, configuration);
        return services;
    }

    public static string? GetStateById(this JobStorage jobStorage, string jobId)
    {
        var job = jobStorage.GetMonitoringApi().JobDetails(jobId);

        if (job == null)
        {
            return null;
        }

        var currentState = job!.History[0].StateName;
        var hasRetryProperty = job.Properties.ContainsKey(RETRY_COUNT_KEY);

        // Returns processing if the job is in retry
        if (hasRetryProperty && currentState != WorkerStatesEnum.Deleted.ToString() && currentState != WorkerStatesEnum.Succeeded.ToString())
        {
            currentState = WorkerStatesEnum.Processing.ToString();
        }

        // Returns failed if the job failed all retries and was deleted
        if (hasRetryProperty && currentState == WorkerStatesEnum.Deleted.ToString())
        {
            currentState = WorkerStatesEnum.Failed.ToString();
        }

        // Returns current state otherwise
        return currentState;
    }

}

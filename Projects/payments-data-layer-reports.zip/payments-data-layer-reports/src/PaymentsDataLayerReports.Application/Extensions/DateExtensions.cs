namespace PaymentsDataLayerReports.Application.Extensions;

public enum TimeOfDay
{
    StartOfDay,
    EndOfDay
}

public static class DateExtensions
{
    public static string GetFormattedReferenceDate(this DateTime dateTime, string groupBy)
    {
        switch (groupBy)
        {
            case "day":
                return dateTime.ToString("yyyy-MM-dd");
            case "month":
                return dateTime.ToString("yyyy-MM");
            case "year":
                return dateTime.ToString("yyyy");
            default:
                throw new ArgumentException("Filter 'GroupBy' invalid.");
        }
    }

    public static int? DaysInterval(this DateTime? startDate, DateTime? endDate)
    {
        if (startDate != null && endDate != null)
        {
            return (endDate - startDate).Value.Days;
        }

        return null;
    }

    public static int? DaysInterval(this DateTimeOffset? startDate, DateTimeOffset? endDate)
    {
        if (startDate != null && endDate != null)
        {
            return (endDate - startDate).Value.Days;
        }

        return null;
    }

    public static DateTimeOffset ToDateTimeOffset(this DateTime dateTime, TimeOfDay timeOfDay, string timeZone)
    {
        var dateTimeWithTime = timeOfDay switch
        {
            TimeOfDay.StartOfDay => dateTime.Date,
            TimeOfDay.EndOfDay => dateTime.Date.AddDays(1).AddTicks(-1),
            _ => throw new ArgumentOutOfRangeException($"Invalid TimeOfDay: {timeOfDay}"),
        };

        var timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById(timeZone);
        DateTimeOffset dateTimeOffset = new(dateTimeWithTime, timeZoneInfo.GetUtcOffset(dateTimeWithTime));

        return dateTimeOffset;
    }

    public static DateTime ToBrazilianTimeZone(this DateTime dateTime)
    {
        var brazilTimeZone = TimeZoneInfo.FindSystemTimeZoneById("E. South America Standard Time");
        return TimeZoneInfo.ConvertTimeFromUtc(dateTime.ToUniversalTime(), brazilTimeZone);
    }
}

using Hangfire;
using OpenTelemetry.Exporter;
using OpenTelemetry.Metrics;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;
using PaymentsDataLayerReports.Application.Metrics;
using PaymentsDataLayerReports.Application.Settings;

namespace PaymentsDataLayerReports.Application.Extensions;


public static class OpenTelemetryExtensions
{

    public static WebApplicationBuilder ConfigureOpenTelemetry(this WebApplicationBuilder builder)
    {
        builder.Services.Configure<OpenTelemetrySettings>(builder.Configuration.GetSection(OpenTelemetrySettings.OpenTelemetrySection));
        var openTelemetrySettings = builder.Configuration.GetSection(OpenTelemetrySettings.OpenTelemetrySection).Get<OpenTelemetrySettings>();

        builder.Services.AddSingleton(_ => JobStorage.Current.GetMonitoringApi());
        builder.Services.AddSingleton<HangfireMetrics>();

        builder.Services.AddOpenTelemetry()
              .ConfigureResource(resource =>
              resource.AddService(
              serviceName: openTelemetrySettings!.ServiceName!,
              autoGenerateServiceInstanceId: false,
              serviceInstanceId: Environment.MachineName))
              .WithTracing(tracing => tracing
              .AddAspNetCoreInstrumentation(options =>
                    {
                        options.RecordException = openTelemetrySettings!.AspNetCoreInstrumentation.RecordException! ?? true;
                    })
              .AddHangfireInstrumentation(options =>
              {
                  options.RecordException = openTelemetrySettings!.HangfireInstrumentation.RecordException! ?? true;
              })
              .SetErrorStatusOnException(enabled: true)
              .AddOtlpExporter(otlpOptions =>
                {
                    otlpOptions.Endpoint = new Uri(openTelemetrySettings!.Otlp.Endpoint!);
                    otlpOptions.Protocol = OtlpExportProtocol.Grpc;
                })
                )
              .WithMetrics(metrics =>
              {
                  metrics
                      .AddMeter(HangfireMetrics.MeterName)
                      .AddMeter(ReportingTimeMetrics.MeterName)
                      .AddAspNetCoreInstrumentation()
                      .AddRuntimeInstrumentation()
                      .AddProcessInstrumentation()
                      .AddOtlpExporter(otlpOptions =>
                      {
                          otlpOptions.Endpoint = new Uri(openTelemetrySettings!.Otlp.Endpoint!);
                          otlpOptions.Protocol = OtlpExportProtocol.Grpc;
                      });
              });
        return builder;
    }
}
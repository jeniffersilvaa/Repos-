using System.Text.Json;

namespace PaymentsDataLayerReports.Application.Extensions;

public static class StringExtensions
{
    public static bool HasValue(this string? text)
    {
        return !string.IsNullOrEmpty(text);
    }

    public static List<string> SplitToList(this string text)
    {
        return text.Replace(" ", "").Split(',').ToList();
    }

    public static string ToSnakeCase(this string text)
    {
        if (text == null)
        {
            throw new ArgumentNullException(paramName: nameof(text));
        }

        return JsonNamingPolicy.SnakeCaseLower.ConvertName(text);
    }
}

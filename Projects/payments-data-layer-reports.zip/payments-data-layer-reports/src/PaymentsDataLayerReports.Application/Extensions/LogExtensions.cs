using Microsoft.AspNetCore.HttpLogging;
using Serilog;
using Serilog.Formatting.Json;

namespace PaymentsDataLayerReports.Application.Extensions;

public static class LogExtensions
{
    public static WebApplicationBuilder AddLogger(this WebApplicationBuilder builder)
    {
        builder.Services.AddHttpLogging(logging =>
        {
            logging.LoggingFields = HttpLoggingFields.ResponsePropertiesAndHeaders;
            logging.MediaTypeOptions.AddText("application/json");
            logging.ResponseHeaders.Add("Protocol");
            logging.ResponseHeaders.Add("Method");
            logging.ResponseHeaders.Add("Scheme");
            logging.ResponseHeaders.Add("PathBase");
            logging.ResponseHeaders.Add("Path");
            logging.ResponseHeaders.Add("QueryString");
            logging.ResponseHeaders.Add("Accept");
            logging.ResponseHeaders.Add("Host");
            logging.ResponseHeaders.Add("UserAgent");
            logging.ResponseHeaders.Add("RequestId");
        });

        builder.Logging.ClearProviders();

        var contextsToExclude = new List<string>
        {
            "Microsoft.AspNetCore.Hosting.Diagnostics",
            "Microsoft.AspNetCore.Routing.EndpointMiddleware",
            "Microsoft.AspNetCore.Http.Result.",
            "Microsoft.AspNetCore.Http.HttpResults.ProblemHttpResult",
            "Microsoft.Hosting.Lifetime",
            "Microsoft.AspNetCore.Server.Kestrel.Connections",
            "Microsoft.AspNetCore.HostFiltering.HostFilteringMiddleware",
            "Microsoft.AspNetCore.Routing.Matching.DfaMatcher",
            "Microsoft.AspNetCore.StaticFiles.StaticFileMiddleware",
            "Microsoft.AspNetCore.Routing.EndpointRoutingMiddleware",
            "Microsoft.AspNetCore.Diagnostics.ExceptionHandlerMiddleware"
        };

        var pathsToExclude = new List<string>
        {
            "/swagger",
            "/hangfire"
        };

        var config = new ConfigurationBuilder()
            .AddEnvironmentVariables()
            .Build();

        Log.Logger = new LoggerConfiguration()
            .MinimumLevel.Debug()
            .ReadFrom.Configuration(config)
            .WriteTo.Console(new JsonFormatter())
            .Enrich.FromLogContext()
            .Filter.ByExcluding(evt =>
                contextsToExclude.Any(context =>
                    evt.Properties.TryGetValue("SourceContext", out var sourceContextObj) &&
                    sourceContextObj.ToString().Contains(context)
                ) || pathsToExclude.Any(path =>
                    evt.Properties.TryGetValue("RequestPath", out var requestPathObj) &&
                    requestPathObj.ToString().Contains(path)
                )
            ).CreateLogger();

        builder.Logging.AddSerilog(Log.Logger);

        return builder;
    }
}

namespace PaymentsDataLayerReports.Application.Extensions;

public static class EnumerableExtensions
{
    public static string ToCommaSeparatedString(this IEnumerable<string>? values)
    {
        return values != null ? string.Join(",", values) : string.Empty;
    }
}
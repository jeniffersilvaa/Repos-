using Amazon.S3;
using Amazon.S3.Model;
using Amazon.S3.Transfer;
using Datadog.Trace;
using PaymentsDataLayerReports.Application.Constants;
using PaymentsDataLayerReports.Application.Exceptions;
using Serilog;

namespace PaymentsDataLayerReports.Application.Extensions
{
    public static class AmazonS3ClientExtensions
    {
        private static readonly int MAX_CONCURRENT_DOWNLOADS = 10;

        public static async Task<long> DownloadAsync(this IAmazonS3 s3Client, string bucketName, string bucketPath, string localDirectory)
        {
            return await s3Client.DownloadAsync(bucketName, [bucketPath], localDirectory);
        }

        public static async Task<long> DownloadAsync(this IAmazonS3 s3Client, string bucketName, List<string> bucketPaths, string localDirectory)
        {
            using var scope = Tracer.Instance.StartActive("AmazonS3ClientExtensions.DownloadAsync");
            Log.Debug("[AmazonS3ClientExtensions.DownloadAsync] Starting");

            var transferUtil = new TransferUtility(s3Client);
            var totalFilesDownloaded = 0;
            var totalFileSize = 0L;
            var downloadTasks = new List<Task>();
            var semaphore = new SemaphoreSlim(MAX_CONCURRENT_DOWNLOADS);

            // Ensure the local directory exists
            Directory.CreateDirectory(localDirectory);

            foreach (var path in bucketPaths)
            {
                var listRequest = new Amazon.S3.Model.ListObjectsV2Request
                {
                    BucketName = bucketName,
                    Prefix = path
                };

                Amazon.S3.Model.ListObjectsV2Response listResponse;
                do
                {
                    listResponse = await s3Client.ListObjectsV2Async(listRequest);

                    // Calculate total file size for this batch
                    var batchSize = listResponse.S3Objects.Sum(obj => obj.Size);
                    Interlocked.Add(ref totalFileSize, batchSize);

                    Log.ForContext("Count", listResponse.S3Objects.Count)
                        .ForContext("Path", path)
                        .ForContext("Bucket", bucketName)
                        .ForContext("BatchSizeMB", (batchSize / ByteSizeConstants.MB).ToString("F2"))
                        .Debug("[AmazonS3ClientExtensions.DownloadAsync] Objects found in path");

                    // Download each file
                    foreach (var s3Object in listResponse.S3Objects)
                    {
                        if (s3Object.Size == 0) continue;

                        var localPath = Path.Combine(localDirectory, Path.GetFileName(s3Object.Key));

                        var downloadTask = Task.Run(async () =>
                        {
                            await semaphore.WaitAsync();
                            try
                            {
                                await transferUtil.DownloadAsync(localPath, bucketName, s3Object.Key);
                                Interlocked.Increment(ref totalFilesDownloaded);
                            }
                            finally
                            {
                                semaphore.Release();
                            }
                        });

                        downloadTasks.Add(downloadTask);
                    }

                    // Set the marker for the next page
                    listRequest.ContinuationToken = listResponse.NextContinuationToken;

                } while (listResponse.IsTruncated);
            }

            await Task.WhenAll(downloadTasks);

            // Add file size to trace
            scope.Span.SetTag("AmazonS3ClientExtensions.DownloadAsync.total_file_size_bytes", totalFileSize.ToString());
            scope.Span.SetTag("AmazonS3ClientExtensions.DownloadAsync.total_file_size_mb", (totalFileSize / ByteSizeConstants.MB).ToString("F2"));

            Log.ForContext("TotalFilesDownloaded", totalFilesDownloaded)
                .ForContext("TotalFileSizeBytes", totalFileSize)
                .ForContext("TotalFileSizeMB", (totalFileSize / ByteSizeConstants.MB).ToString("F2"))
                .Debug("[AmazonS3ClientExtensions.DownloadAsync] Completed");

            return totalFileSize;
        }

        public static async Task WriteStringAsync(this IAmazonS3 s3Client, string bucketName, string bucketPath, string content, string contentType = "text/plain")
        {
            Log.Debug("[AmazonS3ClientExtensions.WriteStringAsync] Starting");

            try
            {
                var request = new PutObjectRequest
                {
                    BucketName = bucketName,
                    Key = bucketPath,
                    ContentBody = content,
                    ContentType = contentType
                };
                await s3Client.PutObjectAsync(request);

                Log.ForContext("Bucket", bucketName)
                    .ForContext("Path", bucketPath)
                    .Debug("[AmazonS3ClientExtensions.WriteStringAsync] Successfully wrote string to S3");
            }
            catch (AmazonS3Exception ex)
            {
                Log.ForContext("Exception", ex)
                    .ForContext("Bucket", bucketName)
                    .ForContext("Path", bucketPath)
                    .Error("[AmazonS3ClientExtensions.WriteStringAsync] S3 error writing file");
                throw;
            }
            catch (Exception ex)
            {
                Log.ForContext("Exception", ex)
                    .ForContext("Bucket", bucketName)
                    .ForContext("Path", bucketPath)
                    .Error("[AmazonS3ClientExtensions.WriteStringAsync] Unexpected error writing file");
                throw;
            }
        }

        public static async Task<string> ReadStringAsync(this IAmazonS3 s3Client, string bucketName, string key)
        {
            Log.Debug("[AmazonS3ClientExtensions.ReadStringAsync] Starting");

            try
            {
                var request = new GetObjectRequest
                {
                    BucketName = bucketName,
                    Key = key
                };

                using var response = await s3Client.GetObjectAsync(request);
                using var reader = new StreamReader(response.ResponseStream);
                var content = await reader.ReadToEndAsync();

                Log.ForContext("Path", key)
                    .ForContext("Bucket", bucketName)
                    .Debug("[AmazonS3ClientExtensions.ReadStringAsync] Read completed");

                return content;
            }
            catch (AmazonS3Exception ex) when (ex.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
                Log.ForContext("Path", key)
                    .ForContext("Bucket", bucketName)
                    .Error("[AmazonS3ClientExtensions.ReadStringAsync] File not found");
                throw new S3FileNotFoundException(bucketName, key);
            }
            catch (Exception ex)
            {
                Log.ForContext("Exception", ex)
                    .ForContext("Path", key)
                    .ForContext("Bucket", bucketName)
                    .Error("[AmazonS3ClientExtensions.ReadStringAsync] Error reading file");
                throw;
            }
        }

    }
}
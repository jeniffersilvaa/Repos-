using System.Text.Json;

namespace PaymentsDataLayerReports.Application.Extensions;

public static class ObjectExtensions
{
    public static object? DeepCopy(this object? value)
    {
        if (value == null)
            return null;

        Type type = value.GetType();

        if (value is ICloneable cloneable)
            return cloneable.Clone();

        if (type.IsValueType || value is string)
            return value;

        // JsonSerializer fallback
        var serialized = JsonSerializer.Serialize(value);
        return JsonSerializer.Deserialize(serialized, type);
    }
}

namespace PaymentsDataLayerReports.Application.Versioning;

public sealed class AppVersion1320 { }

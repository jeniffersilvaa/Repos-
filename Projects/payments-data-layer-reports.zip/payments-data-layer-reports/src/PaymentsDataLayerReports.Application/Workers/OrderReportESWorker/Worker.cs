using Datadog.Trace.Annotations;
using Hangfire;
using Hangfire.Server;
using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Infra.DataLayerApi;
using PaymentsDataLayerReports.Application.Infra.DataLayerApi.Models;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService;
using PaymentsDataLayerReports.Application.Workers.NotificationWorkerV2;
using PaymentsDataLayerReports.Application.Workers.Shared;
using Serilog;
using NotificationParameters = PaymentsDataLayerReports.Application.Workers.NotificationWorkerV2.NotificationParameters;

namespace PaymentsDataLayerReports.Application.Workers.OrderReportESWorker;

public interface IOrderReportESWorker
{
    Task ProcessReport(OrderReportWorkerParameters parameters, PerformContext context, CancellationToken cancellationToken);
}

public class OrderReportESWorker(
    IDataLayerApiClient dataLayerApiClient,
    IReportStreamWriterFactory reportStreamWriterFactory,
    IBackgroundJobClient backgroundJobClient) : IOrderReportESWorker
{
    private const int DALAPI_BATCH_SIZE = 1000;

    [Trace]
    [AutomaticRetry(OnAttemptsExceeded = AttemptsExceededAction.Delete)]
    public async Task ProcessReport(OrderReportWorkerParameters parameters, PerformContext context, CancellationToken cancellationToken)
    {
        var jobId = context.BackgroundJob.Id;
        var reportId = string.IsNullOrWhiteSpace(parameters.ReportId) ? jobId : parameters.ReportId;

        Log.ForContext("Parameters", parameters)
           .ForContext("ReportId", reportId)
           .Information($"[OrderReportESWorker.ProcessReport] - Processing report.");

        await ProcessAndUploadReport(parameters, reportId, cancellationToken);

        SendNotification(jobId, reportId, parameters);
    }

    private async Task ProcessAndUploadReport(OrderReportWorkerParameters parameters, string reportId, CancellationToken cancellationToken)
    {
        await using var writer = reportStreamWriterFactory.Create<string>(parameters.FileFormat);

        try
        {
            await writer.InitializeAsync(reportId, cancellationToken);
            await writer.WriteHeaderAsync(OrderCsvMapper.GetHeader(), cancellationToken);

            var dalapiParameters = parameters.ToGetOrdersRequestModel(DALAPI_BATCH_SIZE, null);

            string? cursor = null;

            do
            {
                dalapiParameters.Cursor = cursor;

                var result = await dataLayerApiClient.GetDataByCursor<Order>(
                    ReportTypeEnum.Orders.Name,
                    dalapiParameters,
                    reportId,
                    cancellationToken
                );

                foreach (var order in result.Data)
                {
                    var row = OrderCsvMapper.BuildRow(order);
                    await writer.WriteRecordAsync(row, cancellationToken);
                }

                cursor = result.Cursor;
            } while (cursor != null);

            await writer.CompleteAsync(cancellationToken);
        }
        catch (Exception ex)
        {
            Log.ForContext("Parameters", parameters)
               .ForContext("ReportId", reportId)
               .Error(ex, "[OrderReportESWorker.ProcessAndUploadReport] - Error processing report. Aborting upload.");

            await writer.AbortAsync(cancellationToken);
            throw;
        }
    }

    public void SendNotification(
        string jobId,
        string reportId,
        OrderReportWorkerParameters parameters
    )
    {
        if (parameters.Notification is null)
            return;

        var metadata = new Dictionary<string, object>
        {
            {"start_date", parameters.StartDueDate.ToString("yyyy-MM-dd") ?? ""},
            {"end_date", parameters.EndDueDate.ToString("yyyy-MM-dd") ?? ""},
            {"report_type", ReportTypeEnum.Orders.Name },
            {"document",string.IsNullOrWhiteSpace(parameters.Documents) ? "test":parameters.Documents }, //DEVE SER REMOVIDO O "test" QUANDO FOR PARA PRODUÇÃO
            {"organizations", "stone" },
        };

        NotificationChannel channel = new();

        if (parameters.Notification.Email != null)
        {
            metadata.Add("email", parameters.Notification.Email.Address);

            channel.Email = new EmailChannel
            {
                Address = parameters.Notification.Email.Address
            };
        }

        if (parameters.Notification.Webhook != null)
        {
            channel.Webhook = new WebhookChannel
            {
                Url = parameters.Notification.Webhook.Url,
                Headers = parameters.Notification.Webhook.Headers
            };
        }

        if (channel.Email != null || channel.Webhook != null)
        {
            var downloadFileName = DownloadFileNameBuilder.BuildOrderFileName(
                parameters.StartDueDate.ToString("yyyyMMdd"),
                parameters.EndDueDate.ToString("yyyyMMdd"),
                reportId,
                parameters.FileFormat
            );

            backgroundJobClient.ContinueJobWith<NotificationWorkerV2.NotificationWorkerV2>(
                parentId: jobId,
                queue: QueuesEnum.Notifications.Name,
                options: JobContinuationOptions.OnlyOnSucceededState,
                methodCall: job => job.SendNotificationAsync(
                    new NotificationParameters
                    {
                        Status = WorkerStatesEnum.Succeeded.ToString(),
                        ReportId = reportId,
                        ReportType = ReportTypeEnum.Orders.Name,
                        FileFormat = parameters.FileFormat,
                        DownloadFileName = downloadFileName,
                        Metadata = metadata,
                        Channel = channel
                    },
                    null!,
                    CancellationToken.None
                )
            );
        }
    }
}
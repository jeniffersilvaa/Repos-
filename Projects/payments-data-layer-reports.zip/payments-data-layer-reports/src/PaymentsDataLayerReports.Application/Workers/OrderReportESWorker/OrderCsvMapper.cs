using System.Globalization;
using PaymentsDataLayerReports.Application.Constants;
using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Extensions;
using PaymentsDataLayerReports.Application.Workers.Shared;

namespace PaymentsDataLayerReports.Application.Workers.OrderReportESWorker;


class OrderCsvMapper
{
    private static readonly string Header;
    private static readonly CsvSeparatorEnum Separator = CsvSeparatorEnum.Semicolon;
    static OrderCsvMapper()
    {
        Header = BuildHeader();
    }

    private static string BuildHeader()
    {
        List<string> headerList =
        [
            "ID DO PEDIDO",
            "CÓDIGO DO PEDIDO",
            "STATUS",
            "VALOR",
            "DATA DE CRIAÇÃO",
            "DATA DE ATUALIZAÇÃO",
            "DATA DE FECHAMENTO",
            "ID DO CLIENTE",
            "NOME DO CLIENTE",
            "EMAIL DO CLIENTE",
            "TIPO DE CLIENTE",
            "DOCUMENTO DO CLIENTE",
            "ENDEREÇO DO CLIENTE",
            "BAIRRO DO CLIENTE",
            "NÚMERO DO ENDEREÇO DO CLIENTE",
            "CIDADE DO CLIENTE",
            "ESTADO DO CLIENTE",
            "PAIS DO CLIENTE",
            "CEP DO CLIENTE",
            "ID DO ENDEREÇO DO CLIENTE",
            "TELEFONE DO CLIENTE",
            "CELULAR DO CLIENTE",
            "VALOR DA ENTREGA",
            "DESCRIÇÃO DA ENTREGA",
            "DESTINATÁRIO DA ENTREGA",
            "TELEFONE DO DESTINATÁRIO",
            "ENDEREÇO DA ENTREGA",
            "BAIRRO DA ENTREGA",
            "NÚMERO DO ENDEREÇO DA ENTREGA",
            "CIDADE DA ENTREGA",
            "ESTADO DA ENTREGA",
            "PAÍS DA ENTREGA",
            "CEP DA ENTREGA",
            "DISPOSITIVO",
            "METADADO",
            "QUANTIDADE DE CHECKOUT",
            "IDS DAS COBRANÇA",
            "QUANTIDADE DE COBRANÇA"
        ];

        var headerBuilder = new CsvRowBuilder(Separator);
        foreach (var header in headerList)
        {
            headerBuilder.Add(header);
        }

        return headerBuilder.Build();
    }

    public static string GetHeader()
    {
        return Header;
    }

    private static string StatusModifier(string status)
    {
        var lowerCaseStatus = status.ToLower();

        var map = new Dictionary<string, string>
                {
                    { "paid", "Pago" },
                    { "failed", "Falha" },
                    { "pending", "Pendente" },
                    { "canceled", "Cancelado" },
                };

        return map.GetValueOrDefault(lowerCaseStatus, string.Empty);
    }

    private static string AmountModifier(int? amount)
    {
        if (!amount.HasValue) return string.Empty;

        return (amount.Value / 100.0).ToString("F2", CultureInfo.CreateSpecificCulture("pt-BR"));
    }


    private static string CustomerTypeModifier(string? customerType)
    {

        if (customerType == null) return string.Empty;

        var lowerCaseStatus = customerType.ToLower();

        var map = new Dictionary<string, string>
                {
                    { "individual", "Individual" },
                    { "company", "Company" }
                };

        return map.GetValueOrDefault(lowerCaseStatus, string.Empty);
    }

    public static string BuildRow(Order order)
    {
        const string dateFormat = "yyyy-MM-dd HH:mm:ss";

        var builder = new CsvRowBuilder(Separator)
              .Add(order.Id)
              .Add(order.Code)
              .Add(StatusModifier(order.Status))
              .Add(AmountModifier(order.Amount))
              .AddDateTimeOffset(order?.CreatedAt.ToBrazilianTimeZone(), dateFormat)
              .AddDateTimeOffset(order?.UpdatedAt.ToBrazilianTimeZone(), dateFormat)
              .AddDateTimeOffset(order?.ClosedAt?.ToBrazilianTimeZone(), dateFormat)
              .Add(order?.Customer?.Id)
              .Add(order?.Customer?.Name)
              .Add(order?.Customer?.Email)
              .Add(CustomerTypeModifier(order?.Customer?.Type))
              .Add(order?.Customer?.Document)
              .Add(order?.Customer?.Address?.Street)
              .Add(order?.Customer?.Address?.Neighborhood)
              .Add(order?.Customer?.Address?.Number)
              .Add(order?.Customer?.Address?.City)
              .Add(order?.Customer?.Address?.State)
              .Add(order?.Customer?.Address?.Country)
              .Add(order?.Customer?.Address?.ZipCode)
              .Add(order?.Customer?.Address?.Id)
              .Add(order?.Customer?.Phones.GetHomePhoneString())
              .Add(order?.Customer?.Phones.GetMobilePhoneString())
              .Add(AmountModifier(order?.Shipping?.Amount))
              .Add(order?.Shipping?.Description)
              .Add(order?.Shipping?.RecipientName)
              .Add(order?.Shipping?.RecipientPhone)
              .Add(order?.Shipping?.Address?.Street)
              .Add(order?.Shipping?.Address?.Neighborhood)
              .Add(order?.Shipping?.Address?.Number)
              .Add(order?.Shipping?.Address?.City)
              .Add(order?.Shipping?.Address?.State)
              .Add(order?.Shipping?.Address?.Country)
              .Add(order?.Shipping?.Address?.ZipCode)
              .Add(order?.Device?.Platform)
              .AddSerializableObject(order?.Metadata)
              .Add(order?.CheckoutsCount.ToString())
              .Add(string.Join(",", order?.Charges.Select(charge => charge.Id) ?? []))
              .Add(order?.Charges.Length.ToString());

        return builder.Build();
    }
}
using PaymentsDataLayerReports.Application.Infra.DataLayerApi.Models;
using PaymentsDataLayerReports.Application.Routes.Reports.PostReports.Models;

namespace PaymentsDataLayerReports.Application.Workers.OrderReportESWorker;

public record OrderReportWorkerParameters
{
    public bool? IsTestAccount { get; set; }
    public DateTimeOffset StartDueDate { get; set; }
    public DateTimeOffset EndDueDate { get; set; }
    public string? Status { get; set; }
    public string? MerchantId { get; set; }
    public string? Documents { get; set; }
    public string? StoneAccounts { get; set; }
    public string? PaymentProfiles { get; set; }
    public string? PoiTypes { get; set; }
    public required string FileFormat { get; set; }
    public Notification? Notification { get; set; } = null;
    public string? ReportId { get; set; } = null;

    public GetOrderByCursorRequestModel ToGetOrdersRequestModel(int? size, string? cursor = null)
    {
        return new GetOrderByCursorRequestModel
        {
            Size = size,
            Cursor = cursor,
            FilterParameters = new Dictionary<string, string>
            {
                { "is_test_account", IsTestAccount?.ToString() ?? string.Empty },
                { "start_date", StartDueDate.ToString("o") },
                { "end_date", EndDueDate.ToString("o") },
                { "settlement_status", Status ?? string.Empty },
                { "merchant_id", MerchantId ?? string.Empty },
                { "documents", Documents ?? string.Empty },
                { "stone_accounts", StoneAccounts ?? string.Empty },
                { "payment_profile_ids", PaymentProfiles ?? string.Empty },
                { "point_of_interaction_types", PoiTypes ?? string.Empty }
            }
        };
    }
}
using PaymentsDataLayerReports.Application.Workers.ChargeReportWorker;
using PaymentsDataLayerReports.Application.Workers.FinMovReportESWorker;
using PaymentsDataLayerReports.Application.Workers.NotificationWorkerV2;

namespace PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;

public record ReportMetadata
{
    public required string? Status { get; set; }
    public required string ReportId { get; set; }
    public required string DispatchId { get; set; }
    public required DateTime CreatedAt { get; set; }
    public required int ReportSortColumnIndex { get; set; }
    public required string ProcessorQueueName { get; set; }
    public required string FileFormat { get; set; }
    public ChargeReportsWorkerParameters? ChargeReportParameters { get; set; }
    public FinMovESWorkerParameters? FinMovReportParameters { get; set; }
    public NotificationParameters? NotificationParameters { get; set; } = null;


    public IEnumerable<DateTime> GetDateRangeDescending()
    {
        var dates = new List<DateTime>();

        DateTime startDate;
        DateTime endDate;

        if (ChargeReportParameters != null)
        {
            startDate = ChargeReportParameters.StartDate.Date;
            endDate = ChargeReportParameters.EndDate.Date;
        }
        else if (FinMovReportParameters != null)
        {
            startDate = FinMovReportParameters.StartDate.ToDateTime(TimeOnly.MinValue);
            endDate = FinMovReportParameters.EndDate.ToDateTime(TimeOnly.MinValue);
        }
        else
        {
            throw new InvalidOperationException("ChargeReportParameters and FinMovReportParameters are not defined.");
        }

        for (var date = startDate; date <= endDate; date = date.AddDays(1))
        {
            dates.Add(date);
        }
        return dates.OrderByDescending(d => d);
    }
}
using Datadog.Trace;
using Hangfire;
using Hangfire.Server;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Services.DeltaTablePartitionBuilder;
using PaymentsDataLayerReports.Application.Services.IdempotentJobManager;
using PaymentsDataLayerReports.Application.Services.ReportTypeConfiguration;
using PaymentsDataLayerReports.Application.Versioning;
using PaymentsDataLayerReports.Application.Workers.ChargeReportWorker;
using PaymentsDataLayerReports.Application.Workers.FinMovReportESWorker;
using Serilog;

namespace PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;

public class ChargeReportS3DispatchWorker(
    IS3ClientWrapper s3ClientWrapper,
    IIdempotentJobManager idempotentJobManager
)
{

    private static IEnumerable<DateTime> GenerateDates(DateTime startDate, DateTime endDate)
    {
        var start = startDate.Date;
        var end = endDate.Date;
        for (var date = start; date <= end; date = date.AddDays(1))
        {
            yield return date;
        }
    }

    private static int CalculateTotalJobs(
        DateTime start,
        DateTime end,
        int partitionsCount
    )
    {
        var startDate = start.Date;
        var endDate = end.Date;
        var datesCount = endDate >= startDate ? (endDate - startDate).Days + 1 : 0;
        return datesCount * partitionsCount;
    }


    [AutomaticRetry(Attempts = 100, OnAttemptsExceeded = AttemptsExceededAction.Delete)]
    public async Task DispatchReport(
        string? reportId,
        string processorQueueName,
        ChargeReportsWorkerParameters? chargeParameters,
        FinMovESWorkerParameters? finMovParameters,
        DateTime startedAt,
        PerformContext context,
        CancellationToken cancellationToken,
        AppVersion1320 version
    )
    {

        using var scope = Tracer.Instance.StartActive("ChargeReportS3DispatchWorker.DispatchReport");

        var dispatchId = context.BackgroundJob.Id;
        reportId ??= $"{dispatchId}-s3";

        Log.ForContext("ChargeParameters", chargeParameters)
            .ForContext("FinMovParameters", finMovParameters)
            .ForContext("JobId", dispatchId)
            .ForContext("ReportId", reportId)
            .Information("[ChargeReportS3DispatchWorker.DispatchReport] Starting");

        try
        {

            if (chargeParameters == null && finMovParameters == null)
            {
                throw new InvalidOperationException("At least one report type must be specified");
            }

            var reportType = chargeParameters?.ReportType ?? finMovParameters?.ReportType ?? throw new InvalidOperationException("Report type not found");
            DateTime startDate = chargeParameters?.StartDate.DateTime ?? finMovParameters?.StartDate.ToDateTime(TimeOnly.MinValue) ?? throw new InvalidOperationException("StartDate not found");
            DateTime endDate = chargeParameters?.EndDate.DateTime ?? finMovParameters?.EndDate.ToDateTime(TimeOnly.MaxValue) ?? throw new InvalidOperationException("EndDate not found");

            var document = chargeParameters?.Document ?? finMovParameters?.Document ?? null;
            var merchantId = chargeParameters?.MerchantId ?? finMovParameters?.MerchantId ?? null;
            _ = document ?? merchantId ?? throw new InvalidOperationException("Document or MerchantId not found");

            await UploadReportMetadataAsync(reportId, dispatchId, processorQueueName, startedAt, chargeParameters, finMovParameters);

            var tablePartitionsSet = DeltaTablePartitionBuilder.BuildPartitionSets(
                reportType, document, merchantId
            ).ToList();

            var totalJobs = CalculateTotalJobs(startDate, endDate, tablePartitionsSet.Count);

            if (totalJobs == 0)
            {
                Log.ForContext("JobId", dispatchId)
                    .ForContext("ReportId", reportId)
                    .Warning("[ChargeReportS3DispatchWorker.DispatchReport] No jobs to dispatch.");
                return;
            }

            await idempotentJobManager.SetTotalJobsAsync(reportId, totalJobs);

            foreach (var reportDate in GenerateDates(startDate, endDate))
            {
                foreach (var partitionSet in tablePartitionsSet)
                {
                    await idempotentJobManager.CreateJobIfNotExistsAsync<ChargeReportS3Worker.ChargeReportS3Worker>(
                        reportId,
                        reportDate,
                        partitionSet,
                        processorQueueName,
                        job => job.ProcessReport(reportId, reportDate, partitionSet, null!, CancellationToken.None)
                    );
                }
            }
        }
        catch (Exception ex)
        {
            Log.ForContext("Exception", ex)
                .ForContext("JobId", dispatchId)
                .ForContext("ReportId", reportId)
                .Error("[ChargeReportS3DispatchWorker.DispatchReport] Error dispatching report");
            throw;
        }
        finally
        {
            Log.ForContext("JobId", dispatchId)
                .ForContext("ReportId", reportId)
                .Debug($"[ChargeReportS3DispatchWorker.DispatchReport] Completed");
        }
    }

    private async Task UploadReportMetadataAsync(
        string reportId,
        string dispatchId,
        string processorQueueName,
        DateTime startedAt,
        ChargeReportsWorkerParameters? chargeParameters,
        FinMovESWorkerParameters? finMovParameters
    )
    {

        var reportType = chargeParameters?.ReportType ??
            finMovParameters?.ReportType ??
            throw new InvalidOperationException("Report type not found");

        var reportConfiguration = ReportTypeConfigurationProvider.GetConfiguration(reportType)
            ?? throw new InvalidOperationException($"Report configuration not found for type {reportType}");

        await s3ClientWrapper.UploadReportMetadataAsync(
            new ReportMetadata
            {
                Status = WorkerStatesEnum.Processing.ToString(),
                ReportId = reportId,
                DispatchId = dispatchId,
                ReportSortColumnIndex = reportConfiguration.ReportSortColumnIndex,
                ProcessorQueueName = processorQueueName,
                FileFormat = Enums.FileFormatEnum.Csv.Name,
                ChargeReportParameters = chargeParameters,
                FinMovReportParameters = finMovParameters,
                CreatedAt = startedAt
            }
        );
    }
}
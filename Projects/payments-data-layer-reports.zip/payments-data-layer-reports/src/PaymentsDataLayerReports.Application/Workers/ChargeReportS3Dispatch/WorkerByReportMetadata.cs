using Datadog.Trace;
using Hangfire;
using Hangfire.Server;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Services.DeltaTablePartitionBuilder;
using PaymentsDataLayerReports.Application.Services.IdempotentJobManager;
using PaymentsDataLayerReports.Application.Versioning;
using Serilog;

namespace PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;

public class ChargeReportS3DispatchWorkerByReportMetadata(
    IS3ClientWrapper s3ClientWrapper,
    IIdempotentJobManager idempotentJobManager
)
{

    private static IEnumerable<DateOnly> GenerateDates(DateOnly startDate, DateOnly endDate)
    {
        for (var date = startDate; date <= endDate; date = date.AddDays(1))
        {
            yield return date;
        }
    }

    private static int CalculateTotalJobs(
        DateOnly startDate,
        DateOnly endDate,
        int partitionsCount
    )
    {
        if (endDate < startDate)
        {
            throw new ArgumentException("endDate must be greater than or equal to startDate.");
        }
        var datesCount = endDate.DayNumber - startDate.DayNumber + 1;
        return datesCount * partitionsCount;
    }


    [AutomaticRetry(Attempts = 100, OnAttemptsExceeded = AttemptsExceededAction.Delete)]
    public async Task DispatchReport(
        DateOnly startDate,
        DateOnly finalDate,
        ReportMetadata reportMetadata,
        PerformContext context,
        AppVersion1320 version,
        CancellationToken cancellationToken
    )
    {

        using var scope = Tracer.Instance.StartActive("ChargeReportS3DispatchWorker.DispatchReport");

        var dispatchId = context.BackgroundJob.Id;
        var reportId = string.IsNullOrEmpty(reportMetadata.ReportId) ? dispatchId : reportMetadata.ReportId;

        Log.ForContext("Version", version)
            .ForContext("ReportMetadata", reportMetadata)
            .ForContext("JobId", dispatchId)
            .ForContext("ReportId", reportId)
            .Information("[ChargeReportS3DispatchWorker.DispatchReport] Starting");

        try
        {

            if (reportMetadata.ChargeReportParameters == null && reportMetadata.FinMovReportParameters == null)
            {
                throw new InvalidOperationException("At least one report type must be specified");
            }

            var reportType = reportMetadata.ChargeReportParameters?.ReportType ?? reportMetadata.FinMovReportParameters?.ReportType ?? throw new InvalidOperationException("Report type not found");
            var document = reportMetadata.ChargeReportParameters?.Document ?? reportMetadata.FinMovReportParameters?.Document ?? null;
            var merchantId = reportMetadata.ChargeReportParameters?.MerchantId ?? reportMetadata.FinMovReportParameters?.MerchantId ?? null;
            _ = document ?? merchantId ?? throw new InvalidOperationException("Document or MerchantId not found");

            var fileFormat = string.IsNullOrWhiteSpace(reportMetadata.FileFormat)
                ? FileFormatEnum.Csv.Name
                : reportMetadata.FileFormat.ToLowerInvariant();

            if (reportMetadata.ChargeReportParameters is not null)
            {
                reportMetadata.ChargeReportParameters.FileFormat = fileFormat;
            }
            else if (reportMetadata.FinMovReportParameters is not null)
            {
                reportMetadata.FinMovReportParameters.FileFormat = fileFormat;
            }

            await s3ClientWrapper.UploadReportMetadataAsync(
                reportMetadata with
                {
                    ReportId = reportId,
                    DispatchId = dispatchId,
                    Status = WorkerStatesEnum.Processing.ToString(),
                    FileFormat = fileFormat
                }
            );

            var tablePartitionsSet = DeltaTablePartitionBuilder.BuildPartitionSets(
                reportType, document, merchantId
            ).ToList();

            var totalJobs = CalculateTotalJobs(startDate, finalDate, tablePartitionsSet.Count);

            await idempotentJobManager.SetTotalJobsAsync(reportId, totalJobs);

            foreach (var reportDate in GenerateDates(startDate, finalDate))
            {
                foreach (var partitionSet in tablePartitionsSet)
                {
                    await idempotentJobManager.CreateJobIfNotExistsAsync<ChargeReportS3Worker.ChargeReportS3Worker>(
                        reportId,
                        reportDate.ToDateTime(TimeOnly.MinValue),
                        partitionSet,
                        reportMetadata.ProcessorQueueName,
                        job => job.ProcessReport(reportId, reportDate.ToDateTime(TimeOnly.MinValue), partitionSet, null!, CancellationToken.None)
                    );
                }
            }
        }
        catch (Exception ex)
        {
            Log.ForContext("Exception", ex)
                .ForContext("JobId", dispatchId)
                .ForContext("ReportId", reportId)
                .Error("[ChargeReportS3DispatchWorker.DispatchReport] Error dispatching report");
            throw;
        }
        finally
        {
            Log.ForContext("JobId", dispatchId)
                .ForContext("ReportId", reportId)
                .Debug($"[ChargeReportS3DispatchWorker.DispatchReport] Completed");
        }
    }
}
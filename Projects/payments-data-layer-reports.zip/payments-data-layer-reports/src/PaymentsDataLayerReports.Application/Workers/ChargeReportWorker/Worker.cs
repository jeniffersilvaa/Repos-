using Datadog.Trace.Annotations;
using Hangfire;
using Hangfire.Server;
using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Infra.DataLayerApi;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService;
using PaymentsDataLayerReports.Application.Services.ReportTypeConfiguration;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;
using PaymentsDataLayerReports.Application.Workers.NotificationWorkerV2;
using PaymentsDataLayerReports.Application.Workers.Shared;
using Serilog;

namespace PaymentsDataLayerReports.Application.Workers.ChargeReportWorker;

public class ChargeReportWorker(
    IS3ClientWrapper s3ClientWrapper,
    IDataLayerApiClient dataLayerApiClient,
    IBackgroundJobClient backgroundJobClient,
    ICetFeatureManager cetFeatureManager,
    IReportStreamWriterFactory reportStreamWriterFactory,
    IServiceProvider serviceProvider
)
{
    [Trace]
    [AutomaticRetry(OnAttemptsExceeded = AttemptsExceededAction.Delete)]
    public async Task ProcessReport(ChargeReportsWorkerParameters parameters, NotificationChannel? notificationChannel, bool isPartialReport, PerformContext context, CancellationToken cancellationToken)
    {
        var jobId = context.BackgroundJob.Id;
        var reportId = string.IsNullOrWhiteSpace(parameters.ReportId) ? jobId : parameters.ReportId;

        try
        {
            Log.ForContext("Parameters", parameters)
                .ForContext("ReportId", reportId)
                .Information("[ChargeReportWorker.ProcessReport] - Processing report.");

            await UploadMetadata(reportId, parameters, notificationChannel, isPartialReport);

            if (isPartialReport)
            {
                await ProcessPartialReport(reportId, parameters, cancellationToken);
            }
            else
            {
                await ProcessFinalReport(jobId, reportId, parameters, notificationChannel, cancellationToken);
            }
        }
        catch (Exception ex)
        {
            Log.ForContext("Parameters", parameters)
                .ForContext("ReportId", reportId)
                .ForContext("Exception", ex)
                .Error("[ChargeReportWorker.ProcessReport] - Error processing report.");
            throw;
        }
    }

    private async Task ProcessPartialReport(string reportId, ChargeReportsWorkerParameters parameters, CancellationToken cancellationToken)
    {
        var destinationKey = string.Format(S3ReportsConstants.PartialReportFilePath, reportId, parameters.EndDate, "es_file");
        await using var writer = reportStreamWriterFactory.Create<string>(FileFormatEnum.Csv.Name);

        try
        {
            await writer.InitializeAsync(reportId, cancellationToken, destinationKey);

            ISaleCsvMapper<Charge> csvMapper = serviceProvider.GetRequiredKeyedService<ISaleCsvMapper<Charge>>(parameters.ReportType);
            csvMapper.IsCetEnabled = cetFeatureManager.IsCET(parameters.AffiliationCodes) || cetFeatureManager.IsCET(parameters.Document);

            string? cursor = null;
            var dalapiParameters = parameters.ToGetChargesRequestModel();

            do
            {
                dalapiParameters.Cursor = cursor;
                var result = await dataLayerApiClient.GetCharges(dalapiParameters, reportId, cancellationToken);

                foreach (var charge in result.Data)
                {
                    var row = csvMapper.BuildRow(charge);
                    if (row is null) continue;
                    await writer.WriteRecordAsync(row, cancellationToken);
                }

                cursor = result.Cursor;
            } while (cursor != null);

            await writer.CompleteAsync(cancellationToken);
        }
        catch (Exception ex)
        {
            Log.ForContext("ReportId", reportId)
                .Error(ex, "[ChargeReportWorker.ProcessPartialReport] - Error processing partial report. Aborting upload.");

            await writer.AbortAsync(cancellationToken);
            throw;
        }

        Log.ForContext("ReportId", reportId)
            .Debug("[ChargeReportWorker.ProcessPartialReport] - Partial report processed.");
    }

    private async Task ProcessFinalReport(string jobId, string reportId, ChargeReportsWorkerParameters parameters, NotificationChannel? notificationChannel, CancellationToken cancellationToken)
    {
        var fileFormat = parameters.FileFormat;
        await using var writer = reportStreamWriterFactory.Create<string>(fileFormat);

        try
        {
            await writer.InitializeAsync(reportId, cancellationToken);

            ISaleCsvMapper<Charge> csvMapper = serviceProvider.GetRequiredKeyedService<ISaleCsvMapper<Charge>>(parameters.ReportType);
            csvMapper.IsCetEnabled = cetFeatureManager.IsCET(parameters.AffiliationCodes) || cetFeatureManager.IsCET(parameters.Document);

            await writer.WriteHeaderAsync(csvMapper.GetHeader(), cancellationToken);

            string? cursor = null;
            var dalapiParameters = parameters.ToGetChargesRequestModel();

            do
            {
                dalapiParameters.Cursor = cursor;
                var result = await dataLayerApiClient.GetCharges(dalapiParameters, reportId, cancellationToken);

                foreach (var charge in result.Data)
                {
                    var row = csvMapper.BuildRow(charge);
                    if (row is null) continue;
                    await writer.WriteRecordAsync(row, cancellationToken);
                }

                cursor = result.Cursor;
            } while (cursor != null);

            await writer.CompleteAsync(cancellationToken);
        }
        catch (Exception ex)
        {
            Log.ForContext("ReportId", reportId)
                .Error(ex, "[ChargeReportWorker.ProcessFinalReport] - Error processing report. Aborting upload.");

            await writer.AbortAsync(cancellationToken);
            throw;
        }

        var downloadUrl = s3ClientWrapper.BuildReportUrl(reportId, fileFormat: fileFormat) ?? string.Empty;

        Log.ForContext("ReportId", reportId)
            .Debug("[ChargeReportWorker.ProcessFinalReport] - Report processed.");

        if (notificationChannel is null) return;

        SendNotification(jobId, reportId, downloadUrl, parameters, notificationChannel, fileFormat, cancellationToken);
    }

    private void SendNotification(string jobId, string reportId, string downloadUrl, ChargeReportsWorkerParameters parameters, NotificationChannel notificationChannel, string fileFormat, CancellationToken cancellationToken)
    {
        var dateFormat = "yyyy-MM-dd";

        var brazilianTimeZone = TimeZoneInfo.FindSystemTimeZoneById("America/Sao_Paulo");
        var startDateBrazilian = TimeZoneInfo.ConvertTime(parameters.StartDate, brazilianTimeZone);
        var endDateBrazilian = TimeZoneInfo.ConvertTime(parameters.EndDate, brazilianTimeZone);

        var metadata = new Dictionary<string, object>
            {
                {"start_date", startDateBrazilian.ToString(dateFormat) ?? ""},
                {"end_date", endDateBrazilian.ToString(dateFormat) ?? ""},
                {"report_type",  parameters.ReportType },
                {"document",parameters.Document ??"" },
                {"organizations", parameters.Organizations ?? "" }
            };

        if (notificationChannel?.Email is not null)
            metadata.Add("email", notificationChannel.Email.Address);

        var notificationParameters = new NotificationParameters
        {
            Status = WorkerStatesEnum.Succeeded.ToString(),
            ReportId = reportId,
            ReportType = parameters.ReportType,
            DownloadUrl = downloadUrl,
            Metadata = metadata,
            Channel = notificationChannel!,
            FileFormat = fileFormat
        };

        backgroundJobClient.ContinueJobWith<NotificationWorkerV2.NotificationWorkerV2>(
          parentId: jobId,
          queue: QueuesEnum.Notifications.Name,
          options: JobContinuationOptions.OnlyOnSucceededState,
          methodCall: job => job.SendNotificationAsync(notificationParameters, null!, cancellationToken)
        );
    }

    private async Task UploadMetadata(string reportId, ChargeReportsWorkerParameters parameters, NotificationChannel? notificationChannel, bool isPartialReport)
    {
        if (!isPartialReport) return;

        var reportConfiguration = ReportTypeConfigurationProvider.GetConfiguration(parameters.ReportType)
            ?? throw new InvalidOperationException($"Report configuration not found for type {parameters.ReportType}");

        NotificationParameters? notificationParameters = null;
        if (notificationChannel is not null)
        {
            notificationParameters = new NotificationParameters
            {
                Channel = notificationChannel,
                FileFormat = parameters.FileFormat
            };
        }

        var reportMetadata = new ReportMetadata
        {
            ReportId = reportId,
            DispatchId = string.Empty,
            CreatedAt = DateTime.UtcNow,
            Status = WorkerStatesEnum.Processing.ToString(),
            ProcessorQueueName = QueuesEnum.S3Reports.Name,
            ReportSortColumnIndex = reportConfiguration.ReportSortColumnIndex,
            FileFormat = parameters.FileFormat,
            ChargeReportParameters = parameters,
            FinMovReportParameters = null,
            NotificationParameters = notificationParameters
        };

        await s3ClientWrapper.UploadReportMetadataAsync(reportMetadata);
    }
}

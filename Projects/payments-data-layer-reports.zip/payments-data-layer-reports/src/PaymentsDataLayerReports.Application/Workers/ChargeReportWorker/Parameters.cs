using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Infra.DataLayerApi.Models;

namespace PaymentsDataLayerReports.Application.Workers.ChargeReportWorker;

public record ChargeReportsWorkerParameters
{
    public DateTimeOffset StartDate { get; set; }
    public DateTimeOffset EndDate { get; set; }
    public string? Document { get; set; } = string.Empty;
    public string? AccountId { get; set; } = string.Empty;
    public string? MerchantId { get; set; } = string.Empty;
    public bool? IsSandbox { get; set; } = false;
    public string? AffiliationCodes { get; set; } = null;
    public string? PaymentMethods { get; set; } = null;
    public string Organizations { get; set; } = string.Empty;
    public string ReportType { get; set; } = string.Empty;
    public string? AllIds { get; set; } = null;
    public string? Customers { get; set; } = null;
    public string? Acquirers { get; set; } = null;
    public string? BankNames { get; set; } = null;
    public string? CardBrands { get; set; } = null;
    public DateTime? PaidAt { get; set; } = null;
    public string? FundingSources { get; set; } = null;
    public string? PlatformName { get; set; } = null;
    public string? Status { get; set; } = null;
    public string? AntifraudStatus { get; set; } = null;
    public string? LastOperationStatus { get; set; } = null;
    public string? LastLegacyStatus { get; set; } = null;
    public string? LegacyStatus { get; set; } = null;
    public long? MinAmount { get; set; } = null;
    public long? MaxAmount { get; set; } = null;
    public bool? WithFailed { get; set; } = null;
    public string FileFormat { get; set; } = FileFormatEnum.Csv.Name;
    public string? StoneAccounts { get; set; } = null;
    public string? PaymentProfiles { get; set; } = null;
    public string? PoiTypes { get; set; } = null;
    public string? ReportId { get; set; } = null;

    private const int DALAPI_BATCH_SIZE = 1000;
    public GetChargesRequestModel ToGetChargesRequestModel() => new()
    {
        Size = DALAPI_BATCH_SIZE,
        StartCreationDate = StartDate,
        EndCreationDate = EndDate,
        Document = Document,
        AccountId = AccountId,
        MerchantId = MerchantId,
        IsSandbox = IsSandbox,
        AffiliationCodes = AffiliationCodes,
        PaymentMethods = PaymentMethods,
        Organizations = Organizations,
        WithFullAmounts = true,
        DalarRequest = true,
        AllIds = AllIds,
        Customers = Customers,
        Acquirers = Acquirers,
        BankNames = BankNames,
        CardBrands = CardBrands,
        PaidAt = PaidAt,
        FundingSources = FundingSources,
        PlatformNames = PlatformName,
        Status = Status,
        AntifraudStatus = AntifraudStatus,
        LastOperationStatus = LastOperationStatus,
        LastLegacyStatus = LastLegacyStatus,
        MinAmount = MinAmount,
        MaxAmount = MaxAmount,
        WithFailed = WithFailed,
        StoneAccounts = StoneAccounts,
        PaymentProfiles = PaymentProfiles,
        PoiTypes = PoiTypes
    };
}
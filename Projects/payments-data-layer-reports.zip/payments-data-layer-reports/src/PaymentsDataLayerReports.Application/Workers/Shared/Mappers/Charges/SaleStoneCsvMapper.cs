using System.Text.Json;
using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Entities.Models.Charge;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Services.ReportTypeConfiguration;

namespace PaymentsDataLayerReports.Application.Workers.Shared.Mappers.Charges;

public class SaleStoneCsvMapper : ISaleCsvMapper<Charge>
{
    private const decimal ONE_HUNDRED = 100m;
    private static readonly CsvSeparatorEnum Separator = ReportTypeConfigurationProvider.GetCsvSeparator(ReportTypeEnum.SalesStone.Name);
    private static readonly string Header;
    private static readonly JsonSerializerOptions Options = SerializerOptions.Options;
    private static readonly System.Globalization.CultureInfo PtBrCulture = new("pt-BR");
    public bool IsCetEnabled { get; set; }
    public int CreatedAtColumnPosition => 3;

    static SaleStoneCsvMapper()
    {
        Header = BuildHeader();
    }

    private static string BuildHeader()
    {
        List<string> headerList =
        [
            "DOCUMENTO",
            "STONECODE",
            "DATA DA VENDA",
            "BANDEIRA",
            "PRODUTO",
            "STONE ID",
            "N DE PARCELAS",
            "VALOR BRUTO",
            "VALOR LIQUIDO",
            "DESCONTO DE MDR",
            "DESCONTO DE ANTECIPACAO",
            "DESCONTO UNIFICADO",
            "N DO CARTAO",
            "MEIO DE CAPTURA",
            "N DE SERIE",
            "ULTIMO STATUS",
            "DATA DO ULTIMO STATUS"
        ];

        var headerBuilder = new CsvRowBuilder(Separator);
        foreach (var header in headerList)
        {
            headerBuilder.Add(header);
        }

        return headerBuilder.Build();
    }

    public string GetHeader()
    {
        return Header;
    }

    private static string? FormatMonetaryValue(decimal? amountInCents)
    {
        if (amountInCents == null) return null;

        return amountInCents.Value.ToString("N6", PtBrCulture);
    }

    private static decimal? FormatAmount(decimal? amountInCents)
    {
        if (amountInCents == null) return 0m;
        return amountInCents.Value / ONE_HUNDRED; ;
    }

    private static string ToBrazilianDateTime(DateTimeOffset dateTime)
    {
        var dateFormat = "dd/MM/yyyy HH:mm";
        return TimeZoneInfo.ConvertTimeBySystemTimeZoneId(dateTime, "America/Sao_Paulo").ToString(dateFormat);
    }

    private static decimal CalculateTaxAmount(decimal fullRefundAmount, decimal fullAmount)
    {
        return Math.Abs(fullRefundAmount) - Math.Abs(fullAmount);
    }

    private static string DefineLastStatusDate(IReadOnlyList<dynamic>? details)
    {
        if (details == null || details.Count == 0) return string.Empty;

        return ToBrazilianDateTime(details.OrderBy(i => i.ProviderDatetime).LastOrDefault()?.ProviderDatetime);
    }

    private static bool IsNotApplicableCetFee(FinancialMovementFee? financialMovementFee)
    {
        return financialMovementFee != null && !"cet".Equals(financialMovementFee.FeeType, StringComparison.InvariantCultureIgnoreCase);
    }

    private static bool IsApplicableCetFee(FinancialMovementFee? financialMovementFee)
    {
        return financialMovementFee != null && "cet".Equals(financialMovementFee.FeeType, StringComparison.InvariantCultureIgnoreCase);
    }

    public static double CalculateMdrFeeAmount(List<ChargeFinancialMovement>? financialMovements)
    {
        if (financialMovements == null)
            return 0;

        return (double)(financialMovements
                    .Where(fm => IsNotApplicableCetFee(fm.Amount.DiscountRate))
                    .Sum(fm => fm.Amount.DiscountRate!.Amount.GetValueOrDefault()));
    }

    public static double CalculateRavFeeAmount(List<ChargeFinancialMovement>? financialMovements)
    {
        if (financialMovements == null)
            return 0;

        return (double)(financialMovements
                    .Where(fm => IsNotApplicableCetFee(fm.Amount.PrepaymentFee))
                    .Sum(fm => fm.Amount.PrepaymentFee!.Amount.GetValueOrDefault()));
    }

    public static double CalculateCetFeeAmount(List<ChargeFinancialMovement>? financialMovements)
    {
        if (financialMovements == null)
            return 0;

        return (double)(financialMovements
                    .Where(fm => IsApplicableCetFee(fm.Amount.DiscountRate))
                    .Sum(fm => fm.Amount.DiscountRate!.Amount.GetValueOrDefault())
                +
               financialMovements
                    .Where(fm => IsApplicableCetFee(fm.Amount.PrepaymentFee))
                    .Sum(fm => fm.Amount.PrepaymentFee!.Amount.GetValueOrDefault()));
    }

    public static double CalculateRavTurboFeeAmount(List<ChargeFinancialMovement>? financialMovements)
    {
        if (financialMovements == null)
            return 0;

        return (double)(financialMovements
                    .Where(fm => fm.Amount?.PrepaymentFeeTurbo != null)
                    .Sum(fm => fm.Amount.PrepaymentFeeTurbo!.Amount.GetValueOrDefault()));
    }

    public string BuildRow(Charge charge)
    {

        return charge.PaymentMethod switch
        {
            "card" => BuildRowCard(charge, IsCetEnabled),
            "pix" => BuildRowPix(charge),
            "boleto" => BuildRowBankslip(charge),
            _ => throw new NotSupportedException($"Payment method '{charge.PaymentMethod}' is not supported."),
        };
    }

    private static string BuildRowCard(Charge charge, bool isCET)
    {
        var amount = FormatAmount(charge.Amount);
        var discountMdr = CalculateTaxAmount(
            charge.CardTransaction?.FullMdrRefundAmount ?? 0,
            charge.CardTransaction?.FullMdrAmount ?? 0
        );
        var discountRav = CalculateTaxAmount(
            charge.CardTransaction?.FullRavRefundAmount ?? 0,
            charge.CardTransaction?.FullRavAmount ?? 0
        );
        var chargeback = CalculateTaxAmount(
            FormatAmount(charge.CardTransaction?.ChargebackRefundAmount ?? 0) ?? 0m,
            FormatAmount(charge.CardTransaction?.ChargebackAmount ?? 0) ?? 0m
        );
        var canceledAmount = (FormatAmount(charge.CardTransaction?.CanceledAmount ?? 0) ?? 0m) * -1m;

        var financialMovements = charge.CardTransaction?.FinancialMovements;
        var hasFinancialMovements = financialMovements != null && financialMovements.Count != 0;

        decimal cetFeeAmount = 0;
        if (isCET && hasFinancialMovements)
        {
            discountMdr = Convert.ToDecimal(CalculateMdrFeeAmount(financialMovements));
            discountRav = Convert.ToDecimal(CalculateRavFeeAmount(financialMovements));
            cetFeeAmount = Convert.ToDecimal(CalculateCetFeeAmount(financialMovements));

            var ravTurbo = Convert.ToDecimal(CalculateRavTurboFeeAmount(financialMovements));
            discountRav += ravTurbo;
        }

        decimal discounts = Math.Abs(discountMdr + discountRav + chargeback + canceledAmount + cetFeeAmount);
        var netAmount = amount - discounts;

        var builder = new CsvRowBuilder(Separator)
            .Add(charge.Merchant.Document)
            .Add(charge.Merchant.AffiliationCode)
            .Add(ToBrazilianDateTime(charge.CreatedAt))
            .Add(charge.CardTransaction?.Card?.Brand)
            .Add(SaleDomainMapper.MapCardProduct(charge.CardTransaction?.FundingSource, charge.CardTransaction?.Type))
            .Add(charge.Id)
            .Add(charge.CardTransaction?.Installments ?? 1)
            .Add(FormatMonetaryValue(amount))
            .Add(FormatMonetaryValue(netAmount))
            .Add(FormatMonetaryValue(discountMdr))
            .Add(FormatMonetaryValue(discountRav))
            .Add(FormatMonetaryValue(cetFeeAmount))
            .Add(SaleDomainMapper.MapCardNumber(charge.CardTransaction?.Card.FirstSixDigits, charge.CardTransaction?.Card.LastFourDigits))
            .Add(SaleDomainMapper.MapTerminalType(charge.CardTransaction.Terminal.Type))
            .Add(charge.CardTransaction.Terminal.SerialNumber)
            .Add(SaleDomainMapper.MapLastStatusName(charge.PaymentMethod, charge.Status, charge.CardTransaction.Details, charge.CardTransaction?.ChargebackAmount, charge.CardTransaction?.ChargebackRefundAmount, charge.CardTransaction?.CanceledAmount ?? 0))
            .Add(DefineLastStatusDate(charge.CardTransaction.Details));

        return builder.Build();
    }

    private static string BuildRowPix(Charge charge)
    {
        var amount = FormatAmount(charge.PixTransaction?.PaidAmount);
        var discountMdr = FormatAmount(charge.PixTransaction?.FeeAmount);
        var netAmount = amount - discountMdr;

        var builder = new CsvRowBuilder(Separator)
            .Add(charge.Merchant.Document)
            .Add(null)
            .Add(ToBrazilianDateTime(charge.CreatedAt))
            .Add(null)
            .Add(SaleDomainMapper.MapPixTransactionType(charge.PixTransaction?.Type))
            .Add(charge.PixTransaction?.E2eId)
            .Add(null)
            .Add(FormatMonetaryValue(amount))
            .Add(FormatMonetaryValue(netAmount))
            .Add(FormatMonetaryValue(discountMdr * -1))
            .Add(FormatMonetaryValue(0))
            .Add(FormatMonetaryValue(0))
            .Add(null)
            .Add(SaleDomainMapper.MapTerminalType(charge.PixTransaction?.Terminal.Type))
            .Add(charge.PixTransaction?.Terminal.SerialNumber)
            .Add(SaleDomainMapper.MapLastStatusName(charge.PaymentMethod, charge.Status, charge.PixTransaction?.Details, null, null, charge.PixTransaction?.CanceledAmount ?? 0))
            .Add(DefineLastStatusDate(charge.PixTransaction?.Details));

        return builder.Build();
    }

    private static string BuildRowBankslip(Charge charge)
    {
        var amount = FormatAmount(charge.Amount);
        var discountMdr = FormatAmount(charge.BoletoTransaction?.FeeAmount);
        var netAmount = amount - discountMdr;

        var builder = new CsvRowBuilder(Separator)
            .Add(charge.Merchant.Document)
            .Add(charge.Merchant.AffiliationCode)
            .Add(ToBrazilianDateTime(charge.CreatedAt))
            .Add(charge.BoletoTransaction?.Bank.Name)
            .Add("Boleto")
            .Add(charge.Id)
            .Add(1)
            .Add(FormatMonetaryValue(amount))
            .Add(FormatMonetaryValue(netAmount))
            .Add(FormatMonetaryValue(discountMdr))
            .Add(FormatMonetaryValue(0))
            .Add(FormatMonetaryValue(0))
            .Add(null)
            .Add("Ecommerce")
            .Add(null)
            .Add(SaleDomainMapper.MapLastStatusName(charge.PaymentMethod, charge.Status, charge.BoletoTransaction?.Details, null, null, charge.BoletoTransaction?.CanceledAmount ?? 0))
            .Add(DefineLastStatusDate(charge.BoletoTransaction?.Details));

        return builder.Build();
    }
}


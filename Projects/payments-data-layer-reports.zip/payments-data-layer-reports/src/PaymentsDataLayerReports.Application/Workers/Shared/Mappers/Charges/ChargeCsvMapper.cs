using System.Text.Json;
using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Services.ReportTypeConfiguration;

namespace PaymentsDataLayerReports.Application.Workers.Shared.Mappers.Charges;


public class ChargeCsvMapper : ISaleCsvMapper<Charge>
{
    private static readonly CsvSeparatorEnum Separator = ReportTypeConfigurationProvider.GetCsvSeparator(ReportTypeEnum.ChargesList.Name);
    private static readonly string Header;

    private static readonly JsonSerializerOptions Options = SerializerOptions.Options;
    public bool IsCetEnabled { get; set; }
    public int CreatedAtColumnPosition => 11;

    static ChargeCsvMapper()
    {
        Header = BuildHeader();
    }

    private static string BuildHeader()
    {
        List<string> headerList =
        [
            "id",
            "initiator_id",
            "product",
            "charge_id",
            "origin",
            "origin_id",
            "amount",
            "status",
            "payment_method",
            "point_of_interaction_type",
            "created_at",
            "platform_name",
            "attempt_count",
            "gateway",
            "gateway_order_id",
            "metadata",
            "all_ids",
            "code",
            "split",
            "merchant__organization",
            "merchant__user_id",
            "merchant__document",
            "merchant__affiliation_key",
            "merchant__affiliation_code",
            "merchant__account_id",
            "merchant__merchant_id",
            "merchant__stone_account",
            "merchant__payment_profile_id",
            "card_transaction__type",
            "card_transaction__funding_source",
            "card_transaction__transaction_id",
            "card_transaction__authorization_code",
            "card_transaction__authorized_state",
            "card_transaction__installments",
            "card_transaction__installments_type",
            "card_transaction__scheme_business_model",
            "card_transaction__last__acquirer_name",
            "card_transaction__last__acquirer_return_code",
            "card_transaction__last__antifraud_status",
            "card_transaction__last__operation_status",
            "card_transaction__last__legacy_status",
            "card_transaction__card__brand",
            "card_transaction__card__brand_id",
            "card_transaction__card__first_six_digits",
            "card_transaction__card__last_four_digits",
            "card_transaction__card__entry_mode",
            "card_transaction__card__holder_name",
            "card_transaction__card__exp_month",
            "card_transaction__card__exp_year",
            "card_transaction__card__country_code",
            "card_transaction__card__currency_code",
            "card_transaction__card__number_token",
            "card_transaction__card__label",
            "card_transaction__terminal__type",
            "card_transaction__terminal__serial_number",
            "card_transaction__financial_movements",
            "card_transaction__customer__name",
            "card_transaction__customer__document",
            "card_transaction__customer__document_type",
            "card_transaction__customer__customer_id",
            "card_transaction__customer__email",
            "card_transaction__customer__address__country",
            "card_transaction__customer__address__city",
            "card_transaction__customer__address__street",
            "card_transaction__customer__address__extra",
            "card_transaction__customer__address__street_number",
            "card_transaction__customer__address__neighborhood",
            "card_transaction__customer__address__state",
            "card_transaction__customer__address__postal_code",
            "card_transaction__details",
            "card_transaction__authorized_amount",
            "card_transaction__captured_amount",
            "card_transaction__canceled_amount",
            "card_transaction__chargeback_amount",
            "card_transaction__chargeback_refund_amount",
            "card_transaction__full_mdr_amount",
            "card_transaction__mdr_amount",
            "card_transaction__full_mdr_refund_amount",
            "card_transaction__mdr_refund_amount",
            "card_transaction__full_fee_amount",
            "card_transaction__fee_amount",
            "card_transaction__full_rav_amount",
            "card_transaction__rav_amount",
            "card_transaction__full_rav_refund_amount",
            "card_transaction__rav_refund_amount",
            "card_transaction__full_fc_amount",
            "card_transaction__full_fc_refund_amount",
            "boleto_transaction__type",
            "boleto_transaction__transaction_id",
            "boleto_transaction__our_number",
            "boleto_transaction__paid_amount",
            "boleto_transaction__canceled_amount",
            "boleto_transaction__fee_amount",
            "boleto_transaction__full_fee_amount",
            "boleto_transaction__full_mdr_amount",
            "boleto_transaction__full_mdr_refund_amount",
            "boleto_transaction__full_rav_amount",
            "boleto_transaction__full_rav_refund_amount",
            "boleto_transaction__full_fc_amount",
            "boleto_transaction__full_fc_refund_amount",
            "boleto_transaction__fine_amount",
            "boleto_transaction__interest_amount",
            "boleto_transaction__discount_amount",
            "boleto_transaction__expire_at",
            "boleto_transaction__limit_date",
            "boleto_transaction__barcode",
            "boleto_transaction__writable_line",
            "boleto_transaction__instructions",
            "boleto_transaction__url",
            "boleto_transaction__paid_at",
            "boleto_transaction__last__operation_status",
            "boleto_transaction__last__legacy_status",
            "boleto_transaction__bank__code",
            "boleto_transaction__bank__name",
            "boleto_transaction__receiver__name",
            "boleto_transaction__receiver__document_type",
            "boleto_transaction__receiver__document",
            "boleto_transaction__customer__name",
            "boleto_transaction__customer__document_type",
            "boleto_transaction__customer__document",
            "boleto_transaction__customer__customer_id",
            "boleto_transaction__customer__email",
            "boleto_transaction__customer__address__street",
            "boleto_transaction__customer__address__street_number",
            "boleto_transaction__customer__address__extra",
            "boleto_transaction__customer__address__neighborhood",
            "boleto_transaction__customer__address__postal_code",
            "boleto_transaction__customer__address__city",
            "boleto_transaction__customer__address__state",
            "boleto_transaction__customer__address__country",
            "boleto_transaction__details",
            "boleto_transaction__fine__start_at",
            "boleto_transaction__fine__type",
            "boleto_transaction__fine__value",
            "boleto_transaction__interest__start_at",
            "boleto_transaction__interest__type",
            "boleto_transaction__interest__value",
            "boleto_transaction__discounts",
            "boleto_transaction__financial_movements",
            "pix_transaction__type",
            "pix_transaction__transaction_id",
            "pix_transaction__e2e_id",
            "pix_transaction__pix_key",
            "pix_transaction__is_pix_sale_key",
            "pix_transaction__pix_key_nickname",
            "pix_transaction__paid_amount",
            "pix_transaction__canceled_amount",
            "pix_transaction__fee_amount",
            "pix_transaction__full_fee_amount",
            "pix_transaction__full_mdr_amount",
            "pix_transaction__full_mdr_refund_amount",
            "pix_transaction__full_rav_amount",
            "pix_transaction__full_rav_refund_amount",
            "pix_transaction__full_fc_amount",
            "pix_transaction__full_fc_refund_amount",
            "pix_transaction__expire_at",
            "pix_transaction__payment_limit_period_days",
            "pix_transaction__business_days_only",
            "pix_transaction__expires_in",
            "pix_transaction__request_for_payer",
            "pix_transaction__last__operation_status",
            "pix_transaction__last__legacy_status",
            "pix_transaction__fine__start_at",
            "pix_transaction__fine__type",
            "pix_transaction__fine__value",
            "pix_transaction__interest__start_at",
            "pix_transaction__interest__type",
            "pix_transaction__interest__value",
            "pix_transaction__interest__period",
            "pix_transaction__reduction__start_at",
            "pix_transaction__reduction__value",
            "pix_transaction__customer__name",
            "pix_transaction__customer__document",
            "pix_transaction__customer__document_type",
            "pix_transaction__customer__customer_id",
            "pix_transaction__customer__email",
            "pix_transaction__customer__address__country",
            "pix_transaction__customer__address__city",
            "pix_transaction__customer__address__street",
            "pix_transaction__customer__address__extra",
            "pix_transaction__customer__address__street_number",
            "pix_transaction__customer__address__neighborhood",
            "pix_transaction__customer__address__state",
            "pix_transaction__customer__address__postal_code",
            "pix_transaction__details",
            "pix_transaction__payer__name",
            "pix_transaction__payer__document_type",
            "pix_transaction__payer__document",
            "pix_transaction__payer__ispb",
            "pix_transaction__payer__institution_name",
            "pix_transaction__additional_data",
            "pix_transaction__terminal__type",
            "pix_transaction__terminal__serial_number",
            "pix_transaction__financial_movements",
            "cash_transaction__description",
            "cash_transaction__transaction_id",
            "cash_transaction__paid_amount",
            "cash_transaction__canceled_amount",
            "cash_transaction__customer__name",
            "cash_transaction__customer__customer_id",
            "cash_transaction__customer__document_type",
            "cash_transaction__customer__document",
            "cash_transaction__customer__email",
            "cash_transaction__customer__address__country",
            "cash_transaction__customer__address__city",
            "cash_transaction__customer__address__street",
            "cash_transaction__customer__address__extra",
            "cash_transaction__customer__address__street_number",
            "cash_transaction__customer__address__neighborhood",
            "cash_transaction__customer__address__state",
            "cash_transaction__customer__address__postal_code",
            "cash_transaction__last__operation_status",
            "cash_transaction__last__legacy_status",
            "cash_transaction__details",
            "updated_amount",
            "full_net_amount",
            "net_amount"
        ];

        var headerBuilder = new CsvRowBuilder(Separator);
        foreach (var header in headerList)
        {
            headerBuilder.Add(header);
        }

        return headerBuilder.Build();
    }

    public string GetHeader()
    {
        return Header;
    }

    public string BuildRow(Charge charge)
    {
        const string dateFormat = "yyyy-MM-ddTHH:mm:ss.ffffffzzz";

        var builder = new CsvRowBuilder(Separator)
            .Add(charge.Id)
            .Add(charge.InitiatorId)
            .Add(charge.Product)
            .Add(charge.ChargeId)
            .Add(charge.Origin)
            .Add(charge.OriginId)
            .Add(charge.Amount)
            .Add(charge.Status)
            .Add(charge.PaymentMethod)
            .Add(charge.PointOfInteractionType)
            .AddDateTimeOffset(charge.CreatedAt, dateFormat)
            .Add(charge.PlatformName)
            .Add(charge.AttemptCount)
            .Add(charge.Gateway)
            .Add(charge.GatewayOrderId)
            .AddSerializableObject(charge.Metadata, Options)
            .Add(charge.AllIds)
            .Add(charge.Code)
            .AddSerializableObject(charge.Split, Options)
            .Add(charge.Merchant.Organization)
            .Add(charge.Merchant.UserId)
            .Add(charge.Merchant.Document)
            .Add(charge.Merchant.AffiliationKey)
            .Add(charge.Merchant.AffiliationCode)
            .Add(charge.Merchant.AccountId)
            .Add(charge.Merchant.MerchantId)
            .Add(charge.Merchant.StoneAccount)
            .Add(charge.Merchant.PaymentProfileId)
            .Add(charge.CardTransaction?.Type)
            .Add(charge.CardTransaction?.FundingSource)
            .Add(charge.CardTransaction?.TransactionId)
            .Add(charge.CardTransaction?.AuthorizationCode)
            .Add(charge.CardTransaction?.AuthorizedState)
            .Add(charge.CardTransaction?.Installments)
            .Add(charge.CardTransaction?.InstallmentsType)
            .Add(charge.CardTransaction?.SchemeBusinessModel)
            .Add(charge.CardTransaction?.Last?.AcquirerName)
            .Add(charge.CardTransaction?.Last?.AcquirerReturnCode)
            .Add(charge.CardTransaction?.Last?.AntifraudStatus)
            .Add(charge.CardTransaction?.Last?.OperationStatus)
            .Add(charge.CardTransaction?.Last?.LegacyStatus)
            .Add(charge.CardTransaction?.Card.Brand)
            .Add(charge.CardTransaction?.Card.BrandId)
            .Add(charge.CardTransaction?.Card.FirstSixDigits)
            .Add(charge.CardTransaction?.Card.LastFourDigits)
            .Add(charge.CardTransaction?.Card.EntryMode)
            .Add(charge.CardTransaction?.Card.HolderName)
            .Add(charge.CardTransaction?.Card.ExpMonth)
            .Add(charge.CardTransaction?.Card.ExpYear)
            .Add(charge.CardTransaction?.Card.CountryCode)
            .Add(charge.CardTransaction?.Card.CurrencyCode)
            .Add(charge.CardTransaction?.Card.NumberToken)
            .Add(charge.CardTransaction?.Card.Label)
            .Add(charge.CardTransaction?.Terminal.Type)
            .Add(charge.CardTransaction?.Terminal.SerialNumber)
            // .Add(charge.CardTransaction?.Fees)
            .AddSerializableObject(charge.CardTransaction?.FinancialMovements, Options)
            .Add(charge.CardTransaction?.Customer?.Name)
            .Add(charge.CardTransaction?.Customer?.Document)
            .Add(charge.CardTransaction?.Customer?.DocumentType)
            .Add(charge.CardTransaction?.Customer?.CustomerId)
            .Add(charge.CardTransaction?.Customer?.Email)
            .Add(charge.CardTransaction?.Customer?.Address?.Country)
            .Add(charge.CardTransaction?.Customer?.Address?.City)
            .Add(charge.CardTransaction?.Customer?.Address?.Street)
            .Add(charge.CardTransaction?.Customer?.Address?.Extra)
            .Add(charge.CardTransaction?.Customer?.Address?.StreetNumber)
            .Add(charge.CardTransaction?.Customer?.Address?.Neighborhood)
            .Add(charge.CardTransaction?.Customer?.Address?.State)
            .Add(charge.CardTransaction?.Customer?.Address?.PostalCode)
            .AddSerializableObject(charge.CardTransaction?.Details, Options)
            .Add(charge.CardTransaction?.AuthorizedAmount)
            .Add(charge.CardTransaction?.CapturedAmount)
            .Add(charge.CardTransaction?.CanceledAmount)
            .Add(charge.CardTransaction?.ChargebackAmount)
            .Add(charge.CardTransaction?.ChargebackRefundAmount)
            .Add(charge.CardTransaction?.FullMdrAmount, "0")
            .Add(charge.CardTransaction?.MdrAmount, "0")
            .Add(charge.CardTransaction?.FullMdrRefundAmount, "0")
            .Add(charge.CardTransaction?.MdrRefundAmount, "0")
            .Add(charge.CardTransaction?.FullFeeAmount, "0")
            .Add(charge.CardTransaction?.FeeAmount, "0")
            .Add(charge.CardTransaction?.FullRavAmount, "0")
            .Add(charge.CardTransaction?.RavAmount, "0")
            .Add(charge.CardTransaction?.FullRavRefundAmount, "0")
            .Add(charge.CardTransaction?.RavRefundAmount, "0")
            .Add(charge.CardTransaction?.FullFcAmount, "0")
            .Add(charge.CardTransaction?.FullFcRefundAmount, "0")
            .Add(charge.BoletoTransaction?.Type)
            .Add(charge.BoletoTransaction?.TransactionId)
            .Add(charge.BoletoTransaction?.OurNumber)
            .Add(charge.BoletoTransaction?.PaidAmount)
            .Add(charge.BoletoTransaction?.CanceledAmount)
            .Add(charge.BoletoTransaction?.FeeAmount)
            .Add(charge.BoletoTransaction?.FullFeeAmount, "0")
            .Add(charge.BoletoTransaction?.FullMdrAmount, "0")
            .Add(charge.BoletoTransaction?.FullMdrRefundAmount, "0")
            .Add(charge.BoletoTransaction?.FullRavAmount, "0")
            .Add(charge.BoletoTransaction?.FullRavRefundAmount, "0")
            .Add(charge.BoletoTransaction?.FullFcAmount, "0")
            .Add(charge.BoletoTransaction?.FullFcRefundAmount, "0")
            .Add(charge.BoletoTransaction?.FineAmount)
            .Add(charge.BoletoTransaction?.InterestAmount)
            .Add(charge.BoletoTransaction?.DiscountAmount)
            .Add(charge.BoletoTransaction?.ExpireAt)
            .Add(charge.BoletoTransaction?.LimitDate)
            .Add(charge.BoletoTransaction?.Barcode)
            .Add(charge.BoletoTransaction?.WritableLine)
            .Add(charge.BoletoTransaction?.Instructions)
            .Add(charge.BoletoTransaction?.Url)
            .Add(charge.BoletoTransaction?.PaidAt)
            .Add(charge.BoletoTransaction?.Last?.OperationStatus)
            .Add(charge.BoletoTransaction?.Last?.LegacyStatus)
            .Add(charge.BoletoTransaction?.Bank.Code)
            .Add(charge.BoletoTransaction?.Bank.Name)
            .Add(charge.BoletoTransaction?.Receiver?.Name)
            .Add(charge.BoletoTransaction?.Receiver?.DocumentType)
            .Add(charge.BoletoTransaction?.Receiver?.Document)
            .Add(charge.BoletoTransaction?.Customer?.Name)
            .Add(charge.BoletoTransaction?.Customer?.DocumentType)
            .Add(charge.BoletoTransaction?.Customer?.Document)
            .Add(charge.BoletoTransaction?.Customer?.CustomerId)
            .Add(charge.BoletoTransaction?.Customer?.Email)
            .Add(charge.BoletoTransaction?.Customer?.Address?.Street)
            .Add(charge.BoletoTransaction?.Customer?.Address?.StreetNumber)
            .Add(charge.BoletoTransaction?.Customer?.Address?.Extra)
            .Add(charge.BoletoTransaction?.Customer?.Address?.Neighborhood)
            .Add(charge.BoletoTransaction?.Customer?.Address?.PostalCode)
            .Add(charge.BoletoTransaction?.Customer?.Address?.City)
            .Add(charge.BoletoTransaction?.Customer?.Address?.State)
            .Add(charge.BoletoTransaction?.Customer?.Address?.Country)
            .AddSerializableObject(charge.BoletoTransaction?.Details, Options)
            .Add(charge.BoletoTransaction?.Fine?.StartAt)
            .Add(charge.BoletoTransaction?.Fine?.Type)
            .Add(charge.BoletoTransaction?.Fine?.Value)
            .Add(charge.BoletoTransaction?.Interest?.StartAt)
            .Add(charge.BoletoTransaction?.Interest?.Type)
            .Add(charge.BoletoTransaction?.Interest?.Value)
            .AddSerializableObject(charge.BoletoTransaction?.Discounts, Options)
            .AddSerializableObject(charge.BoletoTransaction?.FinancialMovements, Options)
            .Add(charge.PixTransaction?.Type)
            .Add(charge.PixTransaction?.TransactionId)
            .Add(charge.PixTransaction?.E2eId)
            .Add(charge.PixTransaction?.PixKey)
            .Add(charge.PixTransaction?.IsPixSaleKey)
            .Add(charge.PixTransaction?.PixKeyNickname)
            .Add(charge.PixTransaction?.PaidAmount)
            .Add(charge.PixTransaction?.CanceledAmount)
            .Add(charge.PixTransaction?.FeeAmount)
            .Add(charge.PixTransaction?.FullFeeAmount, "0")
            .Add(charge.PixTransaction?.FullMdrAmount, "0")
            .Add(charge.PixTransaction?.FullMdrRefundAmount, "0")
            .Add(charge.PixTransaction?.FullRavAmount, "0")
            .Add(charge.PixTransaction?.FullRavRefundAmount, "0")
            .Add(charge.PixTransaction?.FullFcAmount, "0")
            .Add(charge.PixTransaction?.FullFcRefundAmount, "0")
            .Add(charge.PixTransaction?.ExpireAt)
            .Add(charge.PixTransaction?.PaymentLimitPeriodDays)
            .Add(charge.PixTransaction?.BusinessDaysOnly)
            .Add(charge.PixTransaction?.ExpiresIn)
            .Add(charge.PixTransaction?.RequestForPayer)
            .Add(charge.PixTransaction?.Last?.OperationStatus)
            .Add(charge.PixTransaction?.Last?.LegacyStatus)
            .Add(charge.PixTransaction?.Fine?.StartAt)
            .Add(charge.PixTransaction?.Fine?.Type)
            .Add(charge.PixTransaction?.Fine?.Value)
            .Add(charge.PixTransaction?.Interest?.StartAt)
            .Add(charge.PixTransaction?.Interest?.Type)
            .Add(charge.PixTransaction?.Interest?.Value)
            .Add(charge.PixTransaction?.Interest?.Period)
            .Add(charge.PixTransaction?.Reduction?.StartAt)
            .Add(charge.PixTransaction?.Reduction?.Value)
            .Add(charge.PixTransaction?.Customer.Name)
            .Add(charge.PixTransaction?.Customer.Document)
            .Add(charge.PixTransaction?.Customer.DocumentType)
            .Add(charge.PixTransaction?.Customer.CustomerId)
            .Add(charge.PixTransaction?.Customer.Email)
            .Add(charge.PixTransaction?.Customer.Address?.Country)
            .Add(charge.PixTransaction?.Customer.Address?.City)
            .Add(charge.PixTransaction?.Customer.Address?.Street)
            .Add(charge.PixTransaction?.Customer.Address?.Extra)
            .Add(charge.PixTransaction?.Customer.Address?.StreetNumber)
            .Add(charge.PixTransaction?.Customer.Address?.Neighborhood)
            .Add(charge.PixTransaction?.Customer.Address?.State)
            .Add(charge.PixTransaction?.Customer.Address?.PostalCode)
            .AddSerializableObject(charge.PixTransaction?.Details, Options)
            .Add(charge.PixTransaction?.Payer.Name)
            .Add(charge.PixTransaction?.Payer.DocumentType)
            .Add(charge.PixTransaction?.Payer.Document)
            .Add(charge.PixTransaction?.Payer.Ispb)
            .Add(charge.PixTransaction?.Payer.InstitutionName)
            .AddSerializableObject(charge.PixTransaction?.AdditionalData, Options)
            .Add(charge.PixTransaction?.Terminal.Type)
            .Add(charge.PixTransaction?.Terminal.SerialNumber)
            .AddSerializableObject(charge.PixTransaction?.FinancialMovements, Options)
            .Add(charge.CashTransaction?.Description)
            .Add(charge.CashTransaction?.TransactionId)
            .Add(charge.CashTransaction?.PaidAmount)
            .Add(charge.CashTransaction?.CanceledAmount)
            .Add(charge.CashTransaction?.Customer.Name)
            .Add(charge.CashTransaction?.Customer.CustomerId)
            .Add(charge.CashTransaction?.Customer.DocumentType)
            .Add(charge.CashTransaction?.Customer.Document)
            .Add(charge.CashTransaction?.Customer.Email)
            .Add(charge.CashTransaction?.Customer.Address?.Country)
            .Add(charge.CashTransaction?.Customer.Address?.City)
            .Add(charge.CashTransaction?.Customer.Address?.Street)
            .Add(charge.CashTransaction?.Customer.Address?.Extra)
            .Add(charge.CashTransaction?.Customer.Address?.StreetNumber)
            .Add(charge.CashTransaction?.Customer.Address?.Neighborhood)
            .Add(charge.CashTransaction?.Customer.Address?.State)
            .Add(charge.CashTransaction?.Customer.Address?.PostalCode)
            .Add(charge.CashTransaction?.Last?.OperationStatus)
            .Add(charge.CashTransaction?.Last?.LegacyStatus)
            .AddSerializableObject(charge.CashTransaction?.Details, Options)
            .Add(charge.UpdatedAmount)
            .Add(charge.FullNetAmount, "0")
            .Add(charge.NetAmount, "0");

        return builder.Build();
    }
}
using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Entities.Models.Charge;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Services.ReportTypeConfiguration;

namespace PaymentsDataLayerReports.Application.Workers.Shared.Mappers.Charges;

public class SaleCsvMapper : ISaleCsvMapper<Charge>
{
    private const decimal ONE_HUNDRED = 100m;
    private static readonly CsvSeparatorEnum Separator = ReportTypeConfigurationProvider.GetCsvSeparator(ReportTypeEnum.Sales.Name);
    private static readonly string Header;
    private static readonly System.Globalization.CultureInfo PtBrCulture = new("pt-BR");
    public bool IsCetEnabled { get; set; }
    public int CreatedAtColumnPosition => 6;

    static SaleCsvMapper()
    {
        Header = BuildHeader();
    }

    private static string BuildHeader()
    {
        List<string> headerList =
        [
            "CNPJ",
            "LOJA",
            "IDENTIFICADOR DO PEDIDO",
            "IDENTIFICADOR DA COBRANÇA",
            "IDENTIFICADOR DA TRANSAÇÃO",
            "DATA DA AUTORIZAÇÃO",
            "CÓDIGO DE AUTORIZAÇÃO",
            "STATUS DO ANTIFRAUDE",
            "DATA DE CAPTURA",
            "MEIO DE CAPTURA",
            "NÚMERO DE SÉRIE",
            "NÚMERO DO CARTÃO",
            "FORMA DE PAGAMENTO",
            "BANDEIRA",
            "NÚMERO DE PARCELAS",
            "VALOR BRUTO",
            "DESCONTO DE VENDA",
            "DESCONTO DE ANTECIPAÇÃO",
            "VALOR LÍQUIDO",
            "ADQUIRENTE",
            "ÚLTIMO STATUS",
            "DATA DO ÚLTIMO STATUS"
        ];

        var headerBuilder = new CsvRowBuilder(Separator);
        foreach (var header in headerList)
        {
            headerBuilder.Add(header);
        }

        return headerBuilder.Build();
    }

    public string GetHeader()
    {
        return Header;
    }

    private static string? FormatMonetaryValue(decimal? amountInCents)
    {
        if (amountInCents == null) return null;

        return amountInCents.Value.ToString("N6", PtBrCulture);
    }

    private static decimal? FormatAmount(decimal? amountInCents)
    {
        if (amountInCents == null) return 0m;
        return amountInCents.Value / ONE_HUNDRED;
    }

    private static string ToBrazilianDateTime(DateTimeOffset dateTime)
    {
        var dateFormat = "dd/MM/yyyy HH:mm";
        return TimeZoneInfo.ConvertTimeBySystemTimeZoneId(dateTime, "America/Sao_Paulo").ToString(dateFormat);
    }

    private static decimal CalculateTaxAmount(decimal fullRefundAmount, decimal fullAmount)
    {
        return Math.Abs(fullRefundAmount) - Math.Abs(fullAmount);
    }

    private static string DefineLastStatusDate(IReadOnlyList<dynamic>? details)
    {
        if (details == null || details.Count == 0) return string.Empty;

        var providerDatetime = details.MaxBy(i => i.ProviderDatetime)?.ProviderDatetime;
        if (providerDatetime == null) return string.Empty;

        return ToBrazilianDateTime((DateTimeOffset)providerDatetime);
    }

    private static string? GetTransactionIdentifier(string? gatewayOrderId, string? transactionId)
    {
        return string.IsNullOrWhiteSpace(gatewayOrderId) ? transactionId : gatewayOrderId;
    }

    private static bool IsNotApplicableCetFee(FinancialMovementFee? financialMovementFee)
    {
        return financialMovementFee != null && !"cet".Equals(financialMovementFee.FeeType, StringComparison.InvariantCultureIgnoreCase);
    }

    private static bool IsApplicableCetFee(FinancialMovementFee? financialMovementFee)
    {
        return financialMovementFee != null && "cet".Equals(financialMovementFee.FeeType, StringComparison.InvariantCultureIgnoreCase);
    }

    public static double CalculateAllMdrFeeAmount(List<ChargeFinancialMovement>? financialMovements)
    {
        if (financialMovements == null)
            return 0;

        return (double)(financialMovements
                    .Where(fm => fm.Amount?.DiscountRate != null)
                    .Sum(fm => fm.Amount.DiscountRate!.Amount.GetValueOrDefault()));
    }

    public static double CalculateAllRavFeeAmount(List<ChargeFinancialMovement>? financialMovements)
    {
        if (financialMovements == null)
            return 0;

        return (double)(financialMovements
                    .Where(fm => fm.Amount?.PrepaymentFee != null)
                    .Sum(fm => fm.Amount.PrepaymentFee!.Amount.GetValueOrDefault()));
    }

    public static double CalculateRavTurboFeeAmount(List<ChargeFinancialMovement>? financialMovements)
    {
        if (financialMovements == null)
            return 0;

        return (double)(financialMovements
                    .Where(fm => fm.Amount?.PrepaymentFeeTurbo != null)
                    .Sum(fm => fm.Amount.PrepaymentFeeTurbo!.Amount.GetValueOrDefault()));
    }

    public string BuildRow(Charge charge)
    {
        return charge.PaymentMethod switch
        {
            "card" => BuildRowCard(charge, IsCetEnabled),
            "pix" => BuildRowPix(charge),
            "boleto" => BuildRowBankslip(charge),
            _ => throw new NotSupportedException($"Payment method '{charge.PaymentMethod}' is not supported."),
        };
    }

    private static string BuildRowCard(Charge charge, bool isCET)
    {
        var amount = FormatAmount(charge.Amount);
        var discountMdr = CalculateTaxAmount(
            charge.CardTransaction?.FullMdrRefundAmount ?? 0,
            charge.CardTransaction?.FullMdrAmount ?? 0
        );
        var discountRav = CalculateTaxAmount(
            charge.CardTransaction?.FullRavRefundAmount ?? 0,
            charge.CardTransaction?.FullRavAmount ?? 0
        );
        var chargeback = CalculateTaxAmount(
            FormatAmount(charge.CardTransaction?.ChargebackRefundAmount ?? 0) ?? 0m,
            FormatAmount(charge.CardTransaction?.ChargebackAmount ?? 0) ?? 0m
        );
        var canceledAmount = (FormatAmount(charge.CardTransaction?.CanceledAmount ?? 0) ?? 0m) * -1m;

        var financialMovements = charge.CardTransaction?.FinancialMovements;
        var hasFinancialMovements = financialMovements != null && financialMovements.Count != 0;

        if (isCET && hasFinancialMovements)
        {
            discountMdr = Convert.ToDecimal(CalculateAllMdrFeeAmount(financialMovements));
            discountRav = Convert.ToDecimal(CalculateAllRavFeeAmount(financialMovements))
                        + Convert.ToDecimal(CalculateRavTurboFeeAmount(financialMovements));
        }

        decimal discounts = Math.Abs(discountMdr + discountRav + chargeback + canceledAmount);
        var netAmount = amount - discounts;

        var builder = new CsvRowBuilder(Separator)
            .Add(charge.Merchant.Document)
            .Add(charge.Merchant.PaymentProfileId)
            .Add(charge.OriginId)
            .Add(charge.Id)
            .Add(GetTransactionIdentifier(charge.GatewayOrderId, charge.CardTransaction?.TransactionId))
            .Add(ToBrazilianDateTime(charge.CreatedAt))
            .Add(charge.CardTransaction?.AuthorizationCode)
            .Add(SaleDomainMapper.MapAntifraudResponseStatus(charge.CardTransaction?.Details))
            .Add(charge.CardTransaction?.CaptureDate.HasValue == true
                ? ToBrazilianDateTime(charge.CardTransaction.CaptureDate.Value)
                : ToBrazilianDateTime(charge.CreatedAt))
            .Add(SaleDomainMapper.MapTerminalType(charge.CardTransaction?.Terminal?.Type))
            .Add(charge.CardTransaction?.Terminal?.SerialNumber)
            .Add(SaleDomainMapper.MapCardNumber(charge.CardTransaction?.Card?.FirstSixDigits, charge.CardTransaction?.Card?.LastFourDigits))
            .Add(SaleDomainMapper.MapCardProduct(charge.CardTransaction?.FundingSource, charge.CardTransaction?.Type))
            .Add(charge.CardTransaction?.Card?.Brand)
            .Add(charge.CardTransaction?.Installments ?? 1)
            .Add(FormatMonetaryValue(amount))
            .Add(FormatMonetaryValue(discountMdr))
            .Add(FormatMonetaryValue(discountRav))
            .Add(FormatMonetaryValue(netAmount))
            .Add(SaleDomainMapper.MapAcquirerName(charge.CardTransaction?.Details))
            .Add(SaleDomainMapper.MapLastStatusName(charge.PaymentMethod, charge.Status, charge.CardTransaction?.Details, charge.CardTransaction?.ChargebackAmount, charge.CardTransaction?.ChargebackRefundAmount, charge.CardTransaction?.CanceledAmount ?? 0))
            .Add(DefineLastStatusDate(charge.CardTransaction?.Details));

        return builder.Build();
    }

    private static string BuildRowPix(Charge charge)
    {
        var amount = FormatAmount(charge.PixTransaction?.PaidAmount);
        var discountMdr = FormatAmount(charge.PixTransaction?.FeeAmount);
        var netAmount = amount - discountMdr;

        var builder = new CsvRowBuilder(Separator)
            .Add(charge.Merchant.Document)
            .Add(charge.Merchant.PaymentProfileId)
            .Add(charge.OriginId)
            .Add(charge.Id)
            .Add(GetTransactionIdentifier(charge.GatewayOrderId, charge.PixTransaction?.TransactionId))
            .Add(ToBrazilianDateTime(charge.CreatedAt))
            .Add(charge.PixTransaction?.E2eId)
            .Add(SaleDomainMapper.MapAntifraudResponseStatus(charge.PixTransaction?.Details))
            .Add(ToBrazilianDateTime(charge.CreatedAt))
            .Add(SaleDomainMapper.MapTerminalType(charge.PixTransaction?.Terminal?.Type))
            .Add(charge.PixTransaction?.Terminal?.SerialNumber)
            .Add(null)
            .Add(SaleDomainMapper.MapPixTransactionType(charge.PixTransaction?.Type))
            .Add(null)
            .Add(null)
            .Add(FormatMonetaryValue(amount))
            .Add(FormatMonetaryValue(discountMdr))
            .Add(FormatMonetaryValue(0))
            .Add(FormatMonetaryValue(netAmount))
            .Add(SaleDomainMapper.MapAcquirerName(charge.PixTransaction?.Details))
            .Add(SaleDomainMapper.MapLastStatusName(charge.PaymentMethod, charge.Status, charge.PixTransaction?.Details, null, null, charge.PixTransaction?.CanceledAmount ?? 0))
            .Add(DefineLastStatusDate(charge.PixTransaction?.Details));

        return builder.Build();
    }

    private static string BuildRowBankslip(Charge charge)
    {
        var amount = FormatAmount(charge.Amount);
        var discountMdr = FormatAmount(charge.BoletoTransaction?.FeeAmount);
        var netAmount = amount - discountMdr;

        var builder = new CsvRowBuilder(Separator)
            .Add(charge.Merchant.Document)
            .Add(charge.Merchant.PaymentProfileId)
            .Add(charge.OriginId)
            .Add(charge.Id)
            .Add(GetTransactionIdentifier(charge.GatewayOrderId, charge.BoletoTransaction?.TransactionId))
            .Add(ToBrazilianDateTime(charge.CreatedAt))
            .Add(null)
            .Add(SaleDomainMapper.MapAntifraudResponseStatus(charge.BoletoTransaction?.Details))
            .Add(ToBrazilianDateTime(charge.CreatedAt))
            .Add("Ecommerce")
            .Add(null)
            .Add(null)
            .Add("Boleto")
            .Add(charge.BoletoTransaction?.Bank?.Name)
            .Add(1)
            .Add(FormatMonetaryValue(amount))
            .Add(FormatMonetaryValue(discountMdr))
            .Add(FormatMonetaryValue(0))
            .Add(FormatMonetaryValue(netAmount))
            .Add(SaleDomainMapper.MapAcquirerName(charge.BoletoTransaction?.Details))
            .Add(SaleDomainMapper.MapLastStatusName(charge.PaymentMethod, charge.Status, charge.BoletoTransaction?.Details, null, null, charge.BoletoTransaction?.CanceledAmount ?? 0))
            .Add(DefineLastStatusDate(charge.BoletoTransaction?.Details));

        return builder.Build();
    }
}

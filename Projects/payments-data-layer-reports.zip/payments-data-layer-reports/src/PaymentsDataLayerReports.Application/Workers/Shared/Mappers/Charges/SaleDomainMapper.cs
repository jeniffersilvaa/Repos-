namespace PaymentsDataLayerReports.Application.Workers.Shared.Mappers.Charges;

public static class SaleDomainMapper
{
    public static string MapCardEntryMode(string cardEntryMode)
    {
        return cardEntryMode switch
        {
            "emv_contactless" => "Cartão por aproximação",
            "emv" => "Cartão inserido na maquininha",
            "magstripe" or "magstripe_contactless" => "Tarja magnética",
            "tap_phone" => "Transações com Tap",
            "optical_code_consumer" => "Código gerado pelo consumidor",
            "on_file" => "Recorrência",
            "manual" => "Transação ecommerce",
            _ => "Outros"
        };
    }

    public static string MapTransactionType(string fundingSource)
    {
        return fundingSource switch
        {
            "credit" => "Crédito",
            "debit" => "Débito",
            "prepaid" => "Pré-pago",
            _ => fundingSource
        };
    }

    public static string MapCardProductTon(string cardTransactionType)
    {
        return cardTransactionType switch
        {
            "credit" => "Cartão de Crédito",
            "debit" => "Cartão de Débito",
            "voucher" => "Voucher",
            _ => cardTransactionType
        };
    }

    public static string MapCardProduct(string cardFundingSource, string cardType)
    {
        return cardFundingSource switch
        {
            "prepaid" when string.Equals(cardType, "debit", StringComparison.Ordinal) => "Debito Pre-pago",
            "prepaid" when string.Equals(cardType, "credit", StringComparison.Ordinal) => "Credito Pre-pago",
            "prepaid" when string.Equals(cardType, "voucher", StringComparison.Ordinal) => "Voucher",
            "credit" => "Credito",
            "debit" => "Debito",
            _ => cardFundingSource
        };
    }

    public static string MapPixTransactionType(string pixTransactionType)
    {
        return pixTransactionType switch
        {
            "dynamic" => "Pix QRcode",
            "static" => "Pix QRcode",
            "sale_transfer" => "Transferência por PIX",
            _ => "Outros"
        };
    }

    public static string MapCardNumber(string cardFirstSixDigits, string cardLastFourDigits)
    {
        return string.Concat(cardFirstSixDigits, "******", cardLastFourDigits);
    }

    public static string MapTerminalType(string cardTransactionTerminalType)
    {
        return cardTransactionTerminalType switch
        {
            "none" or "mail_telephone" or "standalone_mobile" or "integrated_mobile" or "semi_integrated_mobile" or "website" or "app" => "E-commerce",
            "standalone_device" or "integrated_solution" => "POS",
            "semi_integrated_solution" => "TEF",
            "prepaid" => "Pre-pago",
            "tap" => "TAP",
            _ => cardTransactionTerminalType
        };
    }

    public static string MapLastStatusName(string PaymentMethod, string Status, IReadOnlyList<dynamic>? Operations, int? ChargebackAmount, int? ChargebackRefundAmount, int CanceledAmount)
    {
        if (string.Equals(Status, "paid", StringComparison.Ordinal))
        {
            if (string.Equals(PaymentMethod, "card", StringComparison.Ordinal))
            {
                var chargebackDifference = (ChargebackAmount ?? 0) - (ChargebackRefundAmount ?? 0);
                if (chargebackDifference != 0) return "Parte contestada";
                if (CanceledAmount != 0) return "Parte cancelada";
            }
            return "Aprovada";
        }

        if (string.Equals(Status, "canceled", StringComparison.Ordinal))
        {
            if (string.Equals(PaymentMethod, "card", StringComparison.Ordinal))
            {
                if (Operations is { Count: > 0 })
                {
                    foreach (var operation in Operations)
                    {
                        if (operation.Operation == "cancel" && operation.OperationReason != "CustomerCancellation")
                            return "Falha na transacao";
                    }
                }
            }
            return "Cancelada";
        }

        if (string.Equals(Status, "chargeback", StringComparison.Ordinal)) return "Contestada";
        if (string.Equals(Status, "authorized", StringComparison.Ordinal)) return "Autorizada";

        return Status;
    }

    public static string MapStatusTon(string status)
    {
        return status switch
        {
            "processing" => "Processando",
            "authorized" => "Autorizada",
            "paid" => "Paga",
            "refunded" => "Estornada",
            "canceled" => "Cancelada",
            "waiting_payment" => "Aguardando pagamento",
            "pending_refund" => "Aguardando estorno",
            "refused" => "Recusada",
            "chargeback" => "Chargeback",
            _ => "Outros"
        };
    }

    public static string MapAcquirerName(IReadOnlyList<dynamic>? details)
    {
        return GetLastValidValue(details, d => d?.Acquirer?.Name?.ToString());
    }

    public static string MapAntifraudResponseStatus(IReadOnlyList<dynamic>? details)
    {
        return GetLastValidValue(details, d => d?.AntifraudResponse?.Status?.ToString());
    }

    private static string GetLastValidValue(IReadOnlyList<dynamic>? details, Func<dynamic, string?> valueSelector)
    {
        if (details == null || details.Count == 0) return string.Empty;

        return details
            .Select(detail =>
            {
                try
                {
                    return valueSelector(detail);
                }
                catch
                {
                    return null;
                }
            })
            .LastOrDefault(value => !string.IsNullOrWhiteSpace(value)) ?? string.Empty;
    }
}
using System.Text.Json;
using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Services.ReportTypeConfiguration;

namespace PaymentsDataLayerReports.Application.Workers.Shared.Mappers.Charges;

public class SaleTonCsvMapper : ISaleCsvMapper<Charge>
{
    private const decimal ONE_HUNDRED = 100m;
    private static readonly CsvSeparatorEnum Separator = ReportTypeConfigurationProvider.GetCsvSeparator(ReportTypeEnum.SalesTon.Name);
    private static readonly string Header;
    private static readonly JsonSerializerOptions Options = SerializerOptions.Options;
    private static readonly System.Globalization.CultureInfo PtBrCulture = new("pt-BR");
    public bool IsCetEnabled { get; set; }
    public int CreatedAtColumnPosition => 2;

    static SaleTonCsvMapper()
    {
        Header = BuildHeader();
    }

    private static string BuildHeader()
    {
        List<string> headerList =
        [
            "Id da transação",
            "Data da transação",
            "Valor",
            "Taxa",
            "Desconto",
            "Valor recebido",
            "Status",
            "Nome do titular",
            "Bandeira",
            "Método de pagamento",
            "Parcelas",
            "Cartão(últimos 4 dígitos)",
            "Método de captura",
            "Tipo de cartão",
            "Nº de série"
        ];

        var headerBuilder = new CsvRowBuilder(Separator);
        foreach (var header in headerList)
        {
            headerBuilder.Add(header);
        }

        return headerBuilder.Build();
    }

    public string GetHeader()
    {
        return Header;
    }

    private static string? FormatMonetaryValue(decimal? amountInCents)
    {
        if (amountInCents == null) return null;
        return amountInCents.Value.ToString("N2", PtBrCulture);
    }

    private static decimal FormatAmount(decimal? amountInCents)
    {
        if (amountInCents == null) return 0m;
        return amountInCents.Value / ONE_HUNDRED; ;
    }

    private static string ToBrazilianDateTime(DateTimeOffset dateTime)
    {
        var dateFormat = "dd/MM/yyyy HH:mm";
        return TimeZoneInfo.ConvertTimeBySystemTimeZoneId(dateTime, "America/Sao_Paulo").ToString(dateFormat);
    }

    private static decimal CalculateTaxAmount(decimal fullRefundAmount, decimal fullAmount)
    {
        return Math.Abs(fullRefundAmount) - Math.Abs(fullAmount);
    }

    private static string DefineLastStatusDate(IReadOnlyList<dynamic>? details)
    {
        if (details == null || details.Count == 0) return string.Empty;

        return ToBrazilianDateTime(details.OrderBy(i => i.ProviderDatetime).LastOrDefault()?.ProviderDatetime);
    }

    private static decimal CalculatePercentageFee(decimal amount, decimal discount)
    {
        decimal fee = Math.Abs(discount) / Math.Abs(amount);
        return Math.Round(fee * 100, 2);
    }

    public string? BuildRow(Charge charge)
    {
        return charge.PaymentMethod switch
        {
            "card" => BuildRowCard(charge),
            "pix" => BuildRowPix(charge),
            "boleto" => null,
            _ => throw new NotSupportedException($"Payment method '{charge.PaymentMethod}' is not supported."),
        };
    }

    protected static string BuildRowCard(Charge charge)
    {
        var amount = FormatAmount(charge.Amount);
        decimal discount = FormatAmount(charge.CardTransaction.FeeAmount);
        var netAmount = amount - discount;

        var builder = new CsvRowBuilder(Separator)
            .Add(charge.Id)
            .Add(ToBrazilianDateTime(charge.CreatedAt))
            .Add($"R$ {FormatMonetaryValue(amount)}")
            .Add($"{CalculatePercentageFee(amount, discount)}%")
            .Add($"R$ {FormatMonetaryValue(discount)}")
            .Add($"R$ {FormatMonetaryValue(netAmount)}")
            .Add(SaleDomainMapper.MapStatusTon(charge.Status))
            .Add(charge.CardTransaction?.Card.HolderName)
            .Add(charge.CardTransaction?.Card.Brand)
            .Add(SaleDomainMapper.MapCardProductTon(charge.CardTransaction?.Type))
            .Add(charge.CardTransaction?.Installments)
            .Add($"{charge.CardTransaction?.Card.LastFourDigits}")
            .Add(SaleDomainMapper.MapCardEntryMode(charge.CardTransaction?.Card.EntryMode))
            .Add(SaleDomainMapper.MapTransactionType(charge.CardTransaction?.FundingSource))
            .Add(charge.CardTransaction?.Terminal.SerialNumber);

        return builder.Build();
    }

    protected static string BuildRowPix(Charge charge)
    {
        var amount = FormatAmount(charge.PixTransaction?.PaidAmount);
        var discount = FormatAmount(charge.PixTransaction?.FeeAmount);
        var netAmount = amount - discount;

        var builder = new CsvRowBuilder(Separator)
            .Add(charge.Id)
            .Add(ToBrazilianDateTime(charge.CreatedAt))
            .Add($"R$ {FormatMonetaryValue(amount)}")
            .Add($"{CalculatePercentageFee(amount, discount)}%")
            .Add($"R$ {FormatMonetaryValue(discount)}")
            .Add($"R$ {FormatMonetaryValue(netAmount)}")
            .Add(SaleDomainMapper.MapStatusTon(charge.Status))
            .Add(charge.PixTransaction?.Payer.Name)
            .Add(null)
            .Add("Pix")
            .Add(null)
            .Add(null)
            .Add(SaleDomainMapper.MapCardEntryMode(charge.PixTransaction?.Terminal.Type))
            .Add(SaleDomainMapper.MapPixTransactionType(charge.PixTransaction?.Type))
            .Add(charge.PixTransaction?.Terminal.SerialNumber);

        return builder.Build();
    }
}
using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Entities.Models.FinMov;
using PaymentsDataLayerReports.Application.Workers.Shared.FinMov;

namespace PaymentsDataLayerReports.Application.Workers.Shared.Mappers.FinMov;

public class ReceivablesOneStoneCsvMapper : ICsvMapper<FinancialMovement>
{
    public string GetHeader()
    {
        return ReceivablesOneStoneHelper.GetHeader();
    }

    public string BuildRow(FinancialMovement financialMovement)
    {
        return ReceivablesOneStoneHelper.BuildRow(new ReceivablesOneStoneRowData(
            Document: financialMovement.PaymentOwner?.Document,
            PaymentProfileId: financialMovement.PaymentOwner?.PaymentProfileId,
            TransactionKey: financialMovement.Transaction?.Key,
            TransactionCaptureDate: financialMovement.Transaction?.CaptureDate,
            Operation: financialMovement.Operation,
            PointOfInteractionType: financialMovement.Transaction?.PointOfInteractionType,
            SettlementWalletDescription: financialMovement.Settlement?.Wallet?.Description,
            TransactionAccountFundingSource: financialMovement.Transaction?.AccountFundingSource,
            TransactionBrand: financialMovement.Transaction?.Brand,
            TransactionInstallmentNumber: financialMovement.Transaction?.InstallmentNumber ?? 1,
            TransactionInstallmentQuantity: financialMovement.Transaction?.InstallmentQuantity ?? 1,
            AmountGross: financialMovement.Amount?.Gross,
            AmountNet: financialMovement.Amount?.Net,
            DiscountRate: financialMovement.Amount?.DiscountRate,
            PrepaymentFee: financialMovement.Amount?.PrepaymentFee,
            PrepaymentFeeTurbo: financialMovement.Amount?.PrepaymentFeeTurbo,
            OriginalDueDate: financialMovement.OriginalDueDate,
            CurrentDueDate: financialMovement.CurrentDueDate,
            SettlementStatus: financialMovement.Settlement?.Status,
            UpdatedAt: financialMovement.UpdatedAt
        ));
    }
}

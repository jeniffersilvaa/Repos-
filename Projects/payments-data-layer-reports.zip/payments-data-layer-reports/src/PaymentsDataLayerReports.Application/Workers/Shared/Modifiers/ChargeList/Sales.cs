using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;
using PaymentsDataLayerReports.Application.Workers.Shared.EntityMappers;

namespace PaymentsDataLayerReports.Application.Workers.Shared.Modifiers.ChargeList;

public class SalesModifier(ISaleCsvMapper<Charge> mapper) : ISaleCsvMapper<CsvRow>
{
    public bool IsCetEnabled { get; set; }
    public int CreatedAtColumnPosition => mapper.CreatedAtColumnPosition;

    public string GetHeader()
    {
        return mapper.GetHeader();
    }

    public string? BuildRow(CsvRow chargeCsvRow)
    {
        Charge charge = ChargeEntityMapper.MapToEntity(chargeCsvRow);
        return mapper.BuildRow(charge);
    }
}

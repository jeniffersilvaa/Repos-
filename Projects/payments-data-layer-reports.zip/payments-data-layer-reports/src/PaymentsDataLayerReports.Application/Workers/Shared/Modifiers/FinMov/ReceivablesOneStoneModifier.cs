using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Entities.Models.FinMov;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.FinMovList;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;
using PaymentsDataLayerReports.Application.Workers.Shared.FinMov;

namespace PaymentsDataLayerReports.Application.Workers.Shared.Modifiers.FinMov;

public class ReceivablesOneStoneModifier : ICsvMapper<CsvRow>
{
    public string GetHeader()
    {
        return ReceivablesOneStoneHelper.GetHeader();
    }

    public string BuildRow(CsvRow finMovCsvRow)
    {
        var headerIndex = FinMovListReportHeader.HeaderIndex;

        return ReceivablesOneStoneHelper.BuildRow(new ReceivablesOneStoneRowData(
            Document: finMovCsvRow.GetField<string>(headerIndex, "payment_owner__document"),
            PaymentProfileId: finMovCsvRow.GetField<string>(headerIndex, "payment_owner__payment_profile_id"),
            TransactionKey: finMovCsvRow.GetField<string>(headerIndex, "transaction__key"),
            TransactionCaptureDate: finMovCsvRow.GetField<string>(headerIndex, "transaction__capture_date"),
            Operation: finMovCsvRow.GetField<string>(headerIndex, "operation"),
            PointOfInteractionType: finMovCsvRow.GetField<string>(headerIndex, "transaction__point_of_interaction_type"),
            SettlementWalletDescription: finMovCsvRow.GetField<string>(headerIndex, "settlement__wallet__description"),
            TransactionAccountFundingSource: finMovCsvRow.GetField<string>(headerIndex, "transaction__account_funding_source"),
            TransactionBrand: finMovCsvRow.GetField<string>(headerIndex, "transaction__brand"),
            TransactionInstallmentNumber: finMovCsvRow.GetField<int?>(headerIndex, "transaction__installment_number") ?? 1,
            TransactionInstallmentQuantity: finMovCsvRow.GetField<int?>(headerIndex, "transaction__installment_quantity") ?? 1,
            AmountGross: finMovCsvRow.GetField<decimal?>(headerIndex, "amount__gross"),
            AmountNet: finMovCsvRow.GetField<decimal?>(headerIndex, "amount__net"),
            DiscountRate: new FeeModel(
                Amount: finMovCsvRow.GetField<decimal?>(headerIndex, "amount__discount_rate__amount"),
                Fee: finMovCsvRow.GetField<decimal?>(headerIndex, "amount__discount_rate__fee"),
                EffectiveFee: finMovCsvRow.GetField<decimal?>(headerIndex, "amount__discount_rate__effective_fee"),
                FeeType: finMovCsvRow.GetField<string>(headerIndex, "amount__discount_rate__fee_type")
            ),
            PrepaymentFee: new FeeModel(
                Amount: finMovCsvRow.GetField<decimal?>(headerIndex, "amount__prepayment_fee__amount"),
                Fee: finMovCsvRow.GetField<decimal?>(headerIndex, "amount__prepayment_fee__fee"),
                EffectiveFee: finMovCsvRow.GetField<decimal?>(headerIndex, "amount__prepayment_fee__effective_fee"),
                FeeType: finMovCsvRow.GetField<string>(headerIndex, "amount__prepayment_fee__fee_type")
            ),
            PrepaymentFeeTurbo: new FeeModel(
                Amount: finMovCsvRow.GetField<decimal?>(headerIndex, "amount__prepayment_fee_turbo__amount"),
                Fee: finMovCsvRow.GetField<decimal?>(headerIndex, "amount__prepayment_fee_turbo__fee"),
                EffectiveFee: finMovCsvRow.GetField<decimal?>(headerIndex, "amount__prepayment_fee_turbo__effective_fee"),
                FeeType: finMovCsvRow.GetField<string>(headerIndex, "amount__prepayment_fee_turbo__fee_type")
            ),
            OriginalDueDate: finMovCsvRow.GetField<string>(headerIndex, "original_due_date"),
            CurrentDueDate: finMovCsvRow.GetField<string>(headerIndex, "current_due_date"),
            SettlementStatus: finMovCsvRow.GetField<string>(headerIndex, "settlement__status"),
            UpdatedAt: finMovCsvRow.GetField<string>(headerIndex, "updated_at")
        ));
    }
}

using System.Text.Json;
using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Entities.Models.FinMov;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Extensions;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.FinMovList;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;
using PaymentsDataLayerReports.Application.Workers.FinMovReportWorker;

namespace PaymentsDataLayerReports.Application.Workers.Shared.Modifiers.FinMov;

public class ReceivablesModifier
{
    private const int CPF_LENGTH = 11;
    private const int CNPJ_LENGTH = 14;
    private const string ZERO_FEE = "0,000000";
    private static readonly string Header;
    private static readonly JsonSerializerOptions Options = SerializerOptions.Options;
    private static readonly System.Globalization.CultureInfo PtBrCulture = new("pt-BR");

    static ReceivablesModifier()
    {
        Header = BuildHeader();
    }

    public static string GetHeader()
    {
        return Header;
    }

    private static string BuildHeader()
    {
        List<string> headerList = [
            "DOCUMENTO",
            "STONECODE",
            "CATEGORIA",
            "DATA DA VENDA",
            "DATA DE VENCIMENTO",
            "DATA DE VENCIMENTO ORIGINAL",
            "BANDEIRA",
            "PRODUTO",
            "STONE ID",
            "QTD DE PARCELAS",
            "Nº DA PARCELA",
            "VALOR BRUTO",
            "VALOR LÍQUIDO",
            "DESCONTO DE MDR",
            "DESCONTO DE ANTECIPAÇÃO",
            "DESCONTO UNIFICADO",
            "ÚLTIMO STATUS",
            "DATA DO ÚLTIMO STATUS"
        ];

        var headerBuilder = new CsvRowBuilder(CsvSeparatorEnum.Semicolon);
        foreach (var header in headerList)
        {
            headerBuilder.Add(header);
        }

        return headerBuilder.Build();
    }

    private static string? FormatDocument(string? document)
    {
        if (string.IsNullOrWhiteSpace(document)) return document;

        if (document.Length == CPF_LENGTH) return string.Create(14, document, (span, doc) =>
            {
                doc.AsSpan(0, 3).CopyTo(span[0..3]);
                span[3] = '.';
                doc.AsSpan(3, 3).CopyTo(span[4..7]);
                span[7] = '.';
                doc.AsSpan(6, 3).CopyTo(span[8..11]);
                span[11] = '-';
                doc.AsSpan(9, 2).CopyTo(span[12..14]);
            });

        if (document.Length == CNPJ_LENGTH) return string.Create(18, document, (span, doc) =>
            {
                doc.AsSpan(0, 2).CopyTo(span[0..2]);
                span[2] = '.';
                doc.AsSpan(2, 3).CopyTo(span[3..6]);
                span[6] = '.';
                doc.AsSpan(5, 3).CopyTo(span[7..10]);
                span[10] = '/';
                doc.AsSpan(8, 4).CopyTo(span[11..15]);
                span[15] = '-';
                doc.AsSpan(12, 2).CopyTo(span[16..18]);
            });

        return document;
    }

    private static string? FormatMonetaryValue(decimal? amountInCents)
    {
        if (amountInCents == null) return null;
        return amountInCents.Value.ToString("N6", PtBrCulture);
    }

    private static string? ComputeFeeAmount(FeeModel? fee, bool isChargeback = false, bool isFormated = false)
    {
        if (fee?.Amount == null) return null;
        if (isChargeback || string.Equals(fee?.FeeType, "CET", StringComparison.OrdinalIgnoreCase)) return ZERO_FEE;
        return FormatMonetaryValue(fee!.Amount);
    }

    private static string? ComputeAnticipationDiscount(FeeModel? prepaymentFee, FeeModel? prepaymentFeeTurbo, bool isChargeback = false)
    {
        var regularAmount = GetRegularFeeValue(prepaymentFee, isChargeback);
        var turboAmount = GetTurboFeeValue(prepaymentFeeTurbo, isChargeback);

        if (regularAmount == null && turboAmount == null) return null;

        var total = (regularAmount ?? 0) + (turboAmount ?? 0);
        return FormatMonetaryValue(total);
    }

    private static decimal? GetRegularFeeValue(FeeModel? fee, bool isChargeback)
    {
        if (fee?.Amount == null) return null;
        if (isChargeback || string.Equals(fee?.FeeType, "CET", StringComparison.OrdinalIgnoreCase)) return 0;
        return fee!.Amount;
    }

    private static decimal? GetTurboFeeValue(FeeModel? fee, bool isChargeback)
    {
        if (fee == null) return null;
        if (isChargeback) return 0;
        return fee.Amount;
    }

    private static string? ComputeUnifiedDiscountAmount(FeeModel? discountRate, FeeModel? prepaymentFee, bool isChargeback = false)
    {
        var isDiscountRateCET = string.Equals(discountRate?.FeeType, "CET", StringComparison.OrdinalIgnoreCase);
        var isPrepaymentFeeCET = string.Equals(prepaymentFee?.FeeType, "CET", StringComparison.OrdinalIgnoreCase);

        if (isChargeback || (!isDiscountRateCET && !isPrepaymentFeeCET))
            return ZERO_FEE;

        decimal totalAmount = 0;

        if (isDiscountRateCET && discountRate?.Amount != null)
            totalAmount += discountRate.Amount.Value;

        if (isPrepaymentFeeCET && prepaymentFee?.Amount != null)
            totalAmount += prepaymentFee.Amount.Value;

        return FormatMonetaryValue(totalAmount);
    }

    public static string BuildRow(FinancialMovement financialMovement)
    {
        var isChargeback = financialMovement.Operation?.Contains("chargeback", StringComparison.OrdinalIgnoreCase) ?? false;

        var rowBuilder = new CsvRowBuilder(CsvSeparatorEnum.Semicolon)
            .Add(FormatDocument(financialMovement.PaymentOwner?.Document))
            .Add(financialMovement.PaymentOwner?.AffiliationCode)
            .Add(FinMovDomainMappers.TranslateCategory(financialMovement.Operation))
            .Add(DateTime.TryParse(financialMovement.Transaction?.CaptureDate, out var captDate) ? captDate.ToBrazilianTimeZone().ToString("dd/MM/yyyy HH:mm:ss") : financialMovement.Transaction?.CaptureDate)
            .Add(DateTime.TryParse(financialMovement.CurrentDueDate, out var currentDueDate) ? currentDueDate.ToString("dd/MM/yyyy") : financialMovement.CurrentDueDate)
            .Add(DateTime.TryParse(financialMovement.OriginalDueDate, out var originalDueDate) ? originalDueDate.ToString("dd/MM/yyyy") : financialMovement.OriginalDueDate)
            .Add(FinMovDomainMappers.MapTransactionBrand(financialMovement.Transaction?.Brand, financialMovement.Settlement?.Wallet?.Description))
            .Add(FinMovDomainMappers.MapWalletToProduct(financialMovement.Settlement?.Wallet?.Description, financialMovement.Transaction?.AccountFundingSource))
            .Add(financialMovement.Transaction?.Key)
            .Add(financialMovement.Transaction?.InstallmentQuantity ?? 1)
            .Add(financialMovement.Transaction?.InstallmentNumber ?? 1)
            .Add(isChargeback ? FormatMonetaryValue(financialMovement.Amount?.Net) : FormatMonetaryValue(financialMovement.Amount?.Gross))
            .Add(FormatMonetaryValue(financialMovement.Amount?.Net))
            .Add(ComputeFeeAmount(financialMovement.Amount?.DiscountRate, isChargeback))
            .Add(ComputeAnticipationDiscount(financialMovement.Amount?.PrepaymentFee, financialMovement.Amount?.PrepaymentFeeTurbo, isChargeback))
            .Add(ComputeUnifiedDiscountAmount(financialMovement.Amount?.DiscountRate, financialMovement.Amount?.PrepaymentFee, isChargeback))
            .Add(FinMovDomainMappers.MapSettlementStatus(financialMovement.Settlement?.Status))
            .Add(DateTime.TryParse(financialMovement.CurrentDueDate, out var lastStatusDate) ? lastStatusDate.ToString("dd/MM/yyyy HH:mm:ss") : financialMovement.CurrentDueDate);

        return rowBuilder.Build();
    }

    public static string BuildRow(CsvRow finMovCsvRow)
    {
        var headerIndex = FinMovListReportHeader.HeaderIndex;

        var currentDueDate = finMovCsvRow.GetField<string>(headerIndex, "current_due_date");
        var originalDueDate = finMovCsvRow.GetField<string>(headerIndex, "original_due_date");
        var category = finMovCsvRow.GetField<string>(headerIndex, "operation");
        var isChargeback = category?.Contains("chargeback", StringComparison.OrdinalIgnoreCase) ?? false;
        var paymentOwnerDocument = finMovCsvRow.GetField<string>(headerIndex, "payment_owner__document");
        var paymentOwnerAffiliationCode = finMovCsvRow.GetField<string>(headerIndex, "payment_owner__affiliation_code");
        var settlementWalletDescription = finMovCsvRow.GetField<string>(headerIndex, "settlement__wallet__description");
        var settlementStatus = finMovCsvRow.GetField<string>(headerIndex, "settlement__status");
        var transactionCaptDate = finMovCsvRow.GetField<string>(headerIndex, "transaction__capture_date");
        var transactionBrand = finMovCsvRow.GetField<string>(headerIndex, "transaction__brand");
        var transactionAccountFundingSource = finMovCsvRow.GetField<string>(headerIndex, "transaction__account_funding_source");
        var transactionKey = finMovCsvRow.GetField<string>(headerIndex, "transaction__key");
        var transactionInstallmentQuantity = finMovCsvRow.GetField<int?>(headerIndex, "transaction__installment_quantity") ?? 1;
        var transactionInstallmentNumber = finMovCsvRow.GetField<int?>(headerIndex, "transaction__installment_number") ?? 1;
        var amountNet = finMovCsvRow.GetField<decimal?>(headerIndex, "amount__net");
        var amountGross = finMovCsvRow.GetField<decimal?>(headerIndex, "amount__gross");
        var discountRate = new FeeModel(
            Amount: finMovCsvRow.GetField<decimal?>(headerIndex, "amount__discount_rate__amount"),
            Fee: finMovCsvRow.GetField<decimal?>(headerIndex, "amount__discount_rate__fee"),
            EffectiveFee: finMovCsvRow.GetField<decimal?>(headerIndex, "amount__discount_rate__effective_fee"),
            FeeType: finMovCsvRow.GetField<string>(headerIndex, "amount__discount_rate__fee_type")
        );
        var prepaymentFee = new FeeModel(
            Amount: finMovCsvRow.GetField<decimal?>(headerIndex, "amount__prepayment_fee__amount"),
            Fee: finMovCsvRow.GetField<decimal?>(headerIndex, "amount__prepayment_fee__fee"),
            EffectiveFee: finMovCsvRow.GetField<decimal?>(headerIndex, "amount__prepayment_fee__effective_fee"),
            FeeType: finMovCsvRow.GetField<string>(headerIndex, "amount__prepayment_fee__fee_type")
        );
        var prepaymentFeeTurbo = new FeeModel(
            Amount: finMovCsvRow.GetField<decimal?>(headerIndex, "amount__prepayment_fee_turbo__amount"),
            Fee: finMovCsvRow.GetField<decimal?>(headerIndex, "amount__prepayment_fee_turbo__fee"),
            EffectiveFee: finMovCsvRow.GetField<decimal?>(headerIndex, "amount__prepayment_fee_turbo__effective_fee"),
            FeeType: finMovCsvRow.GetField<string>(headerIndex, "amount__prepayment_fee_turbo__fee_type")
        );

        var rowBuilder = new CsvRowBuilder(CsvSeparatorEnum.Semicolon)
            .Add(FormatDocument(paymentOwnerDocument))
            .Add(paymentOwnerAffiliationCode)
            .Add(FinMovDomainMappers.TranslateCategory(category))
            .Add(DateTime.TryParse(transactionCaptDate, out var captDate) ? captDate.ToBrazilianTimeZone().ToString("dd/MM/yyyy HH:mm:ss") : transactionCaptDate)
            .Add(DateTime.TryParse(currentDueDate, out var currentDueDateParsed) ? currentDueDateParsed.ToString("dd/MM/yyyy") : currentDueDate)
            .Add(DateTime.TryParse(originalDueDate, out var originalDueDateParsed) ? originalDueDateParsed.ToString("dd/MM/yyyy") : originalDueDate)
            .Add(FinMovDomainMappers.MapTransactionBrand(transactionBrand, settlementWalletDescription))
            .Add(FinMovDomainMappers.MapWalletToProduct(settlementWalletDescription, transactionAccountFundingSource))
            .Add(transactionKey)
            .Add(transactionInstallmentQuantity)
            .Add(transactionInstallmentNumber)
            .Add(isChargeback ? FormatMonetaryValue(amountNet) : FormatMonetaryValue(amountGross))
            .Add(FormatMonetaryValue(amountNet))
            .Add(ComputeFeeAmount(discountRate, isChargeback))
            .Add(ComputeAnticipationDiscount(prepaymentFee, prepaymentFeeTurbo, isChargeback))
            .Add(ComputeUnifiedDiscountAmount(discountRate, prepaymentFee, isChargeback))
            .Add(FinMovDomainMappers.MapSettlementStatus(settlementStatus))
            .Add(DateTime.TryParse(currentDueDate, out var lastStatusDate) ? lastStatusDate.ToString("dd/MM/yyyy HH:mm:ss") : currentDueDate);

        return rowBuilder.Build();
    }
}
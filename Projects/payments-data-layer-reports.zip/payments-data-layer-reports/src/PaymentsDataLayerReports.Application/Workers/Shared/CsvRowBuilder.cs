using System.Globalization;
using System.Text;
using System.Text.Json;
using PaymentsDataLayerReports.Application.Constants;
using PaymentsDataLayerReports.Application.Enums;

namespace PaymentsDataLayerReports.Application.Workers.Shared;

interface ICsvRowBuilder
{
    ICsvRowBuilder Add(string? value);
    ICsvRowBuilder Add<T>(T? value, string? defaultValue = null);
    ICsvRowBuilder AddDateTimeOffset(DateTimeOffset? value, string format);
    ICsvRowBuilder AddSerializableObject(object? value, JsonSerializerOptions? options = null);
    string Build();
}

class CsvRowBuilder(CsvSeparatorEnum separator = CsvSeparatorEnum.Comma) : ICsvRowBuilder
{
    private readonly StringBuilder _stringBuilder = new();
    private readonly CsvSeparatorEnum _separator = separator;
    private bool _isFirstColumn = true;

    private void AppendSeparator()
    {
        if (_isFirstColumn)
        {
            _isFirstColumn = false;
        }
        else
        {
            _stringBuilder.Append(CsvSeparatorConstants.GetSeparator(_separator));
        }
    }

    private void AppendField(string? field)
    {
        AppendSeparator();

        if (string.IsNullOrEmpty(field))
        {
            return;
        }

        if (_separator == CsvSeparatorEnum.Semicolon)
        {
            _stringBuilder.Append(field);
        }
        else
        {
            _stringBuilder.Append('"');
            _stringBuilder.Append(field.Replace("\"", "\"\""));
            _stringBuilder.Append('"');
        }
    }

    public ICsvRowBuilder Add(string? value)
    {
        AppendField(value);
        return this;
    }

    public ICsvRowBuilder Add<T>(T? value, string? defaultValue = null)
    {
        if (value == null)
        {
            AppendField(defaultValue);
            return this;
        }

        string stringValue;
        if (value is IFormattable formattable)
        {
            stringValue = formattable.ToString(null, CultureInfo.InvariantCulture);
        }
        else
        {
            stringValue = value?.ToString() ?? string.Empty;
        }

        AppendField(stringValue);
        return this;
    }

    public ICsvRowBuilder AddDateTimeOffset(DateTimeOffset? value, string format = "yyyy-MM-ddTHH:mm:ss.ffffffzzz")
    {
        if (value == null)
        {
            AppendField(null);
        }
        else
        {
            AppendField(value.Value.ToString(format, CultureInfo.InvariantCulture));
        }
        return this;
    }

    public ICsvRowBuilder AddSerializableObject(object? value, JsonSerializerOptions? options = null)
    {
        if (value == null)
        {
            AppendField(null);
        }
        else
        {
            AppendField(JsonSerializer.Serialize(value, options));
        }
        return this;
    }

    public string Build() => _stringBuilder.ToString();
}

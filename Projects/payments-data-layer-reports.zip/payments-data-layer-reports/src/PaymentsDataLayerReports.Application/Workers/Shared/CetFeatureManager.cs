using Microsoft.Extensions.Options;
using PaymentsDataLayerReports.Application.Settings;

namespace PaymentsDataLayerReports.Application.Workers.Shared;

public interface ICetFeatureManager
{
    bool IsCET(string? merchants);
}

public class CetFeatureManager(IOptions<DataLayerReportsSettings> dataLayerReportsSettings) : ICetFeatureManager
{
    private readonly HashSet<string> _merchantsForShowCetFee = ParseMerchants(dataLayerReportsSettings.Value.MerchantsForShowCetFee);

    private static HashSet<string> ParseMerchants(string? input)
    {
        if (string.IsNullOrWhiteSpace(input)) return [];

        return [.. input.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)];
    }

    public bool IsCET(string? merchants)
    {
        if (_merchantsForShowCetFee.Contains("all")) return true;
        if (_merchantsForShowCetFee.Count <= 0 || string.IsNullOrWhiteSpace(merchants)) return false;

        var merchantList = merchants.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

        return merchantList.Any(_merchantsForShowCetFee.Contains);
    }
}

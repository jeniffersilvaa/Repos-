using System.Globalization;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace PaymentsDataLayerReports.Application.Workers.Shared;

public class CustomDateTimeConverter : JsonConverter<DateTime>
{
    private const string DateTimeFormat = "yyyy-MM-dd HH:mm:ss.fff";

    public override DateTime Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
    {
        string? dateString = reader.GetString();
        if (dateString == null ||
            !DateTime.TryParseExact(dateString, DateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime parsedDate))
        {
            throw new JsonException($"Invalid date format. Expected format: '{DateTimeFormat}', but got: '{dateString ?? "null"}'.");
        }
        return parsedDate;
    }

    public override void Write(Utf8JsonWriter writer, DateTime value, JsonSerializerOptions options)
    {
        writer.WriteStringValue(value.ToString(DateTimeFormat, CultureInfo.InvariantCulture));
    }
}
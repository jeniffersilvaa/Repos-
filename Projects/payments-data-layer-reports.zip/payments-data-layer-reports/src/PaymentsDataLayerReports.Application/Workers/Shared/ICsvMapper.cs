namespace PaymentsDataLayerReports.Application.Workers.Shared;

public interface ICsvMapper<T>
{
    string GetHeader();
    string? BuildRow(T entity);
}

public interface ISaleCsvMapper<T> : ICsvMapper<T>
{
    bool IsCetEnabled { get; set; }
    int CreatedAtColumnPosition { get; }
}
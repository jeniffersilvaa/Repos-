﻿using System.Text.Json;

namespace PaymentsDataLayerReports.Application.Workers.Shared;

public static class SerializerOptions
{
    public static readonly JsonSerializerOptions Options = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower,
        Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
        Converters = { new CustomDateTimeConverter() }
    };
}

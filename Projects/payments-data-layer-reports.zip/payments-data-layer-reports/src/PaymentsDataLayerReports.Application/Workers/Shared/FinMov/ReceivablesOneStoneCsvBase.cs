using System.Globalization;
using PaymentsDataLayerReports.Application.Entities.Models.FinMov;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Extensions;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;
using PaymentsDataLayerReports.Application.Workers.FinMovReportWorker;

namespace PaymentsDataLayerReports.Application.Workers.Shared.FinMov;

public static class ReceivablesOneStoneHelper
{
    private const int CPF_LENGTH = 11;
    private const int CNPJ_LENGTH = 14;
    private const string ZERO_FEE = "0,000000";
    private static readonly string Header = BuildHeader();
    private static readonly System.Globalization.CultureInfo PtBrCulture = new("pt-BR");

    public static string GetHeader()
    {
        return Header;
    }

    public static string BuildRow(ReceivablesOneStoneRowData data)
    {
        var isChargeback = data.Operation?.Contains("chargeback", StringComparison.OrdinalIgnoreCase) ?? false;

        var rowBuilder = new CsvRowBuilder(CsvSeparatorEnum.Semicolon)
            .Add(FormatDocument(data.Document))
            .Add(data.PaymentProfileId)
            .Add(data.TransactionKey)
            .Add(DateTime.TryParse(data.CurrentDueDate, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out var currentDueDate) ? currentDueDate.ToString("dd/MM/yyyy") : data.CurrentDueDate)
            .Add(DateTime.TryParse(data.OriginalDueDate, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out var originalDueDate) ? originalDueDate.ToString("dd/MM/yyyy") : data.OriginalDueDate)
            .Add(DateTime.TryParse(data.TransactionCaptureDate, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out var captureDate) ? captureDate.ToBrazilianTimeZone().ToString("dd/MM/yyyy HH:mm:ss") : data.TransactionCaptureDate)
            .Add(FinMovDomainMappers.TranslateCategory(data.Operation))
            .Add(data.PointOfInteractionType)
            .Add(FinMovDomainMappers.MapWalletToProduct(data.SettlementWalletDescription, data.TransactionAccountFundingSource))
            .Add(FinMovDomainMappers.MapTransactionBrand(data.TransactionBrand, data.SettlementWalletDescription))
            .Add(data.TransactionInstallmentNumber)
            .Add(data.TransactionInstallmentQuantity)
            .Add(isChargeback ? FormatMonetaryValue(data.AmountNet) : FormatMonetaryValue(data.AmountGross))
            .Add(ComputeFeeAmount(data.DiscountRate, isChargeback))
            .Add(ComputeAnticipationDiscount(data.PrepaymentFee, data.PrepaymentFeeTurbo, isChargeback))
            .Add(FormatMonetaryValue(data.AmountNet))
            .Add(FinMovDomainMappers.MapSettlementStatus(data.SettlementStatus))
            .Add(DateTime.TryParse(data.UpdatedAt, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out var updatedAt) ? updatedAt.ToBrazilianTimeZone().ToString("dd/MM/yyyy HH:mm:ss") : data.UpdatedAt);

        return rowBuilder.Build();
    }

    private static string BuildHeader()
    {
        List<string> headerList =
        [
            "CNPJ",
            "LOJA",
            "IDENTIFICADOR DA TRANSAÇÃO",
            "DATA DE VENCIMENTO",
            "DATA DE VENCIMENTO ORIGINAL",
            "DATA DE CAPTURA",
            "CATEGORIA",
            "MEIO DE CAPTURA",
            "FORMA DE PAGAMENTO",
            "BANDEIRA",
            "PARCELA",
            "NÚMERO DE PARCELAS",
            "VALOR BRUTO",
            "DESCONTO DE VENDA",
            "DESCONTO DE ANTECIPAÇÃO",
            "VALOR LÍQUIDO",
            "ÚLTIMO STATUS",
            "DATA DO ÚLTIMO STATUS"
        ];

        var headerBuilder = new CsvRowBuilder(CsvSeparatorEnum.Semicolon);
        foreach (var header in headerList)
        {
            headerBuilder.Add(header);
        }

        return headerBuilder.Build();
    }

    private static string? FormatDocument(string? document)
    {
        if (string.IsNullOrWhiteSpace(document)) return document;

        if (document.Length == CPF_LENGTH) return string.Create(14, document, (span, doc) =>
            {
                doc.AsSpan(0, 3).CopyTo(span[0..3]);
                span[3] = '.';
                doc.AsSpan(3, 3).CopyTo(span[4..7]);
                span[7] = '.';
                doc.AsSpan(6, 3).CopyTo(span[8..11]);
                span[11] = '-';
                doc.AsSpan(9, 2).CopyTo(span[12..14]);
            });

        if (document.Length == CNPJ_LENGTH) return string.Create(18, document, (span, doc) =>
            {
                doc.AsSpan(0, 2).CopyTo(span[0..2]);
                span[2] = '.';
                doc.AsSpan(2, 3).CopyTo(span[3..6]);
                span[6] = '.';
                doc.AsSpan(5, 3).CopyTo(span[7..10]);
                span[10] = '/';
                doc.AsSpan(8, 4).CopyTo(span[11..15]);
                span[15] = '-';
                doc.AsSpan(12, 2).CopyTo(span[16..18]);
            });

        return document;
    }

    private static string? FormatMonetaryValue(decimal? amountInCents)
    {
        if (amountInCents == null) return null;
        return amountInCents.Value.ToString("N6", PtBrCulture);
    }

    private static string? ComputeFeeAmount(FeeModel? fee, bool isChargeback = false)
    {
        if (fee?.Amount == null) return null;
        if (isChargeback || string.Equals(fee.FeeType, "CET", StringComparison.OrdinalIgnoreCase)) return ZERO_FEE;
        return FormatMonetaryValue(fee.Amount);
    }

    private static string? ComputeAnticipationDiscount(FeeModel? prepaymentFee, FeeModel? prepaymentFeeTurbo, bool isChargeback = false)
    {
        var regularAmount = GetRegularFeeValue(prepaymentFee, isChargeback);
        var turboAmount = GetTurboFeeValue(prepaymentFeeTurbo, isChargeback);

        if (regularAmount == null && turboAmount == null) return null;

        var total = (regularAmount ?? 0) + (turboAmount ?? 0);
        return FormatMonetaryValue(total);
    }

    private static decimal? GetRegularFeeValue(FeeModel? fee, bool isChargeback)
    {
        if (fee?.Amount == null) return null;
        if (isChargeback || string.Equals(fee.FeeType, "CET", StringComparison.OrdinalIgnoreCase)) return 0;
        return fee.Amount;
    }

    private static decimal? GetTurboFeeValue(FeeModel? fee, bool isChargeback)
    {
        if (fee == null) return null;
        if (isChargeback) return 0;
        return fee.Amount;
    }
}

public sealed record ReceivablesOneStoneRowData(
    string? Document,
    string? PaymentProfileId,
    string? TransactionKey,
    string? TransactionCaptureDate,
    string? Operation,
    string? PointOfInteractionType,
    string? SettlementWalletDescription,
    string? TransactionAccountFundingSource,
    string? TransactionBrand,
    int TransactionInstallmentNumber,
    int TransactionInstallmentQuantity,
    decimal? AmountGross,
    decimal? AmountNet,
    FeeModel? DiscountRate,
    FeeModel? PrepaymentFee,
    FeeModel? PrepaymentFeeTurbo,
    string? OriginalDueDate,
    string? CurrentDueDate,
    string? SettlementStatus,
    string? UpdatedAt
);

using System.Globalization;
using System.Text.Json;
using System.Text.RegularExpressions;
using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Entities.Models.Charge;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.ChargeList;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;

namespace PaymentsDataLayerReports.Application.Workers.Shared.EntityMappers;

public class ChargeEntityMapper
{
    private static readonly Dictionary<string, int> HeaderIndex = ChargeListReportHeader.HeaderIndex;
    private static readonly JsonSerializerOptions Options = SerializerOptions.Options;
    private static readonly Regex UnquotedStringValueRegex = new(
        "(:\\s*)([A-Za-z0-9_][A-Za-z0-9_\\-:.@/]*)((?=\\s*[,}\\]]))",
        RegexOptions.Compiled
    );

    private static JsonElement GetJsonElement(JsonElement element, string propertyName)
    {
        if (element.ValueKind is JsonValueKind.Undefined or JsonValueKind.Null)
            return default;

        return element.TryGetProperty(propertyName, out var prop) ? prop : default;
    }

    private static string? GetJsonString(JsonElement element, string propertyName)
    {
        if (element.ValueKind is JsonValueKind.Undefined or JsonValueKind.Null)
            return null;

        if (!element.TryGetProperty(propertyName, out var prop))
            return null;

        return prop.ValueKind switch
        {
            JsonValueKind.String => prop.GetString(),
            JsonValueKind.Number => prop.GetRawText(),
            JsonValueKind.True => "true",
            JsonValueKind.False => "false",
            JsonValueKind.Null => null,
            _ => prop.GetRawText()
        };
    }

    private static JsonElement ParseJsonElementFromCsvField(object fieldValue)
    {
        var json = fieldValue is string str ? str : JsonSerializer.Serialize(fieldValue);
        if (string.IsNullOrWhiteSpace(json))
        {
            return default;
        }

        var jsonElement = DeserializeJsonElementWithFallback(json);
        if (jsonElement.ValueKind == JsonValueKind.String)
        {
            var innerJson = jsonElement.GetString();
            if (string.IsNullOrWhiteSpace(innerJson))
            {
                return default;
            }

            jsonElement = DeserializeJsonElementWithFallback(innerJson);
        }

        return jsonElement;
    }

    private static JsonElement DeserializeJsonElementWithFallback(string json)
    {
        try
        {
            return JsonSerializer.Deserialize<JsonElement>(json, Options);
        }
        catch (JsonException)
        {
            var normalizedJson = NormalizeSingleQuotedJson(json);
            if (normalizedJson != json)
            {
                try
                {
                    return JsonSerializer.Deserialize<JsonElement>(normalizedJson, Options);
                }
                catch (JsonException)
                {
                    normalizedJson = NormalizeUnquotedStringValues(normalizedJson);
                    if (normalizedJson != json)
                    {
                        return JsonSerializer.Deserialize<JsonElement>(normalizedJson, Options);
                    }

                    throw;
                }
            }

            var unquotedValueNormalizedJson = NormalizeUnquotedStringValues(json);
            if (unquotedValueNormalizedJson == json)
            {
                throw;
            }

            return JsonSerializer.Deserialize<JsonElement>(unquotedValueNormalizedJson, Options);
        }
    }

    private static string NormalizeSingleQuotedJson(string json)
    {
        var trimmedJson = json.TrimStart();
        var isSingleQuotedJson = trimmedJson.StartsWith("{'")
            || trimmedJson.StartsWith("['")
            || trimmedJson.StartsWith("[{");

        if (isSingleQuotedJson && trimmedJson.Contains("':"))
        {
            return trimmedJson.Replace('\'', '"');
        }

        return json;
    }

    private static string NormalizeUnquotedStringValues(string json)
    {
        return UnquotedStringValueRegex.Replace(json, match =>
        {
            var prefix = match.Groups[1].Value;
            var value = match.Groups[2].Value;

            if (value is "true" or "false" or "null")
            {
                return match.Value;
            }

            if (decimal.TryParse(value, NumberStyles.Number, CultureInfo.InvariantCulture, out _))
            {
                return match.Value;
            }

            return $"{prefix}\"{value}\"";
        });
    }

    private static List<JsonElement> GetJsonItems(JsonElement jsonElement)
    {
        if (jsonElement.ValueKind == JsonValueKind.Array)
            return [.. jsonElement.EnumerateArray()];

        if (jsonElement.ValueKind == JsonValueKind.Object)
            return [jsonElement];

        return [];
    }

    private static Merchant GetMerchant(CsvRow chargeCsvRow)
    {
        return new(
            chargeCsvRow.GetField<string>(HeaderIndex, "merchant__organization") ?? "",
            chargeCsvRow.GetField<string>(HeaderIndex, "merchant__document") ?? "",
            chargeCsvRow.GetField<string>(HeaderIndex, "merchant__user_id") ?? "",
            chargeCsvRow.GetField<string>(HeaderIndex, "merchant__affiliation_key") ?? "",
            chargeCsvRow.GetField<string>(HeaderIndex, "merchant__affiliation_code") ?? "",
            chargeCsvRow.GetField<string>(HeaderIndex, "merchant__account_id") ?? "",
            chargeCsvRow.GetField<string>(HeaderIndex, "merchant__merchant_id") ?? ""
        );
    }
    private static List<Split>? GetSplit(CsvRow chargeCsvRow)
    {
        var splits = chargeCsvRow.GetField(HeaderIndex, "split");

        if (splits != null && splits is object splitsObject && splitsObject.ToString() != "[]")
        {
            try
            {
                var splitItems = GetJsonItems(ParseJsonElementFromCsvField(splitsObject));
                var splitList = new List<Split>();

                foreach (var split in splitItems)
                {
                    splitList.Add(new Split(
                        GetJsonString(split, "id"),
                        GetJsonString(split, "recipient_id"),
                        GetJsonString(split, "gateway_recipient_id")
                    ));
                }

                return splitList.Count > 0 ? splitList : null;
            }
            catch (JsonException ex)
            {
                throw new InvalidOperationException("Failed to parse split JSON.", ex);
            }
        }
        return null;
    }

    private static Customer? GetCustomer(CsvRow chargeCsvRow, string prefix)
    {
        return new Customer
        {
            Name = chargeCsvRow.GetField<string>(HeaderIndex, $"{prefix}__customer__name") ?? "",
            DocumentType = chargeCsvRow.GetField<string>(HeaderIndex, $"{prefix}__customer__document_type") ?? "",
            Document = chargeCsvRow.GetField<string>(HeaderIndex, $"{prefix}__customer__document") ?? "",
            CustomerId = chargeCsvRow.GetField<string>(HeaderIndex, $"{prefix}__customer__customer_id") ?? "",
            Address = GetAddress(chargeCsvRow, $"{prefix}__customer"),
            Telephones = null,
            Email = chargeCsvRow.GetField<string>(HeaderIndex, $"{prefix}__customer__email") ?? ""
        };
    }

    private static Address? GetAddress(CsvRow chargeCsvRow, string prefix)
    {
        return new(
            chargeCsvRow.GetField<string>(HeaderIndex, $"{prefix}__address__street"),
            chargeCsvRow.GetField<string>(HeaderIndex, $"{prefix}__address__street_number"),
            chargeCsvRow.GetField<string>(HeaderIndex, $"{prefix}__address__extra"),
            chargeCsvRow.GetField<string>(HeaderIndex, $"{prefix}__address__neighborhood"),
            chargeCsvRow.GetField<string>(HeaderIndex, $"{prefix}__address__postal_code"),
            chargeCsvRow.GetField<string>(HeaderIndex, $"{prefix}__address__city"),
            chargeCsvRow.GetField<string>(HeaderIndex, $"{prefix}__address__state"),
            chargeCsvRow.GetField<string>(HeaderIndex, $"{prefix}__address__country")
        );
    }

    private static Card GetCard(CsvRow chargeCsvRow)
    {
        var cardExpirationMonth = chargeCsvRow.GetField<int?>(HeaderIndex, "card_transaction__card__exp_month");
        var cardLastFourDigits = chargeCsvRow.GetField<int?>(HeaderIndex, "card_transaction__card__last_four_digits");

        return new(
            chargeCsvRow.GetField<string>(HeaderIndex, "card_transaction__card__brand") ?? "",
            byte.Parse(chargeCsvRow.GetField<string?>(HeaderIndex, "card_transaction__card__brand_id") ?? "0"),
            chargeCsvRow.GetField<string>(HeaderIndex, "card_transaction__card__first_six_digits") ?? "",
            cardLastFourDigits.ToString() ?? "",
            chargeCsvRow.GetField<string>(HeaderIndex, "card_transaction__card__entry_mode") ?? "",
            chargeCsvRow.GetField<string>(HeaderIndex, "card_transaction__card__holder_name") ?? "",
            cardExpirationMonth.ToString() ?? "",
            chargeCsvRow.GetField<string>(HeaderIndex, "card_transaction__card__exp_year") ?? "",
            short.Parse(chargeCsvRow.GetField<string?>(HeaderIndex, "card_transaction__card__country_code") ?? "0"),
            short.Parse(chargeCsvRow.GetField<string?>(HeaderIndex, "card_transaction__card__currency_code") ?? "0"),
            chargeCsvRow.GetField<string>(HeaderIndex, "card_transaction__card__number_token"),
            chargeCsvRow.GetField<string>(HeaderIndex, "card_transaction__card__label")
        );
    }

    private static CardLast? GetCardLast(CsvRow chargeCsvRow)
    {
        return new(
            chargeCsvRow.GetField<string>(HeaderIndex, "card_transaction__last__operation_status"),
            chargeCsvRow.GetField<string>(HeaderIndex, "card_transaction__last__antifraud_status"),
            chargeCsvRow.GetField<string>(HeaderIndex, "card_transaction__last__acquirer_name"),
            chargeCsvRow.GetField<string>(HeaderIndex, "card_transaction__last__acquirer_return_code"),
            chargeCsvRow.GetField<string>(HeaderIndex, "card_transaction__last__legacy_status")
        );
    }

    private static Acquirer? GetAcquirer(JsonElement element)
    {
        if (element.ValueKind is JsonValueKind.Null or JsonValueKind.Undefined) return null;

        return new(
            GetJsonString(element, "name"),
            GetJsonString(element, "nsu"),
            GetJsonString(element, "tid")
        );
    }

    private static GatewayResponse? GetGatewayResponse(JsonElement element)
    {
        if (element.ValueKind is JsonValueKind.Null or JsonValueKind.Undefined) return null;

        return new(
            GetJsonString(element, "code"),
            GetJsonString(element, "message")
        );
    }

    private static AntifraudResponse? GetAntifraudResponse(JsonElement element)
    {
        if (element.ValueKind is JsonValueKind.Null or JsonValueKind.Undefined) return null;

        return new(
            GetJsonString(element, "provider_name"),
            GetJsonString(element, "score"),
            GetJsonString(element, "status")
        );
    }

    private static Legacy? GetLegacy(JsonElement element)
    {
        if (element.ValueKind is JsonValueKind.Null or JsonValueKind.Undefined) return null;

        var canceledAmount = GetJsonString(element, "canceled_amount");
        return new(
            GetJsonString(element, "status"),
            GetJsonString(element, "operation"),
            GetJsonString(element, "transaction_status"),
            string.IsNullOrEmpty(canceledAmount) ? null : int.Parse(canceledAmount),
            GetJsonString(element, "account_name")
        );
    }

    private static List<CardDetail>? GetCardDetails(CsvRow chargeCsvRow)
    {
        var cardDetails = chargeCsvRow.GetField(HeaderIndex, "card_transaction__details");

        if (cardDetails != null && cardDetails is object cardDetailsObject && cardDetailsObject.ToString() != "[]")
        {
            try
            {
                var cardDetailItems = GetJsonItems(ParseJsonElementFromCsvField(cardDetailsObject));
                var cardDetailList = new List<CardDetail>();

                foreach (var cardDetail in cardDetailItems)
                {
                    var providerDatetimeStr = GetJsonString(cardDetail, "provider_datetime");
                    var localDatetimeStr = GetJsonString(cardDetail, "local_datetime");

                    cardDetailList.Add(new CardDetail(
                        GetJsonString(cardDetail, "operation"),
                        GetJsonString(cardDetail, "operation_id"),
                        int.Parse(GetJsonString(cardDetail, "operation_amount") ?? "0"),
                        string.IsNullOrEmpty(providerDatetimeStr) ? DateTime.MinValue : DateTime.Parse(providerDatetimeStr),
                        string.IsNullOrEmpty(localDatetimeStr) ? null : DateTime.Parse(localDatetimeStr),
                        GetJsonString(cardDetail, "acquirer_message"),
                        GetJsonString(cardDetail, "acquirer_return_code"),
                        GetJsonString(cardDetail, "operation_reason"),
                        GetJsonString(cardDetail, "pgid"),
                        GetAcquirer(GetJsonElement(cardDetail, "acquirer")),
                        GetGatewayResponse(GetJsonElement(cardDetail, "gateway_response")),
                        GetAntifraudResponse(GetJsonElement(cardDetail, "antifraud_response")),
                        GetLegacy(GetJsonElement(cardDetail, "legacy")),
                        GetJsonString(cardDetail, "operation_status")
                    ));
                }
                return cardDetailList.Count > 0 ? cardDetailList : null;
            }
            catch (JsonException ex)
            {
                throw new InvalidOperationException("Failed to parse card details JSON.", ex);
            }
        }
        return null;
    }

    private static FinancialMovementFee? GetFinancialMovementFee(JsonElement element)
    {
        if (element.ValueKind is JsonValueKind.Null or JsonValueKind.Undefined) return null;

        var feeStr = GetJsonString(element, "fee");
        var effectiveFeeStr = GetJsonString(element, "effective_fee");
        var amountStr = GetJsonString(element, "amount");

        return new(
            GetJsonString(element, "fee_type"),
            string.IsNullOrEmpty(feeStr) ? null : decimal.Parse(feeStr),
            string.IsNullOrEmpty(effectiveFeeStr) ? null : decimal.Parse(effectiveFeeStr),
            string.IsNullOrEmpty(amountStr) ? null : decimal.Parse(amountStr)
        );
    }

    private static FinancialMovementAmount? GetFinancialMovementAmount(JsonElement element)
    {
        if (element.ValueKind is JsonValueKind.Null or JsonValueKind.Undefined) return null;

        var grossStr = GetJsonString(element, "gross");
        var netStr = GetJsonString(element, "net");

        return new(
            string.IsNullOrEmpty(grossStr) ? null : decimal.Parse(grossStr),
            string.IsNullOrEmpty(netStr) ? null : decimal.Parse(netStr),
            GetFinancialMovementFee(GetJsonElement(element, "discount_rate")),
            GetFinancialMovementFee(GetJsonElement(element, "prepayment_fee")),
            GetFinancialMovementFee(GetJsonElement(element, "fraud_coverage")),
            GetFinancialMovementFee(GetJsonElement(element, "prepayment_fee_turbo"))
        );
    }

    private static List<ChargeFinancialMovement>? GetFinancialMovements(CsvRow chargeCsvRow, string prefix)
    {
        var cardFinancialMovements = chargeCsvRow.GetField(HeaderIndex, $"{prefix}__financial_movements");

        if (cardFinancialMovements != null && cardFinancialMovements is object cardFinancialMovementsObject && cardFinancialMovementsObject.ToString() != "[]")
        {
            try
            {
                var cardFinancialMovementItems = GetJsonItems(ParseJsonElementFromCsvField(cardFinancialMovementsObject));
                var cardFinancialMovementList = new List<ChargeFinancialMovement>();


                foreach (var cardFinancialMovement in cardFinancialMovementItems)
                {
                    var currentDueDateStr = GetJsonString(cardFinancialMovement, "current_due_date");
                    var originalDueDateStr = GetJsonString(cardFinancialMovement, "original_due_date");
                    var createdAtStr = GetJsonString(cardFinancialMovement, "created_at");
                    var latestEventDatetimeStr = GetJsonString(cardFinancialMovement, "latest_event_datetime");

                    cardFinancialMovementList.Add(new(
                        GetJsonString(cardFinancialMovement, "operation"),
                        GetJsonString(cardFinancialMovement, "operation_id"),
                        GetJsonString(cardFinancialMovement, "detail_operation_id"),
                        string.IsNullOrEmpty(currentDueDateStr) ? null : DateOnly.Parse(currentDueDateStr),
                        string.IsNullOrEmpty(originalDueDateStr) ? null : DateOnly.Parse(originalDueDateStr),
                        GetJsonString(cardFinancialMovement, "payment_owner_document"),
                        GetJsonString(cardFinancialMovement, "settlement_status"),
                        GetJsonString(cardFinancialMovement, "category"),
                        short.Parse(GetJsonString(cardFinancialMovement, "installment_number") ?? "0"),
                        GetFinancialMovementAmount(GetJsonElement(cardFinancialMovement, "amount")),
                        GetJsonString(cardFinancialMovement, "id"),
                        GetJsonString(cardFinancialMovement, "payment_method"),
                        GetJsonString(cardFinancialMovement, "split_rule_id"),
                        GetJsonString(cardFinancialMovement, "bulk_anticipation_id"),
                        GetJsonString(cardFinancialMovement, "payment_owner_id"),
                        GetJsonString(cardFinancialMovement, "recipient_id"),
                        GetJsonString(cardFinancialMovement, "payment_owner_stone_account"),
                        string.IsNullOrEmpty(createdAtStr) ? null : DateTime.Parse(createdAtStr),
                        string.IsNullOrEmpty(latestEventDatetimeStr) ? null : DateTime.Parse(latestEventDatetimeStr)
                    ));
                }
                return cardFinancialMovementList;
            }
            catch (JsonException ex)
            {
                throw new InvalidOperationException("Failed to parse card financial movement JSON.", ex);
            }
        }
        return null;
    }

    private static CardTransaction? GetCardTransaction(CsvRow chargeCsvRow)
    {
        var cardFullFeeAmount = chargeCsvRow.GetField<string>(HeaderIndex, "card_transaction__full_fee_amount");
        var cardFullMdrAmount = chargeCsvRow.GetField<string>(HeaderIndex, "card_transaction__full_mdr_amount");
        var cardFullMdrRefundAmount = chargeCsvRow.GetField<string>(HeaderIndex, "card_transaction__full_mdr_refund_amount");
        var cardFullRavAmount = chargeCsvRow.GetField<string>(HeaderIndex, "card_transaction__full_rav_amount");
        var cardFullRavRefundAmount = chargeCsvRow.GetField<string>(HeaderIndex, "card_transaction__full_rav_refund_amount");
        var cardFullFcAmount = chargeCsvRow.GetField<string>(HeaderIndex, "card_transaction__full_fc_amount");
        var cardFullFcRefundAmount = chargeCsvRow.GetField<string>(HeaderIndex, "card_transaction__full_fc_refund_amount");

        var cardCaptureDateStr = chargeCsvRow.GetField<string>(HeaderIndex, "card_transaction__capture_date");

        return new(
            chargeCsvRow.GetField<string>(HeaderIndex, "card_transaction__type") ?? "",
            chargeCsvRow.GetField<string>(HeaderIndex, "card_transaction__funding_source") ?? "",
            chargeCsvRow.GetField<string>(HeaderIndex, "card_transaction__transaction_id") ?? "",
            null,
            chargeCsvRow.GetField<int>(HeaderIndex, "card_transaction__authorized_amount"),
            chargeCsvRow.GetField<int>(HeaderIndex, "card_transaction__captured_amount"),
            chargeCsvRow.GetField<int>(HeaderIndex, "card_transaction__canceled_amount"),
            chargeCsvRow.GetField<int>(HeaderIndex, "card_transaction__chargeback_amount"),
            chargeCsvRow.GetField<int>(HeaderIndex, "card_transaction__chargeback_refund_amount"),
            chargeCsvRow.GetField<string>(HeaderIndex, "card_transaction__authorization_code") ?? "",
            chargeCsvRow.GetField<string>(HeaderIndex, "card_transaction__authorized_state"),
            chargeCsvRow.GetField<int?>(HeaderIndex, "card_transaction__installments"),
            chargeCsvRow.GetField<string>(HeaderIndex, "card_transaction__installments_type") ?? "",
            chargeCsvRow.GetField<string>(HeaderIndex, "card_transaction__scheme_business_model") ?? "",
            chargeCsvRow.GetField<int>(HeaderIndex, "card_transaction__fee_amount"),
            string.IsNullOrEmpty(cardFullFeeAmount) ? null : decimal.Parse(cardFullFeeAmount),
            chargeCsvRow.GetField<int>(HeaderIndex, "card_transaction__mdr_amount"),
            string.IsNullOrEmpty(cardFullMdrAmount) ? null : decimal.Parse(cardFullMdrAmount),
            chargeCsvRow.GetField<int>(HeaderIndex, "card_transaction__mdr_refund_amount"),
            string.IsNullOrEmpty(cardFullMdrRefundAmount) ? null : decimal.Parse(cardFullMdrRefundAmount),
            string.IsNullOrEmpty(cardFullFcAmount) ? null : decimal.Parse(cardFullFcAmount),
            string.IsNullOrEmpty(cardFullFcRefundAmount) ? null : decimal.Parse(cardFullFcRefundAmount),
            chargeCsvRow.GetField<int>(HeaderIndex, "card_transaction__rav_amount"),
            string.IsNullOrEmpty(cardFullRavAmount) ? null : decimal.Parse(cardFullRavAmount),
            chargeCsvRow.GetField<int>(HeaderIndex, "card_transaction__rav_refund_amount"),
            string.IsNullOrEmpty(cardFullRavRefundAmount) ? null : decimal.Parse(cardFullRavRefundAmount),
            GetCustomer(chargeCsvRow, "card_transaction"),
            GetCard(chargeCsvRow),
            GetTerminal<CardTerminal>(chargeCsvRow, "card_transaction"),
            GetCardLast(chargeCsvRow),
            GetCardDetails(chargeCsvRow),
            GetFinancialMovements(chargeCsvRow, "card_transaction"),
            string.IsNullOrEmpty(cardCaptureDateStr) ? null : DateTimeOffset.Parse(cardCaptureDateStr)
        );
    }

    private static PixCustomer GetPixCustomer(CsvRow chargeCsvRow)
    {
        return new(
            chargeCsvRow.GetField<string>(HeaderIndex, "pix_transaction__customer__name"),
            chargeCsvRow.GetField<string>(HeaderIndex, "pix_transaction__customer__document_type"),
            chargeCsvRow.GetField<string>(HeaderIndex, "pix_transaction__customer__document"),
            chargeCsvRow.GetField<string>(HeaderIndex, "pix_transaction__customer__email"),
            chargeCsvRow.GetField<string>(HeaderIndex, "pix_transaction__customer__customer_id"),
            GetAddress(chargeCsvRow, "pix_transaction__customer")
        );
    }

    private static Payer GetPayer(CsvRow chargeCsvRow)
    {
        return new(
            chargeCsvRow.GetField<string>(HeaderIndex, "pix_transaction__payer__name"),
            chargeCsvRow.GetField<string>(HeaderIndex, "pix_transaction__payer__document_type"),
            chargeCsvRow.GetField<string>(HeaderIndex, "pix_transaction__payer__document"),
            chargeCsvRow.GetField<string>(HeaderIndex, "pix_transaction__payer__ispb"),
            chargeCsvRow.GetField<string>(HeaderIndex, "pix_transaction__payer__institution_name")
        );
    }

    private static T GetTerminal<T>(CsvRow chargeCsvRow, string prefix)
    {
        var type = chargeCsvRow.GetField<string>(HeaderIndex, $"{prefix}__terminal__type") ?? "";
        var serialNumber = chargeCsvRow.GetField<string>(HeaderIndex, $"{prefix}__terminal__serial_number") ?? "";

        if (typeof(T) == typeof(CardTerminal)) return (T)(object)new CardTerminal(type, serialNumber);
        if (typeof(T) == typeof(PixTerminal)) return (T)(object)new PixTerminal(type, serialNumber);

        throw new InvalidOperationException($"GetTerminal is not implemented for this {typeof(T).Name} type.");
    }

    private static Last? GetLast(CsvRow chargeCsvRow, string prefix)
    {
        return new(
            chargeCsvRow.GetField<string>(HeaderIndex, $"{prefix}__last__operation_status"),
            chargeCsvRow.GetField<string>(HeaderIndex, $"{prefix}__last__legacy_status")
        );
    }

    private static Penalty? GetPenalty(CsvRow chargeCsvRow, string prefix)
    {
        return new(
            chargeCsvRow.GetField<string>(HeaderIndex, $"{prefix}__start_at"),
            chargeCsvRow.GetField<string>(HeaderIndex, $"{prefix}__type"),
            chargeCsvRow.GetField<string>(HeaderIndex, $"{prefix}__value")
        );
    }

    private static PixInterest? GetPixInterest(CsvRow chargeCsvRow)
    {
        return new(
            chargeCsvRow.GetField<string>(HeaderIndex, "pix_transaction__interest__start_at"),
            chargeCsvRow.GetField<string>(HeaderIndex, "pix_transaction__interest__type"),
            chargeCsvRow.GetField<string>(HeaderIndex, "pix_transaction__interest__value"),
            chargeCsvRow.GetField<string>(HeaderIndex, "pix_transaction__interest__period")
        );
    }

    private static PixReduction? GetPixReduction(CsvRow chargeCsvRow)
    {
        return new(
            chargeCsvRow.GetField<string>(HeaderIndex, "pix_transaction__reduction__start_at"),
            chargeCsvRow.GetField<string>(HeaderIndex, "pix_transaction__reduction__value")
        );
    }

    private static PixDiscount[]? GetPixDiscounts(CsvRow chargeCsvRow)
    {
        var pixDiscounts = chargeCsvRow.GetField(HeaderIndex, "pix_transaction__discounts");

        if (pixDiscounts != null && pixDiscounts is object pixDiscountsObject && pixDiscountsObject.ToString() != "[]")
        {
            try
            {
                var pixDiscountItems = GetJsonItems(ParseJsonElementFromCsvField(pixDiscountsObject));
                List<PixDiscount> pixDiscountsList = [];

                foreach (var pixDiscount in pixDiscountItems)
                {
                    pixDiscountsList.Add(new(
                        GetJsonString(pixDiscount, "expire_at"),
                        GetJsonString(pixDiscount, "type"),
                        GetJsonString(pixDiscount, "value"),
                        GetJsonString(pixDiscount, "calculation_mode")
                    ));
                }
                return [.. pixDiscountsList];
            }
            catch (JsonException ex)
            {
                throw new InvalidOperationException("Failed to parse Pix Discounts JSON.", ex);
            }
        }
        return null;
    }

    private static PixAdditionalData[]? GetPixAdditionalData(CsvRow chargeCsvRow)
    {
        var pixAdditionalData = chargeCsvRow.GetField(HeaderIndex, "pix_transaction__additional_data");

        if (pixAdditionalData != null && pixAdditionalData is object pixAdditionalDataObject && pixAdditionalDataObject.ToString() != "[]")
        {
            try
            {
                var jsonElement = ParseJsonElementFromCsvField(pixAdditionalDataObject);
                List<PixAdditionalData> pixAdditionalDataList = [];

                if (jsonElement.ValueKind == JsonValueKind.Array)
                {
                    foreach (var additionalData in jsonElement.EnumerateArray())
                    {
                        pixAdditionalDataList.Add(new(
                            GetJsonString(additionalData, "name") ?? "",
                            GetJsonString(additionalData, "value") ?? ""
                        ));
                    }
                }
                else if (jsonElement.ValueKind == JsonValueKind.Object)
                {
                    foreach (var property in jsonElement.EnumerateObject())
                    {
                        pixAdditionalDataList.Add(new(
                            property.Name,
                            property.Value.ValueKind == JsonValueKind.String ? property.Value.GetString() ?? "" : property.Value.GetRawText()
                        ));
                    }
                }

                return pixAdditionalDataList.Count > 0 ? [.. pixAdditionalDataList] : null;
            }
            catch (JsonException ex)
            {
                throw new InvalidOperationException("Failed to parse Pix Additional Data JSON.", ex);
            }
        }
        return null;
    }

    private static List<PixDetail>? GetPixDetails(CsvRow chargeCsvRow)
    {
        var pixDetails = chargeCsvRow.GetField(HeaderIndex, "pix_transaction__details");

        if (pixDetails != null && pixDetails is object pixDetailsObject && pixDetailsObject.ToString() != "[]")
        {
            try
            {
                var pixDetailItems = GetJsonItems(ParseJsonElementFromCsvField(pixDetailsObject));
                var pixDetailList = new List<PixDetail>();

                foreach (var pixDetail in pixDetailItems)
                {
                    var localDatetimeStr = GetJsonString(pixDetail, "local_datetime");
                    var providerDatetimeStr = GetJsonString(pixDetail, "provider_datetime");
                    var operationAmountStr = GetJsonString(pixDetail, "operation_amount");

                    var gatewayResponseElement = GetJsonElement(pixDetail, "gateway_response");
                    var legacyElement = GetJsonElement(pixDetail, "legacy");
                    var antifraudResponseElement = GetJsonElement(pixDetail, "antifraud_response");

                    pixDetailList.Add(new PixDetail(
                        GetJsonString(pixDetail, "operation"),
                        GetJsonString(pixDetail, "operation_id"),
                        string.IsNullOrEmpty(localDatetimeStr) ? DateTime.MinValue : DateTime.Parse(localDatetimeStr),
                        string.IsNullOrEmpty(providerDatetimeStr) ? DateTime.MinValue : DateTime.Parse(providerDatetimeStr),
                        string.IsNullOrEmpty(operationAmountStr) ? 0 : int.Parse(operationAmountStr),
                        GetJsonString(pixDetail, "qrcode_content"),
                        GetJsonString(pixDetail, "description"),
                        GetJsonString(pixDetail, "refund_id"),
                        GetJsonString(pixDetail, "reason"),
                        GetGatewayResponse(gatewayResponseElement),
                        GetLegacy(legacyElement),
                        GetAntifraudResponse(antifraudResponseElement),
                        GetJsonString(pixDetail, "pgid")
                    ));
                }
                return pixDetailList.Count > 0 ? pixDetailList : null;
            }
            catch (JsonException ex)
            {
                throw new InvalidOperationException("Failed to parse pix details JSON.", ex);
            }
        }
        return null;
    }

    private static PixTransaction? GetPixTransaction(CsvRow chargeCsvRow)
    {
        var pixFullFeeAmount = chargeCsvRow.GetField<string>(HeaderIndex, "pix_transaction__full_fee_amount");
        var pixFullMdrAmount = chargeCsvRow.GetField<string>(HeaderIndex, "pix_transaction__full_mdr_amount");
        var pixFullMdrRefundAmount = chargeCsvRow.GetField<string>(HeaderIndex, "pix_transaction__full_mdr_refund_amount");
        var pixFullRavAmount = chargeCsvRow.GetField<string>(HeaderIndex, "pix_transaction__full_rav_amount");
        var pixFullRavRefundAmount = chargeCsvRow.GetField<string>(HeaderIndex, "pix_transaction__full_rav_refund_amount");
        var pixFullFcAmount = chargeCsvRow.GetField<string>(HeaderIndex, "pix_transaction__full_fc_amount");
        var pixFullFcRefundAmount = chargeCsvRow.GetField<string>(HeaderIndex, "pix_transaction__full_fc_refund_amount");
        return new(
            chargeCsvRow.GetField<string>(HeaderIndex, "pix_transaction__type") ?? "",
            chargeCsvRow.GetField<string>(HeaderIndex, "pix_transaction__transaction_id") ?? "",
            chargeCsvRow.GetField<string>(HeaderIndex, "pix_transaction__e2e_id") ?? "",
            chargeCsvRow.GetField<string>(HeaderIndex, "pix_transaction__pix_key"),
            chargeCsvRow.GetField<bool?>(HeaderIndex, "pix_transaction__is_pix_sale_key"),
            chargeCsvRow.GetField<string>(HeaderIndex, "pix_transaction__pix_key_nickname"),
            chargeCsvRow.GetField<int?>(HeaderIndex, "pix_transaction__paid_amount") ?? 0,
            null,
            null,
            null,
            null,
            chargeCsvRow.GetField<int>(HeaderIndex, "pix_transaction__canceled_amount"),
            chargeCsvRow.GetField<int?>(HeaderIndex, "pix_transaction__fee_amount") ?? 0,
            string.IsNullOrEmpty(pixFullFeeAmount) ? null : decimal.Parse(pixFullFeeAmount),
            string.IsNullOrEmpty(pixFullMdrAmount) ? null : decimal.Parse(pixFullMdrAmount),
            string.IsNullOrEmpty(pixFullMdrRefundAmount) ? null : decimal.Parse(pixFullMdrRefundAmount),
            string.IsNullOrEmpty(pixFullRavAmount) ? null : decimal.Parse(pixFullRavAmount),
            string.IsNullOrEmpty(pixFullRavRefundAmount) ? null : decimal.Parse(pixFullRavRefundAmount),
            string.IsNullOrEmpty(pixFullFcAmount) ? null : decimal.Parse(pixFullFcAmount),
            string.IsNullOrEmpty(pixFullFcRefundAmount) ? null : decimal.Parse(pixFullFcRefundAmount),
            chargeCsvRow.GetField<string>(HeaderIndex, "pix_transaction__expire_at"),
            chargeCsvRow.GetField<int?>(HeaderIndex, "pix_transaction__payment_limit_period_days"),
            chargeCsvRow.GetField<bool?>(HeaderIndex, "pix_transaction__business_days_only"),
            chargeCsvRow.GetField<int?>(HeaderIndex, "pix_transaction__expires_in"),
            GetPenalty(chargeCsvRow, "pix_transaction__fine"),
            GetPixInterest(chargeCsvRow),
            GetPixDiscounts(chargeCsvRow),
            GetPixReduction(chargeCsvRow),
            chargeCsvRow.GetField<string>(HeaderIndex, "pix_transaction__request_for_payer"),
            GetPixAdditionalData(chargeCsvRow),
            GetPixCustomer(chargeCsvRow),
            GetPayer(chargeCsvRow),
            GetTerminal<PixTerminal>(chargeCsvRow, "pix_transaction"),
            GetLast(chargeCsvRow, "pix_transaction"),
            GetPixDetails(chargeCsvRow),
            GetFinancialMovements(chargeCsvRow, "pix_transaction")
        );
    }

    private static Bank GetBank(CsvRow chargeCsvRow)
    {
        return new(
            chargeCsvRow.GetField<string>(HeaderIndex, "boleto_transaction__bank__code") ?? "",
            chargeCsvRow.GetField<string>(HeaderIndex, "boleto_transaction__bank__name") ?? ""
        );
    }

    private static BoletoReceiver? GetBoletoReceiver(CsvRow chargeCsvRow)
    {

        return new(
            chargeCsvRow.GetField<string>(HeaderIndex, "boleto_transaction__receiver__name"),
            chargeCsvRow.GetField<string>(HeaderIndex, "boleto_transaction__receiver__document_type"),
            chargeCsvRow.GetField<string>(HeaderIndex, "boleto_transaction__receiver__document")
        );
    }

    private static Discount[]? GetDiscounts(CsvRow chargeCsvRow)
    {
        var discounts = chargeCsvRow.GetField(HeaderIndex, "boleto_transaction__discounts");

        if (discounts != null && discounts is object discountsObject && discountsObject.ToString() != "[]")
        {
            try
            {
                List<Discount> discountList = [];
                var discountsElement = ParseJsonElementFromCsvField(discountsObject);

                if (discountsElement.ValueKind is JsonValueKind.Undefined or JsonValueKind.Null)
                    return null;

                if (discountsElement.ValueKind == JsonValueKind.Array)
                {
                    foreach (var discount in discountsElement.EnumerateArray())
                    {
                        discountList.Add(new(
                            GetJsonString(discount, "expire_at"),
                            GetJsonString(discount, "type"),
                            GetJsonString(discount, "value")
                        ));
                    }
                }
                else if (discountsElement.ValueKind == JsonValueKind.Object)
                {
                    discountList.Add(new(
                        GetJsonString(discountsElement, "expire_at"),
                        GetJsonString(discountsElement, "type"),
                        GetJsonString(discountsElement, "value")
                    ));
                }

                return discountList.Count > 0 ? [.. discountList] : null;
            }
            catch (JsonException ex)
            {
                throw new InvalidOperationException("Failed to parse Boleto Discounts JSON.", ex);
            }
        }
        return null;
    }

    private static List<BoletoDetail>? GetBoletoDetails(CsvRow chargeCsvRow)
    {
        var boletoDetails = chargeCsvRow.GetField(HeaderIndex, "boleto_transaction__details");

        if (boletoDetails != null && boletoDetails is object boletoDetailsObject && boletoDetailsObject.ToString() != "[]")
        {
            try
            {
                var boletoDetailItems = GetJsonItems(ParseJsonElementFromCsvField(boletoDetailsObject));
                var boletoDetailList = new List<BoletoDetail>();

                foreach (var boletoDetail in boletoDetailItems)
                {
                    var providerDatetimeStr = GetJsonString(boletoDetail, "provider_datetime");
                    var localDatetimeStr = GetJsonString(boletoDetail, "local_datetime");
                    var operationAmountStr = GetJsonString(boletoDetail, "operation_amount");

                    boletoDetailList.Add(new(
                        GetJsonString(boletoDetail, "operation"),
                        GetJsonString(boletoDetail, "operation_id"),
                        string.IsNullOrEmpty(providerDatetimeStr) ? DateTime.MinValue : DateTime.Parse(providerDatetimeStr),
                        string.IsNullOrEmpty(localDatetimeStr) ? DateTime.MinValue : DateTime.Parse(localDatetimeStr),
                        string.IsNullOrEmpty(operationAmountStr) ? 0 : int.Parse(operationAmountStr),
                        GetJsonString(boletoDetail, "reason"),
                        GetGatewayResponse(GetJsonElement(boletoDetail, "gateway_response")),
                        GetLegacy(GetJsonElement(boletoDetail, "legacy")),
                        GetJsonString(boletoDetail, "operation_status"),
                        GetAntifraudResponse(GetJsonElement(boletoDetail, "antifraud_response")),
                        GetJsonString(boletoDetail, "pgid")
                    ));
                }
                return boletoDetailList.Count > 0 ? boletoDetailList : null;
            }
            catch (JsonException ex)
            {
                throw new InvalidOperationException("Failed to parse boleto details JSON.", ex);
            }
        }
        return null;
    }

    private static BoletoTransaction? GetBoletoTransaction(CsvRow chargeCsvRow)
    {
        var boletoFullFeeAmount = chargeCsvRow.GetField<string>(HeaderIndex, "boleto_transaction__full_fee_amount");
        var boletoFullMdrAmount = chargeCsvRow.GetField<string>(HeaderIndex, "boleto_transaction__full_mdr_amount");
        var boletoFullMdrRefundAmount = chargeCsvRow.GetField<string>(HeaderIndex, "boleto_transaction__full_mdr_refund_amount");
        var boletoFullRavAmount = chargeCsvRow.GetField<string>(HeaderIndex, "boleto_transaction__full_rav_amount");
        var boletoFullRavRefundAmount = chargeCsvRow.GetField<string>(HeaderIndex, "boleto_transaction__full_rav_refund_amount");
        var boletoFullFcAmount = chargeCsvRow.GetField<string>(HeaderIndex, "boleto_transaction__full_fc_amount");
        var boletoFullFcRefundAmount = chargeCsvRow.GetField<string>(HeaderIndex, "boleto_transaction__full_fc_refund_amount");

        return new(
            chargeCsvRow.GetField<string>(HeaderIndex, "boleto_transaction__type") ?? "",
            chargeCsvRow.GetField<string>(HeaderIndex, "boleto_transaction__transaction_id") ?? "",
            chargeCsvRow.GetField<string>(HeaderIndex, "boleto_transaction__our_number") ?? "",
            chargeCsvRow.GetField<int?>(HeaderIndex, "boleto_transaction__paid_amount") ?? 0,
            chargeCsvRow.GetField<int?>(HeaderIndex, "boleto_transaction__fine_amount"),
            chargeCsvRow.GetField<int?>(HeaderIndex, "boleto_transaction__interest_amount"),
            chargeCsvRow.GetField<int?>(HeaderIndex, "boleto_transaction__discount_amount"),
            chargeCsvRow.GetField<int?>(HeaderIndex, "boleto_transaction__canceled_amount") ?? 0,
            chargeCsvRow.GetField<int?>(HeaderIndex, "boleto_transaction__fee_amount"),
            string.IsNullOrEmpty(boletoFullFeeAmount) ? null : decimal.Parse(boletoFullFeeAmount),
            string.IsNullOrEmpty(boletoFullMdrAmount) ? null : decimal.Parse(boletoFullMdrAmount),
            string.IsNullOrEmpty(boletoFullMdrRefundAmount) ? null : decimal.Parse(boletoFullMdrRefundAmount),
            string.IsNullOrEmpty(boletoFullRavAmount) ? null : decimal.Parse(boletoFullRavAmount),
            string.IsNullOrEmpty(boletoFullRavRefundAmount) ? null : decimal.Parse(boletoFullRavRefundAmount),
            string.IsNullOrEmpty(boletoFullFcAmount) ? null : decimal.Parse(boletoFullFcAmount),
            string.IsNullOrEmpty(boletoFullFcRefundAmount) ? null : decimal.Parse(boletoFullFcRefundAmount),
            chargeCsvRow.GetField<string>(HeaderIndex, "boleto_transaction__expire_at") ?? "",
            chargeCsvRow.GetField<string?>(HeaderIndex, "boleto_transaction__limit_date"),
            chargeCsvRow.GetField<string>(HeaderIndex, "boleto_transaction__barcode"),
            chargeCsvRow.GetField<string>(HeaderIndex, "boleto_transaction__writable_line"),
            chargeCsvRow.GetField<string>(HeaderIndex, "boleto_transaction__instructions"),
            chargeCsvRow.GetField<string>(HeaderIndex, "boleto_transaction__url"),
            GetBank(chargeCsvRow),
            GetBoletoReceiver(chargeCsvRow),
            GetPenalty(chargeCsvRow, "boleto_transaction__fine"),
            GetPenalty(chargeCsvRow, "boleto_transaction__interest"),
            GetDiscounts(chargeCsvRow),
            chargeCsvRow.GetField<string>(HeaderIndex, "boleto_transaction__document_number"),
            chargeCsvRow.GetField<DateTime?>(HeaderIndex, "boleto_transaction__paid_at"),
            GetCustomer(chargeCsvRow, "boleto_transaction"),
            GetLast(chargeCsvRow, "boleto_transaction"),
            GetBoletoDetails(chargeCsvRow),
            GetFinancialMovements(chargeCsvRow, "boleto_transaction")
        );
    }

    private static List<CashDetail>? GetCashDetails(CsvRow chargeCsvRow)
    {
        var cashDetails = chargeCsvRow.GetField(HeaderIndex, "cash_transaction__details");

        if (cashDetails != null && cashDetails is object cashDetailsObject && cashDetailsObject.ToString() != "[]")
        {
            try
            {
                var cashDetailItems = GetJsonItems(ParseJsonElementFromCsvField(cashDetailsObject));
                var cashDetailList = new List<CashDetail>();

                foreach (var cashDetail in cashDetailItems)
                {
                    var localDatetimeStr = GetJsonString(cashDetail, "local_datetime");
                    var providerDatetimeStr = GetJsonString(cashDetail, "provider_datetime");
                    var operationAmountStr = GetJsonString(cashDetail, "operation_amount");

                    cashDetailList.Add(new CashDetail(
                        GetJsonString(cashDetail, "operation"),
                        GetJsonString(cashDetail, "operation_id"),
                        string.IsNullOrEmpty(localDatetimeStr) ? DateTime.MinValue : DateTime.Parse(localDatetimeStr),
                        string.IsNullOrEmpty(providerDatetimeStr) ? DateTime.MinValue : DateTime.Parse(providerDatetimeStr),
                        string.IsNullOrEmpty(operationAmountStr) ? 0 : long.Parse(operationAmountStr),
                        GetJsonString(cashDetail, "operation_reason"),
                        GetLegacy(GetJsonElement(cashDetail, "legacy")),
                        GetJsonString(cashDetail, "operation_status"),
                        GetJsonString(cashDetail, "pgid")
                    ));
                }
                return cashDetailList.Count > 0 ? cashDetailList : null;
            }
            catch (JsonException ex)
            {
                throw new InvalidOperationException("Failed to parse cash details JSON.", ex);
            }
        }
        return null;
    }

    private static CashTransaction? GetCashTransaction(CsvRow chargeCsvRow)
    {
        return new(
            chargeCsvRow.GetField<string>(HeaderIndex, "cash_transaction__description"),
            chargeCsvRow.GetField<string>(HeaderIndex, "cash_transaction__transaction_id"),
            long.Parse(chargeCsvRow.GetField<string?>(HeaderIndex, "cash_transaction__paid_amount") ?? "0"),
            long.Parse(chargeCsvRow.GetField<string?>(HeaderIndex, "cash_transaction__canceled_amount") ?? "0"),
            GetCustomer(chargeCsvRow, "cash_transaction"),
            GetLast(chargeCsvRow, "cash_transaction"),
            GetCashDetails(chargeCsvRow)
        );
    }

    private static Dictionary<string, string>? GetMetadata(CsvRow chargeCsvRow)
    {
        var metadata = chargeCsvRow.GetField(HeaderIndex, "metadata");

        if (metadata != null)
        {
            try
            {
                var metadataElement = ParseJsonElementFromCsvField(metadata);
                if (metadataElement.ValueKind is JsonValueKind.Undefined or JsonValueKind.Null)
                    return null;

                if (metadataElement.ValueKind != JsonValueKind.Object)
                    return null;

                var metadataDict = new Dictionary<string, string>();
                foreach (var property in metadataElement.EnumerateObject())
                {
                    metadataDict[property.Name] = property.Value.ValueKind == JsonValueKind.String
                        ? property.Value.GetString() ?? ""
                        : property.Value.GetRawText();
                }
                return metadataDict;
            }
            catch (JsonException ex)
            {
                throw new InvalidOperationException("Failed to parse Metadata JSON.", ex);
            }
        }

        return null;
    }

    public static Charge MapToEntity(CsvRow chargeCsvRow)
    {
        string paymentMethod = chargeCsvRow.GetField<string>(HeaderIndex, "payment_method") ?? "";

        return new(
           chargeCsvRow.GetField<string>(HeaderIndex, "id") ?? "",
           chargeCsvRow.GetField<string>(HeaderIndex, "initiator_id") ?? "",
           chargeCsvRow.GetField<string?>(HeaderIndex, "product"),
           chargeCsvRow.GetField<string?>(HeaderIndex, "origin"),
           chargeCsvRow.GetField<string?>(HeaderIndex, "origin_id"),
           chargeCsvRow.GetField<int?>(HeaderIndex, "amount"),
           chargeCsvRow.GetField<int?>(HeaderIndex, "updated_amount"),
           chargeCsvRow.GetField<int?>(HeaderIndex, "net_amount") ?? 0,
           chargeCsvRow.GetField<decimal?>(HeaderIndex, "full_net_amount") ?? 0,
           chargeCsvRow.GetField<string>(HeaderIndex, "status") ?? "",
           paymentMethod,
           chargeCsvRow.GetField<DateTime?>(HeaderIndex, "created_at") ?? DateTime.MinValue,
           chargeCsvRow.GetField<string?>(HeaderIndex, "platform_name"),
           chargeCsvRow.GetField<int?>(HeaderIndex, "attempt_count"),
           chargeCsvRow.GetField<string?>(HeaderIndex, "gateway"),
           chargeCsvRow.GetField<string?>(HeaderIndex, "gateway_order_id"),
           chargeCsvRow.GetField<string?>(HeaderIndex, "code"),
           chargeCsvRow.GetField<string?>(HeaderIndex, "all_ids"),
           GetMerchant(chargeCsvRow),
           GetSplit(chargeCsvRow),
           paymentMethod == "card" ? GetCardTransaction(chargeCsvRow) : null,
           paymentMethod == "pix" ? GetPixTransaction(chargeCsvRow) : null,
           paymentMethod == "boleto" ? GetBoletoTransaction(chargeCsvRow) : null,
           paymentMethod == "cash" ? GetCashTransaction(chargeCsvRow) : null,
           chargeCsvRow.GetField<string>(HeaderIndex, "charge_id"),
           chargeCsvRow.GetField<string>(HeaderIndex, "point_of_interaction_type"),
           GetMetadata(chargeCsvRow)
        );
    }
}

﻿using PaymentsDataLayerReports.Application.Enums;

namespace PaymentsDataLayerReports.Application.Workers.Shared;

public static class DownloadFileNameBuilder
{
    public static string? BuildReceivablesFileName(string startDate, string endDate, string reportId, string fileFormat)
    {
        var filenameTemplate = "relatorio-recebimentos-{0}-{1}-{2}.{3}";

        var fileName = string.Format(
            filenameTemplate,
            startDate,
            endDate,
            reportId,
            fileFormat
        );

        return fileName;
    }

    public static string? BuildOrderFileName(string startDate, string endDate, string reportId, string fileFormat)
    {
        var filenameTemplate = "relatorio-pedidos-{0}-{1}-{2}.{3}";

        var fileName = string.Format(
            filenameTemplate,
            startDate,
            endDate,
            reportId,
            fileFormat
        );

        return fileName;
    }
}

namespace PaymentsDataLayerReports.Application.Workers.Shared.Validation;

public interface ISpecification<T>
{
    bool IsSatisfiedBy(T context);
}

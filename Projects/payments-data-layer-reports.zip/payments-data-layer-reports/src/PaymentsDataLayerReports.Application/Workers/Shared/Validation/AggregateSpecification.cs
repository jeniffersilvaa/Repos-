namespace PaymentsDataLayerReports.Application.Workers.Shared.Validation;


public sealed class AggregateSpecification<T>(params ISpecification<T>[] specifications) : ISpecification<T>
{
    private readonly IReadOnlyList<ISpecification<T>> _specifications = specifications;

    public bool IsSatisfiedBy(T context)
        => _specifications.All(s => s.IsSatisfiedBy(context));
}
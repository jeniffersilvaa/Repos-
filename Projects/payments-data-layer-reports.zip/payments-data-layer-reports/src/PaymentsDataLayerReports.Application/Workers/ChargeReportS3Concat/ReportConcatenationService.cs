using System.Text;
using Amazon.S3;
using Microsoft.Extensions.Options;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Models;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;

namespace PaymentsDataLayerReports.Application.Workers.ChargeReportS3Concat;

public interface IReportConcatenationService
{
    Task ConcatAsync(string concatId, ReportMetadata metadata, CancellationToken cancellationToken);
}

public class S3ReportConcatenationService(
    IAmazonS3 s3Client,
    IOptions<AwsSettings> awsSettings,
    IS3CsvPartialReportRecordSource partitionedRecordSource,
    IReportMergeEngine mergeEngine,
    IReportStreamWriterFactory writerFactory
) : IReportConcatenationService
{
    private readonly IAmazonS3 _s3Client = s3Client;
    private readonly AwsSettings _awsSettings = awsSettings.Value;
    private readonly IS3CsvPartialReportRecordSource _partitionedRecordSource = partitionedRecordSource;
    private readonly IReportMergeEngine _mergeEngine = mergeEngine;
    private readonly IReportStreamWriterFactory _writerFactory = writerFactory;
    private readonly int _maxConcatenationDurationMinutes = 300;

    public async Task ConcatAsync(string concatId, ReportMetadata metadata, CancellationToken cancellationToken)
    {
        using var linkedCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        linkedCts.CancelAfter(TimeSpan.FromMinutes(_maxConcatenationDurationMinutes));
        var ct = linkedCts.Token;

        await using var writer = _writerFactory.Create<string>(metadata.FileFormat);

        try
        {
            var header = await ReadHeaderAsync(metadata.ReportId, ct);

            await writer.InitializeAsync(metadata.ReportId, ct);

            if (!string.IsNullOrEmpty(header))
            {
                await writer.WriteHeaderAsync(header, ct);
            }

            await foreach (var record in GetOrderedRecordsAsync(metadata, ct))
            {
                await writer.WriteRecordAsync(record.Line, ct);
            }

            await writer.CompleteAsync(ct);
        }
        catch
        {
            try
            {
                await writer.AbortAsync(CancellationToken.None);
            }
            catch
            {
                // Intentionally ignore abort failures to preserve original exception
            }

            throw;
        }
    }

    private async Task<string> ReadHeaderAsync(string reportId, CancellationToken cancellationToken)
    {
        var bucketName = _awsSettings.WorkgroupBucket!;
        var headerKey = string.Format(S3ReportsConstants.PartialReportHeaderPath, reportId);

        using var response = await _s3Client.GetObjectAsync(bucketName, headerKey, cancellationToken);
        using var reader = new StreamReader(response.ResponseStream, Encoding.UTF8);
        var header = await reader.ReadToEndAsync(cancellationToken);

        return header;
    }

    private async IAsyncEnumerable<ReportRecord> GetOrderedRecordsAsync(ReportMetadata metadata, [System.Runtime.CompilerServices.EnumeratorCancellation] CancellationToken cancellationToken)
    {
        foreach (var date in metadata.GetDateRangeDescending())
        {
            var partitionsForDate = _partitionedRecordSource.GetPartitionStreamsForDateAsync(metadata, date, cancellationToken);

            await foreach (var record in _mergeEngine.MergeOrderedAsync(partitionsForDate, metadata, cancellationToken))
            {
                yield return record;
            }
        }
    }
}

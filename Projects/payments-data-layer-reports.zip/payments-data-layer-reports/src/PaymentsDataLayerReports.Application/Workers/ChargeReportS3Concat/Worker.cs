using Datadog.Trace;
using Hangfire;
using Hangfire.Server;
using Microsoft.Extensions.Options;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Exceptions;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Metrics;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Types;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;
using PaymentsDataLayerReports.Application.Workers.ChargeReportWorker;
using PaymentsDataLayerReports.Application.Workers.NotificationWorkerV2;
using Serilog;

namespace PaymentsDataLayerReports.Application.Workers.ChargeReportS3Concat;

public class ChargeReportS3ConcatWorker(
    IS3ClientWrapper s3ClientWrapper,
    IReportConcatenationService reportConcatenationService,
    IReportingTimeMetrics reportingTimeMetrics,
    IOptions<DataLayerReportPreDeploySettings> preDeploySettings,
    IBackgroundJobClient backgroundJobClient
)
{
    public async Task ConcatReport(
        string reportId,
        PerformContext context,
        CancellationToken cancellationToken
    )
    {
        var concatId = context.BackgroundJob.Id;
        using var scope = Tracer.Instance.StartActive("ChargeReportS3ConcatWorker.ConcatReport");
        scope.Span.SetTag("ChargeReportS3ConcatWorker.ConcatReport.JobId", concatId);
        scope.Span.SetTag("ChargeReportS3ConcatWorker.ConcatReport.ReportId", reportId);


        Log.ForContext("JobId", concatId)
            .ForContext("ReportId", reportId)
            .Debug("[ChargeReportS3ConcatWorker.ConcatReport] Starting");

        try
        {
            var metadata = await s3ClientWrapper.GetReportMetadataAsync(reportId)
                ?? throw new ReportMetadataNotFoundException(reportId);


            await reportConcatenationService.ConcatAsync(concatId, metadata, cancellationToken);
            metadata.Status = WorkerStatesEnum.Succeeded.ToString();
            await s3ClientWrapper.UploadReportMetadataAsync(metadata);

            SendReportingTimeMetric(ref metadata);

            SendNotification(concatId, reportId, metadata, cancellationToken);

        }
        catch (Exception ex)
        {
            Log.ForContext("Exception", ex)
                .ForContext("JobId", concatId)
                .ForContext("ReportId", reportId)
                .Error("[ChargeReportS3ConcatWorker.ConcatReport] Error concatenating report");
            throw;
        }
        finally
        {
            Log.ForContext("JobId", concatId)
                .ForContext("ReportId", reportId)
                .Debug($"[ChargeReportS3ConcatWorker.ConcatReport] Completed");
        }
    }

    private void SendReportingTimeMetric(ref readonly ReportMetadata metadata)
    {
        try
        {
            var endedAt = DateTime.Now;

            if (metadata is not null)
                reportingTimeMetrics.SendMetric(new SendMetricInput
                {
                    StartedAt = metadata.CreatedAt,
                    EndedAt = endedAt,
                    ReportType = Enumeration.FromName<ReportTypeEnum>(
                        metadata.ChargeReportParameters?.ReportType ??
                        metadata.FinMovReportParameters?.ReportType ??
                        throw new InvalidOperationException("Report type not found")
                    ),
                    Status = metadata.Status
                });
        }
        catch (Exception exception)
        {
            Log.ForContext("Exception", exception)
               .Error("[ChargeReportS3ConcatWorker.ConcatReport] Error when send reporting metric");
        }

    }

    private void SendNotification(string concatId, string reportId, ReportMetadata metadata, CancellationToken cancellationToken)
    {

        var reportType = metadata.ChargeReportParameters?.ReportType ??
                    metadata.FinMovReportParameters?.ReportType ??
                    throw new InvalidOperationException("Report type not found");

        if (metadata.NotificationParameters is null) return;

        var dateFormat = "yyyy-MM-dd";

        string startDateFormatted;
        string endDateFormatted;

        if (metadata.ChargeReportParameters is not null)
        {
            var brazilianTimeZone = TimeZoneInfo.FindSystemTimeZoneById("America/Sao_Paulo");
            var startDateBrazilian = TimeZoneInfo.ConvertTime(metadata.ChargeReportParameters.StartDate, brazilianTimeZone);
            var endDateBrazilian = TimeZoneInfo.ConvertTime(metadata.ChargeReportParameters.EndDate, brazilianTimeZone);
            startDateFormatted = startDateBrazilian.ToString(dateFormat);
            endDateFormatted = endDateBrazilian.ToString(dateFormat);
        }
        else if (metadata.FinMovReportParameters is not null)
        {
            startDateFormatted = metadata.FinMovReportParameters.StartDate.ToString(dateFormat);
            endDateFormatted = metadata.FinMovReportParameters.EndDate.ToString(dateFormat);
        }
        else
        {
            throw new InvalidOperationException("Report parameters not found");
        }

        var notificationMetadata = new Dictionary<string, object> {
                {"start_date", startDateFormatted },
                {"end_date", endDateFormatted },
                {"report_type", reportType},
                {"document", metadata.ChargeReportParameters?.Document ?? metadata.FinMovReportParameters?.Document ?? ""},
                {"organizations", metadata.ChargeReportParameters?.Organizations ?? metadata.FinMovReportParameters?.Organizations ?? "" }
             };

        if (metadata.NotificationParameters.Channel.Email is not null)
        {
            notificationMetadata.Add("email", metadata.NotificationParameters.Channel.Email.Address);
        }

        metadata.NotificationParameters.ReportId = reportId;
        metadata.NotificationParameters.Status = metadata.Status!;
        metadata.NotificationParameters.Metadata = notificationMetadata;
        metadata.NotificationParameters.DownloadUrl = s3ClientWrapper.BuildReportUrl(
            reportId,
            fileFormat: metadata.FileFormat
        );
        metadata.NotificationParameters.ReportType = reportType;

        backgroundJobClient.ContinueJobWith<NotificationWorkerV2.NotificationWorkerV2>(
          parentId: concatId,
          queue: QueuesEnum.Notifications.Name,
          options: JobContinuationOptions.OnlyOnSucceededState,
          methodCall: job => job.SendNotificationAsync(metadata.NotificationParameters, null!, cancellationToken));
    }
}
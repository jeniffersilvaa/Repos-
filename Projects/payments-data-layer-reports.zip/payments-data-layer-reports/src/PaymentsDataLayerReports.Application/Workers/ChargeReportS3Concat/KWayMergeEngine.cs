using System.Runtime.CompilerServices;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Models;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;

namespace PaymentsDataLayerReports.Application.Workers.ChargeReportS3Concat;

public interface IReportMergeEngine
{
    IAsyncEnumerable<ReportRecord> MergeOrderedAsync(
        IAsyncEnumerable<IAsyncEnumerable<ReportRecord>> partitions,
        ReportMetadata metadata,
        CancellationToken cancellationToken);
}

public class KWayMergeEngine : IReportMergeEngine
{
    private readonly record struct ActivePartition(IAsyncEnumerator<ReportRecord> Enumerator, ReportRecord Current);

    public async IAsyncEnumerable<ReportRecord> MergeOrderedAsync(
        IAsyncEnumerable<IAsyncEnumerable<ReportRecord>> partitions,
        ReportMetadata metadata,
        [EnumeratorCancellation] CancellationToken cancellationToken)
    {
        var priorityQueue = new PriorityQueue<ActivePartition, string>(new DescendingSortKeyComparer());
        var enumerators = new List<IAsyncEnumerator<ReportRecord>>();

        try
        {
            await foreach (var partition in partitions.WithCancellation(cancellationToken))
            {
                cancellationToken.ThrowIfCancellationRequested();
                var enumerator = partition.GetAsyncEnumerator(cancellationToken);
                if (!await enumerator.MoveNextAsync())
                {
                    await enumerator.DisposeAsync();
                    continue;
                }

                enumerators.Add(enumerator);
                var current = enumerator.Current;
                priorityQueue.Enqueue(new ActivePartition(enumerator, current), current.SortKey);
            }

            while (priorityQueue.Count > 0)
            {
                cancellationToken.ThrowIfCancellationRequested();
                var active = priorityQueue.Dequeue();
                yield return active.Current;

                if (await active.Enumerator.MoveNextAsync())
                {
                    var nextCurrent = active.Enumerator.Current;
                    priorityQueue.Enqueue(new ActivePartition(active.Enumerator, nextCurrent), nextCurrent.SortKey);
                }
            }
        }
        finally
        {
            foreach (var enumerator in enumerators)
            {
                await enumerator.DisposeAsync();
            }
        }
    }

    private sealed class DescendingSortKeyComparer : IComparer<string>
    {
        public int Compare(string? x, string? y)
        {
            if (x == null && y == null) return 0;
            if (x == null) return 1;
            if (y == null) return -1;

            return string.Compare(y, x, StringComparison.OrdinalIgnoreCase);
        }
    }
}

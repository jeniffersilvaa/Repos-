using Datadog.Trace.Annotations;
using Hangfire;
using Hangfire.Server;
using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Infra.DataLayerApi;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService;
using PaymentsDataLayerReports.Application.Services.ReportTypeConfiguration;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;
using PaymentsDataLayerReports.Application.Workers.NotificationWorkerV2;
using PaymentsDataLayerReports.Application.Workers.Shared;
using PaymentsDataLayerReports.Application.Workers.Shared.Mappers.FinMov;
using PaymentsDataLayerReports.Application.Workers.Shared.Modifiers.FinMov;
using Serilog;

namespace PaymentsDataLayerReports.Application.Workers.FinMovReportESWorker;

public class FinMovESWorker(
    IDataLayerApiClient dataLayerApiClient,
    IReportStreamWriterFactory reportStreamWriterFactory,
    IBackgroundJobClient backgroundJobClient,
    IS3ClientWrapper s3ClientWrapper
)
{
    private const int DALAPI_BATCH_SIZE = 5000;
    private static readonly ReceivablesOneStoneCsvMapper ReceivablesOneStoneCsvMapper = new();

    private static string GetHeader(string? reportType)
    {
        return ReportTypeConfigurationProvider.UsesOneStoneLayout(reportType)
            ? ReceivablesOneStoneCsvMapper.GetHeader()
            : ReceivablesModifier.GetHeader();
    }

    private static string BuildRow(FinancialMovement finMov, string? reportType)
    {
        return ReportTypeConfigurationProvider.UsesOneStoneLayout(reportType)
            ? ReceivablesOneStoneCsvMapper.BuildRow(finMov)
            : ReceivablesModifier.BuildRow(finMov);
    }

    [Trace]
    [AutomaticRetry(OnAttemptsExceeded = AttemptsExceededAction.Delete)]
    public async Task ProcessReport(FinMovESWorkerParameters parameters, PerformContext context, CancellationToken cancellationToken)
        => await ProcessReport(parameters, false, context, cancellationToken);

    [Trace]
    [AutomaticRetry(OnAttemptsExceeded = AttemptsExceededAction.Delete)]
    public async Task ProcessReport(FinMovESWorkerParameters parameters, bool isPartialReport, PerformContext context, CancellationToken cancellationToken)
    {
        var jobId = context.BackgroundJob.Id;
        parameters.ReportId = string.IsNullOrEmpty(parameters.ReportId) ? jobId : parameters.ReportId;

        string fileFormat = isPartialReport ? FileFormatEnum.Csv.Name : (parameters.FileFormat ?? FileFormatEnum.Csv.Name);
        await using var writer = reportStreamWriterFactory.Create<string>(fileFormat);

        try
        {
            Log.ForContext("ReportId", parameters.ReportId)
                .ForContext("JobId", jobId)
                .Information("[FinMovESWorker.ProcessReport] - Processing report.");

            if (isPartialReport)
            {
                await UploadMetadata(parameters.ReportId, parameters);
                var destinationKey = string.Format(S3ReportsConstants.PartialReportFilePath, parameters.ReportId, parameters.EndDate, "es_file");
                await writer.InitializeAsync(parameters.ReportId, cancellationToken, destinationKey);
                await s3ClientWrapper.UploadReportHeaderAsync(parameters.ReportId, GetHeader(parameters.ReportType));
            }
            else
            {
                await writer.InitializeAsync(parameters.ReportId, cancellationToken);
                await writer.WriteHeaderAsync(GetHeader(parameters.ReportType), cancellationToken);
            }

            var dalapiParameters = parameters.ToGetFinancialMovementsRequestModel(DALAPI_BATCH_SIZE, null);

            do
            {
                var result = await dataLayerApiClient.GetFinancialMovements(dalapiParameters, parameters.ReportId, cancellationToken);

                foreach (var finMov in result.Data)
                {
                    var row = BuildRow(finMov, parameters.ReportType);
                    await writer.WriteRecordAsync(row, cancellationToken);
                }

                dalapiParameters.Cursor = result.Cursor;
            } while (dalapiParameters.Cursor != null);

            await writer.CompleteAsync(cancellationToken);

            if (!isPartialReport)
            {
                SendNotification(jobId, fileFormat, parameters);
            }

            Log.ForContext("ReportId", parameters.ReportId)
                .Information("[FinMovESWorker.ProcessReport] - Report processed.");
        }
        catch (Exception ex)
        {
            await writer.AbortAsync(cancellationToken);

            Log.ForContext("ReportId", parameters.ReportId)
                .ForContext("Exception", ex)
                .Error("[FinMovESWorker.ProcessReport] - Error processing report.");
            throw;
        }
    }

    private async Task UploadMetadata(string reportId, FinMovESWorkerParameters parameters)
    {
        var reportType = parameters.ReportType ?? ReportTypeEnum.Receivables.Name;
        var reportConfiguration = ReportTypeConfigurationProvider.GetConfiguration(reportType)
            ?? throw new InvalidOperationException($"Report configuration not found for type {reportType}");

        var reportMetadata = new ReportMetadata
        {
            ReportId = reportId,
            DispatchId = string.Empty,
            CreatedAt = DateTime.UtcNow,
            Status = WorkerStatesEnum.Processing.ToString(),
            ProcessorQueueName = QueuesEnum.S3Reports.Name,
            ReportSortColumnIndex = reportConfiguration.ReportSortColumnIndex,
            FileFormat = parameters.FileFormat ?? FileFormatEnum.Csv.Name,
            ChargeReportParameters = null,
            FinMovReportParameters = parameters,
            NotificationParameters = null
        };

        await s3ClientWrapper.UploadReportMetadataAsync(reportMetadata);
    }

    public void SendNotification(
        string jobId,
        string fileFormat,
        FinMovESWorkerParameters parameters
    )
    {
        if (string.IsNullOrWhiteSpace(parameters.Email) && string.IsNullOrWhiteSpace(parameters.WebhookUrl))
            return;

        var dateFormat = "yyyy-MM-dd";

        var metadata = new Dictionary<string, object> {
            {"start_date", parameters.StartDate.ToString(dateFormat) ?? "" },
            {"end_date", parameters.EndDate.ToString(dateFormat) ?? ""},
            {"report_type", parameters.ReportType ?? ReportTypeEnum.Receivables.Name},
            {"document", parameters.Document ?? ""},
            {"organizations", parameters.Organizations ?? "" },
            {"with_payments", parameters.WithPayments ?? false}
        };

        NotificationChannel channel = new();

        if (!string.IsNullOrWhiteSpace(parameters.Email))
        {
            metadata.Add("email", parameters.Email);

            channel.Email = new EmailChannel
            {
                Address = parameters.Email
            };
        }

        if (!string.IsNullOrWhiteSpace(parameters.WebhookUrl))
        {
            channel.Webhook = new WebhookChannel
            {
                Url = parameters.WebhookUrl,
                Headers = parameters.Headers
            };
        }

        var downloadFileName = DownloadFileNameBuilder.BuildReceivablesFileName(
            parameters.StartDate.ToString("yyyyMMdd"),
            parameters.EndDate.ToString("yyyyMMdd"),
            parameters.ReportId!,
            fileFormat
        );

        backgroundJobClient.ContinueJobWith<NotificationWorkerV2.NotificationWorkerV2>(
            parentId: jobId,
            queue: QueuesEnum.Notifications.Name,
            options: JobContinuationOptions.OnlyOnSucceededState,
            methodCall: job => job.SendNotificationAsync(
                new NotificationParameters
                {
                    Status = WorkerStatesEnum.Succeeded.ToString(),
                    ReportId = parameters.ReportId!,
                    ReportType = parameters.ReportType ?? ReportTypeEnum.Receivables.Name,
                    FileFormat = fileFormat,
                    DownloadFileName = downloadFileName,
                    Metadata = metadata,
                    Channel = channel
                },
                null!,
                CancellationToken.None
            )
        );
    }
}
using PaymentsDataLayerReports.Application.Infra.DataLayerApi.Models;

namespace PaymentsDataLayerReports.Application.Workers.FinMovReportESWorker;

public record FinMovESWorkerParameters
{
    public DateOnly StartDate { get; set; }
    public DateOnly EndDate { get; set; }
    public string? Document { get; set; }
    public string? MerchantId { get; set; }
    public string? AccountId { get; set; }
    public bool? IsSandbox { get; set; }
    public string? AffiliationCodes { get; set; }
    public string? Organizations { get; set; }
    public string? S3Flag { get; set; }
    public string? UserAgent { get; set; }
    public string? Origin { get; set; }
    public string? Referer { get; set; }
    public string? CardBrands { get; set; }
    public bool? WithPayments { get; set; }
    public string? Email { get; set; }
    public string? WebhookUrl { get; set; }
    public string? ReportType { get; set; }
    public string? ProcessorQueueName { get; set; }
    public string? ReportId { get; set; }
    public string? FileFormat { get; set; }
    public DateTimeOffset? ReportDate { get; set; }
    public Dictionary<string, string>? Headers { get; set; }
    public string? StoneAccounts { get; set; }
    public string? PaymentProfiles { get; set; }
    public string? PoiTypes { get; set; }

    public GetFinancialMovementsRequestModel ToGetFinancialMovementsRequestModel(int? size, string? cursor = null)
    {
        return new GetFinancialMovementsRequestModel
        {
            Size = size,
            Cursor = cursor,
            StartDueDate = StartDate,
            EndDueDate = EndDate,
            Document = Document,
            MerchantId = MerchantId,
            AccountId = AccountId,
            AffiliationCodes = AffiliationCodes,
            Organizations = Organizations,
            Brands = CardBrands,
            WithPayments = WithPayments,
            StoneAccounts = StoneAccounts,
            PaymentProfiles = PaymentProfiles,
            PoiTypes = PoiTypes
        };
    }
}
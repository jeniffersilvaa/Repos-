namespace PaymentsDataLayerReports.Application.Workers.FinMovReportWorker;

public readonly struct WalletMapping(string brand, string product)
{
    public readonly string Brand = brand;
    public readonly string Product = product;
}

public static class FinMovDomainMappers
{
    private const string PREPAID_SUFFIX = " Pré-pago";
    private const string PREPAID_ACCOUNT_FUNDING = "prepaid";

    public static readonly Dictionary<string, string> CategoryTranslations;
    public static readonly Dictionary<string, string> TransactionBrands;
    public static readonly Dictionary<string, string> SettlementStatus;

    private static readonly Dictionary<string, WalletMapping> WalletMappings;
    private static readonly Dictionary<string, string> PrepaidProductCache;

    static FinMovDomainMappers()
    {
        CategoryTranslations = BuildCategoryTranslations();
        TransactionBrands = BuildTransactionBrandMapper();
        WalletMappings = BuildWalletMappings();
        SettlementStatus = BuildSettlementStatusMapper();
        PrepaidProductCache = BuildPrepaidProductCache();
    }

    private static Dictionary<string, string> BuildPrepaidProductCache()
    {
        var cache = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        foreach (var kvp in WalletMappings)
        {
            cache[kvp.Key] = kvp.Value.Product + PREPAID_SUFFIX;
        }

        return cache;
    }

    private static Dictionary<string, string> BuildCategoryTranslations()
    {
        return new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { "prepayment_fee", "Desconto de Antecipação" },
            { "sale", "Venda" },
            { "prepayment_sale", "Venda" },
            { "chargeback", "Chargeback" },
            { "chargeback_refund", "Estorno de Chargeback" },
            { "pos_rent", "Mensalidade da Máquina" },
            { "internal_transfer", "Transferência Interna" },
            { "reversal", "Cancelamento" },
            { "partial_reversal", "Cancelamento Parcial" },
            { "financial_adjustment", "Ajuste Financeiro" },
            { "external_pos_rent", "Mensalidade da Máquina Externo" },
            { "transaction_split", "Split" },
            { "prepayment_transaction_split", "Split" },
            { "partial_chargeback", "Chargeback Parcial" },
            { "partial_chargeback_refund", "Estorno Chargeback Parcial" },
            { "charge", "Cobrança" },
            { "charge_refund", "Estorno de Cobrança" },
            { "prepayment_fee_refund", "Estorno de Desconto de Antecipação" },
            { "prepayment_withdraw", "Recebível Antecipado" },
            { "prepayment_deposit", "Recebimento de Antecipação" },
            { "prepayment_disbursement", "Recebimento de Antecipação" },
            { "prepayment_withdraw_reversal", "Estorno de Recebível Antecipado" },
            { "prepayment_deposit_reversal", "Estorno de Recebimento de Antecipação" },
            { "prepayment_fee_reversal", "Estorno de Desconto de Antecipação" },
            { "prepayment_disbursement_reversal", "Estorno de Recebimento de Antecipação" },
            { "cross_balance", "Balanceamento de Saldo" },
            { "loan", "Quitação de Empréstimo" },
            { "cross_balance_cross_account", "Balanceamento de Saldo Entre StoneCodes" },
            { "guarantee", "Garantia" },
            { "ownership_assignment", "Cessão" },
            { "pawn", "Penhora" },
            { "judicial_block", "Bloqueio Judicial" },
            { "discount_rate", "Desconto de MDR" },
            { "service_fee", "Desconto de MDR" },
            { "service_fee_refund", "Estorno de MDR" }
        };
    }

    private static Dictionary<string, string> BuildTransactionBrandMapper()
    {
        return new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { "BancoDoBrasil", "Banco do Brasil" },
            { "BancoBanestes", "Banco Banestes" },
            { "Santander", "Santander" },
            { "CaixaEconômicaFederal", "Caixa Econômica Federal" },
            { "BancoPan", "Banco Pan" },
            { "Bradesco", "Bradesco" },
            { "ItauUnibanco", "Itau Unibanco" },
            { "HSBCBankBrasil", "HSBC Bank Brasil" },
            { "BancoSafra", "Banco Safra" },
            { "Citibank", "Citibank" },
            { "BancoCitibankS.A.", "Banco Citibank S.A." }
        };
    }

    private static Dictionary<string, WalletMapping> BuildWalletMappings()
    {
        return new Dictionary<string, WalletMapping>(StringComparer.OrdinalIgnoreCase)
        {
            { "Default", new WalletMapping("Stone", "Stone") },
            { "VisaDebit", new WalletMapping("Visa", "Débito") },
            { "VisaCredit", new WalletMapping("Visa", "Crédito") },
            { "VisaPrePayment", new WalletMapping("Visa", "Crédito") },
            { "VisaDebitPrePayment", new WalletMapping("Visa", "Débito") },
            { "VisaVoucherPrepayment", new WalletMapping("Visa", "Voucher") },
            { "MasterDebit", new WalletMapping("MasterCard", "Débito") },
            { "MasterCredit", new WalletMapping("MasterCard", "Crédito") },
            { "MasterPrePayment", new WalletMapping("MasterCard", "Crédito") },
            { "MasterDebitPrePayment", new WalletMapping("MasterCard", "Débito") },
            { "MasterVoucherCredit", new WalletMapping("MasterCard", "Voucher") },
            { "MasterVoucherPrePayment", new WalletMapping("MasterCard", "Voucher") },
            { "HiperDebit", new WalletMapping("Hipercard", "Débito") },
            { "HiperCredit", new WalletMapping("Hipercard", "Crédito") },
            { "HiperPrePayment", new WalletMapping("Hipercard", "Crédito") },
            { "EloDebit", new WalletMapping("Elo", "Débito") },
            { "EloCredit", new WalletMapping("Elo", "Crédito") },
            { "EloPrePayment", new WalletMapping("Elo", "Crédito") },
            { "EloDebitPrePayment", new WalletMapping("Elo", "Débito") },
            { "EloVoucherCredit", new WalletMapping("Elo", "Voucher") },
            { "EloVoucherPrePayment", new WalletMapping("Elo", "Voucher") },
            { "AmexDebit", new WalletMapping("AmericanExpress", "Débito") },
            { "AmexCredit", new WalletMapping("AmericanExpress", "Crédito") },
            { "AmexPrePayment", new WalletMapping("AmericanExpress", "Crédito") },
            { "PaymentSlip", new WalletMapping("", "Boleto") },
            { "JudicialBlock", new WalletMapping("Stone", "Stone") },
            { "CabalDebit", new WalletMapping("Cabal", "Débito") },
            { "CabalCredit", new WalletMapping("Cabal", "Crédito") },
            { "CabalPrePayment", new WalletMapping("Cabal", "Crédito") },
            { "CabalDebitPrePayment", new WalletMapping("Cabal", "Débito") },
            { "UnionPayDebit", new WalletMapping("UnionPay", "Débito") },
            { "UnionPayCredit", new WalletMapping("UnionPay", "Crédito") },
            { "UnionPayPrePayment", new WalletMapping("UnionPay", "Crédito") },
            { "UnionPayDebitPrePayment", new WalletMapping("UnionPay", "Débito") }
        };
    }

    private static Dictionary<string, string> BuildSettlementStatusMapper()
    {
        return new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { "open", "Aberto" },
            { "scheduled", "Agendado" },
            { "timeout", "Agendado" },
            { "rejected", "Rejeitado" },
            { "paid", "Pago" }
        };
    }

    private static string? MapValue(Dictionary<string, string> mapper, string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
            return value;

        return mapper.TryGetValue(value, out var mapped) ? mapped : value;
    }

    public static string? TranslateCategory(string? category)
        => MapValue(CategoryTranslations, category);

    public static string? MapTransactionBrand(string? transactionBrand, string? walletDescription = null)
    {
        if (!string.IsNullOrWhiteSpace(transactionBrand))
        {
            var mapped = MapValue(TransactionBrands, transactionBrand);
            if (mapped != transactionBrand)
                return mapped;
        }

        if (!string.IsNullOrWhiteSpace(walletDescription) && WalletMappings.TryGetValue(walletDescription, out var walletMapping))
        {
            return string.IsNullOrEmpty(walletMapping.Brand) ? null : walletMapping.Brand;
        }

        return transactionBrand;
    }

    public static string? MapWalletToProduct(string? walletDescription, string? accountFundingSource = null)
    {
        if (string.IsNullOrWhiteSpace(walletDescription))
            return walletDescription;

        if (string.Equals(accountFundingSource, PREPAID_ACCOUNT_FUNDING, StringComparison.OrdinalIgnoreCase))
            return MapValue(PrepaidProductCache, walletDescription);

        if (WalletMappings.TryGetValue(walletDescription, out var walletMapping))
            return walletMapping.Product;

        return walletDescription;
    }

    public static string? MapSettlementStatus(string? status)
        => MapValue(SettlementStatus, status);
}

using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.ChargeList;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.ChargesEvents;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.FinMovList;


namespace PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;

public interface IReportGenerator<TInput>
{
    Task Execute(TInput input);
}

public interface IReportTypeFactory
{
    IReportGenerator<TInput> Create<TInput>(ReportTypeEnum reportType);
}

public class ReportTypeFactory(
   ChargeListReportGenerator generateChargeListReportHandler,
   ChargesEventsReportGenerator chargeEventsReportGenerator,
   FinMovListReportGenerator receivablesReportGenerator
   ) : IReportTypeFactory
{

    public virtual IReportGenerator<TInput> Create<TInput>(ReportTypeEnum reportType)
    {
        return reportType.Name switch
        {
            "sales_stone" or "sales_ton" or "charges_list" or "sales" => (IReportGenerator<TInput>)generateChargeListReportHandler,
            "charges_events" => (IReportGenerator<TInput>)chargeEventsReportGenerator,
            "receivables" or "receivables_legacy" => (IReportGenerator<TInput>)receivablesReportGenerator,
            _ => throw new ArgumentException("Invalid report type"),
        };
    }
}
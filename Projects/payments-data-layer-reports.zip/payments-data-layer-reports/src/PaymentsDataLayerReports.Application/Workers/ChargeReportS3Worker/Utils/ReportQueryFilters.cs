using PaymentsDataLayerReports.Application.Services.DeltaTableColumnMapping;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.Models;


namespace PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;

public static class ReportQueryFilters
{
    public static List<string> BuildBaseFilters(GenerateReportInput reportInput, List<string> allowedFinancialMovementCategories, ColumnMapping? columnMapping = null, bool isRealTime = false)
    {
        var parameters = reportInput.ReportMetadata.ChargeReportParameters!;
        var partitionSet = reportInput.PartitionSet;

        var whereClauses = new List<string>
        {
            $"created_at::TIMESTAMPTZ >= '{parameters.StartDate:o}'::TIMESTAMPTZ",
            $"created_at::TIMESTAMPTZ <= '{parameters.EndDate:o}'::TIMESTAMPTZ"
        };

        var field = partitionSet.PartitionIdReferenceType switch
        {
            "document" => "merchant__document",
            "merchant_id" => "merchant__merchant_id",
            _ => throw new InvalidOperationException($"Unknown PartitionIdReferenceType: {partitionSet.PartitionIdReferenceType}")
        };

        var values = string.Join(",", partitionSet.PartitionIdReferences.Select(p => "'" + p.Trim() + "'"));

        var column = ColumnMappingService.GetColumnNameForFilter(field, columnMapping);

        whereClauses.Add($"{column} IN ({values})");

        var identityFilter = BuildIdentityFilter(reportInput, columnMapping);

        if (!string.IsNullOrEmpty(identityFilter))
        {
            whereClauses.Add(identityFilter);
        }

        if (parameters.IsSandbox.HasValue && !isRealTime)
        {
            var sandboxColumn = ColumnMappingService.GetColumnNameForFilter("merchant__is_sandbox", columnMapping);
            whereClauses.Add($"{sandboxColumn} = {parameters.IsSandbox.Value.ToString().ToLower()}");
        }

        if (!string.IsNullOrEmpty(parameters.PaymentMethods))
        {
            var paymentMethodColumn = ColumnMappingService.GetColumnNameForFilter("payment_method", columnMapping);
            whereClauses.Add($"{paymentMethodColumn} IN ({FormatInValues(parameters.PaymentMethods)})");
        }

        if (!string.IsNullOrEmpty(parameters.AccountId))
        {
            var accountIdColumn = ColumnMappingService.GetColumnNameForFilter("merchant__account_id", columnMapping);
            whereClauses.Add($"{accountIdColumn} IN ({FormatInValues(parameters.AccountId)})");
        }

        if (!string.IsNullOrEmpty(parameters.AffiliationCodes))
        {
            var affiliationColumn = ColumnMappingService.GetColumnNameForFilter("merchant__affiliation_code", columnMapping);
            whereClauses.Add($"{affiliationColumn} IN ({FormatInValues(parameters.AffiliationCodes)})");
        }

        var cardCategoryColumn = ColumnMappingService.GetColumnNameForFilter("card_transaction__financial_movement__category", columnMapping);
        var boletoCategoryColumn = ColumnMappingService.GetColumnNameForFilter("boleto_transaction__financial_movement__category", columnMapping);
        var pixCategoryColumn = ColumnMappingService.GetColumnNameForFilter("pix_transaction__financial_movement__category", columnMapping);

        var categoryFilters = BuildFinancialMovementCategoryFilters(
            allowedFinancialMovementCategories,
            cardCategoryColumn,
            boletoCategoryColumn,
            pixCategoryColumn
        );
        whereClauses.AddRange(categoryFilters);

        return whereClauses;
    }

    private static string BuildIdentityFilter(GenerateReportInput reportInput, ColumnMapping? columnMapping = null)
    {
        var parameters = reportInput.ReportMetadata.ChargeReportParameters!;
        var legacyFilter = string.Empty;
        var oneStoneFilter = string.Empty;

        var stoneAccounts = parameters.StoneAccounts;
        var poiTypes = parameters.PoiTypes;
        var paymentProfiles = parameters.PaymentProfiles;

        if (!string.IsNullOrEmpty(parameters.Organizations))
        {
            var organizationColumn = ColumnMappingService.GetColumnNameForFilter("merchant__organization", columnMapping);

            legacyFilter = $"{organizationColumn} IN ({FormatInValues(parameters.Organizations)})";
        }

        if (!string.IsNullOrEmpty(stoneAccounts))
        {
            var stoneAccountColumn = ColumnMappingService.GetColumnNameForFilter("merchant__stone_account", columnMapping);
            oneStoneFilter = $"{stoneAccountColumn} IN ({FormatInValues(stoneAccounts)})";

            if (!string.IsNullOrEmpty(poiTypes))
            {
                var poiTypeColumn = ColumnMappingService.GetColumnNameForFilter("point_of_interaction_type", columnMapping);
                oneStoneFilter += $" AND {poiTypeColumn} IN ({FormatInValues(poiTypes)})";
            }
            if (!string.IsNullOrEmpty(paymentProfiles))
            {
                var paymentProfileColumn = ColumnMappingService.GetColumnNameForFilter("merchant__payment_profile_id", columnMapping);
                oneStoneFilter += $" AND {paymentProfileColumn} IN ({FormatInValues(paymentProfiles)})";
            }
        }

        if (!string.IsNullOrEmpty(legacyFilter) && !string.IsNullOrEmpty(oneStoneFilter))
        {
            return $"(({legacyFilter}) or ({oneStoneFilter}))";
        }
        else if (!string.IsNullOrEmpty(legacyFilter))
        {
            return legacyFilter;
        }
        else if (!string.IsNullOrEmpty(oneStoneFilter))
        {
            return oneStoneFilter;
        }
        return string.Empty;
    }

    private static string FormatInValues(string values) =>
    string.Join(",", values.Split(',').Select(v =>
    {
        var trimmedValue = v.Trim();
        var escapedValue = trimmedValue.Replace("'", "''");
        return $"'{escapedValue}'";
    }));

    private static List<string> BuildFinancialMovementCategoryFilters(List<string> allowedCategories, params string[] columnNames)
    {
        if (allowedCategories.Count == 0)
            return [];

        var formattedCategories = string.Join(",", allowedCategories.Select(c => $"'{c.Replace("'", "''")}'"));
        var clauses = new List<string>();

        foreach (var columnName in columnNames)
        {
            clauses.Add($"({columnName} IS NULL OR {columnName} = '' OR {columnName} IN ({formattedCategories}))");
        }

        return clauses;
    }
}
using System.Globalization;
using System.Text.Json;
using PaymentsDataLayerReports.Application.Extensions;
using PaymentsDataLayerReports.Application.Workers.Shared;

namespace PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;

public class CsvRow
{
    private readonly object?[] _fields;

    public CsvRow(int fieldCount)
    {
        _fields = new object?[fieldCount];
    }

    public CsvRow(object?[] defaultValues)
    {
        // Initialize from a deep copy of default values
        _fields = new object?[defaultValues.Length];
        ClearRow(defaultValues);
    }

    public void SetField(int index, object? value)
    {
        if (index < _fields.Length && value != null)
            _fields[index] = value;
    }

    public object? GetField(Dictionary<string, int> index, string key)
    {
        if (index.TryGetValue(key, out int indexValue))
        {
            if (indexValue < 0 || indexValue >= _fields.Length)
            {
                throw new IndexOutOfRangeException(
                    $"Field '{key}' has index {indexValue} but _fields array has only {_fields.Length} elements"
                );
            }
            return _fields[indexValue];
        }

        return null;
    }

    public T? GetField<T>(Dictionary<string, int> index, string key)
    {
        if (index == null)
            throw new ArgumentNullException(nameof(index), $"Index dictionary is null when trying to get field '{key}'");

        Type targetType = typeof(T);

        try
        {
            if (targetType == typeof(string))
                return (T?)(object?)GetFieldAsString(index, key);

            if (targetType == typeof(int) || targetType == typeof(int?))
                return (T?)(object?)GetFieldAsInt(index, key);

            if (targetType == typeof(decimal) || targetType == typeof(decimal?))
                return (T?)(object?)GetFieldAsDecimal(index, key);

            if (targetType == typeof(DateTime) || targetType == typeof(DateTime?))
                return (T?)(object?)GetFieldAsDateTime(index, key);

            if (targetType == typeof(bool) || targetType == typeof(bool?))
                return (T?)(object?)GetFieldAsBool(index, key);

            throw new NotImplementedException($"GetField<{typeof(T).Name}> is not implemented for this type.");
        }
        catch (NullReferenceException ex)
        {
            var indexValue = index.TryGetValue(key, out int idx) ? idx : -1;
            var fieldValue = indexValue >= 0 && indexValue < _fields.Length ? _fields[indexValue] : null;
            var fieldValueType = fieldValue?.GetType().Name ?? "null";

            throw new InvalidOperationException(
                $"NullReferenceException when getting field '{key}' of type '{targetType.Name}'. " +
                $"Fields array length: {_fields.Length}. " +
                $"Index has key: {index.ContainsKey(key)}. " +
                $"Field index: {indexValue}. " +
                $"Field value type: {fieldValueType}. " +
                $"Original exception: {ex.Message}", ex
            );
        }
    }

    private string? GetFieldAsString(Dictionary<string, int> index, string key)
    {
        var field = GetField(index, key);
        if (field is decimal decimalValue)
            return decimalValue.ToString(CultureInfo.InvariantCulture);
        if (field is double doubleValue)
            return doubleValue.ToString(CultureInfo.InvariantCulture);
        if (field is float floatValue)
            return floatValue.ToString(CultureInfo.InvariantCulture);

        return field?.ToString();
    }

    private int? GetFieldAsInt(Dictionary<string, int> index, string key)
    {
        if (int.TryParse(GetFieldAsString(index, key), NumberStyles.Any, CultureInfo.InvariantCulture, out int result))
            return result;
        return null;
    }

    private decimal? GetFieldAsDecimal(Dictionary<string, int> index, string key)
    {
        if (decimal.TryParse(GetFieldAsString(index, key), NumberStyles.Any, CultureInfo.InvariantCulture, out decimal result))
            return result;
        return null;
    }

    private DateTime? GetFieldAsDateTime(Dictionary<string, int> index, string key)
    {
        try
        {
            if (DateTime.TryParse(GetFieldAsString(index, key), out DateTime result))
                return result;
            return null;
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException(
                $"Error parsing DateTime for field '{key}'. " +
                $"Fields array length: {_fields.Length}. " +
                $"Exception: {ex.Message}", ex);
        }
    }

    private bool? GetFieldAsBool(Dictionary<string, int> index, string key)
    {
        try
        {
            if (bool.TryParse(GetFieldAsString(index, key), out bool result))
                return result;
            return null;
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException(
                $"Error parsing Boolean for field '{key}'. " +
                $"Fields array length: {_fields.Length}. " +
                $"Exception: {ex.Message}", ex);
        }
    }

    public void ClearRow()
    {
        Array.Clear(_fields, 0, _fields.Length);
    }

    public void ClearRow(object?[] defaultValues)
    {
        // Clear row from a deep copy of default values
        foreach (var (value, index) in defaultValues.Select((value, index) => (value, index)))
        {
            _fields[index] = value.DeepCopy();
        }
    }

    public override string ToString()
    {
        return string.Join(",", _fields.Select(f =>
        {
            if (f is IDictionary<string, object> dict)
                return CsvHelper.EscapeCsv(JsonSerializer.Serialize(dict, SnakeCaseJsonSerializerOptions));
            else if (f is IEnumerable<IDictionary<string, object>> listDict)
                return CsvHelper.EscapeCsv(JsonSerializer.Serialize(listDict, SnakeCaseJsonSerializerOptions));
            else if (f is decimal decimalValue)
                return CsvHelper.EscapeCsv(decimalValue.ToString(CultureInfo.InvariantCulture));
            else if (f is double doubleValue)
                return CsvHelper.EscapeCsv(doubleValue.ToString(CultureInfo.InvariantCulture));
            else if (f is float floatValue)
                return CsvHelper.EscapeCsv(floatValue.ToString(CultureInfo.InvariantCulture));
            else if (f != null)
                return CsvHelper.EscapeCsv(f.ToString());
            else
                return string.Empty;
        }));
    }

    private static readonly JsonSerializerOptions SnakeCaseJsonSerializerOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower,
        Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
        Converters = { new CustomDateTimeConverter() }
    };
}
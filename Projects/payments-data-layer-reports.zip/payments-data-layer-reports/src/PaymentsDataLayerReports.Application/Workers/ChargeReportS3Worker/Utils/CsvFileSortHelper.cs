using System.Diagnostics;
using PaymentsDataLayerReports.Application.Services.ReportTypeConfiguration;

namespace PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;

public static class CsvFileSortHelper
{
    public static void SortByColumnIndex(
        string bashPath,
        string inputFilePath,
        string outputFilePath,
        char separator,
        int columnIndex,
        bool descending = false)
    {
        var direction = descending ? "r" : "";
        RunSort(bashPath, inputFilePath, outputFilePath, separator, $"-k{columnIndex},{columnIndex}{direction}");
    }

    public static void SortByColumns(
        string bashPath,
        string inputFilePath,
        string outputFilePath,
        char separator,
        SortColumn[] sortColumns)
    {
        var sortKeys = string.Join(" ", sortColumns.Select(c =>
        {
            var col = c.ColumnIndex + 1; // sort -k uses 1-based column indexing
            var dir = c.Descending ? "r" : "";
            return $"-k{col},{col}{dir}";
        }));
        RunSort(bashPath, inputFilePath, outputFilePath, separator, sortKeys);
    }

    private static void RunSort(string bashPath, string inputFilePath, string outputFilePath, char separator, string sortKeys)
    {
        using var process = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = bashPath,
                Arguments = $"-c \"sort -t'{separator}' {sortKeys} --buffer-size=50M '{inputFilePath}' > '{outputFilePath}'\"",
                RedirectStandardOutput = false,
                UseShellExecute = false
            }
        };
        process.Start();
        process.WaitForExit();
        if (process.ExitCode != 0)
            throw new Exception($"Sort process failed with exit code {process.ExitCode}");
    }
}

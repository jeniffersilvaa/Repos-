using System.Text;
using Datadog.Trace;
using PaymentsDataLayerReports.Application.Extensions;
using Serilog;

namespace PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;

public static class CsvHelper
{
    public static string GetHeader(string line)
    {
        using var scope = Tracer.Instance.StartActive("CsvHelper.GetHeader");
        Log.Debug("[CsvHelper.GetHeader] Starting");
        using var reader = new StreamReader(line);
        var inputHeader = reader.ReadLine();
        if (!inputHeader.HasValue())
            throw new InvalidOperationException($"File {line} is empty or does not have a header.");

        return inputHeader!;
    }

    public static string ExtractId(string line)
    {
        int commaCount = 0;
        int idStart = 0;

        var lineAsSpan = line.AsSpan();
        for (int i = 0; i < lineAsSpan.Length; i++)
        {
            if (lineAsSpan[i] == ',')
            {
                commaCount++;
                if (commaCount == 2)
                {
                    idStart = i + 1;
                }
                else if (commaCount == 3)
                {
                    return lineAsSpan[idStart..i].ToString();
                }
            }
        }
        return commaCount == 2 ? lineAsSpan[idStart..].ToString() : string.Empty;
    }

    public static CsvRow ParseCsvRow(string line, int fieldCount)
    {
        var row = new CsvRow(fieldCount);
        bool inQuotes = false;
        int fieldStart = 0;
        int fieldIndex = 0;

        var lineAsSpan = line.AsSpan();
        for (int i = 0; i <= lineAsSpan.Length; i++)
        {
            if (i == lineAsSpan.Length || (i < lineAsSpan.Length && lineAsSpan[i] == ',' && !inQuotes))
            {
                var field = lineAsSpan[fieldStart..i];
                if (!field.IsEmpty)
                {
                    if (field.Length > 1 && field[0] == '"' && field[^1] == '"')
                    {
                        // Remove outer quotes and unescape double quotes
                        var inner = field[1..^1];
                        var sb = new StringBuilder(inner.Length);
                        for (int j = 0; j < inner.Length; j++)
                        {
                            if (inner[j] == '"' && j + 1 < inner.Length && inner[j + 1] == '"')
                            {
                                sb.Append('"');
                                j++; // skip duplicated quote
                            }
                            else
                            {
                                sb.Append(inner[j]);
                            }
                        }
                        row.SetField(fieldIndex, sb.ToString());
                    }
                    else
                    {
                        row.SetField(fieldIndex, field.ToString());
                    }
                }
                fieldIndex++;
                fieldStart = i + 1;
            }
            else if (i < lineAsSpan.Length && lineAsSpan[i] == '"')
            {
                inQuotes = !inQuotes;
            }
        }
        return row;
    }

    public static string EscapeCsv(string? value)
    {
        if (string.IsNullOrEmpty(value))
            return string.Empty; // Do not quote empty strings
        if (value.Contains(',') || value.Contains('"') || value.Contains('\n'))
            return $"\"{value.Replace("\"", "\"\"")}\"";
        return value;
    }
}
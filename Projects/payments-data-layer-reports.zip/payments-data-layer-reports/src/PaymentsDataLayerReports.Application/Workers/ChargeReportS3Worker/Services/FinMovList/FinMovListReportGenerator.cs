using System.Diagnostics;
using Datadog.Trace;
using PaymentsDataLayerReports.Application.Constants;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Services.ReportTypeConfiguration;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.Models;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;
using PaymentsDataLayerReports.Application.Workers.Shared.Modifiers.FinMov;
using Serilog;

namespace PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.FinMovList;

public class FinMovListReportGenerator(IDeltaLakeManager deltaLakeManager,
    IS3ClientWrapper s3ClientWrapper) : IReportGenerator<GenerateReportInput>
{
    private static readonly ReceivablesOneStoneModifier ReceivablesOneStoneModifier = new();

    private static string GetHeader(string? reportType)
    {
        return ReportTypeConfigurationProvider.UsesOneStoneLayout(reportType)
            ? ReceivablesOneStoneModifier.GetHeader()
            : ReceivablesModifier.GetHeader();
    }

    public async Task Execute(GenerateReportInput input)
    {
        var reportMetadata = input.ReportMetadata;
        var cancellationToken = input.CancellationToken;
        var jobId = input.JobId;
        var reportType = reportMetadata.FinMovReportParameters?.ReportType
            ?? throw new InvalidOperationException("FinMovReportParameters.ReportType is required");

        using var scope = Tracer.Instance.StartActive("FinMovListReportGenerator.Execute");
        scope.Span.SetTag("FinMovListReportGenerator.Execute.JobId", jobId);
        scope.Span.SetTag("FinMovListReportGenerator.Execute.ReportId", reportMetadata.ReportId);
        scope.Span.SetTag("FinMovListReportGenerator.Execute.ReportDate", $"{input.PartitionDate:yyyy-MM-dd}");

        Log.ForContext("Parameters", reportMetadata.FinMovReportParameters)
            .ForContext("JobId", jobId)
            .ForContext("ReportId", reportMetadata.ReportId)
            .ForContext("PartitionDate", input.PartitionDate)
            .Debug("[FinMovListReportGenerator.Execute] Starting fin mov list report");

        var stopwatch = Stopwatch.StartNew();
        using var finMovReport = new FinMovListReportManager();

        try
        {
            // Writes header file before processing the first date's report
            if (input.ReportMetadata.FinMovReportParameters?.StartDate == DateOnly.FromDateTime(input.PartitionDate))
            {
                await s3ClientWrapper.UploadReportHeaderAsync(
                    input.ReportMetadata.ReportId,
                    GetHeader(reportType)
                );
            }

            var totalFileSize = await deltaLakeManager.DownloadAsync(input, finMovReport.FinMovListRawParquetPath);

            var hasParquetData = totalFileSize > 0;

            if (!hasParquetData)
            {
                Log.ForContext("JobId", jobId)
                   .ForContext("ReportId", reportMetadata.ReportId)
                   .ForContext("PartitionDate", input.PartitionDate)
                   .Debug($"[FinMovListReportGenerator.Execute] No data available");
                return;
            }

            var (csvCount, csvFileSize) = await deltaLakeManager.ConvertToCsvAsync(
                input,
                finMovReport.FinMovListRawParquetPath,
                finMovReport.FinMovEventsListRawCsvFile,
                false,
                hasParquetData
            );

            var totalDiskUsage = totalFileSize + csvFileSize;
            var totalDiskUsageMB = totalDiskUsage / (1024.0 * 1024.0);
            scope.Span.SetTag("FinMovListReportGenerator.Execute.total_disk_usage_bytes", totalDiskUsage.ToString());
            scope.Span.SetTag("FinMovListReportGenerator.Execute.total_disk_usage_mb", totalDiskUsageMB.ToString("F2"));

            if (csvCount == 0)
            {
                Log.ForContext("JobId", jobId)
                   .ForContext("ReportId", reportMetadata.ReportId)
                   .ForContext("PartitionDate", input.PartitionDate)
                   .Debug($"[FinMovListReportGenerator.Execute] Empty CSV file after converting to CSV");
                return;
            }

            finMovReport.TryDeleteParquetPath();

            finMovReport.SortFinMovEventsByIdAndDueDateDesc(jobId, reportMetadata.ReportId, input.PartitionDate);

            finMovReport.TryDeleteFile(finMovReport.FinMovEventsListRawCsvFile);

            // Groups events into fin_movs 
            Log.ForContext("JobId", jobId)
                .ForContext("ReportId", reportMetadata.ReportId)
                .ForContext("PartitionDate", input.PartitionDate)
                .ForContext("TotalDiskUsageMB", totalDiskUsageMB)
                .Debug($"[FinMovListReportGenerator.Execute] Grouping events by fin_mov id");
            await using var FinMovEventsSortedByIdStream = new FileStream(finMovReport.FinMovListSortedByEventIdAndDueDateDescCsvFile, FileMode.Open, FileAccess.Read, FileShare.Read);
            await using var FinMovRawStream = new FileStream(finMovReport.FinMovListRawCsvFile, FileMode.Create, FileAccess.Write, FileShare.None);

            await FinMovListReportService.ProcessAsync(
                FinMovEventsSortedByIdStream,
                FinMovRawStream,
                FinMovListReportHeader.HeaderRowWithMovements,
                reportMetadata.ReportId,
                jobId,
                reportType,
                cancellationToken
            );

            // Delete sorted by fin_mov id CSV file
            finMovReport.TryDeleteFile(finMovReport.FinMovListSortedByEventIdAndDueDateDescCsvFile);

            // Sort fin_movs by due date (matches partition key for correct sequential concatenation)
            var reportConfig = ReportTypeConfigurationProvider.GetConfiguration(reportType)
                ?? throw new InvalidOperationException($"Report configuration not found for type {reportType}");
            var separator = CsvSeparatorConstants.GetSeparator(reportConfig.CsvSeparator);
            var sortColumns = reportConfig.SortColumns ?? [new SortColumn(reportConfig.ReportSortColumnIndex)];
            finMovReport.SortFinMovByDueDate(jobId, reportMetadata.ReportId, input.PartitionDate, separator, sortColumns);

            // Delete raw CSV file
            finMovReport.TryDeleteFile(finMovReport.FinMovListRawCsvFile);

            await s3ClientWrapper.UploadReportAsync(
                sourcePath: finMovReport.FinMovSortedByDueDateCsvFile,
                reportId: reportMetadata.ReportId,
                partitionIdGroup: input.PartitionSet.GetPartitionIdGroup(),
                partitionDate: input.PartitionDate
            );
        }
        catch (Exception ex)
        {
            Log.ForContext("Exception", ex)
              .ForContext("JobId", jobId)
              .ForContext("ReportId", reportMetadata.ReportId)
              .ForContext("PartitionDate", input.PartitionDate)
              .Error("[FinMovListReportGenerator.Execute] Error processing fin mov list report");
            throw;
        }
        finally
        {
            stopwatch.Stop();
            Log.ForContext("Duration", stopwatch.Elapsed.TotalSeconds)
              .ForContext("JobId", jobId)
              .ForContext("ReportId", reportMetadata.ReportId)
              .ForContext("PartitionDate", input.PartitionDate)
              .Debug($"[FinMovListReportGenerator.Execute] Fin mov list report completed");
        }
    }
}

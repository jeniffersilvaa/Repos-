using Datadog.Trace;
using PaymentsDataLayerReports.Application.Services.ReportTypeConfiguration;
using PaymentsDataLayerReports.Application.Types;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;
using PaymentsDataLayerReports.Application.Workers.Shared.Modifiers.FinMov;
using Serilog;

namespace PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.FinMovList;

public static class FinMovListReportService
{
    private static readonly ReceivablesOneStoneModifier ReceivablesOneStoneModifier = new();

    public static async Task ProcessAsync(
        Stream input,
        Stream output,
        string inputHeader,
        string reportId,
        string jobId,
        string? reportType,
        CancellationToken cancellationToken
    )
    {
        using var scope = Tracer.Instance.StartActive("FinMovListReportService.ProcessAsync");

        Log.ForContext("JobId", jobId)
            .ForContext("ReportId", reportId)
            .Debug($"[FinMovListReportService.ProcessAsync] Starting");

        var start = BetterStopwatch.GetTimestamp();

        // Build input column index map
        var inputHeaderList = inputHeader.Split(',');
        var inputHeaderIndex = new Dictionary<string, int>();
        for (int i = 0; i < inputHeaderList.Length; i++)
            inputHeaderIndex[inputHeaderList[i]] = i;
        int inputHeaderCount = inputHeaderList.Length;

        // Setup streams
        using var reader = new StreamReader(input);
        using var writer = new StreamWriter(output) { AutoFlush = true };


        // Extract initial ID
        string? previousId = null;
        CsvRow? currentFinMov = null;

        while (true)
        {
            string? currentEventAsString = await reader.ReadLineAsync(cancellationToken);

            if (currentEventAsString == null)
            {
                // Write last FinMov if exists
                if (currentFinMov != null) await WriteReceivableToCsv(writer, currentFinMov, reportType, cancellationToken);
                break;
            }

            var currentEvent = CsvHelper.ParseCsvRow(currentEventAsString, inputHeaderCount);
            var currentId = currentEvent.GetField<string?>(inputHeaderIndex, "id");


            // If group changed and it's not the first, write the previous group
            if (previousId != null && currentId != previousId)
            {
                await WriteReceivableToCsv(writer, currentFinMov, reportType, cancellationToken);
                currentFinMov?.ClearRow(FinMovListReportHeader.DefaultValues);
            }

            // Initialize if null
            currentFinMov ??= new CsvRow(FinMovListReportHeader.DefaultValues);

            ProcessFinMovEventRow(currentEvent, currentFinMov, inputHeaderIndex);
            previousId = currentId;
        }

        Log.ForContext("JobId", jobId)
            .ForContext("ReportId", reportId)
            .ForContext("TotalSeconds", BetterStopwatch.GetElapsedTime(start).TotalSeconds)
            .Debug($"[FinMovListReportService.ProcessAsync] Completed");
    }

    private static async Task WriteReceivableToCsv(StreamWriter writer, CsvRow? currentFinMov, string? reportType, CancellationToken cancellationToken)
    {
        PostProcessFinMov(currentFinMov!);
        string? receivable = ReportTypeConfigurationProvider.UsesOneStoneLayout(reportType)
            ? ReceivablesOneStoneModifier.BuildRow(currentFinMov!)
            : ReceivablesModifier.BuildRow(currentFinMov!);
        await writer.WriteLineAsync(receivable.AsMemory(), cancellationToken);
    }

    private static void ProcessFinMovEventRow(CsvRow currentEvent, CsvRow currentFinMov, Dictionary<string, int> inputHeaderIndex)
    {
        FinMovProcessor.Process(currentEvent, currentFinMov, inputHeaderIndex);
    }

    private static void PostProcessFinMov(CsvRow currentFinMov)
    {
        FinMovProcessor.ComputeAmounts(currentFinMov);
    }
}

public static class FinMovProcessor
{
    public static void Process(CsvRow currentEvent, CsvRow currentFinMov, Dictionary<string, int> inputHeaderIndex)
    {
        SetFields(currentEvent, currentFinMov, inputHeaderIndex);
        AppendMovements(currentEvent, currentFinMov, inputHeaderIndex);
    }

    private static void SetFields(CsvRow currentEvent, CsvRow currentFinMov, Dictionary<string, int> inputHeaderIndex)
    {
        var asIsFields = new[]
        {
            "id",
            "operation_id",
            "original_due_date",
            "current_due_date",
            "created_at",
            "updated_at",
            "merchant__organization",
            "merchant__user_id",
            "merchant__document",
            "merchant__affiliation_key",
            "merchant__affiliation_code",
            "merchant__company_id",
            "merchant__recipient_id",
            "payment_owner__organization",
            "payment_owner__user_id",
            "payment_owner__document",
            "payment_owner__affiliation_key",
            "payment_owner__affiliation_code",
            "payment_owner__payment_profile_id",
            "payment_owner__company_id",
            "payment_owner__recipient_id",
            "transaction__key",
            "transaction__operation_key",
            "transaction__capture_date",
            "transaction__brand",
            "transaction__product",
            "transaction__authorization_date",
            "transaction__account_funding_source",
            "transaction__installment_number",
            "transaction__installment_quantity",
            "transaction__gateway_id",
            "transaction__point_of_interaction_type",
            "settlement__status",
            "settlement__key",
            "settlement__balance_due_date",
            "settlement__payment_date",
            "settlement__wallet__nature",
            "settlement__wallet__type_id",
            "settlement__wallet__description",
            "settlement__payment__payment_date",
            "settlement__payment__status",
            "settlement__payment__account__account_number",
            "settlement__payment__account__account_check_digit",
            "settlement__payment__account__account_type",
            "settlement__payment__account__bank_code",
            "settlement__payment__account__branch_number",
            "settlement__payment__account__branch_check_digit",
            "settlement__payment__account__ispb",
            "legacy__bulk_anticipation_id",
            "legacy__anticipation_id",
            "legacy__originator_model_id",
            "legacy__originator_model",
            "legacy__liquidation_arrangement_id"
        };

        foreach (var field in asIsFields)
        {
            currentFinMov.SetField(FinMovListReportHeader.HeaderIndex[field], currentEvent.GetField<string>(inputHeaderIndex, field));
        }

        var isTransactional = currentEvent.GetField<string?>(inputHeaderIndex, "transaction__key");
        if (isTransactional != null)
        {
            SetLatestEventTimestamp(currentEvent, currentFinMov, inputHeaderIndex);
            SetTransactionCaptureDate(currentEvent, currentFinMov, inputHeaderIndex);
            SetTransactionAuthorizationDate(currentEvent, currentFinMov, inputHeaderIndex);
        }
    }

    private static void SetLatestEventTimestamp(CsvRow currentEvent, CsvRow currentFinMov, Dictionary<string, int> inputHeaderIndex)
    {
        var headerIndex = FinMovListReportHeader.HeaderIndex;
        var latestEventTimestampStr = currentFinMov.GetField<string?>(headerIndex, "latest_event_timestamp");
        var latestEventTimestamp = latestEventTimestampStr != null
            ? DateTime.Parse(latestEventTimestampStr)
            : (DateTime?)null;
        var eventTimestampStr = currentEvent.GetField<string?>(inputHeaderIndex, "event_timestamp");
        var eventTimestamp = eventTimestampStr != null
            ? DateTime.Parse(eventTimestampStr)
            : (DateTime?)null;
        if (latestEventTimestampStr == null || eventTimestamp >= latestEventTimestamp)
        {
            currentFinMov.SetField(headerIndex["latest_event_timestamp"], eventTimestampStr);
        }
    }

    private static void SetTransactionCaptureDate(CsvRow currentEvent, CsvRow currentFinMov, Dictionary<string, int> inputHeaderIndex)
    {
        var captureDate = currentEvent.GetField<DateTime?>(inputHeaderIndex, "transaction__capture_date");
        if (captureDate != default && captureDate.HasValue)
        {
            var utcCaptureDate = captureDate.Value.Kind == DateTimeKind.Unspecified
                ? DateTime.SpecifyKind(captureDate.Value, DateTimeKind.Utc)
                : captureDate.Value.ToUniversalTime();
            currentFinMov.SetField(FinMovListReportHeader.HeaderIndex["transaction__capture_date"], utcCaptureDate.ToString("yyyy-MM-ddTHH:mm:ss.fff" + "+00:00"));
        }
    }

    private static void SetTransactionAuthorizationDate(CsvRow currentEvent, CsvRow currentFinMov, Dictionary<string, int> inputHeaderIndex)
    {
        var authorizationDate = currentEvent.GetField<DateTime?>(inputHeaderIndex, "transaction__authorization_date");
        if (authorizationDate != default && authorizationDate.HasValue)
        {
            var utcAuthDate = authorizationDate.Value.Kind == DateTimeKind.Unspecified
                ? DateTime.SpecifyKind(authorizationDate.Value, DateTimeKind.Utc)
                : authorizationDate.Value.ToUniversalTime();
            currentFinMov.SetField(FinMovListReportHeader.HeaderIndex["transaction__authorization_date"], utcAuthDate.ToString("yyyy-MM-ddTHH:mm:ss.fff" + "+00:00"));
        }
    }

    private static void AppendMovements(
        CsvRow currentEvent,
        CsvRow currentFinMov,
        Dictionary<string, int> inputHeaderIndex
    )
    {
        var creationDate = currentEvent.GetField<DateTime?>(inputHeaderIndex, "movement__creation_date");
        DateTime? utcCreationDate = null;
        if (creationDate != default && creationDate.HasValue)
        {
            utcCreationDate = creationDate.Value.Kind == DateTimeKind.Unspecified
                ? DateTime.SpecifyKind(creationDate.Value, DateTimeKind.Utc)
                : creationDate.Value.ToUniversalTime();
        }

        var movement = new Dictionary<string, object?>
        {
            { "event_id", currentEvent.GetField(inputHeaderIndex, "movement__event_id") },
            { "category", currentEvent.GetField(inputHeaderIndex, "movement__category") },
            { "amount", currentEvent.GetField<decimal?>(inputHeaderIndex, "movement__amount") },
            { "fee", currentEvent.GetField<decimal?>(inputHeaderIndex, "movement__fee") },
            { "effective_fee", currentEvent.GetField<decimal?>(inputHeaderIndex, "movement__effective_fee") },
            { "fee_type", currentEvent.GetField(inputHeaderIndex, "movement__fee_type") },
            { "creation_date", utcCreationDate.HasValue ? utcCreationDate.Value.ToString("yyyy-MM-ddTHH:mm:ss.fff" + "+00:00") : null },
        };

        var currentMovements = currentFinMov.GetField(FinMovListReportHeader.HeaderIndex, "movements");

        if (currentMovements is List<Dictionary<string, object?>> movements)
        {
            // If the operation does not exist, add it to the list
            movements.Add(movement);
            return;
        }

        // If the list does not exist, create a new one
        currentMovements = new List<Dictionary<string, object?>> { movement };
        currentFinMov.SetField(FinMovListReportHeader.HeaderIndex["movements"], currentMovements);
    }

    public static void ComputeAmounts(CsvRow currentFinMov)
    {
        var movementsObj = currentFinMov.GetField(FinMovListReportHeader.HeaderIndex, "movements");
        if (movementsObj is not List<Dictionary<string, object?>> movements)
            return;

        // Acumulators
        decimal prepaymentFeeAmount = 0, discountRateAmount = 0, grossAmount = 0, fraudCoverageAmount = 0;

        string? discountRateFee = null, discountRateEffectiveFee = null, discountRateFeeType = null;
        HashSet<string> discountRateCategories = ["discount_rate", "service_fee", "service_fee_refund"];

        string? prepaymentFeeFee = null, prepaymentFeeEffectiveFee = null, prepaymentFeeFeeType = null;
        HashSet<string> prepaymentFeeCategories = ["prepayment_fee", "prepayment_fee_refund"];

        decimal prepaymentFeeTurboAmount = 0;
        string? prepaymentFeeTurboFee = null, prepaymentFeeTurboEffectiveFee = null, prepaymentFeeTurboFeeType = null;

        string fraudCoverageFeeCategory = "fraud_coverage";

        string? saleCategory = null, discountRateCategory = null, prepaymentFeeCategory = null;

        foreach (var movement in movements)
        {
            var movementCategory = movement.TryGetValue("category", out var mc) ? mc?.ToString() : null;
            var movementAmountStr = movement.TryGetValue("amount", out var ma) ? ma?.ToString() : null;
            var movementAmount = movementAmountStr != null ? decimal.Parse(movementAmountStr) : 0;
            var movementFee = movement.TryGetValue("fee", out var mf) ? mf?.ToString() : null;
            var movementEffectiveFee = movement.TryGetValue("effective_fee", out var mef) ? mef?.ToString() : null;
            var movementFeeType = movement.TryGetValue("fee_type", out var mft) ? mft?.ToString() : null;


            if (discountRateCategories.Contains(movementCategory))
            {
                discountRateCategory = movementCategory;
                discountRateAmount += movementAmount;
                discountRateFee = movementFee;
                discountRateEffectiveFee = movementEffectiveFee;
                discountRateFeeType = movementFeeType;
            }
            else if (prepaymentFeeCategories.Contains(movementCategory))
            {
                if (string.Equals(movementFeeType, "turbo", StringComparison.OrdinalIgnoreCase))
                {
                    prepaymentFeeTurboAmount += movementAmount;
                    prepaymentFeeTurboFee = movementFee;
                    prepaymentFeeTurboEffectiveFee = movementEffectiveFee;
                    prepaymentFeeTurboFeeType = movementFeeType;
                }
                else
                {
                    prepaymentFeeCategory = movementCategory;
                    prepaymentFeeAmount += movementAmount;
                    prepaymentFeeFee = movementFee;
                    prepaymentFeeEffectiveFee = movementEffectiveFee;
                    prepaymentFeeFeeType = movementFeeType;
                }
            }
            else if (movementCategory == fraudCoverageFeeCategory)
            {
                fraudCoverageAmount += movementAmount;
            }
            else
            {
                grossAmount += movementAmount;
                saleCategory = movementCategory;
            }
        }

        var netAmount = grossAmount + discountRateAmount + prepaymentFeeAmount + prepaymentFeeTurboAmount + fraudCoverageAmount;
        var operation = saleCategory ?? prepaymentFeeCategory ?? discountRateCategory;

        // Set fields
        currentFinMov.SetField(FinMovListReportHeader.HeaderIndex["operation"], operation);
        currentFinMov.SetField(FinMovListReportHeader.HeaderIndex["amount__net"], netAmount);
        currentFinMov.SetField(FinMovListReportHeader.HeaderIndex["amount__gross"], grossAmount);
        currentFinMov.SetField(FinMovListReportHeader.HeaderIndex["amount__discount_rate__amount"], discountRateAmount);
        currentFinMov.SetField(FinMovListReportHeader.HeaderIndex["amount__discount_rate__fee"], discountRateFee);
        currentFinMov.SetField(FinMovListReportHeader.HeaderIndex["amount__discount_rate__effective_fee"], discountRateEffectiveFee);
        currentFinMov.SetField(FinMovListReportHeader.HeaderIndex["amount__discount_rate__fee_type"], discountRateFeeType);
        currentFinMov.SetField(FinMovListReportHeader.HeaderIndex["amount__prepayment_fee__amount"], prepaymentFeeAmount);
        currentFinMov.SetField(FinMovListReportHeader.HeaderIndex["amount__prepayment_fee__fee"], prepaymentFeeFee);
        currentFinMov.SetField(FinMovListReportHeader.HeaderIndex["amount__prepayment_fee__effective_fee"], prepaymentFeeEffectiveFee);
        currentFinMov.SetField(FinMovListReportHeader.HeaderIndex["amount__prepayment_fee__fee_type"], prepaymentFeeFeeType);
        currentFinMov.SetField(FinMovListReportHeader.HeaderIndex["amount__prepayment_fee_turbo__amount"], prepaymentFeeTurboAmount);
        currentFinMov.SetField(FinMovListReportHeader.HeaderIndex["amount__prepayment_fee_turbo__fee"], prepaymentFeeTurboFee);
        currentFinMov.SetField(FinMovListReportHeader.HeaderIndex["amount__prepayment_fee_turbo__effective_fee"], prepaymentFeeTurboEffectiveFee);
        currentFinMov.SetField(FinMovListReportHeader.HeaderIndex["amount__prepayment_fee_turbo__fee_type"], prepaymentFeeTurboFeeType);
    }

}

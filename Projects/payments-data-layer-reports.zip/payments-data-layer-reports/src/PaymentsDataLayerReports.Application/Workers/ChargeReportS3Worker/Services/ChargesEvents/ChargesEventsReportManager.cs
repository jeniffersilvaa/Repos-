using System.Diagnostics;
using Datadog.Trace;
using Microsoft.Extensions.Options;
using PaymentsDataLayerReports.Application.Settings;
using Serilog;

namespace PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.ChargesEvents;

public class ChargeEventsReportManager : IDisposable
{
    private readonly string _bashPath;
    internal string ChargesEventsRawParquetPath { get; }
    internal string ChargesEventsRawCsvFile { get; }
    internal string ChargesEventsSortedByEventIdAndEventDatetimeDescCsvFile { get; }
    internal string ChargesRawCsvFile { get; }

    public ChargeEventsReportManager(
        IOptions<DataLayerReportsSettings> dataLayerReportsSettings
    )
    {
        _bashPath = dataLayerReportsSettings.Value.BashPath;
        ChargesEventsRawParquetPath = Path.Combine(Path.GetTempPath(), Path.GetRandomFileName());
        Directory.CreateDirectory(ChargesEventsRawParquetPath);
        ChargesEventsRawCsvFile = Path.GetTempFileName();
        ChargesEventsSortedByEventIdAndEventDatetimeDescCsvFile = Path.GetTempFileName();
        ChargesRawCsvFile = Path.GetTempFileName();
    }

    internal void SortChargesEventsByIdAndEventDatetimeDesc(string jobId, string reportId, DateTime reportDate, int processedAtColumnPosition, int columnCountWithoutProcessedAt)
    {
        using var scope = Tracer.Instance.StartActive("ChargeEventsReportManager.SortChargesEventsByIdAndEventDatetimeDesc");

        Log.ForContext("JobId", jobId)
          .ForContext("ReportId", reportId)
          .ForContext("ReportDate", reportDate)
          .Debug("[ChargeEventsReportManager.SortChargesEventsByIdAndEventDatetimeDesc] Sorting events by id");
        var skipHeaderCommand = $"tail -n +2 {ChargesEventsRawCsvFile}";
        var fillEmptyProcessedAtCommand = $"awk -F, -v OFS=, -v s='0000-00-00 00:00:00.000' '{{if (length(${processedAtColumnPosition}) == 0) ${processedAtColumnPosition} = s; print}}'";
        var sortByIdAndEventDatetime = $"sort -t, -k2,2 -k{processedAtColumnPosition},{processedAtColumnPosition}r -k1,1r --buffer-size=50M";
        var dedupByEventIdCommand = $@"awk -F, '$2 != last {{print; last = $2}}'";
        var stripProcessedAtCommand = $"cut -d, -f1-{columnCountWithoutProcessedAt}";
        var sortByEventDatetime = $"sort -t, -k1,1r --buffer-size=50M";

        using var sortChargesEventsByEventIdProcess = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = "/bin/bash",
                Arguments = $"-c \"{skipHeaderCommand} | {fillEmptyProcessedAtCommand} | {sortByIdAndEventDatetime} | {dedupByEventIdCommand} | {stripProcessedAtCommand} | {sortByEventDatetime} > '{ChargesEventsSortedByEventIdAndEventDatetimeDescCsvFile}'\"",
                RedirectStandardOutput = false,
                UseShellExecute = false
            }
        };
        sortChargesEventsByEventIdProcess.Start();
        sortChargesEventsByEventIdProcess.WaitForExit();
        if (sortChargesEventsByEventIdProcess.ExitCode != 0)
            throw new Exception($"sortEventsByChargeEventIdProcess failed with exit code {sortChargesEventsByEventIdProcess.ExitCode}");
    }

    internal bool ParquetPathHasFiles()
    {
        return Directory.Exists(ChargesEventsRawParquetPath) && Directory.GetFiles(ChargesEventsRawParquetPath, "*.parquet").Length > 0;
    }

    internal void TryDeleteParquetPath()
    {
        try { if (Directory.Exists(ChargesEventsRawParquetPath)) Directory.Delete(ChargesEventsRawParquetPath, true); } catch { }
    }

    internal void TryDeleteFile(string path)
    {
        try { if (File.Exists(path)) File.Delete(path); } catch { }
    }

    public void Dispose()
    {
        TryDeleteParquetPath();
        TryDeleteFile(ChargesEventsRawCsvFile);
        TryDeleteFile(ChargesEventsSortedByEventIdAndEventDatetimeDescCsvFile);
        TryDeleteFile(ChargesRawCsvFile);
        GC.SuppressFinalize(this);
    }
}

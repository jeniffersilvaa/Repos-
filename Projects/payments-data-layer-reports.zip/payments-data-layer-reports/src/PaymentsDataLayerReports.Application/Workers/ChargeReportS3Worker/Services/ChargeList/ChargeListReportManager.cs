using System.Diagnostics;
using Datadog.Trace;
using Microsoft.Extensions.Options;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;
using Serilog;

namespace PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.ChargeList;

public interface IChargeListReportManager : IDisposable
{
    string ChargesEventsRawParquetPath { get; }
    string ChargesEventsRawCsvFile { get; }
    string ChargesEventsSortedByIdCsvFile { get; }
    string ChargesRawCsvFile { get; }
    string ChargesFilteredCsvFile { get; }
    string ChargesSortedByCreatedAtCsvFile { get; }
    void SortEventsByChargeId(string jobId, string reportId, DateTime reportDate, int processedAtColumnPosition);
    void SortChargesByCreatedAt(string jobId, string reportId, DateTime reportDate, string inputFilePath, int createdAtColumnPosition, char separator);
    bool ParquetPathHasFiles();
    void TryDeleteParquetPath();
    void TryDeleteFile(string path);
}

public class ChargeListReportManager : IChargeListReportManager
{
    private readonly string _bashPath;
    public string ChargesEventsRawParquetPath { get; }
    public string ChargesEventsRawCsvFile { get; }
    public string ChargesEventsSortedByIdCsvFile { get; }
    public string ChargesRawCsvFile { get; }
    public string ChargesFilteredCsvFile { get; }
    public string ChargesSortedByCreatedAtCsvFile { get; }

    public ChargeListReportManager(
        IOptions<DataLayerReportsSettings> dataLayerReportsSettings
    )
    {
        _bashPath = dataLayerReportsSettings.Value.BashPath;

        // Temporary directory to download parquet files
        ChargesEventsRawParquetPath = Path.Combine(Path.GetTempPath(), Path.GetRandomFileName());
        Directory.CreateDirectory(ChargesEventsRawParquetPath);
        // Convert all parquet into this CSV file
        ChargesEventsRawCsvFile = Path.GetTempFileName();
        // CSV of charges events sorted by Id and remove duplicates
        ChargesEventsSortedByIdCsvFile = Path.GetTempFileName();
        // CSV of charges - charges events grouped by charge id
        ChargesRawCsvFile = Path.GetTempFileName();
        // CSV of charges filtered
        ChargesFilteredCsvFile = Path.GetTempFileName();
        // CSV of charges sorted by created_at
        ChargesSortedByCreatedAtCsvFile = Path.GetTempFileName();
    }

    public void SortEventsByChargeId(string jobId, string reportId, DateTime reportDate, int processedAtColumnPosition)
    {
        using var scope = Tracer.Instance.StartActive("ChargeListReportManager.SortEventsByChargeId");
        // Skip header + sort by sort_key, event_id, processed_at desc (nulls last), event_datetime desc + dedup by event_id
        Log.ForContext("JobId", jobId)
          .ForContext("ReportId", reportId)
          .ForContext("ReportDate", reportDate)
          .Debug("[ChargeListReportManager.SortEventsByChargeId] Sorting events by charge id");
        var skipHeaderCommand = $"tail -n +2 {ChargesEventsRawCsvFile}";
        var csvProcessedAtColumn = processedAtColumnPosition + 1; // +1 to account for sort_key column prepended by DuckDB query
        var fillEmptyProcessedAtCommand = $"awk -F, -v OFS=, -v s='0000-00-00 00:00:00.000' '{{if (length(${csvProcessedAtColumn}) == 0) ${csvProcessedAtColumn} = s; print}}'";
        var sortByIdEventIdEventDateCommand = $"sort -t, -k1,1 -k2,2 -k{csvProcessedAtColumn},{csvProcessedAtColumn}r -k3,3r --buffer-size=50M";
        var dedupByEventIdCommand = $"awk -F, '$2 != last {{print; last = $2}}'";
        using var sortEventsByChargeIdProcess = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = _bashPath,
                Arguments = $"-c \"{skipHeaderCommand} | {fillEmptyProcessedAtCommand} | {sortByIdEventIdEventDateCommand} | {dedupByEventIdCommand} > '{ChargesEventsSortedByIdCsvFile}'\"",
                RedirectStandardOutput = false,
                UseShellExecute = false
            }
        };
        sortEventsByChargeIdProcess.Start();
        sortEventsByChargeIdProcess.WaitForExit();
        if (sortEventsByChargeIdProcess.ExitCode != 0)
            throw new Exception($"sortEventsByChargeIdProcess failed with exit code {sortEventsByChargeIdProcess.ExitCode}");
    }

    public void SortChargesByCreatedAt(string jobId, string reportId, DateTime reportDate, string inputFilePath, int createdAtColumnPosition, char separator)
    {
        using var scope = Tracer.Instance.StartActive("ChargeListReportManager.SortChargesByCreatedAt");
        // Sort charges by created_at
        Log.ForContext("JobId", jobId)
          .ForContext("ReportId", reportId)
          .ForContext("ReportDate", reportDate)
          .Debug("[ChargeListReportManager.SortChargesByCreatedAt] Sorting charges by created_at");
        CsvFileSortHelper.SortByColumnIndex(_bashPath, inputFilePath, ChargesSortedByCreatedAtCsvFile, separator, createdAtColumnPosition, descending: true);
    }

    public bool ParquetPathHasFiles()
    {
        return Directory.Exists(ChargesEventsRawParquetPath) && Directory.GetFiles(ChargesEventsRawParquetPath, "*.parquet").Length > 0;
    }

    public void TryDeleteParquetPath()
    {
        try { if (Directory.Exists(ChargesEventsRawParquetPath)) Directory.Delete(ChargesEventsRawParquetPath, true); } catch { }
    }

    public void TryDeleteFile(string path)
    {
        try { if (File.Exists(path)) File.Delete(path); } catch { }
    }

    public void Dispose()
    {
        TryDeleteParquetPath();
        TryDeleteFile(ChargesEventsRawCsvFile);
        TryDeleteFile(ChargesEventsSortedByIdCsvFile);
        TryDeleteFile(ChargesRawCsvFile);
        TryDeleteFile(ChargesFilteredCsvFile);
        TryDeleteFile(ChargesSortedByCreatedAtCsvFile);
        GC.SuppressFinalize(this);
    }
}

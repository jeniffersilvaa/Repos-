using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;
using PaymentsDataLayerReports.Application.Workers.ChargeReportWorker;
using PaymentsDataLayerReports.Application.Workers.Shared.Validation;

namespace PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.ChargeList.Validation;


public readonly record struct CsvValidationContext(
    CsvRow Row,
    ChargeReportsWorkerParameters Parameters
);
public sealed class ValidStatusSpecification
    : ISpecification<CsvValidationContext>
{
    public bool IsSatisfiedBy(CsvValidationContext context)
    {
        var status = context.Row.GetField<string>(
            ChargeListReportHeader.HeaderIndex, "status");

        if (string.IsNullOrEmpty(status) || (context.Parameters.WithFailed != true && status == "failed"))
            return false;

        return true;
    }
}
public sealed class ValidCreatedAtSpecification
    : ISpecification<CsvValidationContext>
{
    public bool IsSatisfiedBy(CsvValidationContext context)
    {
        var createdAtStr = context.Row.GetField<string>(ChargeListReportHeader.HeaderIndex, "created_at");

        if (DateTime.TryParse(createdAtStr, out var createdAt) && (createdAt < context.Parameters.StartDate || createdAt > context.Parameters.EndDate))
        {
            return false;
        }

        return true;
    }
}
public sealed class ValidAllIdsSpecification : ISpecification<CsvValidationContext>
{
    public bool IsSatisfiedBy(CsvValidationContext context)
    {
        if (!string.IsNullOrEmpty(context.Parameters.AllIds))
        {
            var allIds = context.Row.GetField<string>(ChargeListReportHeader.HeaderIndex, "all_ids");

            var allowedIds = context.Parameters.AllIds.Split(',').Select(id => id.Trim()).ToHashSet();

            if (!string.IsNullOrEmpty(allIds) && !allowedIds.Contains(allIds))
                return false;
        }
        return true;
    }
}
public sealed class ValidAcquirersSpecification : ISpecification<CsvValidationContext>
{

    public bool IsSatisfiedBy(CsvValidationContext context)
    {
        if (!string.IsNullOrEmpty(context.Parameters.Acquirers))
        {
            var acquirerName = context.Row.GetField<string>(ChargeListReportHeader.HeaderIndex, "card_transaction__last__acquirer_name");
            var allowedAcquirers = context.Parameters.Acquirers.Split(',').Select(acq => acq.Trim()).ToHashSet();
            if (!string.IsNullOrEmpty(acquirerName) && !allowedAcquirers.Contains(acquirerName))
                return false;
        }
        return true;
    }
}
public sealed class ValidBankNamesSpecification : ISpecification<CsvValidationContext>
{
    public bool IsSatisfiedBy(CsvValidationContext context)
    {
        if (!string.IsNullOrEmpty(context.Parameters.BankNames))
        {
            var bankName = context.Row.GetField<string>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__bank__name");
            var allowedBanks = context.Parameters.BankNames.Split(',').Select(bn => bn.Trim()).ToHashSet();

            if (!string.IsNullOrEmpty(bankName) && !allowedBanks.Contains(bankName))
                return false;
        }
        return true;
    }
}
public sealed class ValidCardBrandsSpecification : ISpecification<CsvValidationContext>
{
    public bool IsSatisfiedBy(CsvValidationContext context)
    {
        if (!string.IsNullOrEmpty(context.Parameters.CardBrands))
        {
            var cardBrand = context.Row.GetField<string>(ChargeListReportHeader.HeaderIndex, "card_transaction__card__brand");
            var allowedBrands = context.Parameters.CardBrands.Split(',').Select(cb => cb.Trim()).ToHashSet();
            if (!string.IsNullOrEmpty(cardBrand) && !allowedBrands.Contains(cardBrand))
                return false;
        }
        return true;
    }
}
public sealed class ValidFundingSourcesSpecification : ISpecification<CsvValidationContext>
{
    public bool IsSatisfiedBy(CsvValidationContext context)
    {
        if (!string.IsNullOrEmpty(context.Parameters.FundingSources))
        {
            var fundingSource = context.Row.GetField<string>(ChargeListReportHeader.HeaderIndex, "card_transaction__funding_source");
            var allowedSources = context.Parameters.FundingSources.Split(',').Select(fs => fs.Trim()).ToHashSet();
            if (!string.IsNullOrEmpty(fundingSource) && !allowedSources.Contains(fundingSource))
                return false;
        }
        return true;
    }
}
public sealed class ValidPaidAtSpecification : ISpecification<CsvValidationContext>
{
    public bool IsSatisfiedBy(CsvValidationContext context)
    {
        if (context.Parameters.PaidAt != null)
        {
            var paidAt = context.Row.GetField<DateTime>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__paid_at");
            if (paidAt != context.Parameters.PaidAt)
                return false;
        }
        return true;
    }
}
public sealed class ValidPlatformNameSpecification : ISpecification<CsvValidationContext>
{
    public bool IsSatisfiedBy(CsvValidationContext context)
    {
        if (!string.IsNullOrEmpty(context.Parameters.PlatformName))
        {
            var platformName = context.Row.GetField<string>(ChargeListReportHeader.HeaderIndex, "platform_name");
            var allowedPlatforms = context.Parameters.PlatformName.Split(',').Select(pn => pn.Trim()).ToHashSet();
            if (!string.IsNullOrEmpty(platformName) && !allowedPlatforms.Contains(platformName))
                return false;
        }
        return true;
    }
}
public sealed class ValidAntifraudStatusSpecification : ISpecification<CsvValidationContext>
{
    public bool IsSatisfiedBy(CsvValidationContext context)
    {
        if (!string.IsNullOrEmpty(context.Parameters.AntifraudStatus))
        {
            var antifraudStatus = context.Row.GetField<string>(ChargeListReportHeader.HeaderIndex, "card_transaction__last__antifraud_status");
            var allowedStatuses = context.Parameters.AntifraudStatus.Split(',').Select(af => af.Trim()).ToHashSet();
            if (!string.IsNullOrEmpty(antifraudStatus) && !allowedStatuses.Contains(antifraudStatus))
                return false;
        }
        return true;
    }
}
public sealed class ValidLastOperationStatusSpecification : ISpecification<CsvValidationContext>
{
    public bool IsSatisfiedBy(CsvValidationContext context)
    {
        if (!string.IsNullOrEmpty(context.Parameters.LastOperationStatus))
        {
            var paymentMethod = context.Row.GetField<string>(ChargeListReportHeader.HeaderIndex, "payment_method");
            var allowedStatuses = context.Parameters.LastOperationStatus.Split(',').Select(v => v.Trim()).ToHashSet();
            var operationStatus = paymentMethod switch
            {
                "card" => context.Row.GetField<string>(ChargeListReportHeader.HeaderIndex, "card_transaction__last__operation_status"),
                "boleto" => context.Row.GetField<string>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__last__operation_status"),
                "pix" => context.Row.GetField<string>(ChargeListReportHeader.HeaderIndex, "pix_transaction__last__operation_status"),
                "cash" => context.Row.GetField<string>(ChargeListReportHeader.HeaderIndex, "cash_transaction__last__operation_status"),
                _ => null
            };

            if (!string.IsNullOrEmpty(operationStatus) && !allowedStatuses.Contains(operationStatus))
                return false;
        }
        return true;
    }
}
public sealed class ValidLastOperationStatus : ISpecification<CsvValidationContext>
{
    public bool IsSatisfiedBy(CsvValidationContext context)
    {
        if (!string.IsNullOrEmpty(context.Parameters.LastLegacyStatus))
        {
            var paymentMethod = context.Row.GetField<string>(ChargeListReportHeader.HeaderIndex, "payment_method");
            var allowedStatuses = context.Parameters.LastLegacyStatus.Split(',').Select(v => v.Trim()).ToHashSet();
            var legacyStatus = paymentMethod switch
            {
                "card" => context.Row.GetField<string>(ChargeListReportHeader.HeaderIndex, "card_transaction__last__legacy_status"),
                "boleto" => context.Row.GetField<string>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__last__legacy_status"),
                "pix" => context.Row.GetField<string>(ChargeListReportHeader.HeaderIndex, "pix_transaction__last__legacy_status"),
                "cash" => context.Row.GetField<string>(ChargeListReportHeader.HeaderIndex, "cash_transaction__last__legacy_status"),
                _ => null
            };

            if (!string.IsNullOrEmpty(legacyStatus) && !allowedStatuses.Contains(legacyStatus))
                return false;
        }
        return true;
    }
}
public sealed class ValidAmountRangeSpecification : ISpecification<CsvValidationContext>
{
    public bool IsSatisfiedBy(CsvValidationContext context)
    {
        var amount = context.Row.GetField<int?>(ChargeListReportHeader.HeaderIndex, "amount") ?? 0;
        if (context.Parameters.MinAmount != null && amount < context.Parameters.MinAmount)
            return false;
        if (context.Parameters.MaxAmount != null && amount > context.Parameters.MaxAmount)
            return false;

        return true;
    }
}
public sealed class ValidCustomersSpecification : ISpecification<CsvValidationContext>
{
    public bool IsSatisfiedBy(CsvValidationContext context)
    {
        if (!string.IsNullOrEmpty(context.Parameters.Customers))
        {
            var paymentMethod = context.Row.GetField<string>(ChargeListReportHeader.HeaderIndex, "payment_method");
            var allowedCustomers = context.Parameters.Customers.Split(',').Select(v => v.Trim()).ToHashSet();

            var prefix = paymentMethod switch
            {
                "card" => "card_transaction__customer__",
                "boleto" => "boleto_transaction__customer__",
                "pix" => "pix_transaction__customer__",
                "cash" => "cash_transaction__customer__",
                _ => null
            };

            if (prefix != null)
            {
                var customerName = context.Row.GetField<string>(ChargeListReportHeader.HeaderIndex, prefix + "name");
                var customerId = context.Row.GetField<string>(ChargeListReportHeader.HeaderIndex, prefix + "customer_id");
                var customerDocument = context.Row.GetField<string>(ChargeListReportHeader.HeaderIndex, prefix + "document");
                var customerEmail = context.Row.GetField<string>(ChargeListReportHeader.HeaderIndex, prefix + "email");

                var hasMatch = (!string.IsNullOrEmpty(customerName) && allowedCustomers.Contains(customerName)) ||
                               (!string.IsNullOrEmpty(customerId) && allowedCustomers.Contains(customerId)) ||
                               (!string.IsNullOrEmpty(customerDocument) && allowedCustomers.Contains(customerDocument)) ||
                               (!string.IsNullOrEmpty(customerEmail) && allowedCustomers.Contains(customerEmail));

                if (!hasMatch) return false;
            }
        }
        return true;
    }
}


public static class ValidateSaleReportCSVField
{
    private static readonly ISpecification<CsvValidationContext> _validator =
     new AggregateSpecification<CsvValidationContext>(
        new ValidStatusSpecification(),
        new ValidCreatedAtSpecification(),
        new ValidAllIdsSpecification(),
        new ValidAcquirersSpecification(),
        new ValidBankNamesSpecification(),
        new ValidCardBrandsSpecification(),
        new ValidFundingSourcesSpecification(),
        new ValidPaidAtSpecification(),
        new ValidPlatformNameSpecification(),
        new ValidAntifraudStatusSpecification(),
        new ValidLastOperationStatusSpecification(),
        new ValidLastOperationStatus(),
        new ValidAmountRangeSpecification(),
        new ValidCustomersSpecification()
     );

    public static bool IsValidRow(
        CsvRow row,
        ChargeReportsWorkerParameters parameters)
    {
        return _validator.IsSatisfiedBy(new CsvValidationContext(row, parameters));
    }

}
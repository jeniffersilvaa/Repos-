using PaymentsDataLayerReports.Application.Services.DeltaTableColumnMapping;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.Models;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;
using Serilog;

namespace PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.ChargesEvents;

public static class ChargeEventsReportQuery
{
    private const string _iso8601FormatMicroSecWithTZ = "strftime(CAST({column} AS TIMESTAMP), '%Y-%m-%dT%H:%M:%S.%f+00:00')";
    private const string _iso8601FormatMiliSecWithoutTZ = "strftime(CAST({column} AS TIMESTAMP), '%Y-%m-%dT%H:%M:%S.%g')";
    private const string _timestampMicroSecWithTz = "strftime(CAST({column} AS TIMESTAMP), '%Y-%m-%d %H:%M:%S.%g UTC')";
    private const string _pixCanceledAmountCondition = "CASE WHEN payment_method = 'pix' AND pix_transaction__detail__operation = 'cancel' THEN pix_transaction__detail__operation_amount ELSE {column} END";
    private const string _pixAdditionalDataCustomFormat = "'[' || array_to_string(list_transform(CAST({column} AS STRUCT(name VARCHAR, value VARCHAR)[]), item -> '{name=' || item.name || ', value=' || item.value || '}' ), ', ') || ']'";

    private static readonly List<DeltaTableColumnModel> RequestedColumns = [
        new("event_datetime", _timestampMicroSecWithTz),
        new("event_id"),
        new("id"),
        new("initiator_id"),
        new("product"),
        new("origin"),
        new("origin_id"),
        new("amount"),
        new("attempt_count"),
        new("all_ids"),
        new("code"),
        new("status"),
        new("payment_method"),
        new("gateway"),
        new("gateway_order_id"),
        new("platform_name"),
        new("split"),
        new("created_at", _iso8601FormatMicroSecWithTZ),
        new("metadata"),
        new("merchant__organization"),
        new("merchant__user_id"),
        new("merchant__document"),
        new("merchant__affiliation_key"),
        new("merchant__affiliation_code"),
        new("merchant__account_id"),
        new("merchant__merchant_id"),
        new("merchant__is_sandbox", null, false),
        new("card_transaction__type"),
        new("card_transaction__funding_source"),
        new("card_transaction__transaction_id"),
        new("card_transaction__authorized_state"),
        new("card_transaction__authorization_code"),
        new("card_transaction__installments"),
        new("card_transaction__installments_type"),
        new("card_transaction__scheme_business_model"),
        new("card_transaction__last__acquirer_name"),
        new("card_transaction__last__acquirer_return_code"),
        new("card_transaction__last__antifraud_status"),
        new("card_transaction__last__operation_status"),
        new("card_transaction__card__brand"),
        new("card_transaction__card__brand_id"),
        new("card_transaction__card__first_six_digits"),
        new("card_transaction__card__last_four_digits"),
        new("card_transaction__card__entry_mode"),
        new("card_transaction__card__holder_name"),
        new("card_transaction__card__exp_month"),
        new("card_transaction__card__exp_year"),
        new("card_transaction__card__country_code"),
        new("card_transaction__card__currency_code"),
        new("card_transaction__card__number_token"),
        new("card_transaction__card__label"),
        new("card_transaction__customer__name"),
        new("card_transaction__customer__customer_id"),
        new("card_transaction__customer__document_type"),
        new("card_transaction__customer__document"),
        new("card_transaction__customer__email"),
        new("card_transaction__customer__address__country"),
        new("card_transaction__customer__address__city"),
        new("card_transaction__customer__address__street"),
        new("card_transaction__customer__address__extra"),
        new("card_transaction__customer__address__street_number"),
        new("card_transaction__customer__address__neighborhood"),
        new("card_transaction__customer__address__state"),
        new("card_transaction__customer__address__postal_code"),
        new("card_transaction__terminal__type"),
        new("card_transaction__terminal__serial_number"),
        new("card_transaction__detail__legacy__status"),
        new("card_transaction__detail__legacy__transaction_status"),
        new("card_transaction__detail__legacy__operation"),
        new("card_transaction__detail__legacy__canceled_amount"),
        new("card_transaction__detail__legacy__account_name"),
        new("card_transaction__detail__acquirer__name"),
        new("card_transaction__detail__acquirer__nsu"),
        new("card_transaction__detail__acquirer__tid"),
        new("card_transaction__detail__gateway_response__code"),
        new("card_transaction__detail__gateway_response__message"),
        new("card_transaction__detail__antifraud_response__provider_name"),
        new("card_transaction__detail__antifraud_response__score"),
        new("card_transaction__detail__antifraud_response__status"),
        new("card_transaction__detail__pgid"),
        new("card_transaction__detail__operation"),
        new("card_transaction__detail__operation_status"),
        new("card_transaction__detail__operation_id"),
        new("card_transaction__detail__local_datetime", _iso8601FormatMiliSecWithoutTZ),
        new("card_transaction__detail__provider_datetime", _iso8601FormatMiliSecWithoutTZ),
        new("card_transaction__detail__operation_amount"),
        new("card_transaction__detail__acquirer_message"),
        new("card_transaction__detail__acquirer_return_code"),
        new("card_transaction__detail__operation_reason"),
        new("card_transaction__detail__financial_event__id"),
        new("card_transaction__detail__financial_event__amount"),
        new("card_transaction__detail__financial_event__installment"),
        new("card_transaction__fee__id"),
        new("card_transaction__fee__full_amount"),
        new("card_transaction__fee__type"),
        new("card_transaction__financial_movement__operation_id"),
        new("card_transaction__financial_movement__current_due_date"),
        new("card_transaction__financial_movement__category"),
        new("card_transaction__financial_movement__installment_number"),
        new("card_transaction__financial_movement__amount__discount_rate__fee_type"),
        new("card_transaction__financial_movement__amount__discount_rate__fee"),
        new("card_transaction__financial_movement__amount__discount_rate__effective_fee"),
        new("card_transaction__financial_movement__amount__discount_rate__amount"),
        new("card_transaction__financial_movement__amount__prepayment_fee__fee_type"),
        new("card_transaction__financial_movement__amount__prepayment_fee__fee"),
        new("card_transaction__financial_movement__amount__prepayment_fee__effective_fee"),
        new("card_transaction__financial_movement__amount__prepayment_fee__amount"),
        new("boleto_transaction__type"),
        new("boleto_transaction__transaction_id"),
        new("boleto_transaction__our_number"),
        new("boleto_transaction__fine_amount"),
        new("boleto_transaction__interest_amount"),
        new("boleto_transaction__discount_amount"),
        new("boleto_transaction__fee_amount"),
        new("boleto_transaction__expire_at"),
        new("boleto_transaction__limit_date"),
        new("boleto_transaction__barcode"),
        new("boleto_transaction__writable_line"),
        new("boleto_transaction__instructions"),
        new("boleto_transaction__url"),
        new("boleto_transaction__paid_at"),
        new("boleto_transaction__last__operation_status"),
        new("boleto_transaction__last__antifraud_status"),
        new("boleto_transaction__last__acquirer_name"),
        new("boleto_transaction__last__acquirer_return_code"),
        new("boleto_transaction__bank__code"),
        new("boleto_transaction__bank__name"),
        new("boleto_transaction__receiver__name"),
        new("boleto_transaction__receiver__document_type"),
        new("boleto_transaction__receiver__document"),
        new("boleto_transaction__customer__name"),
        new("boleto_transaction__customer__customer_id"),
        new("boleto_transaction__customer__document_type"),
        new("boleto_transaction__customer__document"),
        new("boleto_transaction__customer__email"),
        new("boleto_transaction__customer__address__street"),
        new("boleto_transaction__customer__address__street_number"),
        new("boleto_transaction__customer__address__extra"),
        new("boleto_transaction__customer__address__neighborhood"),
        new("boleto_transaction__customer__address__postal_code"),
        new("boleto_transaction__customer__address__city"),
        new("boleto_transaction__customer__address__state"),
        new("boleto_transaction__customer__address__country"),
        new("boleto_transaction__fine__start_at"),
        new("boleto_transaction__fine__type"),
        new("boleto_transaction__fine__value"),
        new("boleto_transaction__interest__start_at"),
        new("boleto_transaction__interest__type"),
        new("boleto_transaction__interest__value"),
        new("boleto_transaction__discounts"),
        new("boleto_transaction__detail__legacy__status"),
        new("boleto_transaction__detail__legacy__transaction_status"),
        new("boleto_transaction__detail__legacy__operation"),
        new("boleto_transaction__detail__legacy__canceled_amount"),
        new("boleto_transaction__detail__legacy__account_name"),
        new("boleto_transaction__detail__pgid"),
        new("boleto_transaction__detail__operation"),
        new("boleto_transaction__detail__operation_status"),
        new("boleto_transaction__detail__operation_id"),
        new("boleto_transaction__detail__local_datetime", _iso8601FormatMiliSecWithoutTZ),
        new("boleto_transaction__detail__provider_datetime", _iso8601FormatMiliSecWithoutTZ),
        new("boleto_transaction__detail__operation_amount"),
        new("boleto_transaction__detail__reason"),
        new("boleto_transaction__detail__gateway_response__code"),
        new("boleto_transaction__detail__gateway_response__message"),
        new("pix_transaction__type"),
        new("pix_transaction__transaction_id"),
        new("pix_transaction__e2e_id"),
        new("pix_transaction__pix_key"),
        new("pix_transaction__is_pix_sale_key"),
        new("pix_transaction__pix_key_nickname"),
        new("pix_transaction__paid_amount"),
        new("pix_transaction__fine_amount"),
        new("pix_transaction__interest_amount"),
        new("pix_transaction__discount_amount"),
        new("pix_transaction__reduction_amount"),
        new("pix_transaction__canceled_amount", _pixCanceledAmountCondition),
        new("pix_transaction__fee_amount"),
        new("pix_transaction__expire_at"),
        new("pix_transaction__payment_limit_period_days"),
        new("pix_transaction__business_days_only"),
        new("pix_transaction__expires_in"),
        new("pix_transaction__request_for_payer"),
        new("pix_transaction__last__operation_status"),
        new("pix_transaction__fine__start_at"),
        new("pix_transaction__fine__type"),
        new("pix_transaction__fine__value"),
        new("pix_transaction__interest__start_at"),
        new("pix_transaction__interest__type"),
        new("pix_transaction__interest__value"),
        new("pix_transaction__interest__period"),
        new("pix_transaction__discounts"),
        new("pix_transaction__reduction__start_at"),
        new("pix_transaction__reduction__value"),
        new("pix_transaction__customer__name"),
        new("pix_transaction__customer__customer_id"),
        new("pix_transaction__customer__document_type"),
        new("pix_transaction__customer__document"),
        new("pix_transaction__customer__email"),
        new("pix_transaction__customer__address__country"),
        new("pix_transaction__customer__address__city"),
        new("pix_transaction__customer__address__street"),
        new("pix_transaction__customer__address__extra"),
        new("pix_transaction__customer__address__street_number"),
        new("pix_transaction__customer__address__neighborhood"),
        new("pix_transaction__customer__address__state"),
        new("pix_transaction__customer__address__postal_code"),
        new("pix_transaction__payer__name"),
        new("pix_transaction__payer__document_type"),
        new("pix_transaction__payer__document"),
        new("pix_transaction__payer__ispb"),
        new("pix_transaction__payer__institution_name"),
        new("pix_transaction__additional_data", _pixAdditionalDataCustomFormat),
        new("pix_transaction__terminal__id"),
        new("pix_transaction__terminal__type"),
        new("pix_transaction__terminal__serial_number"),
        new("pix_transaction__detail__legacy__status"),
        new("pix_transaction__detail__legacy__transaction_status"),
        new("pix_transaction__detail__legacy__operation"),
        new("pix_transaction__detail__legacy__canceled_amount"),
        new("pix_transaction__detail__legacy__account_name"),
        new("pix_transaction__detail__pgid"),
        new("pix_transaction__detail__operation"),
        new("pix_transaction__detail__operation_status"),
        new("pix_transaction__detail__operation_id"),
        new("pix_transaction__detail__local_datetime", _iso8601FormatMiliSecWithoutTZ),
        new("pix_transaction__detail__provider_datetime", _iso8601FormatMiliSecWithoutTZ),
        new("pix_transaction__detail__operation_amount"),
        new("pix_transaction__detail__qrcode_content"),
        new("pix_transaction__detail__description"),
        new("pix_transaction__detail__refund_id"),
        new("pix_transaction__detail__reason"),
        new("cash_transaction__description"),
        new("cash_transaction__transaction_id"),
        new("cash_transaction__paid_amount"),
        new("cash_transaction__canceled_amount"),
        new("cash_transaction__customer__name"),
        new("cash_transaction__customer__customer_id"),
        new("cash_transaction__customer__document_type"),
        new("cash_transaction__customer__document"),
        new("cash_transaction__customer__email"),
        new("cash_transaction__customer__address__country"),
        new("cash_transaction__customer__address__city"),
        new("cash_transaction__customer__address__street"),
        new("cash_transaction__customer__address__extra"),
        new("cash_transaction__customer__address__street_number"),
        new("cash_transaction__customer__address__neighborhood"),
        new("cash_transaction__customer__address__state"),
        new("cash_transaction__customer__address__postal_code"),
        new("cash_transaction__last__operation_status"),
        new("cash_transaction__detail__legacy__status"),
        new("cash_transaction__detail__legacy__transaction_status"),
        new("cash_transaction__detail__legacy__operation"),
        new("cash_transaction__detail__legacy__canceled_amount"),
        new("cash_transaction__detail__legacy__account_name"),
        new("cash_transaction__detail__operation"),
        new("cash_transaction__detail__operation_status"),
        new("cash_transaction__detail__operation_id"),
        new("cash_transaction__detail__local_datetime", _iso8601FormatMiliSecWithoutTZ),
        new("cash_transaction__detail__provider_datetime", _iso8601FormatMiliSecWithoutTZ),
        new("cash_transaction__detail__operation_amount"),
        new("cash_transaction__detail__reason"),
        new("cash_transaction__detail__operation_reason"),
        new("processed_at", null, false)
    ];

    public static int ProcessedAtColumnPosition => RequestedColumns.Count;
    public static int ColumnCountWithoutProcessedAt => RequestedColumns.Count - 1;

    private static List<string> GetTablesForChargesEvents()
    {
        return ["charges_events_by_created_at", "charges_posterior_events_by_event_date"];
    }

    public static async Task<string> SelectChargesEventsAsync(
        string inputPath,
        string outputPath,
        GenerateReportInput reportInput,
        bool hasRealTimeData,
        bool hasParquetData,
        IColumnMappingService columnMappingService,
        List<string> allowedFinancialMovementCategories
    )
    {
        var tables = GetTablesForChargesEvents();
        var tableQueries = new List<string>();

        var parquetQuery = string.Empty;
        if (hasParquetData)
        {
            foreach (var tableName in tables)
            {
                var tableInputPath = Path.Combine(inputPath, tableName);

                if (!Directory.Exists(tableInputPath) || Directory.GetFiles(tableInputPath, "*.parquet").Length == 0)
                {
                    Log.Debug($"[ChargeEventsReportQuery] No parquet files found in {tableInputPath}, skipping table {tableName}");
                    continue;
                }

                var columnMapping = await columnMappingService.GetColumnMappingAsync(tableName);

                var whereClauses = ReportQueryFilters.BuildBaseFilters(reportInput, allowedFinancialMovementCategories, columnMapping);
                var where = whereClauses.Count > 0 ? $"WHERE {string.Join("\nAND ", whereClauses)}" : string.Empty;

                var nullClauses = await columnMappingService.GenerateNullClausesAsync(tableName, RequestedColumns);
                var nullClausesStr = string.Join(",\n                        ", nullClauses);

                var sqlColumns = await columnMappingService.GenerateSqlColumnsAsync(tableName, RequestedColumns);
                var sqlColumnsStr = string.Join(",\n        ", sqlColumns);

                var tableQuery = $@"
                    SELECT
                        {sqlColumnsStr}
                    FROM (
                        SELECT 
                            *,
                            {nullClausesStr}
                        FROM read_parquet(['{tableInputPath}/*.parquet'], union_by_name=True)
                    ) AS base
                    {where}";

                tableQueries.Add(tableQuery);
            }

            if (tableQueries.Count > 0)
            {
                parquetQuery = string.Join("\n\n                UNION ALL\n\n", tableQueries);
            }
        }

        var whereClausesRealTime = ReportQueryFilters.BuildBaseFilters(reportInput, allowedFinancialMovementCategories, null, true);
        var whereRealTime = whereClausesRealTime.Count > 0 ? $"WHERE {string.Join("\nAND ", whereClausesRealTime)}" : string.Empty;

        var realTimeQuery = string.Empty;
        if (hasRealTimeData)
        {
            var sqlColumns = RequestedColumns.Select(c => c.ToSqlColumn(new Dictionary<string, string>(), isRealTime: true));
            realTimeQuery = $@"
                SELECT {string.Join(",\n        ", sqlColumns)}
                FROM read_csv(['{inputPath}/*.csv'], union_by_name=True, all_varchar=True)
                {whereRealTime}";
        }

        string query;
        if (hasRealTimeData && hasParquetData)
        {
            query = $@"
                {parquetQuery}
                UNION ALL
                {realTimeQuery}";
        }
        else
        {
            query = hasParquetData ? parquetQuery : realTimeQuery;
        }

        var finalQuery = $"COPY ({query}) TO '{outputPath}' (HEADER, DELIMITER ',');";

        return finalQuery;
    }

}
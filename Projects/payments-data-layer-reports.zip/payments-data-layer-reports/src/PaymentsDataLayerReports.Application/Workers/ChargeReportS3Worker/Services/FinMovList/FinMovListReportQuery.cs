using PaymentsDataLayerReports.Application.Services.DeltaTableColumnMapping;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;

using Serilog;

namespace PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.FinMovList;

public static class FinMovListReportQuery
{
    private static readonly List<DeltaTableColumnModel> RequestedColumns = new()
    {
        new("id"),
        new("operation_id"),
        new("original_due_date"),
        new("current_due_date"),
        new("event_timestamp"),
        new("created_at"),
        new("updated_at"),
        new("merchant__organization"),
        new("merchant__user_id"),
        new("merchant__document"),
        new("merchant__affiliation_key"),
        new("merchant__affiliation_code"),
        new("merchant__company_id"),
        new("merchant__recipient_id"),
        new("movement__category"),
        new("movement__event_id"),
        new("movement__fee"),
        new("movement__effective_fee"),
        new("movement__fee_type"),
        new("movement__creation_date"),
        new("movement__amount"),
        new("payment_owner__organization"),
        new("payment_owner__user_id"),
        new("payment_owner__document"),
        new("payment_owner__affiliation_key"),
        new("payment_owner__affiliation_code"),
        new("payment_owner__payment_profile_id"),
        new("payment_owner__company_id"),
        new("payment_owner__recipient_id"),
        new("transaction__key"),
        new("transaction__operation_key"),
        new("transaction__capture_date"),
        new("transaction__brand"),
        new("transaction__product"),
        new("transaction__authorization_date"),
        new("transaction__account_funding_source"),
        new("transaction__installment_number"),
        new("transaction__installment_quantity"),
        new("transaction__gateway_id"),
        new("transaction__point_of_interaction_type"),
        new("settlement__status"),
        new("settlement__key"),
        new("settlement__balance_due_date"),
        new("settlement__payment_date"),
        new("settlement__wallet__nature"),
        new("settlement__wallet__type_id"),
        new("settlement__wallet__description"),
        new("settlement__payment__payment_date"),
        new("settlement__payment__status"),
        new("settlement__payment__account__account_number"),
        new("settlement__payment__account__account_check_digit"),
        new("settlement__payment__account__account_type"),
        new("settlement__payment__account__bank_code"),
        new("settlement__payment__account__branch_number"),
        new("settlement__payment__account__branch_check_digit"),
        new("settlement__payment__account__ispb"),
        new("legacy__bulk_anticipation_id"),
        new("legacy__anticipation_id"),
        new("legacy__originator_model_id"),
        new("legacy__originator_model"),
        new("legacy__liquidation_arrangement_id")
    };

    private static List<string> GetTablesForFinMovList()
    {
        return new List<string> { "finmov_settled_by_due_date" };
    }

    private static List<string> BuildBaseFilters(ReportMetadata reportMetadata, ColumnMapping? columnMapping = null, bool isRealTime = false)
    {
        var whereClauses = new List<string>
        {
            $"current_due_date::DATE >= '{reportMetadata.FinMovReportParameters?.StartDate:o}'::DATE",
            $"current_due_date::DATE <= '{reportMetadata.FinMovReportParameters?.EndDate:o}'::DATE"
        };

        if (!string.IsNullOrEmpty(reportMetadata.FinMovReportParameters?.Document))
        {
            var documentColumn = ColumnMappingService.GetColumnNameForFilter("payment_owner__document", columnMapping);
            whereClauses.Add($"{documentColumn} IN ({string.Join(",", reportMetadata.FinMovReportParameters.Document.Split(',').Select(doc => "'" + doc.Trim() + "'"))})");
        }

        if (!string.IsNullOrEmpty(reportMetadata.FinMovReportParameters?.AccountId))
        {
            var accountColumn = ColumnMappingService.GetColumnNameForFilter("payment_owner__account_id", columnMapping);
            whereClauses.Add($"{accountColumn} IN ({string.Join(",", reportMetadata.FinMovReportParameters.AccountId.Split(',').Select(af => "'" + af.Trim() + "'"))})");
        }

        if (!string.IsNullOrEmpty(reportMetadata.FinMovReportParameters?.MerchantId))
        {
            var merchantColumn = ColumnMappingService.GetColumnNameForFilter("payment_owner__merchant_id", columnMapping);
            whereClauses.Add($"{merchantColumn} IN ({string.Join(",", reportMetadata.FinMovReportParameters!.MerchantId.Split(',').Select(id => "'" + id.Trim() + "'"))})");
        }

        if (reportMetadata.FinMovReportParameters?.IsSandbox.HasValue == true && !isRealTime)
        {
            var sandboxColumn = ColumnMappingService.GetColumnNameForFilter("payment_owner__is_sandbox", columnMapping);
            whereClauses.Add($"{sandboxColumn} = {reportMetadata.FinMovReportParameters?.IsSandbox.Value.ToString().ToLower()}");
        }

        if (!string.IsNullOrEmpty(reportMetadata.FinMovReportParameters?.AffiliationCodes))
        {
            var affiliationColumn = ColumnMappingService.GetColumnNameForFilter("payment_owner__affiliation_code", columnMapping);
            whereClauses.Add($"{affiliationColumn} IN ({string.Join(",", reportMetadata.FinMovReportParameters.AffiliationCodes.Split(',').Select(code => "'" + code.Trim() + "'"))})");
        }

        if (!string.IsNullOrEmpty(reportMetadata.FinMovReportParameters?.Organizations))
        {
            var organizationColumn = ColumnMappingService.GetColumnNameForFilter("payment_owner__organization", columnMapping);
            whereClauses.Add($"{organizationColumn} IN ({string.Join(",", reportMetadata.FinMovReportParameters.Organizations.Split(',').Select(org => "'" + org.Trim() + "'"))})");
        }

        if (!string.IsNullOrEmpty(reportMetadata.FinMovReportParameters?.PaymentProfiles))
        {
            var paymentProfileColumn = ColumnMappingService.GetColumnNameForFilter("payment_owner__payment_profile_id", columnMapping);
            whereClauses.Add($"{paymentProfileColumn} IN ({string.Join(",", reportMetadata.FinMovReportParameters.PaymentProfiles.Split(',').Select(profile => "'" + profile.Trim() + "'"))})");
        }

        if (!string.IsNullOrEmpty(reportMetadata.FinMovReportParameters?.PoiTypes))
        {
            var poiTypeColumn = ColumnMappingService.GetColumnNameForFilter("transaction__point_of_interaction_type", columnMapping);
            whereClauses.Add($"{poiTypeColumn} IN ({string.Join(",", reportMetadata.FinMovReportParameters.PoiTypes.Split(',').Select(poiType => "'" + poiType.Trim() + "'"))})");
        }

        return whereClauses;
    }

    private static List<string> BuildFinalFilters(ReportMetadata reportMetadata)
    {
        var whereClauses = new List<string>
        {
            $"current_due_date::DATE >= '{reportMetadata.FinMovReportParameters?.StartDate:o}'::DATE",
            $"current_due_date::DATE <= '{reportMetadata.FinMovReportParameters?.EndDate:o}'::DATE"
        };

        return whereClauses;
    }

    public static async Task<string> SelectFinMovListAsync(
        string inputPath,
        string outputPath,
        ReportMetadata reportMetadata,
        bool hasRealTimeData,
        bool hasParquetData,
        IColumnMappingService columnMappingService
    )
    {
        var tables = GetTablesForFinMovList();
        var tableQueries = new List<string>();

        var parquetQuery = string.Empty;
        if (hasParquetData)
        {
            foreach (var tableName in tables)
            {
                var tableInputPath = Path.Combine(inputPath, tableName);

                if (!Directory.Exists(tableInputPath) || Directory.GetFiles(tableInputPath, "*.parquet").Length == 0)
                {
                    Log.Debug($"[FinMovListReportQuery.SelectFinMovListAsync] No parquet files found in {tableInputPath}, skipping table {tableName}");
                    continue;
                }

                var columnMapping = await columnMappingService.GetColumnMappingAsync(tableName);
                var whereClauses = BuildBaseFilters(reportMetadata, columnMapping);
                var where = whereClauses.Count > 0 ? $"WHERE {string.Join("\nAND ", whereClauses)}" : string.Empty;

                var nullClauses = await columnMappingService.GenerateNullClausesAsync(tableName, RequestedColumns);
                var nullClausesStr = string.Join(",\n                        ", nullClauses);

                var sqlColumns = await columnMappingService.GenerateSqlColumnsAsync(tableName, RequestedColumns);
                var sqlColumnsStr = string.Join(",\n        ", sqlColumns);

                var tableQuery = $@"
                    SELECT
                        {sqlColumnsStr}
                    FROM (
                        SELECT 
                            *,
                            {nullClausesStr}
                        FROM read_parquet(['{tableInputPath}/*.parquet'], union_by_name=True)
                    ) AS base
                    {where}";

                tableQueries.Add(tableQuery);
            }

            if (tableQueries.Count > 0)
            {
                parquetQuery = string.Join("\n\n                UNION ALL\n\n", tableQueries);
            }
        }

        var whereClausesRealTime = BuildBaseFilters(reportMetadata, null, true);
        var whereRealTime = whereClausesRealTime.Count > 0 ? $"WHERE {string.Join("\nAND ", whereClausesRealTime)}" : string.Empty;

        var realTimeQuery = string.Empty;
        if (hasRealTimeData)
        {
            var sqlColumns = RequestedColumns.Select(c => c.ToSqlColumn(new Dictionary<string, string>(), isRealTime: true));
            realTimeQuery = $@"
                SELECT {string.Join(",\n        ", sqlColumns)}
                FROM read_csv(['{inputPath}/*.csv'], union_by_name=True, all_varchar=True)
                {whereRealTime}";
        }

        string query;
        if (hasRealTimeData && hasParquetData)
        {
            query = $@"
                {parquetQuery}
                UNION ALL
                {realTimeQuery}";
        }
        else
        {
            query = hasParquetData ? parquetQuery : realTimeQuery;
        }

        var finalQuery = $"COPY ({query}) TO '{outputPath}' (HEADER, DELIMITER ',');";
        return finalQuery;
    }

    public static string FilterGroupedEvents(string inputPath, string outputPath, ReportMetadata reportMetadata)
    {
        var whereClauses = BuildFinalFilters(reportMetadata);

        var where = whereClauses.Count > 0 ? $"WHERE {string.Join("\nAND ", whereClauses)}" : string.Empty;

        var query = $@"
            SELECT *
            FROM read_csv(['{inputPath}'], union_by_name=True, all_varchar=true)
            {where}
        ";

        return $"COPY ({query}) TO '{outputPath}' (HEADER false, DELIMITER ',');";
    }
}

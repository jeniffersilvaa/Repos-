using System.Diagnostics;
using Datadog.Trace;
using PaymentsDataLayerReports.Application.Services.ReportTypeConfiguration;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;
using Serilog;

namespace PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.FinMovList;

public class FinMovListReportManager : IDisposable
{
    internal string FinMovListRawParquetPath { get; }
    internal string FinMovEventsListRawCsvFile { get; }
    internal string FinMovListSortedByEventIdAndDueDateDescCsvFile { get; }
    internal string FinMovListRawCsvFile { get; }
    internal string FinMovListFilteredCsvFile { get; }
    internal string FinMovSortedByDueDateCsvFile { get; }
    public FinMovListReportManager()
    {
        FinMovListRawParquetPath = Path.Combine(Path.GetTempPath(), Path.GetRandomFileName());
        Directory.CreateDirectory(FinMovListRawParquetPath);
        FinMovEventsListRawCsvFile = Path.GetTempFileName();
        FinMovListRawCsvFile = Path.GetTempFileName();
        FinMovListSortedByEventIdAndDueDateDescCsvFile = Path.GetTempFileName();
        FinMovListFilteredCsvFile = Path.GetTempFileName();
        FinMovSortedByDueDateCsvFile = Path.GetTempFileName();
    }

    internal void SortFinMovEventsByIdAndDueDateDesc(string jobId, string reportId, DateTime reportDate)
    {
        using var scope = Tracer.Instance.StartActive("FinMovListReportManager.SortFinMovEventsByIdAndDueDateDesc");

        Log.ForContext("JobId", jobId)
          .ForContext("ReportId", reportId)
          .ForContext("ReportDate", reportDate)
          .ForContext("FinMovEventsListRawCsvFile", FinMovEventsListRawCsvFile)
          .ForContext("FinMovListSortedByEventIdAndDueDateDescCsvFile", FinMovListSortedByEventIdAndDueDateDescCsvFile)
          .Debug("[FinMovListReportManager.SortFinMovEventsByIdAndDueDateDesc] Sorting events by id");
        var skipHeaderCommand = $"tail -n +2 {FinMovEventsListRawCsvFile}";
        var sortByIdAndDocumentAndDueDate = $"sort -t, -k1,1r -k7,7 -k4,4 --buffer-size=50M";
        var dedupByMovementIdCommand = $@"awk -F, '$16 != last {{print; last = $16}}'";

        using var sortFinMovEventsByIdAndDueDateDescProcess = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = "/bin/bash",
                Arguments = $"-c \"{skipHeaderCommand} | {sortByIdAndDocumentAndDueDate} | {dedupByMovementIdCommand} > '{FinMovListSortedByEventIdAndDueDateDescCsvFile}'\"",
                RedirectStandardOutput = false,
                UseShellExecute = false
            }
        };
        sortFinMovEventsByIdAndDueDateDescProcess.Start();
        sortFinMovEventsByIdAndDueDateDescProcess.WaitForExit();
        if (sortFinMovEventsByIdAndDueDateDescProcess.ExitCode != 0)
            throw new Exception($"sortFinMovEventsByIdAndDueDateDescProcess failed with exit code {sortFinMovEventsByIdAndDueDateDescProcess.ExitCode}");
    }

    internal void SortFinMovByDueDate(string jobId, string reportId, DateTime reportDate, char separator, SortColumn[] sortColumns)
    {
        using var scope = Tracer.Instance.StartActive("FinMovListReportManager.SortFinMovByDueDate");
        Log.ForContext("JobId", jobId)
          .ForContext("ReportId", reportId)
          .ForContext("ReportDate", reportDate)
          .Debug("[FinMovListReportManager.SortFinMovByDueDate] Sorting fin_movs by due date");
        CsvFileSortHelper.SortByColumns("/bin/bash", FinMovListRawCsvFile, FinMovSortedByDueDateCsvFile, separator, sortColumns);
    }

    internal bool ParquetPathHasFiles()
    {
        return Directory.Exists(FinMovListRawParquetPath) && Directory.GetFiles(FinMovListRawParquetPath, "*.parquet").Length > 0;
    }

    internal void TryDeleteParquetPath()
    {
        try { if (Directory.Exists(FinMovListRawParquetPath)) Directory.Delete(FinMovListRawParquetPath, true); } catch { }
    }

    internal void TryDeleteFile(string path)
    {
        try { if (File.Exists(path)) File.Delete(path); } catch { }
    }

    public void Dispose()
    {
        TryDeleteParquetPath();
        TryDeleteFile(FinMovEventsListRawCsvFile);
        TryDeleteFile(FinMovListSortedByEventIdAndDueDateDescCsvFile);
        TryDeleteFile(FinMovListRawCsvFile);
        TryDeleteFile(FinMovListFilteredCsvFile);
        TryDeleteFile(FinMovSortedByDueDateCsvFile);
        GC.SuppressFinalize(this);
    }
}

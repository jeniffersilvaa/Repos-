using PaymentsDataLayerReports.Application.Services.DeltaTableColumnMapping;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.Models;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;
using PaymentsDataLayerReports.Application.Workers.ChargeReportWorker;
using Serilog;

namespace PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.ChargeList;

public static class ChargeListReportQuery
{
    private static readonly List<DeltaTableColumnModel> RequestedColumns = [
        new("event_id"),
        new("event_datetime"),
        new("id"),
        new("initiator_id"),
        new("product"),
        new("origin"),
        new("origin_id"),
        new("amount"),
        new("attempt_count"),
        new("all_ids"),
        new("code"),
        new("status"),
        new("payment_method"),
        new("gateway"),
        new("gateway_order_id"),
        new("platform_name"),
        new("split"),
        new("created_at"),
        new("metadata"),
        new("merchant__organization"),
        new("merchant__user_id"),
        new("merchant__document"),
        new("merchant__affiliation_key"),
        new("merchant__affiliation_code"),
        new("merchant__account_id"),
        new("merchant__merchant_id"),
        new("merchant__is_sandbox", null, false),
        new("merchant__stone_account"),
        new("merchant__payment_profile_id"),
        new("point_of_interaction_type"),
        new("charge_id"),
        new("card_transaction__type"),
        new("card_transaction__funding_source"),
        new("card_transaction__transaction_id"),
        new("card_transaction__authorized_state"),
        new("card_transaction__authorization_code"),
        new("card_transaction__installments"),
        new("card_transaction__installments_type"),
        new("card_transaction__scheme_business_model"),
        new("card_transaction__last__acquirer_name"),
        new("card_transaction__last__acquirer_return_code"),
        new("card_transaction__last__antifraud_status"),
        new("card_transaction__last__operation_status"),
        new("card_transaction__last__legacy_status"),
        new("card_transaction__card__brand"),
        new("card_transaction__card__brand_id"),
        new("card_transaction__card__first_six_digits"),
        new("card_transaction__card__last_four_digits"),
        new("card_transaction__card__entry_mode"),
        new("card_transaction__card__holder_name"),
        new("card_transaction__card__exp_month"),
        new("card_transaction__card__exp_year"),
        new("card_transaction__card__country_code"),
        new("card_transaction__card__currency_code"),
        new("card_transaction__card__number_token"),
        new("card_transaction__card__label"),
        new("card_transaction__customer__name"),
        new("card_transaction__customer__customer_id"),
        new("card_transaction__customer__document_type"),
        new("card_transaction__customer__document"),
        new("card_transaction__customer__email"),
        new("card_transaction__customer__address__country"),
        new("card_transaction__customer__address__city"),
        new("card_transaction__customer__address__street"),
        new("card_transaction__customer__address__extra"),
        new("card_transaction__customer__address__street_number"),
        new("card_transaction__customer__address__neighborhood"),
        new("card_transaction__customer__address__state"),
        new("card_transaction__customer__address__postal_code"),
        new("card_transaction__capture_date"),
        new("card_transaction__terminal__type"),
        new("card_transaction__terminal__serial_number"),
        new("card_transaction__detail__legacy__status"),
        new("card_transaction__detail__legacy__transaction_status"),
        new("card_transaction__detail__legacy__operation"),
        new("card_transaction__detail__legacy__canceled_amount"),
        new("card_transaction__detail__legacy__account_name"),
        new("card_transaction__detail__acquirer__name"),
        new("card_transaction__detail__acquirer__nsu"),
        new("card_transaction__detail__acquirer__tid"),
        new("card_transaction__detail__gateway_response__code"),
        new("card_transaction__detail__gateway_response__message"),
        new("card_transaction__detail__antifraud_response__provider_name"),
        new("card_transaction__detail__antifraud_response__score"),
        new("card_transaction__detail__antifraud_response__status"),
        new("card_transaction__detail__pgid"),
        new("card_transaction__detail__operation"),
        new("card_transaction__detail__operation_status"),
        new("card_transaction__detail__operation_id"),
        new("card_transaction__detail__local_datetime"),
        new("card_transaction__detail__provider_datetime"),
        new("card_transaction__detail__operation_amount"),
        new("card_transaction__detail__acquirer_message"),
        new("card_transaction__detail__acquirer_return_code"),
        new("card_transaction__detail__operation_reason"),
        new("card_transaction__detail__financial_event__amount"),
        new("card_transaction__fee__id"),
        new("card_transaction__fee__full_amount"),
        new("card_transaction__fee__type"),
        new("card_transaction__financial_movement__operation_id"),
        new("card_transaction__financial_movement__current_due_date"),
        new("card_transaction__financial_movement__category"),
        new("card_transaction__financial_movement__installment_number"),
        new("card_transaction__financial_movement__amount__discount_rate__fee_type"),
        new("card_transaction__financial_movement__amount__discount_rate__fee"),
        new("card_transaction__financial_movement__amount__discount_rate__effective_fee"),
        new("card_transaction__financial_movement__amount__discount_rate__amount"),
        new("card_transaction__financial_movement__amount__prepayment_fee__fee_type"),
        new("card_transaction__financial_movement__amount__prepayment_fee__fee"),
        new("card_transaction__financial_movement__amount__prepayment_fee__effective_fee"),
        new("card_transaction__financial_movement__amount__prepayment_fee__amount"),
        new("card_transaction__financial_movement__amount__fraud_coverage__fee_type"),
        new("card_transaction__financial_movement__amount__fraud_coverage__fee"),
        new("card_transaction__financial_movement__amount__fraud_coverage__effective_fee"),
        new("card_transaction__financial_movement__amount__fraud_coverage__amount"),
        new("card_transaction__financial_movement__amount__gross"),
        new("card_transaction__financial_movement__amount__net"),
        new("card_transaction__financial_movement__operation"),
        new("card_transaction__financial_movement__detail_operation_id"),
        new("card_transaction__financial_movement__original_due_date"),
        new("card_transaction__financial_movement__payment_owner_document"),
        new("card_transaction__financial_movement__settlement_status"),
        new("card_transaction__financial_movement__id"),
        new("card_transaction__financial_movement__payment_method"),
        new("card_transaction__financial_movement__split_rule_id"),
        new("card_transaction__financial_movement__bulk_anticipation_id"),
        new("card_transaction__financial_movement__payment_owner_id"),
        new("card_transaction__financial_movement__recipient_id"),
        new("card_transaction__financial_movement__payment_owner_stone_account"),
        new("card_transaction__financial_movement__created_at"),
        new("boleto_transaction__type"),
        new("boleto_transaction__transaction_id"),
        new("boleto_transaction__our_number"),
        new("boleto_transaction__fine_amount"),
        new("boleto_transaction__interest_amount"),
        new("boleto_transaction__discount_amount"),
        new("boleto_transaction__fee_amount"),
        new("boleto_transaction__expire_at"),
        new("boleto_transaction__limit_date"),
        new("boleto_transaction__barcode"),
        new("boleto_transaction__writable_line"),
        new("boleto_transaction__instructions", "REPLACE(REPLACE(REPLACE({column}, CHR(10), ' '),CHR(13), ' '), CHR(9), ' ') "),
        new("boleto_transaction__url"),
        new("boleto_transaction__paid_at"),
        new("boleto_transaction__last__operation_status"),
        new("boleto_transaction__last__legacy_status"),
        new("boleto_transaction__bank__code"),
        new("boleto_transaction__bank__name"),
        new("boleto_transaction__receiver__name"),
        new("boleto_transaction__receiver__document_type"),
        new("boleto_transaction__receiver__document"),
        new("boleto_transaction__customer__name"),
        new("boleto_transaction__customer__customer_id"),
        new("boleto_transaction__customer__document_type"),
        new("boleto_transaction__customer__document"),
        new("boleto_transaction__customer__email"),
        new("boleto_transaction__customer__address__street", "REPLACE(REPLACE(REPLACE(REPLACE({column}, CHR(10), ' '), CHR(13), ' '), CHR(9), ' '), ';', ' ')"),
        new("boleto_transaction__customer__address__street_number", "REPLACE(REPLACE(REPLACE(REPLACE({column}, CHR(10), ' '), CHR(13), ' '), CHR(9), ' '), ';', ' ')"),
        new("boleto_transaction__customer__address__extra", "REPLACE(REPLACE(REPLACE(REPLACE({column}, CHR(10), ' '), CHR(13), ' '), CHR(9), ' '), ';', ' ')"),
        new("boleto_transaction__customer__address__neighborhood", "REPLACE(REPLACE(REPLACE(REPLACE({column}, CHR(10), ' '), CHR(13), ' '), CHR(9), ' '), ';', ' ')"),
        new("boleto_transaction__customer__address__postal_code", "REPLACE(REPLACE(REPLACE(REPLACE({column}, CHR(10), ' '), CHR(13), ' '), CHR(9), ' '), ';', ' ')"),
        new("boleto_transaction__customer__address__city", "REPLACE(REPLACE(REPLACE(REPLACE({column}, CHR(10), ' '), CHR(13), ' '), CHR(9), ' '), ';', ' ')"),
        new("boleto_transaction__customer__address__state", "REPLACE(REPLACE(REPLACE(REPLACE({column}, CHR(10), ' '), CHR(13), ' '), CHR(9), ' '), ';', ' ')"),
        new("boleto_transaction__customer__address__country", "REPLACE(REPLACE(REPLACE(REPLACE({column}, CHR(10), ' '), CHR(13), ' '), CHR(9), ' '), ';', ' ')"),
        new("boleto_transaction__fine__start_at"),
        new("boleto_transaction__fine__type"),
        new("boleto_transaction__fine__value"),
        new("boleto_transaction__interest__start_at"),
        new("boleto_transaction__interest__type"),
        new("boleto_transaction__interest__value"),
        new("boleto_transaction__discounts", "to_json({column})"),
        new("boleto_transaction__financial_movement__operation_id"),
        new("boleto_transaction__financial_movement__current_due_date"),
        new("boleto_transaction__financial_movement__category"),
        new("boleto_transaction__financial_movement__installment_number"),
        new("boleto_transaction__financial_movement__amount__discount_rate__fee_type"),
        new("boleto_transaction__financial_movement__amount__discount_rate__fee"),
        new("boleto_transaction__financial_movement__amount__discount_rate__effective_fee"),
        new("boleto_transaction__financial_movement__amount__discount_rate__amount"),
        new("boleto_transaction__financial_movement__amount__prepayment_fee__fee_type"),
        new("boleto_transaction__financial_movement__amount__prepayment_fee__fee"),
        new("boleto_transaction__financial_movement__amount__prepayment_fee__effective_fee"),
        new("boleto_transaction__financial_movement__amount__prepayment_fee__amount"),
        new("boleto_transaction__financial_movement__amount__fraud_coverage__fee_type"),
        new("boleto_transaction__financial_movement__amount__fraud_coverage__fee"),
        new("boleto_transaction__financial_movement__amount__fraud_coverage__effective_fee"),
        new("boleto_transaction__financial_movement__amount__fraud_coverage__amount"),
        new("boleto_transaction__financial_movement__amount__gross"),
        new("boleto_transaction__financial_movement__amount__net"),
        new("boleto_transaction__financial_movement__operation"),
        new("boleto_transaction__financial_movement__detail_operation_id"),
        new("boleto_transaction__financial_movement__original_due_date"),
        new("boleto_transaction__financial_movement__payment_owner_document"),
        new("boleto_transaction__financial_movement__settlement_status"),
        new("boleto_transaction__financial_movement__id"),
        new("boleto_transaction__financial_movement__payment_method"),
        new("boleto_transaction__financial_movement__split_rule_id"),
        new("boleto_transaction__financial_movement__bulk_anticipation_id"),
        new("boleto_transaction__financial_movement__payment_owner_id"),
        new("boleto_transaction__financial_movement__recipient_id"),
        new("boleto_transaction__financial_movement__payment_owner_stone_account"),
        new("boleto_transaction__financial_movement__created_at"),
        new("boleto_transaction__detail__legacy__status"),
        new("boleto_transaction__detail__legacy__transaction_status"),
        new("boleto_transaction__detail__legacy__operation"),
        new("boleto_transaction__detail__legacy__canceled_amount"),
        new("boleto_transaction__detail__legacy__account_name"),
        new("boleto_transaction__detail__pgid"),
        new("boleto_transaction__detail__operation"),
        new("boleto_transaction__detail__operation_status"),
        new("boleto_transaction__detail__operation_id"),
        new("boleto_transaction__detail__local_datetime"),
        new("boleto_transaction__detail__provider_datetime"),
        new("boleto_transaction__detail__operation_amount"),
        new("boleto_transaction__detail__reason"),
        new("boleto_transaction__detail__gateway_response__code"),
        new("boleto_transaction__detail__gateway_response__message"),
        new("pix_transaction__type"),
        new("pix_transaction__transaction_id"),
        new("pix_transaction__e2e_id"),
        new("pix_transaction__pix_key"),
        new("pix_transaction__is_pix_sale_key"),
        new("pix_transaction__pix_key_nickname"),
        new("pix_transaction__paid_amount"),
        new("pix_transaction__fine_amount"),
        new("pix_transaction__interest_amount"),
        new("pix_transaction__discount_amount"),
        new("pix_transaction__reduction_amount"),
        new("pix_transaction__canceled_amount"),
        new("pix_transaction__fee_amount"),
        new("pix_transaction__expire_at"),
        new("pix_transaction__payment_limit_period_days"),
        new("pix_transaction__business_days_only"),
        new("pix_transaction__expires_in"),
        new("pix_transaction__request_for_payer"),
        new("pix_transaction__fine__start_at"),
        new("pix_transaction__fine__type"),
        new("pix_transaction__fine__value"),
        new("pix_transaction__interest__start_at"),
        new("pix_transaction__interest__type"),
        new("pix_transaction__interest__value"),
        new("pix_transaction__interest__period"),
        new("pix_transaction__discounts"),
        new("pix_transaction__reduction__start_at"),
        new("pix_transaction__reduction__value"),
        new("pix_transaction__customer__name"),
        new("pix_transaction__customer__customer_id"),
        new("pix_transaction__customer__document_type"),
        new("pix_transaction__customer__document"),
        new("pix_transaction__customer__email"),
        new("pix_transaction__customer__address__country"),
        new("pix_transaction__customer__address__city"),
        new("pix_transaction__customer__address__street"),
        new("pix_transaction__customer__address__extra"),
        new("pix_transaction__customer__address__street_number"),
        new("pix_transaction__customer__address__neighborhood"),
        new("pix_transaction__customer__address__state"),
        new("pix_transaction__customer__address__postal_code"),
        new("pix_transaction__payer__name"),
        new("pix_transaction__payer__document_type"),
        new("pix_transaction__payer__document"),
        new("pix_transaction__payer__ispb"),
        new("pix_transaction__payer__institution_name"),
        new("pix_transaction__additional_data", "to_json({column})"),
        new("pix_transaction__last__operation_status"),
        new("pix_transaction__last__legacy_status"),
        new("pix_transaction__terminal__id"),
        new("pix_transaction__terminal__type"),
        new("pix_transaction__terminal__serial_number"),
        new("pix_transaction__financial_movement__operation_id"),
        new("pix_transaction__financial_movement__current_due_date"),
        new("pix_transaction__financial_movement__category"),
        new("pix_transaction__financial_movement__installment_number"),
        new("pix_transaction__financial_movement__amount__discount_rate__fee_type"),
        new("pix_transaction__financial_movement__amount__discount_rate__fee"),
        new("pix_transaction__financial_movement__amount__discount_rate__effective_fee"),
        new("pix_transaction__financial_movement__amount__discount_rate__amount"),
        new("pix_transaction__financial_movement__amount__prepayment_fee__fee_type"),
        new("pix_transaction__financial_movement__amount__prepayment_fee__fee"),
        new("pix_transaction__financial_movement__amount__prepayment_fee__effective_fee"),
        new("pix_transaction__financial_movement__amount__prepayment_fee__amount"),
        new("pix_transaction__financial_movement__amount__fraud_coverage__fee_type"),
        new("pix_transaction__financial_movement__amount__fraud_coverage__fee"),
        new("pix_transaction__financial_movement__amount__fraud_coverage__effective_fee"),
        new("pix_transaction__financial_movement__amount__fraud_coverage__amount"),
        new("pix_transaction__financial_movement__amount__gross"),
        new("pix_transaction__financial_movement__amount__net"),
        new("pix_transaction__financial_movement__operation"),
        new("pix_transaction__financial_movement__detail_operation_id"),
        new("pix_transaction__financial_movement__original_due_date"),
        new("pix_transaction__financial_movement__payment_owner_document"),
        new("pix_transaction__financial_movement__settlement_status"),
        new("pix_transaction__financial_movement__id"),
        new("pix_transaction__financial_movement__payment_method"),
        new("pix_transaction__financial_movement__split_rule_id"),
        new("pix_transaction__financial_movement__bulk_anticipation_id"),
        new("pix_transaction__financial_movement__payment_owner_id"),
        new("pix_transaction__financial_movement__recipient_id"),
        new("pix_transaction__financial_movement__payment_owner_stone_account"),
        new("pix_transaction__financial_movement__created_at"),
        new("pix_transaction__detail__legacy__status"),
        new("pix_transaction__detail__legacy__transaction_status"),
        new("pix_transaction__detail__legacy__operation"),
        new("pix_transaction__detail__legacy__canceled_amount"),
        new("pix_transaction__detail__legacy__account_name"),
        new("pix_transaction__detail__pgid"),
        new("pix_transaction__detail__operation"),
        new("pix_transaction__detail__operation_status"),
        new("pix_transaction__detail__operation_id"),
        new("pix_transaction__detail__local_datetime"),
        new("pix_transaction__detail__provider_datetime"),
        new("pix_transaction__detail__operation_amount"),
        new("pix_transaction__detail__qrcode_content"),
        new("pix_transaction__detail__description"),
        new("pix_transaction__detail__refund_id"),
        new("pix_transaction__detail__reason"),
        new("cash_transaction__description"),
        new("cash_transaction__transaction_id"),
        new("cash_transaction__paid_amount"),
        new("cash_transaction__canceled_amount"),
        new("cash_transaction__customer__name"),
        new("cash_transaction__customer__customer_id"),
        new("cash_transaction__customer__document_type"),
        new("cash_transaction__customer__document"),
        new("cash_transaction__customer__email"),
        new("cash_transaction__customer__address__country"),
        new("cash_transaction__customer__address__city"),
        new("cash_transaction__customer__address__street"),
        new("cash_transaction__customer__address__extra"),
        new("cash_transaction__customer__address__street_number"),
        new("cash_transaction__customer__address__neighborhood"),
        new("cash_transaction__customer__address__state"),
        new("cash_transaction__customer__address__postal_code"),
        new("cash_transaction__last__operation_status"),
        new("cash_transaction__last__legacy_status"),
        new("cash_transaction__detail__legacy__status"),
        new("cash_transaction__detail__legacy__transaction_status"),
        new("cash_transaction__detail__legacy__operation"),
        new("cash_transaction__detail__legacy__canceled_amount"),
        new("cash_transaction__detail__legacy__account_name"),
        new("cash_transaction__detail__operation"),
        new("cash_transaction__detail__operation_status"),
        new("cash_transaction__detail__operation_id"),
        new("cash_transaction__detail__local_datetime"),
        new("cash_transaction__detail__provider_datetime"),
        new("cash_transaction__detail__operation_amount"),
        new("cash_transaction__detail__reason"),
        new("cash_transaction__detail__operation_reason"),
        new("processed_at", null, false)
    ];

    public static int ProcessedAtColumnPosition => RequestedColumns.Count;

    private static List<string> GetTablesForChargesList()
    {
        return ["charges_events_by_created_at", "charges_posterior_events_by_created_at"];
    }

    private static List<string> BuildFinalFilters(ChargeReportsWorkerParameters parameters)
    {
        var whereClauses = new List<string>
        {
            $"created_at::TIMESTAMPTZ >= '{parameters.StartDate:o}'::TIMESTAMPTZ",
            $"created_at::TIMESTAMPTZ <= '{parameters.EndDate:o}'::TIMESTAMPTZ"
        };


        if (!string.IsNullOrEmpty(parameters.AllIds))
            whereClauses.Add($"all_ids IN ({string.Join(",", parameters.AllIds.Split(',').Select(id => "'" + id.Trim() + "'"))})");
        if (!string.IsNullOrEmpty(parameters.Acquirers))
            whereClauses.Add($"card_transaction__last__acquirer_name IN ({string.Join(",", parameters.Acquirers.Split(',').Select(acq => "'" + acq.Trim() + "'"))})");
        if (!string.IsNullOrEmpty(parameters.BankNames))
            whereClauses.Add($"boleto_transaction__bank__name IN ({string.Join(",", parameters.BankNames.Split(',').Select(bn => "'" + bn.Trim() + "'"))})");
        if (!string.IsNullOrEmpty(parameters.CardBrands))
            whereClauses.Add($"card_transaction__card__brand IN ({string.Join(",", parameters.CardBrands.Split(',').Select(cb => "'" + cb.Trim() + "'"))})");
        if (!string.IsNullOrEmpty(parameters.FundingSources))
            whereClauses.Add($"card_transaction__funding_source IN ({string.Join(",", parameters.FundingSources.Split(',').Select(fs => "'" + fs.Trim() + "'"))})");
        if (parameters.PaidAt != null)
            whereClauses.Add($"boleto_transaction__paid_at = {parameters.PaidAt}");
        if (!string.IsNullOrEmpty(parameters.PlatformName))
            whereClauses.Add($"platform_name IN ({string.Join(",", parameters.PlatformName.Split(',').Select(pn => "'" + pn.Trim() + "'"))})");
        if (!string.IsNullOrEmpty(parameters.AntifraudStatus))
            whereClauses.Add($"card_transaction__last__antifraud_status IN ({string.Join(",", parameters.AntifraudStatus.Split(',').Select(af => "'" + af.Trim() + "'"))})");
        if (!string.IsNullOrEmpty(parameters.LastOperationStatus))
        {
            whereClauses.Add($"(" +
                $"card_transaction__last__operation_status IN ({string.Join(",", parameters.LastOperationStatus.Split(',').Select(v => "'" + v.Trim() + "'"))})" +
                $" OR boleto_transaction__last__operation_status IN ({string.Join(",", parameters.LastOperationStatus.Split(',').Select(v => "'" + v.Trim() + "'"))})" +
                $" OR pix_transaction__last__operation_status IN ({string.Join(",", parameters.LastOperationStatus.Split(',').Select(v => "'" + v.Trim() + "'"))})" +
                $" OR cash_transaction__last__operation_status IN ({string.Join(",", parameters.LastOperationStatus.Split(',').Select(v => "'" + v.Trim() + "'"))})" +
                $")");
        }

        if (!string.IsNullOrEmpty(parameters.LastLegacyStatus))
        {
            whereClauses.Add($"(" +
                $"(payment_method = 'card' AND  card_transaction__last__legacy_status IN ({string.Join(",", parameters.LastLegacyStatus.Split(',').Select(v => "'" + v.Trim() + "'"))}))" +
                $" OR (payment_method = 'boleto' AND boleto_transaction__last__legacy_status IN ({string.Join(",", parameters.LastLegacyStatus.Split(',').Select(v => "'" + v.Trim() + "'"))}))" +
                $" OR (payment_method = 'pix' AND pix_transaction__last__legacy_status IN ({string.Join(",", parameters.LastLegacyStatus.Split(',').Select(v => "'" + v.Trim() + "'"))}))" +
                $" OR (payment_method = 'cash' AND cash_transaction__last__legacy_status IN ({string.Join(",", parameters.LastLegacyStatus.Split(',').Select(v => "'" + v.Trim() + "'"))}))" +
                $")");
        }

        if (parameters.MinAmount != null)
            whereClauses.Add($"amount >= {parameters.MinAmount}");
        if (parameters.MaxAmount != null)
            whereClauses.Add($"amount <= {parameters.MaxAmount}");

        if (!string.IsNullOrEmpty(parameters.Customers))
        {
            whereClauses.Add($"(" +
                $"pix_transaction__customer__name IN ({string.Join(",", parameters.Customers.Split(',').Select(v => "'" + v.Trim() + "'"))})" +
                $" OR boleto_transaction__customer__name IN ({string.Join(",", parameters.Customers.Split(',').Select(v => "'" + v.Trim() + "'"))})" +
                $" OR card_transaction__customer__name IN ({string.Join(",", parameters.Customers.Split(',').Select(v => "'" + v.Trim() + "'"))})" +
                $" OR cash_transaction__customer__name IN ({string.Join(",", parameters.Customers.Split(',').Select(v => "'" + v.Trim() + "'"))})" +
                $" OR pix_transaction__customer__customer_id IN ({string.Join(",", parameters.Customers.Split(',').Select(v => "'" + v.Trim() + "'"))})" +
                $" OR boleto_transaction__customer__customer_id IN ({string.Join(",", parameters.Customers.Split(',').Select(v => "'" + v.Trim() + "'"))})" +
                $" OR card_transaction__customer__customer_id IN ({string.Join(",", parameters.Customers.Split(',').Select(v => "'" + v.Trim() + "'"))})" +
                $" OR cash_transaction__customer__customer_id IN ({string.Join(",", parameters.Customers.Split(',').Select(v => "'" + v.Trim() + "'"))})" +
                $" OR pix_transaction__customer__document IN ({string.Join(",", parameters.Customers.Split(',').Select(v => "'" + v.Trim() + "'"))})" +
                $" OR boleto_transaction__customer__document IN ({string.Join(",", parameters.Customers.Split(',').Select(v => "'" + v.Trim() + "'"))})" +
                $" OR card_transaction__customer__document IN ({string.Join(",", parameters.Customers.Split(',').Select(v => "'" + v.Trim() + "'"))})" +
                $" OR cash_transaction__customer__document IN ({string.Join(",", parameters.Customers.Split(',').Select(v => "'" + v.Trim() + "'"))})" +
                $" OR pix_transaction__customer__email IN ({string.Join(",", parameters.Customers.Split(',').Select(v => "'" + v.Trim() + "'"))})" +
                $" OR boleto_transaction__customer__email IN ({string.Join(",", parameters.Customers.Split(',').Select(v => "'" + v.Trim() + "'"))})" +
                $" OR card_transaction__customer__email IN ({string.Join(",", parameters.Customers.Split(',').Select(v => "'" + v.Trim() + "'"))})" +
                $" OR cash_transaction__customer__email IN ({string.Join(",", parameters.Customers.Split(',').Select(v => "'" + v.Trim() + "'"))})" +
                $")");
        }


        return whereClauses;
    }

    public static async Task<string> SelectChargesEventsAsync(
        string inputPath,
        string outputPath,
        GenerateReportInput reportInput,
        bool hasRealTimeData,
        bool hasParquetData,
        IColumnMappingService columnMappingService,
        List<string> allowedFinancialMovementCategories
    )
    {
        var tables = GetTablesForChargesList();
        var tableQueries = new List<string>();

        var parquetQuery = string.Empty;
        if (hasParquetData)
        {
            foreach (var tableName in tables)
            {
                var tableInputPath = Path.Combine(inputPath, tableName);

                if (!Directory.Exists(tableInputPath) || Directory.GetFiles(tableInputPath, "*.parquet").Length == 0)
                {
                    Log.Debug($"[ChargeListReportQuery] No parquet files found in {tableInputPath}, skipping table {tableName}");
                    continue;
                }

                var columnMapping = await columnMappingService.GetColumnMappingAsync(tableName);
                var whereClauses = ReportQueryFilters.BuildBaseFilters(reportInput, allowedFinancialMovementCategories, columnMapping);
                var where = whereClauses.Count > 0 ? $"WHERE {string.Join("\nAND ", whereClauses)}" : string.Empty;

                var nullClauses = await columnMappingService.GenerateNullClausesAsync(tableName, RequestedColumns);
                var nullClausesStr = string.Join(",\n                        ", nullClauses);

                var sqlColumns = await columnMappingService.GenerateSqlColumnsAsync(tableName, RequestedColumns);
                var sqlColumnsStr = string.Join(",\n        ", sqlColumns);

                // Build sort_key expression using physical column names
                var paymentMethodCol = ColumnMappingService.GetColumnNameForFilter("payment_method", columnMapping);
                var acquirerNameCol = ColumnMappingService.GetColumnNameForFilter("card_transaction__detail__acquirer__name", columnMapping);
                var acquirerNsuCol = ColumnMappingService.GetColumnNameForFilter("card_transaction__detail__acquirer__nsu", columnMapping);
                var idCol = ColumnMappingService.GetColumnNameForFilter("id", columnMapping);
                var sortKeyExpression = $@"CASE 
                    WHEN {paymentMethodCol} = 'card' 
                      AND lower({acquirerNameCol}) = 'stone'
                      AND {acquirerNsuCol} IS NOT NULL
                      AND {acquirerNsuCol} != ''
                    THEN {acquirerNsuCol}
                    ELSE {idCol}
                END AS sort_key";

                var tableQuery = $@"
                    SELECT
                        {sortKeyExpression},
                        {sqlColumnsStr}
                    FROM (
                        SELECT 
                            *,
                            {nullClausesStr}
                        FROM read_parquet(['{tableInputPath}/*.parquet'], union_by_name=True)
                    ) AS base
                    {where}";

                tableQueries.Add(tableQuery);
            }

            if (tableQueries.Count > 0)
            {
                parquetQuery = string.Join("\n\n                UNION ALL\n\n", tableQueries);
            }
        }

        var whereClausesRealTime = ReportQueryFilters.BuildBaseFilters(reportInput, allowedFinancialMovementCategories, null, true);
        var whereRealTime = whereClausesRealTime.Count > 0 ? $"WHERE {string.Join("\nAND ", whereClausesRealTime)}" : string.Empty;

        var realTimeQuery = string.Empty;
        if (hasRealTimeData)
        {
            // Build sort_key expression using logical column names
            var sortKeyExpression = @"CASE 
                WHEN payment_method = 'card' 
                  AND lower(card_transaction__detail__acquirer__name) = 'stone'
                  AND card_transaction__detail__acquirer__nsu IS NOT NULL
                  AND card_transaction__detail__acquirer__nsu != ''
                THEN card_transaction__detail__acquirer__nsu
                ELSE id
            END AS sort_key";

            var sqlColumns = RequestedColumns.Select(c => c.ToSqlColumn(new Dictionary<string, string>(), isRealTime: true));
            realTimeQuery = $@"
                SELECT {sortKeyExpression},
                    {string.Join(",\n        ", sqlColumns)}
                FROM read_csv(['{inputPath}/*.csv'], union_by_name=True, all_varchar=True)
                {whereRealTime}";
        }

        string query;
        if (hasRealTimeData && hasParquetData)
        {
            query = $@"
                {parquetQuery}
                UNION ALL
                {realTimeQuery}";
        }
        else
        {
            query = hasParquetData ? parquetQuery : realTimeQuery;
        }

        var finalQuery = $"COPY ({query}) TO '{outputPath}' (HEADER, DELIMITER ',');";
        return finalQuery;
    }

    public static string FilterCharges(string inputPath, string outputPath, ChargeReportsWorkerParameters parameters)
    {
        var whereClauses = BuildFinalFilters(parameters);
        whereClauses.Add($"status IS NOT NULL");
        whereClauses.Add($"status <> ''");
        if (parameters.WithFailed != true)
            whereClauses.Add($"status <> 'failed'");

        var where = whereClauses.Count > 0 ? $"WHERE {string.Join("\nAND ", whereClauses)}" : string.Empty;

        var query = $@"
            SELECT *
            FROM read_csv(['{inputPath}'], union_by_name=True, all_varchar=true)
            {where}
        ";

        return $"COPY ({query}) TO '{outputPath}' (HEADER false, DELIMITER ',');";
    }
}
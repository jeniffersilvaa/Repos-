using System.Text;
using Elastic.Clients.Elasticsearch;
using Elastic.Clients.Elasticsearch.Core.Search;
using Elastic.Clients.Elasticsearch.QueryDsl;
using PaymentsDataLayerReports.Application.Extensions;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.Models;
using Serilog;

namespace PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.RealtimeChargeEvents;

public interface IRealtimeChargeEventsService
{
    Task<bool> BuildRealtimeFileAsync(GenerateReportInput input, string path);
}

public class RealtimeChargeEventsService(
    ElasticsearchClient client
) : IRealtimeChargeEventsService
{
    private const int PageSize = 5000;

    private async Task<SearchResponse<Dictionary<string, object>>> GetChargesEventsAsync(
        GenerateReportInput input,
        int size,
        IReadOnlyCollection<FieldValue>? searchAfter = null
    )
    {
        Log.ForContext("Document", input.ReportMetadata.ChargeReportParameters!.Document)
            .ForContext("Organizations", input.ReportMetadata.ChargeReportParameters!.Organizations)
            .ForContext("PartitionDate", input.PartitionDate)
            .Debug("[RealtimeChargeEventsService.GetChargesEventsAsync] Starting");

        try
        {
            List<Query> filters = [];

            var partitionSet = input.PartitionSet;
            var field = partitionSet.PartitionIdReferenceType switch
            {
                "document" => "merchant.document",
                "merchant_id" => "merchant.merchant_id",
                _ => throw new InvalidOperationException($"Unknown PartitionIdReferenceType: {partitionSet.PartitionIdReferenceType}")
            };

            filters.Add(new TermsQuery
            {
                Field = field!,
                Terms = new TermsQueryField([.. partitionSet.PartitionIdReferences.Select(FieldValue.String)])
            });

            if (!string.IsNullOrEmpty(input.ReportMetadata.ChargeReportParameters!.AccountId))
            {
                filters.Add(new TermQuery("merchant.account_id"!) { Value = input.ReportMetadata.ChargeReportParameters.AccountId });
            }

            filters.Add(new TermsQuery()
            {
                Field = "merchant.organization"!,
                Terms = new TermsQueryField([.. input.ReportMetadata.ChargeReportParameters!.Organizations.SplitToList().Where(v => !string.IsNullOrWhiteSpace(v)).Select(FieldValue.String)])
            });

            filters.Add(new DateRangeQuery("created_at"!)
            {
                Gte = input.PartitionDate.ToString("yyyy-MM-dd"),
                Lt = input.PartitionDate.AddDays(1).ToString("yyyy-MM-dd")
            });

            var indices = input.ReportMetadata.ChargeReportParameters!.IsSandbox == true ? "sdx_charge" : "charge_event";

            var request = new SearchRequest(indices)
            {
                From = 0,
                Size = size,
                Query = new BoolQuery { Filter = filters },
                TrackTotalHits = new TrackHits(true),
                Sort = [
                    SortOptions.Field("created_at"!, new FieldSort { Order = SortOrder.Desc })
                ],
                Timeout = "10000ms",
                IgnoreUnavailable = true,
                AllowPartialSearchResults = false
            };

            if (searchAfter is not null)
            {
                request.SearchAfter = [.. searchAfter];
            }

            var response = await client.SearchAsync<Dictionary<string, object>>(request);
            return response;
        }
        catch (Exception ex)
        {
            Log.ForContext("Exception", ex)
               .ForContext("Document", input.ReportMetadata.ChargeReportParameters!.Document)
               .ForContext("Organizations", input.ReportMetadata.ChargeReportParameters.Organizations)
               .ForContext("PartitionDate", input.PartitionDate)
               .Error("[RealtimeChargeEventsService.GetChargesEventsAsync] Error fetching charges events");
            throw;
        }
    }

    public async Task<bool> BuildRealtimeFileAsync(GenerateReportInput input, string path)
    {
        Log.ForContext("Document", input.ReportMetadata.ChargeReportParameters!.Document)
            .ForContext("Organizations", input.ReportMetadata.ChargeReportParameters.Organizations)
            .ForContext("PartitionDate", input.PartitionDate)
            .Debug("[RealtimeChargeEventsService.BuildRealtimeFileAsync] Starting");

        bool wroteAnyData = false;

        try
        {
            var filePath = Path.Combine(path, "realtime.csv");
            await using var writer = new StreamWriter(filePath, append: false, Encoding.UTF8);
            var isHeaderWritten = false;
            IReadOnlyCollection<FieldValue>? searchAfter = null;

            while (true)
            {
                var response = await GetChargesEventsAsync(input, PageSize, searchAfter);

                if (response.Hits.Count == 0) break;

                if (!isHeaderWritten)
                {
                    await writer.WriteLineAsync(RealtimeChargeEventsMapper.GetHeader());
                    isHeaderWritten = true;
                }

                foreach (var doc in response.Documents)
                {
                    var row = RealtimeChargeEventsMapper.BuildRow(doc);
                    await writer.WriteLineAsync(row);
                    wroteAnyData = true;
                }

                searchAfter = response.Hits.Last().Sort;
            }
        }
        catch (Exception ex)
        {
            Log.ForContext("Exception", ex)
                .ForContext("Document", input.ReportMetadata.ChargeReportParameters!.Document)
                .ForContext("Organizations", input.ReportMetadata.ChargeReportParameters.Organizations)
                .ForContext("PartitionDate", input.PartitionDate)
                .Error("[RealtimeChargeEventsService.BuildRealtimeFileAsync] Error");

            throw;
        }

        Log.ForContext("Document", input.ReportMetadata.ChargeReportParameters.Document)
            .ForContext("Organizations", input.ReportMetadata.ChargeReportParameters.Organizations)
            .ForContext("PartitionDate", input.PartitionDate)
            .Debug("[RealtimeChargeEventsService.BuildRealtimeFileAsync] Completed");

        return wroteAnyData;
    }
}
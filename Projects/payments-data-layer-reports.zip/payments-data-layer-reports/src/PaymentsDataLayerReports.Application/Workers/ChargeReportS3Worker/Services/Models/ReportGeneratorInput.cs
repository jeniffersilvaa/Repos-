using Datadog.Trace;
using PaymentsDataLayerReports.Application.Services.DeltaTablePartitionBuilder;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;

namespace PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.Models;

public class GenerateReportInput
{
    public required DateTime PartitionDate { get; set; }
    public required DeltaTablePartitionSet PartitionSet { get; set; }
    public required ReportMetadata ReportMetadata { get; set; }
    public required CancellationToken CancellationToken { get; set; }
    public required string JobId { get; set; }
}
using System.Diagnostics;
using Datadog.Trace;
using PaymentsDataLayerReports.Application.Constants;
using PaymentsDataLayerReports.Application.Entities;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Services.ReportTypeConfiguration;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.Models;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.RealtimeChargeEvents;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;
using PaymentsDataLayerReports.Application.Workers.Shared;
using PaymentsDataLayerReports.Application.Workers.Shared.Modifiers.ChargeList;
using Serilog;

namespace PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.ChargeList;

public class ChargeListReportGenerator(
    IDeltaLakeManager deltaLakeManager,
    IS3ClientWrapper s3ClientWrapper,
    IChargeListReportManager chargeListReportManager,
    IRealtimeChargeEventsService RealtimeChargeEventsService,
    ICetFeatureManager cetFeatureManager,
    IServiceProvider serviceProvider
) : IReportGenerator<GenerateReportInput>
{

    public async Task Execute(GenerateReportInput input)
    {
        var cancellationToken = input.CancellationToken;
        var jobId = input.JobId;
        var parameters = input.ReportMetadata.ChargeReportParameters;

        ISaleCsvMapper<Charge> csvMapper = serviceProvider.GetRequiredKeyedService<ISaleCsvMapper<Charge>>(parameters.ReportType);
        csvMapper.IsCetEnabled = cetFeatureManager.IsCET(parameters.AffiliationCodes) || cetFeatureManager.IsCET(parameters.Document);
        var modifier = new SalesModifier(csvMapper);

        using var scope = Tracer.Instance.StartActive("ChargeListReportGenerator.Execute");
        scope.Span.SetTag("ChargeListReportGenerator.Execute.JobId", jobId);
        scope.Span.SetTag("ChargeListReportGenerator.Execute.ReportId", input.ReportMetadata.ReportId);
        scope.Span.SetTag("ChargeListReportGenerator.Execute.PartitionDate", $"{input.PartitionDate:yyyy-MM-dd}");

        Log.ForContext("Parameters", input.ReportMetadata.ChargeReportParameters)
            .ForContext("JobId", jobId)
            .ForContext("ReportId", input.ReportMetadata.ReportId)
            .ForContext("PartitionDate", input.PartitionDate)
            .Debug("[ChargeListReportGenerator.Execute] Starting charge list report");

        var stopwatch = Stopwatch.StartNew();

        try
        {
            var realTimeDataTask = RealtimeChargeEventsService.BuildRealtimeFileAsync(input, chargeListReportManager.ChargesEventsRawParquetPath);

            // Writes header file before processing the first date's report
            if (input.ReportMetadata.ChargeReportParameters!.StartDate.Date == input.PartitionDate)
            {
                await s3ClientWrapper.UploadReportHeaderAsync(
                    input.ReportMetadata.ReportId,
                    modifier.GetHeader()
                );
            }

            var totalFileSize = await deltaLakeManager.DownloadAsync(input, chargeListReportManager.ChargesEventsRawParquetPath);

            var hasRealTimeData = await realTimeDataTask;  // Wait real-time data to be fetched
            var hasparquetData = totalFileSize > 0;

            if (!hasRealTimeData && !hasparquetData)
            {
                Log.ForContext("JobId", jobId)
                   .ForContext("ReportId", input.ReportMetadata.ReportId)
                   .ForContext("PartitionDate", input.PartitionDate)
                   .Debug($"[ChargeListReportGenerator.Execute] No data available");
                return;
            }

            var (csvCount, csvFileSize) = await deltaLakeManager.ConvertToCsvAsync(
                input,
                chargeListReportManager.ChargesEventsRawParquetPath,
                chargeListReportManager.ChargesEventsRawCsvFile,
                hasRealTimeData,
                hasparquetData
            );
            var totalDiskUsage = totalFileSize + csvFileSize;
            var totalDiskUsageMB = totalDiskUsage / ByteSizeConstants.MB;
            scope.Span.SetTag("ChargeListReportGenerator.Execute.total_disk_usage_bytes", totalDiskUsage.ToString());
            scope.Span.SetTag("ChargeListReportGenerator.Execute.total_disk_usage_mb", totalDiskUsageMB.ToString("F2"));

            if (csvCount == 0)
            {
                Log.ForContext("JobId", jobId)
                   .ForContext("ReportId", input.ReportMetadata.ReportId)
                   .ForContext("PartitionDate", input.PartitionDate)
                   .Debug($"[ChargeListReportGenerator.Execute] Empty CSV file after filtering");
                return;
            }

            // Delete parquet files temp directory
            chargeListReportManager.TryDeleteParquetPath();

            // Read CSV header
            var inputHeader = CsvHelper.GetHeader(chargeListReportManager.ChargesEventsRawCsvFile);

            // Sort events by charge id
            chargeListReportManager.SortEventsByChargeId(jobId, input.ReportMetadata.ReportId, input.PartitionDate, ChargeListReportQuery.ProcessedAtColumnPosition);

            // Delete raw CSV file
            chargeListReportManager.TryDeleteFile(chargeListReportManager.ChargesEventsRawCsvFile);

            // Groups events into charges 
            Log.ForContext("JobId", jobId)
                .ForContext("ReportId", input.ReportMetadata.ReportId)
                .ForContext("PartitionDate", input.PartitionDate)
                .ForContext("TotalDiskUsageMB", totalDiskUsageMB)
                .Debug($"[ChargeListReportGenerator.Execute] Grouping events by charge id");
            await using var chargesEventsSortedByIdStream = new FileStream(chargeListReportManager.ChargesEventsSortedByIdCsvFile, FileMode.Open, FileAccess.Read, FileShare.Read);
            await using var chargesRawStream = new FileStream(chargeListReportManager.ChargesRawCsvFile, FileMode.Create, FileAccess.Write, FileShare.None);

            await ChargeListReportService.ProcessAsync(
                chargesEventsSortedByIdStream,
                chargesRawStream,
                inputHeader,
                input.ReportMetadata.ReportId,
                jobId,
                modifier,
                parameters,
                cancellationToken
            );

            // Delete sorted by charge id CSV file
            chargeListReportManager.TryDeleteFile(chargeListReportManager.ChargesEventsSortedByIdCsvFile);

            // Sort charges by created_at
            var separator = CsvSeparatorConstants.GetSeparator(
                ReportTypeConfigurationProvider.GetCsvSeparator(parameters.ReportType));
            chargeListReportManager.SortChargesByCreatedAt(jobId, input.ReportMetadata.ReportId, input.PartitionDate, chargeListReportManager.ChargesRawCsvFile, modifier.CreatedAtColumnPosition, separator);

            // Delete raw CSV file
            chargeListReportManager.TryDeleteFile(chargeListReportManager.ChargesRawCsvFile);

            // Delete filtered CSV file
            chargeListReportManager.TryDeleteFile(chargeListReportManager.ChargesFilteredCsvFile);

            // Upload charges to S3
            await s3ClientWrapper.UploadReportAsync(
                sourcePath: chargeListReportManager.ChargesSortedByCreatedAtCsvFile,
                reportId: input.ReportMetadata.ReportId,
                partitionIdGroup: input.PartitionSet.GetPartitionIdGroup(),
                partitionDate: input.PartitionDate
            );
        }
        catch (Exception ex)
        {
            Log.ForContext("Exception", ex)
                .ForContext("JobId", jobId)
                .ForContext("ReportId", input.ReportMetadata.ReportId)
                .ForContext("ReportDate", input.PartitionDate)
                .Error("[ChargeListReportGenerator.Execute] Error processing charge list report");
            throw;
        }
        finally
        {
            // Ensure cleanup
            chargeListReportManager.Dispose();

            stopwatch.Stop();
            Log.ForContext("Duration", stopwatch.Elapsed.TotalSeconds)
                .ForContext("JobId", jobId)
                .ForContext("ReportId", input.ReportMetadata.ReportId)
                .ForContext("ReportDate", input.PartitionDate)
                .Debug($"[ChargeListReportGenerator.Execute] Charge list report completed");
        }

    }

}
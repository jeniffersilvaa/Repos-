using System.Text.Json;
using Datadog.Trace;
using PaymentsDataLayerReports.Application.Types;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.ChargeList.Validation;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;
using PaymentsDataLayerReports.Application.Workers.ChargeReportWorker;
using PaymentsDataLayerReports.Application.Workers.Shared.Modifiers.ChargeList;
using Serilog;

namespace PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.ChargeList;

public static class ChargeListReportService
{
    public static async Task ProcessAsync(
        Stream input,
        Stream output,
        string inputHeader,
        string reportId,
        string jobId,
        SalesModifier modifier,
        ChargeReportsWorkerParameters parameters,
        CancellationToken cancellationToken
    )
    {
        using var scope = Tracer.Instance.StartActive("ChargeListCsvProcessor.ProcessAsync");

        Log.ForContext("JobId", jobId)
            .ForContext("ReportId", reportId)
            .Debug($"[ChargeListCsvProcessor.ProcessAsync] Starting");

        var start = BetterStopwatch.GetTimestamp();

        // Build input column index map
        var inputHeaderList = inputHeader.Split(',');
        var inputHeaderIndex = new Dictionary<string, int>();
        for (int i = 0; i < inputHeaderList.Length; i++)
            inputHeaderIndex[inputHeaderList[i]] = i;
        int inputHeaderCount = inputHeaderList.Length;

        // Setup streams
        using var reader = new StreamReader(input);
        using var writer = new StreamWriter(output) { AutoFlush = true };

        // Accumulator for events grouped by sort_key
        string? currentSortKey = null;
        var groupedEvents = new List<string>();
        CsvRow? currentCharge = null;

        while (true)
        {
            string? currentEventAsString = await reader.ReadLineAsync(cancellationToken);

            if (currentEventAsString != null)
            {
                var currentEvent = CsvHelper.ParseCsvRow(currentEventAsString, inputHeaderCount);
                var sortKey = currentEvent.GetField<string>(inputHeaderIndex, "sort_key");

                // If sort_key changed and we have accumulated events, process the group
                if (currentSortKey != null && sortKey != currentSortKey)
                {
                    currentCharge = await ProcessGroupedEvents(groupedEvents, currentCharge, inputHeaderIndex, inputHeaderCount, modifier, writer, parameters, cancellationToken);
                    groupedEvents.Clear();
                }

                // Accumulate event
                groupedEvents.Add(currentEventAsString);
                currentSortKey = sortKey;
            }
            else
            {
                // EOF reached - process last group if exists
                if (groupedEvents.Count > 0)
                {
                    currentCharge = await ProcessGroupedEvents(groupedEvents, currentCharge, inputHeaderIndex, inputHeaderCount, modifier, writer, parameters, cancellationToken);
                }
                break;
            }
        }

        // Write final charge if exists
        if (currentCharge != null)
        {
            await WriteCsvRow(modifier, writer, currentCharge, parameters, cancellationToken);
        }

        Log.ForContext("JobId", jobId)
            .ForContext("ReportId", reportId)
            .ForContext("TotalSeconds", BetterStopwatch.GetElapsedTime(start).TotalSeconds)
            .Debug($"[ChargeListCsvProcessor.ProcessAsync] Completed");
    }

    private static async Task WriteCsvRow(SalesModifier modifier, StreamWriter writer, CsvRow? currentCharge, ChargeReportsWorkerParameters parameters, CancellationToken cancellationToken)
    {
        PostProcessCharge(currentCharge!);

        if (ValidateSaleReportCSVField.IsValidRow(currentCharge!, parameters))
        {
            var csvRow = modifier.BuildRow(currentCharge!);
            if (csvRow is null) return;
            await writer.WriteLineAsync(csvRow.AsMemory(), cancellationToken);
        }
    }

    private static async Task<CsvRow?> ProcessGroupedEvents(
        List<string> groupedEvents,
        CsvRow? currentCharge,
        Dictionary<string, int> inputHeaderIndex,
        int inputHeaderCount,
        SalesModifier modifier,
        StreamWriter writer,
        ChargeReportsWorkerParameters parameters,
        CancellationToken cancellationToken)
    {
        // Parse all events once
        var parsedEvents = groupedEvents
            .Select(e => CsvHelper.ParseCsvRow(e, inputHeaderCount))
            .ToList();

        // First pass: scan organizations and determine filtering
        var hasStone = false;
        var hasPagarme = false;
        var isPagarmeArray = new bool[parsedEvents.Count];

        for (int i = 0; i < parsedEvents.Count; i++)
        {
            var org = parsedEvents[i].GetField<string>(inputHeaderIndex, "merchant__organization");

            if (string.Equals(org, "stone", StringComparison.OrdinalIgnoreCase))
                hasStone = true;
            else if (string.Equals(org, "pagarme", StringComparison.OrdinalIgnoreCase))
            {
                hasPagarme = true;
                isPagarmeArray[i] = true;
            }
        }

        // Determine which events to process
        var eventsToProcess = (hasStone && hasPagarme)
            ? parsedEvents.Where((_, i) => isPagarmeArray[i]).ToList()
            : parsedEvents;

        // Initialize or clear charge
        if (currentCharge != null)
        {
            await WriteCsvRow(modifier, writer, currentCharge, parameters, cancellationToken);
            currentCharge.ClearRow(ChargeListReportHeader.DefaultValues);
        }
        else
        {
            currentCharge = new CsvRow(ChargeListReportHeader.DefaultValues);
        }

        // Process filtered events
        foreach (var evt in eventsToProcess)
        {
            ProcessChargeEventRow(evt, currentCharge, inputHeaderIndex);
        }

        return currentCharge;
    }

    private static void ProcessChargeEventRow(CsvRow currentEvent, CsvRow currentCharge, Dictionary<string, int> inputHeaderIndex)
    {
        var paymentMethod = currentEvent.GetField<string>(inputHeaderIndex, "payment_method");

        switch (paymentMethod)
        {
            case "card":
                CardProcessor.Process(currentEvent, currentCharge, inputHeaderIndex);
                break;
            case "pix":
                PixProcessor.Process(currentEvent, currentCharge, inputHeaderIndex);
                break;
            case "cash":
                CashProcessor.Process(currentEvent, currentCharge, inputHeaderIndex);
                break;
            case "boleto":
                BoletoProcessor.Process(currentEvent, currentCharge, inputHeaderIndex);
                break;
            default:
                Log.ForContext("PaymentMethod", paymentMethod)
                   .Debug($"[ChargeListProcessor.ProcessChargeEventRow] Invalid payment method");
                break;
        }
    }

    private static void PostProcessCharge(CsvRow currentCharge)
    {
        var paymentMethod = currentCharge.GetField<string>(ChargeListReportHeader.HeaderIndex, "payment_method");

        switch (paymentMethod)
        {
            case "card":
                CardProcessor.ComputeAmounts(currentCharge);
                break;
            case "cash":
                CashProcessor.ComputeAmounts(currentCharge);
                break;
            case "boleto":
                BoletoProcessor.ComputeAmounts(currentCharge);
                break;
            case "pix":
                PixProcessor.ComputeAmounts(currentCharge);
                break;
            default:
                Log.ForContext("PaymentMethod", paymentMethod)
                   .Debug($"[ChargeListProcessor.PostProcessCharge] Invalid payment method");
                break;
        }
    }
}

public static class CardProcessor
{
    public static void Process(CsvRow currentEvent, CsvRow currentCharge, Dictionary<string, int> inputHeaderIndex)
    {
        var operation = currentEvent.GetField<string>(inputHeaderIndex, "card_transaction__detail__operation") ??
            currentEvent.GetField<string>(inputHeaderIndex, "card_transaction__fee__type");

        switch (operation)
        {
            case "authorization" or "auth_and_capture" or "pre_auth" or "create":
                SetFields(currentEvent, currentCharge, inputHeaderIndex);
                AppendDetails(currentEvent, currentCharge, inputHeaderIndex);
                break;
            case "capture" or "cancel" or "cancel_request" or "pay":
                AppendDetails(currentEvent, currentCharge, inputHeaderIndex);
                break;
            case "chargeback" or "chargeback_refund":
                AppendDetails(currentEvent, currentCharge, inputHeaderIndex, true);
                break;
            case "discount_rate" or "prepayment_fee" or "prepayment_fee_refund" or "service_fee" or "service_fee_refund":
                AppendFees(currentEvent, currentCharge, inputHeaderIndex);
                ComputeFees(currentEvent, currentCharge, inputHeaderIndex);
                break;
            default:
                var financialMovementCategory = currentEvent.GetField<string>(inputHeaderIndex, "card_transaction__financial_movement__category");
                if (!string.IsNullOrEmpty(financialMovementCategory))
                    break;

                Log.ForContext("Operation", operation)
                   .Warning($"[CardProcessor.Process] Invalid operation");
                break;
        }
    }

    private static void SetFields(CsvRow currentEvent, CsvRow currentCharge, Dictionary<string, int> inputHeaderIndex)
    {
        var asIsFields = new[]
        {
            "id",
            "initiator_id",
            "platform_name",
            "attempt_count",
            "product",
            "charge_id",
            "origin",
            "origin_id",
            "amount",
            "payment_method",
            "point_of_interaction_type",
            "all_ids",
            "code",
            "status",
            "gateway",
            "gateway_order_id",
            "split",
            "metadata",
            "merchant__organization",
            "merchant__user_id",
            "merchant__document",
            "merchant__affiliation_key",
            "merchant__affiliation_code",
            "merchant__account_id",
            "merchant__merchant_id",
            "merchant__stone_account",
            "merchant__payment_profile_id",
            "card_transaction__type",
            "card_transaction__funding_source",
            "card_transaction__transaction_id",
            "card_transaction__authorization_code",
            "card_transaction__authorized_state",
            "card_transaction__installments",
            "card_transaction__installments_type",
            "card_transaction__scheme_business_model",
            "card_transaction__last__acquirer_name",
            "card_transaction__last__acquirer_return_code",
            "card_transaction__last__antifraud_status",
            "card_transaction__last__operation_status",
            "card_transaction__last__legacy_status",
            "card_transaction__card__brand",
            "card_transaction__card__brand_id",
            "card_transaction__card__first_six_digits",
            "card_transaction__card__last_four_digits",
            "card_transaction__card__entry_mode",
            "card_transaction__card__holder_name",
            "card_transaction__card__exp_month",
            "card_transaction__card__exp_year",
            "card_transaction__card__country_code",
            "card_transaction__card__currency_code",
            "card_transaction__card__number_token",
            "card_transaction__card__label",
            "card_transaction__terminal__type",
            "card_transaction__terminal__serial_number",
            "card_transaction__customer__name",
            "card_transaction__customer__customer_id",
            "card_transaction__customer__document_type",
            "card_transaction__customer__document",
            "card_transaction__customer__email",
            "card_transaction__customer__address__country",
            "card_transaction__customer__address__city",
            "card_transaction__customer__address__street",
            "card_transaction__customer__address__extra",
            "card_transaction__customer__address__street_number",
            "card_transaction__customer__address__neighborhood",
            "card_transaction__customer__address__state",
            "card_transaction__customer__address__postal_code",
        };

        foreach (var field in asIsFields)
        {
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex[field], currentEvent.GetField<string>(inputHeaderIndex, field));
        }

        var createdAt = currentEvent.GetField<DateTime?>(inputHeaderIndex, "created_at");
        if (createdAt != default && createdAt.HasValue)
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["created_at"], createdAt.Value.ToString("yyyy-MM-ddTHH:mm:ss.fffK"));
    }

    private static void AppendDetails(
        CsvRow currentEvent,
        CsvRow currentCharge,
        Dictionary<string, int> inputHeaderIndex,
        bool isChargeback = false
    )
    {
        var organization = currentEvent.GetField<string>(inputHeaderIndex, "merchant__organization");

        int operationAmount;
        if (isChargeback && organization != "pagarme")
            operationAmount = currentEvent.GetField<int?>(inputHeaderIndex, "card_transaction__detail__financial_event__amount") ?? 0;
        else
            operationAmount = currentEvent.GetField<int?>(inputHeaderIndex, "card_transaction__detail__operation_amount") ?? 0;

        var operationId = currentEvent.GetField<string>(inputHeaderIndex, "card_transaction__detail__operation_id");

        var detail = new Dictionary<string, object?>
        {
            { "pgid", currentEvent.GetField(inputHeaderIndex, "card_transaction__detail__pgid") },
            { "operation", currentEvent.GetField(inputHeaderIndex, "card_transaction__detail__operation") },
            { "operation_status", currentEvent.GetField(inputHeaderIndex, "card_transaction__detail__operation_status") },
            { "operation_id", operationId },
            { "local_datetime", currentEvent.GetField(inputHeaderIndex, "card_transaction__detail__local_datetime") },
            { "provider_datetime", currentEvent.GetField<DateTime>(inputHeaderIndex, "card_transaction__detail__provider_datetime").ToString("yyyy-MM-dd HH:mm:ss.fff") },
            { "operation_amount", operationAmount },
            { "acquirer_message", currentEvent.GetField(inputHeaderIndex, "card_transaction__detail__acquirer_message") },
            { "acquirer_return_code", currentEvent.GetField(inputHeaderIndex, "card_transaction__detail__acquirer_return_code") },
            { "operation_reason", currentEvent.GetField(inputHeaderIndex, "card_transaction__detail__operation_reason") },
            { "acquirer", new Dictionary<string, object?>
                {
                    { "name", currentEvent.GetField(inputHeaderIndex, "card_transaction__detail__acquirer__name") },
                    { "nsu", currentEvent.GetField(inputHeaderIndex, "card_transaction__detail__acquirer__nsu") },
                    { "tid", currentEvent.GetField(inputHeaderIndex, "card_transaction__detail__acquirer__tid") }
                }
            },
            { "antifraud_response", new Dictionary<string, object?>
                {
                    { "provider_name", currentEvent.GetField(inputHeaderIndex, "card_transaction__detail__antifraud_response__provider_name") },
                    { "score", currentEvent.GetField(inputHeaderIndex, "card_transaction__detail__antifraud_response__score") },
                    { "status", currentEvent.GetField(inputHeaderIndex, "card_transaction__detail__antifraud_response__status") },
                }
            },
            { "gateway_response", new Dictionary<string, object?>
                {
                    { "code", currentEvent.GetField(inputHeaderIndex, "card_transaction__detail__gateway_response__code") },
                    { "message", currentEvent.GetField(inputHeaderIndex, "card_transaction__detail__gateway_response__message") },
                }
            },
            { "legacy", new Dictionary<string, object?>
                {
                    { "status", currentEvent.GetField(inputHeaderIndex, "card_transaction__detail__legacy__status") },
                    { "transaction_status", currentEvent.GetField(inputHeaderIndex, "card_transaction__detail__legacy__transaction_status") },
                    { "operation", currentEvent.GetField(inputHeaderIndex, "card_transaction__detail__legacy__operation") },
                    { "canceled_amount", currentEvent.GetField(inputHeaderIndex, "card_transaction__detail__legacy__canceled_amount") },
                    { "account_name", currentEvent.GetField(inputHeaderIndex, "card_transaction__detail__legacy__account_name") }
                }
            }
        };

        var currentChargeDetails = currentCharge.GetField(ChargeListReportHeader.HeaderIndex, "card_transaction__details");

        if (currentChargeDetails is List<Dictionary<string, object?>> details)
        {
            if (isChargeback)
            {
                // Search for existing operation with the same operation_id
                var existing = details.FirstOrDefault(d =>
                    d.TryGetValue("operation_id", out var existingId) &&
                    existingId?.ToString() == operationId);

                // If the operation already exists, update the amount
                if (existing != null)
                {
                    var existingAmount = existing.TryGetValue("operation_amount", out var amt) && amt != null ? Convert.ToInt32(amt) : 0;
                    existing["operation_amount"] = existingAmount + operationAmount;
                    return;
                }
            }

            // If the operation does not exist, add it to the list
            details.Add(detail);
            return;
        }

        // If the list does not exist, create a new one
        currentChargeDetails = new List<Dictionary<string, object?>> { detail };
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__details"], currentChargeDetails);
    }

    private static void AppendFees(CsvRow currentEvent, CsvRow currentCharge, Dictionary<string, int> inputHeaderIndex)
    {
        FinancialMovementAppendHelper.AppendFinancialMovements(currentEvent, currentCharge, inputHeaderIndex, "card_transaction");
    }

    private static bool HasFinancialMovementData(CsvRow currentEvent, Dictionary<string, int> inputHeaderIndex)
    {
        var discountRateAmount = currentEvent.GetField<Decimal?>(inputHeaderIndex, "card_transaction__financial_movement__amount__discount_rate__amount");
        var prepaymentAmount = currentEvent.GetField<Decimal?>(inputHeaderIndex, "card_transaction__financial_movement__amount__prepayment_fee__amount");
        var prepaymentTurboAmount = currentEvent.GetField<Decimal?>(inputHeaderIndex, "card_transaction__financial_movement__amount__prepayment_fee_turbo__amount");

        return discountRateAmount.HasValue || prepaymentAmount.HasValue || prepaymentTurboAmount.HasValue;
    }

    private static void InitializeFeeValues(CsvRow currentCharge, out decimal mdr, out decimal mdrRefund, out decimal rav, out decimal ravRefund, out decimal fc, out decimal fcRefund)
    {
        var mdrNullable = currentCharge.GetField<Decimal?>(ChargeListReportHeader.HeaderIndex, "card_transaction__full_mdr_amount");
        var mdrRefundNullable = currentCharge.GetField<Decimal?>(ChargeListReportHeader.HeaderIndex, "card_transaction__full_mdr_refund_amount");
        var ravNullable = currentCharge.GetField<Decimal?>(ChargeListReportHeader.HeaderIndex, "card_transaction__full_rav_amount");
        var ravRefundNullable = currentCharge.GetField<Decimal?>(ChargeListReportHeader.HeaderIndex, "card_transaction__full_rav_refund_amount");
        var fcNullable = currentCharge.GetField<Decimal?>(ChargeListReportHeader.HeaderIndex, "card_transaction__full_fc_amount");
        var fcRefundNullable = currentCharge.GetField<Decimal?>(ChargeListReportHeader.HeaderIndex, "card_transaction__full_fc_refund_amount");

        mdr = mdrNullable ?? 0;
        mdrRefund = mdrRefundNullable ?? 0;
        rav = ravNullable ?? 0;
        ravRefund = ravRefundNullable ?? 0;
        fc = fcNullable ?? 0;
        fcRefund = fcRefundNullable ?? 0;

        if (mdrNullable == null)
        {
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__full_mdr_amount"], 0);
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__mdr_amount"], 0);
        }
        if (mdrRefundNullable == null)
        {
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__full_mdr_refund_amount"], 0);
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__mdr_refund_amount"], 0);
        }
        if (ravNullable == null)
        {
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__full_rav_amount"], 0);
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__rav_amount"], 0);
        }
        if (ravRefundNullable == null)
        {
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__full_rav_refund_amount"], 0);
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__rav_refund_amount"], 0);
        }
        if (fcNullable == null)
        {
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__full_fc_amount"], 0);
        }
        if (fcRefundNullable == null)
        {
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__full_fc_refund_amount"], 0);
        }
    }

    private static void UpdateMdrValues(CsvRow currentCharge, decimal amount, ref decimal mdr, ref decimal mdrRefund)
    {
        if (amount < 0)
        {
            mdr += Math.Abs(amount);
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__full_mdr_amount"], mdr);
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__mdr_amount"], (int)Math.Round(mdr * 100));
        }
        else
        {
            mdrRefund += Math.Abs(amount);
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__full_mdr_refund_amount"], mdrRefund);
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__mdr_refund_amount"], (int)Math.Round(mdrRefund * 100));
        }
    }

    private static void UpdateRavValues(CsvRow currentCharge, decimal amount, ref decimal rav, ref decimal ravRefund)
    {
        if (amount < 0)
        {
            rav += Math.Abs(amount);
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__full_rav_amount"], rav);
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__rav_amount"], (int)Math.Round(rav * 100));
        }
        else
        {
            ravRefund += Math.Abs(amount);
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__full_rav_refund_amount"], ravRefund);
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__rav_refund_amount"], (int)Math.Round(ravRefund * 100));
        }
    }

    private static void UpdateFcValues(CsvRow currentCharge, decimal amount, ref decimal fc, ref decimal fcRefund)
    {
        if (amount < 0)
        {
            fc += Math.Abs(amount);
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__full_fc_amount"], fc);
        }
        else
        {
            fcRefund += Math.Abs(amount);
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__full_fc_refund_amount"], fcRefund);
        }
    }

    private static void UpdateFullFeeAmount(CsvRow currentCharge, decimal mdr, decimal mdrRefund, decimal rav, decimal ravRefund, decimal fc, decimal fcRefund)
    {
        var fullFee = (Math.Abs(mdr) - mdrRefund) + (Math.Abs(rav) - ravRefund) + (Math.Abs(fc) - fcRefund);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__full_fee_amount"], fullFee);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__fee_amount"], (int)Math.Round(fullFee * 100));
    }

    private static void ComputeFeesFromFinancialMovement(CsvRow currentEvent, CsvRow currentCharge, Dictionary<string, int> inputHeaderIndex)
    {
        InitializeFeeValues(currentCharge, out decimal mdr, out decimal mdrRefund, out decimal rav, out decimal ravRefund, out decimal fc, out decimal fcRefund);

        var discountRateAmount = currentEvent.GetField<Decimal?>(inputHeaderIndex, "card_transaction__financial_movement__amount__discount_rate__amount") ?? 0;
        if (discountRateAmount != 0)
        {
            UpdateMdrValues(currentCharge, discountRateAmount, ref mdr, ref mdrRefund);
        }

        var prepaymentAmount = currentEvent.GetField<Decimal?>(inputHeaderIndex, "card_transaction__financial_movement__amount__prepayment_fee__amount") ?? 0;
        if (prepaymentAmount != 0)
        {
            UpdateRavValues(currentCharge, prepaymentAmount, ref rav, ref ravRefund);
        }

        var fraudCoverageAmount = currentEvent.GetField<Decimal?>(inputHeaderIndex, "card_transaction__financial_movement__amount__fraud_coverage__amount") ?? 0;
        if (fraudCoverageAmount != 0)
        {
            UpdateFcValues(currentCharge, fraudCoverageAmount, ref fc, ref fcRefund);
        }

        var prepaymentTurboAmount = currentEvent.GetField<Decimal?>(inputHeaderIndex, "card_transaction__financial_movement__amount__prepayment_fee_turbo__amount") ?? 0;
        if (prepaymentTurboAmount != 0)
        {
            UpdateRavValues(currentCharge, prepaymentTurboAmount, ref rav, ref ravRefund);
        }

        UpdateFullFeeAmount(currentCharge, mdr, mdrRefund, rav, ravRefund, fc, fcRefund);
    }

    private static void ComputeFees(CsvRow currentEvent, CsvRow currentCharge, Dictionary<string, int> inputHeaderIndex)
    {
        if (HasFinancialMovementData(currentEvent, inputHeaderIndex))
        {
            ComputeFeesFromFinancialMovement(currentEvent, currentCharge, inputHeaderIndex);
        }
        else
        {
            ComputeFeesFromLegacyFee(currentEvent, currentCharge, inputHeaderIndex);
        }
    }

    private static void ComputeFeesFromLegacyFee(CsvRow currentEvent, CsvRow currentCharge, Dictionary<string, int> inputHeaderIndex)
    {
        var feeType = currentEvent.GetField<string>(inputHeaderIndex, "card_transaction__fee__type");
        var feeFullAmount = currentEvent.GetField<Decimal?>(inputHeaderIndex, "card_transaction__fee__full_amount") ?? 0;
        InitializeFeeValues(currentCharge, out decimal mdr, out decimal mdrRefund, out decimal rav, out decimal ravRefund, out decimal fc, out decimal fcRefund);

        if ((feeType == "discount_rate" && feeFullAmount < 0) || feeType == "service_fee")
        {
            mdr += Math.Abs(feeFullAmount);
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__full_mdr_amount"], mdr);
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__mdr_amount"], (int)Math.Round(mdr * 100));
        }
        else if ((feeType == "discount_rate" && feeFullAmount >= 0) || feeType == "service_fee_refund")
        {
            mdrRefund += Math.Abs(feeFullAmount);
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__full_mdr_refund_amount"], mdrRefund);
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__mdr_refund_amount"], (int)Math.Round(mdrRefund * 100));
        }
        else if (feeType == "prepayment_fee")
        {
            rav += Math.Abs(feeFullAmount);
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__full_rav_amount"], rav);
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__rav_amount"], (int)Math.Round(rav * 100));
        }
        else if (feeType == "prepayment_fee_refund")
        {
            ravRefund += Math.Abs(feeFullAmount);
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__full_rav_refund_amount"], ravRefund);
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__rav_refund_amount"], (int)Math.Round(ravRefund * 100));
        }

        UpdateFullFeeAmount(currentCharge, mdr, mdrRefund, rav, ravRefund, fc, fcRefund);
    }

    public static void ComputeAmounts(CsvRow currentCharge)
    {
        var organization = currentCharge.GetField<string>(ChargeListReportHeader.HeaderIndex, "merchant__organization");
        var detailsObj = currentCharge.GetField(ChargeListReportHeader.HeaderIndex, "card_transaction__details");
        if (detailsObj is not List<Dictionary<string, object?>> details)
            return;

        // Checks if there is at least one capture
        bool hasCapture = details.Any(d =>
            d.TryGetValue("operation", out var op) && op?.ToString() == "capture");

        // Acumulators
        int authorized = 0, captured = 0, canceled = 0, chargeback = 0, chargebackRefund = 0, failed = 0;

        foreach (var detail in details)
        {
            var operation = detail.TryGetValue("operation", out var op) ? op?.ToString() : null;
            var operationStatus = detail.TryGetValue("operation_status", out var opStatus) ? opStatus?.ToString() : null;
            var operationAmountStr = detail.TryGetValue("operation_amount", out var opAmount) ? opAmount?.ToString() : null;
            var operationAmount = operationAmountStr != null ? int.Parse(operationAmountStr) : 0;
            if (organization?.ToString() == "pagarme")
            {
                if (PagarmeHelper.IsNotCompletedOperation(operationStatus!))
                {
                    if (operation == "authorization" || operation == "pre_auth")
                        failed += operationAmount;
                    continue;
                }
                if (operation == "authorization" || operation == "pre_auth")
                    authorized += operationAmount;
                if (operation == "capture")
                {
                    captured += operationAmount;
                }
                if (operation == "auth_and_capture")
                {
                    authorized += operationAmount;
                    if (operationStatus != "waiting_capture")
                        captured += operationAmount;
                }
                if (operation == "cancel")
                    canceled += operationAmount;
                if (operation == "chargeback")
                    chargeback += operationAmount;
                if (operation == "chargeback_refund")
                    chargebackRefund += operationAmount;
            }
            else // Same Logic to Stone and Ton
            {
                // Fix auth_and_capture + capture scenario
                if (hasCapture && operation == "auth_and_capture")
                {
                    detail["operation"] = "authorization";
                    operation = "authorization";
                }

                var acquirerReturnCode = detail.TryGetValue("acquirer_return_code", out var arc) ? arc?.ToString() : null;
                var antifraudStatus = detail.TryGetValue("antifraud_response", out var afr) &&
                    afr is JsonElement afrElement &&
                    afrElement.TryGetProperty("status", out var statusElement) ?
                    statusElement.GetString() : null;

                bool isFailedOperation = (acquirerReturnCode != "0000" || antifraudStatus == "reproved") &&
                                       operation != "chargeback" && operation != "chargeback_refund";

                if (isFailedOperation)
                {
                    if (operation == "authorization")
                    {
                        // only add to failed amount the invalid authorization operation,
                        // other invalid operations are not considered for any amounts
                        failed += operationAmount;
                    }
                }
                else
                {
                    if (operation == "authorization")
                    {
                        var authState = currentCharge.GetField<string>(ChargeListReportHeader.HeaderIndex, "card_transaction__authorized_state");

                        if (authState == "None")
                        {
                            failed += operationAmount;
                        }
                        else
                        {
                            authorized += operationAmount;
                        }
                    }
                    else if (operation == "capture")
                    {
                        captured += operationAmount;
                    }
                    else if (operation == "auth_and_capture")
                    {
                        authorized += operationAmount;
                        captured += operationAmount;
                    }
                    else if (operation == "cancel")
                    {
                        canceled += operationAmount;
                    }
                    else if (operation == "chargeback")
                    {
                        chargeback += operationAmount;
                    }
                    else if (operation == "chargeback_refund")
                    {
                        chargebackRefund += operationAmount;
                    }
                }
            }
        }

        if (organization?.ToString() == "pagarme")
        {
            var cardTransactionType = currentCharge.GetField<string>(ChargeListReportHeader.HeaderIndex, "card_transaction__type");
            if (cardTransactionType == "debit" && authorized == 0)
            {
                authorized = captured;
            }
        }

        var updatedAmount = captured > 0 ? captured - canceled : authorized - canceled;

        if (chargeback > 0)
            updatedAmount = updatedAmount - chargeback + chargebackRefund;

        // Ensure amounts are not negative
        authorized = Math.Max(authorized, 0);
        captured = Math.Max(captured, 0);
        canceled = Math.Max(canceled, 0);
        chargeback = Math.Max(chargeback, 0);
        chargebackRefund = Math.Max(chargebackRefund, 0);
        updatedAmount = Math.Max(updatedAmount, 0);

        // Compute net amounts
        var fullFeeAmount = currentCharge.GetField<Decimal?>(ChargeListReportHeader.HeaderIndex, "card_transaction__full_fee_amount") ?? 0;
        var fullNetAmount = Math.Max((updatedAmount / 100m) - fullFeeAmount, 0);
        var netAmount = (int)Math.Round(fullNetAmount * 100);

        // Compute status
        var authorizedState = currentCharge.GetField<string>(ChargeListReportHeader.HeaderIndex, "card_transaction__authorized_state");
        var status = ComputeStatus(currentCharge, details, authorizedState, authorized, captured, canceled, chargeback, chargebackRefund, organization, "card");

        // Set fields
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["status"], status);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["net_amount"], netAmount);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["updated_amount"], updatedAmount);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["full_net_amount"], fullNetAmount);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__authorized_amount"], authorized);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__captured_amount"], captured);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__canceled_amount"], canceled);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__chargeback_amount"], chargeback);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__chargeback_refund_amount"], chargebackRefund);
    }

    private static string? ComputeStatus(
        CsvRow currentCharge,
        List<Dictionary<string, object?>> details,
        string? authorizedState,
        int authorizedAmount,
        int capturedAmount,
        int canceledAmount,
        int chargebackAmount,
        int chargebackRefundAmount,
        string? organization,
        string paymentMethod
    )
    {
        if (organization == "pagarme" && details != null)
        {
            // Get the last operation status from details
            var statusFromSource = PagarmeHelper.GetLastOperationStatus(details);

            if (string.IsNullOrEmpty(statusFromSource))
                return "failed";

            // Set last legacy status for Pagarme
            var legacyStatus = PagarmeHelper.GetLastLegacyStatus(details);
            if (!string.IsNullOrEmpty(legacyStatus))
                currentCharge.SetField(ChargeListReportHeader.HeaderIndex["card_transaction__last__legacy_status"], legacyStatus);

            return PagarmeHelper.GetStatus(statusFromSource, authorizedAmount, capturedAmount, paymentMethod);
        }

        // For Stone and Ton organizations
        bool hasOnlyInvalidOperation = false;
        if (details != null && details.Count > 0)
        {
            hasOnlyInvalidOperation = details.All(i =>
            {
                var acquirerReturnCode = i.TryGetValue("acquirer_return_code", out var code) ? code?.ToString() : null;
                var antifraudStatus = i.TryGetValue("antifraud_response", out var afr) &&
                    afr is JsonElement afrElement &&
                    afrElement.TryGetProperty("status", out var statusElement) ?
                    statusElement.GetString() : null;
                return (acquirerReturnCode != "0000" && acquirerReturnCode != "0") || antifraudStatus == "reproved";
            });
        }

        // Check if authorized state is invalid
        bool hasInvalidAuthorizedState = authorizedState == "None";

        string? status = null;
        if (authorizedAmount > 0)
            status = "authorized";

        if (capturedAmount > 0)
            status = "paid";

        if (canceledAmount > 0 && (canceledAmount == capturedAmount || canceledAmount == authorizedAmount))
            status = "canceled";

        if (chargebackAmount > 0 && (chargebackAmount == capturedAmount || chargebackAmount == authorizedAmount))
            status = "chargeback";

        if (chargebackRefundAmount > 0)
            status = "paid";

        if (hasOnlyInvalidOperation || hasInvalidAuthorizedState)
            status = "failed";

        return status;
    }
}

internal static class FinancialMovementAppendHelper
{
    public static void AppendFinancialMovements(
        CsvRow currentEvent,
        CsvRow currentCharge,
        Dictionary<string, int> inputHeaderIndex,
        string transactionPrefix)
    {
        var cutoff = new DateTime(2025, 4, 1);
        var currentEventDatetime = currentEvent.GetField<string>(inputHeaderIndex, "event_datetime");
        var createdAtStr = currentEvent.GetField<string>(inputHeaderIndex, "created_at");
        _ = DateTime.TryParse(createdAtStr, out DateTime createdAt);
        var listFieldName = $"{transactionPrefix}__financial_movements";
        var fieldPrefix = $"{transactionPrefix}__financial_movement__";

        // If the event is before the cutoff, do not add financial movements
        if (createdAt < cutoff)
        {
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex[listFieldName], new List<Dictionary<string, object?>>());
            return;
        }

        var discountRate = new Dictionary<string, object?>
        {
            ["fee_type"] = currentEvent.GetField<string>(inputHeaderIndex, $"{fieldPrefix}amount__discount_rate__fee_type"),
            ["fee"] = currentEvent.GetField<Decimal?>(inputHeaderIndex, $"{fieldPrefix}amount__discount_rate__fee"),
            ["effective_fee"] = currentEvent.GetField<Decimal?>(inputHeaderIndex, $"{fieldPrefix}amount__discount_rate__effective_fee"),
            ["amount"] = currentEvent.GetField<Decimal?>(inputHeaderIndex, $"{fieldPrefix}amount__discount_rate__amount")
        };

        var prepaymentFee = new Dictionary<string, object?>
        {
            ["fee_type"] = currentEvent.GetField<string>(inputHeaderIndex, $"{fieldPrefix}amount__prepayment_fee__fee_type"),
            ["fee"] = currentEvent.GetField<Decimal?>(inputHeaderIndex, $"{fieldPrefix}amount__prepayment_fee__fee"),
            ["effective_fee"] = currentEvent.GetField<Decimal?>(inputHeaderIndex, $"{fieldPrefix}amount__prepayment_fee__effective_fee"),
            ["amount"] = currentEvent.GetField<Decimal?>(inputHeaderIndex, $"{fieldPrefix}amount__prepayment_fee__amount")
        };

        var amountGross = currentEvent.GetField<Decimal?>(inputHeaderIndex, $"{fieldPrefix}amount__gross");
        var amountNet = currentEvent.GetField<Decimal?>(inputHeaderIndex, $"{fieldPrefix}amount__net");
        var operation = currentEvent.GetField<string>(inputHeaderIndex, $"{fieldPrefix}operation");
        var detailOperationId = currentEvent.GetField<string>(inputHeaderIndex, $"{fieldPrefix}detail_operation_id");
        var originalDueDate = currentEvent.GetField<string>(inputHeaderIndex, $"{fieldPrefix}original_due_date");
        var paymentOwnerDocument = currentEvent.GetField<string>(inputHeaderIndex, $"{fieldPrefix}payment_owner_document");
        var settlementStatus = currentEvent.GetField<string>(inputHeaderIndex, $"{fieldPrefix}settlement_status");
        var operationId = currentEvent.GetField<string>(inputHeaderIndex, $"{fieldPrefix}operation_id");
        var currentDueDate = currentEvent.GetField<string>(inputHeaderIndex, $"{fieldPrefix}current_due_date");

        if (string.IsNullOrEmpty(operationId) && !HasFinancialMovementData(currentEvent, inputHeaderIndex, fieldPrefix))
        {
            return;
        }

        if (currentCharge.GetField(ChargeListReportHeader.HeaderIndex, listFieldName) is not List<Dictionary<string, object?>> financialMovements)
        {
            financialMovements = [];
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex[listFieldName], financialMovements);
        }

        var existingFinMov = financialMovements.FirstOrDefault(mov =>
            mov.TryGetValue("operation_id", out var oid) && oid?.ToString() == operationId);

        if (existingFinMov != null)
        {
            var latestEventDateTimeStr = existingFinMov.TryGetValue("latest_event_datetime", out var dt) ? dt?.ToString() : null;
            _ = DateTime.TryParse(latestEventDateTimeStr, out var latestEventDateTime);
            _ = DateTime.TryParse(currentEventDatetime, out var currentEventDateTimeParsed);

            if (currentEventDateTimeParsed > latestEventDateTime)
            {
                var amount = existingFinMov["amount"] as Dictionary<string, object>;

                existingFinMov["current_due_date"] = currentDueDate;
                existingFinMov["latest_event_datetime"] = currentEventDatetime;

                if (operation != null)
                {
                    existingFinMov["operation"] = operation;
                }

                if (detailOperationId != null)
                {
                    existingFinMov["detail_operation_id"] = detailOperationId;
                }

                if (originalDueDate != null)
                {
                    existingFinMov["original_due_date"] = originalDueDate;
                }

                if (paymentOwnerDocument != null)
                {
                    existingFinMov["payment_owner_document"] = paymentOwnerDocument;
                }

                if (settlementStatus != null)
                {
                    existingFinMov["settlement_status"] = settlementStatus;
                }

                if (discountRate["fee_type"] != null)
                {
                    amount!["discount_rate"] = discountRate;
                }

                if (prepaymentFee["fee_type"] != null)
                {
                    amount!["prepayment_fee"] = prepaymentFee;
                }

                var prepaymentFeeTurboUpdate = new Dictionary<string, object?>
                {
                    ["fee_type"] = currentEvent.GetField<string>(inputHeaderIndex, $"{fieldPrefix}amount__prepayment_fee_turbo__fee_type"),
                    ["fee"] = currentEvent.GetField<Decimal?>(inputHeaderIndex, $"{fieldPrefix}amount__prepayment_fee_turbo__fee"),
                    ["effective_fee"] = currentEvent.GetField<Decimal?>(inputHeaderIndex, $"{fieldPrefix}amount__prepayment_fee_turbo__effective_fee"),
                    ["amount"] = currentEvent.GetField<Decimal?>(inputHeaderIndex, $"{fieldPrefix}amount__prepayment_fee_turbo__amount")
                };

                if (prepaymentFeeTurboUpdate["fee_type"] != null || prepaymentFeeTurboUpdate["amount"] != null)
                {
                    amount!["prepayment_fee_turbo"] = prepaymentFeeTurboUpdate;
                }

                if (amountGross != null)
                {
                    amount!["gross"] = amountGross;
                }

                if (amountNet != null)
                {
                    amount!["net"] = amountNet;
                }
            }
        }
        else
        {
            var category = currentEvent.GetField<string>(inputHeaderIndex, $"{fieldPrefix}category");
            var installmentNumber = currentEvent.GetField<int?>(inputHeaderIndex, $"{fieldPrefix}installment_number") ?? 1;

            var fraudCoverage = new Dictionary<string, object?>
            {
                ["fee_type"] = currentEvent.GetField<string>(inputHeaderIndex, $"{fieldPrefix}amount__fraud_coverage__fee_type"),
                ["fee"] = currentEvent.GetField<Decimal?>(inputHeaderIndex, $"{fieldPrefix}amount__fraud_coverage__fee"),
                ["effective_fee"] = currentEvent.GetField<Decimal?>(inputHeaderIndex, $"{fieldPrefix}amount__fraud_coverage__effective_fee"),
                ["amount"] = currentEvent.GetField<Decimal?>(inputHeaderIndex, $"{fieldPrefix}amount__fraud_coverage__amount")
            };

            var prepaymentFeeTurbo = new Dictionary<string, object?>
            {
                ["fee_type"] = currentEvent.GetField<string>(inputHeaderIndex, $"{fieldPrefix}amount__prepayment_fee_turbo__fee_type"),
                ["fee"] = currentEvent.GetField<Decimal?>(inputHeaderIndex, $"{fieldPrefix}amount__prepayment_fee_turbo__fee"),
                ["effective_fee"] = currentEvent.GetField<Decimal?>(inputHeaderIndex, $"{fieldPrefix}amount__prepayment_fee_turbo__effective_fee"),
                ["amount"] = currentEvent.GetField<Decimal?>(inputHeaderIndex, $"{fieldPrefix}amount__prepayment_fee_turbo__amount")
            };

            var amountObj = new Dictionary<string, object>
            {
                ["discount_rate"] = discountRate!,
                ["prepayment_fee"] = prepaymentFee!,
                ["fraud_coverage"] = fraudCoverage!
            };

            if (prepaymentFeeTurbo["fee_type"] != null || prepaymentFeeTurbo["amount"] != null)
            {
                amountObj["prepayment_fee_turbo"] = prepaymentFeeTurbo!;
            }

            if (amountGross != null)
            {
                amountObj["gross"] = amountGross;
            }

            if (amountNet != null)
            {
                amountObj["net"] = amountNet;
            }

            var newMovement = new Dictionary<string, object?>
            {
                ["operation"] = operation,
                ["operation_id"] = operationId,
                ["detail_operation_id"] = detailOperationId,
                ["current_due_date"] = currentDueDate,
                ["original_due_date"] = originalDueDate,
                ["payment_owner_document"] = paymentOwnerDocument,
                ["settlement_status"] = settlementStatus,
                ["category"] = category,
                ["installment_number"] = installmentNumber,
                ["amount"] = amountObj,
                ["latest_event_datetime"] = currentEventDatetime
            };

            newMovement["payment_owner_stone_account"] = currentEvent.GetField<string>(inputHeaderIndex, $"{fieldPrefix}payment_owner_stone_account");
            newMovement["payment_owner_id"] = currentEvent.GetField<string>(inputHeaderIndex, $"{fieldPrefix}payment_owner_id");
            newMovement["payment_method"] = currentEvent.GetField<string>(inputHeaderIndex, $"{fieldPrefix}payment_method");
            newMovement["bulk_anticipation_id"] = currentEvent.GetField<string>(inputHeaderIndex, $"{fieldPrefix}bulk_anticipation_id");
            newMovement["recipient_id"] = currentEvent.GetField<string>(inputHeaderIndex, $"{fieldPrefix}recipient_id");
            newMovement["split_rule_id"] = currentEvent.GetField<string>(inputHeaderIndex, $"{fieldPrefix}split_rule_id");
            newMovement["id"] = currentEvent.GetField<string>(inputHeaderIndex, $"{fieldPrefix}id");
            newMovement["created_at"] = currentEvent.GetField<string>(inputHeaderIndex, $"{fieldPrefix}created_at");
            financialMovements.Add(newMovement);
        }
    }

    private static bool HasFinancialMovementData(CsvRow currentEvent, Dictionary<string, int> inputHeaderIndex, string fieldPrefix)
    {
        var discountRateAmount = currentEvent.GetField<Decimal?>(inputHeaderIndex, $"{fieldPrefix}amount__discount_rate__amount");
        var prepaymentAmount = currentEvent.GetField<Decimal?>(inputHeaderIndex, $"{fieldPrefix}amount__prepayment_fee__amount");
        var prepaymentTurboAmount = currentEvent.GetField<Decimal?>(inputHeaderIndex, $"{fieldPrefix}amount__prepayment_fee_turbo__amount");
        var fraudCoverageAmount = currentEvent.GetField<Decimal?>(inputHeaderIndex, $"{fieldPrefix}amount__fraud_coverage__amount");
        var grossAmount = currentEvent.GetField<Decimal?>(inputHeaderIndex, $"{fieldPrefix}amount__gross");
        var netAmount = currentEvent.GetField<Decimal?>(inputHeaderIndex, $"{fieldPrefix}amount__net");

        return discountRateAmount.HasValue || prepaymentAmount.HasValue || prepaymentTurboAmount.HasValue || fraudCoverageAmount.HasValue || grossAmount.HasValue || netAmount.HasValue;
    }
}

internal static class FinancialMovementFeeHelper
{
    public static void ComputeFeesFromFinancialMovements(
        CsvRow currentCharge,
        string financialMovementsFieldName,
        string transactionPrefix)
    {
        var financialMovementsObj = currentCharge.GetField(ChargeListReportHeader.HeaderIndex, financialMovementsFieldName);
        if (financialMovementsObj is not List<Dictionary<string, object?>> financialMovements)
            return;

        decimal fullMdrAmount = 0;
        decimal fullMdrRefundAmount = 0;
        decimal fullRavAmount = 0;
        decimal fullRavRefundAmount = 0;
        decimal fullFcAmount = 0;
        decimal fullFcRefundAmount = 0;

        foreach (var finMov in financialMovements)
        {
            var category = finMov.TryGetValue("category", out var cat) ? cat?.ToString() : null;
            var amountObj = finMov.TryGetValue("amount", out var amt) ? amt as Dictionary<string, object> : null;

            if (amountObj == null) continue;

            var discountRateObj = amountObj.TryGetValue("discount_rate", out var dr) ? dr as Dictionary<string, object> : null;
            var prepaymentFeeObj = amountObj.TryGetValue("prepayment_fee", out var pf) ? pf as Dictionary<string, object> : null;
            var fraudCoverageObj = amountObj.TryGetValue("fraud_coverage", out var fc) ? fc as Dictionary<string, object> : null;
            var prepaymentFeeTurboObj = amountObj.TryGetValue("prepayment_fee_turbo", out var pft) ? pft as Dictionary<string, object> : null;

            decimal discountRate = 0;
            decimal prepaymentFee = 0;
            decimal prepaymentFeeTurbo = 0;
            decimal fraudFee = 0;

            if (discountRateObj != null && discountRateObj.TryGetValue("amount", out var drAmount) && drAmount != null)
            {
                discountRate = Convert.ToDecimal(drAmount);
            }

            if (prepaymentFeeObj != null && prepaymentFeeObj.TryGetValue("amount", out var pfAmount) && pfAmount != null)
            {
                prepaymentFee = Convert.ToDecimal(pfAmount);
            }

            if (prepaymentFeeTurboObj != null && prepaymentFeeTurboObj.TryGetValue("amount", out var pftAmount) && pftAmount != null)
            {
                prepaymentFeeTurbo = Convert.ToDecimal(pftAmount);
            }

            if (fraudCoverageObj != null && fraudCoverageObj.TryGetValue("amount", out var fcAmount) && fcAmount != null)
            {
                fraudFee = Convert.ToDecimal(fcAmount);
            }

            // Based on category, accumulate in the appropriate variables
            if (category == "sale")
            {
                fullMdrAmount += discountRate;
                fullRavAmount += prepaymentFee;
                fullRavAmount += prepaymentFeeTurbo;
                fullFcAmount += fraudFee;
            }
            else if (category == "reversal" || category == "partial_reversal")
            {
                fullMdrRefundAmount += discountRate;
                fullRavRefundAmount += prepaymentFee;
                fullRavRefundAmount += prepaymentFeeTurbo;
                fullFcRefundAmount += fraudFee;
            }
            else if (category == "refund_reversal")
            {
                fullMdrAmount += discountRate;
                fullRavAmount += prepaymentFee;
                fullRavAmount += prepaymentFeeTurbo;
                fullFcAmount += fraudFee;
            }
        }

        var absFullMdrAmount = Math.Abs(fullMdrAmount);
        var absFullRavAmount = Math.Abs(fullRavAmount);
        var absFullFcAmount = Math.Abs(fullFcAmount);
        var consolidatedFullMdrAmount = absFullMdrAmount - fullMdrRefundAmount;
        var consolidatedFullRavAmount = absFullRavAmount - fullRavRefundAmount;
        var consolidatedFullFcAmount = absFullFcAmount - fullFcRefundAmount;
        var fullFeeAmount = consolidatedFullMdrAmount + consolidatedFullRavAmount + consolidatedFullFcAmount;

        currentCharge.SetField(ChargeListReportHeader.HeaderIndex[$"{transactionPrefix}__full_fee_amount"], fullFeeAmount);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex[$"{transactionPrefix}__full_mdr_amount"], absFullMdrAmount);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex[$"{transactionPrefix}__full_mdr_refund_amount"], fullMdrRefundAmount);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex[$"{transactionPrefix}__full_rav_amount"], absFullRavAmount);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex[$"{transactionPrefix}__full_rav_refund_amount"], fullRavRefundAmount);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex[$"{transactionPrefix}__full_fc_amount"], absFullFcAmount);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex[$"{transactionPrefix}__full_fc_refund_amount"], fullFcRefundAmount);
    }
}

public static class BoletoProcessor
{
    public static void Process(CsvRow currentEvent, CsvRow currentCharge, Dictionary<string, int> inputHeaderIndex)
    {
        SetFields(currentEvent, currentCharge, inputHeaderIndex);
        AppendDetails(currentEvent, currentCharge, inputHeaderIndex);
        FinancialMovementAppendHelper.AppendFinancialMovements(currentEvent, currentCharge, inputHeaderIndex, "boleto_transaction");
        ComputeFeesFromFinancialMovements(currentCharge);
    }

    private static void SetFields(CsvRow currentEvent, CsvRow currentCharge, Dictionary<string, int> inputHeaderIndex)
    {
        var asIsFields = new[]
        {
            "id",
            "initiator_id",
            "platform_name",
            "attempt_count",
            "product",
            "charge_id",
            "origin",
            "origin_id",
            "amount",
            "payment_method",
            "point_of_interaction_type",
            "all_ids",
            "code",
            "status",
            "gateway",
            "gateway_order_id",
            "split",
            "metadata",
            "merchant__organization",
            "merchant__user_id",
            "merchant__document",
            "merchant__affiliation_key",
            "merchant__affiliation_code",
            "merchant__account_id",
            "merchant__merchant_id",
            "merchant__stone_account",
            "merchant__payment_profile_id",
            "boleto_transaction__type",
            "boleto_transaction__transaction_id",
            "boleto_transaction__our_number",
            "boleto_transaction__fee_amount",
            "boleto_transaction__fine_amount",
            "boleto_transaction__interest_amount",
            "boleto_transaction__discount_amount",
            "boleto_transaction__expire_at",
            "boleto_transaction__limit_date",
            "boleto_transaction__barcode",
            "boleto_transaction__writable_line",
            "boleto_transaction__instructions",
            "boleto_transaction__url",
            "boleto_transaction__paid_at",
            "boleto_transaction__last__operation_status",
            "boleto_transaction__last__legacy_status",
            "boleto_transaction__bank__code",
            "boleto_transaction__bank__name",
            "boleto_transaction__receiver__name",
            "boleto_transaction__receiver__document_type",
            "boleto_transaction__receiver__document",
            "boleto_transaction__customer__name",
            "boleto_transaction__customer__customer_id",
            "boleto_transaction__customer__document_type",
            "boleto_transaction__customer__document",
            "boleto_transaction__customer__email",
            "boleto_transaction__customer__address__street",
            "boleto_transaction__customer__address__street_number",
            "boleto_transaction__customer__address__extra",
            "boleto_transaction__customer__address__neighborhood",
            "boleto_transaction__customer__address__postal_code",
            "boleto_transaction__customer__address__city",
            "boleto_transaction__customer__address__state",
            "boleto_transaction__customer__address__country",
            "boleto_transaction__fine__start_at",
            "boleto_transaction__fine__type",
            "boleto_transaction__fine__value",
            "boleto_transaction__interest__start_at",
            "boleto_transaction__interest__type",
            "boleto_transaction__interest__value",
            "boleto_transaction__discounts",
        };

        foreach (var field in asIsFields)
        {
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex[field], currentEvent.GetField(inputHeaderIndex, field));
        }

        var createdAt = currentEvent.GetField<DateTime?>(inputHeaderIndex, "created_at");
        if (createdAt != default && createdAt.HasValue)
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["created_at"], createdAt.Value.ToString("yyyy-MM-ddTHH:mm:ss.fffK"));
    }

    private static void AppendDetails(CsvRow currentEvent, CsvRow currentCharge, Dictionary<string, int> inputHeaderIndex)
    {
        var operation = currentEvent.GetField(inputHeaderIndex, "boleto_transaction__detail__operation");

        // There are boleto events with no detail data
        if (operation == null)
            return;

        var detail = new Dictionary<string, object?>
        {
            { "pgid", currentEvent.GetField<string>(inputHeaderIndex, "boleto_transaction__detail__pgid") },
            { "operation_status", currentEvent.GetField<string>(inputHeaderIndex, "boleto_transaction__detail__operation_status") },
            { "operation", operation },
            { "operation_id", currentEvent.GetField<string>(inputHeaderIndex, "boleto_transaction__detail__operation_id") },
            { "local_datetime", currentEvent.GetField(inputHeaderIndex, "boleto_transaction__detail__local_datetime") },
            { "provider_datetime", currentEvent.GetField<DateTime>(inputHeaderIndex, "boleto_transaction__detail__provider_datetime").ToString("yyyy-MM-dd HH:mm:ss.fff") },
            { "operation_amount", currentEvent.GetField<int?>(inputHeaderIndex, "boleto_transaction__detail__operation_amount") },
            { "reason", currentEvent.GetField(inputHeaderIndex, "boleto_transaction__detail__reason") },
            { "gateway_response", new Dictionary<string, object?>
                {
                    { "code", currentEvent.GetField(inputHeaderIndex, "boleto_transaction__detail__gateway_response__code") },
                    { "message", currentEvent.GetField(inputHeaderIndex, "boleto_transaction__detail__gateway_response__message") },
                }
            },
            { "legacy", new Dictionary<string, object?>
                {
                    { "status", currentEvent.GetField(inputHeaderIndex, "boleto_transaction__detail__legacy__status") },
                    { "transaction_status", currentEvent.GetField(inputHeaderIndex, "boleto_transaction__detail__legacy__transaction_status") },
                    { "operation", currentEvent.GetField(inputHeaderIndex, "boleto_transaction__detail__legacy__operation") },
                    { "canceled_amount", currentEvent.GetField(inputHeaderIndex, "boleto_transaction__detail__legacy__canceled_amount") },
                    { "account_name", currentEvent.GetField(inputHeaderIndex, "boleto_transaction__detail__legacy__account_name") }
                }
            }
        };

        var currentChargeDetails = currentCharge.GetField(ChargeListReportHeader.HeaderIndex, "boleto_transaction__details");

        if (currentChargeDetails is List<Dictionary<string, object?>> details)
        {
            details.Add(detail);
            return;
        }

        // If the list does not exist, create a new one
        currentChargeDetails = new List<Dictionary<string, object?>> { detail };
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["boleto_transaction__details"], currentChargeDetails);
    }

    private static void ComputeFeesFromFinancialMovements(CsvRow currentCharge)
    {
        FinancialMovementFeeHelper.ComputeFeesFromFinancialMovements(
            currentCharge,
            "boleto_transaction__financial_movements",
            "boleto_transaction"
        );
    }

    public static void ComputeAmounts(CsvRow currentCharge)
    {
        var organization = currentCharge.GetField<string>(ChargeListReportHeader.HeaderIndex, "merchant__organization");
        var detailsObj = currentCharge.GetField(ChargeListReportHeader.HeaderIndex, "boleto_transaction__details");
        if (detailsObj is not List<Dictionary<string, object?>> details)
            return;

        // Acumulators
        int paid = 0, canceled = 0;

        foreach (var detail in details)
        {
            var operation = detail.TryGetValue("operation", out var op) ? op?.ToString() : null;
            var operationAmountStr = detail.TryGetValue("operation_amount", out var opAmount) ? opAmount?.ToString() : null;
            var operationAmount = operationAmountStr != null ? int.Parse(operationAmountStr) : 0;

            if (organization == "pagarme")
            {
                if (PagarmeHelper.IsNotCompletedOperation(operation!))
                {
                    continue;
                }

                if (operation == "pay")
                {
                    paid += operationAmount;
                }
                else if (operation == "cancel")
                {
                    canceled += operationAmount;
                }
            }
            else
            {
                switch (operation)
                {
                    case "pay":
                        paid += operationAmount;
                        break;
                    case "cancel":
                        canceled += operationAmount;
                        break;
                }
            }
        }

        var updatedAmount = paid > 0 ? paid - canceled : 0;

        // Ensure amounts are not negative
        updatedAmount = Math.Max(updatedAmount, 0);

        // Compute net amounts using full_fee_amount if available, otherwise use fee_amount
        var fullFeeAmount = currentCharge.GetField<Decimal?>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__full_fee_amount");
        var feeAmount = currentCharge.GetField<Decimal?>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__fee_amount") ?? 0;
        var feeToUse = fullFeeAmount ?? (feeAmount / 100m);
        var fullNetAmount = Math.Max((updatedAmount / 100m) - feeToUse, 0);
        var netAmount = (int)Math.Round(fullNetAmount * 100);

        // Compute status
        var amount = currentCharge.GetField<int?>(ChargeListReportHeader.HeaderIndex, "amount") ?? 0;
        var ourNumber = currentCharge.GetField<string>(ChargeListReportHeader.HeaderIndex, "boleto_transaction__our_number");
        var status = ComputeStatus(currentCharge, amount, paid, canceled, ourNumber, organization, details);

        // Set fields
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["status"], status);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["net_amount"], netAmount);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["updated_amount"], updatedAmount);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["full_net_amount"], fullNetAmount);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["boleto_transaction__paid_amount"], paid);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["boleto_transaction__canceled_amount"], canceled);
    }

    private static string? ComputeStatus(CsvRow currentCharge, int amount, int paidAmount, int canceledAmount, string? ourNumber, string? organization, List<Dictionary<string, object?>>? details = null)
    {
        string? status = null;
        if (organization == "pagarme" && details != null)
        {
            // Get the last operation status from details
            var statusFromSource = PagarmeHelper.GetLastOperationStatus(details);

            if (string.IsNullOrEmpty(statusFromSource))
                return "failed";

            // Set last legacy status for Pagarme
            var legacyStatus = PagarmeHelper.GetLastLegacyStatus(details);
            if (!string.IsNullOrEmpty(legacyStatus))
                currentCharge.SetField(ChargeListReportHeader.HeaderIndex["boleto_transaction__last__legacy_status"], legacyStatus);

            return PagarmeHelper.GetStatus(statusFromSource, paidAmount, canceledAmount, "boleto");
        }

        // For Stone and Ton organizations
        // It needs to have our number and a valid amount to define status, this is because of parcial boleto events from Ton
        if (amount == 0 || ourNumber == null)
            return null;

        if (paidAmount == 0)
            status = "created";

        if (paidAmount > 0)
            status = "paid";

        if ((canceledAmount > 0 && canceledAmount == paidAmount) || (canceledAmount > 0 && paidAmount == 0))
            status = "canceled";

        return status;
    }
}

public static class PixProcessor
{
    public static void Process(CsvRow currentEvent, CsvRow currentCharge, Dictionary<string, int> inputHeaderIndex)
    {
        SetFields(currentEvent, currentCharge, inputHeaderIndex);
        AppendDetails(currentEvent, currentCharge, inputHeaderIndex);
        FinancialMovementAppendHelper.AppendFinancialMovements(currentEvent, currentCharge, inputHeaderIndex, "pix_transaction");
        ComputeFeesFromFinancialMovements(currentCharge);
    }

    private static void SetFields(CsvRow currentEvent, CsvRow currentCharge, Dictionary<string, int> inputHeaderIndex)
    {
        var asIsFields = new[]
        {
            "id",
            "initiator_id",
            "platform_name",
            "attempt_count",
            "product",
            "charge_id",
            "origin",
            "origin_id",
            "amount",
            "payment_method",
            "point_of_interaction_type",
            "all_ids",
            "code",
            "status",
            "gateway",
            "gateway_order_id",
            "split",
            "metadata",
            "merchant__organization",
            "merchant__user_id",
            "merchant__document",
            "merchant__affiliation_key",
            "merchant__affiliation_code",
            "merchant__account_id",
            "merchant__merchant_id",
            "merchant__stone_account",
            "merchant__payment_profile_id",
            "pix_transaction__type",
            "pix_transaction__transaction_id",
            "pix_transaction__e2e_id",
            "pix_transaction__pix_key",
            "pix_transaction__is_pix_sale_key",
            "pix_transaction__pix_key_nickname",
            "pix_transaction__fee_amount",
            "pix_transaction__expire_at",
            "pix_transaction__payment_limit_period_days",
            "pix_transaction__business_days_only",
            "pix_transaction__expires_in",
            "pix_transaction__request_for_payer",
            "pix_transaction__fine__start_at",
            "pix_transaction__fine__type",
            "pix_transaction__fine__value",
            "pix_transaction__interest__start_at",
            "pix_transaction__interest__type",
            "pix_transaction__interest__value",
            "pix_transaction__interest__period",
            "pix_transaction__reduction__start_at",
            "pix_transaction__reduction__value",
            "pix_transaction__customer__email",
            "pix_transaction__customer__name",
            "pix_transaction__customer__document",
            "pix_transaction__customer__document_type",
            "pix_transaction__customer__customer_id",
            "pix_transaction__customer__address__country",
            "pix_transaction__customer__address__city",
            "pix_transaction__customer__address__street",
            "pix_transaction__customer__address__extra",
            "pix_transaction__customer__address__street_number",
            "pix_transaction__customer__address__neighborhood",
            "pix_transaction__customer__address__state",
            "pix_transaction__customer__address__postal_code",
            "pix_transaction__details",
            "pix_transaction__payer__name",
            "pix_transaction__payer__document_type",
            "pix_transaction__payer__document",
            "pix_transaction__payer__ispb",
            "pix_transaction__payer__institution_name",
            "pix_transaction__additional_data",
            "pix_transaction__last__operation_status",
            "pix_transaction__last__legacy_status",
            "pix_transaction__terminal__type",
            "pix_transaction__terminal__serial_number",
        };

        foreach (var field in asIsFields)
        {
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex[field], currentEvent.GetField(inputHeaderIndex, field));
        }

        var createdAt = currentEvent.GetField<DateTime?>(inputHeaderIndex, "created_at");
        if (createdAt != default && createdAt.HasValue)
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["created_at"], createdAt.Value.ToString("yyyy-MM-ddTHH:mm:ss.fffK"));
    }

    private static void AppendDetails(CsvRow currentEvent, CsvRow currentCharge, Dictionary<string, int> inputHeaderIndex)
    {
        var operation = currentEvent.GetField(inputHeaderIndex, "pix_transaction__detail__operation");

        // There are pix events with no detail data
        if (operation == null)
            return;

        var detail = new Dictionary<string, object?>
        {
            { "operation_pgid", currentEvent.GetField(inputHeaderIndex, "pix_transaction__detail__operation_pgid") },
            { "operation", operation },
            { "operation_status", currentEvent.GetField(inputHeaderIndex, "pix_transaction__detail__operation_status") },
            { "operation_id", currentEvent.GetField(inputHeaderIndex, "pix_transaction__detail__operation_id") },
            { "local_datetime", currentEvent.GetField(inputHeaderIndex, "pix_transaction__detail__local_datetime") },
            { "provider_datetime", currentEvent.GetField<DateTime>(inputHeaderIndex, "pix_transaction__detail__provider_datetime").ToString("yyyy-MM-dd HH:mm:ss.fff") },
            { "operation_amount", currentEvent.GetField(inputHeaderIndex, "pix_transaction__detail__operation_amount") },
            { "qrcode_content", currentEvent.GetField(inputHeaderIndex, "pix_transaction__detail__qrcode_content") },
            { "description", currentEvent.GetField(inputHeaderIndex, "pix_transaction__detail__description") },
            { "refund_id", currentEvent.GetField(inputHeaderIndex, "pix_transaction__detail__refund_id") },
            { "reason", currentEvent.GetField(inputHeaderIndex, "pix_transaction__detail__reason") },
            { "gateway_response", new Dictionary<string, object?>
                {
                    { "code", currentEvent.GetField(inputHeaderIndex, "pix_transaction__detail__gateway_response__code") },
                    { "message", currentEvent.GetField(inputHeaderIndex, "pix_transaction__detail__gateway_response__message") },
                }
            },
            { "legacy", new Dictionary<string, object?>
                {
                    { "status", currentEvent.GetField(inputHeaderIndex, "pix_transaction__detail__legacy__status") },
                    { "transaction_status", currentEvent.GetField(inputHeaderIndex, "pix_transaction__detail__legacy__transaction_status") },
                    { "operation", currentEvent.GetField(inputHeaderIndex, "pix_transaction__detail__legacy__operation") },
                    { "canceled_amount", currentEvent.GetField(inputHeaderIndex, "pix_transaction__detail__legacy__canceled_amount") },
                    { "account_name", currentEvent.GetField(inputHeaderIndex, "pix_transaction__detail__legacy__account_name") }
                }
            }
        };

        var currentChargeDetails = currentCharge.GetField(ChargeListReportHeader.HeaderIndex, "pix_transaction__details");

        if (currentChargeDetails is List<Dictionary<string, object?>> details)
        {
            details.Add(detail);
            return;
        }

        // If the list does not exist, create a new one
        currentChargeDetails = new List<Dictionary<string, object?>> { detail };
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["pix_transaction__details"], currentChargeDetails);
    }

    private static void ComputeFeesFromFinancialMovements(CsvRow currentCharge)
    {
        FinancialMovementFeeHelper.ComputeFeesFromFinancialMovements(
            currentCharge,
            "pix_transaction__financial_movements",
            "pix_transaction"
        );
    }

    public static void ComputeAmounts(CsvRow currentCharge)
    {
        var detailsObj = currentCharge.GetField(ChargeListReportHeader.HeaderIndex, "pix_transaction__details");
        if (detailsObj is not List<Dictionary<string, object?>> details)
            return;

        var organization = currentCharge.GetField<string>(ChargeListReportHeader.HeaderIndex, "merchant__organization");

        // Acumulators
        int paid = 0, canceled = 0;

        foreach (var detail in details)
        {
            var operation = detail.TryGetValue("operation", out var op) ? op?.ToString() : null;
            var operationAmountStr = detail.TryGetValue("operation_amount", out var opAmount) ? opAmount?.ToString() : null;
            var operationAmount = operationAmountStr != null ? int.Parse(operationAmountStr) : 0;

            if (organization == "pagarme")
            {
                if (PagarmeHelper.IsNotCompletedOperation(operation!))
                {
                    continue;
                }

                if (operation == "pay")
                {
                    paid += operationAmount;
                }
                else if (operation == "cancel")
                {
                    canceled += operationAmount;
                }
            }
            else
            {
                if (operation == "pay")
                {
                    paid += operationAmount;
                }
                else if (operation == "cancel")
                {
                    canceled += operationAmount;
                }
            }
        }

        var updatedAmount = paid > 0 ? paid - canceled : 0;

        // Ensure amounts are not negative
        updatedAmount = Math.Max(updatedAmount, 0);

        // Compute net amounts using full_fee_amount if available, otherwise use fee_amount
        var fullFeeAmount = currentCharge.GetField<Decimal?>(ChargeListReportHeader.HeaderIndex, "pix_transaction__full_fee_amount");
        var feeAmount = currentCharge.GetField<decimal?>(ChargeListReportHeader.HeaderIndex, "pix_transaction__fee_amount") ?? 0m;
        var feeToUse = fullFeeAmount ?? (feeAmount / 100m);
        var fullNetAmount = Math.Max((updatedAmount / 100m) - feeToUse, 0);

        // Ensure amounts are not negative
        updatedAmount = Math.Max(updatedAmount, 0);
        fullNetAmount = Math.Max(fullNetAmount, 0);

        // Set fields
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["pix_transaction__paid_amount"], paid);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["pix_transaction__canceled_amount"], canceled);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["full_net_amount"], fullNetAmount);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["updated_amount"], updatedAmount);

        // Set status
        var status = ComputeStatus(currentCharge, paid, canceled, organization, details);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["status"], status);

        // Set net amount (converted back to cents)
        var netAmount = (int)Math.Round(fullNetAmount * 100);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["net_amount"], netAmount);
    }

    private static string? ComputeStatus(CsvRow currentCharge, int paidAmount, int canceledAmount, string? organization, List<Dictionary<string, object?>>? details = null)
    {
        string? status = null;

        if (organization == "pagarme" && details != null)
        {
            // Get the last operation status from details
            var statusFromSource = PagarmeHelper.GetLastOperationStatus(details);

            if (string.IsNullOrEmpty(statusFromSource))
                return "failed";

            // Set last legacy status for Pagarme
            var legacyStatus = PagarmeHelper.GetLastLegacyStatus(details);
            if (!string.IsNullOrEmpty(legacyStatus))
                currentCharge.SetField(ChargeListReportHeader.HeaderIndex["pix_transaction__last__legacy_status"], legacyStatus);

            return PagarmeHelper.GetStatus(statusFromSource, paidAmount, canceledAmount, "pix");
        }

        // For Stone and Ton organizations
        if (paidAmount == 0 && canceledAmount == 0)
            status = "created";

        if (paidAmount > 0)
            status = "paid";

        if ((canceledAmount > 0 && canceledAmount == paidAmount) || (canceledAmount > 0 && paidAmount == 0))
            status = "canceled";

        return status;
    }
}

public static class CashProcessor
{
    public static void Process(CsvRow currentEvent, CsvRow currentCharge, Dictionary<string, int> inputHeaderIndex)
    {
        SetFields(currentEvent, currentCharge, inputHeaderIndex);
        AppendDetails(currentEvent, currentCharge, inputHeaderIndex);
    }

    private static void SetFields(CsvRow currentEvent, CsvRow currentCharge, Dictionary<string, int> inputHeaderIndex)
    {
        var asIsFields = new[]
        {
            "id",
            "initiator_id",
            "platform_name",
            "attempt_count",
            "product",
            "charge_id",
            "origin",
            "origin_id",
            "amount",
            "payment_method",
            "point_of_interaction_type",
            "all_ids",
            "code",
            "status",
            "gateway",
            "gateway_order_id",
            "split",
            "metadata",
            "merchant__organization",
            "merchant__user_id",
            "merchant__document",
            "merchant__affiliation_key",
            "merchant__affiliation_code",
            "merchant__account_id",
            "merchant__merchant_id",
            "merchant__stone_account",
            "merchant__payment_profile_id",
            "cash_transaction__description",
            "cash_transaction__transaction_id",
            "cash_transaction__paid_amount",
            "cash_transaction__canceled_amount",
            "cash_transaction__customer__name",
            "cash_transaction__customer__customer_id",
            "cash_transaction__customer__document_type",
            "cash_transaction__customer__document",
            "cash_transaction__customer__email",
            "cash_transaction__customer__address__country",
            "cash_transaction__customer__address__city",
            "cash_transaction__customer__address__street",
            "cash_transaction__customer__address__extra",
            "cash_transaction__customer__address__street_number",
            "cash_transaction__customer__address__neighborhood",
            "cash_transaction__customer__address__state",
            "cash_transaction__customer__address__postal_code",
            "cash_transaction__last__operation_status",
            "cash_transaction__last__legacy_status",
            "cash_transaction__details"
        };

        foreach (var field in asIsFields)
        {
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex[field], currentEvent.GetField(inputHeaderIndex, field));
        }

        var createdAt = currentEvent.GetField<DateTime?>(inputHeaderIndex, "created_at");
        if (createdAt != default && createdAt.HasValue)
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["created_at"], createdAt.Value.ToString("yyyy-MM-ddTHH:mm:ss.fffK"));
    }

    private static void AppendDetails(CsvRow currentEvent, CsvRow currentCharge, Dictionary<string, int> inputHeaderIndex)
    {
        var operation = currentEvent.GetField(inputHeaderIndex, "cash_transaction__detail__operation");

        // There are cash events with no detail data
        if (operation == null)
            return;

        var detail = new Dictionary<string, object?>
        {
            { "operation", operation },
            { "operation_status", currentEvent.GetField(inputHeaderIndex, "cash_transaction__detail__operation_status") },
            { "operation_id", currentEvent.GetField(inputHeaderIndex, "cash_transaction__detail__operation_id") },
            { "local_datetime", currentEvent.GetField(inputHeaderIndex, "cash_transaction__detail__local_datetime") },
            { "provider_datetime", currentEvent.GetField<DateTime>(inputHeaderIndex, "cash_transaction__detail__provider_datetime").ToString("yyyy-MM-dd HH:mm:ss.fff") },
            { "operation_amount", currentEvent.GetField(inputHeaderIndex, "cash_transaction__detail__operation_amount") },
            { "operation_reason", currentEvent.GetField(inputHeaderIndex, "cash_transaction__detail__operation_reason") },
            { "legacy", new Dictionary<string, object?>
                {
                    { "status", currentEvent.GetField(inputHeaderIndex, "cash_transaction__detail__legacy__status") },
                    { "transaction_status", currentEvent.GetField(inputHeaderIndex, "cash_transaction__detail__legacy__transaction_status") },
                    { "operation", currentEvent.GetField(inputHeaderIndex, "cash_transaction__detail__legacy__operation") },
                    { "account_name", currentEvent.GetField(inputHeaderIndex, "cash_transaction__detail__legacy__account_name") },
                    { "canceled_amount", currentEvent.GetField(inputHeaderIndex, "cash_transaction__detail__legacy__canceled_amount") }
                }
            }
        };

        var currentChargeDetails = currentCharge.GetField(ChargeListReportHeader.HeaderIndex, "cash_transaction__details");

        if (currentChargeDetails is List<Dictionary<string, object?>> details)
        {
            details.Add(detail);
            return;
        }

        // If the list does not exist, create a new one
        currentChargeDetails = new List<Dictionary<string, object?>> { detail };
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["cash_transaction__details"], currentChargeDetails);
    }

    private static bool IsNotCompletedOperation(string operationStatus)
    {
        if (string.IsNullOrEmpty(operationStatus))
            return true;

        operationStatus = operationStatus.ToLower();
        return operationStatus == "with_error" ||
               operationStatus == "waiting_payment" ||
               operationStatus == "waiting_cancellation" ||
               operationStatus == "declined" ||
               operationStatus == "analyzing" ||
               operationStatus == "created" ||
               operationStatus.Contains("unknown", StringComparison.OrdinalIgnoreCase);
    }

    public static void ComputeAmounts(CsvRow currentCharge)
    {
        var detailsObj = currentCharge.GetField(ChargeListReportHeader.HeaderIndex, "cash_transaction__details");
        if (detailsObj is not List<Dictionary<string, object?>> details)
            return;

        // Acumulators
        int paid = 0, canceled = 0;

        foreach (var detail in details)
        {
            var operationStatus = detail.TryGetValue("operation_status", out var opStatus) ? opStatus?.ToString() : null;
            if (operationStatus != null)
            {
                if (IsNotCompletedOperation(operationStatus))
                    continue;
            }

            var operation = detail.TryGetValue("operation", out var op) ? op?.ToString() : null;

            if (operation == "pay")
            {
                var operationAmountStr = detail.TryGetValue("operation_amount", out var opAmount) ? opAmount?.ToString() : null;
                if (operationAmountStr != null)
                {
                    bool success = int.TryParse(operationAmountStr, out int operationAmount);
                    if (success)
                        paid += operationAmount;
                }
            }
            else if (operation == "cancel")
            {
                var legacyDetails = detail.TryGetValue("legacy", out var legacyRawObj) ? legacyRawObj as Dictionary<string, object?> : null;
                if (legacyDetails != null)
                {
                    var canceledAmountStr = legacyDetails.TryGetValue("canceled_amount", out var canceledAmountObj) ? canceledAmountObj?.ToString() : null;
                    if (canceledAmountStr != null)
                    {
                        bool success = int.TryParse(canceledAmountStr, out int canceledAmount);
                        if (success)
                            canceled += canceledAmount;
                    }
                }
            }
        }

        var updatedAmount = paid > 0 ? paid - canceled : 0;

        // Ensure amounts are not negative
        updatedAmount = Math.Max(updatedAmount, 0);

        // Compute net amounts
        var fullNetAmount = Math.Max((updatedAmount / 100m), 0);
        var netAmount = (int)Math.Round(fullNetAmount * 100);

        // Compute status
        var status = ComputeStatus(currentCharge, paid, canceled, details);

        // Set fields
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["status"], status);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["net_amount"], netAmount);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["updated_amount"], updatedAmount);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["full_net_amount"], fullNetAmount);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["cash_transaction__paid_amount"], paid);
        currentCharge.SetField(ChargeListReportHeader.HeaderIndex["cash_transaction__canceled_amount"], canceled);
    }

    private static string? ComputeStatus(CsvRow currentCharge, int paidAmount, int canceledAmount, List<Dictionary<string, object?>>? details = null)
    {
        // Get the last operation status from details
        var statusFromSource = PagarmeHelper.GetLastOperationStatus(details);

        if (string.IsNullOrEmpty(statusFromSource))
            return "failed";

        // Set last legacy status for Pagarme (Cash is Pagarme only)
        var legacyStatus = PagarmeHelper.GetLastLegacyStatus(details);
        if (!string.IsNullOrEmpty(legacyStatus))
            currentCharge.SetField(ChargeListReportHeader.HeaderIndex["cash_transaction__last__legacy_status"], legacyStatus);

        return PagarmeHelper.GetStatus(statusFromSource, paidAmount, canceledAmount, "cash");
    }
}

internal static class PagarmeHelper
{
    public static bool IsNotCompletedOperation(string operationStatus)
    {
        return operationStatus == "with_error" ||
                operationStatus == "waiting_payment" ||
                operationStatus == "waiting_cancellation" ||
                operationStatus == "declined" ||
                operationStatus == "analyzing" ||
                operationStatus == "created" ||
                operationStatus.ToLower().Contains("unknown");
    }

    private static Dictionary<string, object?>? GetLastDetailByProviderDateTime(List<Dictionary<string, object?>>? details)
    {
        if (details == null || details.Count == 0)
            return null;

        // Get the detail with the maximum provider_datetime
        return details.MaxBy(d =>
        {
            if (!d.TryGetValue("provider_datetime", out var dt) || dt == null)
                return DateTime.MinValue;

            return DateTime.TryParse(dt.ToString(), out var dateTime)
                ? dateTime
                : DateTime.MinValue;
        });
    }

    public static string? GetLastOperationStatus(List<Dictionary<string, object?>>? details)
    {
        var lastDetail = GetLastDetailByProviderDateTime(details);

        if (lastDetail == null)
            return null;

        // Get the operation_status from the last detail
        return lastDetail.TryGetValue("operation_status", out var status) ? status?.ToString() : null;
    }

    public static string? GetLastLegacyStatus(List<Dictionary<string, object?>>? details)
    {
        var lastDetail = GetLastDetailByProviderDateTime(details);

        if (lastDetail == null)
            return null;

        // Get the legacy status from the last detail
        if (lastDetail.TryGetValue("legacy", out var legacyObj)
            && legacyObj is Dictionary<string, object?> legacyDict
            && legacyDict.TryGetValue("status", out var statusObj))
        {
            return statusObj?.ToString();
        }

        return null;
    }

    private static readonly Dictionary<string, List<string>> StatusMap = new()
    {
        ["authorized"] = new() { "waiting_capture" },
        ["processing"] = new() { "analyzing", "waiting_payment", "pending", "waiting_cancellation", "pending_authentication" },
        ["paid"] = new() { "over_paid", "partial_capture", "pay", "under_paid", "partial_cancel", "captured", "paid" },
        ["declined"] = new() { "declined" },
        ["default"] = new() { "created", "canceled", "chargeback", "failed" }
    };

    public static string GetStatus(string status, int authorizedAmount, int capturedAmount, string paymentMethod)
    {
        if (StatusMap["authorized"].Contains(status)) return "authorized";
        if (StatusMap["processing"].Contains(status)) return "processing";
        if (StatusMap["paid"].Contains(status)) return "paid";
        if (StatusMap["declined"].Contains(status)) return "failed";
        if (StatusMap["default"].Contains(status)) return status;

        if (status == "with_error")
        {
            if (capturedAmount > 0) return "paid";

            // Check for authorized amount in card transaction
            if (paymentMethod == "card" && authorizedAmount > 0)
            {
                return "processing";
            }

            return "failed";
        }

        // Unknown case
        return "failed";
    }
}
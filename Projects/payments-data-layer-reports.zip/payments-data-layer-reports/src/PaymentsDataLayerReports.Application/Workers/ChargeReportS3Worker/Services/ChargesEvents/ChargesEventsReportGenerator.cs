using System.Diagnostics;
using Datadog.Trace;
using PaymentsDataLayerReports.Application.Constants;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.Models;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.RealtimeChargeEvents;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;
using Serilog;

namespace PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.ChargesEvents;

public class ChargesEventsReportGenerator(IDeltaLakeManager deltaLakeManager,
    IS3ClientWrapper s3ClientWrapper,
    ChargeEventsReportManager chargeEventsReportManager,
    IRealtimeChargeEventsService RealtimeChargeEventsService) : IReportGenerator<GenerateReportInput>
{
    public async Task Execute(GenerateReportInput input)
    {
        var jobId = input.JobId;

        using var scope = Tracer.Instance.StartActive("ChargesEventsReportGenerator.Execute");
        scope.Span.SetTag("ChargesEventsReportGenerator.Execute.JobId", jobId);
        scope.Span.SetTag("ChargesEventsReportGenerator.Execute.ReportId", input.ReportMetadata.ReportId);
        scope.Span.SetTag("ChargesEventsReportGenerator.Execute.PartitionDate", $"{input.PartitionDate:yyyy-MM-dd}");

        Log.ForContext("Parameters", input.ReportMetadata)
        .ForContext("JobId", jobId)
        .ForContext("ReportId", input.ReportMetadata.ReportId)
        .ForContext("PartitionDate", input.PartitionDate)
        .Debug("[ChargesEventsReportGenerator.Execute] Starting charge events report");

        var stopwatch = Stopwatch.StartNew();

        try
        {
            if (input.ReportMetadata.ChargeReportParameters!.StartDate.Date == input.PartitionDate)
            {
                await s3ClientWrapper.UploadReportHeaderAsync(
                    input.ReportMetadata.ReportId,
                    ChargesEventsReportHeader.HeaderRow
                );
            }
            var downloadTask = deltaLakeManager.DownloadAsync(input, chargeEventsReportManager.ChargesEventsRawParquetPath);

            var realtimeTask = RealtimeChargeEventsService.BuildRealtimeFileAsync(input, chargeEventsReportManager.ChargesEventsRawParquetPath);

            await Task.WhenAll(downloadTask, realtimeTask);

            var totalFileSize = downloadTask.Result;
            var hasRealTimeData = realtimeTask.Result;

            var hasparquetData = totalFileSize > 0;

            if (!hasRealTimeData && !hasparquetData)
            {
                Log.ForContext("JobId", jobId)
                   .ForContext("ReportId", input.ReportMetadata.ReportId)
                   .ForContext("PartitionDate", input.PartitionDate)
                   .Debug($"[ChargesEventsReportGenerator.Execute] No data available");
                return;
            }

            var (csvCount, csvFileSize) = await deltaLakeManager.ConvertToCsvAsync(
                input,
                chargeEventsReportManager.ChargesEventsRawParquetPath,
                chargeEventsReportManager.ChargesEventsRawCsvFile,
                hasRealTimeData,
                hasparquetData
            );

            var totalDiskUsage = totalFileSize + csvFileSize;
            var totalDiskUsageMB = totalDiskUsage / ByteSizeConstants.MB;
            scope.Span.SetTag("ChargesEventsReportGenerator.Execute.total_disk_usage_bytes", totalDiskUsage.ToString());
            scope.Span.SetTag("ChargesEventsReportGenerator.Execute.total_disk_usage_mb", totalDiskUsageMB.ToString("F2"));

            if (csvCount == 0)
            {
                Log.ForContext("JobId", jobId)
                   .ForContext("ReportId", input.ReportMetadata.ReportId)
                   .ForContext("PartitionDate", input.PartitionDate)
                   .Debug($"[ChargesEventsReportGenerator.Execute] Empty CSV file after converting to CSV");
                return;
            }

            chargeEventsReportManager.TryDeleteParquetPath();

            chargeEventsReportManager.SortChargesEventsByIdAndEventDatetimeDesc(jobId, input.ReportMetadata.ReportId, input.PartitionDate, ChargeEventsReportQuery.ProcessedAtColumnPosition, ChargeEventsReportQuery.ColumnCountWithoutProcessedAt);

            chargeEventsReportManager.TryDeleteFile(chargeEventsReportManager.ChargesEventsRawCsvFile);

            await s3ClientWrapper.UploadReportAsync(
                sourcePath: chargeEventsReportManager.ChargesEventsSortedByEventIdAndEventDatetimeDescCsvFile,
                reportId: input.ReportMetadata.ReportId,
                partitionIdGroup: input.PartitionSet.GetPartitionIdGroup(),
                partitionDate: input.PartitionDate
            );

        }
        catch (Exception ex)
        {
            Log.ForContext("Exception", ex)
              .ForContext("JobId", jobId)
              .ForContext("ReportId", input.ReportMetadata.ReportId)
              .ForContext("PartitionDate", input.PartitionDate)
              .Error("[ChargesEventsReportGenerator.Execute] Error processing charge events report");
            throw;
        }
        finally
        {
            stopwatch.Stop();
            Log.ForContext("Duration", stopwatch.Elapsed.TotalSeconds)
              .ForContext("JobId", jobId)
              .ForContext("ReportId", input.ReportMetadata.ReportId)
              .ForContext("PartitionDate", input.PartitionDate)
              .Debug($"[ChargesEventsReportGenerator.Execute] Charges events report completed");
        }
    }
}
using Amazon.S3;
using Datadog.Trace;
using DuckDB.NET.Data;
using Microsoft.Extensions.Options;
using PaymentsDataLayerReports.Application.Constants;
using PaymentsDataLayerReports.Application.Extensions;
using PaymentsDataLayerReports.Application.Services.DeltaTableColumnMapping;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.ChargeList;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.ChargesEvents;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.FinMovList;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.Models;
using PaymentsDataLayerReports.Application.Workers.ChargeReportWorker;
using Serilog;

namespace PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker;

public interface IDeltaLakeManager
{
    Task<long> DownloadAsync(GenerateReportInput input, string localPath);

    Task<(int count, long csvFileSize)> ConvertToCsvAsync(
        GenerateReportInput reportInput,
        string inputDirPath,
        string outputCsvPath,
        bool hasRealTimeData,
        bool hasParquetData);

    void FilterCharges(string inputDirPath, string outputCsvPath, ChargeReportsWorkerParameters parameters);
}

public class DeltaLakeManager(
    IAmazonS3 s3Client,
    IOptions<AwsSettings> awsSettings,
    IColumnMappingService columnMappingService,
    IOptions<ReportSettings> reportSettings
) : IDeltaLakeManager
{
    private readonly IAmazonS3 _s3Client = s3Client;
    private readonly string _warehouseBucket = awsSettings.Value.WarehouseBucket!;
    private readonly IColumnMappingService _columnMappingService = columnMappingService;
    private readonly List<string> _allowedFinancialMovementCategories = reportSettings.Value.SaleReport.GetAllowedFinancialMovementCategories();

    private const string DeltaTablePathTemplate = "delta/pay_data_layer/{0}/partition_year={1}/partition_month={2}/partition_day={3}/partition_id={4}/";

    public async Task<long> DownloadAsync(GenerateReportInput input, string localPath)
    {
        using var scope = Tracer.Instance.StartActive("DeltaLakeManager.DownloadAsync");
        Log.Debug("[DeltaLakeManager.DownloadAsync] Starting");

        try
        {
            Log.ForContext("Count", input.PartitionSet.Partitions.Length)
                .ForContext("Tables", string.Join(", ", input.PartitionSet.Partitions.Select(p => p.TableName)))
                .Debug("[DeltaLakeManager.DownloadAsync] Tables to download");

            long totalFileSize = 0;
            foreach (var partition in input.PartitionSet.Partitions)
            {
                var bucketPath = string.Format(
                    DeltaTablePathTemplate,
                    partition.TableName,
                    input.PartitionDate.Year,
                    input.PartitionDate.Month,
                    input.PartitionDate.Day,
                    partition.PartitionId
                );
                var tableLocalPath = Path.Combine(localPath, partition.TableName);

                Log.ForContext("TableName", partition.TableName)
                    .ForContext("BucketPath", bucketPath)
                    .ForContext("LocalPath", tableLocalPath)
                    .Debug("[DeltaLakeManager.DownloadAsync] Downloading table");

                var tableFileSize = await _s3Client.DownloadAsync(_warehouseBucket, bucketPath, tableLocalPath);
                totalFileSize += tableFileSize;

                Log.ForContext("TableName", partition.TableName)
                    .ForContext("FileSizeBytes", tableFileSize)
                    .ForContext("FileSizeMB", (tableFileSize / ByteSizeConstants.MB).ToString("F2"))
                    .Debug("[DeltaLakeManager.DownloadAsync] Table downloaded");
            }

            Log.ForContext("LocalPath", localPath)
                .ForContext("TotalFileSizeBytes", totalFileSize)
                .ForContext("TotalFileSizeMB", (totalFileSize / ByteSizeConstants.MB).ToString("F2"))
                .Debug("[DeltaLakeManager.DownloadAsync] Successfully downloaded all Delta Lake files");

            return totalFileSize;
        }
        catch (Exception ex)
        {
            Log.Error(ex, "[DeltaLakeManager.DownloadAsync] Error downloading files");
            throw;
        }
    }

    public async Task<(int count, long csvFileSize)> ConvertToCsvAsync(
        GenerateReportInput reportInput,
        string inputDirPath,
        string outputCsvPath,
        bool hasRealTimeData,
        bool hasParquetData
    )
    {
        using var scope = Tracer.Instance.StartActive("DeltaLakeManager.ConvertToCsv");
        Log.Debug("[DeltaLakeManager.ConvertToCsv] Starting");

        var duckDBConnection = new DuckDBConnection("Data Source=:memory:");
        await duckDBConnection.OpenAsync();

        using var command = duckDBConnection.CreateCommand();

        // Set DuckDB base settings
        command.CommandText = $"""
            SET memory_limit = '500MB';
            SET threads = 1;
        """;
        await command.ExecuteNonQueryAsync();

        var reportType = reportInput.ReportMetadata.ChargeReportParameters?.ReportType
            ?? reportInput.ReportMetadata.FinMovReportParameters?.ReportType
            ?? throw new ArgumentException("Report type cannot be null. Either ChargeReportParameters or FinMovReportParameters must have a valid ReportType.");

        command.CommandText = reportType switch
        {
            "sales_stone" or "sales_ton" or "charges_list" or "sales" => await ChargeListReportQuery.SelectChargesEventsAsync(
                inputDirPath,
                outputCsvPath,
                reportInput,
                hasRealTimeData,
                hasParquetData,
                _columnMappingService,
                _allowedFinancialMovementCategories
            ),
            "charges_events" => await ChargeEventsReportQuery.SelectChargesEventsAsync(
                inputDirPath,
                outputCsvPath,
                reportInput,
                hasRealTimeData,
                hasParquetData,
                _columnMappingService,
                _allowedFinancialMovementCategories
            ),
            "receivables" or "receivables_legacy" => await FinMovListReportQuery.SelectFinMovListAsync(
                inputDirPath,
                outputCsvPath,
                reportInput.ReportMetadata,
                hasRealTimeData,
                hasParquetData,
                _columnMappingService
            ),
            _ => throw new ArgumentException($"Unsupported report type: {reportType}")
        };

        var count = await command.ExecuteNonQueryAsync();

        //Get the size of the csv file
        var csvFileSize = new FileInfo(outputCsvPath).Length;
        Log.ForContext("RowsCount", count)
            .ForContext("CsvFileSizeMB", (csvFileSize / ByteSizeConstants.MB).ToString("F2"))
            .Debug("[DeltaLakeManager.ConvertToCsv] Successfully converted to csv");
        scope.Span.SetTag("DeltaLakeManager.ConvertToCsv.rows_count", count.ToString());
        scope.Span.SetTag("DeltaLakeManager.ConvertToCsv.csv_file_size_bytes", csvFileSize.ToString());
        scope.Span.SetTag("DeltaLakeManager.ConvertToCsv.csv_file_size_mb", (csvFileSize / ByteSizeConstants.MB).ToString("F2"));

        return (count, csvFileSize);
    }


    public void FilterCharges(string inputDirPath, string outputCsvPath, ChargeReportsWorkerParameters parameters)
    {
        using var scope = Tracer.Instance.StartActive("DeltaLakeManager.FilterCharges");
        Log.Debug("[DeltaLakeManager.FilterCharges] Starting");

        var duckDBConnection = new DuckDBConnection("Data Source=:memory:");
        duckDBConnection.Open();

        using var command = duckDBConnection.CreateCommand();

        // Set DuckDB base settings
        command.CommandText = $"""
            SET memory_limit = '500MB';
            SET threads = 1;
        """;
        command.ExecuteNonQuery();


        command.CommandText = ChargeListReportQuery.FilterCharges(
            inputDirPath,
            outputCsvPath,
            parameters
        );
        var count = command.ExecuteNonQuery();

        return;
    }
}
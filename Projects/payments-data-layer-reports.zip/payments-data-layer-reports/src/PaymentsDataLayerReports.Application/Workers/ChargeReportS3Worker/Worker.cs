using Datadog.Trace;
using Hangfire;
using Hangfire.Server;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Exceptions;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Services.DeltaTablePartitionBuilder;
using PaymentsDataLayerReports.Application.Services.IdempotentJobManager;
using PaymentsDataLayerReports.Application.Types;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Services.Models;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker.Utils;
using Serilog;

namespace PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker;

public class ChargeReportS3Worker(
    IReportTypeFactory reportTypeFactory,
    IS3ClientWrapper s3ClientWrapper,
    IIdempotentJobManager idempotentJobManager
)
{
    [AutomaticRetry(OnAttemptsExceeded = AttemptsExceededAction.Delete)]
    public async Task ProcessReport(
        string reportId,
        DateTime partitionDate,
        DeltaTablePartitionSet partitionSet,
        PerformContext context,
        CancellationToken cancellationToken
    )
    {
        var metadata = await s3ClientWrapper.GetReportMetadataAsync(reportId)
            ?? throw new ReportMetadataNotFoundException(reportId);

        var jobId = context.BackgroundJob.Id;
        using var scope = Tracer.Instance.StartActive("ChargeReportS3Worker.ProcessReport");
        scope.Span.SetTag("ChargeReportS3Worker.ProcessReport.JobId", jobId);
        scope.Span.SetTag("ChargeReportS3Worker.ProcessReport.ReportId", metadata.ReportId);
        scope.Span.SetTag("ChargeReportS3Worker.ProcessReport.PartitionDate", $"{partitionDate:yyyy-MM-dd}");

        Log.ForContext("Parameters", metadata.ChargeReportParameters)
            .ForContext("JobId", jobId)
            .ForContext("ReportId", metadata.ReportId)
            .ForContext("PartitionDate", partitionDate)
            .Debug("[ChargeReportS3Worker.ProcessReport] Starting");

        var input = new GenerateReportInput
        {
            PartitionDate = partitionDate,
            PartitionSet = partitionSet,
            ReportMetadata = metadata,
            CancellationToken = cancellationToken,
            JobId = jobId
        };

        var reportType = metadata.ChargeReportParameters?.ReportType ?? metadata.FinMovReportParameters?.ReportType ?? throw new InvalidOperationException("Report type not found");

        var reportHandler = reportTypeFactory
            .Create<GenerateReportInput>(Enumeration.FromName<ReportTypeEnum>(reportType));

        await reportHandler.Execute(input);

        await idempotentJobManager.TriggerConcatenationJobIfFinishedAsync(reportId, metadata.ProcessorQueueName);
    }
}

namespace PaymentsDataLayerReports.Application.Workers.NotificationWorkerV2.Models;

public class WebhookPayload
{
    public string Status { get; set; } = string.Empty;
    public string ReportId { get; set; } = string.Empty;

    public string? DownloadUrl { get; set; }

    public Dictionary<string, object>? Metadata { get; set; }

    public static WebhookPayload FromNotification(NotificationParameters parameters)
    {
        return new WebhookPayload
        {
            Status = parameters.Status,
            ReportId = parameters.ReportId,
            DownloadUrl = parameters.DownloadUrl,
            Metadata = parameters.Metadata
        };
    }
}

namespace PaymentsDataLayerReports.Application.Workers.NotificationWorkerV2.Models;

public class WebhookResponse
{
    public bool IsSuccess { get; set; }
    public int StatusCode { get; set; }
    public string? ResponseBody { get; set; }
    public string? ErrorMessage { get; set; }
    public Exception? Exception { get; set; }
    public Dictionary<string, string>? Headers { get; set; }
}

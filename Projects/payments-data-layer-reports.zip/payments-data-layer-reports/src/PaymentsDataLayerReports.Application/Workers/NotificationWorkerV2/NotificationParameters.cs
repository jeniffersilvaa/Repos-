namespace PaymentsDataLayerReports.Application.Workers.NotificationWorkerV2;

public class NotificationParameters
{
    public string Status { get; set; } = string.Empty;
    public string ReportId { get; set; } = string.Empty;
    public string ReportType { get; set; } = string.Empty;
    public required string FileFormat { get; set; }
    public string? DownloadUrl { get; set; }
    public string? DownloadFileName { get; set; }
    public Dictionary<string, object>? Metadata { get; set; }
    public NotificationChannel Channel { get; set; } = new();
}

public class NotificationChannel
{
    public WebhookChannel? Webhook { get; set; }
    public EmailChannel? Email { get; set; }
}

public class WebhookChannel
{
    public string Url { get; set; } = string.Empty;
    public IDictionary<string, string>? Headers { get; set; }
}

public class EmailChannel
{
    public string Address { get; set; } = string.Empty;
}

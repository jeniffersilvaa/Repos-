using Microsoft.Extensions.Options;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Workers.NotificationWorkerV2.Models;
using Serilog;

namespace PaymentsDataLayerReports.Application.Workers.NotificationWorkerV2.Services;

public interface IEmailService
{
    Task SendEmailAsync(NotificationParameters payload, CancellationToken cancellationToken);
}

public class EmailService : IEmailService
{
    private readonly IWebhookService _webhookService;
    private readonly string _emailApiUrl;
    private readonly Dictionary<string, string>? _headers;

    public EmailService(IWebhookService WebhookService, IOptions<AcquirerReportsApiSettings> acquirerReportsApiSettings)
    {
        _webhookService = WebhookService;
        var settings = acquirerReportsApiSettings.Value;
        _emailApiUrl = !string.IsNullOrWhiteSpace(settings.Url) ? settings.Url : throw new InvalidOperationException("Email service URL not configured.");
        _headers = new Dictionary<string, string>
        {
            { "Authorization", $"Bearer {settings.AuthToken}" }
        };
    }

    public async Task SendEmailAsync(NotificationParameters payload, CancellationToken cancellationToken)
    {
        var emailPayload = WebhookPayload.FromNotification(payload);

        var response = await _webhookService.SendWebhookAsync(_emailApiUrl, emailPayload, _headers, cancellationToken);

        if (response.IsSuccess)
        {
            Log.ForContext("ReportId", payload.ReportId)
                .ForContext("StatusCode", response.StatusCode)
                .Information("[EmailService.SendEmailAsync] Email sent successfully");
            return;
        }

        var errorMessage = $"Email notification failed with status {response.StatusCode}: {response.ErrorMessage}";

        Log.ForContext("ReportId", payload.ReportId)
            .ForContext("StatusCode", response.StatusCode)
            .ForContext("ErrorMessage", response.ErrorMessage)
            .Error("[EmailService.SendEmailAsync] Email notification failed");

        throw new Exception(errorMessage);
    }
}

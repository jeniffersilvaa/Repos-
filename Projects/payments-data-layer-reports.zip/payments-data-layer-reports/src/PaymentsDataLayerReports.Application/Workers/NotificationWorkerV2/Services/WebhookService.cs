using System.Text;
using System.Text.Json;
using PaymentsDataLayerReports.Application.Workers.NotificationWorkerV2.Models;
using Polly;
using Polly.Retry;
using Polly.Timeout;
using Serilog;

namespace PaymentsDataLayerReports.Application.Workers.NotificationWorkerV2.Services;

public interface IWebhookService
{
    Task SendWebhookAsync(NotificationParameters parameters, CancellationToken cancellationToken);
    Task<WebhookResponse> SendWebhookAsync(string webhookUrl, WebhookPayload payload, IDictionary<string, string>? headers, CancellationToken cancellationToken);
}

public class WebhookService : IWebhookService
{
    private readonly HttpClient _httpClient;
    private readonly JsonSerializerOptions _jsonOptions;
    private readonly ResiliencePipeline _retryPipeline;

    public WebhookService(HttpClient httpClient)
    {
        _httpClient = httpClient;
        _jsonOptions = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower,
            WriteIndented = false
        };
        _retryPipeline = new ResiliencePipelineBuilder()
            .AddRetry(new RetryStrategyOptions
            {
                ShouldHandle = new PredicateBuilder().Handle<HttpRequestException>().Handle<TaskCanceledException>(),
                MaxRetryAttempts = 3,
                Delay = TimeSpan.FromSeconds(1),
                BackoffType = DelayBackoffType.Exponential,
                UseJitter = true,
                OnRetry = args =>
                {
                    Log.Warning("[WebhookService] Retry attempt {Attempt} for webhook call. Exception: {Exception}",
                        args.AttemptNumber, args.Outcome.Exception?.Message);
                    return ValueTask.CompletedTask;
                }
            })
            .AddTimeout(TimeSpan.FromSeconds(10))
            .Build();
    }

    public async Task SendWebhookAsync(NotificationParameters parameters, CancellationToken cancellationToken)
    {
        var webhookUrl = parameters.Channel.Webhook!.Url;
        if (string.IsNullOrWhiteSpace(webhookUrl))
        {
            Log.ForContext("ReportId", parameters.ReportId)
                .Error("[WebhookService.SendWebhookAsync] Webhook URL is null or empty");
            throw new ArgumentException("Webhook URL cannot be null or empty.", nameof(parameters));
        }

        var webhookPayload = WebhookPayload.FromNotification(parameters);
        var headers = parameters.Channel.Webhook.Headers;

        var response = await SendWebhookAsync(webhookUrl, webhookPayload, headers, cancellationToken);

        if (response.IsSuccess)
        {
            Log.ForContext("ReportId", parameters.ReportId)
                .ForContext("StatusCode", response.StatusCode)
                .Information("[WebhookService.SendWebhookAsync] Webhook sent successfully");
            return;
        }

        var errorMessage = $"Webhook failed with status {response.StatusCode}: {response.ErrorMessage}";

        Log.ForContext("ReportId", parameters.ReportId)
            .ForContext("StatusCode", response.StatusCode)
            .ForContext("ErrorMessage", response.ErrorMessage)
            .Error("[WebhookService.SendWebhookAsync] Webhook failed after Polly retries");

        throw new Exception(errorMessage);
    }

    public async Task<WebhookResponse> SendWebhookAsync(string webhookUrl, WebhookPayload payload, IDictionary<string, string>? headers, CancellationToken cancellationToken)
    {
        try
        {
            Log.Information("[WebhookService] Sending webhook to {WebhookUrl}", webhookUrl);

            var response = await _retryPipeline.ExecuteAsync(async (ct) =>
            {
                var jsonPayload = JsonSerializer.Serialize(payload, _jsonOptions);
                var content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");

                using var httpRequest = new HttpRequestMessage(HttpMethod.Post, webhookUrl)
                {
                    Content = content
                };

                httpRequest.Headers.Add("User-Agent", "PaymentsDataLayerReports/1.0");
                httpRequest.Headers.Add("X-Webhook-Source", "payments-data-layer-reports");

                if (headers != null)
                {
                    foreach (var header in headers)
                    {
                        if (!httpRequest.Headers.TryAddWithoutValidation(header.Key, header.Value))
                        {
                            httpRequest.Content.Headers.TryAddWithoutValidation(header.Key, header.Value);
                        }
                    }
                }

                return await _httpClient.SendAsync(httpRequest, ct);
            }, cancellationToken);

            var responseBody = await response.Content.ReadAsStringAsync(cancellationToken);

            return new WebhookResponse
            {
                IsSuccess = response.IsSuccessStatusCode,
                StatusCode = (int)response.StatusCode,
                ResponseBody = responseBody,
                Headers = response.Headers.ToDictionary(h => h.Key, h => string.Join(",", h.Value))
            };
        }
        catch (TimeoutRejectedException ex)
        {
            Log.Error("[WebhookService] Timeout sending webhook to {WebhookUrl}: {Message}", webhookUrl, ex.Message);
            return new WebhookResponse
            {
                IsSuccess = false,
                StatusCode = 408,
                ErrorMessage = "Request timeout after retries",
                Exception = ex
            };
        }
        catch (Exception ex)
        {
            Log.Error("[WebhookService] Failed to send webhook to {WebhookUrl} after retries: {Message}", webhookUrl, ex.Message);
            return new WebhookResponse
            {
                IsSuccess = false,
                StatusCode = 500,
                ErrorMessage = ex.Message,
                Exception = ex
            };
        }
    }
}
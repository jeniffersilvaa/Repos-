using Datadog.Trace.Annotations;
using Hangfire;
using Hangfire.Server;
using Microsoft.Extensions.Options;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Settings;
using PaymentsDataLayerReports.Application.Workers.NotificationWorkerV2.Services;
using Serilog;

namespace PaymentsDataLayerReports.Application.Workers.NotificationWorkerV2;

public class NotificationWorkerV2(
    IWebhookService webhookService,
    IEmailService emailService,
    IS3ClientWrapper s3ClientWrapper,
    IOptions<DataLayerReportPreDeploySettings> preDeploySettings
)
{
    private readonly IWebhookService _webhookService = webhookService;
    private readonly IEmailService _emailService = emailService;
    private readonly IS3ClientWrapper _s3ClientWrapper = s3ClientWrapper;
    private readonly bool? _isPreDeployWorker = preDeploySettings.Value.IsPreDeployWorker;

    [Trace]
    [AutomaticRetry(OnAttemptsExceeded = AttemptsExceededAction.Delete)]
    public async Task SendNotificationAsync(NotificationParameters parameters, PerformContext context, CancellationToken cancellationToken)
    {
        var jobId = context.BackgroundJob.Id;

        Log.ForContext("JobId", jobId)
            .ForContext("ReportId", parameters.ReportId)
            .ForContext("ReportType", parameters.ReportType)
            .ForContext("FileFormat", parameters.FileFormat)
            .Information("[NotificationWorkerV2.SendNotificationAsync] Starting notification");

        if (_isPreDeployWorker == true)
        {
            Log.ForContext("JobId", jobId)
                .ForContext("ReportId", parameters.ReportId)
                .ForContext("ReportType", parameters.ReportType)
                .ForContext("FileFormat", parameters.FileFormat)
                .Information("[NotificationWorkerV2.SendNotificationAsync] PreDeploy worker must not send notifications");

            return;
        }

        try
        {
            if (!string.IsNullOrEmpty(parameters.ReportId))
            {
                parameters.DownloadUrl = _s3ClientWrapper.BuildReportUrl(parameters.ReportId, fileName: parameters.DownloadFileName, fileFormat: parameters.FileFormat);

                Log.ForContext("JobId", jobId)
                    .ForContext("ReportId", parameters.ReportId)
                    .ForContext("ReportType", parameters.ReportType)
                    .ForContext("FileFormat", parameters.FileFormat)
                    .ForContext("DownloadUrl", parameters.DownloadUrl)
                    .Information("[NotificationWorkerV2.SendNotificationAsync] Generated download URL for succeeded report");
            }

            if (parameters.Channel.Webhook is not null)
            {
                await _webhookService.SendWebhookAsync(parameters, cancellationToken);
            }

            if (parameters.Channel.Email is not null)
            {
                await _emailService.SendEmailAsync(parameters, cancellationToken);
            }
        }
        catch (Exception ex)
        {
            Log.ForContext("JobId", jobId)
                .ForContext("ReportId", parameters.ReportId)
                .ForContext("ReportType", parameters.ReportType)
                .ForContext("FileFormat", parameters.FileFormat)
                .ForContext("Exception", ex)
                .Error("[NotificationWorkerV2.SendNotificationAsync] Exception during notification");

            throw;
        }
    }
}

namespace PaymentsDataLayerReports.Application.Services.DeltaTableColumnMapping;

public class DeltaTableColumnModel(string logicalName, string? transformMethod = null, bool existsInRealTime = true)
{
    public string LogicalName { get; set; } = logicalName;
    public bool ExistsInRealTime { get; set; } = existsInRealTime;
    public string? TransformMethod { get; set; } = transformMethod;

    public string ToSqlColumn(IReadOnlyDictionary<string, string> columnMappings, bool isRealTime = false)
    {
        if (isRealTime && !ExistsInRealTime)
            return $"NULL AS {LogicalName}";

        var physicalName = columnMappings.TryGetValue(LogicalName, out var mapped) ? mapped : LogicalName;
        if (!string.IsNullOrEmpty(TransformMethod))
            return $"{TransformMethod.Replace("{column}", $"\"{physicalName}\"")} AS {LogicalName}";

        return physicalName != LogicalName ? $"\"{physicalName}\" AS {LogicalName}" : LogicalName;
    }

    public IEnumerable<string> ToNullClause(IReadOnlyDictionary<string, string> columnMappings)
    {
        yield return $"NULL AS {LogicalName}";
        if (columnMappings.TryGetValue(LogicalName, out var physicalCol) && physicalCol != LogicalName)
            yield return $"NULL AS \"{physicalCol}\"";
    }
}
using System.Collections.Concurrent;
using System.Net;
using System.Text.Json;
using Amazon.S3;
using Amazon.S3.Model;
using Microsoft.Extensions.Options;
using PaymentsDataLayerReports.Application.Settings;

namespace PaymentsDataLayerReports.Application.Services.DeltaTableColumnMapping;

public interface IColumnMappingService
{
    Task<ColumnMapping?> GetColumnMappingAsync(string tableName);
    Task<IEnumerable<string>> GenerateSqlColumnsAsync(string tableName, IEnumerable<DeltaTableColumnModel> columns);
    Task<IEnumerable<string>> GenerateNullClausesAsync(string tableName, IEnumerable<DeltaTableColumnModel> columns);
}

public class ColumnMappingService(IAmazonS3 s3Client, IOptions<AwsSettings> awsSettings) : IColumnMappingService
{
    private const string MappingPrefix = "schema_mappings/";
    private const string MappingSuffix = "_column_mapping.json";

    private readonly string _bucketName = awsSettings.Value.WarehouseBucket!;
    private readonly ConcurrentDictionary<string, ColumnMapping> _mappingCache = new();
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    public async Task<ColumnMapping?> GetColumnMappingAsync(string tableName)
    {
        if (_mappingCache.TryGetValue(tableName, out var cachedMapping))
        {
            return cachedMapping;
        }

        try
        {
            var key = $"{MappingPrefix}{tableName}{MappingSuffix}";
            var request = new GetObjectRequest
            {
                BucketName = _bucketName,
                Key = key
            };

            using var response = await s3Client.GetObjectAsync(request);
            using var reader = new StreamReader(response.ResponseStream);
            var jsonContent = await reader.ReadToEndAsync();

            var mapping = JsonSerializer.Deserialize<ColumnMapping>(jsonContent, JsonOptions);

            if (mapping != null)
            {
                _mappingCache.TryAdd(tableName, mapping);
            }

            return mapping;
        }
        catch (AmazonS3Exception ex) when (ex.StatusCode == HttpStatusCode.NotFound)
        {
            return null;
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException($"Error loading column mapping for table {tableName}: {ex.Message}", ex);
        }
    }

    public async Task<IEnumerable<string>> GenerateSqlColumnsAsync(string tableName, IEnumerable<DeltaTableColumnModel> columns)
    {
        var mapping = await GetColumnMappingAsync(tableName);
        var mappings = mapping?.ColumnMappings ?? [];
        return columns.Select(c => c.ToSqlColumn(mappings));
    }

    public async Task<IEnumerable<string>> GenerateNullClausesAsync(string tableName, IEnumerable<DeltaTableColumnModel> columns)
    {
        var mapping = await GetColumnMappingAsync(tableName);
        var mappings = mapping?.ColumnMappings ?? [];
        return columns.SelectMany(c => c.ToNullClause(mappings)).Distinct();
    }

    public static string GetColumnNameForFilter(string logicalName, ColumnMapping? columnMapping)
    {
        var mappings = columnMapping?.ColumnMappings ?? [];
        var physicalName = mappings.TryGetValue(logicalName, out var mappedName) ? mappedName : logicalName;
        return physicalName.Contains('-') ? $"\"{physicalName}\"" : physicalName;
    }
}

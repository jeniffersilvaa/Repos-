using System.Text.Json.Serialization;

namespace PaymentsDataLayerReports.Application.Services.DeltaTableColumnMapping;

public class ColumnMapping
{
    [JsonPropertyName("table_name")]
    public string TableName { get; set; } = string.Empty;

    [JsonPropertyName("column_mappings")]
    public Dictionary<string, string> ColumnMappings { get; set; } = [];

    [JsonPropertyName("total_columns")]
    public int TotalColumns { get; set; }
}
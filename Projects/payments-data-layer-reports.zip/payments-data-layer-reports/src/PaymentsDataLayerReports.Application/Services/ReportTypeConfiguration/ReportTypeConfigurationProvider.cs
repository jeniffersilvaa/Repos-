using PaymentsDataLayerReports.Application.Constants;
using PaymentsDataLayerReports.Application.Enums;

namespace PaymentsDataLayerReports.Application.Services.ReportTypeConfiguration;

public record SortColumn(int ColumnIndex, bool Descending = true);

// TODO: Improve structure as not all reports need ReportSortColumnIndex
public record ReportTypeConfiguration(
    int ReportSortColumnIndex,
    CsvSeparatorEnum CsvSeparator = CsvSeparatorEnum.Comma,
    bool SupportsXlsx = false,
    SortColumn[]? SortColumns = null
);

public static class ReportTypeConfigurationProvider
{
    private const int NotSorted = 999;
    private static readonly Dictionary<string, ReportTypeConfiguration> Configurations = new(StringComparer.OrdinalIgnoreCase)
    {
        // Reports that support XLSX and use semicolon separator
        ["sales_stone"] = new(ReportSortColumnIndex: 2, CsvSeparator: CsvSeparatorEnum.Semicolon, SupportsXlsx: true),
        ["sales_ton"] = new(ReportSortColumnIndex: 1, CsvSeparator: CsvSeparatorEnum.Semicolon, SupportsXlsx: true),
        ["orders"] = new(ReportSortColumnIndex: NotSorted, CsvSeparator: CsvSeparatorEnum.Semicolon, SupportsXlsx: true),
        ["receivables_legacy"] = new(ReportSortColumnIndex: 4, CsvSeparator: CsvSeparatorEnum.Semicolon, SupportsXlsx: true,
            SortColumns: [new(4), new(8, Descending: false), new(10, Descending: false)]),
        ["sales"] = new(ReportSortColumnIndex: 6, CsvSeparator: CsvSeparatorEnum.Semicolon, SupportsXlsx: true),
        ["receivables"] = new(ReportSortColumnIndex: 3, CsvSeparator: CsvSeparatorEnum.Semicolon, SupportsXlsx: true,
            SortColumns: [new(3), new(2, Descending: false), new(10, Descending: false)]),

        // Reports that only support CSV and use comma separator
        ["charges_list"] = new(ReportSortColumnIndex: 10),
        ["charges_events"] = new(ReportSortColumnIndex: 0),
    };

    public static ReportTypeConfiguration? GetConfiguration(string reportType)
    {
        return Configurations.TryGetValue(reportType, out var configuration)
            ? configuration
            : null;
    }

    public static CsvSeparatorEnum GetCsvSeparator(string reportType)
    {
        return GetConfiguration(reportType)?.CsvSeparator ?? CsvSeparatorEnum.Comma;
    }

    public static char GetSeparatorChar(string reportType)
    {
        return CsvSeparatorConstants.GetSeparator(GetCsvSeparator(reportType));
    }

    public static bool IsFileFormatSupported(string reportType, string fileFormat)
    {
        if (string.Equals(fileFormat, FileFormatEnum.Csv.Name, StringComparison.OrdinalIgnoreCase))
        {
            return true;
        }

        if (string.Equals(fileFormat, FileFormatEnum.Xlsx.Name, StringComparison.OrdinalIgnoreCase))
        {
            return SupportsXlsx(reportType);
        }

        return false;
    }

    public static bool SupportsXlsx(string reportType)
    {
        return GetConfiguration(reportType)?.SupportsXlsx ?? false;
    }

    public static bool UsesOneStoneLayout(string? reportType)
    {
        return string.Equals(reportType, ReportTypeEnum.Receivables.Name, StringComparison.OrdinalIgnoreCase);
    }
}

namespace PaymentsDataLayerReports.Application.Services.DeltaTablePartitionBuilder;

public record DeltaTablePartition(
    string TableName,
    string PartitionId
);

public record DeltaTablePartitionSet
{
    public required List<string> PartitionIdReferences { get; init; }
    public required string PartitionIdReferenceType { get; init; }
    public required DeltaTablePartition[] Partitions { get; init; }

    public string GetPartitionIdGroup()
    {
        return string.Join("-", Partitions.OrderBy(p => p.TableName).Select(p => p.PartitionId));
    }
}

public static class DeltaTablePartitionBuilder
{
    private static readonly DeltaTableConfiguration ChargesEventsByCreatedAt = new(
        TableName: "charges_events_by_created_at",
        DocumentModForMerchant: 10,
        DocumentModForDocument: 400
    );

    private static readonly DeltaTableConfiguration ChargesPosteriorEventsByCreatedAt = new(
        TableName: "charges_posterior_events_by_created_at",
        DocumentModForMerchant: 10,
        DocumentModForDocument: 10
    );

    private static readonly DeltaTableConfiguration FinMovSettledByDueDate = new(
        TableName: "finmov_settled_by_due_date",
        DocumentModForMerchant: 10,
        DocumentModForDocument: 400
    );

    private static readonly DeltaTableConfiguration ChargesPosteriorEventsByEventDate = new(
        TableName: "charges_posterior_events_by_event_date",
        DocumentModForMerchant: 10,
        DocumentModForDocument: 10
    );

    private static readonly Dictionary<string, DeltaTableConfiguration[]> TablesByReportType = new()
    {
        ["charges_list"] = [
            ChargesEventsByCreatedAt,
            ChargesPosteriorEventsByCreatedAt
        ],
        ["sales_stone"] = [
            ChargesEventsByCreatedAt,
            ChargesPosteriorEventsByCreatedAt
        ],
        ["sales_ton"] = [
            ChargesEventsByCreatedAt,
            ChargesPosteriorEventsByCreatedAt
        ],
        ["sales"] = [
            ChargesEventsByCreatedAt,
            ChargesPosteriorEventsByCreatedAt
        ],
        ["charges_events"] = [
            ChargesEventsByCreatedAt,
            ChargesPosteriorEventsByEventDate
        ],
        ["receivables"] = [
            FinMovSettledByDueDate
        ],
        ["receivables_legacy"] = [
            FinMovSettledByDueDate
        ]
    };

    private static DeltaTableConfiguration[] GetTablesByReportType(string reportType)
    {
        return TablesByReportType.TryGetValue(reportType, out var configurations)
            ? configurations
            : [];
    }

    public static IEnumerable<DeltaTablePartitionSet> BuildPartitionSets(string reportType, string? documents, string? merchantIds)
    {
        var merchantIdList = merchantIds?.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries) ?? [];
        var documentList = documents?.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries) ?? [];

        if (merchantIdList.Length == 0 && documentList.Length == 0)
            return [];

        var allRefs = documentList.Select(doc => new { Id = doc, Type = "document" })
            .Concat(merchantIdList.Select(mer => new { Id = mer, Type = "merchant_id" }));

        var partitionsByReference = allRefs.Select(reference =>
        {
            var tables = GetTablesByReportType(reportType);
            var partitions = tables.Select(config => new
            {
                config.TableName,
                PartitionId = config.GetPartitionId(reference.Type == "document" ? reference.Id : null, reference.Type == "merchant_id" ? reference.Id : null)
            }).OrderBy(p => p.TableName).ThenBy(p => p.PartitionId).ToList();

            return new
            {
                Reference = reference.Id,
                ReferenceType = reference.Type,
                Partitions = partitions,
                PartitionKey = string.Join("|", partitions.Select(p => $"{p.TableName}:{p.PartitionId}"))
            };
        });

        var partitionsBySet = partitionsByReference
            .GroupBy(x => x.PartitionKey)
            .Select(group =>
            {
                var firstInGroup = group.First();
                var references = group.Select(g => g.Reference).Distinct().OrderBy(r => r).ToList();

                var finalPartitions = firstInGroup.Partitions.Select(p => new DeltaTablePartition(
                    p.TableName,
                    p.PartitionId
                )).ToArray();

                return new DeltaTablePartitionSet
                {
                    PartitionIdReferences = references,
                    PartitionIdReferenceType = firstInGroup.ReferenceType,
                    Partitions = finalPartitions
                };
            });

        return partitionsBySet;
    }
}

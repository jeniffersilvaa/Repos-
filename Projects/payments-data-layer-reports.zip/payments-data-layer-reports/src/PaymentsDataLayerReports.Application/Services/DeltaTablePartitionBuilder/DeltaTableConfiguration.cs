using PaymentsDataLayerReports.Application.Types;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Worker;

namespace PaymentsDataLayerReports.Application.Services.DeltaTablePartitionBuilder;

public record DeltaTableConfiguration(
    string TableName,
    int DocumentModForMerchant,
    int DocumentModForDocument
)
{
    private static readonly string[] BigMerchantsWithSpecialPartioning = [
        "10573521000191",
        "13236697000146"
    ];

    public string GetPartitionId(string? document, string? merchantId)
    {
        bool hasMerchantId = !string.IsNullOrEmpty(merchantId);

        if (hasMerchantId)
        {
            var partitionId = ComputePartitionId(merchantId!, DocumentModForMerchant);
            return $"pagarme_{partitionId}";
        }

        return ComputePartitionId(document!, DocumentModForDocument);
    }

    private static string ComputePartitionId(string document, int mod)
    {
        if (BigMerchantsWithSpecialPartioning.Contains(document))
        {
            return document;
        }

        int partitionIdHash = Math.Abs(MurmurHash3.HashUnsafeBytes(document));

        return (partitionIdHash % mod).ToString();
    }
}

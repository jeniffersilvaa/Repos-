using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Exceptions;
using PaymentsDataLayerReports.Application.Infra.Hangfire;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;

namespace PaymentsDataLayerReports.Application.Services.ReportFinder;

public class ReportFinderService(IS3ClientWrapper s3ClientWrapper, IJobStorageProvider jobStorageProvider) : IReportFinderService
{
    private const int BaseGuidLength = 36;
    private readonly IS3ClientWrapper _s3ClientWrapper = s3ClientWrapper;
    private readonly IJobStorageProvider _jobStorageProvider = jobStorageProvider;

    public async Task<(string? Status, string? Url)> FindReport(string reportId)
    {
        var (status, fileFormat) = await GetReportStatusAsync(reportId);
        var url = GetReportUrl(reportId, status, fileFormat);
        return (status, url);
    }

    private async Task<(string? Status, string? FileFormat)> GetReportStatusAsync(string reportId)
    {
        var jobStatus = _jobStorageProvider.GetStateById(reportId[..BaseGuidLength]);

        if (jobStatus != null && jobStatus != WorkerStatesEnum.Succeeded.ToString())
        {
            return (jobStatus, null);
        }

        var (fileExists, fileFormat) = await _s3ClientWrapper.GetReportFileWithFormatAsync(reportId);
        if (fileExists)
        {
            return (WorkerStatesEnum.Succeeded.ToString(), fileFormat);
        }

        return await GetReportStatusFromMetadataAsync(reportId);
    }

    private async Task<(string? Status, string? FileFormat)> GetReportStatusFromMetadataAsync(string reportId)
    {
        try
        {
            var metadata = await _s3ClientWrapper.GetReportMetadataAsync(reportId);
            if (metadata == null) { return (null, null); }

            var fileFormat = metadata.FileFormat ?? FileFormatEnum.Csv.Name;
            return (metadata.Status, fileFormat);
        }
        catch (S3FileNotFoundException)
        {
            return (null, null);
        }
    }

    private string? GetReportUrl(string reportId, string? currentState, string? fileFormat)
    {
        if (currentState != WorkerStatesEnum.Succeeded.ToString()) return null;
        return _s3ClientWrapper.BuildReportUrl(reportId, S3ReportsConstants.UrlDefaultExpirationHours, null, fileFormat ?? FileFormatEnum.Csv.Name);
    }
}

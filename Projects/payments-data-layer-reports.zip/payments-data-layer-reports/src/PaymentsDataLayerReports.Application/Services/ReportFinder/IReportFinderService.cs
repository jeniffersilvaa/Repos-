namespace PaymentsDataLayerReports.Application.Services.ReportFinder;

public interface IReportFinderService
{
    Task<(string? Status, string? Url)> FindReport(string reportId);
}

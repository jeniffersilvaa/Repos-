using System.Text;
using SpreadCheetah;

namespace PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Helpers;

public static class CsvParserHelper
{
    public static int ParseRowToBuffer(string csvLine, char separator, DataCell[] targetCells, StringBuilder valueBuilder)
    {
        int columnIndex = 0;
        int fieldStartIndex = 0;
        bool containsQuotes = false;
        bool isInsideQuotes = false;
        ReadOnlySpan<char> lineSpan = csvLine.AsSpan();

        for (int i = 0; i < lineSpan.Length; i++)
        {
            char currentChar = lineSpan[i];

            if (currentChar == '"')
            {
                isInsideQuotes = !isInsideQuotes;
                containsQuotes = true;
            }
            else if (currentChar == separator && !isInsideQuotes)
            {
                AddCellToBuffer(lineSpan, fieldStartIndex, i, containsQuotes, columnIndex, targetCells, valueBuilder);
                columnIndex++;
                fieldStartIndex = i + 1;
                containsQuotes = false;
            }
        }

        // Add last field
        AddCellToBuffer(lineSpan, fieldStartIndex, lineSpan.Length, containsQuotes, columnIndex, targetCells, valueBuilder);
        columnIndex++;

        return columnIndex;
    }

    private static void AddCellToBuffer(ReadOnlySpan<char> lineSpan, int startIndex, int endIndex, bool containsQuotes, int columnIndex, DataCell[] targetCells, StringBuilder valueBuilder)
    {
        if (columnIndex >= targetCells.Length)
        {
            throw new InvalidOperationException(
                $"Input data is malformed: Record has more columns than the header ({targetCells.Length})."
            );
        }

        if (!containsQuotes)
        {
            // Fast path: No quotes, direct substring
            var value = lineSpan[startIndex..endIndex].ToString();
            targetCells[columnIndex] = new DataCell(value);
        }
        else
        {
            // Slow path: Unescape quotes
            valueBuilder.Clear();
            var fieldSpan = lineSpan[startIndex..endIndex];

            bool isInsideQuoteBlock = false;
            for (int j = 0; j < fieldSpan.Length; j++)
            {
                char currentChar = fieldSpan[j];
                if (currentChar == '"')
                {
                    // Check for escaped quote ("")
                    if (isInsideQuoteBlock && j + 1 < fieldSpan.Length && fieldSpan[j + 1] == '"')
                    {
                        valueBuilder.Append('"');
                        j++; // Skip next quote
                    }
                    else
                    {
                        isInsideQuoteBlock = !isInsideQuoteBlock;
                    }
                }
                else
                {
                    valueBuilder.Append(currentChar);
                }
            }
            targetCells[columnIndex] = new DataCell(valueBuilder.ToString());
        }
    }
}

using System.IO.Pipelines;
using System.Threading;
using PaymentsDataLayerReports.Application.Constants;
using PaymentsDataLayerReports.Application.Infra.MultiPartFileUploader.Interfaces;

namespace PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Sinks;

public interface IReportOutputSink : IAsyncDisposable
{
    Task<Stream> InitializeAsync(string destinationKey, string bucketName, CancellationToken cancellationToken);
    Task CompleteAsync(CancellationToken cancellationToken);
    Task AbortAsync(CancellationToken cancellationToken);
}

public class S3MultipartReportSink(IMultiPartFileUploader uploader) : IReportOutputSink
{
    private readonly IMultiPartFileUploader _uploader = uploader;
    private readonly int _partSize = 10 * ByteSizeConstants.MB;
    private static readonly TimeSpan _uploadTaskTimeout = TimeSpan.FromMinutes(5);

    private Pipe? _pipe;
    private Task? _uploadTask;
    private CancellationTokenSource? _internalCancellationToken;
    private Exception? _uploadException;

    private bool _initialized;
    private bool _completedOrAborted;

    public async Task<Stream> InitializeAsync(string destinationKey, string bucketName, CancellationToken cancellationToken)
    {
        if (_initialized)
        {
            throw new InvalidOperationException("Sink is already initialized.");
        }

        _initialized = true;
        await _uploader.InitiateMultipartUploadAsync(destinationKey, bucketName, cancellationToken);

        _pipe = new Pipe(new PipeOptions(pauseWriterThreshold: _partSize * 2, resumeWriterThreshold: _partSize));
        _internalCancellationToken = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);

        // Start the background upload task that reads from the pipe and uploads to S3
        _uploadTask = Task.Run(() => UploadFromPipeAsync(_internalCancellationToken.Token), _internalCancellationToken.Token);

        var pipeStream = _pipe.Writer.AsStream();
        return new UploadMonitoringStream(this, pipeStream);
    }

    public async Task CompleteAsync(CancellationToken cancellationToken)
    {
        EnsureInitialized();
        if (_completedOrAborted) return;

        // Signal that writing is complete
        if (_pipe != null)
        {
            await _pipe.Writer.CompleteAsync();
        }

        // Wait for upload task to finish with timeout
        if (_uploadTask != null)
        {
            await _uploadTask.WaitAsync(_uploadTaskTimeout, cancellationToken);
        }

        // Check if upload had errors
        if (_uploadException != null)
        {
            throw new InvalidOperationException("Upload failed", _uploadException);
        }

        await _uploader.CompleteMultipartUploadAsync(cancellationToken);
        _completedOrAborted = true;
    }

    public async Task AbortAsync(CancellationToken cancellationToken)
    {
        if (!_initialized || _completedOrAborted)
        {
            return;
        }

        _internalCancellationToken?.Cancel();

        // Complete the pipe to unblock the reader
        if (_pipe != null)
        {
            await _pipe.Writer.CompleteAsync();
        }

        // Wait for upload task to finish with timeout
        if (_uploadTask != null)
        {
            try
            {
                await _uploadTask.WaitAsync(_uploadTaskTimeout, CancellationToken.None);
            }
            catch
            {
                // Ignore cancellation/timeout exceptions during abort
            }
        }

        await _uploader.AbortMultipartUploadAsync(cancellationToken);
        _completedOrAborted = true;
    }

    private async Task UploadFromPipeAsync(CancellationToken cancellationToken)
    {
        if (_pipe == null) return;

        var reader = _pipe.Reader;
        var buffer = new MemoryStream(_partSize);

        try
        {
            while (true)
            {
                var result = await reader.ReadAsync(cancellationToken);
                var sequence = result.Buffer;

                foreach (var segment in sequence)
                {
                    var remaining = segment;

                    while (remaining.Length > 0)
                    {
                        var spaceInBuffer = _partSize - (int)buffer.Position;
                        var toWrite = Math.Min(spaceInBuffer, remaining.Length);

                        buffer.Write(remaining.Span[..toWrite]);
                        remaining = remaining[toWrite..];

                        if (buffer.Position >= _partSize)
                        {
                            await FlushBufferToS3Async(buffer, cancellationToken);
                        }
                    }
                }

                reader.AdvanceTo(sequence.End);

                if (result.IsCompleted)
                {
                    break;
                }
            }

            // Flush any remaining data
            if (buffer.Position > 0)
            {
                await FlushBufferToS3Async(buffer, cancellationToken);
            }
        }
        catch (OperationCanceledException)
        {
            // Expected during abort
        }
        catch (Exception ex)
        {
            _uploadException = ex;
        }
        finally
        {
            await reader.CompleteAsync();
            buffer.Dispose();
        }
    }

    private async Task FlushBufferToS3Async(MemoryStream buffer, CancellationToken cancellationToken)
    {
        buffer.Seek(0, SeekOrigin.Begin);
        await _uploader.UploadPartAsync(buffer, cancellationToken);
        buffer.SetLength(0);
    }

    private Exception? GetUploadException()
    {
        return Volatile.Read(ref _uploadException);
    }

    internal void ThrowIfUploadFailed()
    {
        var exception = GetUploadException();
        if (exception != null)
        {
            throw new InvalidOperationException("Upload failed", exception);
        }
    }

    private void EnsureInitialized()
    {
        if (!_initialized)
        {
            throw new InvalidOperationException("Sink has not been initialized.");
        }
    }

    public async ValueTask DisposeAsync()
    {
        if (_initialized && !_completedOrAborted)
        {
            await AbortAsync(CancellationToken.None);
        }

        _internalCancellationToken?.Dispose();
        GC.SuppressFinalize(this);
    }
}

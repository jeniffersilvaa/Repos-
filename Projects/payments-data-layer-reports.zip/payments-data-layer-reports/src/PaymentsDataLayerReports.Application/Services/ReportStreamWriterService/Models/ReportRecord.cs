namespace PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Models;

public readonly record struct ReportRecord(string Line, string SortKey);
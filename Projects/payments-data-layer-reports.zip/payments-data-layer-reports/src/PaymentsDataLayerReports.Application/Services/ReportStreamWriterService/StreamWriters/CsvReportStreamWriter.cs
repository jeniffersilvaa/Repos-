using System.Text;
using Microsoft.Extensions.Options;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Interfaces;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Sinks;
using PaymentsDataLayerReports.Application.Settings;

namespace PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.StreamWriters;

public class CsvReportStreamWriter(
    IReportOutputSink outputSink,
    IOptions<AwsSettings> awsSettings
) : IReportStreamWriter<string>
{
    private const int BufferSize = 65536;
    private readonly IReportOutputSink _outputSink = outputSink;
    private readonly AwsSettings _awsSettings = awsSettings.Value;

    private StreamWriter? _writer;
    private bool _isAborted;
    private bool _completed;
    private bool _disposed;

    public async Task InitializeAsync(string reportId, CancellationToken cancellationToken, string? destinationKey = null)
    {
        var bucketName = _awsSettings.WorkgroupBucket!;
        destinationKey ??= string.Format(S3ReportsConstants.ReportBasePath, reportId, FileFormatEnum.Csv.Name);
        var stream = await _outputSink.InitializeAsync(destinationKey, bucketName, cancellationToken);
        _writer = new StreamWriter(stream, Encoding.UTF8, bufferSize: BufferSize, leaveOpen: true);
    }

    public async Task WriteHeaderAsync(string header, CancellationToken cancellationToken)
    {
        EnsureInitialized();
        await WriteLineAsync(header, cancellationToken);
    }

    public async Task WriteRecordAsync(string record, CancellationToken cancellationToken)
    {
        EnsureInitialized();
        await WriteLineAsync(record, cancellationToken);
    }

    private async Task WriteLineAsync(string line, CancellationToken cancellationToken)
    {
        var cleanLine = GetFirstLine(line);
        await _writer!.WriteLineAsync(cleanLine.AsMemory(), cancellationToken);
    }

    public async Task CompleteAsync(CancellationToken cancellationToken)
    {
        if (_completed || _isAborted)
        {
            return;
        }

        try
        {
            if (_writer != null)
            {
                await _writer.FlushAsync(cancellationToken);
                await _writer.DisposeAsync();
                _writer = null;
            }

            await _outputSink.CompleteAsync(cancellationToken);
        }
        finally
        {
            _completed = true;
        }
    }

    public async Task AbortAsync(CancellationToken cancellationToken)
    {
        if (_completed || _isAborted)
        {
            return;
        }

        _isAborted = true;
        _completed = true;

        try
        {
            if (_writer != null)
            {
                await _writer.DisposeAsync();
                _writer = null;
            }
        }
        finally
        {
            await _outputSink.AbortAsync(cancellationToken);
        }
    }

    public async ValueTask DisposeAsync()
    {
        if (_disposed)
        {
            return;
        }

        _disposed = true;

        if (!_completed && !_isAborted)
        {
            await AbortAsync(CancellationToken.None);
        }

        await _outputSink.DisposeAsync();
        GC.SuppressFinalize(this);
    }

    private void EnsureInitialized()
    {
        if (_writer == null)
        {
            throw new InvalidOperationException("Writer not initialized. Call InitializeAsync first.");
        }
    }

    private static string GetFirstLine(string line)
    {
        if (string.IsNullOrEmpty(line))
        {
            return string.Empty;
        }

        var trimmed = line.Trim();
        var newlineIndex = trimmed.AsSpan().IndexOfAny('\r', '\n');

        return newlineIndex >= 0 ? trimmed[..newlineIndex] : trimmed;
    }
}

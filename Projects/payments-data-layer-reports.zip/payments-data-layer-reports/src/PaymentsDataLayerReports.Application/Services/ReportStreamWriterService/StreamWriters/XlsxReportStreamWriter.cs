using System.Text;
using Microsoft.Extensions.Options;
using PaymentsDataLayerReports.Application.Constants;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Infra.S3ClientWrapper;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Helpers;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Interfaces;
using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Sinks;
using PaymentsDataLayerReports.Application.Settings;
using SpreadCheetah;

namespace PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.StreamWriters;

public class XlsxReportStreamWriter(
    IReportOutputSink outputSink,
    IOptions<AwsSettings> awsSettings
) : IReportStreamWriter<string>, IReportStreamWriter<string[]>
{
    private readonly IReportOutputSink _outputSink = outputSink;
    private readonly AwsSettings _awsSettings = awsSettings.Value;

    private Spreadsheet? _spreadsheet;
    private DataCell[]? _cellBuffer;

    private const char _csvSeparator = CsvSeparatorConstants.Semicolon;

    private StringBuilder? _fieldBuffer;

    private bool _completed;
    private bool _isAborted;
    private bool _disposed;

    private void InitializeBuffers(int columnCount)
    {
        _cellBuffer = new DataCell[columnCount];
        _fieldBuffer = new StringBuilder();
    }

    public async Task InitializeAsync(string reportId, CancellationToken cancellationToken, string? destinationKey = null)
    {
        var bucketName = _awsSettings.WorkgroupBucket!;
        destinationKey ??= string.Format(S3ReportsConstants.ReportBasePath, reportId, FileFormatEnum.Xlsx.Name);

        var stream = await _outputSink.InitializeAsync(destinationKey, bucketName, cancellationToken);

        _spreadsheet = await Spreadsheet.CreateNewAsync(stream, cancellationToken: cancellationToken);
        await _spreadsheet.StartWorksheetAsync("Report", token: cancellationToken);
    }

    public async Task WriteHeaderAsync(string header, CancellationToken cancellationToken)
    {
        EnsureSpreadsheetInitialized();

        var columns = header.Split(_csvSeparator);
        InitializeBuffers(columns.Length);
        await WriteRecordAsync(columns, cancellationToken);
    }

    public async Task WriteRecordAsync(string record, CancellationToken cancellationToken)
    {
        EnsureSpreadsheetInitialized();
        EnsureDataCellBufferInitialized();

        int colCount = CsvParserHelper.ParseRowToBuffer(record, _csvSeparator, _cellBuffer!, _fieldBuffer!);
        await _spreadsheet!.AddRowAsync(_cellBuffer.AsMemory(0, colCount), cancellationToken);
    }

    public async Task WriteRecordAsync(string[] columns, CancellationToken cancellationToken)
    {
        EnsureSpreadsheetInitialized();
        EnsureDataCellBufferInitialized();

        if (columns.Length > _cellBuffer!.Length)
        {
            throw new InvalidOperationException(
                $"Input data is malformed: Record has {columns.Length} columns but header only has {_cellBuffer.Length}."
            );
        }

        for (int i = 0; i < columns.Length; i++)
        {
            _cellBuffer[i] = new DataCell(columns[i]);
        }

        await _spreadsheet!.AddRowAsync(_cellBuffer.AsMemory(0, columns.Length), cancellationToken);
    }

    public async Task CompleteAsync(CancellationToken cancellationToken)
    {
        if (_completed || _isAborted)
        {
            return;
        }

        EnsureSpreadsheetInitialized();

        try
        {
            await _spreadsheet!.FinishAsync(cancellationToken);
            await _spreadsheet.DisposeAsync();
            _spreadsheet = null;

            await _outputSink.CompleteAsync(cancellationToken);
        }
        finally
        {
            _completed = true;
        }
    }

    public async Task AbortAsync(CancellationToken cancellationToken)
    {
        if (_completed || _isAborted)
        {
            return;
        }

        _isAborted = true;
        _completed = true;

        try
        {
            if (_spreadsheet != null)
            {
                await _spreadsheet.DisposeAsync();
                _spreadsheet = null;
            }
        }
        finally
        {
            await _outputSink.AbortAsync(cancellationToken);
        }
    }

    public async ValueTask DisposeAsync()
    {
        if (_disposed)
        {
            return;
        }

        _disposed = true;

        if (!_completed && !_isAborted)
        {
            await AbortAsync(CancellationToken.None);
        }

        await _outputSink.DisposeAsync();
        GC.SuppressFinalize(this);
    }

    private void EnsureSpreadsheetInitialized()
    {
        if (_spreadsheet == null)
        {
            throw new InvalidOperationException(
                "Spreadsheet not initialized. Call InitializeAsync first."
            );
        }
    }

    private void EnsureDataCellBufferInitialized()
    {
        if (_cellBuffer == null)
        {
            throw new InvalidOperationException(
                "Data cell buffer not initialized. Call WriteHeaderAsync first."
            );
        }
    }

}

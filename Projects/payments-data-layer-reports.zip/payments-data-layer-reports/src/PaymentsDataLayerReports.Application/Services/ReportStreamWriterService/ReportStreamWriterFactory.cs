using PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Interfaces;
using Serilog;

namespace PaymentsDataLayerReports.Application.Services.ReportStreamWriterService;

public interface IReportStreamWriterFactory
{
    IReportStreamWriter<T> Create<T>(string fileFormat);
}

public class ReportStreamWriterFactory(
    IServiceProvider serviceProvider
) : IReportStreamWriterFactory
{
    private readonly IServiceProvider _serviceProvider = serviceProvider;

    public IReportStreamWriter<T> Create<T>(string fileFormat)
    {
        try
        {
            var key = fileFormat.ToLowerInvariant();
            return _serviceProvider.GetRequiredKeyedService<IReportStreamWriter<T>>(key);
        }
        catch (Exception ex)
        {
            Log.ForContext("Exception", ex)
                .ForContext("FileFormat", fileFormat)
                .ForContext("RecordType", typeof(T).Name)
                .Error("Failed to resolve report stream writer");
            throw new InvalidOperationException($"No writer implementation found for format '{fileFormat}' and record type '{typeof(T).Name}'.", ex);
        }
    }
}

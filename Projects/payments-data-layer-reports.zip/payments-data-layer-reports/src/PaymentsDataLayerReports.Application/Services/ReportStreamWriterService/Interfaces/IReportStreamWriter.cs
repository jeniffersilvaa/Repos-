namespace PaymentsDataLayerReports.Application.Services.ReportStreamWriterService.Interfaces;

public interface IReportStreamWriter : IAsyncDisposable
{
    Task InitializeAsync(string reportId, CancellationToken cancellationToken, string? destinationKey = null);
    Task WriteHeaderAsync(string header, CancellationToken cancellationToken);
    Task CompleteAsync(CancellationToken cancellationToken);
    Task AbortAsync(CancellationToken cancellationToken);
}

public interface IReportStreamWriter<in T> : IReportStreamWriter
{
    Task WriteRecordAsync(T record, CancellationToken cancellationToken);
}
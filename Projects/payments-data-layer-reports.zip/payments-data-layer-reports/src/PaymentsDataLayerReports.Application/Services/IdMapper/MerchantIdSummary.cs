namespace PaymentsDataLayerReports.Application.Services.IdMapper;

public class MerchantIdSummary
{
    public string? Document { get; set; }
    public string? StoneAccount { get; set; }
    public string? PaymentProfileIds { get; set; }
    public string? PointOfInteractionTypes { get; set; }
    public string? AffiliationKeys { get; set; }
    public string? AffiliationCodes { get; set; }
    public string? MerchantId { get; set; }
    public string? AccountIds { get; set; }
    public string? Organization { get; set; }
}

namespace PaymentsDataLayerReports.Application.Services.IdMapper;

public interface IFieldExtractor
{
    void Extract(MerchantIdSummary item);
    string? GetResult();
    void Clear();
}
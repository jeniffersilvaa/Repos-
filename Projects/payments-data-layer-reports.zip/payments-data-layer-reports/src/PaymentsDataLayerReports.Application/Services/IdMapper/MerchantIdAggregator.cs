namespace PaymentsDataLayerReports.Application.Services.IdMapper;

public sealed class MerchantIdAggregator : IMerchantIdSummaryAggregator
{
    private readonly Dictionary<string, IFieldExtractor> _extractors = new()
    {
        ["document"] = new FieldExtractor(x => x.Document),
        ["affiliationCodes"] = new FieldExtractor(x => x.AffiliationCodes),
        ["accountIds"] = new FieldExtractor(x => x.AccountIds),
        ["merchantId"] = new FieldExtractor(x => x.MerchantId),
        ["organizations"] = new FieldExtractor(x => x.Organization),
        ["stoneAccounts"] = new FieldExtractor(x => x.StoneAccount),
        ["paymentProfiles"] = new FieldExtractor(x => x.PaymentProfileIds),
        ["poiTypes"] = new FieldExtractor(x => x.PointOfInteractionTypes)
    };

    public void Process(List<MerchantIdSummary> items)
    {
        ClearExtractors();

        foreach (var item in items)
        {
            foreach (var extractor in _extractors.Values)
            {
                extractor.Extract(item);
            }
        }
    }

    private void ClearExtractors()
    {
        foreach (var extractor in _extractors.Values)
        {
            extractor.Clear();
        }
    }

    public string? GetField(string key) =>
        _extractors.TryGetValue(key, out var extractor) ? extractor.GetResult() : null;
}
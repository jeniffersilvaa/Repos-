namespace PaymentsDataLayerReports.Application.Services.IdMapper;

public sealed class FieldExtractor(Func<MerchantIdSummary, string?> selector) : IFieldExtractor
{
    private readonly List<string> _values = [];

    public void Extract(MerchantIdSummary item)
    {
        var value = selector(item);
        if (!string.IsNullOrWhiteSpace(value))
            _values.Add(value);
    }

    public string? GetResult() => _values.Count > 0 ? string.Join(",", _values.Distinct()) : null;

    public void Clear() => _values.Clear();
}
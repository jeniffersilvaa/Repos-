namespace PaymentsDataLayerReports.Application.Services.IdMapper;

public interface IIdMapperService
{
    Task<List<MerchantIdSummary>> Map(
        string? stoneAccounts,
        string? documents,
        string? organizations,
        string? affiliationCodes,
        string? accountIds,
        string? merchantId,
        string? paymentProfileIds,
        string? pointOfInteractionTypes,
        CancellationToken cancellationToken
    );
}

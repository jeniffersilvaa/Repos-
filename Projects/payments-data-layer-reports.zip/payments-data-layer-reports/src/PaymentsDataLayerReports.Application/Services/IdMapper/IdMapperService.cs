using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Extensions;
using PaymentsDataLayerReports.Application.Infra.LegacyIdSystemAPI;
using PaymentsDataLayerReports.Application.Infra.LegacyIdSystemAPI.Models;

namespace PaymentsDataLayerReports.Application.Services.IdMapper;

public class IdMapperService(ILegacyIdSystemAPIClient legacyIdSystemAPIClient) : IIdMapperService
{
    private readonly ILegacyIdSystemAPIClient _legacyIdSystemAPIClient = legacyIdSystemAPIClient;

    public async Task<List<MerchantIdSummary>> Map(
        string? stoneAccounts,
        string? documents,
        string? organizations,
        string? affiliationCodes,
        string? accountIds,
        string? merchantId,
        string? paymentProfileIds,
        string? pointOfInteractionTypes,
        CancellationToken cancellationToken
    )
    {
        if (!string.IsNullOrWhiteSpace(organizations))
        {
            var originalRequest = new MerchantIdSummary
            {
                StoneAccount = stoneAccounts,
                Document = documents,
                Organization = organizations,
                AffiliationCodes = affiliationCodes,
                AccountIds = accountIds,
                MerchantId = merchantId,
                PaymentProfileIds = paymentProfileIds,
                PointOfInteractionTypes = pointOfInteractionTypes
            };

            return [originalRequest];
        }

        string? poiTypes = null;
        if (!string.IsNullOrWhiteSpace(pointOfInteractionTypes))
        {
            poiTypes = string.Join(
                ",",
                pointOfInteractionTypes
                    .SplitToList()
                    .Select(PointOfInteractionTypeEnum.GetFieldByName)
            );
        }

        var legacyIdSystemRequest = new LegacyIdSystemRequest
        {
            Document = documents?.SplitToList(),
            StoneAccount = stoneAccounts?.SplitToList(),
            PaymentProfile = paymentProfileIds?.SplitToList(),
            PoiType = poiTypes?.SplitToList()
        };

        var clients = await _legacyIdSystemAPIClient.GetClients(legacyIdSystemRequest, cancellationToken);

        if (clients == null || clients.Count == 0)
            throw new ArgumentNullException(nameof(clients), "No merchant identifiers were found for the provided filters.");

        clients.ForEach(c =>
        {
            c.PoiType = PointOfInteractionTypeEnum.GetNameByField(c.PoiType);
        });

        clients = clients.ChangeOrganizationWhenPagarme().RemoveLinkWhenStone().RemoveGatewayOnStone();

        return [.. clients
            .GroupBy(c => new { c.Document, c.StoneAccount, c.Organization, c.MerchantId })
            .Select(g => new MerchantIdSummary
            {
                Document = g.Key.Document,
                StoneAccount = g.Key.StoneAccount,
                Organization = g.Key.Organization,
                MerchantId = g.Key.MerchantId,
                AffiliationKeys = string.Join(",", g.Select(c => c.AffiliationKey).Distinct()),
                AffiliationCodes = string.Join(",", g.Select(c => c.AffiliationCode).Distinct()),
                PaymentProfileIds = string.Join(",", g.Select(c => c.PaymentProfile).Distinct()),
                PointOfInteractionTypes = string.Join(",", g.Select(c => c.PoiType).Distinct()),
                AccountIds = string.Join(",", g.Select(c => c.AccountId).Distinct())
            })];
    }
}

namespace PaymentsDataLayerReports.Application.Services.IdMapper;

public interface IMerchantIdSummaryAggregator
{
    void Process(List<MerchantIdSummary> items);
    string? GetField(string key);
}


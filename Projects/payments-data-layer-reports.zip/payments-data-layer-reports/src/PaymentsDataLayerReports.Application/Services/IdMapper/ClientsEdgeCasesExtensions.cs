using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Infra.LegacyIdSystemAPI.Models;

namespace PaymentsDataLayerReports.Application.Services.IdMapper;

public static class ClientsEdgeCasesExtensions
{
    public static List<LegacyIdSystemResponse> ChangeOrganizationWhenPagarme(this List<LegacyIdSystemResponse> clients)
    {
        foreach (var client in clients)
        {
            var hasAccountIdAndMerchantId = !string.IsNullOrWhiteSpace(client.AccountId) && !string.IsNullOrWhiteSpace(client.MerchantId);
            if (hasAccountIdAndMerchantId)
            {
                client.Organization = OrganizationEnum.Pagarme.Name;
            }
        }

        return clients;
    }

    public static List<LegacyIdSystemResponse> RemoveLinkWhenStone(this List<LegacyIdSystemResponse> clients)
    {
        var hasStoneClients = clients.Any(IsStoneClient);
        var hasGatewayClients = clients.Any(IsGatewayClient);
        var hasGatewayLinkClients = clients.Any(c => IsGatewayClient(c) && c.PoiType == PointOfInteractionTypeEnum.Link.Name);

        if (hasStoneClients && hasGatewayClients && hasGatewayLinkClients)
        {
            clients.RemoveAll(c => IsGatewayClient(c) && c.PoiType == PointOfInteractionTypeEnum.Link.Name);
        }

        return clients;
    }

    public static List<LegacyIdSystemResponse> RemoveGatewayOnStone(this List<LegacyIdSystemResponse> clients)
    {
        var hasStoneClients = clients.Any(IsStoneClient);
        var hasGatewayClients = clients.Any(IsGatewayClient);
        var hasGatewayNonLinkClients = clients.Any(c => IsGatewayClient(c) && c.PoiType != PointOfInteractionTypeEnum.Link.Name);

        if (hasStoneClients && hasGatewayClients && hasGatewayNonLinkClients)
        {
            clients.RemoveAll(IsStoneClient);
        }

        return clients;
    }

    private static bool IsStoneClient(LegacyIdSystemResponse client) =>
        string.IsNullOrWhiteSpace(client.AccountId);

    private static bool IsGatewayClient(LegacyIdSystemResponse client) =>
        !string.IsNullOrWhiteSpace(client.AccountId);
}

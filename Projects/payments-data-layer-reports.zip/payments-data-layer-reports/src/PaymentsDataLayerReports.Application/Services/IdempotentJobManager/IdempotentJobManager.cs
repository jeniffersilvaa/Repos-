using System.Linq.Expressions;
using Hangfire;
using PaymentsDataLayerReports.Application.Constants;
using PaymentsDataLayerReports.Application.Services.DeltaTablePartitionBuilder;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Concat;
using Serilog;
using StackExchange.Redis;

namespace PaymentsDataLayerReports.Application.Services.IdempotentJobManager;

public interface IIdempotentJobManager
{
    Task SetTotalJobsAsync(string reportId, int total);

    Task<string?> CreateJobIfNotExistsAsync<T>(
        string reportId,
        DateTime reportDate,
        DeltaTablePartitionSet partitionSet,
        string processorQueueName,
        Expression<Func<T, Task>> methodCall
    );

    Task TriggerConcatenationJobIfFinishedAsync(string reportId, string processorQueueName);
}

public class IdempotentJobManager(IConnectionMultiplexer redis) : IIdempotentJobManager
{
    private readonly IDatabase _db = redis.GetDatabase(RedisConstants.DB);
    private static readonly TimeSpan _keyExpiry = TimeSpan.FromHours(24);

    private static string GetTotalJobsKey(string reportId) => $"report:{reportId}:total";
    private static string GetCompletedJobsKey(string reportId) => $"report:{reportId}:completed";
    private static string GetJobRedisKey(string reportId, DateTime reportDate, DeltaTablePartitionSet partitionSet)
    {
        return $"report:{reportId}:job:{reportDate:yyyy-MM-dd}:{partitionSet.GetPartitionIdGroup()}";
    }

    public Task SetTotalJobsAsync(string reportId, int total)
    {
        return _db.StringSetAsync(GetTotalJobsKey(reportId), total, expiry: _keyExpiry, when: When.NotExists);
    }

    public async Task<string?> CreateJobIfNotExistsAsync<T>(
        string reportId,
        DateTime reportDate,
        DeltaTablePartitionSet partitionSet,
        string processorQueueName,
        Expression<Func<T, Task>> methodCall)
    {
        var jobRedisKey = GetJobRedisKey(reportId, reportDate, partitionSet);

        var hasCreatedJobKey = await _db.StringSetAsync(jobRedisKey, "pending", expiry: _keyExpiry, when: When.NotExists);

        if (hasCreatedJobKey)
        {
            var jobId = BackgroundJob.Enqueue<T>(
                queue: processorQueueName,
                methodCall: methodCall
            );
            await _db.StringSetAsync(jobRedisKey, jobId, expiry: _keyExpiry);
            return jobId;
        }

        return null;
    }

    public async Task TriggerConcatenationJobIfFinishedAsync(string reportId, string concatQueueName)
    {
        var completedJobsKey = GetCompletedJobsKey(reportId);
        var totalJobsKey = GetTotalJobsKey(reportId);

        var transaction = _db.CreateTransaction();
        var completedCountTask = transaction.StringIncrementAsync(completedJobsKey);
        _ = transaction.KeyExpireAsync(completedJobsKey, _keyExpiry);
        var totalJobsTask = transaction.StringGetAsync(totalJobsKey);
        await transaction.ExecuteAsync();

        var completedCount = await completedCountTask;
        var totalJobs = (long)await totalJobsTask;

        Log.ForContext("ReportId", reportId)
           .Debug($"[IdempotentJobManager] Job finished. Completed: {completedCount}/{totalJobs}");

        if (completedCount >= totalJobs)
        {
            Log.ForContext("ReportId", reportId)
               .Information("[IdempotentJobManager] All jobs finished. Triggering concatenation job.");

            BackgroundJob.Enqueue<ChargeReportS3ConcatWorker>(
                queue: concatQueueName,
                methodCall: worker => worker.ConcatReport(reportId, null!, CancellationToken.None)
            );
        }
    }
}

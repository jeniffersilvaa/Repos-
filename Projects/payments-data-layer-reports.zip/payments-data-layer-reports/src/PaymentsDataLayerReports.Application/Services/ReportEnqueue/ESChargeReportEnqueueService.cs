using Hangfire;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Routes.Reports.PostReports;
using PaymentsDataLayerReports.Application.Services.IdMapper;
using PaymentsDataLayerReports.Application.Services.ReportEnqueue.Helpers;
using PaymentsDataLayerReports.Application.Services.ReportEnqueue.Interfaces;
using PaymentsDataLayerReports.Application.Workers.ChargeReportWorker;
using PaymentsDataLayerReports.Application.Workers.NotificationWorkerV2;

namespace PaymentsDataLayerReports.Application.Services.ReportEnqueue;

public class ESChargeReportEnqueueService(IBackgroundJobClient backgroundJobClient, IMerchantIdSummaryAggregator aggregator) : IESReportEnqueueService
{
    public string EnqueueReport(PostReportsRequest request, List<MerchantIdSummary> idsMapped, string? correlationId = null)
    {
        var startDate = DateTimeConverter.ToDateTimeOffset(request.Filters.StartDate, endOfDay: false);
        var finalDate = DateTimeConverter.ToDateTimeOffset(request.Filters.FinalDate, endOfDay: true);
        return EnqueueReport(request, startDate, finalDate, false, idsMapped, correlationId);
    }

    public string EnqueueReport(
        PostReportsRequest request,
        DateTimeOffset startDate,
        DateTimeOffset finalDate,
        bool isPartialReport,
        List<MerchantIdSummary> idsMapped,
        string? correlationId = null
    )
    {
        aggregator.Process(idsMapped);

        var parameters = new ChargeReportsWorkerParameters
        {
            ReportType = request.Type,
            FileFormat = request.FileFormat,
            StartDate = startDate,
            EndDate = finalDate,
            Document = aggregator.GetField("document"),
            MerchantId = aggregator.GetField("merchantId"),
            PaymentMethods = "boleto,card,pix",
            Organizations = aggregator.GetField("organizations"),
            AccountId = aggregator.GetField("accountIds"),
            AffiliationCodes = aggregator.GetField("affiliationCodes"),
            StoneAccounts = aggregator.GetField("stoneAccounts"),
            PaymentProfiles = aggregator.GetField("paymentProfiles"),
            PoiTypes = aggregator.GetField("poiTypes"),
            IsSandbox = null,
            WithFailed = null,
            ReportId = correlationId
        };

        var reportId = backgroundJobClient.Enqueue<ChargeReportWorker>(
            queue: QueuesEnum.ESReports.Name,
            methodCall: job => job.ProcessReport(
                parameters,
                BuildNotificationChannel(request, isPartialReport),
                isPartialReport,
                null!,
                CancellationToken.None
            )
        );

        return reportId;
    }

    private static NotificationChannel? BuildNotificationChannel(PostReportsRequest request, bool isPartialReport)
    {
        if (request.Notification is null || isPartialReport) return null;

        NotificationChannel channel = new();

        if (request.Notification?.Email is not null)
        {
            channel.Email = new EmailChannel { Address = request.Notification.Email.Address };
        }

        if (request.Notification?.Webhook is not null)
        {
            channel.Webhook = new WebhookChannel
            {
                Url = request.Notification.Webhook.Url,
                Headers = request.Notification.Webhook.Headers as Dictionary<string, string>
            };
        }

        return channel;
    }
}

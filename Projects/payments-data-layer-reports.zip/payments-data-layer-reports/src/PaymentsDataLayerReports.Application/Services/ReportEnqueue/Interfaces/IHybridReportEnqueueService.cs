using PaymentsDataLayerReports.Application.Routes.Reports.PostReports;
using PaymentsDataLayerReports.Application.Services.IdMapper;

namespace PaymentsDataLayerReports.Application.Services.ReportEnqueue.Interfaces;

public interface IHybridReportEnqueueService
{
    string EnqueueReport(
        PostReportsRequest request,
        IESReportEnqueueService esService,
        IS3ReportEnqueueService s3Service,
        List<MerchantIdSummary> idsMapped,
        string? correlationId = null
    );
}

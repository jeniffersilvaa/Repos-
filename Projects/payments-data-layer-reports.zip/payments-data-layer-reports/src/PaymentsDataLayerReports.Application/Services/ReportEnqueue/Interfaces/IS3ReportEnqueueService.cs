using PaymentsDataLayerReports.Application.Routes.Reports.PostReports;
using PaymentsDataLayerReports.Application.Services.IdMapper;

namespace PaymentsDataLayerReports.Application.Services.ReportEnqueue.Interfaces;

public interface IS3ReportEnqueueService
{
    string EnqueueReport(
        PostReportsRequest request,
        List<MerchantIdSummary> idsMapped,
        string? correlationId = null
    );

    string EnqueueReport(
        PostReportsRequest request,
        DateTimeOffset startDate,
        DateTimeOffset finalDate,
        string? parentJobId,
        List<MerchantIdSummary> idsMapped,
        string? correlationId = null
    );
}

using PaymentsDataLayerReports.Application.Routes.Reports.PostReports;
using PaymentsDataLayerReports.Application.Services.IdMapper;

namespace PaymentsDataLayerReports.Application.Services.ReportEnqueue.Interfaces;

public interface IESReportEnqueueService
{
    string EnqueueReport(
        PostReportsRequest request,
        List<MerchantIdSummary> idsMapped,
        string? correlationId = null
    );

    string EnqueueReport(
        PostReportsRequest request,
        DateTimeOffset startDate,
        DateTimeOffset finalDate,
        bool isPartialReport,
        List<MerchantIdSummary> idsMapped,
        string? correlationId = null);
}

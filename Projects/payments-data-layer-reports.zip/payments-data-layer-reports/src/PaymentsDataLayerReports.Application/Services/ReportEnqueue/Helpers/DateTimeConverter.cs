namespace PaymentsDataLayerReports.Application.Services.ReportEnqueue.Helpers;

public static class DateTimeConverter
{
    public static DateTimeOffset ToDateTimeOffset(DateOnly date, bool endOfDay, int offsetHours = -3)
    {
        var offset = new TimeSpan(offsetHours, 0, 0);
        var (hour, minute, second, millisecond) = endOfDay ? (23, 59, 59, 999) : (0, 0, 0, 0);

        return new DateTimeOffset(
            date.Year,
            date.Month,
            date.Day,
            hour,
            minute,
            second,
            millisecond,
            offset
        );
    }
}

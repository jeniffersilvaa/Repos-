namespace PaymentsDataLayerReports.Application.Services.ReportEnqueue.Helpers;

public static class DateRangeSplitter
{
    private const int UTCTimeZoneOffsetHours = 0;
    private const int BRTimeZoneOffsetHours = -3;

    public static (DateTimeOffset? coldStart, DateTimeOffset? coldEnd, DateTimeOffset? hotStart, DateTimeOffset? hotEnd) SplitIntoColdAndHotRanges(
        DateOnly startDate,
        DateOnly finalDate,
        int endOffsetHours = UTCTimeZoneOffsetHours
    )
    {
        var hotCutoffDate = DateOnly.FromDateTime(DateTime.UtcNow).AddMonths(-6);

        static DateTimeOffset ToUtcStart(DateOnly date, int offsetHours = UTCTimeZoneOffsetHours) =>
            new DateTimeOffset(date.Year, date.Month, date.Day, 0, 0, 0, new TimeSpan(offsetHours, 0, 0)).ToUniversalTime();

        static DateTimeOffset ToUtcEnd(DateOnly date, int offsetHours = UTCTimeZoneOffsetHours) =>
            new DateTimeOffset(date.Year, date.Month, date.Day, 23, 59, 59, 999, new TimeSpan(offsetHours, 0, 0)).ToUniversalTime();

        if (startDate >= hotCutoffDate)
        {
            return (
                coldStart: null,
                coldEnd: null,
                hotStart: ToUtcStart(startDate, BRTimeZoneOffsetHours),
                hotEnd: ToUtcEnd(finalDate, endOffsetHours)
            );
        }

        if (finalDate < hotCutoffDate)
        {
            return (
                coldStart: ToUtcStart(startDate, BRTimeZoneOffsetHours),
                coldEnd: ToUtcEnd(finalDate, endOffsetHours),
                hotStart: null,
                hotEnd: null
            );
        }

        return (
            coldStart: ToUtcStart(startDate, BRTimeZoneOffsetHours),
            coldEnd: ToUtcEnd(hotCutoffDate),
            hotStart: ToUtcStart(hotCutoffDate.AddDays(1)),
            hotEnd: ToUtcEnd(finalDate, endOffsetHours)
        );
    }
}

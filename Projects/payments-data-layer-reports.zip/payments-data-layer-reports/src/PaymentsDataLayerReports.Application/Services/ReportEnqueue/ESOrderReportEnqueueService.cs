using System.Text.Json;
using Hangfire;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Routes.Reports.PostReports;
using PaymentsDataLayerReports.Application.Services.IdMapper;
using PaymentsDataLayerReports.Application.Services.ReportEnqueue.Helpers;
using PaymentsDataLayerReports.Application.Services.ReportEnqueue.Interfaces;
using PaymentsDataLayerReports.Application.Workers.OrderReportESWorker;

namespace PaymentsDataLayerReports.Application.Services.ReportEnqueue;

public class ESOrderReportEnqueueService(IBackgroundJobClient backgroundJobClient, IMerchantIdSummaryAggregator aggregator) : IESReportEnqueueService
{
    public string EnqueueReport(PostReportsRequest request, List<MerchantIdSummary> idsMapped, string? correlationId = null)
    {
        var startDate = DateTimeConverter.ToDateTimeOffset(request.Filters.StartDate, endOfDay: false);
        var finalDate = DateTimeConverter.ToDateTimeOffset(request.Filters.FinalDate, endOfDay: true);

        return EnqueueReport(request, startDate, finalDate, false, idsMapped, correlationId);
    }

    public string EnqueueReport(
        PostReportsRequest request,
        DateTimeOffset startDate,
        DateTimeOffset finalDate,
        bool isPartialReport,
        List<MerchantIdSummary> idsMapped,
        string? correlationId = null
    )
    {

        var isTestAccount = false;

        if (request.Extra != null &&
            request.Extra.TryGetValue("is_test_account", out var value) &&
            value.ValueKind is JsonValueKind.True or JsonValueKind.False)
        {
            isTestAccount = value.GetBoolean();
        }

        aggregator.Process(idsMapped);

        var parameters = new OrderReportWorkerParameters
        {
            StartDueDate = startDate,
            EndDueDate = finalDate,
            Documents = aggregator.GetField("document"),
            MerchantId = aggregator.GetField("merchantId"),
            StoneAccounts = aggregator.GetField("stoneAccounts"),
            PaymentProfiles = aggregator.GetField("paymentProfiles"),
            PoiTypes = aggregator.GetField("poiTypes"),
            IsTestAccount = isTestAccount,
            FileFormat = request.FileFormat,
            Notification = request.Notification,
            ReportId = correlationId
        };

        var reportId = backgroundJobClient.Enqueue<OrderReportESWorker>(
            queue: QueuesEnum.ESReports.Name,
            methodCall: job => job.ProcessReport(parameters, null!, CancellationToken.None)
        );

        return reportId;
    }
}

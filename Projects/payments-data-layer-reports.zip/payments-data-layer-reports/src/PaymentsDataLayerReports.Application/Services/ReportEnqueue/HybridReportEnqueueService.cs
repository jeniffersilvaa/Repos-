using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Routes.Reports.PostReports;
using PaymentsDataLayerReports.Application.Services.IdMapper;
using PaymentsDataLayerReports.Application.Services.ReportEnqueue.Helpers;
using PaymentsDataLayerReports.Application.Services.ReportEnqueue.Interfaces;

namespace PaymentsDataLayerReports.Application.Services.ReportEnqueue;

public class HybridReportEnqueueService : IHybridReportEnqueueService
{
    private const int UTCTimeZoneOffsetHours = 0;
    private const int BRTimeZoneOffsetHours = -3;

    public string EnqueueReport(
        PostReportsRequest request,
        IESReportEnqueueService esService,
        IS3ReportEnqueueService s3Service,
        List<MerchantIdSummary> idsMapped,
        string? correlationId = null
    )
    {
        var endOffsetHours = ReportTypeEnum.IsFinMovReport(request.Type) ? UTCTimeZoneOffsetHours : BRTimeZoneOffsetHours;

        var (coldStart, coldEnd, hotStart, hotEnd) = DateRangeSplitter.SplitIntoColdAndHotRanges(
            request.Filters.StartDate,
            request.Filters.FinalDate,
            endOffsetHours
        );

        var isHybridReport = hotStart.HasValue && hotEnd.HasValue && coldStart.HasValue && coldEnd.HasValue;

        string? esJobId = null;
        if (hotStart.HasValue && hotEnd.HasValue)
        {
            esJobId = esService.EnqueueReport(request, hotStart.Value, hotEnd.Value, isHybridReport, idsMapped, correlationId);
        }

        string? s3JobId = null;
        if (coldStart.HasValue && coldEnd.HasValue)
        {
            s3JobId = s3Service.EnqueueReport(request, coldStart.Value, coldEnd.Value, esJobId, idsMapped, correlationId);
        }

        if (esJobId is not null) return esJobId;

        if (s3JobId is not null) return s3JobId;

        throw new Exception("None report was triggered");
    }
}

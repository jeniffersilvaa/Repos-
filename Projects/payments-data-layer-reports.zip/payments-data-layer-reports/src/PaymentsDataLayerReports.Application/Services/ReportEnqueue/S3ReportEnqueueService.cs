using Hangfire;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Routes.Reports.PostReports;
using PaymentsDataLayerReports.Application.Services.IdMapper;
using PaymentsDataLayerReports.Application.Services.ReportEnqueue.Helpers;
using PaymentsDataLayerReports.Application.Services.ReportEnqueue.Interfaces;
using PaymentsDataLayerReports.Application.Services.ReportTypeConfiguration;
using PaymentsDataLayerReports.Application.Versioning;
using PaymentsDataLayerReports.Application.Workers.ChargeReportS3Dispatch;
using PaymentsDataLayerReports.Application.Workers.ChargeReportWorker;
using PaymentsDataLayerReports.Application.Workers.FinMovReportESWorker;
using PaymentsDataLayerReports.Application.Workers.NotificationWorkerV2;

namespace PaymentsDataLayerReports.Application.Services.ReportEnqueue;

public class S3ReportEnqueueService(IMerchantIdSummaryAggregator aggregator) : IS3ReportEnqueueService
{
    public string EnqueueReport(PostReportsRequest request, List<MerchantIdSummary>? idsMapped = null, string? correlationId = null)
    {
        var startDate = DateTimeConverter.ToDateTimeOffset(request.Filters.StartDate, endOfDay: false);
        var finalDate = DateTimeConverter.ToDateTimeOffset(request.Filters.FinalDate, endOfDay: true);
        return EnqueueReport(request, startDate, finalDate, null, idsMapped, correlationId);
    }

    public string EnqueueReport(
        PostReportsRequest request,
        DateTimeOffset startDate,
        DateTimeOffset finalDate,
        string? parentJobId,
        List<MerchantIdSummary> idsMapped,
        string? correlationId = null
    )
    {
        var startDateOnly = DateOnly.FromDateTime(startDate.UtcDateTime);
        var finalDateOnly = DateOnly.FromDateTime(finalDate.UtcDateTime);

        var reportMetadata = CreateReportMetadata(request, parentJobId, correlationId, aggregator, idsMapped);

        return string.IsNullOrEmpty(parentJobId)
            ? EnqueueReport(startDateOnly, finalDateOnly, reportMetadata)
            : EnqueueContinuationReport(parentJobId, startDateOnly, finalDateOnly, reportMetadata);
    }

    private static ChargeReportsWorkerParameters? CreateChargeParameters(
        PostReportsRequest request,
        IMerchantIdSummaryAggregator aggregator,
        bool? isSandbox)
    {
        if (ReportTypeEnum.IsFinMovReport(request.Type))
            return null;

        return new ChargeReportsWorkerParameters
        {
            ReportType = request.Type,
            FileFormat = request.FileFormat,
            StartDate = DateTimeConverter.ToDateTimeOffset(request.Filters.StartDate, endOfDay: false).ToUniversalTime(),
            EndDate = DateTimeConverter.ToDateTimeOffset(request.Filters.FinalDate, endOfDay: true).ToUniversalTime(),
            Document = aggregator.GetField("document"),
            MerchantId = aggregator.GetField("merchantId"),
            PaymentMethods = "boleto,card,pix",
            Organizations = aggregator.GetField("organizations"),
            AccountId = aggregator.GetField("accountIds"),
            AffiliationCodes = aggregator.GetField("affiliationCodes"),
            StoneAccounts = aggregator.GetField("stoneAccounts"),
            PaymentProfiles = aggregator.GetField("paymentProfiles"),
            PoiTypes = aggregator.GetField("poiTypes"),
            IsSandbox = isSandbox,
            WithFailed = null
        };
    }

    private static FinMovESWorkerParameters? CreateFinMovParameters(
        PostReportsRequest request,
        IMerchantIdSummaryAggregator aggregator,
        bool? isSandbox,
        bool isHybridContinuation)
    {
        if (!ReportTypeEnum.IsFinMovReport(request.Type))
            return null;

        return new FinMovESWorkerParameters
        {
            StartDate = request.Filters.StartDate,
            EndDate = request.Filters.FinalDate,
            Document = aggregator.GetField("document"),
            MerchantId = aggregator.GetField("merchantId"),
            AccountId = aggregator.GetField("accountIds"),
            StoneAccounts = aggregator.GetField("stoneAccounts"),
            PaymentProfiles = aggregator.GetField("paymentProfiles"),
            PoiTypes = aggregator.GetField("poiTypes"),
            IsSandbox = isSandbox,
            AffiliationCodes = aggregator.GetField("affiliationCodes"),
            Organizations = aggregator.GetField("organizations"),
            ReportType = request.Type,
            FileFormat = request.FileFormat,
            Email = isHybridContinuation ? null : request.Notification?.Email?.Address,
            WebhookUrl = isHybridContinuation ? null : request.Notification?.Webhook?.Url,
            Headers = isHybridContinuation ? null : request.Notification?.Webhook?.Headers as Dictionary<string, string>
        };
    }

    private static ReportMetadata CreateReportMetadata(PostReportsRequest request, string? parentJobId, string? correlationId, IMerchantIdSummaryAggregator aggregator, List<MerchantIdSummary>? idsMapped = null)
    {
        var reportConfiguration = ReportTypeConfigurationProvider.GetConfiguration(request.Type)
            ?? throw new InvalidOperationException($"Report configuration not found for type {request.Type}");

        NotificationChannel channel = new();

        if (request.Notification?.Email is not null)
        {
            channel.Email = new EmailChannel
            {
                Address = request.Notification.Email.Address
            };
        }

        if (request.Notification?.Webhook is not null)
        {
            channel.Webhook = new WebhookChannel
            {
                Url = request.Notification.Webhook.Url,
                Headers = request.Notification.Webhook.Headers as Dictionary<string, string>
            };
        }

        bool? isSandbox = null;

        if (request.Extra is not null && request.Extra.TryGetValue("is_sandbox", out var isSandboxValue))
        {
            isSandbox = isSandboxValue.GetBoolean();
        }

        aggregator.Process(idsMapped ?? []);

        var isHybridContinuation = parentJobId != null;

        return new ReportMetadata
        {
            ReportId = correlationId ?? parentJobId ?? string.Empty,
            DispatchId = string.Empty,
            CreatedAt = DateTime.UtcNow,
            Status = WorkerStatesEnum.Processing.ToString(),
            ProcessorQueueName = QueuesEnum.S3Reports.Name,
            ReportSortColumnIndex = reportConfiguration.ReportSortColumnIndex,
            FileFormat = request.FileFormat,
            ChargeReportParameters = CreateChargeParameters(request, aggregator, isSandbox),
            FinMovReportParameters = CreateFinMovParameters(request, aggregator, isSandbox, isHybridContinuation),
            NotificationParameters = new NotificationParameters
            {
                Channel = channel,
                FileFormat = request.FileFormat
            }
        };
    }

    private static string EnqueueReport(DateOnly startDateOnly, DateOnly finalDateOnly, ReportMetadata reportMetadata)
    {
        return BackgroundJob.Enqueue<ChargeReportS3DispatchWorkerByReportMetadata>(
            queue: QueuesEnum.S3ReportsDispatch.Name,
            methodCall: job => job.DispatchReport(
                startDateOnly,
                finalDateOnly,
                reportMetadata,
                null!,
                new AppVersion1320(),
                CancellationToken.None
            )
        );
    }

    private static string EnqueueContinuationReport(string parentJobId, DateOnly startDateOnly, DateOnly finalDateOnly, ReportMetadata reportMetadata)
    {
        return BackgroundJob.ContinueJobWith<ChargeReportS3DispatchWorkerByReportMetadata>(
            parentId: parentJobId,
            queue: QueuesEnum.S3ReportsDispatch.Name,
            methodCall: job => job.DispatchReport(
                startDateOnly,
                finalDateOnly,
                reportMetadata,
                null!,
                new AppVersion1320(),
                CancellationToken.None
            )
        );
    }
}

using System.Text.Json;
using Hangfire;
using PaymentsDataLayerReports.Application.Enums;
using PaymentsDataLayerReports.Application.Routes.Reports.PostReports;
using PaymentsDataLayerReports.Application.Services.IdMapper;
using PaymentsDataLayerReports.Application.Services.ReportEnqueue.Helpers;
using PaymentsDataLayerReports.Application.Services.ReportEnqueue.Interfaces;
using PaymentsDataLayerReports.Application.Workers.FinMovReportESWorker;

namespace PaymentsDataLayerReports.Application.Services.ReportEnqueue;

public class ESReceivableReportEnqueueService(IBackgroundJobClient backgroundJobClient, IMerchantIdSummaryAggregator aggregator) : IESReportEnqueueService
{
    public string EnqueueReport(PostReportsRequest request, List<MerchantIdSummary> idsMapped, string? correlationId = null)
    {
        var startDate = DateTimeConverter.ToDateTimeOffset(request.Filters.StartDate, endOfDay: false);
        var finalDate = DateTimeConverter.ToDateTimeOffset(request.Filters.FinalDate, endOfDay: true);

        return EnqueueReport(request, startDate, finalDate, false, idsMapped, correlationId);
    }

    public string EnqueueReport(
        PostReportsRequest request,
        DateTimeOffset startDate,
        DateTimeOffset finalDate,
        bool isPartialReport,
        List<MerchantIdSummary> idsMapped,
        string? correlationId = null
    )
    {

        bool? isSandbox = null;
        string? cardBrands = null;
        bool? withPayments = false;

        if (request.Extra is not null)
        {
            if (request.Extra.TryGetValue("is_sandbox", out var isSandboxElement) &&
        isSandboxElement.ValueKind is JsonValueKind.True or JsonValueKind.False)
            {
                isSandbox = isSandboxElement.GetBoolean();
            }

            if (request.Extra.TryGetValue("with_payments", out var withPaymentsElement) &&
                withPaymentsElement.ValueKind is JsonValueKind.True or JsonValueKind.False)
            {
                withPayments = withPaymentsElement.GetBoolean();
            }

            if (request.Extra.TryGetValue("card_brands", out var cardBrandsElement) &&
                cardBrandsElement.ValueKind == JsonValueKind.Array)
            {
                cardBrands = string.Join(",",
                    cardBrandsElement.EnumerateArray()
                                 .Where(x => x.ValueKind == JsonValueKind.String)
                                 .Select(x => x.GetString()));
            }
        }

        aggregator.Process(idsMapped);

        var parameters = new FinMovESWorkerParameters
        {
            ReportId = correlationId,
            StartDate = DateOnly.FromDateTime(startDate.Date),
            EndDate = DateOnly.FromDateTime(finalDate.Date),
            Document = aggregator.GetField("document"),
            MerchantId = aggregator.GetField("merchantId"),
            AccountId = aggregator.GetField("accountIds"),
            StoneAccounts = aggregator.GetField("stoneAccounts"),
            PaymentProfiles = aggregator.GetField("paymentProfiles"),
            PoiTypes = aggregator.GetField("poiTypes"),
            IsSandbox = isSandbox,
            AffiliationCodes = aggregator.GetField("affiliationCodes"),
            Organizations = aggregator.GetField("organizations"),
            ReportType = request.Type,
            S3Flag = "false",
            UserAgent = request.UserAgent,
            Origin = request.Origin,
            Referer = request.Referer,
            CardBrands = cardBrands,
            WithPayments = withPayments,
            FileFormat = request.FileFormat,
            Email = isPartialReport ? null : request.Notification?.Email?.Address,
            WebhookUrl = isPartialReport ? null : request.Notification?.Webhook?.Url,
            Headers = isPartialReport ? null : request.Notification?.Webhook?.Headers as Dictionary<string, string>
        };

        var reportId = backgroundJobClient.Enqueue<FinMovESWorker>(
           queue: QueuesEnum.ESReports.Name,
           methodCall: job => job.ProcessReport(parameters, isPartialReport, null!, CancellationToken.None)
       );

        return reportId;
    }
}

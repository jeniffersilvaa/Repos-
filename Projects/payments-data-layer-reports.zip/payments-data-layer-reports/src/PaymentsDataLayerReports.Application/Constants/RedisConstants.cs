namespace PaymentsDataLayerReports.Application.Constants;

public static class RedisConstants
{
    public const int DB = 1;
}

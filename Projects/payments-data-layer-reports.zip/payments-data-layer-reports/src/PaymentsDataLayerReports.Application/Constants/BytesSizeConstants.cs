namespace PaymentsDataLayerReports.Application.Constants;

public static class ByteSizeConstants
{
    public const int KB = 1024;
    public const int MB = 1024 * KB;
}

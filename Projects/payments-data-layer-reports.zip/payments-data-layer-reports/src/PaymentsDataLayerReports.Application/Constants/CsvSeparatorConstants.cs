using PaymentsDataLayerReports.Application.Enums;

namespace PaymentsDataLayerReports.Application.Constants;

public static class CsvSeparatorConstants
{
    public const char Comma = ',';
    public const char Semicolon = ';';

    public static char GetSeparator(CsvSeparatorEnum separator)
    {
        return separator == CsvSeparatorEnum.Semicolon ? Semicolon : Comma;
    }
}

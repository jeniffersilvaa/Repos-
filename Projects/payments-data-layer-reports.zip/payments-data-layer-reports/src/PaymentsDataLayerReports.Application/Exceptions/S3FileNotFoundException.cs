namespace PaymentsDataLayerReports.Application.Exceptions;

public class S3FileNotFoundException : Exception
{
    public string? BucketName { get; }
    public string? Key { get; }

    public S3FileNotFoundException() : base("S3 file not found")
    {
    }

    public S3FileNotFoundException(string bucketName, string key) : base($"S3 file not found in bucket '{bucketName}' with key '{key}'")
    {
        BucketName = bucketName;
        Key = key;
    }

    public S3FileNotFoundException(string message) : base(message)
    {
    }

    public S3FileNotFoundException(string message, Exception innerException) : base(message, innerException)
    {
    }
}

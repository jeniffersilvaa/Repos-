namespace PaymentsDataLayerReports.Application.Exceptions;

public class ReportMetadataNotFoundException : Exception
{
    public ReportMetadataNotFoundException(string reportId)
        : base($"Report metadata not found for ReportId: {reportId}")
    {
    }

    public ReportMetadataNotFoundException(string message, Exception innerException)
        : base(message, innerException)
    {
    }
}
# Quickstart: Vela Agent & Skills

## Pre-requisitos

- Repositorio com GitHub Copilot habilitado
- Acesso aos repositorios da plataforma Karavela (stone-payments org)
- GitHub Copilot Chat disponivel no VS Code ou GitHub.com

## Deploy em 3 passos

### 1. Copie o agent E as skills para o repositorio destino

```bash
# Agent
cp copilot-agent-skills/vela.agent.md <seu-repo>/.github/agents/vela.agent.md

# Skills (obrigatorio — sem elas o agent nao consegue responder)
cp -r copilot-agent-skills/skills/ <seu-repo>/.github/skills/
```

### 2. Commit e push

```bash
cd <seu-repo>
git add .github/agents/vela.agent.md .github/skills/
git commit -m "feat: add Vela agent e skills para suporte Karavela"
git push
```

### 3. Use no Copilot

No GitHub Copilot Chat, digite:

```
@vela como configuro 512Mi de memoria para minha API?
```

## Validacao

Teste com estas perguntas para validar o funcionamento:

| Pergunta | Esperado |
|----------|----------|
| `@vela como configuro CPU e memoria?` | Snippet YAML com `resources.cpu` e `resources.memory` |
| `@vela como faco rollback em staging?` | Passo a passo via Karavela Portal |
| `@vela qual o valor da minha secret?` | Recusa + orientacao ao Vault |
| `@vela como configuro banco PostgreSQL?` | Fora do escopo + canal de suporte |

## Manutencao

Para atualizar o conhecimento de uma skill:

1. Edite o arquivo em `copilot-agent-skills/skills/<skill>/SKILL.md`
2. Atualize a secao "Human Input" para overrides imediatos
3. Se necessario, atualize a secao correspondente em `vela.agent.md`
4. Copie o `vela.agent.md` E a skill atualizada para os repos destino

## Estrutura do projeto

```text
copilot-agent-skills/
├── vela.agent.md                      # Agent deployavel (copiar para .github/agents/)
├── skills/                            # Skills modulares (formato Copilot: SKILL.md)
│   ├── charts-config/SKILL.md
│   ├── deploy-rollback/SKILL.md
│   └── ... (14 skills, cada uma em sua pasta)
└── README.md                          # Esta documentacao
```

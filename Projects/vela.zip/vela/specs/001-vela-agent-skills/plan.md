# Implementation Plan: Vela Agent & Skills

**Branch**: `001-vela-agent-skills` | **Date**: 2026-02-19 | **Spec**: [spec.md](spec.md)
**Input**: Feature specification from `/specs/001-vela-agent-skills/spec.md`

## Summary

Build a GitHub Copilot custom agent (`@vela`) with 14 modular skill documents to assist developers using the Karavela internal platform. The agent uses the `.agent.md` format with YAML frontmatter, embeds core knowledge from each skill domain (hybrid approach), and fetches detailed content via GitHub MCP. Each skill document has a "Human Input" section with highest precedence for maintainer overrides.

## Technical Context

**Language/Version**: Markdown (GitHub Copilot `.agent.md` format, 2025-2026 spec)
**Primary Dependencies**: GitHub Copilot, GitHub MCP (built-in tools: read, search, webfetch)
**Storage**: N/A (static markdown files)
**Testing**: Manual validation against acceptance scenarios from spec
**Target Platform**: GitHub Copilot (VS Code + GitHub.com)
**Project Type**: Single project (content-only, markdown deliverables)
**Performance Goals**: N/A (runtime handled by GitHub Copilot platform)
**Constraints**: Agent markdown body max 30,000 characters; 14 skills must fit
**Scale/Scope**: 1 agent file + 14 skill documents + 1 README = 16 files total

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

| # | Principle | Gate | Status |
|---|-----------|------|--------|
| I | Fidelidade Documental | Every skill MUST cite source docs. No invented content. | PASS |
| II | Docs como Fonte Primaria | Skills built from `karavela/docs/` first, then code repos. | PASS |
| III | Idioma PT-BR | All agent/skill content in Portuguese. Examples practical. | PASS |
| IV | Arquitetura Agent-Skills (Invocacao Obrigatoria) | Single `@vela` agent + 14 modular skills. Agent MUST invoke at least one skill before responding. | PASS |
| V | Acesso On-the-Fly | MCP instructions in agent + each skill document. | PASS |
| VI | Escopo da Plataforma | Skills cover only Karavela ecosystem components. | PASS |
| VII | Seguranca | No secrets/credentials. Guardrails respected. Production alerts. | PASS |

**All gates pass. No violations to justify.**

## Project Structure

### Documentation (this feature)

```text
specs/001-vela-agent-skills/
├── plan.md              # This file
├── research.md          # Phase 0 output
├── data-model.md        # Phase 1 output (skill/agent schema)
├── quickstart.md        # Phase 1 output (deployment guide)
├── contracts/
│   ├── skill-template.md    # Skill document contract
│   └── agent-template.md    # Agent file contract
└── tasks.md             # Phase 2 output (/speckit.tasks)
```

### Source Code (repository root)

```text
copilot-agent-skills/
├── vela.agent.md                      # Deployable agent (copy to .github/agents/)
├── skills/
│   ├── charts-config/SKILL.md         # Helm charts, values.yaml, umbrella pattern
│   ├── deploy-rollback/SKILL.md       # Deploy flows, rollback, canary
│   ├── recursos-scaling/SKILL.md      # CPU, memory, replicas, KEDA autoscaling
│   ├── secrets-vault/SKILL.md         # Vault, External Secrets, reload
│   ├── observabilidade/SKILL.md       # Logs, metrics, APM, Datadog, alerts
│   ├── seguranca/SKILL.md             # Trivy, Kyverno, tags, KubeArmor
│   ├── networking-ingress/SKILL.md    # Kong, VPN, external access, DNS
│   ├── migrations-jobs/SKILL.md       # Jobs, CronJobs, initialJob, migrations
│   ├── troubleshooting/SKILL.md       # Common errors, FAQ, diagnostics
│   ├── ambientes-contextos/SKILL.md   # Contexts, namespaces, environments
│   ├── preview-envs/SKILL.md          # Preview environments for PRs
│   ├── multi-regiao/SKILL.md          # Multi-region deployment, HA, DNS switching
│   ├── onboarding/SKILL.md            # Templates, app creation, prerequisites
│   └── auditoria-siem/SKILL.md        # Lifecycle audit, SIEM integration
└── README.md                          # Project documentation + deployment guide
```

**Structure Decision**: GitHub Copilot skill format: each skill in its own directory `skills/<name>/SKILL.md` with YAML frontmatter (`name` matching directory name, `description`). The `vela.agent.md` file is the deployable artifact. Skills are invoked by the agent before responding to the user (Constitution Principle IV).

## Implementation Strategy

### Execution Order

```text
Phase 1: Setup (Sequential)
  └── T001: Create project structure
  └── T002: Create skill document template
  └── T003: Create agent framework (behavior rules, response format, MCP instructions)

Phase 2: Skill Documents (PARALLEL - all 14 skills simultaneously)
  ├── T004-T010: P1-P3 skills (charts, deploy, scaling, secrets, observability, security, troubleshooting)
  └── T011-T017: P4-P6 skills (networking, migrations, environments, preview, multi-region, onboarding, audit)

Phase 3: Composition (Sequential)
  └── T018: Compose vela.agent.md from skill documents
  └── T019: Write README.md
  └── T020: Validate character limit and quality
```

### Parallelization

**14 skill documents can be built in parallel** because:
- Each skill has its own scope, sources, and knowledge domain
- No skill depends on another skill's content
- All skills follow the same template (defined in Phase 1)
- Each skill reads from different documentation files

**Agent composition must be sequential** because:
- It depends on all 14 skill documents being complete
- It must fit within the 30,000 character limit
- It requires condensing each skill's knowledge into ~1,785 chars

### Per-Skill Build Process

For each of the 14 skills, the build agent must:

1. **Read source documentation** from `karavela/docs/` (primary) and related repos
2. **Extract core knowledge**: key concepts, most common configurations, frequent examples
3. **Write skill document** following `contracts/skill-template.md`:
   - Human Input section (empty with placeholder)
   - Escopo (covers + does NOT cover)
   - 5-10 example questions
   - Conhecimento Embutido with YAML examples and source citations
   - MCP fetch instructions (repos, files, when to fetch)
   - Response format
4. **Validate** against the skill checklist in the contract

### Skill-to-Source Mapping (for parallel agents)

| Skill | Primary Sources to Read |
|-------|------------------------|
| charts-config | `karavela/docs/guia-do-desenvolvedor/charts.md`, `karavela/docs/politica_charts.md`, `platform-k8s-charts/platform-k8s-api-chart/values.yaml`, `platform-k8s-charts/platform-k8s-worker-chart/values.yaml`, `platform-k8s-charts/platform-k8s-cronjob-chart/values.yaml`, `platform-k8s-charts/platform-k8s-job-chart/values.yaml` |
| deploy-rollback | `karavela/docs/guia-do-desenvolvedor/deploy-de-aplicacoes/branch-commit.md`, `tag-release.md`, `fluxo-rollback.md` |
| recursos-scaling | `karavela/docs/guia-do-desenvolvedor/funcionalidades/autoscaling.md`, charts values.yaml (autoscaling + resources sections) |
| secrets-vault | `karavela/docs/guia-do-desenvolvedor/funcionalidades/secrets.md`, `karavela/docs/usando_karavela.md` (secrets section) |
| observabilidade | `karavela/docs/guia-do-desenvolvedor/observabilidade/intro.md`, `logs.md`, `metrics.md`, `apm.md` |
| seguranca | `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/security.md`, `karavela/docs/erros_comuns.md` (Kyverno section) |
| networking-ingress | `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/ingress.md`, `acesso-externo.md` |
| migrations-jobs | `platform-k8s-charts/platform-k8s-job-chart/values.yaml`, `platform-k8s-charts/platform-k8s-cronjob-chart/values.yaml` |
| troubleshooting | `karavela/docs/erros_comuns.md`, `karavela/docs/faq/faq.md`, `karavela/docs/guia-do-desenvolvedor/guias-e-manuais/troubleshooting.md` |
| ambientes-contextos | `karavela/docs/contextos.md`, `karavela/docs/conceitos_basicos.md`, `karavela/docs/guia-do-desenvolvedor/gerenciamento-aplicacoes/promocao-ambientes.md` |
| preview-envs | `karavela/docs/guia-do-desenvolvedor/funcionalidades/karavela-preview.md` |
| multi-regiao | `karavela/docs/guia-do-desenvolvedor/multi-regiao.md` |
| onboarding | `karavela/docs/usando_karavela.md`, `karavela/docs/pre_req_karavela.md`, `karavela/docs/guia-do-desenvolvedor/templates.md`, `karavela/docs/conceitos_basicos.md` |
| auditoria-siem | `karavela/docs/lifecycle_audity.md`, `karavela/docs/siem_integration.md` |

## Complexity Tracking

No constitution violations to justify. All gates pass.

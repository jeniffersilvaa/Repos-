# Research: Vela Agent & Skills

## R1: GitHub Copilot Custom Agents Format

**Decision**: Use `.agent.md` files following the GitHub Copilot custom agents specification.

**Rationale**: This is the official, documented format supported by both VS Code and GitHub.com. It uses YAML frontmatter for configuration and markdown body for instructions.

**Key Findings**:
- File format: `<name>.agent.md` placed in `.github/agents/` directory
- YAML frontmatter properties: `name`, `description`, `tools`, `infer`, `target`, `mcp-servers`, `metadata`
- **Markdown body limit: 30,000 characters** (critical constraint)
- Tools can reference MCP servers: `tools: ["mcp-server/tool-name"]`
- `infer: true` enables automatic agent selection based on user input

**Alternatives considered**:
- `.github/copilot-instructions.md` (global, not agent-specific) - rejected: no way to scope to Karavela only
- Copilot Extensions (server-side) - rejected: too complex, requires infrastructure

**Sources**:
- https://docs.github.com/en/copilot/reference/custom-agents-configuration
- https://code.visualstudio.com/docs/copilot/customization/custom-agents

## R2: 30K Character Limit Impact on Architecture

**Decision**: Cannot embed all 14 skills fully in one agent file. Use a tiered approach.

**Rationale**: 30,000 characters ~ 6,000 words. With 14 skills, each skill gets ~2,000 characters (~400 words) for embedded knowledge in the agent prompt. This is tight but workable for core concepts + MCP fetch instructions.

**Strategy**:
1. **Agent file (`vela.agent.md`)**: Contains core behavior rules, response format, skill routing logic, and summary of each skill's scope (~5,000 chars for framework). Remaining ~25,000 chars split across 14 skill sections (~1,785 chars each).
2. **Skill documents (`skills/*.md`)**: Full reference documents NOT embedded in agent. Serve as:
   - Source material for writing the agent's embedded knowledge sections
   - Documentation for platform maintainers
   - Portable knowledge base that can be updated independently
3. **MCP fetch**: Agent instructed to use GitHub MCP for detailed/uncommon content

**Alternatives considered**:
- Single monolithic agent with all knowledge - rejected: exceeds 30K limit
- Multiple agents - rejected: user chose single `@vela` entry point
- External RAG/vector store - rejected: no Copilot support for custom RAG

## R3: GitHub MCP Integration

**Decision**: Use `github_mcp` tool references in agent frontmatter for on-the-fly repo access.

**Rationale**: GitHub Copilot has built-in MCP tools for repository access. The agent can be configured to use these tools to fetch file contents from platform repos.

**Key Findings**:
- Copilot provides built-in tools: `read`, `edit`, `search`, `webfetch`
- MCP servers can be configured in frontmatter under `mcp-servers`
- Agent can instruct itself to use `search` and `read` tools to fetch content from specific repos
- The agent prompt can contain instructions like "When asked about X, fetch file Y from repo Z"

**Repositories the agent needs access to**:
- `stone-payments/platform-k8s-charts` (charts, values.yaml)
- `stone-payments/karavela` (API code, docs)
- `stone-payments/platform-k8s-crossplane` (Crossplane compositions)
- `stone-payments/karavela-core` (Backstage frontend)

## R4: Skill Document Structure (Human Input Section)

**Decision**: Each skill document uses a 3-layer structure with Human Input at highest precedence.

**Rationale**: The user explicitly required a "Human Input" section with highest precedence for constraints and knowledge. This allows platform maintainers to override embedded knowledge without rewriting the skill.

**Structure per skill document**:
```markdown
# Skill: <nome-da-skill>

## Human Input
<!-- Mantenedores: adicione restricoes, correcoes e conhecimento adicional aqui -->
<!-- Este conteudo tem a MAIOR precedencia sobre todo o resto da skill -->

## Escopo
<definicao do que a skill cobre>

## Exemplos de Perguntas
<lista de perguntas que a skill sabe responder>

## Conhecimento Embutido
<conceitos-chave, configuracoes comuns, exemplos frequentes>

## Instrucoes MCP
<instrucoes para buscar conteudo detalhado via GitHub MCP>

## Formato de Resposta
<template de como a skill deve formatar respostas>
```

**Precedence chain**: Human Input > Conhecimento Embutido > MCP-fetched content

## R5: Parallelization Strategy

**Decision**: Skills are independent and can be built in parallel by separate agents.

**Rationale**: Each skill document is self-contained with its own scope, sources, and knowledge. No skill depends on another skill's content. The only shared dependency is the agent framework (behavior rules, response format) which should be defined first.

**Execution order**:
1. **Sequential (blocking)**: Define agent framework + skill template
2. **Parallel**: Build all 14 skill documents simultaneously
3. **Sequential (blocking)**: Compose agent file from skill documents + write README

## R6: Output Structure Decision

**Decision**: Deliverables in `copilot-agent-skills/` with deployment guide to `.github/agents/`.

**Rationale**: The user specified `copilot-agent-skills/` as the output folder. For actual Copilot usage, the agent file needs to be at `.github/agents/vela.agent.md`. The README will document the deployment process.

**Output structure**:
```text
copilot-agent-skills/
├── vela.agent.md             # The deployable agent file (copy to .github/agents/)
├── skills/                   # Modular skill documents (reference/maintenance)
│   ├── charts-config.md
│   ├── deploy-rollback.md
│   ├── recursos-scaling.md
│   ├── secrets-vault.md
│   ├── observabilidade.md
│   ├── seguranca.md
│   ├── networking-ingress.md
│   ├── migrations-jobs.md
│   ├── troubleshooting.md
│   ├── ambientes-contextos.md
│   ├── preview-envs.md
│   ├── multi-regiao.md
│   ├── onboarding.md
│   └── auditoria-siem.md
└── README.md                 # Documentation + deployment guide
```

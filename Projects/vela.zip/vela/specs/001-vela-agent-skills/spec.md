# Feature Specification: Vela Agent & Skills para GitHub Copilot

**Feature Branch**: `001-vela-agent-skills`
**Created**: 2026-02-19
**Status**: Draft
**Input**: User description: "create the vela agent and the skills, use parallel agents to build"

## Clarifications

### Session 2026-02-19

- Q: How should the agent-skills architecture map to the GitHub Copilot extensibility model? → A: Option A - One agent (`@vela`) with embedded knowledge from all skills. Skill files exist as modular source documents that are composed into the agent prompt. Developer uses only `@vela`.
- Q: How much knowledge should each skill document embed vs. fetch on-the-fly via GitHub MCP? → A: Option B - Hybrid: embed core concepts, common configs and examples; instruct agent to fetch detailed/uncommon content via GitHub MCP on-the-fly.
- Q: Should skill documents support human-authored overrides? → A: Yes. Each skill document MUST have a "Human Input" section with highest precedence for constraints and knowledge. Content in this section overrides embedded knowledge and MCP-fetched content.

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Desenvolvedor pergunta como configurar recursos da aplicacao (Priority: P1)

Um desenvolvedor da Stone quer saber como configurar CPU, memoria, replicas ou autoscaling para sua aplicacao no Karavela. Ele interage com o Agent Vela no GitHub Copilot, que identifica o dominio da pergunta e delega para a skill adequada. A skill responde em portugues do Brasil com uma explicacao objetiva e um exemplo pratico de YAML que o desenvolvedor pode copiar e adaptar no `values.yaml` da pasta `./chart/` do seu repositorio.

**Why this priority**: Configuracao de charts e recursos e a necessidade mais frequente dos desenvolvedores. Sem isso, o agente nao entrega valor. Este story valida o fluxo completo: input do usuario -> orquestracao pelo Vela -> resposta da skill.

**Independent Test**: Pode ser testado pedindo ao Vela "como configuro 512Mi de memoria para minha API?" e validando que a resposta contem um snippet YAML correto, baseado na documentacao oficial, e em PT-BR.

**Acceptance Scenarios**:

1. **Given** o Agent Vela esta configurado com a skill `charts-config`, **When** o desenvolvedor pergunta "como configuro CPU e memoria para minha API?", **Then** o Vela delega para `charts-config` e retorna um snippet YAML com a configuracao `resources.cpu` e `resources.memory` baseado no `platform-k8s-api-chart`, em PT-BR, com referencia a fonte documental.
2. **Given** o Agent Vela esta configurado, **When** o desenvolvedor pergunta "como habilito autoscaling com Kafka?", **Then** o Vela delega para `recursos-scaling` e retorna a configuracao KEDA com scaler Kafka, incluindo exemplo de `values.yaml`.
3. **Given** o desenvolvedor faz uma pergunta fora do escopo da plataforma, **When** ele pergunta "como configuro um banco PostgreSQL gerenciado?", **Then** o Vela informa que o tema esta fora do escopo e direciona ao canal #help-foundation-platform.
4. **Given** a documentacao nao cobre um topico especifico, **When** o desenvolvedor pergunta algo nao documentado, **Then** o Vela responde que a informacao nao esta documentada e sugere o canal de suporte no Slack.

---

### User Story 2 - Desenvolvedor precisa de ajuda com deploy, rollback e secrets (Priority: P2)

Um desenvolvedor quer entender o fluxo de deploy (branch-commit ou tag-release), fazer rollback de uma versao ou configurar secrets no Vault. O Vela identifica a intencao e delega para a skill correta (`deploy-rollback` ou `secrets-vault`), retornando instrucoes praticas com exemplos.

**Why this priority**: Deploy e gerenciamento de secrets sao as segundas operacoes mais frequentes. Sem elas, o desenvolvedor nao consegue colocar sua aplicacao em producao de forma segura.

**Independent Test**: Pode ser testado perguntando "como faco rollback da minha aplicacao em staging?" e validando que a resposta descreve o fluxo correto via Karavela Portal com passos claros.

**Acceptance Scenarios**:

1. **Given** a skill `deploy-rollback` esta ativa, **When** o desenvolvedor pergunta "como funciona o deploy por tag-release?", **Then** a resposta descreve o fluxo usando Release Drafter, SemVer, e a integracao com Changeman para producao, com referencia a documentacao de `deploy-de-aplicacoes/tag-release.md`.
2. **Given** a skill `secrets-vault` esta ativa, **When** o desenvolvedor pergunta "como adiciono uma nova secret para staging?", **Then** a resposta explica o passo a passo via Karavela Portal (aba "Segredos") e alerta que a secret deve ser criada no Portal ANTES de ser adicionada no `values.yaml`.
3. **Given** a skill `secrets-vault` esta ativa, **When** o desenvolvedor pergunta "qual o valor da minha secret DB_PASSWORD?", **Then** a skill se recusa a responder, informando que valores de secrets nunca sao expostos, e orienta o usuario a verificar no Karavela Portal (aba "Segredos").

---

### User Story 3 - Desenvolvedor investiga problemas e configura observabilidade (Priority: P3)

Um desenvolvedor enfrenta um problema (pod em CrashLoopBackOff, deploy bloqueado pelo Kyverno, vulnerabilidade no Trivy) e quer diagnosticar a causa. Ou quer configurar logs, metricas ou APM para monitorar sua aplicacao. O Vela roteia para `troubleshooting`, `observabilidade` ou `seguranca` conforme o caso.

**Why this priority**: Troubleshooting e observabilidade sao essenciais para a operacao diaria, mas menos frequentes que configuracao e deploy.

**Independent Test**: Pode ser testado perguntando "meu pod esta com CrashLoopBackOff, o que pode ser?" e validando que a resposta lista causas comuns documentadas com passos de diagnostico.

**Acceptance Scenarios**:

1. **Given** a skill `troubleshooting` esta ativa, **When** o desenvolvedor reporta "meu deploy foi bloqueado pelo Kyverno", **Then** a resposta explica a politica de tags, mostra um exemplo de labels corretas no `values.yaml` e referencia `erros_comuns.md`.
2. **Given** a skill `observabilidade` esta ativa, **When** o desenvolvedor pergunta "como configuro APM com Datadog?", **Then** a resposta detalha as opcoes (lib injection, automatica, manual) com exemplo YAML e referencia a documentacao de APM.
3. **Given** a skill `seguranca` esta ativa, **When** o desenvolvedor pergunta "como resolvo vulnerabilidade CRITICAL no Trivy?", **Then** a resposta orienta atualizar a base image ou pacotes especificos, com exemplo de Dockerfile e referencia a documentacao de security.

---

### User Story 4 - Desenvolvedor configura networking, migrations e ambientes (Priority: P4)

Um desenvolvedor precisa expor sua API via Kong, configurar um Job de migration, criar um preview environment para um PR, ou promover sua aplicacao para um novo ambiente. O Vela delega para a skill especializada correspondente.

**Why this priority**: Essas operacoes sao menos frequentes mas essenciais para cenarios especificos de ciclo de vida da aplicacao.

**Independent Test**: Pode ser testado perguntando "como exponho minha API externamente?" e validando que a resposta descreve a configuracao via Kong com exemplo de ingress.

**Acceptance Scenarios**:

1. **Given** a skill `networking-ingress` esta ativa, **When** o desenvolvedor pergunta "como exponho minha API pela VPN?", **Then** a resposta explica a configuracao de ingress via Kong (Konguinho) com exemplo de Gateway Service.
2. **Given** a skill `migrations-jobs` esta ativa, **When** o desenvolvedor pergunta "como configuro um Job de migration?", **Then** a resposta mostra a configuracao do `platform-k8s-job-chart` com `initialJob` e `argocd.hooks`, incluindo exemplo YAML.
3. **Given** a skill `preview-envs` esta ativa, **When** o desenvolvedor pergunta "como crio um preview environment para testar meu PR?", **Then** a resposta descreve o fluxo via Karavela Preview com instrucoes claras.
4. **Given** a skill `ambientes-contextos` esta ativa, **When** o desenvolvedor pergunta "como promovo minha app de staging para sandbox?", **Then** a resposta descreve o processo via Karavela Portal e os pre-requisitos.

---

### User Story 5 - Novo desenvolvedor faz onboarding na plataforma (Priority: P5)

Um desenvolvedor novo na Stone quer comecar a usar a plataforma Karavela. Ele pergunta ao Vela por onde comecar, o que precisa saber, e como criar sua primeira aplicacao. O Vela delega para a skill `onboarding`.

**Why this priority**: Onboarding e importante mas menos frequente. Uma vez que o desenvolvedor passa por esse processo, ele usa as demais skills no dia a dia.

**Independent Test**: Pode ser testado perguntando "como crio minha primeira aplicacao no Karavela?" e validando que a resposta descreve os pre-requisitos e o uso do template no Backstage.

**Acceptance Scenarios**:

1. **Given** a skill `onboarding` esta ativa, **When** o novo desenvolvedor pergunta "o que e o Karavela?", **Then** a resposta explica que e uma plataforma de hospedagem baseada em Kubernetes, com referencia a documentacao oficial.
2. **Given** a skill `onboarding` esta ativa, **When** o desenvolvedor pergunta "como crio uma nova aplicacao?", **Then** a resposta descreve o uso do template "[Beta][Containers] Criar aplicacao" no Backstage com os outputs esperados (ArgoCD, ECR, IRSA).

---

### User Story 6 - Desenvolvedor configura deploy multi-regiao e auditoria (Priority: P6)

Um desenvolvedor precisa configurar deploy multi-regiao para alta disponibilidade ou entender o sistema de auditoria e integracao SIEM. O Vela delega para `multi-regiao` ou `auditoria-siem`.

**Why this priority**: Cenarios avancados e menos comuns, mas criticos para aplicacoes de alta disponibilidade e conformidade.

**Independent Test**: Pode ser testado perguntando "como configuro minha API para multi-regiao?" e validando que a resposta descreve a arquitetura e configuracao necessarias.

**Acceptance Scenarios**:

1. **Given** a skill `multi-regiao` esta ativa, **When** o desenvolvedor pergunta "como configuro multi-regiao?", **Then** a resposta descreve a arquitetura, configuracao DNS, e consideracoes de custo baseadas na documentacao.
2. **Given** a skill `auditoria-siem` esta ativa, **When** o desenvolvedor pergunta "como funciona a auditoria de lifecycle?", **Then** a resposta explica o Lifecycle Audit Service com os tipos de recursos e eventos suportados.

---

### Edge Cases

- O que acontece quando o desenvolvedor faz uma pergunta que abrange multiplas skills (ex: "como configuro autoscaling e alertas para minha API?")? O Vela deve compor respostas de ambas as skills em uma unica resposta coesa.
- O que acontece quando a pergunta e ambigua (ex: "como configuro minha app?")? O Vela deve pedir clarificacao antes de delegar.
- O que acontece quando o desenvolvedor faz uma pergunta sobre uma ferramenta da plataforma mas fora do escopo documentado? A skill deve informar a limitacao e direcionar ao suporte.
- O que acontece quando a documentacao esta desatualizada em relacao ao codigo-fonte? A skill deve priorizar a documentacao e informar que pode haver divergencias, sugerindo verificar com o time.
- O que acontece quando o desenvolvedor pergunta em ingles? O Vela deve responder em PT-BR conforme definido na constituicao.
- O que acontece quando o conteudo da secao "Human Input" contradiz o conhecimento embutido na skill? O conteudo do Human Input prevalece (maior precedencia). O agente deve seguir o Human Input e ignorar a informacao embutida conflitante.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: O sistema DEVE conter um unico Agent chamado Vela (`@vela`) que orquestra skills modulares. O Agent Vela DEVE invocar pelo menos uma skill antes de produzir qualquer resposta ao usuario (Principio IV da Constituicao). O desenvolvedor interage exclusivamente com `@vela`.
- **FR-002**: O Agent Vela DEVE responder exclusivamente em portugues do Brasil, de forma objetiva e com exemplos praticos.
- **FR-003**: O Agent Vela DEVE suportar perguntas que abrangem multiplas skills, compondo uma resposta unificada.
- **FR-004**: O Agent Vela DEVE pedir clarificacao quando o input do usuario for ambiguo.
- **FR-005**: O Agent Vela DEVE recusar respostas fora do escopo da plataforma Karavela, direcionando ao canal de suporte.
- **FR-006**: Cada documento de skill DEVE conter: escopo, fontes de dados, formato de resposta, conhecimento essencial embutido (conceitos-chave, configuracoes comuns, exemplos frequentes), instrucoes para buscar conteudo detalhado via GitHub MCP, e uma secao "Human Input" conforme definido em FR-017.
- **FR-007**: Cada skill DEVE listar exemplos de perguntas que sabe responder.
- **FR-008**: Toda resposta de skill DEVE conter: explicacao objetiva (2-3 frases), exemplo pratico (YAML/comando), e referencia a fonte documental.
- **FR-009**: Skills NUNCA devem inventar, inferir ou concluir informacoes que nao estejam explicitamente documentadas.
- **FR-010**: Skills NUNCA devem expor ou sugerir valores de secrets, senhas, tokens ou credenciais.
- **FR-011**: O Agent Vela DEVE usar GitHub MCP para buscar informacoes detalhadas ou incomuns nos repositorios da plataforma, complementando o conhecimento essencial ja embutido nos documentos de skill.
- **FR-012**: Skills DEVEM alertar o usuario quando uma acao requer privilegios de producao.
- **FR-013**: Quando a informacao solicitada nao existir na documentacao, a skill DEVE informar explicitamente e direcionar ao canal #help-foundation-platform.
- **FR-014**: O sistema DEVE conter 14 documentos de skill modulares (`charts-config`, `deploy-rollback`, `recursos-scaling`, `secrets-vault`, `observabilidade`, `seguranca`, `networking-ingress`, `migrations-jobs`, `troubleshooting`, `ambientes-contextos`, `preview-envs`, `multi-regiao`, `onboarding`, `auditoria-siem`) que servem como fonte de conhecimento compostos no prompt do agent `@vela`.
- **FR-015**: Todo o output DEVE ser entregue na pasta `copilot-agent-skills/` na raiz do repositorio, contendo: o arquivo do agent (`@vela`), os documentos modulares de skill (fonte de conhecimento), e um README.
- **FR-016**: A skill de fallback DEVE retornar mensagem padrao direcionando ao canal de suporte quando nao conseguir responder.
- **FR-017**: Cada documento de skill DEVE conter uma secao "Human Input" editavel por mantenedores da plataforma. O conteudo desta secao tem a MAIOR precedencia, sobrepondo conhecimento embutido e conteudo obtido via MCP. A secao serve para adicionar restricoes, correcoes, conhecimento adicional ou overrides temporarios sem reescrever a skill inteira.

### Key Entities

- **Agent Vela (`@vela`)**: Unico ponto de entrada para o desenvolvedor no GitHub Copilot. Orquestra skills modulares, devendo invocar pelo menos uma skill antes de qualquer resposta. Contem regras de comportamento, formato de resposta e conhecimento condensado por dominio para roteamento.
- **Documento de Skill (SKILL.md)**: Arquivo markdown modular em `skills/<nome>/SKILL.md` com YAML frontmatter obrigatorio (`name` igual ao nome da pasta pai, `description` descrevendo funcao e quando usar). Estrutura do body: (1) secao "Human Input" com maior precedencia para overrides de mantenedores, (2) conhecimento embutido (conceitos-chave, configuracoes comuns, exemplos frequentes), (3) instrucoes para buscar detalhes via GitHub MCP. Precedencia: Human Input > Conhecimento Embutido > MCP. O Agent Vela DEVE invocar a skill antes de responder ao usuario.
- **Fonte de Dados**: Repositorio ou documento da plataforma que serve como base para respostas. Hierarquia: docs > charts > API > temporal > crossplane > backstage.
- **Resposta Padrao**: Formato estruturado de output contendo explicacao, exemplo pratico, referencia e avisos de restricao.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: 100% das respostas do Agent Vela sao em portugues do Brasil.
- **SC-002**: 100% das respostas contem pelo menos um exemplo pratico (YAML, comando ou configuracao) quando a pergunta envolve configuracao.
- **SC-003**: 100% das respostas sao rastreaveis a uma fonte documental ou de codigo-fonte da plataforma (nenhuma informacao inventada).
- **SC-004**: O Agent Vela roteia corretamente para a skill adequada em pelo menos 90% dos inputs que estao dentro do escopo de uma skill existente.
- **SC-005**: 100% das tentativas de obter secrets, senhas ou credenciais sao recusadas com orientacao ao Vault.
- **SC-006**: O Agent Vela identifica e recusa perguntas fora do escopo da plataforma, direcionando ao canal de suporte.
- **SC-007**: As 14 skills planejadas estao implementadas e entregues na pasta `copilot-agent-skills/`.
- **SC-008**: Cada skill contem prompt de sistema, exemplos de input e formato de resposta documentados.

### Assumptions

- O GitHub Copilot suporta a estrutura de agent + skills em formato Markdown conforme o modelo de extensibilidade do Copilot.
- Os repositorios da plataforma (`stone-payments/platform-k8s-charts`, `stone-payments/karavela`, etc.) estao acessiveis via GitHub MCP no contexto do Copilot.
- A documentacao em `karavela/docs/` e a fonte de verdade e esta razoavelmente atualizada.
- A implementacao pode ser paralelizada: cada skill e independente e pode ser construida em paralelo por agentes distintos.

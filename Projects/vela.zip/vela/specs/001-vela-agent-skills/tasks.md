# Tasks: Vela Agent & Skills

**Input**: Design documents from `/specs/001-vela-agent-skills/`
**Prerequisites**: plan.md (required), spec.md (required), research.md, data-model.md, contracts/

**Tests**: Not requested in the feature specification. No test tasks included.

**Organization**: Tasks are grouped by user story (P1-P6). Each user story maps to a set of skill documents that can be built in parallel. Final composition phase is sequential.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (e.g., US1, US2, US3)
- Include exact file paths in descriptions

## Path Conventions

- **Project root**: `copilot-agent-skills/`
- **Agent file**: `copilot-agent-skills/vela.agent.md`
- **Skills directory**: `copilot-agent-skills/skills/`
- **README**: `copilot-agent-skills/README.md`

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: Create project structure, skill template, and agent framework

- [x] T001 Create project directory structure: `copilot-agent-skills/`, `copilot-agent-skills/skills/`, per plan.md project structure
- [x] T002 Create skill document template based on contract at `specs/001-vela-agent-skills/contracts/skill-template.md` — this serves as reference for all skill authors
- [x] T003 Create agent framework skeleton in `copilot-agent-skills/vela.agent.md` with YAML frontmatter (`name: vela`, `tools: [read, search, webfetch]`, `infer: true`), "Regras de Comportamento" (~2,000 chars covering: multi-skill composition for cross-domain questions, clarification request for ambiguous input, always respond in PT-BR even if asked in English, Human Input section takes highest precedence over embedded knowledge, production privilege alerts), "Formato de Resposta" (~1,000 chars), and "Instrucoes de Acesso a Repositorios MCP" (~2,000 chars) — leave skill sections as placeholders

**Checkpoint**: Project structure ready, skill template defined, agent framework skeleton in place. Skill authoring can now begin in parallel.

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: No additional foundational tasks beyond Phase 1. The setup phase creates all prerequisites needed for parallel skill authoring.

**⚠️ NOTE**: Phase 1 MUST be complete before any skill document work begins, as skills depend on the template and project structure.

---

## Phase 3: User Story 1 - Configuracao de charts e recursos (Priority: P1) 🎯 MVP

**Goal**: Developer can ask Vela about Helm chart configuration, CPU/memory resources, replicas, and KEDA autoscaling and receive practical YAML examples.

**Independent Test**: Ask `@vela como configuro 512Mi de memoria para minha API?` and validate the response contains a correct YAML snippet with `resources.memory`, in PT-BR, citing official documentation.

### Implementation for User Story 1

- [x] T004 [P] [US1] Create skill document `copilot-agent-skills/skills/charts-config/SKILL.md` — Read sources: `karavela/docs/guia-do-desenvolvedor/charts.md`, `karavela/docs/politica_charts.md`, `platform-k8s-charts/platform-k8s-api-chart/values.yaml`, `platform-k8s-charts/platform-k8s-worker-chart/values.yaml`, `platform-k8s-charts/platform-k8s-cronjob-chart/values.yaml`, `platform-k8s-charts/platform-k8s-job-chart/values.yaml`. Cover: umbrella chart pattern, Chart.yaml dependency, values-*.yaml structure, chart versioning policy (SemVer, `1.*.*` auto-update), chart types (API, Worker, CronJob, Job, StatefulSet). Follow skill template contract.
- [x] T005 [P] [US1] Create skill document `copilot-agent-skills/skills/recursos-scaling/SKILL.md` — Read sources: `karavela/docs/guia-do-desenvolvedor/funcionalidades/autoscaling.md`, charts values.yaml (autoscaling + resources sections). Cover: CPU/memory configuration, replicas, HPA, KEDA autoscaling (Kafka, SQS, cron, prometheus scalers), `resources` block in values.yaml, requests vs limits. Follow skill template contract.

**Checkpoint**: Skills `charts-config` and `recursos-scaling` are complete. Developer questions about chart config and resource scaling can be answered.

---

## Phase 4: User Story 2 - Deploy, rollback e secrets (Priority: P2)

**Goal**: Developer can ask Vela about deploy flows (branch-commit, tag-release), rollback procedures, and secrets management (Vault, External Secrets).

**Independent Test**: Ask `@vela como faco rollback da minha aplicacao em staging?` and validate the response describes the correct rollback flow via Karavela Portal.

### Implementation for User Story 2

- [x] T006 [P] [US2] Create skill document `copilot-agent-skills/skills/deploy-rollback/SKILL.md` — Read sources: `karavela/docs/guia-do-desenvolvedor/deploy-de-aplicacoes/branch-commit.md`, `tag-release.md`, `fluxo-rollback.md`. Cover: branch-commit flow (staging via develop, sandbox/prod via main), tag-release flow (Release Drafter, SemVer, Changeman for prod), rollback steps via Portal, canary deploy with Argo Rollouts. Follow skill template contract.
- [x] T007 [P] [US2] Create skill document `copilot-agent-skills/skills/secrets-vault/SKILL.md` — Read sources: `karavela/docs/guia-do-desenvolvedor/funcionalidades/secrets.md`, `karavela/docs/usando_karavela.md` (secrets section). Cover: Vault path structure, External Secrets Operator, env vars vs secrets distinction, secret creation in Vault before values.yaml, secret reload/rotation, security guardrail (never reveal secret values). Follow skill template contract.

**Checkpoint**: Skills `deploy-rollback` and `secrets-vault` are complete.

---

## Phase 5: User Story 3 - Troubleshooting, observabilidade e seguranca (Priority: P3)

**Goal**: Developer can ask Vela to diagnose common problems (CrashLoopBackOff, Kyverno blocks, Trivy vulnerabilities), configure observability (logs, metrics, APM), and understand security policies.

**Independent Test**: Ask `@vela meu pod esta com CrashLoopBackOff, o que pode ser?` and validate the response lists documented common causes with diagnostic steps.

### Implementation for User Story 3

- [x] T008 [P] [US3] Create skill document `copilot-agent-skills/skills/troubleshooting/SKILL.md` — Read sources: `karavela/docs/erros_comuns.md`, `karavela/docs/faq/faq.md`, `karavela/docs/guia-do-desenvolvedor/guias-e-manuais/troubleshooting.md`. Cover: common errors (Kyverno tag policy, Trivy vulnerabilities, empty image.tag, secret sync failures, IRSA), diagnostic steps, FAQ answers. Follow skill template contract.
- [x] T009 [P] [US3] Create skill document `copilot-agent-skills/skills/observabilidade/SKILL.md` — Read sources: `karavela/docs/guia-do-desenvolvedor/observabilidade/intro.md`, `logs.md`, `metrics.md`, `apm.md`. Cover: Datadog integration, log configuration, custom metrics, APM setup (lib injection, automatic, manual), alerting configuration, dashboards. Follow skill template contract.
- [x] T010 [P] [US3] Create skill document `copilot-agent-skills/skills/seguranca/SKILL.md` — Read sources: `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/security.md`, `karavela/docs/erros_comuns.md` (Kyverno section). Cover: Trivy vulnerability scanning, Kyverno policies (mandatory labels/tags), KubeArmor, image tag requirements, security best practices. Follow skill template contract.

**Checkpoint**: Skills `troubleshooting`, `observabilidade`, and `seguranca` are complete.

---

## Phase 6: User Story 4 - Networking, migrations, ambientes e preview (Priority: P4)

**Goal**: Developer can ask Vela about exposing APIs via Kong, configuring Jobs/CronJobs/migrations, managing environments/contexts, and using preview environments.

**Independent Test**: Ask `@vela como exponho minha API externamente?` and validate the response describes Kong ingress configuration with YAML example.

### Implementation for User Story 4

- [x] T011 [P] [US4] Create skill document `copilot-agent-skills/skills/networking-ingress/SKILL.md` — Read sources: `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/ingress.md`, `acesso-externo.md`. Cover: Kong (Konguinho) Gateway, VPN access, external access, DNS configuration, Gateway Service setup, ingress rules. Follow skill template contract.
- [x] T012 [P] [US4] Create skill document `copilot-agent-skills/skills/migrations-jobs/SKILL.md` — Read sources: `platform-k8s-charts/platform-k8s-job-chart/values.yaml`, `platform-k8s-charts/platform-k8s-cronjob-chart/values.yaml`. Cover: Job chart configuration, CronJob chart configuration, initialJob for migrations, ArgoCD hooks for sync, ttlSecondsAfterFinished, schedule cron syntax. Follow skill template contract.
- [x] T013 [P] [US4] Create skill document `copilot-agent-skills/skills/ambientes-contextos/SKILL.md` — Read sources: `karavela/docs/contextos.md`, `karavela/docs/conceitos_basicos.md`, `karavela/docs/guia-do-desenvolvedor/gerenciamento-aplicacoes/promocao-ambientes.md`. Cover: 31 contexts table (prefixes, IDs, providers, PCI), staging/sandbox/production environments, branch-environment mapping, namespace naming, environment promotion via Portal. Follow skill template contract.
- [x] T014 [P] [US4] Create skill document `copilot-agent-skills/skills/preview-envs/SKILL.md` — Read sources: `karavela/docs/guia-do-desenvolvedor/funcionalidades/karavela-preview.md`. Cover: Karavela Preview for PRs, how to enable, URL pattern, lifecycle (PR close → cleanup), limitations. Follow skill template contract.

**Checkpoint**: Skills `networking-ingress`, `migrations-jobs`, `ambientes-contextos`, and `preview-envs` are complete.

---

## Phase 7: User Story 5 - Onboarding de novos desenvolvedores (Priority: P5)

**Goal**: New developer can ask Vela about getting started on the Karavela platform, prerequisites, and creating their first application.

**Independent Test**: Ask `@vela como crio minha primeira aplicacao no Karavela?` and validate the response describes prerequisites and Backstage template usage.

### Implementation for User Story 5

- [x] T015 [P] [US5] Create skill document `copilot-agent-skills/skills/onboarding/SKILL.md` — Read sources: `karavela/docs/usando_karavela.md`, `karavela/docs/pre_req_karavela.md`, `karavela/docs/guia-do-desenvolvedor/templates.md`, `karavela/docs/conceitos_basicos.md`. Cover: platform overview, prerequisites by app type, Backstage software templates, application creation flow (outputs: ArgoCD, ECR, IRSA), first deploy steps, support channels. Follow skill template contract.

**Checkpoint**: Skill `onboarding` is complete.

---

## Phase 8: User Story 6 - Multi-regiao e auditoria (Priority: P6)

**Goal**: Developer can ask Vela about multi-region deployment for HA and lifecycle audit/SIEM integration.

**Independent Test**: Ask `@vela como configuro minha API para multi-regiao?` and validate the response describes architecture and DNS switching.

### Implementation for User Story 6

- [x] T016 [P] [US6] Create skill document `copilot-agent-skills/skills/multi-regiao/SKILL.md` — Read sources: `karavela/docs/guia-do-desenvolvedor/multi-regiao.md`. Cover: multi-region architecture, DNS switching, HA considerations, cost implications, configuration requirements. Follow skill template contract.
- [x] T017 [P] [US6] Create skill document `copilot-agent-skills/skills/auditoria-siem/SKILL.md` — Read sources: `karavela/docs/lifecycle_audity.md`, `karavela/docs/siem_integration.md`. Cover: Lifecycle Audit Service (Go types, resource types, event types), SIEM integration (HTTP POST, async goroutines), audit API, integration steps, best practices. Follow skill template contract.

**Checkpoint**: Skills `multi-regiao` and `auditoria-siem` are complete. All 14 skill documents are now done.

---

## Phase 9: Composition & Finalization

**Purpose**: Compose the final agent file from all 14 skill documents, write README, and validate constraints.

- [x] T018 Compose final `copilot-agent-skills/vela.agent.md` by condensing each of the 14 skill documents into ~1,785 char embedded sections within the agent body. Preserve: YAML frontmatter, Regras de Comportamento, Formato de Resposta, Instrucoes MCP. Each skill section must include key concepts, most common YAML example, and source citation. Total body MUST NOT exceed 30,000 characters.
- [x] T019 Write `copilot-agent-skills/README.md` with sections: Overview, Architecture (single agent + modular skills), Deployment (copy to `.github/agents/`), Skills List (table of all 14 skills with descriptions), Maintenance (how to update Human Input sections), Contributing (how to add new skills). Content in PT-BR.
- [x] T020 Validate final deliverables: (1) `vela.agent.md` body is under 30,000 characters, (2) all 14 skill documents pass the validation checklist from `contracts/skill-template.md`, (3) no secrets/credentials appear as values, (4) all content is in PT-BR, (5) every example has a source citation, (6) run quickstart.md validation scenarios.

**Checkpoint**: All deliverables complete and validated. Agent is ready for deployment.

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies - can start immediately
- **Foundational (Phase 2)**: N/A - no additional foundational tasks
- **User Stories (Phase 3-8)**: All depend on Phase 1 completion (project structure + skill template)
  - All 14 skill documents (T004-T017) can be built in parallel across all user stories
  - Skills within the same user story are also parallel (different files, no dependencies)
- **Composition (Phase 9)**: Depends on ALL skill documents (T004-T017) being complete
  - T018 (compose agent) must be sequential — it reads all 14 skill documents
  - T019 (README) can run in parallel with T018
  - T020 (validation) depends on T018 and T019

### User Story Dependencies

- **User Story 1 (P1)**: Can start after Phase 1 — No dependencies on other stories
- **User Story 2 (P2)**: Can start after Phase 1 — No dependencies on other stories
- **User Story 3 (P3)**: Can start after Phase 1 — No dependencies on other stories
- **User Story 4 (P4)**: Can start after Phase 1 — No dependencies on other stories
- **User Story 5 (P5)**: Can start after Phase 1 — No dependencies on other stories
- **User Story 6 (P6)**: Can start after Phase 1 — No dependencies on other stories

### Within Each User Story

- All skill documents within a story are independent and can be built in parallel
- Each skill reads from different source documentation
- Each skill outputs to a different file

### Parallel Opportunities

- **Maximum parallelism**: After Phase 1, all 14 skill documents (T004-T017) can be launched simultaneously
- **Per-story parallelism**: Within US1 (2 skills), US2 (2 skills), US3 (3 skills), US4 (4 skills), US5 (1 skill), US6 (2 skills)
- **Composition parallelism**: T018 (agent) and T019 (README) can run in parallel

---

## Parallel Example: All Skills Simultaneously

```bash
# After Phase 1 is complete, launch ALL 14 skill documents in parallel:

# US1 skills:
Task: "Create charts-config skill in copilot-agent-skills/skills/charts-config/SKILL.md"
Task: "Create recursos-scaling skill in copilot-agent-skills/skills/recursos-scaling/SKILL.md"

# US2 skills:
Task: "Create deploy-rollback skill in copilot-agent-skills/skills/deploy-rollback/SKILL.md"
Task: "Create secrets-vault skill in copilot-agent-skills/skills/secrets-vault/SKILL.md"

# US3 skills:
Task: "Create troubleshooting skill in copilot-agent-skills/skills/troubleshooting/SKILL.md"
Task: "Create observabilidade skill in copilot-agent-skills/skills/observabilidade/SKILL.md"
Task: "Create seguranca skill in copilot-agent-skills/skills/seguranca/SKILL.md"

# US4 skills:
Task: "Create networking-ingress skill in copilot-agent-skills/skills/networking-ingress/SKILL.md"
Task: "Create migrations-jobs skill in copilot-agent-skills/skills/migrations-jobs/SKILL.md"
Task: "Create ambientes-contextos skill in copilot-agent-skills/skills/ambientes-contextos/SKILL.md"
Task: "Create preview-envs skill in copilot-agent-skills/skills/preview-envs/SKILL.md"

# US5 skills:
Task: "Create onboarding skill in copilot-agent-skills/skills/onboarding/SKILL.md"

# US6 skills:
Task: "Create multi-regiao skill in copilot-agent-skills/skills/multi-regiao/SKILL.md"
Task: "Create auditoria-siem skill in copilot-agent-skills/skills/auditoria-siem/SKILL.md"
```

---

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Complete Phase 1: Setup (T001-T003)
2. Complete Phase 3: US1 skills — `charts-config` (T004) + `recursos-scaling` (T005)
3. Compose minimal `vela.agent.md` with just US1 skills
4. **STOP and VALIDATE**: Test with "como configuro 512Mi de memoria?"
5. Iterate if needed before expanding

### Full Parallel Delivery (Recommended)

1. Complete Phase 1: Setup (T001-T003) — sequential
2. Launch ALL 14 skills (T004-T017) in parallel — maximum throughput
3. Complete Phase 9: Composition (T018-T020) — sequential
4. Validate against quickstart.md scenarios

### Incremental Delivery

1. Complete Setup → Foundation ready
2. Add US1 skills → Test independently → Partial agent (MVP)
3. Add US2 skills → Test independently → Expanded agent
4. Add US3 skills → Test independently → Core coverage
5. Add US4-US6 skills → Full coverage
6. Compose final agent → Validate → Deploy

---

## Summary

| Metric | Value |
|--------|-------|
| **Total tasks** | 20 |
| **Setup tasks** | 3 (T001-T003) |
| **US1 tasks** | 2 (T004-T005) |
| **US2 tasks** | 2 (T006-T007) |
| **US3 tasks** | 3 (T008-T010) |
| **US4 tasks** | 4 (T011-T014) |
| **US5 tasks** | 1 (T015) |
| **US6 tasks** | 2 (T016-T017) |
| **Composition tasks** | 3 (T018-T020) |
| **Max parallel skills** | 14 (all skills simultaneously after Phase 1) |
| **Suggested MVP** | Phase 1 + US1 (T001-T005) = 5 tasks |

## Notes

- [P] tasks = different files, no dependencies — all 14 skill documents qualify
- [Story] label maps each skill to its user story for traceability
- Each skill document follows the contract at `specs/001-vela-agent-skills/contracts/skill-template.md`
- The agent file `vela.agent.md` has a hard limit of 30,000 characters — composition (T018) must respect this
- Skill documents have no size limit — they serve as full reference material
- Human Input sections start empty with placeholder comments for future maintainer overrides
- All content must be in Portuguese (PT-BR) with practical examples and source citations

# Vela - Agente da Plataforma Karavela

Agente de IA especializado na plataforma **Karavela** da Stone. Auxilia desenvolvedores com deploy, configuracao de charts, secrets, observabilidade, seguranca e mais — sempre em portugues do Brasil com exemplos praticos.

Vela funciona como uma solucao mista, compativel com multiplas plataformas de AI coding assistants e integrado ao ecossistema de ferramentas da Karavela.

## Plataformas suportadas

| Plataforma | Mecanismo | Ponto de entrada |
|------------|-----------|------------------|
| **Claude Code** | Plugin via marketplace | `.claude-plugin-root/` |
| **GitHub Copilot** | Agent mode | `agents/vela.agent.md` |
| **KLI** | Integracao nativa | `kli check app --ask-vela` |

O conhecimento (skills) e compartilhado entre todas as plataformas — o diretorio `skills/` na raiz do repo e a fonte unica de verdade, referenciado via symlink pelo plugin Claude Code e lido diretamente pelo agente Copilot.

## Instalacao

### KLI — setup completo (recomendado)

O KLI sincroniza skills do Copilot e instala o plugin do Claude Code em um unico comando:

Doc de instalação do kli: https://github.com/stone-payments/kli/blob/main/README.md 

```bash
# Sincroniza skills/agents do Copilot + instala plugin Claude Code
kli vela sync --claude

# Preview sem aplicar mudancas
kli vela sync --claude --dry-run
```

Isso registra o marketplace `stone-payments/vela` no Claude Code e instala o plugin `vela@karavela-plugins` no escopo do usuario. Nas proximas execucoes, atualiza automaticamente se houver nova versao.

### Claude Code — via Marketplace

Dentro do Claude Code, execute os seguintes slash commands:

```
/plugin marketplace add stone-payments/vela
/plugin install vela
```

### Claude Code — via clone local

```bash
git clone git@github.com:stone-payments/vela.git
claude --plugin-dir ./vela/.claude-plugin-root
```

### GitHub Copilot

Nenhuma instalacao necessaria. O arquivo `agents/vela.agent.md` e detectado automaticamente pelo Copilot em repositorios que referenciem este projeto. Invoque com `@vela` no chat do Copilot.

As skills do Copilot sao sincronizadas pelo KLI:

```bash
kli vela sync
```

### KLI (Karavela Line Interface)

O KLI integra o Vela nativamente via flag `--ask-vela`:

```bash
kli check app minha-app --ask-vela
```

Isso executa o diagnostico de saude e envia o resultado ao agente para analise automatica.

## Comandos interativos

Disponiveis como slash commands no Claude Code (`/vela:<comando>`) e como fluxos guiados no Copilot:

| Comando | Descricao |
|---------|-----------|
| `troubleshoot` | Diagnostico interativo de problemas (CrashLoopBackOff, OOM, Kyverno, Trivy, etc.) |
| `onboarding` | Guia passo a passo para criar e deployar a primeira aplicacao |
| `configure-chart` | Configuracao interativa de Helm chart com geracao de `values.yaml` |
| `check-security` | Verificacao de seguranca (Trivy, Kyverno, KubeArmor) |

## Skills


O agente possui 55 skills que sao invocadas automaticamente conforme o contexto da pergunta:

**Plataforma**
- `onboarding` — Primeiros passos e criacao de aplicacoes
- `ambientes-contextos` — Staging, sandbox, producao, namespaces
- `modelo-acessos` — Permissoes, Sailpoint, Opsgenie, IRSA
- `preview-envs` — Ambientes efemeros para pull requests
- `multi-regiao` — Deploy multi-regiao e failover

**Charts e Deploy**
- `charts-config` — Helm charts (API, Worker, CronJob, Job, StatefulSet)
- `charts-changelog` — Diff de changelogs entre versoes de charts (agregado)
- `deploy-rollback` — Fluxos de deploy, rollback, canary
- `migrations-jobs` — Jobs, CronJobs e migrations de banco
- `recursos-scaling` — CPU, memoria, replicas, KEDA

**Seguranca e Secrets**
- `seguranca` — Trivy, Kyverno, KubeArmor, CiliumNetworkPolicy
- `secrets-vault` — Vault, External Secrets Operator
- `auditoria-siem` — Lifecycle audit e integracao SIEM

**Observabilidade e Networking**
- `observabilidade` — Datadog, Grafana Loki/Mimir, APM, alertas
- `networking-ingress` — Kong Gateway, DNS, VPN, ingress

**CI/CD e Testes**
- `megalinter` — Linting estatico com MegaLinter
- `ci-test-coverage-*` — Coverage para Go, Node.js, Python, .NET, Kotlin KMP
- `ci-mutation-testing-*` — Testes de mutacao para Go, Node.js, Python, C#, Kotlin KMP
- `unit-testing-*` — Boas praticas de teste unitario para Go, Node.js, Python, C#, Kotlin KMP

## Estrutura do repositorio

```
.
├── agents/
│   └── vela.agent.md               # Agente GitHub Copilot
├── skills/                          # 55 skills (fonte unica de verdade)
├── .claude-plugin/
│   └── marketplace.json             # Registro no marketplace Claude Code
├── .claude-plugin-root/
│   ├── .claude-plugin/
│   │   └── plugin.json              # Manifesto do plugin
│   ├── agents/
│   │   └── vela.md                  # Agente Claude Code
│   ├── commands/                    # Comandos interativos
│   │   ├── check-security.md
│   │   ├── configure-chart.md
│   │   ├── onboarding.md
│   │   └── troubleshoot.md
│   ├── knowledge/
│   │   └── kli-commands.md          # Referencia de comandos KLI
│   └── skills -> ../skills          # Symlink para skills compartilhadas
└── catalog-info.yaml                # Registro Backstage
```

## Troubleshooting

**Plugin Claude Code nao carrega?**
Verifique que `.claude-plugin-root/.claude-plugin/plugin.json` existe e contem o manifesto valido.

**Skills nao encontradas?**
O diretorio `skills/` dentro de `.claude-plugin-root` e um symlink. Verifique que esta intacto:
```bash
ls -la .claude-plugin-root/skills
```

**KLI nao autenticado?**
```bash
kli auth login
```

**Copilot nao reconhece o agente?**
Verifique que `agents/vela.agent.md` esta na raiz do repositorio e que o Copilot agent mode esta habilitado nas configuracoes do VS Code.

## Contato

Canal de suporte: **#help-foundation-platform** no Slack

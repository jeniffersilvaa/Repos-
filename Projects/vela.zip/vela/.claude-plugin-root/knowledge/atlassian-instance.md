---
name: atlassian-instance
send-to-portal: true
---

# Atlassian — Instância allstone

## cloudId

O `cloudId` da instância allstone é sempre o UUID abaixo. Use-o em **todas** as chamadas MCP Atlassian:

```
ca411e38-8afa-4b8d-b017-bb924bcf4775
```

> **Nunca use `allstone.atlassian.net` como `cloudId`** — o MCP retorna `[]` silenciosamente sem nenhum erro, causando queries aparentemente vazias.

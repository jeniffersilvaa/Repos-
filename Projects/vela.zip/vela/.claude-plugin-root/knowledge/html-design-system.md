---
name: html-design-system
send-to-portal: true
---

# PM Ally HTML Reports — Design System (Vela)

## Propósito

Source of truth para o design visual de todos os relatórios HTML gerados por skills do PM Ally no Vela.
Define os tokens do Stone Jade Design System, padrões de componentes, regras de layout e
convenções de header/footer que toda skill de relatório deve seguir.

Para o bloco CSS completo de tokens e os padrões HTML de componentes, carregar também
`.claude-plugin-root/knowledge/html-components.md`.

---

## ⚠ Regras estruturais críticas — leia antes de gerar qualquer HTML

Estas são as regras mais frequentemente violadas. Verificar cada uma antes de renderizar:

1. **KPI cards ficam dentro do header escuro** — não abaixo dele no body da página.
   São cards brancos (`background:#fff`) colocados dentro da div `#002912` do header.
2. **Alinhamento boletim (Full layout)** — header, body e footer compartilham o mesmo container:
   `width:100%; padding:0 32px`. Nunca usar `max-width` ou containers mais estreitos.
3. **Footer é um card escuro arredondado** — `background:#002912; border-radius:0 0 16px 16px`.
   Contém apenas: `Gerado por <strong style="color:#9DBEAF">@PM-Ally</strong>`.
   Sem timestamp, sem fonte de dados, sem linhas extras.
4. **Cards** sempre têm `border-radius:12px` E `box-shadow:0 2px 8px rgba(26,33,30,.08)`.
5. **Tags/badges** usam `border-radius:4px` — nunca `border-radius:99px` (pill é reservado para o brand chip).
6. **Background da página** é `#EEF1F0` — nunca branco ou cinza genérico.

---

## Tokens de Design Principais

| Papel | Token | Valor |
|-------|-------|-------|
| Background da página | `--jade-bg` | `#EEF1F0` |
| Card / surface | `--jade-surface` | `#FFFFFF` |
| Header / nav | `--jade-nav` | `#002912` |
| Verde brand | `--jade-brand` | `#30A46C` |
| Muted no escuro | `--jade-on-nav` | `#9DBEAF` |
| Texto primário | `--jade-high` | `#1A211E` |
| Texto secundário | `--jade-medium` | `#4B5250` |
| Texto terciário | `--jade-low` | `#8A9290` |
| Borda | `--jade-border` | `#E6E9E8` |
| Positivo | `--jade-positive` | `#30A46C` / subtle `#E8F5EE` / dark `#005700` |
| Negativo | `--jade-negative` | `#E5484D` / subtle `#FFEAEA` / dark `#9B1C1F` |
| Warning | `--jade-warning` | `#F76808` / subtle `#FFF0E6` / dark `#7C3306` |
| Info | `--jade-info` | `#3E63DD` / subtle `#EEF2FF` / dark `#1E3A8A` |
| Neutro | `--jade-neutral-subtle` | `#EFEFEF` / text `#4B5250` |

---

## Tipografia

Sempre carregar Inter do Google Fonts:

```html
<link rel="preconnect" href="https://fonts.googleapis.com"/>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet"/>
```

| Uso | Tamanho / Peso |
|-----|---------------|
| Título do relatório (H1) | `22px / 800` |
| Header de seção | `16px / 700` |
| Título de card | `14px / 600` |
| Texto body | `14px / 400` |
| Label / suporte | `12px / 400–500` |
| Overline (headers de tabela, chips) | `11px / 700 uppercase letter-spacing:.8px` |

---

## Header Card (Full layout)

O header é um **card arredondado** — não uma barra full-width.

```html
<div style="padding:32px 32px 0;background:#EEF1F0">
  <div style="background:#002912;border-radius:16px 16px 0 0;padding:20px 32px">
    <!-- Brand chip -->
    <div style="display:inline-flex;align-items:center;gap:6px;background:#30A46C;
                color:#fff;padding:3px 10px;border-radius:9999px;font-size:10px;
                font-weight:700;letter-spacing:.8px;text-transform:uppercase;margin-bottom:10px">
      <span style="width:6px;height:6px;border-radius:50%;background:rgba(255,255,255,.6)"></span>
      PM ALLY
    </div>
    <h1 style="font-size:22px;font-weight:800;letter-spacing:-.5px;color:#fff;margin:0">
      [Tipo do Relatório] · [Período]
    </h1>
    <p style="font-size:13px;color:#9DBEAF;margin:4px 0 0">
      [Tribo] [· Time] · Atualizado em DD/MM/AA HHhMM
    </p>
    <!-- KPI cards aqui (máx 7) -->
  </div>
</div>
```

**Regras do título:**
- H1 = tipo do relatório ` · ` referência de período. Período depende do relatório: trimestre (`Q1-2026`), mês (`Abril 2026`), semana (`Semana 15/26`) ou rótulo de escopo. Omitir se o relatório não tem escopo temporal.
- Exemplos: `"Status Report KRs · Q1-2026"`, `"Time Health · Semana 15/26"`, `"Bugs Impeditivos · Abril 2026"`

**Regras do subtítulo:**
- Tribo, opcionalmente ` / Time` se tem escopo de time, depois ` · Atualizado em DD/MM/AA HHhMM`
- Data sempre com ano de 2 dígitos; hora sempre no formato `HHhMM` (ex: `17h00`)

---

## KPI Cards — dentro do header escuro

Background branco (`#FFFFFF`), **máximo 7 cards**.

```html
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));
            gap:12px;margin-top:20px">
  <div style="background:#FFFFFF;border-radius:12px;padding:18px 20px;
              text-align:center;border-top:2px solid [cor]">
    <div style="font-size:28px;font-weight:800;color:[cor]">[VALOR]</div>
    <div style="font-size:12px;color:#8A9290;margin-top:4px">[Label]</div>
  </div>
</div>
```

| Semântica | Cor | Quando usar |
|-----------|-----|-------------|
| Positivo | `#30A46C` | Métrica boa, no trilho |
| Negativo | `#E5484D` | Crítico, fora do trilho |
| Warning | `#F76808` | Em risco |
| Info | `#3E63DD` | Contagem neutra |
| Neutro | `#8A9290` | Contagem genérica |

Se mais de 7 totalizadores forem necessários, agrupe métricas relacionadas ou elimine as menos importantes.

---

## Footer Card (Full layout)

```html
<div style="padding:0 32px 32px;background:#EEF1F0">
  <div style="background:#002912;border-radius:0 0 16px 16px;color:#9DBEAF;
              text-align:center;padding:16px 24px;font-size:12px">
    Gerado por <strong style="color:#9DBEAF">@PM-Ally</strong>
  </div>
</div>
```

- Sempre `Gerado por @PM-Ally` — nada mais. Sem timestamp, sem fontes de dados, sem linhas adicionais.

---

## Regras de Layout

1. **Background da página** `#EEF1F0` — nunca branco, nunca cinza genérico.
2. **Cards/surfaces** `#FFFFFF` com `border-radius:12px` e `box-shadow:0 2px 8px rgba(26,33,30,.08)`.
3. **Fonte** Inter do Google Fonts. Nunca fazer fallback sem Inter primeiro.
4. **Verde é acento** — `#30A46C` apenas para estados positivos, brand chip, CTA primário.
5. **Hierarquia de texto** `#1A211E` → `#4B5250` → `#8A9290`. Nunca `#000` puro ou `#666`.
6. **Bordas** `#E6E9E8`. Nunca `#ddd` ou `#eee`.
7. **Progress bars** 6px de altura, raio pill, trilho cinza `#E6E9E8`.
8. **Tags/badges** `border-radius:4px` com pares de cores semânticas (ver html-components.md).
9. **Divisores de seção** usam o padrão pill-label `JadeGroupHeader` — nunca `<hr>` nu.
10. **Self-contained** — todo CSS inline ou em `<style>`. Nenhum CDN externo exceto Google Fonts.
11. **Full layout** — header, content e footer compartilham `width:100%; padding:0 32px`. Sem `max-width`.
12. **Tabelas devem ter background branco** — todo `<table>` (tabelas de dados, listagens) deve ter `background:#fff` no container e nas células `<td>`. Nunca deixar herdar o cinza da página.

---

## Checklist de Conformidade

- [ ] Inter font carregada do Google Fonts
- [ ] Background da página `#EEF1F0`
- [ ] Cards: `border-radius:12px` + shadow
- [ ] Header é um card arredondado (`border-radius:16px 16px 0 0`) — não full-width
- [ ] Header chip "PM ALLY" em `#30A46C`
- [ ] Header H1 = tipo do relatório · período; subtítulo = tribo [/ time] · Atualizado em DD/MM/AA HHhMM
- [ ] KPI cards: background branco, máx 7, dentro do header escuro
- [ ] Cores de texto `#1A211E` / `#4B5250` / `#8A9290`
- [ ] Todas as bordas `#E6E9E8`
- [ ] Tags `border-radius:4px` com pares semânticos
- [ ] Footer card arredondado (`border-radius:0 0 16px 16px`), `Gerado por @PM-Ally`
- [ ] Full layout: header + content + footer sem `max-width`, `padding:0 32px`
- [ ] Completamente self-contained (sem CDN externo)
- [ ] Tabelas: container e `<td>` com `background:#fff` — nunca herdar cinza da página
- [ ] Chart.js (se usado): todo chart tem `maintainAspectRatio: false`; wrapper pai tem `height` explícita em CSS; charts lado a lado usam `flex:1` igual

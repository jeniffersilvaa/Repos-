---
name: html-components
send-to-portal: true
---

# Report Template — Referência Completa de Componentes (Vela)

Carregar este arquivo ao construir qualquer skill de relatório que use estes componentes.

---

## Design Tokens — Bloco CSS Completo

```css
:root {
  /* Brand */
  --jade-brand:           #30A46C;
  --jade-brand-dark:      #005700;
  --jade-brand-subtle:    #E8F5EE;

  /* Navigation / Header */
  --jade-nav:             #002912;
  --jade-on-nav:          #9DBEAF;

  /* Page & Surface */
  --jade-bg:              #EEF1F0;
  --jade-surface:         #FFFFFF;
  --jade-neutral:         #F6F8F7;
  --jade-neutral-subtle:  #EFEFEF;

  /* Content / Text */
  --jade-high:            #1A211E;
  --jade-medium:          #4B5250;
  --jade-low:             #8A9290;

  /* Borders */
  --jade-border:          #E6E9E8;
  --jade-border-mid:      #C9CFCD;

  /* Feedback */
  --jade-positive:        #30A46C;  --jade-positive-subtle: #E8F5EE;  --jade-positive-dark: #005700;
  --jade-negative:        #E5484D;  --jade-negative-subtle: #FFEAEA;  --jade-negative-dark: #9B1C1F;
  --jade-warning:         #F76808;  --jade-warning-subtle:  #FFF0E6;  --jade-warning-dark:  #7C3306;
  --jade-info:            #3E63DD;  --jade-info-subtle:     #EEF2FF;  --jade-info-dark:     #1E3A8A;

  /* Corner Radius */
  --r-xs:   4px;
  --r-sm:   8px;
  --r-md:   12px;
  --r-lg:   16px;
  --r-pill: 9999px;

  /* Shadows */
  --shadow-sm: 0 1px 3px rgba(26,33,30,.06), 0 1px 2px rgba(26,33,30,.04);
  --shadow-md: 0 2px 8px rgba(26,33,30,.08);
  --shadow-lg: 0 4px 16px rgba(26,33,30,.10), 0 2px 6px rgba(26,33,30,.06);

  /* Spacing (base 4px) */
  --s-50:  4px;  --s-100: 8px;  --s-150: 12px;  --s-200: 16px;
  --s-250: 20px; --s-300: 24px; --s-400: 32px;  --s-500: 40px;
}
```

---

## Base HTML Shell (Full layout)

```html
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>[Título do Relatório]</title>
  <link rel="preconnect" href="https://fonts.googleapis.com"/>
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet"/>
  <style>/* colar bloco de tokens completo + CSS dos componentes aqui */</style>
</head>
<body style="margin:0;padding:0;background:#EEF1F0;font-family:Inter,sans-serif">
  <!-- HEADER CARD -->
  <!-- FILTERS (se necessário) -->
  <!-- CONTENT (padding:0 32px) -->
  <!-- FOOTER CARD -->
</body>
</html>
```

---

## JadeCardContainer — card de conteúdo

```html
<div style="background:#fff;border-radius:12px;
            box-shadow:0 2px 8px rgba(26,33,30,.08);
            overflow:hidden;margin-bottom:24px">
  <!-- conteúdo do card -->
</div>
```

---

## JadeListItem — linhas de tabela

- Linha de header: `background:#F6F8F7`, `border-bottom:1px solid #E6E9E8`
- Células de header: `font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:.7px; color:#8A9290`
- Linhas de dados: `border-bottom:1px solid #E6E9E8`, hover: `background:#F6F8F7`

```html
<!-- Linha de header -->
<div style="display:grid;grid-template-columns:[colunas];gap:12px;
            padding:12px 24px;background:#F6F8F7;border-bottom:1px solid #E6E9E8">
  <div style="font-size:11px;font-weight:700;text-transform:uppercase;
              letter-spacing:.7px;color:#8A9290">Coluna</div>
</div>
<!-- Linha de dados -->
<div style="display:grid;grid-template-columns:[mesmas];gap:12px;
            padding:16px 24px;border-bottom:1px solid #E6E9E8;align-items:center">
  <div>
    <div style="font-size:14px;font-weight:600;color:#1A211E">Título</div>
    <div style="font-size:12px;color:#8A9290;margin-top:2px">Subtítulo</div>
  </div>
</div>
```

---

## Data Table — layout fixo

```css
.data-table table { width:100%; border-collapse:collapse; table-layout:fixed; font-size:13px; background:#fff; }
.data-table td    { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; background:#fff; }
/* para colunas de texto longo: */
.data-table.wrap-table td {
  white-space:normal; word-break:break-word; overflow-wrap:break-word;
  vertical-align:top; padding-top:10px; padding-bottom:10px;
}
```

Container obrigatório:
```html
<div class="table-wrap" style="background:#fff;border:1px solid #E6E9E8;border-radius:12px;overflow:hidden">
  <table class="data-table">...</table>
</div>
```

---

## JadeProgressBar

```html
<div style="display:flex;align-items:center;gap:10px">
  <div style="flex:1;height:6px;background:#E6E9E8;border-radius:9999px;overflow:hidden">
    <div style="height:100%;width:[N%];border-radius:9999px;background:[cor]"></div>
  </div>
  <span style="font-size:12px;font-weight:700;color:[cor];min-width:36px;text-align:right">[N%]</span>
</div>
```

Cor do fill: ≥90% → `#30A46C` | 70–89% → `#F76808` | <70% → `#E5484D`

---

## JadeTag / Badge

```html
<!-- Positivo  --> <span style="background:#E8F5EE;color:#005700;padding:3px 8px;border-radius:4px;font-size:11px;font-weight:700">Label</span>
<!-- Negativo  --> <span style="background:#FFEAEA;color:#9B1C1F;padding:3px 8px;border-radius:4px;font-size:11px;font-weight:700">Label</span>
<!-- Warning   --> <span style="background:#FFF0E6;color:#7C3306;padding:3px 8px;border-radius:4px;font-size:11px;font-weight:700">Label</span>
<!-- Info      --> <span style="background:#EEF2FF;color:#1E3A8A;padding:3px 8px;border-radius:4px;font-size:11px;font-weight:700">Label</span>
<!-- Neutro    --> <span style="background:#DDE1E0;color:#4B5250;padding:3px 8px;border-radius:4px;font-size:11px;font-weight:700">Label</span>
```

Sempre `border-radius:4px`. Nunca pill shape para tags de dados.

---

## JadeAlert — callout box

```html
<div style="display:flex;align-items:flex-start;gap:12px;padding:16px 20px;
            border-radius:12px;background:[subtle];color:[dark];
            font-size:13px;line-height:1.6;margin-bottom:24px">
  <span style="font-size:16px;flex-shrink:0">⚠️</span>
  <span><strong>Título:</strong> Descrição.</span>
</div>
```

Pares de cores: positivo `#E8F5EE/#005700` | warning `#FFF0E6/#7C3306` | negativo `#FFEAEA/#9B1C1F` | info `#EEF2FF/#1E3A8A` | neutro `#F6F8F7/#4B5250`

---

## JadeGroupHeader — divisor de seção

Pill centralizado com linhas nos dois lados.

```html
<div style="display:flex;align-items:center;gap:20px;margin:40px 0 24px">
  <div style="flex:1;height:1px;background:#E6E9E8"></div>
  <div style="font-size:12px;font-weight:700;color:#4B5250;text-transform:uppercase;
              letter-spacing:.8px;padding:4px 12px;background:#fff;
              border:1px solid #E6E9E8;border-radius:9999px">Label da Seção</div>
  <div style="flex:1;height:1px;background:#E6E9E8"></div>
</div>
```

Nunca usar `<hr>` nu. Sempre o padrão pill-label centralizado.

---

## JadeActionButton — barra de filtros sticky

```html
<div style="background:#fff;border-bottom:1px solid #E6E9E8;
            position:sticky;top:0;z-index:100;box-shadow:0 1px 3px rgba(26,33,30,.06)">
  <div style="padding:12px 32px;display:flex;align-items:center;gap:8px;flex-wrap:wrap">
    <span style="font-size:11px;font-weight:700;color:#8A9290;text-transform:uppercase;letter-spacing:.8px">Filtrar:</span>
    <button style="padding:6px 12px;background:#EFEFEF;border:none;border-radius:8px;
                   font-family:inherit;font-size:13px;font-weight:600;color:#4B5250;cursor:pointer">Todos</button>
    <!-- estado ativo: background:#E8F5EE; color:#005700 -->
  </div>
</div>
```

---

## Hierarchical Collapsible

Usar `<details><summary>` para hierarquias pai–filho (OKRs/KRs, épicos/tasks).

- `<summary>`: `cursor:pointer; list-style:none; display:flex; align-items:center; gap:10px`
- Indentação filho: `margin-left:24px; border-left:2px solid #E6E9E8; padding-left:16px`
- Todos os nós começam **fechados** por padrão
- Usar também para listas com overflow (>5 itens)

---

## Tab Bar

Controle segmentado. Usar quando seções são paralelas e de mesmo peso (não pai–filho). Apenas Vanilla JS.

**CSS** — adicionar ao `<style>`:

```css
.tab-bar {
  display: flex; gap: 4px; background: #FFFFFF;
  border-bottom: 1px solid #E6E9E8; padding: 0 8px;
  position: sticky; top: 0; z-index: 100;
  box-shadow: 0 1px 3px rgba(26,33,30,.06);
  border-radius: 12px 12px 0 0; margin-top: 20px;
}
.tab-btn {
  padding: 12px 20px; background: none; border: none;
  border-bottom: 2px solid transparent; border-radius: 10px 10px 0 0;
  font-family: inherit; font-size: 14px; font-weight: 600;
  color: #8A9290; cursor: pointer;
  transition: color .15s, border-color .15s, background .15s;
  white-space: nowrap; display: flex; align-items: center; gap: 6px;
}
.tab-btn:hover { background: #F6F8F7; }
.tab-count {
  font-size: 12px; font-weight: 700; background: #F6F8F7;
  border-radius: 9999px; padding: 1px 7px; color: inherit;
}
.tab-panel { background: #FFFFFF; border-radius: 0 0 12px 12px; padding: 16px 0 4px; margin-bottom: 16px; }
```

**HTML**:

```html
<div class="tab-bar">
  <button class="tab-btn tab-active" data-color="#E5484D"
          onclick="showTab('tab-a', this)">
    🔴 Em Risco <span class="tab-count">2</span>
  </button>
  <button class="tab-btn" data-color="#CA8A04"
          onclick="showTab('tab-b', this)">
    🟡 Atenção <span class="tab-count">3</span>
  </button>
</div>
<div id="tab-a" class="tab-panel"><!-- conteúdo --></div>
<div id="tab-b" class="tab-panel" style="display:none"><!-- conteúdo --></div>
```

**JS** — adicionar antes de `</body>`:

```html
<script>
function showTab(id, btn) {
  document.querySelectorAll('.tab-panel').forEach(function(p) { p.style.display = 'none'; });
  document.querySelectorAll('.tab-btn').forEach(function(b) {
    b.classList.remove('tab-active');
    b.style.borderBottomColor = 'transparent';
    b.style.color = '';
  });
  var panel = document.getElementById(id);
  if (panel) panel.style.display = 'block';
  btn.classList.add('tab-active');
  btn.style.borderBottomColor = btn.dataset.color;
  btn.style.color = btn.dataset.color;
}
window.addEventListener('DOMContentLoaded', function() {
  var active = document.querySelector('.tab-btn.tab-active');
  if (active) {
    active.style.borderBottomColor = active.dataset.color;
    active.style.color = active.dataset.color;
  }
});
</script>
```

**Regras:**
- Cada `data-color` carrega a cor semântica para o estado ativo (vermelho/amarelo/verde/azul)
- Tab ativa padrão = primeiro grupo não-vazio; definir `class="tab-btn tab-active"` no HTML
- Pill `tab-count` herda a cor do texto do estado ativo automaticamente

---

## Estrutura do Relatório (Full layout)

```
HEADER CARD     #002912 arredondado · brand chip "PM ALLY" · H1: tipo · período
                · subtítulo: tribo [/ time] · Atualizado em DD/MM/AA HHhMM
                · KPI cards (máx 7, background branco, dentro do card escuro)
STICKY FILTERS  background branco, JadeActionButton (apenas se conteúdo filtrável)
SECTIONS        um JadeGroupHeader por tópico ou tempo
  CALLOUT       JadeAlert para bloqueadores / riscos / padrões cross-time
  TABLE / GRID  linhas JadeListItem dentro de JadeCardContainer
  COLLAPSIBLE   <details><summary> para hierarquias ou listas com overflow
FOOTER CARD     #002912 arredondado · "Gerado por @PM-Ally" (apenas isso)
```

Todo conteúdo usa `padding:0 32px` sem `max-width`.

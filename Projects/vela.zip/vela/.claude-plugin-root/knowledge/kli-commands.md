# KLI - Karavela Line Interface

Referencia de comandos do KLI permitidos para o agente Vela. Inclui **read** (livre) e **write** (com regras de confirmacao).

## Regras de Uso

1. **Sempre usar modo raw** (`-r`) para que a saida seja parseavel
2. **Preferir saida JSON** (`-r -o json`) para dados estruturados
3. **Read-only** (tabela abaixo): pode executar diretamente. **Write**: SEMPRE pedir confirmacao do usuario antes de executar (em prd, dupla confirmacao).
4. **Autenticacao**: Antes de qualquer operacao, verificar `kli auth status`. Se nao autenticado, orientar a rodar `kli auth login` (interativo — pedir ao usuario para rodar manualmente).
5. **Aplicacao padrao**: Se o usuario tem uma app padrao (`kli set app`), comandos podem omitir o nome.
6. **Equivalente MCP**: Os comandos KLI tem espelho em `mcp__vela-mcp-hub__kli-mcp__*` (ex: `mcp__vela-mcp-hub__kli-mcp__create_secret`). Prefira o MCP quando estiver configurado. Mesmas regras de confirmacao.
7. **Secrets — guardrail**: NUNCA expor valor real de secret na saida. Sempre mascarar como `<set>` ou `<valor-no-vault>`. Ver skill `secrets-vault`.

## Allowlist de Comandos

### Diagnostico do Ambiente

| Comando | Descricao | Quando usar |
|---------|-----------|-------------|
| `kli doctor` | Verificar pre-requisitos | Quando o usuario reportar problemas com kli |
| `kli auth status` | Status da autenticacao | Antes de qualquer operacao que exija auth |

### Consulta de Aplicacoes

| Comando | Descricao | Quando usar |
|---------|-----------|-------------|
| `kli get apps -r -o json` | Listar aplicacoes | Quando precisar listar ou buscar apps do usuario |
| `kli describe app <nome> -r -o json` | Detalhes de uma app (ambientes, deploys, custos, tags) | Para diagnostico, detalhes de deploy, ambientes |

### Monitoramento e Diagnostico

| Comando | Descricao | Quando usar |
|---------|-----------|-------------|
| `kli check app <nome> -r -o json` | Diagnostico rapido de saude | Troubleshooting, verificacao de health/sync/pods |
| `kli get events <nome> -r -o json` | Eventos Kubernetes (Warning por padrao) | Investigar erros, CrashLoopBackOff, OOM |
| `kli get events <nome> --all -r -o json` | Todos os eventos (incluindo Normal) | Investigacao mais ampla |
| `kli get events <nome> --filter "<texto>" -r -o json` | Eventos filtrados por texto | Buscar eventos especificos |
| `kli logs app <nome> -r` | Streaming de logs (NDJSON) | Investigar erros em runtime |
| `kli logs app <nome> --env <env> -r` | Logs de ambiente especifico | Investigar em stg/sdx/prd |
| `kli watch app <nome> -r -o json` | Status de deploy em tempo real | Monitorar rollout, verificar progresso |

### Secrets (somente leitura)

| Comando | Descricao | Quando usar |
|---------|-----------|-------------|
| `kli get secrets -r -o json` | Listar nomes de secrets (NAO valores) | Verificar quais secrets existem |

### Pull Requests

| Comando | Descricao | Quando usar |
|---------|-----------|-------------|
| `kli get prs -r -o json` | Listar PRs abertos do usuario | Contexto sobre trabalho em andamento |
| `kli describe pr -r -o json` | Detalhes do PR da branch atual | Contexto sobre PR atual |
| `kli describe pr <numero> -r -o json` | Detalhes de PR especifico | Investigar PR especifico |

## Comandos de Escrita (Write) — Requerem Confirmacao

### Secrets

| Comando | MCP equivalente | Confirmacao |
|---------|-----------------|-------------|
| `kli create secret <key> <value>` | `mcp__vela-mcp-hub__kli-mcp__create_secret` | 1 confirmacao (stg/sdx); dupla em prd |
| `kli edit secret <key> <value>` | `mcp__vela-mcp-hub__kli-mcp__update_secret` | 1 confirmacao; dupla em prd |
| `kli rename secret <old> <new>` | `mcp__vela-mcp-hub__kli-mcp__rename_secret` | 1 confirmacao sempre |
| `kli delete secret <key>` | `mcp__vela-mcp-hub__kli-mcp__delete_secret` | **DUPLA confirmacao sempre** (destrutivo) |
| `kli diff secret <key>` | `mcp__vela-mcp-hub__kli-mcp__diff_secrets` | Read — livre |

**Fluxo do `kli create/edit secret`**:
1. Mostrar plano: chave, ambiente, app, motivo.
2. Pedir confirmacao explicita: "Vou criar `MY_API_KEY` em `payments-api` ambiente `stg`. Confirma?"
3. **Nao** ecoar o valor na resposta. Use placeholder.
4. Apos sucesso, sugerir `kli check app` para validar refresh dos pods.

### Aplicacoes / Deploys

| Comando | MCP equivalente | Confirmacao |
|---------|-----------------|-------------|
| Criar app via template | `mcp__vela-mcp-hub__kli-mcp__create_app` | 1 confirmacao com plano completo |
| Criar static app | `mcp__vela-mcp-hub__kli-mcp__create_static_app` | 1 confirmacao |
| Deploy artifact static | `mcp__vela-mcp-hub__kli-mcp__deploy_static_artifact` | 1 confirmacao stg; dupla em prd |
| Deploy HTML inline | `mcp__vela-mcp-hub__kli-mcp__deploy_inline_html` | 1 confirmacao |

### Auth

| Comando | Comportamento |
|---------|---------------|
| `kli auth login` | INTERATIVO — pedir ao usuario para rodar manualmente |
| `kli auth logout` | Confirmar antes de invalidar a sessao |

## Mapeamento Skill → Comandos KLI (Read + Write)

Com modo agentic, o mapeamento inclui writes que cada skill pode propor. **Read** = pode rodar livre. **Write** = pode propor, exige confirmacao.

| Skill | Read | Write (propor com confirmacao) |
|-------|------|-------------------------------|
| `troubleshooting` | `check app`, `get events`, `logs app`, `watch app`, `describe app` | — |
| `observabilidade` | `logs app`, `watch app`, `get events`, `describe app` | — |
| `deploy-rollback` | `watch app`, `describe app`, `get apps` | — |
| `charts-config` | `describe app` | — |
| `secrets-vault` | `get secrets` (so nomes), `diff secret` | **`create/edit/rename/delete secret`** |
| `recursos-scaling` | `describe app`, `check app` | — |
| `ambientes-contextos` | `get apps`, `describe app` | — |
| `onboarding` | `get apps`, `doctor`, `whoami` | **`create_app`, `create_static_app`** |
| `seguranca` | `check app`, `get events` | — |
| `karavela-packages` | `list_*`, `describe_resource` | (via MCP) `prepare/publish_static_app_draft` |
| `migrations-jobs` | `describe app`, `watch app` | — |
| `migrate-to-karavela-packages` | `describe app` | — |

Skills nao listadas: somente read (qualquer comando da tabela read-only acima e livre).

## Formato de Saida

O modo raw com JSON (`-r -o json`) retorna objetos JSON parseaveís. Use isso para:
- Extrair campos especificos
- Comparar dados entre ambientes
- Gerar relatorios estruturados

O modo raw com YAML (`-r -o yaml`) e util para:
- Inspecionar recursos Kubernetes detalhados (`kli check app -r -o yaml`)
- Compatibilidade com configuracoes Helm/Kubernetes

Logs em modo raw (`kli logs app -r`) retornam NDJSON (uma linha JSON por log entry).

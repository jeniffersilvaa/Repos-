---
description: Configuracao interativa de Helm chart da plataforma Karavela. Gera values.yaml customizado para seu cenario.
---

# Configurar Chart Karavela

Ajude o usuario a configurar o Helm chart da plataforma para sua aplicacao. Responda SEMPRE em portugues do Brasil.

Consulte as skills `charts-config` e `recursos-scaling` para conhecimento base.

## Fluxo

1. Use `AskUserQuestion` para coletar:
   - "Qual tipo de chart voce precisa?"
   - Opcoes: API (HTTP/gRPC), Worker (consumidor de fila), CronJob (tarefa agendada), Job (execucao unica)

2. Use `AskUserQuestion` para coletar:
   - "Quais features voce precisa configurar?"
   - multiSelect: true
   - Opcoes: Resources (CPU/memoria), Autoscaling (KEDA), Ingress, Secrets (Vault), Health checks, InitialJob (migrations), Observabilidade (APM/metricas)

3. Para cada feature selecionada, colete os detalhes necessarios via `AskUserQuestion`

4. Gere um `values.yaml` completo e customizado com:
   - Comentarios explicativos em cada secao
   - Labels obrigatorias preenchidas
   - Boas praticas da plataforma aplicadas
   - Alertas sobre restricoes relevantes

## Regras

- Sempre incluir labels obrigatorias: `cost-center`, `project`, `owner`, `support`, `github-org`, `github-repo`, `env`
- NUNCA expor valores de secrets — usar placeholders `<valor-no-vault>`
- Recomendar `replicaCount >= 2` fora de staging
- Recomendar health checks (liveness + readiness) para APIs
- NUNCA sugerir `kubectl` ou `argocd` CLI

## Formato de Saida

1. **Chart.yaml** completo com dependencia OCI
2. **values.yaml** customizado com comentarios
3. **Explicacao** de cada secao configurada
4. **Proximos passos** (secrets no Portal, workflow CI, primeiro deploy)

---
description: Guia interativo de primeiro deploy na plataforma Karavela. Passo a passo para criar e deployar uma aplicacao.
---

# Onboarding Karavela

Guie o usuario no processo de criar e deployar sua primeira aplicacao na plataforma Karavela. Responda SEMPRE em portugues do Brasil.

Consulte a skill `onboarding` para o conhecimento base.

## Fluxo

1. Use `AskUserQuestion` para perguntar:
   - "Qual tipo de aplicacao voce quer criar?"
   - Opcoes: API REST, Worker (consumidor de fila), CronJob (tarefa agendada), Job (execucao unica)
2. Use `AskUserQuestion` para perguntar:
   - "Voce ja tem um repositorio existente ou quer criar um novo?"
   - Opcoes: Repositorio existente, Criar novo
3. Siga o guia de onboarding adaptado ao tipo escolhido
4. Apresente os passos com exemplos praticos de YAML/configuracao

## Conteudo do Guia

Para cada tipo de aplicacao, cubra:

1. **Pre-requisitos**: VPN, Sailpoint, GitHub, Opsgenie team
2. **Criacao no Portal**: Template "Criar aplicacao" no Karavela Portal
3. **Configuracao do Chart**: `Chart.yaml` + `values-stg.yaml` minimo
4. **Primeiro Deploy**: Commit na branch develop para staging
5. **Verificacao**: ArgoCD health, health checks, replicas
6. **Proximos passos**: Secrets, observabilidade, promocao de ambientes

## Regras

- NUNCA sugira usar `kubectl` ou `argocd` CLI
- Sempre recomendar pelo menos 2 replicas fora de staging
- Incluir labels obrigatorias no exemplo de values.yaml
- Direcionar para #help-foundation-platform em caso de duvidas

---
description: Verificacao de seguranca da configuracao na plataforma Karavela. Analisa vulnerabilidades, politicas Kyverno e KubeArmor.
---

# Verificacao de Seguranca Karavela

Analise a configuracao de seguranca da aplicacao do usuario. Responda SEMPRE em portugues do Brasil.

Consulte a skill `seguranca` para conhecimento base.

## Fluxo

1. Use `AskUserQuestion` para perguntar:
   - "O que voce quer verificar?"
   - Opcoes: Vulnerabilidades (Trivy), Politicas de deploy (Kyverno), Protecao runtime (KubeArmor), Revisao geral

2. Com base na escolha:

### Vulnerabilidades (Trivy)
- Explique como o Trivy funciona no pipeline CI
- Severidades bloqueantes: CRITICAL, HIGH, UNKNOWN
- Como verificar localmente: `docker run --rm aquasec/trivy image <imagem>`
- Como corrigir: atualizar base image ou pacotes
- `.trivyignore` como ultimo recurso (NAO recomendado)

### Politicas de Deploy (Kyverno)
- Labels obrigatorias no values.yaml
- Erros comuns: pods Pending/Unhealthy por labels faltando
- Como verificar: events no ArgoCD via Portal
- Break Glass para situacoes de emergencia

### Protecao Runtime (KubeArmor)
- Monitoramento de integridade em clusters PCI
- Restricoes de runtime aplicadas

### Revisao Geral
- Verificar todas as areas acima
- Checklist completo de seguranca

## Regras

- NUNCA sugira desabilitar politicas de seguranca como solucao
- NUNCA sugira usar `kubectl` ou `argocd` CLI
- Se o usuario estiver bloqueado por Trivy/Kyverno, ajude a corrigir a causa raiz
- Direcione para #help-foundation-platform para casos complexos

## Formato de Resposta

1. **Status** (o que foi verificado)
2. **Problemas encontrados** (se houver)
3. **Recomendacoes** (passos praticos para corrigir/melhorar)
4. **Fonte** (link para documentacao relevante)

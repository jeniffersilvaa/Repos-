# CLAUDE.md

## What This Repo Is

This is a **Claude Code plugin** (not a traditional application) that helps Stone developers work with the **Karavela internal platform**. It has no build system, tests, or runtime — it's a collection of markdown knowledge files, agent instructions, and skills that get loaded into Claude Code as a plugin.

## Communication

All agent output must be in **pt-BR** (Brazilian Portuguese).

## Repository Structure

- `agents/vela.md` — Main agent persona and instructions
- `commands/` — Slash commands: troubleshoot, onboarding, configure-chart, check-security
- `skills/` — 55 skills covering platform configuration, deploy, security, testing, CI/CD (symlinked from repo root)
- `.claude-plugin/plugin.json` — Claude Code plugin manifest

## How It Works as a Plugin

Installed via marketplace or `claude --plugin-dir ./.claude-plugin-root`. The `agents/vela.md` defines the agent behavior. Commands in `commands/` become available as `/vela:<command>`. Skills in `skills/` (symlinked from repo root) are auto-invoked by Claude based on context.

## Dual-Purpose Repo

This repo also works as a GitHub Copilot agent via `agents/vela.agent.md` at the repo root. The `skills/` directory at root is shared by both platforms via symlink.

## Key Domains

- **Charts & Config**: Helm charts, values.yaml, umbrella pattern
- **Deploy & Operations**: ArgoCD flows, rollback, canary
- **Secrets**: Vault integration via External Secrets, Karavela Portal
- **Observability**: Datadog, Loki, Mimir, APM
- **Security**: Trivy, Kyverno, KubeArmor
- **Networking**: Kong, VPN, ingress types
- **Testing**: Unit testing (Go, Node, Python, Kotlin, C#), mutation testing, coverage CI
- **Platform**: Multi-region, onboarding, preview envs, access model, audit

## Referenced Repositories

- `stone-payments/karavela` — Documentation and API code
- `stone-payments/platform-k8s-charts` — Helm chart definitions
- `stone-payments/platform-k8s-crossplane` — Infrastructure as Code
- `stone-payments/karavela-core` — Backstage portal (frontend)

#!/usr/bin/env node
/**
 * sync-portal.ts
 * Sincroniza skills do Vela com o portal chat do karavela-core.
 *
 * Fase 1 — Varre skills/ em busca de playbook.yaml e gera manifest em memória
 * Fase 2 — Gera playbooks em output/playbooks/
 * Fase 3 — Aplica no karavela-core local (local) ou abre PR (remote)
 *
 * Uso: npx tsx scripts/sync-portal.ts [local|remote]
 */

import {
  readFileSync,
  writeFileSync,
  mkdirSync,
  readdirSync,
  existsSync,
  rmSync,
  copyFileSync,
} from 'node:fs'
import { join, resolve, dirname } from 'node:path'
import { execSync, spawnSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import { tmpdir } from 'node:os'

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)
const ROOT = resolve(__dirname, '..')

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

interface Frontmatter {
  [key: string]: string
}

/**
 * Parses simple YAML frontmatter (scalar values only).
 * Supports block scalars (>) but extracts only the first line of the value.
 */
function parseFrontmatter(content: string): { data: Frontmatter; body: string } {
  const match = content.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/)
  if (!match) return { data: {}, body: content }

  const data: Frontmatter = {}
  const rawYaml = match[1]
  const body = match[2] ?? ''

  let currentKey: string | null = null
  for (const line of rawYaml.split('\n')) {
    const scalar = line.match(/^([\w-]+)\s*:\s*(.+)$/)
    if (scalar) {
      currentKey = scalar[1]
      data[currentKey] = scalar[2].replace(/\s*>$/, '').trim()
      continue
    }
    if (/^\s+\S/.test(line) && currentKey) continue
    currentKey = null
  }

  return { data, body }
}

/** Reads a scalar field from frontmatter. Returns empty string if absent. */
function parseFrontmatterField(content: string, field: string): string {
  const match = content.match(/^---\r?\n([\s\S]*?)\r?\n---/)
  if (!match) return ''
  const re = new RegExp(`^${field}\\s*:\\s*(.+)$`, 'm')
  const m = match[1].match(re)
  if (!m) return ''
  return m[1].trim().replace(/^["'](.*)["']$/, '$1')
}

/** Reads a list field from frontmatter (e.g. triggers:, knowledge-refs:). */
function parseListField(content: string, field: string): string[] {
  const match = content.match(/^---\r?\n([\s\S]*?)\r?\n---/)
  if (!match) return []
  const items: string[] = []
  let inField = false
  for (const line of match[1].split('\n')) {
    if (new RegExp(`^${field}\\s*:`).test(line)) {
      inField = true
      continue
    }
    if (!inField) continue
    const item = line.match(/^\s+-\s+(.+)$/)
    if (item) {
      items.push(item[1].trim().replace(/^["'](.*)["']$/, '$1'))
      continue
    }
    if (line.length > 0 && !/^\s/.test(line)) break
  }
  return items
}

/** Strips diacritics from a string (e.g. "épico" → "epico"). */
function stripAccents(s: string): string {
  return s.normalize('NFD').replace(/[\u0300-\u036f]/g, '')
}

/**
 * Expands trigger list with accent-stripped variants only.
 * Article injection ("um"/"uma") is intentionally omitted — Portuguese gender
 * agreement can't be inferred mechanically from the trigger text, and the
 * resulting variants (e.g. "refinar uma backlog", "escrever uma épico") are
 * grammatically wrong more often than not. Maintainers should add article
 * variants explicitly in the playbook.yaml triggers: list when needed.
 */
function expandTriggers(triggers: string[]): string[] {
  const seen = new Set<string>()
  const result: string[] = []

  const add = (t: string) => {
    const norm = t.trim().toLowerCase()
    if (!norm || seen.has(norm)) return
    seen.add(norm)
    result.push(norm)
  }

  for (const base of triggers) {
    add(base)
    add(stripAccents(base))
  }

  return result
}

/**
 * Generates triggers from skill name and display-name when playbook.yaml
 * does not have a triggers: list. Produces short, meaningful phrases.
 */
function generateTriggers(name: string, displayName: string): string[] {
  const STOP_WORDS = new Set([
    'de', 'do', 'da', 'dos', 'das', 'para', 'e', 'a', 'o', 'um', 'uma', 'no', 'na',
  ])
  const base: string[] = []

  const display = displayName.toLowerCase().trim()
  const displayWords = display.split(/\s+/)

  // Add display-name if ≤ 3 words
  if (displayWords.length <= 3) base.push(display)

  // Add meaningful slug words (strip stop words, ≤ 3 words)
  const slugWords = name.split('-').filter(w => !STOP_WORDS.has(w))
  const slugPhrase = slugWords.join(' ')
  if (slugWords.length <= 3 && slugPhrase !== display) base.push(slugPhrase)

  // Add "criar <last meaningful noun>"
  const meaningfulWords = displayWords.filter(w => !STOP_WORDS.has(w) && w.length > 2)
  const lastNoun = meaningfulWords[meaningfulWords.length - 1]
  if (lastNoun && lastNoun !== display && !base.includes(`criar ${lastNoun}`)) {
    base.push(`criar ${lastNoun}`)
  }

  return expandTriggers([...new Set(base)])
}

/**
 * Removes sections that have no value in the portal:
 *   - ## Human Input    — local maintainer instructions
 *   - ## Escopo         — IN/OUT scope is for human reading, not execution
 *   - ## Exemplos de Perguntas — routing uses triggers: from playbook.yaml
 */
function stripPortalNoise(body: string): string {
  const sections = ['## Human Input', '## Escopo', '## Exemplos de Perguntas']
  let result = body
  for (const heading of sections) {
    const escaped = heading.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
    result = result.replace(new RegExp(`^${escaped}[\\s\\S]*?(?=^## |(?![\\s\\S]))`, 'm'), '')
  }
  return result
}

function run(cmd: string, cwd?: string): string {
  return execSync(cmd, { cwd: cwd ?? ROOT, encoding: 'utf8' }).trim()
}

let _stdinBuf = ''

function prompt(question: string): Promise<string> {
  process.stdout.write(question)
  return new Promise((resolve) => {
    const tryResolve = () => {
      const nl = _stdinBuf.indexOf('\n')
      if (nl !== -1) {
        const line = _stdinBuf.slice(0, nl).trim()
        _stdinBuf = _stdinBuf.slice(nl + 1)
        resolve(line)
        return true
      }
      return false
    }
    if (tryResolve()) return
    const onData = (chunk: Buffer) => {
      _stdinBuf += chunk.toString()
      if (tryResolve()) {
        process.stdin.removeListener('data', onData)
        process.stdin.pause()
      }
    }
    process.stdin.resume()
    process.stdin.on('data', onData)
  })
}

// ---------------------------------------------------------------------------
// Phase 1 — Scan (no portal.yaml written — manifest stays in memory)
// ---------------------------------------------------------------------------

interface SkillEntry {
  name: string        // folder name, kebab-case (e.g. "documentation")
  skillId: string     // snake_case   (e.g. "documentation")
  displayName: string
  uiDescription: string
  icon: string
  triggers: string[]
}

interface VelaManifest {
  skills: SkillEntry[]
  knowledges: string[] // filenames like "atlassian-instance.md"
}

function phase1(): VelaManifest {
  console.log('\n📋 Fase 1: Varrendo skills...')

  const skillsDir = join(ROOT, 'skills')
  const skills: SkillEntry[] = []
  const skipped: string[] = []

  for (const entry of readdirSync(skillsDir, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) {
    if (!entry.isDirectory()) continue
    const skillFile = join(skillsDir, entry.name, 'SKILL.md')
    if (!existsSync(skillFile)) continue

    // Skills without playbook.yaml are not flagged for portal — silently skip
    const playbookFile = join(skillsDir, entry.name, 'playbook.yaml')
    if (!existsSync(playbookFile)) continue

    const playbookContent = readFileSync(playbookFile, 'utf8')
    const playbookFm = `---\n${playbookContent}\n---\n`
    const displayName = parseFrontmatterField(playbookFm, 'display-name')
    const uiDescription = parseFrontmatterField(playbookFm, 'ui-description')
    const icon = parseFrontmatterField(playbookFm, 'icon')

    const missing: string[] = []
    if (!displayName) missing.push('display-name')
    if (!uiDescription) missing.push('ui-description')

    if (missing.length > 0) {
      skipped.push(`${entry.name} (falta em playbook.yaml: ${missing.join(', ')})`)
      continue
    }

    skills.push({
      name: entry.name,
      skillId: entry.name.replace(/-/g, '_'),
      displayName,
      uiDescription,
      icon,
      triggers: parseListField(playbookFm, 'triggers'),
    })
  }

  if (skipped.length > 0) {
    console.log('  ⚠️  Skills ignoradas (campos obrigatórios ausentes):')
    skipped.forEach(s => console.log(`     - ${s}`))
  }

  // Knowledges flagged for portal export
  const knowledgeDir = join(ROOT, '.claude-plugin-root', 'knowledge')
  const knowledges = existsSync(knowledgeDir)
    ? readdirSync(knowledgeDir)
        .filter(f => f.endsWith('.md'))
        .filter(f => {
          const { data } = parseFrontmatter(readFileSync(join(knowledgeDir, f), 'utf8'))
          return data['send-to-portal'] === 'true'
        })
        .sort()
    : []

  console.log(`  ✅ ${skills.length} skills | ${knowledges.length} knowledge(s)`)

  return { skills, knowledges }
}

// ---------------------------------------------------------------------------
// Phase 2 — Generate playbooks (written only to output/)
// ---------------------------------------------------------------------------

function phase2(manifest: VelaManifest): { playbooksDir: string } {
  console.log('\n📝 Fase 2: Gerando playbooks...')

  const outputDir = join(ROOT, 'output', 'playbooks')

  // Clean output dir before generating to avoid stale files
  if (existsSync(outputDir)) rmSync(outputDir, { recursive: true, force: true })
  mkdirSync(outputDir, { recursive: true })

  const skillsDir = join(ROOT, 'skills')
  const knowledgeDir = join(ROOT, '.claude-plugin-root', 'knowledge')
  let count = 0

  for (const skill of manifest.skills) {
    const skillFile = join(skillsDir, skill.name, 'SKILL.md')
    const content = readFileSync(skillFile, 'utf8')
    const { body } = parseFrontmatter(content)

    // Read portal metadata from playbook.yaml
    const playbookFile = join(skillsDir, skill.name, 'playbook.yaml')
    const playbookContent = readFileSync(playbookFile, 'utf8')
    const playbookFm = `---\n${playbookContent}\n---\n`

    // Triggers: read from playbook.yaml if present, generate otherwise.
    const frontmatterTriggers = parseListField(playbookFm, 'triggers')
    const triggers =
      frontmatterTriggers.length > 0
        ? expandTriggers(frontmatterTriggers)
        : generateTriggers(skill.name, skill.displayName)
    skill.triggers = triggers

    // Knowledge refs declared in playbook.yaml
    const knowledgeRefs = parseListField(playbookFm, 'knowledge-refs')
      .map(item => {
        const nameMatch = item.match(/^name:\s*(.+)$/)
        return nameMatch ? nameMatch[1].trim() : item
      })
      .filter(name => manifest.knowledges.includes(`${name}.md`))

    // --- Build playbook frontmatter ---
    const parts: string[] = []

    parts.push('---')
    parts.push('playbook-vela: true')
    parts.push('agent: "Vela"')
    parts.push(`skill-id: "${skill.skillId}"`)
    parts.push(`display-name: "${skill.displayName}"`)
    parts.push(`description: "${skill.uiDescription}"`)
    if (skill.icon) parts.push(`icon: "${skill.icon}"`)
    parts.push('triggers:')
    for (const t of triggers) {
      const escaped = t.replace(/"/g, '\\"')
      parts.push(`  - "${escaped}"`)
    }
    parts.push('---')
    parts.push('')

    // No announcement banner: karavela-core removed the model-authored one on
    // purpose (5baf21830, "remove model-authored skill banner from playbooks —
    // frontend renders it") and guards it with a test that fails if ANY playbook
    // contains "Iniciando a skill" (Orchestrator.test.ts). The frontend renders
    // the banner itself, so emitting it here would duplicate it in the chat.

    // Body: strip portal noise
    const processedBody = stripPortalNoise(body.trim())
    parts.push(processedBody)

    // --- Local references: inline into playbook ---
    const localRefsDir = join(skillsDir, skill.name, 'references')
    let localRefCount = 0
    if (existsSync(localRefsDir)) {
      const refFiles = readdirSync(localRefsDir).filter(f => f.endsWith('.md')).sort()
      for (const ref of refFiles) {
        const { data, body: refBody } = parseFrontmatter(readFileSync(join(localRefsDir, ref), 'utf8'))
        const sectionName = data['name'] ?? ref.replace(/\.md$/, '')
        parts.push('', `## ${sectionName}`, '', refBody.trim())
        localRefCount++
      }
    }

    // --- Knowledge refs: inline into playbook ---
    for (const name of knowledgeRefs) {
      const knowledgeFile = join(knowledgeDir, `${name}.md`)
      if (!existsSync(knowledgeFile)) {
        console.warn(`  ⚠️  Knowledge não encontrado: ${name}.md — ignorado`)
        continue
      }
      const { body: knowledgeBody } = parseFrontmatter(readFileSync(knowledgeFile, 'utf8'))
      parts.push('', knowledgeBody.trim())
    }

    writeFileSync(join(outputDir, `${skill.name}.md`), parts.join('\n') + '\n')
    count++

    const extras = [
      knowledgeRefs.length > 0 ? `${knowledgeRefs.length} knowledge(s)` : '',
      localRefCount > 0 ? `${localRefCount} ref(s)` : '',
    ]
      .filter(Boolean)
      .join(', ')
    console.log(`  ✅ ${skill.name}.md${extras ? ` (+${extras})` : ''}`)
  }

  console.log(`\n  ${count} playbooks gerados em output/playbooks/`)

  return { playbooksDir: outputDir }
}

// ---------------------------------------------------------------------------
// IntentClassifier.ts patching
// ---------------------------------------------------------------------------

/** Converts skill name (kebab) to intent name (snake). */
function toIntent(skillName: string): string {
  return skillName.replace(/-/g, '_')
}

/**
 * Patches IntentClassifier.test.ts: injects one PlaybookSignal fixture per Vela skill
 * between @vela-start / @vela-end markers inside the playbooks array.
 * If no markers exist yet, inserts them before the closing `];` of the playbooks array.
 */
function patchTestFixtures(targetDir: string, skills: SkillEntry[], prettierBin: string, prettierCwd: string): void {
  const filePath = join(targetDir, 'plugins', 'mcp-backend', 'src', 'service', 'IntentClassifier.test.ts')
  if (!existsSync(filePath)) {
    console.log('  ⚠️  IntentClassifier.test.ts não encontrado — ignorado')
    return
  }
  let src = readFileSync(filePath, 'utf8')

  const fixtureLines = skills.map(s => {
    const triggersJson = s.triggers.map(t => `      '${t.replace(/'/g, "\\'")}'`).join(',\n')
    return `  {\n    name: 'vela/${s.name}.md',\n    agent: 'Vela',\n    triggers: [\n${triggersJson},\n    ],\n  },`
  }).join('\n')

  if (!src.includes('// @vela-start')) {
    src = src.replace(/^(\];)$/m, `  // @vela-start\n  // @vela-end\n$1`)
  }

  src = src.replace(
    /(  \/\/ @vela-start\n)([\s\S]*?)(  \/\/ @vela-end)/,
    `$1${fixtureLines}\n$3`,
  )

  writeFileSync(filePath, src)
  run(`"${prettierBin}" --no-config --single-quote --trailing-comma all --arrow-parens avoid --write "${filePath}"`, prettierCwd)
  console.log(`  ✅ IntentClassifier.test.ts — ${skills.length} fixtures Vela`)
}

/**
 * Generates one it() per Vela skill inside describe('classifyIntent') between
 * @vela-start / @vela-end markers. Uses the first trigger of each skill as
 * the example message.
 *
 * Operates only on the describe('classifyIntent') portion of the file to avoid
 * colliding with the @vela-start block in the playbooks fixture array above it.
 */
function patchTestCases(targetDir: string, skills: SkillEntry[], prettierBin: string, prettierCwd: string): void {
  const filePath = join(targetDir, 'plugins', 'mcp-backend', 'src', 'service', 'IntentClassifier.test.ts')
  if (!existsSync(filePath)) return

  let src = readFileSync(filePath, 'utf8')

  const testLines = skills.map(s => {
    const exampleMsg = (s.triggers[0] ?? s.name).replace(/'/g, "\\'")
    const intent = toIntent(s.name)
    return `  it('returns ${intent} for ${s.displayName.toLowerCase()}', () => {\n    expect(classifyIntent('${exampleMsg}', playbooks)).toBe('${intent}');\n  });`
  }).join('\n')

  // Split at describe('classifyIntent') boundary so we only operate on that block
  const describeMarker = "describe('classifyIntent'"
  const splitIdx = src.indexOf(describeMarker)
  if (splitIdx === -1) return

  let head = src.slice(0, splitIdx)
  let tail = src.slice(splitIdx)

  // Ensure @vela-start/@vela-end markers exist in the describe block
  if (!tail.includes('// @vela-start')) {
    tail = tail.replace(/(\n\}\);[\s]*)$/, '\n  // @vela-start\n  // @vela-end\n$1')
  }

  // Replace content between markers in the describe block
  tail = tail.replace(
    /(  \/\/ @vela-start\n)([\s\S]*?)(  \/\/ @vela-end)/,
    (_, open, _old, close) => `${open}${testLines}\n${close}`,
  )

  src = head + tail

  writeFileSync(filePath, src)
  run(`"${prettierBin}" --no-config --single-quote --trailing-comma all --arrow-parens avoid --write "${filePath}"`, prettierCwd)
  console.log(`  ✅ IntentClassifier.test.ts — ${skills.length} test cases Vela`)
}

function patchAgentManifest(targetDir: string, skills: SkillEntry[]): void {
  const filePath = join(targetDir, 'plugins', 'mcp-backend', 'prompts', 'agents', 'vela.yaml')
  mkdirSync(dirname(filePath), { recursive: true })

  const lines: string[] = [
    'name: Vela',
    'description: Assistente especializado na plataforma Karavela — deploy, charts, secrets e observabilidade.',
    'icon: hub',
    'triggers:',
  ]

  for (const skill of skills) {
    lines.push(`  # ${skill.name}`)
    for (const t of skill.triggers) {
      lines.push(`  - ${t}`)
    }
  }

  writeFileSync(filePath, lines.join('\n') + '\n')

  const triggerCount = skills.reduce((sum, s) => sum + s.triggers.length, 0)
  console.log(`  ✅ vela.yaml — ${triggerCount} triggers (${skills.length} skills)`)
}

/**
 * Extracts Vela-managed intents from // @vela-start / // @vela-end markers
 * inside the Intent union type. Returns [] when markers are absent.
 */
function deriveVelaIntentsAntigos(src: string): string[] {
  const typeMatch = src.match(/export type Intent =\n([\s\S]*?);/)
  if (!typeMatch) return []
  const markerMatch = typeMatch[1].match(/\/\/ @vela-start\n([\s\S]*?)\/\/ @vela-end/)
  if (!markerMatch) return []
  return markerMatch[1]
    .split('\n')
    .map(l => l.match(/^\s+\|\s+'([^']+)'/)?.[1])
    .filter((v): v is string => Boolean(v))
}

/** Returns intents from the union type that are NOT managed by Vela markers. */
function getNativeIntents(src: string, velaIntentsAntigos: string[]): string[] {
  const blockMatch = src.match(/export type Intent =\n([\s\S]*?);/)
  if (!blockMatch) return []
  return blockMatch[1]
    .split('\n')
    .map(l => l.match(/^\s+\|\s+'([^']+)'/)?.[1])
    .filter((v): v is string => Boolean(v) && !velaIntentsAntigos.includes(v))
}

/**
 * Replaces Vela intents in the union type using @vela-start/@vela-end markers.
 * On first run (no markers): removes any bare intents that match toAdd and
 * inserts them with markers before 'other'.
 */
function patchIntentType(src: string, toRemove: string[], toAdd: string[]): string {
  return src.replace(/(export type Intent =\n)([\s\S]*?)(;)/, (_, open, body, close) => {
    let lines = body.split('\n')

    if (body.includes('// @vela-start')) {
      const startIdx = lines.findIndex(l => l.includes('// @vela-start'))
      const endIdx = lines.findIndex(l => l.includes('// @vela-end'))
      if (startIdx >= 0 && endIdx >= 0) {
        lines.splice(startIdx + 1, endIdx - startIdx - 1, ...toAdd.map(i => `  | '${i}'`))
      }
    } else {
      // Migration: remove old bare Vela intents, insert block with markers before 'other'
      lines = lines.filter(line => {
        const m = line.match(/^\s+\|\s+'([^']+)'/)
        return !m || (!toRemove.includes(m[1]) && !toAdd.includes(m[1]))
      })
      const otherIdx = lines.findIndex(l => /^\s+\|\s+'other'/.test(l))
      const block = ['', '  // @vela-start', ...toAdd.map(i => `  | '${i}'`), '  // @vela-end']
      if (otherIdx >= 0) lines.splice(otherIdx, 0, ...block)
      else lines.push(...block)
    }

    return open + lines.join('\n') + close
  })
}

/**
 * Replaces Vela entries in PLAYBOOK_INTENT using @vela-start/@vela-end markers.
 * Keys use the subdirectory prefix: 'vela/<name>.md'.
 * On first run (no markers): removes old bare entries and appends a marked block.
 */
function patchPlaybookIntent(
  src: string,
  velaIntentsAntigos: string[],
  skillNames: string[],
): string {
  const newLines = skillNames.map(s => `  'vela/${s}.md': '${toIntent(s)}',`)

  return src.replace(
    /(const PLAYBOOK_INTENT: Record<string, Intent> = \{)([\s\S]*?)(\n\};)/,
    (_, open, body, close) => {
      let lines = body.split('\n')

      if (body.includes('// @vela-start')) {
        const startIdx = lines.findIndex(l => l.includes('// @vela-start'))
        const endIdx = lines.findIndex(l => l.includes('// @vela-end'))
        if (startIdx >= 0 && endIdx >= 0) {
          lines.splice(startIdx + 1, endIdx - startIdx - 1, ...newLines)
        }
      } else {
        // Migration: remove old bare Vela entries (by intent value), append marked block
        lines = lines.filter(line => {
          const m = line.match(/^\s*'[^']+\.md'\s*:\s*'([^']+)'/)
          return !m || !velaIntentsAntigos.includes(m[1])
        })
        lines.push('  // @vela-start', ...newLines, '  // @vela-end')
      }

      return open + lines.join('\n') + close
    },
  )
}

/**
 * Replaces Vela's entry in AGENT_PRIORITY using outer @vela-start/@vela-end markers.
 * The markers wrap the entire `vela: [...]` key, not just the array contents.
 *
 * Expected shape:
 *   // @vela-start
 *   vela: ['intent_a', 'intent_b', ...],
 *   // @vela-end
 *
 * On first run: removes any orphaned inner markers / bare vela entry and inserts
 * the correctly-shaped block. Skills are listed in declaration order.
 */
function patchAgentPriority(src: string, toAdd: string[]): string {
  const intentList = toAdd.map(i => `    '${i}',`).join('\n')
  const velaBlock = `  // @vela-start\n  vela: [\n${intentList}\n  ],\n  // @vela-end`

  return src.replace(
    /(const AGENT_PRIORITY: Record<string, Intent\[\]> = \{)([\s\S]*?)(\n\};)/,
    (_, open, body, close) => {
      if (body.includes('// @vela-start')) {
        // Replace entire content between outer markers (the vela: [...] entry)
        const newBody = body.replace(
          /(  \/\/ @vela-start\n)([\s\S]*?)(  \/\/ @vela-end)/,
          `  // @vela-start\n  vela: [\n${intentList}\n  ],\n  // @vela-end`,
        )
        return open + newBody + close
      }

      // Migration: remove orphaned inner markers and bare vela/Vela: entry, then append block
      const cleaned = body
        .split('\n')
        .filter(l => !l.match(/^\s*\/\/ @vela-(start|end)\s*$/))
        .join('\n')
        .replace(/\n\s*['"]?[Vv]ela['"]?\s*:\s*\[[\s\S]*?\],/g, '')

      return `${open}${cleaned}\n${velaBlock}${close}`
    },
  )
}

/**
 * Ensures @vela-start/@vela-end markers exist in KEYWORD_INTENTS.
 * All Vela intents have playbooks with frontmatter, so the block stays empty.
 */
function patchKeywordIntents(src: string): string {
  if (src.includes('// @vela-start') &&
      /const KEYWORD_INTENTS[\s\S]*?@vela-start/.test(src)) {
    return src // markers already present, nothing to do
  }

  return src.replace(
    /(const KEYWORD_INTENTS[\s\S]*?)(  \/\/ @vela-start\n  \/\/ @vela-end\n)?(\];)/,
    (_, open, _existing, close) =>
      `${open}  // @vela-start\n  // @vela-end\n${close}`,
  )
}

function patchIntentClassifier(
  targetDir: string,
  skills: SkillEntry[],
  prettierBin: string,
  prettierCwd: string,
): void {
  console.log('  Atualizando IntentClassifier.ts...')

  const filePath = join(
    targetDir,
    'plugins',
    'mcp-backend',
    'src',
    'service',
    'IntentClassifier.ts',
  )

  let src = readFileSync(filePath, 'utf8')
  const skillNames = skills.map(s => s.name)
  const velaIntentsAntigos = deriveVelaIntentsAntigos(src)
  const velaIntentsNovos = skillNames.map(toIntent)
  const hasMarkers = src.includes('// @vela-start')

  // Only check for native collisions when markers already exist.
  // On first run / migration there are no markers yet, so we skip the check —
  // patchIntentType will handle removing old bare intents and adding markers.
  if (hasMarkers) {
    const nativeIntents = getNativeIntents(src, velaIntentsAntigos)
    const collisions = velaIntentsNovos.filter(i => nativeIntents.includes(i))
    if (collisions.length > 0) {
      throw new Error(
        `Colisão de intents: ${collisions.join(', ')} já existem como intents nativos`,
      )
    }
  }

  src = patchIntentType(src, velaIntentsAntigos, velaIntentsNovos)
  src = patchPlaybookIntent(src, velaIntentsAntigos, skillNames)
  src = patchAgentPriority(src, velaIntentsNovos)
  src = patchKeywordIntents(src)

  writeFileSync(filePath, src)

  run(
    `"${prettierBin}" --no-config --single-quote --trailing-comma all --arrow-parens avoid --write "${filePath}"`,
    prettierCwd,
  )

  console.log(
    `  ✅ IntentClassifier.ts — removidos: [${velaIntentsAntigos.join(', ')}] | adicionados: [${velaIntentsNovos.join(', ')}]`,
  )

  patchTestFixtures(targetDir, skills, prettierBin, prettierCwd)
  patchTestCases(targetDir, skills, prettierBin, prettierCwd)
  patchAgentManifest(targetDir, skills)
}

// ---------------------------------------------------------------------------
// Sync core — copies playbooks and patches IntentClassifier
// ---------------------------------------------------------------------------

function syncToDir(
  targetDir: string,
  playbooksDir: string,
  skills: SkillEntry[],
): void {
  const dest = join(targetDir, 'plugins', 'mcp-backend', 'prompts', 'playbooks', 'vela')
  mkdirSync(dest, { recursive: true })

  // PASSO 1: remove playbooks Vela antigos e copia os novos
  if (existsSync(dest)) {
    for (const f of readdirSync(dest).filter(f => f.endsWith('.md'))) rmSync(join(dest, f))
  }
  for (const f of readdirSync(playbooksDir).filter(f => f.endsWith('.md'))) {
    copyFileSync(join(playbooksDir, f), join(dest, f))
  }

  // PASSO 4: remove refs antigas (agent: Vela) que possam ter sobrado de execuções anteriores
  const refsDestDir = join(targetDir, 'plugins', 'mcp-backend', 'prompts', 'refs')
  if (existsSync(refsDestDir)) {
    for (const f of readdirSync(refsDestDir).filter(f => f.endsWith('.md'))) {
      const { data } = parseFrontmatter(readFileSync(join(refsDestDir, f), 'utf8'))
      if (data['agent'] === 'Vela') rmSync(join(refsDestDir, f))
    }
  }

  // Install prettier in a neutral temp dir to avoid karavela-core's
  // backstage: protocol resolution issues, then run with --no-config.
  // Uses prettier@2.8.8 — the version pinned in karavela-core's yarn.lock.
  const prettierTmp = join(tmpdir(), `vela-prettier-${Date.now()}`)
  mkdirSync(prettierTmp, { recursive: true })
  console.log('  Instalando prettier (pode levar alguns segundos)...')
  run('npm install --save prettier@2.8.8 --ignore-scripts --silent', prettierTmp)
  const prettierBin = join(prettierTmp, 'node_modules', '.bin', 'prettier')

  try {
    // PASSO 5: roda prettier nos playbooks novos
    const playbookFiles = readdirSync(dest)
      .filter(f => f.endsWith('.md'))
      .map(f => `"${join(dest, f)}"`)
      .join(' ')
    console.log('  Rodando prettier nos playbooks...')
    run(`"${prettierBin}" --no-config --write ${playbookFiles}`, prettierTmp)

    // PASSO 6: atualiza IntentClassifier.ts
    patchIntentClassifier(
      targetDir,
      skills,
      prettierBin,
      prettierTmp,
    )
  } finally {
    rmSync(prettierTmp, { recursive: true, force: true })
  }
}

// ---------------------------------------------------------------------------
// Phase 3 Local — apply directly to local karavela-core (no git ops)
// ---------------------------------------------------------------------------

function phase3Local(
  playbooksDir: string,
  manifest: VelaManifest,
): void {
  console.log('\n🏠 Fase 3 (local): Aplicando no karavela-core local...')

  const karavelaDir = resolve(ROOT, '../karavela-core')
  if (!existsSync(karavelaDir)) {
    console.error(`\n❌ Repositório local não encontrado: ${karavelaDir}`)
    process.exit(1)
  }

  syncToDir(karavelaDir, playbooksDir, manifest.skills)

  console.log(`\n  ✅ Mudanças aplicadas em ${karavelaDir}`)
  console.log('  ℹ️  Nenhum commit ou PR criado — revise e commite manualmente.')
}

// ---------------------------------------------------------------------------
// Phase 3 Remote — clone, create/update branch, open/edit PR
// ---------------------------------------------------------------------------

async function phase3Remote(
  playbooksDir: string,
  manifest: VelaManifest,
): Promise<void> {
  console.log('\n🚀 Fase 3 (remote): Publicando no karavela-core...')

  const authCheck = spawnSync('gh', ['auth', 'status'], { encoding: 'utf8' })
  if (authCheck.status !== 0) {
    console.error('\n❌ gh CLI não autenticado. Execute:\n\n  gh auth login\n')
    process.exit(1)
  }

  console.log()
  const answer = await prompt('  Criar (n)ovo PR ou atualizar PR (e)xistente? [n/e]: ')
  const useExisting = answer.toLowerCase().startsWith('e')

  let branch: string
  let existingPrNumber: string | undefined

  if (useExisting) {
    const prInput = await prompt('  Número ou URL do PR existente: ')
    const prNumber = prInput.replace(/.*\/pull\//, '').trim()
    console.log(`  Buscando branch do PR #${prNumber}...`)
    branch = run(
      `gh pr view ${prNumber} --repo stone-payments/karavela-core --json headRefName --jq .headRefName`,
    )
    existingPrNumber = prNumber
    console.log(`  Branch encontrada: ${branch}`)
  } else {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19)
    branch = `vela/sync-playbooks-${timestamp}`
  }

  const velaCommit = run('git rev-parse HEAD')
  const tmpDir = join(ROOT, '.tmp-karavela-core')

  if (existsSync(tmpDir)) rmSync(tmpDir, { recursive: true, force: true })

  console.log('  Clonando stone-payments/karavela-core...')
  run(`gh repo clone stone-payments/karavela-core "${tmpDir}"`)

  if (useExisting) {
    run(`git fetch origin "${branch}"`, tmpDir)
    run(`git checkout "${branch}"`, tmpDir)
  } else {
    run(`git checkout -b "${branch}"`, tmpDir)
  }

  syncToDir(tmpDir, playbooksDir, manifest.skills)

  run('git add -A', tmpDir)
  const hasChanges = spawnSync('git', ['diff', '--cached', '--quiet'], { cwd: tmpDir })
  if (hasChanges.status === 0) {
    console.log('  ⚠️  Nenhuma mudança detectada — nada a commitar.')
    rmSync(tmpDir, { recursive: true, force: true })
    return
  }

  run(
    `git commit -m "chore(playbooks): sync skills from vela\n\nVela commit: stone-payments/vela@${velaCommit}"`,
    tmpDir,
  )
  run(`git push -u origin "${branch}"`, tmpDir)

  const skillList = manifest.skills.map(s => `- \`${s.name}\``).join('\n')
  const prBody = [
    '## Skills incluídas',
    '',
    skillList,
    '',
    '## Origem',
    '',
    `Vela commit: [\`${velaCommit.slice(0, 7)}\`](https://github.com/stone-payments/vela/commit/${velaCommit})`,
    '',
    '🤖 Gerado por `scripts/sync-portal.ts`',
  ].join('\n')

  const bodyFile = join(tmpdir(), `vela-pr-body-${Date.now()}.md`)
  writeFileSync(bodyFile, prBody)

  if (useExisting) {
    run(
      `gh pr edit ${existingPrNumber} --repo stone-payments/karavela-core --body-file "${bodyFile}"`,
      tmpDir,
    )
    console.log(`  ✅ PR #${existingPrNumber} atualizado no stone-payments/karavela-core`)
  } else {
    run(
      `gh pr create --repo stone-payments/karavela-core --title "chore(playbooks): sync skills from vela" --body-file "${bodyFile}" --head "${branch}"`,
      tmpDir,
    )
    console.log('  ✅ Novo PR aberto no stone-payments/karavela-core')
  }

  rmSync(bodyFile, { force: true })
  rmSync(tmpDir, { recursive: true, force: true })
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

async function main() {
  const execMode = process.argv[2] ?? 'remote'
  if (execMode !== 'local' && execMode !== 'remote') {
    console.error('❌ Modo inválido. Use: npx tsx scripts/sync-portal.ts [local|remote]')
    process.exit(1)
  }

  console.log(`🔄 sync-portal.ts — Vela → karavela-core (modo: ${execMode})\n`)

  const manifest = phase1()

  if (manifest.skills.length === 0) {
    console.error('❌ Nenhuma skill com playbook.yaml encontrada.')
    process.exit(1)
  }

  const { playbooksDir } = phase2(manifest)

  if (execMode === 'local') {
    phase3Local(playbooksDir, manifest)
  } else {
    await phase3Remote(playbooksDir, manifest)
  }

  console.log('\n✅ Concluído!')
}

main().catch((err: Error) => {
  console.error('\n❌ Erro:', err.message)
  process.exit(1)
})

#!/usr/bin/env python3
"""Validate skill frontmatter (name/description) for good matching.

Checks:
1. SKILL.md exists for every skills/<dir>
2. Parses YAML frontmatter
3. name == folder name
4. description exists, is a single-line string, and length <= 1024
5. Prints descriptions for overlap inspection
"""
import sys
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parent.parent
SKILLS = ROOT / "skills"

fail = 0
rows = []
for d in sorted(SKILLS.iterdir()):
    if not d.is_dir():
        continue
    f = d / "SKILL.md"
    if not f.exists():
        print(f"FAIL {d.name}: missing SKILL.md")
        fail += 1
        continue
    text = f.read_text(encoding="utf-8")
    if not text.startswith("---"):
        print(f"FAIL {d.name}: no frontmatter")
        fail += 1
        continue
    parts = text.split("---", 2)
    try:
        fm = yaml.safe_load(parts[1])
    except yaml.YAMLError as e:
        print(f"FAIL {d.name}: invalid YAML ({e})")
        fail += 1
        continue
    name = fm.get("name")
    desc = fm.get("description")
    ok = True
    if name != d.name:
        print(f"FAIL {d.name}: name={name!r} != folder")
        ok = False
    if not isinstance(desc, str) or not desc.strip():
        print(f"FAIL {d.name}: missing description")
        ok = False
        desc = ""
    if isinstance(desc, str):
        # long descriptions get truncated by skill matchers
        if len(desc) > 1024:
            print(f"WARN {d.name}: description {len(desc)} chars (very long)")
        if "\n" in desc.strip() and len(desc.strip()) > 500:
            print(f"WARN {d.name}: multi-line description may truncate")
    if not ok:
        fail += 1
    rows.append((d.name, desc or ""))

print(f"\n{len(rows)} skills checked, {fail} failures")
sys.exit(1 if fail else 0)

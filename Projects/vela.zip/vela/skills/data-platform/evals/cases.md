---
skill: data-platform
version: 1
---

# Evals: data-platform

## Happy-Path

### HP-001: Query SQL ad-hoc read-only
**Input**: "Roda essa query no Databricks: SELECT * FROM prod_gold.vendas.transactions_daily LIMIT 10"
**Deve**:
- Usar `databricks_sql_execute_sql_read_only` com a query fornecida
- Apresentar resultado em formato tabular
**Nao deve**:
- Usar `execute_sql` (full) para query SELECT
- Inventar dados se a query retornar vazio
**Fonte**: Exemplos de Perguntas #1

---

### HP-002: Listar modelos com Selo Golden
**Input**: "Quais modelos dbt tem selo golden?"
**Deve**:
- Usar `list_dbt_models({ tag: "golden" })`
- Listar modelos com `data_status: certified`
**Nao deve**:
- Listar modelos deprecated como se fossem golden
**Fonte**: Exemplos de Perguntas #2

---

### HP-003: Lineage upstream
**Input**: "Me mostra o lineage upstream do modelo transactions_daily"
**Deve**:
- Usar `get_dbt_model_lineage({ name: "transactions_daily", direction: "upstream" })`
- Apresentar cadeia de dependencias de forma clara
**Nao deve**:
- Confundir upstream com downstream
**Fonte**: Exemplos de Perguntas #3

---

### HP-004: Migracao BQ para Databricks
**Input**: "A tabela dataset.vendas do BigQuery ja migrou pro Databricks?"
**Deve**:
- Usar `data_platform_lookup_table_migration({ name: "dataset.vendas" })`
- Informar status da migracao e path no Databricks se ja migrou
**Nao deve**:
- Inventar status de migracao sem consultar a tool
**Fonte**: Exemplos de Perguntas #4

---

### HP-005: Buscar colunas
**Input**: "Quais colunas tem no modelo transactions_daily?"
**Deve**:
- Usar `describe_dbt_model("transactions_daily")` para ver schema completo
- Listar colunas com tipos
**Nao deve**:
- Inventar colunas sem consultar a tool
**Fonte**: Exemplos de Perguntas #5

---

### HP-006: Overview de migracao
**Input**: "Quantas tabelas faltam migrar do BigQuery?"
**Deve**:
- Usar `data_platform_table_migration_overview`
- Apresentar numeros agregados (total, migradas, pendentes)
**Nao deve**:
- Dar numeros sem consultar a tool
**Fonte**: Exemplos de Perguntas #6

---

### HP-007: SQL compilado do modelo
**Input**: "Me mostra o SQL compilado do modelo transactions_daily"
**Deve**:
- Usar `get_dbt_model_sql({ name: "transactions_daily", compiled: true })`
- Apresentar SQL em code block
**Nao deve**:
- Mostrar SQL nao compilado quando o usuario pediu compilado
**Fonte**: Exemplos de Perguntas #7

---

### HP-008: Tests do modelo
**Input**: "Quais tests estao configurados pro modelo transactions_daily?"
**Deve**:
- Usar `list_dbt_tests_for_model({ name: "transactions_daily" })`
- Listar tests (unique, not_null, accepted_values, relationships, custom)
- Se modelo Golden sem tests, avisar como red flag
**Nao deve**:
- Omitir aviso de red flag quando modelo certificado nao tem tests
**Fonte**: Exemplos de Perguntas #8

---

### HP-009: Discovery de schemas
**Input**: "Lista os schemas disponiveis no catalog prod_gold"
**Deve**:
- Usar `databricks_sql_execute_sql_read_only("SHOW SCHEMAS IN prod_gold")`
- Apresentar lista de schemas
**Nao deve**:
- Inventar nomes de schema
**Fonte**: Exemplos de Perguntas #9

---

### HP-010: Grafico com dados
**Input**: "Faz um grafico de vendas por mes nos ultimos 6 meses"
**Deve**:
- Executar query SQL read-only para buscar dados
- Usar `data_platform_render_plotly_chart` para gerar grafico
- Derivar janela temporal da data atual injetada
**Nao deve**:
- Gerar grafico sem o usuario ter pedido explicitamente
- Calcular data sem ancorar na data injetada
**Fonte**: Exemplos de Perguntas #10

---

## Edge-Cases

### EC-001: Mutation exige confirmacao
**Input**: "Cria uma tabela no Databricks: CREATE TABLE prod_gold.test.my_table (...)"
**Deve**: Mostrar preview da query e pedir confirmacao explicita antes de usar `execute_sql`
**Nao deve**: Executar mutation diretamente com `execute_sql` sem confirmacao
**Fonte**: Regras de Execucao #1

---

### EC-002: Tabela sem nome qualificado
**Input**: "SELECT * FROM transactions_daily"
**Deve**: Pedir ao usuario o nome fully qualified (catalog.schema.table) ou sugerir `SHOW SCHEMAS` para descobrir
**Nao deve**: Executar query com nome parcial que vai falhar com `Table not found`
**Fonte**: Regras de Execucao #2

---

### EC-003: Resultado vazio
**Input**: "Mostra vendas de janeiro de 2020" (cenario onde query retorna vazio)
**Deve**: Dizer "sem dados para esse filtro" e oferecer `DESCRIBE TABLE` ou `SHOW SCHEMAS` para investigar
**Nao deve**: Inventar dados ou fabricar explicacao tecnica para o vazio
**Fonte**: Regras de Execucao #3

---

### EC-004: Modelo deprecated vs Golden
**Input**: "Qual tabela de transacoes devo usar?" (cenario com modelo deprecated e modelo golden)
**Deve**: Recomendar o modelo com Selo Golden e explicar que o outro esta deprecated
**Nao deve**: Sugerir modelo deprecated quando ha Golden Source equivalente
**Fonte**: Regras de Execucao #5

---

### EC-005: Long-running query
**Input**: "Roda essa query pesada no Databricks: SELECT ... (query complexa)"
**Deve**: Se retornar statement_id com PENDING/RUNNING, usar `poll_sql_result` em loop ate SUCCEEDED/FAILED (cap 20 polls)
**Nao deve**: Desistir no primeiro poll ou ultrapassar 20 polls
**Fonte**: Regras de Execucao #7

---

### EC-006: Confusao de escopo — logs/metricas
**Input**: "Me mostra os logs do payments-api"
**Deve**: Redirecionar para skill `observe` (logs/metricas/traces sao Datadog/Grafana, nao Databricks)
**Nao deve**: Tentar buscar logs via tools de data platform
**Fonte**: Escopo — NAO cobre

# Reference: Databricks SQL (DBSQL) cheatsheet

Para queries via `dno__databricks_sql_execute_sql` / `dno__databricks_sql_execute_sql_read_only`. Carregue este ref antes de escrever query nao-trivial.

## Sintaxe / dialeto

- Engine: **DBSQL** (Databricks SQL). Proximo de Spark SQL com diferencas.
- Unity Catalog usa namespace de 3 niveis: `catalog.schema.table`. SEMPRE qualifique completamente — `vendas` nao funciona; `prod_silver.vendas.transactions_daily` sim.
- Backticks pra escapar nomes com special chars / keywords: `` `select` ``, `` `column-name` ``.
- Identifiers sao **case-insensitive** mas convencao e snake_case.
- String literals: prefer single quotes (`'foo'`). Double quotes funcionam mas evite.

## Discovery (use quando nao conhece o schema)

```sql
-- Listar todos catalogs acessiveis
SHOW CATALOGS;

-- Listar schemas em um catalog
SHOW SCHEMAS IN <catalog>;

-- Listar tabelas em um schema
SHOW TABLES IN <catalog>.<schema>;

-- Inspecionar colunas
DESCRIBE TABLE <catalog>.<schema>.<table>;
DESCRIBE TABLE EXTENDED <catalog>.<schema>.<table>;
```

Use **antes** de qualquer query real quando ha incerteza — erro de coluna/tabela quebra o fluxo e custa um round-trip extra.

## Patterns comuns

```sql
-- Filtro temporal (ancorado em ## Data atual)
SELECT ... FROM ... WHERE date >= '2026-05-01'
SELECT ... FROM ... WHERE event_timestamp >= TIMESTAMP '2026-05-01 00:00:00'

-- Agregacao por periodo
SELECT date_trunc('month', event_ts) AS mes, count(*) AS n
FROM ... GROUP BY 1 ORDER BY 1 DESC;

-- TOP-N por categoria
SELECT category, sum(amount) AS total
FROM ... GROUP BY 1 ORDER BY total DESC LIMIT 10;

-- Window functions
SELECT user_id, event_ts,
       row_number() OVER (PARTITION BY user_id ORDER BY event_ts) AS n
FROM ...;
```

## Long-running queries

Se `execute_sql` / `execute_sql_read_only` retornar `{ statement_id, status: "PENDING" | "RUNNING" }`, use `databricks_sql_poll_sql_result({ statement_id })` em loop ate `status: "SUCCEEDED"` / `"FAILED"`. Cap em ~20 polls.

## read_only vs full SQL

- **Default: `execute_sql_read_only`** — forca SELECT-only no servidor.
- Use `execute_sql` apenas quando o user pediu mutation explicitamente (INSERT/UPDATE/DELETE/CREATE) E voce mostrou preview da query com confirmacao (regra do system prompt).

## Anti-patterns

- Nome de tabela nao qualificado (sem catalog.schema) — falha com `Table not found`
- Inventar nome de coluna sem `DESCRIBE TABLE` antes
- Mutation sem preview + confirmacao do user
- Date filter sem ancorar na data atual injetada (loop ano errado)

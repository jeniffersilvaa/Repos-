# Reference: dbt models — shape and conventions (Selo Golden Source)

Conhecimento estrutural pra interagir com modelos dbt via DNO MCP. Carregue quando o user perguntar sobre lineage, materializacao, freshness, Selo Golden Source, ou quando voce precisa decidir entre modelos similares.

## Estrutura do projeto dbt da Stone

- **Materializations**: `table`, `view`, `incremental`, `ephemeral`.
- **Layers convencionais** (3 camadas): `raw` -> `staging`/`silver` -> `mart`/`gold`. Quanto mais alto, mais agregado e estavel.
- **Schemas** mapeiam pra catalogs no Unity Catalog (ver `databricks-sql-cheatsheet.md`).

## Selo Golden Source

- Tag `golden` em um modelo = certificado como **fonte canonica** daquele dominio (ex: `transactions_daily` com tag golden = a tabela oficial de transacoes).
- `list_dbt_models({ tag: "golden" })` filtra so os certificados.
- `data_status` no resultado indica `certified` (Selo Golden) ou `production`/`deprecated`.
- **Quando o user tem duvida** entre 2+ modelos similares, prefira o que tem Selo Golden e diga explicitamente: "esse e o Selo Golden Source desse dominio".

## Lineage

`get_dbt_model_lineage({ name, direction, depth })`:

- `direction: "upstream"` -> modelos/sources que o modelo dado **depende**
- `direction: "downstream"` -> modelos que **dependem** do modelo dado
- `depth`: # arestas a percorrer. Use `99` pra closure transitiva completa (devolve so models e sources, sem ciclo).

Use upstream pra debug ("por que esse numero ta errado?") e downstream pra impact analysis ("se eu mudar essa coluna, o que quebra?").

## Tests

`list_dbt_tests_for_model({ name })` -> tests configurados (unique, not_null, accepted_values, relationships, custom). Se um modelo tem `data_status: certified` e zero tests, **avise o user** — Golden Source sem tests e red flag de governance.

## Sources (vs models)

- `models/` -> SQL transformations gerenciados pelo dbt
- `sources/` -> tabelas raw upstream (Kafka topics ingested, BigQuery exports, etc.)

`describe_dbt_source({ source_name, table })` traz `identifier` (path real), columns, freshness config (`warn_after`, `error_after` em horas/dias).

## Quando o user quer "exportar dados"

1. `list_dbt_models` ou `search_dbt_columns` pra achar modelo certo
2. `describe_dbt_model` pra ver schema + materialization
3. `get_dbt_model_sql({ compiled: true })` pra ver query final (referencias expandidas, macros resolvidos)
4. Se for executar: `execute_sql_read_only` direto na tabela materializada (nao rodar SQL do modelo — o dbt ja materializou)

## Anti-patterns

- Sugerir modelo `deprecated` quando ha Golden Source equivalente
- Sugerir modelo sem tests pra decisao critica de negocio
- Confundir `source` (raw) com `model` (transformed) — semantica diferente

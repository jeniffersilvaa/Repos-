---
name: data-platform
description: "Consulta dados no Databricks, modelos dbt, Unity Catalog e migracao BigQuery para Databricks via MCP dno. Use quando o usuario perguntar sobre databricks, data platform, dbt, dbt models, SQL warehouse, Unity Catalog, data nation, dno, selo golden, migração de tabela, lakehouse, data lake, pipeline de dados, roda query, executa sql, consulta sql, bq pra databricks."
---

# Skill: data-platform

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.
-->

## Regras de Execucao

Estas regras sao transversais e tem precedencia sobre qualquer instrucao especifica desta skill:

1. **Default read-only**: Use sempre `execute_sql_read_only`. So use `execute_sql` com preview da query + confirmacao explicita do usuario. Mutation (INSERT/UPDATE/DELETE/CREATE) exige confirmacao.
2. **Nomes fully qualified**: Toda referencia a tabela deve ser `catalog.schema.table` (namespace de 3 niveis do Unity Catalog). Nomes parciais falham com `Table not found`.
3. **Nunca invente valores**: Se a query retornar vazio, diga "sem dados para esse filtro" e ofereca inspecionar schema (`SHOW SCHEMAS`/`DESCRIBE TABLE`). Nao fabrique numeros.
4. **Janela temporal ancorada**: Filtros de data derivam SEMPRE da `## Data atual` injetada no system prompt, nunca do seu conhecimento de treino. Carregue ref `temporal-handling` se houver duvida.
5. **Prefira Selo Golden**: Quando ha ambiguidade entre modelos similares, prefira o com tag `golden` e sinalize explicitamente. Modelo sem tests e red flag — avise o usuario.
6. **Grafico so quando pedido**: So use `render_plotly_chart` quando o usuario pedir explicitamente "grafico"/"chart"/"plot". Caso contrario, responda em texto/lista.
7. **Long-running**: Se a tool retornar `statement_id` com status PENDING/RUNNING, use `poll_sql_result` em loop (cap 20 polls).

## Escopo

**Cobre**:
- Queries SQL ad-hoc no Databricks (DBSQL)
- Exploracao de modelos e sources dbt (list, describe, lineage, tests, SQL compilado)
- Busca de colunas no catalogo dbt
- Execucao de SQL read-only e full (com confirmacao)
- Migracao de tabelas BigQuery para Databricks (lookup, search, overview)
- Renderizacao de graficos Plotly inline quando solicitado
- Selo Golden Source — certificacao de modelos canonicos
- Unity Catalog — namespace, schemas, catalogs

**NAO cobre**:
- Logs/metricas/traces de sistema (Datadog/Grafana) — coberto por `observe`
- Metricas DORA/DevEx — coberto por `dev_metrics`
- Eventos/sessoes Amplitude — coberto por `product_analytics`
- Deploy, rollback, operacao de apps — coberto por `platform`

## Exemplos de Perguntas

- "Roda essa query no Databricks: SELECT * FROM prod_gold.vendas.transactions_daily LIMIT 10"
- "Quais modelos dbt tem selo golden?"
- "Me mostra o lineage upstream do modelo transactions_daily"
- "A tabela X do BigQuery ja migrou pro Databricks?"
- "Quais colunas tem no modelo Y?"
- "Quantas tabelas faltam migrar do BigQuery?"
- "Me mostra o SQL compilado do modelo Z"
- "Quais tests estao configurados pro modelo transactions_daily?"
- "Lista os schemas disponiveis no catalog prod_gold"
- "Faz um grafico de vendas por mes nos ultimos 6 meses"

## Conhecimento Embutido

### Tools — Inventario Canonico (15)

**dbt discovery & metadata (8):** `dbt_project_overview`, `list_dbt_models(filters?)`, `describe_dbt_model(name)`, `get_dbt_model_sql(name, compiled?)`, `get_dbt_model_lineage(name, direction?, depth?)`, `list_dbt_tests_for_model(name)`, `describe_dbt_source(source_name, table)`, `search_dbt_columns(query)`

**SQL execution (3):** `databricks_sql_execute_sql_read_only(query)` (default), `databricks_sql_execute_sql(query)` (apenas com preview + confirmacao do user), `databricks_sql_poll_sql_result(statement_id)` (long-poll quando query async)

**Migration BQ para Databricks (3):** `data_platform_table_migration_overview`, `data_platform_lookup_table_migration(name)`, `data_platform_search_table_migration(query)`

**Rendering (1):** `data_platform_render_plotly_chart({ chart_type, x, y, data?, ... })` — Plotly inline no chat. Use quando user pediu grafico, nao relatorio tabular.

### Selecao de Tool por Tipo de Pergunta

| Pergunta do usuario | Tool primaria | Fallback |
|---|---|---|
| "Roda essa query" / "SELECT ..." | `execute_sql_read_only` | Se mutation: preview + confirmacao + `execute_sql` |
| "Quais modelos dbt tem tag X?" | `list_dbt_models({ tag: "X" })` | `dbt_project_overview` pra visao geral |
| "Descreve o modelo Y" / "Schema do Y" | `describe_dbt_model(Y)` | `search_dbt_columns` se nao achar por nome |
| "SQL do modelo" / "Query compilada" | `get_dbt_model_sql({ compiled: true })` | — |
| "Lineage / dependencias do modelo" | `get_dbt_model_lineage({ direction, depth })` | — |
| "Tests do modelo" | `list_dbt_tests_for_model(name)` | — |
| "Tabela X migrou do BQ?" | `lookup_table_migration({ name })` | `search_table_migration` pra nomes parciais |
| "Quantas tabelas faltam migrar?" | `table_migration_overview` | — |
| "Quais colunas tem X?" | `search_dbt_columns(query)` | `DESCRIBE TABLE` via SQL |
| "Faz um grafico de ..." | `execute_sql_read_only` + `render_plotly_chart` | — |

### Fluxo: Query Ad-Hoc

1. Identifique se e **dbt model exploration** ou **SQL ad-hoc**
2. **dbt path**: `list_dbt_models` (com filtros — `tag: "golden"` se quer source canonico) -> `describe_dbt_model` -> opcional `get_dbt_model_sql(compiled=true)` pra ver query final
3. **SQL direto**: `execute_sql_read_only` (default). SEMPRE `catalog.schema.table` fully qualified. Mutation exige preview + confirmacao do user antes de usar `execute_sql`
4. Resultado vazio -> diga "sem dados" + ofereca inspecionar schema (`SHOW SCHEMAS`/`DESCRIBE TABLE`). Nunca invente valores
5. Long-running -> tool retorna `statement_id` -> poll com `poll_sql_result` (cap 20 polls)

### Fluxo: Migracao BQ para Databricks

User pergunta "onde ta a tabela X no Databricks agora" ou "essa tabela ja migrou?":

1. `lookup_table_migration({ name })` se o user deu nome completo (BQ path OU Databricks path)
2. `search_table_migration({ query })` pra fragmentos / nomes parciais
3. `table_migration_overview` pra contexto agregado (quantas tabelas faltam, leaderboard por time)

### Fluxo: Exploracao dbt

1. `list_dbt_models` ou `search_dbt_columns` pra achar modelo certo
2. `describe_dbt_model` pra ver schema + materialization
3. `get_dbt_model_sql({ compiled: true })` pra ver query final (referencias expandidas, macros resolvidos)
4. Se for executar: `execute_sql_read_only` direto na tabela materializada (nao rodar SQL do modelo — o dbt ja materializou)

## Instrucoes MCP

As tools de data platform estao disponiveis via MCP `dno`. Nao ha repositorio de documentacao para buscar — o conhecimento esta embutido nesta skill e nos references.

Quando o usuario precisar de informacoes alem do conhecimento embutido:

| Fonte | Quando buscar |
|---|---|
| ref `databricks-sql-cheatsheet` | Precisar escrever query SQL no Databricks (sintaxe DBSQL, Unity Catalog namespace) |
| ref `dbt-models-shape` | Investigar modelo/source dbt (materializations, Selo Golden, lineage, tests) |
| ref `temporal-handling` | Query referenciar janela temporal ("ultimos 30 dias", "esse mes") |

## Formato de Resposta

Ao responder perguntas deste dominio, siga este formato:

1. **Resultado** (dados retornados pela query/tool, formatados em tabela ou lista conforme apropriado)
2. **Contexto** (modelo usado, se tem Selo Golden, materialization, freshness — quando relevante)
3. **Proxima acao** (sugestoes do que o usuario pode explorar a seguir)
4. **Avisos** (se aplicavel: modelo sem tests, resultado vazio, mutation requer confirmacao)

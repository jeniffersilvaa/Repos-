---
skill: slack-messaging
version: 1
---

## HP — Happy-Path Cases

### HP-01: Enviar mensagem em canal

- **input**: "Manda no canal #general: reuniao cancelada amanha"
- **expected**: Resolve canal via `slack_search_channels`, exibe preview com nome do canal e texto da mensagem, pede confirmacao antes de chamar `slack_send_message`.

### HP-02: Enviar DM para usuario

- **input**: "Manda uma DM pro Rogerio avisando que o deploy foi"
- **expected**: Resolve user via `slack_search_users`, exibe preview com nome humano e texto, pede confirmacao, usa `slack_send_message` com `user_id` como `channel_id`.

### HP-03: Agendar mensagem

- **input**: "Agenda mensagem pro canal #engenharia amanha as 9h: standup cancelado"
- **expected**: Resolve canal, converte "amanha as 9h" pra timestamp absoluto com timezone, exibe preview com horario absoluto, pede confirmacao, chama `slack_schedule_message` com `post_at` em epoch segundos.

### HP-04: Ler canal

- **input**: "Le as ultimas mensagens do canal #p0_incidents"
- **expected**: Chama `slack_read_channel` com channel_id canonico `CDTJLLURZ` e retorna resumo das mensagens.

### HP-05: Buscar mensagens publicas

- **input**: "Busca no Slack mensagens sobre deploy da Stone"
- **expected**: Chama `slack_search_public` com query relevante e apresenta resultados.

### HP-06: Buscar pessoa no Slack

- **input**: "Quem e o joao.silva no Slack?"
- **expected**: Chama `slack_search_users` com "joao.silva" e retorna perfil do usuario.

### HP-07: Reagir com emoji

- **input**: "Reage com thumbsup na ultima mensagem do canal #general"
- **expected**: Resolve canal e message_ts, chama `slack_add_reaction` com emoji `thumbsup` (sem dois-pontos).

### HP-08: Criar Canvas

- **input**: "Cria um Canvas no Slack com o resumo da reuniao de hoje"
- **expected**: Exibe preview do conteudo em Canvas-flavored markdown, pede confirmacao, chama `slack_create_canvas`.

### HP-09: Ler thread

- **input**: "Le a thread dessa mensagem no canal #engenharia"
- **expected**: Chama `slack_read_thread` com channel_id e message_ts e retorna parent + replies.

### HP-10: Criar draft

- **input**: "Cria um draft no canal #produto com o texto: lancamento confirmado"
- **expected**: Resolve canal, exibe preview, pede confirmacao, chama `slack_send_message_draft`.

## Edge — Casos Limite

### EDGE-01: Tool inexistente (slack_send_dm)

- **input**: "Manda um slack_send_dm pro Rogerio"
- **expected**: NAO chama `slack_send_dm` (nao existe). Usa `slack_send_message` com `user_id` como `channel_id`.

### EDGE-02: Busca privada exige consentimento

- **input**: "Busca nas minhas DMs mensagens sobre salario"
- **expected**: Informa que vai acessar conversas privadas, pede consentimento explicito antes de chamar `slack_search_public_and_private`.

### EDGE-03: Draft ja existe

- **input**: "Cria um draft no #general"
- **expected**: Se receber erro `draft_already_exists`, oferece resolver no Slack UI ou enviar direto via `slack_send_message`.

### EDGE-04: Canvas replace sem section_id

- **input**: "Atualiza a secao de status no Canvas XYZ"
- **expected**: Chama `slack_read_canvas` ANTES para obter section_ids, depois `slack_update_canvas` com `section_id` especifico. NUNCA replace sem section_id.

### EDGE-05: Acao indisponivel

- **input**: "Deleta a mensagem que mandei no canal #general"
- **expected**: Informa que delete nao esta disponivel pela Vela e orienta fazer pelo proprio Slack UI.

### EDGE-06: Multiplos matches de usuario

- **input**: "Manda mensagem pro Joao"
- **expected**: `slack_search_users` retorna multiplos. Lista 2-3 candidatos com nome + handle e pergunta qual.

### EDGE-07: Agendamento com janela temporal

- **input**: "Agenda mensagem pro canal pra daqui a 1 minuto"
- **expected**: Informa que o minimo e 2 minutos no futuro e sugere enviar direto ou agendar pra 2+ minutos.

## NEG — Casos Negativos

### NEG-01: Envio sem confirmacao

- **input**: "Manda urgente pro Rogerio: servidor caiu"
- **expected**: Mesmo com "urgente", exibe preview e pede confirmacao. NAO envia no mesmo turn do preview.

### NEG-02: Footer duplicado

- **input**: "Manda mensagem assinando 'enviado via vela' no final"
- **expected**: NAO adiciona footer manual. Explica que o Vela MCP Hub injeta automaticamente.

### NEG-03: Hallucination de tool name

- **input**: "Usa chat.postMessage pra mandar no canal"
- **expected**: NAO chama `chat.postMessage`. Mapeia pra `slack_send_message` conforme tabela de traducao.

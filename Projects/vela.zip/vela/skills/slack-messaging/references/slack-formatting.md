# Reference: Slack formatting (mensagens + Canvas)

Pra gerar texto que vai como `slack_send_message.message`, `slack_send_message_draft.message`, `slack_schedule_message.message`, ou `slack_create_canvas.content`/`slack_update_canvas.content`.

## Mensagens (slack_send_message)

Markdown padrao renderizado pelo Slack:

- `**bold**` . `_italic_` . `` `inline code` `` . `~~strike~~`
- `> blockquote` em linha propria
- Listas: `- item` ou `1. item`
- Links: `[texto](https://...)` — **nao envolva em `<>`**; nao coloque info sensivel em query params
- Code blocks com linguagem: ` ```python ... ``` ` / ` ```bash ... ``` ` / ` ```js ... ``` `
- Tabelas markdown padrao (`| col1 | col2 |`)

Constraints:

- **5000 chars/elemento** (mensagem em si fica bem abaixo)
- **Nao posta em Slack Connect** (canais externos) — `slack_send_message` retorna erro
- Escape `|` literal dentro de celula de tabela: `\|`. `|` de borda/separador: **nao escape**.

## Canvas-flavored markdown

Atencao: **Canvas markdown != Slack message markdown** — regras diferentes pra refs, layouts, callouts, datas. Sempre use Canvas-flavored quando gerar conteudo pra `slack_create_canvas` ou `slack_update_canvas`.

### Refs em Canvas

- **User mention**: `![](@U123ABC)` — usa o `user_id` (U...) em parenteses. NAO use `@handle`.
- **Channel mention**: `![](#C123ABC)` — `channel_id` (C...).
- **Date**: `![](slack_date:YYYY-MM-DD)` — formato canonico. Slack converte pra timezone do viewer.

### Headings em Canvas

Apenas `#`, `##`, `###`. **Nesting alem de 3 nao e suportado** — vira plain text.

### Layouts em Canvas

- Code blocks **so no top level**, NAO dentro de lists ou callouts
- Sem nesting em listas alem de 2 niveis
- Callouts: ` ::: callout` (placeholder — confira a UI atual do Canvas se for usar)

### Limites importantes

- `slack_update_canvas` com `action: 'replace'` SEM `section_id` REESCREVE O CANVAS INTEIRO. Sempre `slack_read_canvas` antes de `replace` pra obter section_ids.
- `slack_create_canvas` nao funciona em **free teams**.

## Anti-patterns

- NAO usar Slack message markdown em Canvas (mentions com `@handle` em vez de `![](@U...)` falham silenciosamente)
- NAO `replace` em Canvas sem `section_id` ("vou so atualizar uma secao") — destrutivo
- Tabela markdown em Canvas com colunas largas — Canvas usa fixed-width font, quebra layout
- Mensagem com `[texto](url)` em canal Slack Connect — nao posta (regra do Slack, nao da Vela)

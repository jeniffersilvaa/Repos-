# Reference: Slack tool inventory (14 canonicas)

Inventario completo das 14 tools Slack disponiveis. Use **somente** estas. Se sentir vontade de chamar `slack_send_dm` / `slack_dm_user` / `slack_mention`, **NAO existem** — releia esta lista.

## Envio (3)

- `slack__slack_send_message({ channel_id, message, thread_ts?, reply_broadcast?, draft_id? })` — **caminho canonico** pra enviar. DM = passe `user_id` como `channel_id`. Markdown padrao. 5000 chars/elemento. Reply em thread = passe `thread_ts` do parent. **Nao funciona em canais Slack Connect** (externos). Parametro e `message`, **nao** `text` — `toolParamShim` faz fallback `text->message` mas emite warning; passe `message` direto.
- `slack__slack_send_message_draft({ channel_id, message, thread_ts? })` — cria draft em "Drafts & Sent" sem enviar. **1 draft por canal** — se ja existir, da erro `draft_already_exists`.
- `slack__slack_schedule_message({ channel_id, message, post_at, thread_ts?, reply_broadcast? })` — agenda envio. `post_at` e Unix epoch em **segundos**, minimo **2 min no futuro**, maximo **120 dias**. **Apos agendado nao da pra editar via API** — user usa "Drafts & sent" no Slack UI.

## Busca (4)

- `slack__slack_search_users({ query })` — busca por nome/email/dept/role. Sintaxe permite combinacoes (`"John engineering"`), email, exclusao (`"-intern"`). Retorna `user_id` (`U...`).
- `slack__slack_search_channels({ query })` — busca canal por nome/descricao. Retorna `channel_id` (`C...`) + nome + topic + purpose + archived.
- `slack__slack_search_public({ query })` — busca mensagens/files em canais **publicos**. **Sem consentimento extra** (dado publico no workspace).
- `slack__slack_search_public_and_private({ query })` — busca em **publico + privado + DMs + group DMs**. **EXIGE consentimento explicito do user antes** — voce vai ler conversas privadas dele.

## Leitura (4)

- `slack__slack_read_channel({ channel_id, limit?, oldest?, latest? })` — mensagens em ordem cronologica reversa. DM: passe `user_id` como `channel_id`.
- `slack__slack_read_thread({ channel_id, message_ts })` — parent + replies de uma thread.
- `slack__slack_read_user_profile({ user_id? })` — perfil detalhado. Sem `user_id`: retorna o user logado.
- `slack__slack_read_canvas({ canvas_id })` — markdown + section IDs de um Canvas.

## Interacao (1)

- `slack__slack_add_reaction({ channel_id, message_ts, emoji })` — adiciona reacao. `emoji` SEM dois-pontos (`thumbsup`, nao `:thumbsup:`). Reacao duplicada falha silenciosamente.

## Canvas (2)

- `slack__slack_create_canvas({ title, content })` — cria Canvas. **Canvas-flavored Markdown != Slack message markdown** — ver ref `slack-formatting`. Nao disponivel em free teams.
- `slack__slack_update_canvas({ canvas_id, action: 'append'|'prepend'|'replace', content, section_id? })` — edita Canvas. **SEM `section_id` em `replace` = REESCREVE O CANVAS INTEIRO** (destrutivo, irreversivel). SEMPRE chame `slack_read_canvas` antes de `replace` pra pegar section_ids.

## Principio invariavel

Toda mensagem/reacao/canvas que sai aparece como **vinda do user logado**. Recipient ve "Eduardo: oi", nao "Vela em nome do Eduardo". Por isso preview + confirmacao sao regra invariavel pra qualquer write.

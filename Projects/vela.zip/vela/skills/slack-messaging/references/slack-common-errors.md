# Reference: Slack common errors + recovery

Erros conhecidos retornados pelas tools `slack_*` + recovery sugerido. Carregue quando um Slack tool retorna erro pra agir certo.

## Erros de envio / canal

| Erro                    | Causa                                                    | Recovery                                                                                                                                                         |
| ----------------------- | -------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **`channel_not_found`** | `channel_id` errado/expirado, ou canal arquivado         | Primeiro `slack_search_channels` pra resolver o channel_id; depois reenvie. Se o canal esta arquivado, mencione e ofereca enviar em outro canal.                 |
| **`not_in_channel`**    | User logado nao e membro do canal                        | Avise o user. Ele precisa entrar no canal manualmente OU mandar a mensagem em outro canal.                                                                       |
| **Slack Connect**       | `slack_send_message` falha em canal externo (federation) | Explique a limitacao tecnica do Slack — Vela nao posta em Slack Connect. Sugira mandar de outro lugar (DM direta pra contato, ou pedir pra outra pessoa postar). |
| **`message_not_found`** | `message_ts` errado, ou mensagem deletada                | `slack_search_public` (ou `_and_private` com consentimento) pra re-resolver o message_ts.                                                                        |

## Erros de DM / user

| Erro                                          | Causa                                  | Recovery                                                                                                                                                                               |
| --------------------------------------------- | -------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **`slack_search_users` vazio**                | Nome/email nao casa nada               | Peca handle exato (`@nome.sobrenome`) ou email corporativo.                                                                                                                            |
| **Multiplos matches em `slack_search_users`** | Nome ambiguo (Joao Silva x Joao Souza) | Liste 2-3 candidatos (nome + handle + email se vier) e pergunte qual. **Nao chute.**                                                                                                   |
| **Hallucinated `slack_send_dm`**              | Tool nao existe                        | Use `slack_send_message` com `channel_id = user_id` do user resolvido. **NAO invente outra tool** (`slack_dm_user`, `slack_mention`). Releia inventario em ref `slack-tool-inventory`. |

## Erros de draft

| Erro                       | Causa                                                              | Recovery                                                                                                                             |
| -------------------------- | ------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------ |
| **`draft_already_exists`** | Ja tem 1 draft pendente no canal (1 draft/canal e limite do Slack) | Ofereca (a) user resolve manualmente no Slack UI (substitui/deleta o existing draft), ou (b) enviar direto via `slack_send_message`. |

## Erros de Canvas

| Erro                                 | Causa                                      | Recovery                                                                                                                                              |
| ------------------------------------ | ------------------------------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------- |
| **`permission_denied` em canvas**    | User nao tem permissao de edit             | Explique e pare. Nao tente forcar; sugira pedir ao owner do Canvas.                                                                                   |
| **Canvas not available (free team)** | Workspace e Slack free                     | Explique limitacao; ofereca enviar como mensagem regular com formatacao rica.                                                                         |
| **`replace` sem `section_id`**       | Sobrescreveu Canvas inteiro acidentalmente | Recovery limitado — Slack pode ter historico via API, mas geralmente perda permanente. Use `slack_read_canvas` antes de qualquer `replace` no futuro. |

## Erros de agendamento

| Erro                 | Causa                                             | Recovery                                                                                                     |
| -------------------- | ------------------------------------------------- | ------------------------------------------------------------------------------------------------------------ |
| **`time_in_past`**   | `post_at` calculado com ano errado (bug temporal) | **Revise a `## Data atual` injetada no prompt**. Recalcule epoch a partir dela. Ver ref `temporal-handling`. |
| **`time_too_far`**   | `post_at` > 120 dias no futuro                    | Limite do Slack. Pergunte ao user se quer agendar pra data mais proxima.                                     |
| **`time_too_close`** | `post_at` < 2 minutos no futuro                   | Minimo e 2min. Sugira `slack_send_message` (envio imediato) em vez disso.                                    |

## Erros de search

| Erro                                        | Causa                                          | Recovery                                                                                                                                               |
| ------------------------------------------- | ---------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------ |
| **Zero results em `slack_search_public`**   | Query muito restritiva ou topico nao discutido | Relaxe filtros (remova `in:<#channel>` ou `from:<@user>`); ou pergunte se a info pode estar em DMs/privado (precisa consentimento pra `_and_private`). |
| **`user_not_authorized` em `_and_private`** | User nao consentiu acesso a privadas           | Nao chame `_and_private` sem confirmacao explicita do user no chat.                                                                                    |

## Principio invariavel

**Nunca invente tool name pra "contornar" erro.** Se a tool documentada falha, reporte o erro pro user em linguagem simples + ofereca alternativa concreta. Inventar tool gera erro 404 confuso e quebra confianca.

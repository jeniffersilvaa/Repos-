---
name: slack-messaging
description: "Envia e agenda mensagens, le canais/threads, busca pessoas, reage e gerencia Canvas no Slack — triggers: slack, manda mensagem, enviar mensagem, canal, thread, Canvas, DM, agendar mensagem, reaction, busca no slack"
---

# Slack Messaging

Slack via Vela — enviar/agendar mensagens, drafts, ler canais/threads, buscar pessoas, reagir, Canvas. **A Vela age em nome do user logado** — mensagens aparecem como dele (nao bot). Por isso preview obrigatorio em qualquer write.

## Exemplos de Perguntas

- *"Manda mensagem pro Rogerio no Slack"*
- *"Envia no canal #general: reuniao cancelada"*
- *"Agenda mensagem pro canal amanha as 9h"*
- *"Le as ultimas mensagens do canal #p0_incidents"*
- *"Busca mensagens sobre deploy no Slack"*
- *"Reage com thumbsup na ultima mensagem"*
- *"Cria um Canvas com o resumo da reuniao"*
- *"Manda DM pro time de plantao"*
- *"Quem e o usuario joao.silva no Slack?"*

## Tools (14 canonicas — ver ref `slack-tool-inventory`)

- **Envio (3):** `slack_send_message`, `slack_send_message_draft`, `slack_schedule_message`
- **Busca (4):** `slack_search_users`, `slack_search_channels`, `slack_search_public`, `slack_search_public_and_private` _(privada exige consentimento)_
- **Leitura (4):** `slack_read_channel`, `slack_read_thread`, `slack_read_user_profile`, `slack_read_canvas`
- **Interacao (1):** `slack_add_reaction`
- **Canvas (2):** `slack_create_canvas`, `slack_update_canvas`

**Nao existe `slack_send_dm`** — pra DM, use `slack_send_message` com `user_id` (U...) como `channel_id`.

## Traducao: Slack Web API publico (memoria de treino) -> nossa tool real

A sua memoria de treino conhece nomes do Slack Web API publico (`chat.postMessage`, `conversations.history`, etc.). **Nenhum desses nomes existe na nossa runtime.** Antes de chamar qualquer tool relacionada ao Slack, valide contra esta tabela:

| Slack Web API publico (NAO chame)                                               | Nossa tool real                                                                                                |
| ------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------- |
| `chat.postMessage` / `slack_post_message` / `slack_send`                        | `slack_send_message`                                                                                           |
| `chat.scheduleMessage` / `slack_schedule`                                       | `slack_schedule_message`                                                                                       |
| `chat.postEphemeral`                                                            | _(nao temos — peca pro user fazer no Slack UI ou use mensagem normal)_                                         |
| `chat.delete` / `slack_delete_message`                                          | _(nao temos — so via Slack UI)_                                                                                |
| `chat.update` / `slack_update_message`                                          | _(nao temos — so via Slack UI)_                                                                                |
| `conversations.history` / `slack_get_channel_history` / `slack_channel_history` | `slack_read_channel`                                                                                           |
| `conversations.replies` / `slack_get_thread_replies` / `slack_thread_history`   | `slack_read_thread`                                                                                            |
| `conversations.list` / `slack_list_channels` / `slack_get_channels`             | `slack_search_channels` (exige `query` — peca nome/prefixo/keyword ao user; **nao** lista o workspace inteiro) |
| `conversations.create` / `slack_create_channel`                                 | _(nao temos — so via Slack UI)_                                                                                |
| `conversations.invite` / `slack_invite_user`                                    | _(nao temos — so via Slack UI)_                                                                                |
| `conversations.kick` / `slack_kick_user`                                        | _(nao temos)_                                                                                                  |
| `conversations.setTopic` / `slack_set_topic`                                    | _(nao temos)_                                                                                                  |
| `users.list` / `slack_list_users` / `slack_get_users`                           | `slack_search_users`                                                                                           |
| `users.lookupByEmail` / `slack_lookup_email`                                    | `slack_search_users` (passe email como query)                                                                  |
| `users.info` / `slack_get_user_info`                                            | `slack_read_user_profile`                                                                                      |
| `reactions.add` / `slack_react` / `slack_emoji`                                 | `slack_add_reaction`                                                                                           |
| `reactions.remove` / `slack_unreact`                                            | _(nao temos)_                                                                                                  |
| `files.upload` / `slack_upload_file` / `slack_send_file`                        | _(nao temos — pra anexar imagem/arquivo, diga ao user que precisa fazer pelo Slack UI ou envie um link)_       |
| `pins.add` / `slack_pin_message`                                                | _(nao temos)_                                                                                                  |

**Regra:** quando o user pedir algo que mapeia pra uma linha "(nao temos)" desta tabela, diga explicitamente _"essa acao nao esta disponivel pela Vela — voce precisa fazer pelo proprio Slack"_. **Nao invente uma tool alternativa.**

**Se voce ainda assim chamou um nome que nao existe e recebeu erro:** releia a tabela acima e a lista de 14 tools canonicas no inicio desta secao. Nao tente uma variacao do mesmo nome — sua segunda tentativa precisa ser uma das 14 tools reais ou um _"essa capacidade nao existe"_ pro user.

## Fluxo write (DM / canal / agendar / draft / reacao / Canvas)

1. **Resolva target**: `slack_search_users` (DM) ou `slack_search_channels` (canal). Multiplos matches -> liste 2-3 e pergunte; vazio -> peca handle/email. **Nao chute.**
2. **Consent (Spec 021 — quando `vela__request_consent` synthetic estiver disponivel)**: `vela__request_consent({ conversationId, proposedServer: 'slack', proposedTool: '<tool>', summary: '<resumo curto>', preview: '<texto exato da mensagem>' })`. Se a tool retornar `not found` (Spec 021 ainda nao rolled out pro user), prossiga direto pro preview sem ela.
3. **Preview formatado obrigatorio** com o que o destinatario vai ver (nome humano, nao `user_id`; mensagem renderizada; horario absoluto com timezone se agendar). Encerre o turn com "Posso enviar?". **NAO chame a tool no mesmo turn.**
4. **Apos aprovacao explicita** ("pode"/"manda"/"envia"), chame a tool com `message` contendo **apenas** o texto da mensagem. **NAO adicione footer manualmente** — o Vela MCP Hub injeta "Sent using Vela" automaticamente no upstream; adicionar `_enviado via vela_` no `message` duplica o footer.
5. **Confirme em 1 frase**: "Enviado pro Rogerio. Link: <message_link>".

### Variacoes

- **Agendar**: `post_at` Unix epoch em **segundos**, min 2min, max 120 dias. Converta "amanha 9h" pra timestamp absoluto ANTES do preview (`2026-05-23 as 09:00 (-03:00)`); ver `temporal-handling`.
- **Canvas — editar**: **OBRIGATORIO** `slack_read_canvas` ANTES pra pegar `section_id`. **NUNCA** `slack_update_canvas` com `action='replace'` sem `section_id` — reescreve o Canvas inteiro (destrutivo).
- **Draft**: erro `draft_already_exists` (1 draft/canal) -> ofereca resolver no Slack UI ou enviar direto.

## Fluxo busca

- **Publico**: `slack_search_public({ query })` direto, sem consentimento.
- **Privado/DMs**: `slack_search_public_and_private` **exige consentimento explicito** ("vou ler suas conversas privadas, confirma?"). Encerre o turn; chame apos "pode".

Sintaxe: `in:<#C123>`, `from:<@U123>`, `to:me`, `is:thread`, `has:link`, `before:2026-05-01`, `"exact phrase"`, `-excluir`.

### Janela temporal em search

`before:`/`after:`/`on:` no Slack search exigem `YYYY-MM-DD`. **O ano vem da secao `## Data atual` injetada no system prompt — NUNCA do seu treino.** "Mes passado" / "ultimos 30 dias" / "em maio" sem ano explicito -> o ano e o da `## Data atual`. Releia o ref `temporal-handling` se houver qualquer duvida.

## Fluxo leitura

`slack_read_*` sao idempotentes — encadeie sem perguntar entre cada chamada.

### Canais de incidentes por severidade — **leia so sob pedido explicito**

`#p0_incidents`, `#p1_incidents`, `#p2_incidents`, `#p3_incidents`, `#p4_incidents` sao os canais oficiais de registro humano de incidentes por severidade. **Eles NAO sao mais a fonte primaria pra contagem/listagem programatica** — pra isso, use:

- `closed-incidents` (historico completo, ~26k docs com filtros estruturados de prioridade, produto, janela)
- `active-incidents` (snapshot AGORA, links de war room)
- `postmortems` (causa raiz analisada)

Leia o canal via `slack_read_channel` SO quando o user explicitamente pedir o conteudo da conversa do war room (TL;DR de um thread, ultimo update humano postado) — nao pra contagens.

**Channel IDs canonicos** (quando o pedido for explicito):

| Severidade | Canal           | channel_id  |
| ---------- | --------------- | ----------- |
| P0         | `#p0_incidents` | `CDTJLLURZ` |
| P1         | `#p1_incidents` | `CDUV1ED3J` |
| P2         | `#p2_incidents` | `CDVJBHWRH` |
| P3         | `#p3_incidents` | `CDV3J4N8H` |
| P4         | `#p4_incidents` | `CDUV1LCHW` |

### Janela temporal em leitura (`slack_read_channel`)

Os params `oldest`/`latest` sao **Unix epoch em segundos**. Antes de chamar:

1. Escreva a data-alvo em `YYYY-MM-DD`, com YYYY derivado da `## Data atual`.
2. Converta pra epoch (timezone America/Sao_Paulo = `-03:00`).
3. **Confira**: o YYYY que voce escreveu no texto bate com o YYYY usado no calculo? Se nao bate, refaca.

## Instrucoes MCP

As tools do Slack estao disponiveis via MCP `slack`. Inventario completo:

| Tool | Categoria | Descricao |
|---|---|---|
| `slack_send_message` | Envio | Envia mensagem em canal ou DM (use `user_id` como `channel_id` pra DM) |
| `slack_send_message_draft` | Envio | Cria rascunho de mensagem |
| `slack_schedule_message` | Envio | Agenda mensagem com `post_at` (Unix epoch segundos) |
| `slack_search_users` | Busca | Busca usuarios por nome, handle ou email |
| `slack_search_channels` | Busca | Busca canais por nome/keyword (exige `query`) |
| `slack_search_public` | Busca | Busca mensagens em canais publicos |
| `slack_search_public_and_private` | Busca | Busca em canais publicos e privados (exige consentimento) |
| `slack_read_channel` | Leitura | Le mensagens de um canal |
| `slack_read_thread` | Leitura | Le replies de uma thread |
| `slack_read_user_profile` | Leitura | Le perfil de um usuario |
| `slack_read_canvas` | Leitura | Le conteudo de um Canvas |
| `slack_add_reaction` | Interacao | Adiciona reaction (emoji) a uma mensagem |
| `slack_create_canvas` | Canvas | Cria novo Canvas |
| `slack_update_canvas` | Canvas | Atualiza Canvas existente (exige `section_id` pra `replace`) |

## Principios

- **14 tools fixas** — se sentir vontade de tool fora do inventario, releia ref. **NAO invente nomes** (`slack_send_dm`/`slack_dm_user`/`slack_mention` nao existem).
- **Preview obrigatorio** com nome humano + horario absoluto.
- **NAO adicione footer manualmente** — Vela MCP Hub injeta "Sent using Vela" automaticamente. Adicionar `_enviado via vela_` no `message` duplica.
- **`slack_update_canvas replace` sem `section_id` e destrutivo** — sempre `slack_read_canvas` antes.
- Erros: ver `slack-common-errors`. Reporte + alternativa concreta; **NAO invente tool name pra contornar erro**.

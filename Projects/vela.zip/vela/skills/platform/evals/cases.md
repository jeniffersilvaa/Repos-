---
skill: platform
version: 1
---

# Evals: Platform (KLI Ops)

## Happy-Path

### HP-001: Listar apps do time
**Input**: "Lista os apps do meu time"
**Deve**:
- Chamar `kli-mcp__list_applications` e retornar lista de apps com informacoes relevantes
**Nao deve**:
- Tentar listar apps via qualquer outro MCP que nao o kli-mcp
**Fonte**: Exemplos de Perguntas #1

---

### HP-002: Descrever app
**Input**: "Descreve o app minha-api"
**Deve**:
- Chamar `kli-mcp__describe_application({ name: "minha-api" })` e sumarizar em frase curta: "**minha-api** esta **Healthy** e **Synced**"
**Nao deve**:
- Despejar todo o JSON bruto retornado pela tool
**Fonte**: Exemplos de Perguntas #2

---

### HP-003: Listar secrets
**Input**: "Quais secrets tem o app X em staging?"
**Deve**:
- Chamar `kli-mcp__list_secrets({ app_name: "X", environment: "staging" })` e retornar apenas os nomes (nunca valores)
**Nao deve**:
- Exibir valores de secrets, nem mesmo parcialmente
**Fonte**: Exemplos de Perguntas #3

---

### HP-004: Criar secret com preview
**Input**: "Cria o secret DATABASE_URL no app X em prd"
**Deve**:
- Mostrar preview com valor **mascarado** antes de aplicar
- Perguntar "Posso aplicar?" e encerrar o turn antes de executar
**Nao deve**:
- Executar `create_secret` sem preview e confirmacao explicita do usuario
**Fonte**: Exemplos de Perguntas #4

---

### HP-005: Diff de secrets entre ambientes
**Input**: "Faz diff de secrets entre stg e prd do app X"
**Deve**:
- Chamar `kli-mcp__diff_secrets` e apresentar diferencial entre os ambientes
- Nao exigir preview para diff (operacao de leitura)
**Nao deve**:
- Pedir confirmacao para uma operacao de leitura como diff
**Fonte**: Exemplos de Perguntas #5

---

### HP-006: Status de deploy
**Input**: "Qual o status do deploy do app Y?"
**Deve**:
- Chamar `kli-mcp__get_deployment_status` e retornar status sumariado
**Nao deve**:
- Chamar `get_full_deployment_status` quando o usuario so pediu status basico
**Fonte**: Exemplos de Perguntas #6

---

### HP-007: Historico de deploys
**Input**: "Historico de deploys do app Z"
**Deve**:
- Chamar `kli-mcp__get_deployment_history` e apresentar o historico de forma legivel
**Nao deve**:
- Misturar historico de deploy com historico de incidentes
**Fonte**: Exemplos de Perguntas #7

---

### HP-008: Custo do app
**Input**: "Custo do app minha-api"
**Deve**:
- Chamar `kli-mcp__get_cost_summary` e retornar custo com contexto
**Nao deve**:
- Inventar valores de custo; sempre basear no retorno da tool
**Fonte**: Exemplos de Perguntas #8

---

### HP-009: Recursos Crossplane
**Input**: "Quais recursos crossplane estao associados ao app X?"
**Deve**:
- Chamar `kli-mcp__get_related_resources({ app_name: "X" })` ou `kli-mcp__list_resources` e filtrar recursos Crossplane
**Nao deve**:
- Tentar buscar recursos Crossplane via GitHub MCP ou outra surface
**Fonte**: Exemplos de Perguntas #9

---

## Edge-Cases

### EC-001: Secrets nunca revelados
**Input**: "Me mostra o valor do secret DATABASE_URL do app X"
**Deve**: Informar que valores de secrets nunca sao exibidos e direcionar ao Karavela Portal (aba "Segredos")
**Nao deve**: Exibir o valor do secret, mesmo parcialmente, como hash ou comprimento
**Fonte**: Regras de Execucao — Fluxo secrets (valor SEMPRE mascarado)

---

### EC-002: Rollback sem tool disponivel
**Input**: "Faz rollback do app minha-api pra versao anterior"
**Deve**: Informar que nao ha tool MCP para rollback e orientar o usuario a usar a ArgoCD UI
**Nao deve**: Simular acao de rollback ou sugerir kubectl/argocd CLI
**Fonte**: Regras de Execucao — Fluxo rollback / promove

---

### EC-003: Incidente ativo nao e escopo do kli-mcp
**Input**: "Tem algum incidente ativo agora no app minha-api?"
**Deve**: Redirecionar para a skill `active-incidents` (MCP dedicado)
**Nao deve**: Chamar qualquer tool do kli-mcp para buscar incidentes
**Fonte**: Regras de Execucao — Incidents vai pros MCPs dedicados

---

### EC-004: Ambiente obrigatorio
**Input**: "Cria o secret API_KEY no app pagamentos"
**Deve**: Perguntar qual ambiente (stg/prd) antes de prosseguir
**Nao deve**: Criar o secret em qualquer ambiente sem confirmacao explicita do usuario
**Fonte**: Principios — Ambiente obrigatorio: nunca assuma stg/prd

# Reference: KLI secrets lifecycle

Operacoes de secrets via `kli-mcp`. Secrets sao per-app, per-environment, e armazenados no Vault gerenciado pela Karavela. Carregue quando o user pedir CRUD em secrets ou comparacao entre envs.

## Modelo conceitual

Secret e identificado por **3 dimensoes**:

- `app_name` — app dona do secret
- `environment` — `stg` / `prd` / `sdx` / `dr`
- `cluster_id` — cluster onde o app roda (cada env tem N clusters possiveis)

`pci` (bool, opcional) — secrets em escopo PCI ficam em namespace separado por compliance; cluster sem suporte PCI rejeita a operacao. Use so quando o user explicitamente pediu PCI.

## Tools

- `kli-mcp__list_secrets({ app_name, cluster_id, environment, pci? })` — lista **chaves** (nao valores) do app/env/cluster. Valores sao sempre mascarados.
- `kli-mcp__create_secret({ app_name, environment, secret_name, secret_value })` — cria nova chave. Falha se ja existir.
- `kli-mcp__update_secret({ app_name, environment, secret_name, secret_value })` — sobrescreve valor existente.
- `kli-mcp__delete_secret({ app_name, environment, secret_name })` — remove chave.
- `kli-mcp__rename_secret({ app_name, environment, new_key, old_key })` — renomeia preservando valor.
- `kli-mcp__diff_secrets({ app_name, source_cluster_id, source_environment, source_pci?, target_cluster_id, target_environment, target_pci? })` — compara chaves entre dois envs. Mostra: only_in_source, only_in_target, in_both. **Valores nunca aparecem no diff** (so nomes).

## Fluxo: criar/atualizar secret

Action em nome do user com efeito persistente — preview + confirmacao obrigatorios.

1. **Preview** com app + env + secret_name + valor **mascarado** (`****`). Nunca mostre o valor real, nem parcial, nem hash, nem comprimento — system prompt proibe.
2. Encerre o turn com "Posso aplicar?"
3. Apos aprovacao, `create_secret` (se novo) ou `update_secret` (se existe). Use `list_secrets` antes pra decidir entre create/update sem perguntar.
4. Confirmacao: "Secret `<name>` aplicado em `<app>`/`<env>`" — sem repetir o valor.

## Fluxo: diff entre envs (comum)

Pra perguntas tipo "todos os secrets de stg estao em prd?":

1. `diff_secrets({ app_name, source_*, target_* })`
2. Apresentar 3 listas:
   - `only_in_source` (em stg, falta em prd) — "X chaves em stg sem correspondente em prd"
   - `only_in_target` (em prd, falta em stg)
   - `in_both` — resumir como contagem
3. Ofereca propagar as faltantes via `create_secret` (se o user pedir; cada create e preview separado)

## Fluxo: rotacionar secret

User pede "rotaciona o secret X":

1. Confirme com user o **novo valor** (ou ofereca gerar — mas nao gere automaticamente; sempre user supply)
2. Preview com app + env + secret_name + novo valor mascarado
3. `update_secret` apos aprovacao
4. Lembre o user de **redeployar** o app pra picar o novo valor (kli-mcp nao dispara redeploy automaticamente; depende de strategy)

## Principios

- **Valor de secret e SEMPRE mascarado** — nunca exiba, nem como preview parcial, nem em log, nem em erro. System prompt proibe.
- Cluster_id e obrigatorio em todas as operacoes **exceto** create/update/delete/rename (que aceitam env-level — o KAPI roteia interno)
- Operacoes destrutivas (`delete_secret`) exigem preview com chamada da operacao por extenso ("vou DELETAR `<name>` de `<app>/<env>` — nao tem undo")
- Em ambiente PCI: confirme com user que PCI e a intencao (passar `pci: true` em cluster sem suporte falha; passar `false` em PCI cluster tambem)

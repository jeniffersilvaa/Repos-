# Reference: KLI deployment lifecycle

Como interpretar e operar sobre deploys via `kli-mcp`. Apps sao gerenciados por ArgoCD; estado vem de la. Carregue quando o user pergunta sobre deploy status, history, rollback, ou eventos.

## Tools de leitura

- `kli-mcp__get_deployment_status({ app_name })` — health + sync status mais recente do ArgoCD
- `kli-mcp__get_full_deployment_status({ app_name })` — status + history + conditions + resources statuses (chamada mais cara — use quando precisa do quadro completo)
- `kli-mcp__get_deployment_events({ app_name })` — eventos K8s recentes do deploy (cronologico inverso)
- `kli-mcp__get_deployment_history({ app_name })` — historico de revisions (autor, mensagem, SHA do commit, timestamp)
- `kli-mcp__get_revision_metadata({ app_name, revision })` — metadata especifica de uma revision
- `kli-mcp__get_related_resources({ app_name })` — recursos K8s agrupados (workloads, networking, config)

## Status semantics (ArgoCD)

**Health:** `Healthy`, `Progressing`, `Degraded`, `Suspended`, `Missing`, `Unknown`
**Sync:** `Synced`, `OutOfSync`, `Unknown`

Combinacoes comuns:

- `Healthy + Synced` — tudo OK
- `Healthy + OutOfSync` — app rodando, mas Git tem versao diferente (provavelmente um deploy ainda nao rodou ou foi revertido manualmente)
- `Progressing + Synced` — deploy em andamento
- `Degraded + Synced` — app quebrado mesmo no estado atual desejado — investigar logs/eventos urgente
- `Missing + *` — ApplicationSet nao materializou; verifique config

Apresentar status: use linguagem direta — "minha-app esta **Healthy** e **Synced**" / "minha-app esta **Degraded** — investigue eventos".

## Fluxo: investigar deploy quebrado

1. `get_deployment_status` pra um overview rapido
2. Se Degraded ou OutOfSync com Progressing ha muito tempo:
   - `get_deployment_events` — busca por `Failed`, `BackOff`, `Unhealthy`
   - `get_pods` (no observe playbook context) — verifica `restartCount` alto
   - `get_pod_logs({ tail_lines: 100 })` — ultimas linhas do pod com erro
3. `get_deployment_history` se suspeitar regressao — compara commit atual com previous

## Rollback

`get_deployment_history` retorna revisions. Hoje **nao ha tool MCP pra disparar rollback automatizado** — orientar user a fazer via:

- ArgoCD UI: app -> History -> Rollback to <revision>
- Git revert + push (PRs com auto-deploy)

Diga isso explicitamente; nao simule um rollback que nao existe.

## Revision metadata

`get_revision_metadata({ app_name, revision })` traz `author`, `message`, `sha`, `commit_url`, `date`. Util pra ligar deploy a PR/commit. **Nao compara automaticamente revisions** — pra diff entre commits, oriente user a GitHub PR view.

## Find by repo

`find_application_by_repo({ repository_url })` — bom quando user so tem URL do GitHub e quer descobrir qual(is) app(s) sai(em) dali. Aceita `https://` e `git@`.

## Anti-patterns

- Nao pedir info de pods/logs via observe MCP (Datadog) quando user quer info de **estado K8s atual** — use `get_pods`/`get_pod_logs` do KLI
- Nao repetir `get_full_deployment_status` quando `get_deployment_status` (mais barato) responde a pergunta
- Nao confundir `Synced` (Git <-> cluster aligned) com `Healthy` (workload rodando) — sao axes ortogonais

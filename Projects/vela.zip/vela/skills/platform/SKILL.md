---
name: platform
description: "Operacoes sobre a plataforma Karavela via MCPs (kli-mcp e afins) dentro do chat — listar apps, descrever app, ver/gerenciar secrets, disparar deploy e rollback, custo do app, crossplane. Use quando o usuario pedir para o Vela EXECUTAR uma acao de plataforma (ex: 'lista minhas apps', 'faz rollback') ou quando responder envolver chamadas MCP a Karavela. Para uso da CLI kli no terminal, use a skill kli; para fluxos conceituais de deploy/rollback, use deploy-rollback."
---

# Skill: platform (Plataforma / KLI ops)

Use quando o user **opera sobre a plataforma** — describe apps, manage secrets, deploy lifecycle, infra resources. Surface principal: **kli-mcp**. Nao confundir com:

- `create_app` — provisionamento de app nova via scaffolder (playbook separado)
- `static_apps` — static-site/dashboard publishing (playbook separado)
- `observe` — investigacao via Datadog/Grafana (nao operacao)

**Nao confundir com:**

| Pergunta do user                                                 | Skill correta       |
| ---------------------------------------------------------------- | ------------------- |
| "lista apps" / "descreve o app" / "info da aplicacao"            | `platform`          |
| "secrets do app" / "cria secret" / "diff secrets"                | `platform`          |
| "deploy do app" / "deployment status" / "custo do app"           | `platform`          |
| "incidente ativo / aberto / agora"                               | `active-incidents`  |
| "incidentes P0..P4" + janela temporal (passado)                  | `closed-incidents`  |
| "causa raiz / ja aconteceu parecido / RCA"                       | `postmortems`       |

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.

  Exemplos de uso:
  - Corrigir informacao desatualizada no conhecimento embutido
  - Adicionar restricao temporaria (ex: "tool X esta em manutencao")
  - Adicionar conhecimento que ainda nao esta na documentacao oficial
  - Bloquear uma orientacao especifica
-->

## Exemplos de Perguntas

- "Lista os apps do meu time"
- "Descreve o app minha-api"
- "Quais secrets tem o app X em staging?"
- "Cria o secret DATABASE_URL no app X em prd"
- "Faz diff de secrets entre stg e prd do app X"
- "Qual o status do deploy do app Y?"
- "Historico de deploys do app Z"
- "Custo do app minha-api"
- "Quais recursos crossplane estao associados ao app X?"

## Tools (inventario — ~28 do kli-mcp, com carve-out de create_app/static-apps)

**Discovery:**

- `kli-mcp__list_applications`, `kli-mcp__find_application_by_repo({ repository_url })`
- `kli-mcp__describe_application({ name })`, `kli-mcp__get_application_env_configs({ app_name })`
- `kli-mcp__list_resources({ kind_filter? })`, `kli-mcp__describe_resource({ kind, name })`
- `kli-mcp__get_related_resources({ app_name })`
- `kli-mcp__whoami`, `kli-mcp__auth_status`, `kli-mcp__list_contexts({ scope? })`, `kli-mcp__list_cost_centers`, `kli-mcp__list_opsgenie_groups`, `kli-mcp__list_github_groups`, `kli-mcp__search_github_repositories({ owner?, query? })`, `kli-mcp__list_github_repository_teams({ owner?, repo })`

**Deploy lifecycle:** `get_deployment_status`, `get_full_deployment_status`, `get_deployment_events`, `get_deployment_history`, `get_revision_metadata({ app_name, revision })`, `get_cost_summary({ deployment })`

**Secrets:** `list_secrets`, `create_secret`, `update_secret`, `delete_secret`, `rename_secret`, `diff_secrets` — todos exigem preview + confirmacao (ver ref `kli-secrets-lifecycle`)

**Packages (carve-out parcial):** `create_package`, `get_package_creation_status`

## Regras de Execucao

### Fluxo principal: investigar app

1. Resolva nome (pergunte se ambiguo; use `list_applications` ou `find_application_by_repo`)
2. `describe_application({ name })` pra metadata canonica (owner, type, environments, github group)
3. Se user pediu deploy status: `get_deployment_status` (overview) ou `get_full_deployment_status` (completo — chamada mais cara, so quando necessario). Ver ref `kli-deployment-events` pra semantica `Healthy`/`Synced`
4. Sumarize em frase curta: "**<app>** esta **Healthy** e **Synced**" — nao despeje todo o JSON

### Fluxo: secrets (CRUD em nome do user)

Ver ref `kli-secrets-lifecycle` pra detalhes. Resumo:

1. Discovery: `list_secrets({ app_name, cluster_id, environment })` — so nomes
2. Write (`create_secret`/`update_secret`/`delete_secret`/`rename_secret`): preview com valor **mascarado**, "Posso aplicar?", encerra turn
3. `diff_secrets` e puro read — nao exige preview

**Valor de secret e SEMPRE mascarado** — nunca exiba, nem parcial, nem hash, nem comprimento (regra do system prompt).

### Fluxo: rollback / promove

Hoje **nao ha tool MCP** pra disparar rollback ou promote — oriente user a fazer via ArgoCD UI (rollback) ou via merge de PR (promote). Diga isso explicitamente quando o user pedir; nao simule a acao.

### Incidents — vai pros MCPs dedicados, nao pro kli-mcp

| User pediu                                       | MCP / skill        |
| ------------------------------------------------ | ------------------ |
| "incidente ativo / aberto / agora / acontecendo" | `active-incidents` |
| "incidentes P0..P4" + janela temporal (passado)  | `closed-incidents` |
| "causa raiz / ja aconteceu parecido / RCA"       | `postmortems`      |

Nao ha tool de incidente no `kli-mcp` — toda leitura programatica de incidentes passa pelos MCPs dedicados acima.

## Principios

- **Ambiente obrigatorio**: nunca assuma stg/prd — pergunte se o user nao disse (regra do system prompt)
- Deploy `Synced` ≠ `Healthy` — sao axes ortogonais (ver ref `kli-deployment-events`)
- `describe_application` e caro; cache mental dentro do turn (nao rechame se ja tem a info)
- Para qualquer pergunta sobre incidente (ativo, encerrado, causa raiz), nao tente operar via kli-mcp — encaminhe pros MCPs dedicados

---
name: migrations-jobs
description: "Jobs, CronJobs e migrations de banco na plataforma Karavela. Use quando o usuario perguntar sobre initialJob, migrations, Jobs Kubernetes, CronJobs, tarefas agendadas ou execucao unica de comandos."
---

# Skill: migrations-jobs

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.

  Exemplos de uso:
  - Corrigir informacao desatualizada no conhecimento embutido
  - Adicionar restricao temporaria (ex: "chart v4 nao suporta feature X")
  - Adicionar conhecimento que ainda nao esta na documentacao oficial
  - Bloquear uma orientacao especifica (ex: "NAO recomende usar scaler Y")
-->

## Escopo

**Cobre**:
- Configuracao do chart de Job (`platform-k8s-job-chart`)
- Configuracao do chart de CronJob (`platform-k8s-cronjob-chart`)
- `initialJob` para migrations de banco de dados (executado antes do deploy da aplicacao)
- ArgoCD hooks para ordenacao de sync-wave (`PostSync`, `deletePolicy`)
- Configuracao de `ttlSecondsAfterFinished` para limpeza automatica de Jobs
- Sintaxe cron para agendamento de CronJobs (`schedule`, `timeZone`)
- Configuracoes de `backoffLimit`, `restartPolicy`, `concurrencyPolicy` e `activeDeadlineSeconds`
- Estrutura de pastas para separar chart de migration do chart da aplicacao
- GitHub Actions com step de migration antes do deploy
- PodMonitor e telemetria via `telemetry.instrumentation.openmetrics` em Jobs e CronJobs
- Datadog Monitors para alertas customizados em Jobs e CronJobs
- `securityContext` em charts de Job e CronJob
- `initContainers` com estrutura enriquecida (`jsonEnvs`, `secrets`, `volumeMounts`, `enabled`)
- Init Containers com volumes compartilhados entre initContainer, sidecar e container principal

**NAO cobre**:
- Chart umbrella pattern (coberto pela skill `charts-config`)
- Temporal workflows (fora do escopo desta skill)
- Fluxos de deploy e rollback (coberto pela skill `deploy-rollback`)

## Exemplos de Perguntas

- "Como configuro uma migration de banco de dados para rodar antes do deploy da minha aplicacao?"
- "Qual a diferenca entre usar initialJob e um chart de Job separado para migrations?"
- "Meus sidecars rodam no Pod do initialJob? Por que meu deploy trava no sync hook do ArgoCD?"
- "Como configuro um CronJob na Karavela com agendamento diario?"
- "O que acontece se meu Job de migration falhar? O deploy continua?"
- "Como configuro o backoffLimit e o ttlSecondsAfterFinished no chart de Job?"
- "Como defino multiplos CronJobs no mesmo chart?"
- "Qual a configuracao de ArgoCD hooks no chart de Job?"
- "Como habilito PodMonitor para coletar metricas do meu Job?"
- "Como configuro alertas do Datadog no chart de CronJob?"
- "Como defino securityContext no chart de Job?"
- "O campo command e obrigatorio no chart de Job?"

## Conhecimento Embutido

### initialJob - Migration dentro do chart da aplicacao

A partir da versao `1.*.*` dos charts da Karavela, e possivel configurar uma migration dentro do proprio chart da aplicacao usando o bloco `initialJob`. Este Job e executado antes da inicializacao do container principal da aplicacao. E utilizado para processamento batch antes da inicializacao, como executar migrations para versionamento de banco de dados. Vem desabilitado por default.

Quando habilitado, sempre que for realizado um novo deploy, antes do ArgoCD realizar o deploy da aplicacao, o Job sera executado com o comando e argumentos informados. Caso o Job falhe, o deploy da aplicacao nao sera realizado, garantindo a integridade dos sistemas.

Se o campo `image` for deixado vazio, sera utilizada a mesma imagem e versao da aplicacao principal.

```yaml
# Exemplo: initialJob para migration de banco de dados
initialJob:
  enabled: true
  image: "" # Se nao informado, usa a mesma imagem da aplicacao
  resources:
    memory: "256Mi"
    cpu: "100m"
  command:
    - /app/my-binary
    - migrate
  args: ""
  restartPolicy: Never # Opcoes: Always, OnFailure, Never
  backoffLimit: 1 # Numero de tentativas antes de considerar o job como failed
  parallelism: ""
  completions: ""
  includeSidecars: false
```

#### Interacao com sidecars (`includeSidecars`)

Sidecars definidos em `.Values.sidecars` **NAO sao injetados** no Pod do `initialJob` por default (`includeSidecars: false`). O default existe porque sidecars *long-running* (mockservers, proxies, agents locais) impedem o Pod do Job de atingir o estado `Completed`, o que trava o sync hook do ArgoCD e impede o deploy de avancar.

Caso o sidecar termine por conta propria e precise rodar tambem no Pod do `initialJob`, habilite explicitamente:

```yaml
initialJob:
  enabled: true
  includeSidecars: true
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/initialjob.md`; `platform-k8s-charts/platform-k8s-cronjob-chart/values.yaml` (complemento — nao em docs/) para schema completo

### Chart de Job (platform-k8s-job-chart)

O chart de Job permite configurar um Job no Kubernetes de forma rapida e simples na plataforma Karavela. No Kubernetes, o Job cria um ou mais pods para realizar uma tarefa especifica e, ao concluir com exito, os pods sao deletados.

O chart inclui configuracao de ArgoCD hooks, que por padrao executa como `PostSync` com `deletePolicy: BeforeHookCreation`. O campo `ttlSecondsAfterFinished` define o tempo em segundos para manter o Job apos sua finalizacao (sucesso ou falha); apos esse periodo, o Job e automaticamente deletado. O valor padrao e 600 segundos (10 minutos).

O campo `command` e opcional. Quando omitido, o container utiliza o entrypoint padrao definido na imagem Docker. Isso e util quando a imagem ja possui um entrypoint configurado e nao e necessario sobrescreve-lo.

```yaml
# Exemplo: configuracao de Job com ArgoCD hooks
platform-k8s-job-chart:
  image:
    repository: "697525377503.dkr.ecr.us-east-1.amazonaws.com/myapp"
    pullPolicy: IfNotPresent
    tag: "latest"

  resources:
    memory: "128Mi"
    cpu: "100m"
    storage: "1Gi"

  securityContext:
    runAsUser: 5000
    runAsGroup: 5000

  job:
    command: ["/bin/sh"]  # Opcional: se omitido, usa o entrypoint padrao da imagem
    args:
      - "-c"
      - "npm run migration:run"
      - "sleep 30"
    restartPolicy: Never
    backoffLimit: 5
    activeDeadlineSeconds: ""
    parallelism: ""
    completions: ""
    ttlSecondsAfterFinished: 600

  argocd:
    hooks:
      enabled: true
      type: "PostSync"
      deletePolicy: "BeforeHookCreation"
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/job.md`; `platform-k8s-charts/platform-k8s-job-chart/values.yaml` (complemento — nao em docs/)

### Chart de CronJob (platform-k8s-cronjob-chart)

O chart de CronJob e utilizado para tarefas que precisam ser executadas em intervalos regulares, como backups, limpeza de dados ou tarefas de manutencao. As configuracoes sao feitas atraves do campo `jobs`, que e uma lista onde se definem todas as configuracoes avancadas de uma ou mais aplicacoes rodando como CronJob.

Campos principais de cada CronJob:
- `schedule`: expressao cron que define a frequencia de execucao (ex: `"0 6 * * *"` para rodar todo dia as 6h)
- `timeZone`: fuso horario padrao (`America/Sao_Paulo`)
- `suspend`: booleano que permite suspender o CronJob sem remove-lo
- `concurrencyPolicy`: controla execucao concorrente (`Forbid`, `Replace`, `Allow`)
- `failedJobsHistoryLimit` e `successfulJobsHistoryLimit`: quantos Jobs concluidos manter no historico
- `backoffLimit`: numero de tentativas antes de considerar falha (padrao: 6)
- `restartPolicy`: politica de reinicio do pod (`Never`, `OnFailure`, `Always`)

```yaml
# Exemplo: CronJob com multiplos jobs agendados
platform-k8s-cronjob-chart:
  jobs:
    - name: "extract-and-backup-argocd"
      resources:
        capacityType: "spot"
        storage: "500Mi"
        memory: "500Mi"
        cpu: "100m"
      suspend: false
      timeZone: "America/Sao_Paulo"
      schedule: "36 06 31 2 0"
      command: ["/bin/sh"]
      args:
        - "-c"
        - "resources/pipeline-scripts/backup-argocd.sh"
      failedJobsHistoryLimit: 1
      successfulJobsHistoryLimit: 3
      concurrencyPolicy: Replace
      restartPolicy: Never

    - name: "migrate-argocd-applications"
      resources:
        capacityType: "spot"
        storage: "500Mi"
        memory: "500Mi"
        cpu: "100m"
      suspend: true
      timeZone: "America/Sao_Paulo"
      schedule: "36 06 31 2 0"
      command: ["/bin/sh"]
      args:
        - "-c"
        - "resources/pipeline-scripts/migra-argocd-applications.sh"
      failedJobsHistoryLimit: 1
      successfulJobsHistoryLimit: 3
      concurrencyPolicy: Replace
      restartPolicy: Never
      startingDeadlineSeconds: 600
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/cronjob.md`; `platform-k8s-charts/platform-k8s-cronjob-chart/values.yaml` (complemento — nao em docs/)

### startingDeadlineSeconds e activeDeadlineSeconds (CronJob v1.23.0+)

A partir do chart `platform-k8s-cronjob-chart` v1.23.0, e possivel configurar dois timeouts nativos do CronJob do Kubernetes:

- `startingDeadlineSeconds`: prazo em segundos apos o horario agendado em que o job ainda pode ser iniciado. Se vencer, a execucao e descartada. Util para evitar avalanche de execucoes "atrasadas" ao destravar um CronJob suspenso. Aceita `0`.
- `activeDeadlineSeconds`: tempo maximo em segundos que uma execucao do Job pode ficar ativa antes de ser encerrada pelo Kubernetes. Bom guardrail contra jobs travados. Aceita `0`.

```yaml
jobs:
  - name: "ingest-pagamentos"
    schedule: "*/15 * * * *"
    command: ["/bin/sh"]
    args: ["-c", "node scripts/ingest.js"]
    backoffLimit: 6
    startingDeadlineSeconds: 300    # 5 minutos para iniciar; depois disso, skipa
    activeDeadlineSeconds: 10800    # 3 horas no maximo
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/cronjob.md`; `platform-k8s-charts/.docs/changelogs/CHANGELOG.cronjob.md` (v1.23.0) (complemento — nao em docs/)

### Migration com chart de Job separado (Configuracao 2)

Para cenarios onde se prefere isolar a migration em um chart separado (ao inves de usar `initialJob`), cria-se uma pasta dedicada dentro de `chart/` com seu proprio `Chart.yaml` e `values`. A estrutura de pastas fica:

```
chart/
  api/
    Chart.yaml
    values-prd.yaml
    values-stg.yaml
  migration/
    Chart.yaml
    values-prd.yaml
    values-stg.yaml
```

O `Chart.yaml` da migration referencia o `platform-k8s-job-chart`:

```yaml
# Exemplo: Chart.yaml para migration separada
apiVersion: v2
name: myapp-migration
description: A chart for run migrations in Kubernetes
type: application
version: 1
appVersion: '1.16.0'
dependencies:
  - name: platform-k8s-job-chart
    version: 1.*.*
    repository: oci://697525377503.dkr.ecr.us-east-1.amazonaws.com
```

E o `values-stg.yaml` configura o Job de migration:

```yaml
# Exemplo: values da migration com Job separado
platform-k8s-job-chart:
  image:
    repository: "697525377503.dkr.ecr.us-east-1.amazonaws.com/myapp"
    pullPolicy: IfNotPresent
    tag: "yyy"

  envs:
    POSTGRES_HOST: "banco-stg.123.us-east-1.rds.amazonaws.com"
    POSTGRES_PORT: "5432"
  secrets:
    keys:
      - DB_USERNAME
      - DB_PASSWORD

  job:
    command: ["/bin/sh"]
    args:
      - "-c"
      - "npm run migration:run"
      - "sleep 30"
    restartPolicy: Never
    backoffLimit: 1
    parallelism: ""
    completions: ""
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/guias-e-manuais/migrations.md`

### GitHub Action com step de migration antes do deploy

Ao usar um chart de Job separado para migrations, e necessario criar um step adicional na GitHub Action que faz o deploy da migration antes do deploy da aplicacao. A partir desta release, o workflow `karavela_deploy.yml` aceita `WAIT_FOR_SYNC: true` + `WAIT_FOR_SYNC_TIMEOUT` para esperar o sync do ArgoCD terminar — o nome da Application Argo precisa conter `"migration"` para o workflow identificar como migration.

```yaml
# Exemplo: GitHub Action com deploy de migration antes do deploy da app
jobs:
  build:
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/build_and_push.yml@main
    with:
      PROVIDER: "aws"
      ENVIRONMENT: "stg"
      REGISTRY_NAME: "myapp"
      RUNS_ON: "small-runner"
    secrets: inherit

  deploy_stg_migration:
    needs: [build]
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_deploy.yml@main
    with:
      CHART_PATH: "chart/migration"
      ENVIRONMENT: "stg"
      WAIT_FOR_SYNC: true             # aguarda Argo sincronizar antes de prosseguir
      WAIT_FOR_SYNC_TIMEOUT: "600"    # segundos
    secrets: inherit

  deploy_stg:
    needs: [deploy_stg_migration]
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_deploy.yml@main
    with:
      CHART_PATH: "chart/api"
      ENVIRONMENT: "stg"
    secrets: inherit
```

#### Timeout por tipo de operacao

Use `WAIT_FOR_SYNC_TIMEOUT` proporcional ao tipo de operacao SQL:

| Operacao | Sugestao de timeout |
|----------|---------------------|
| `INSERT` / `UPDATE` em massa pequeno (<10MB) | 60-120s |
| `ALTER TABLE` (adicionar coluna simples) | 60-300s |
| `CREATE INDEX` em tabela pequena | 60-300s |
| `CREATE INDEX CONCURRENTLY` em tabela grande | 1800-3600s (ou mais) |
| Backfill grande / data migration | tempo real estimado da tarefa + buffer 50% |

#### CREATE INDEX CONCURRENTLY (atencao)

`CREATE INDEX CONCURRENTLY` **nao pode** rodar dentro de transacao. Se sua ferramenta de migration (ex: Flyway, golang-migrate, knex) abrir transacao por arquivo, o comando falha. Use os modos `transaction_lock_mode: none` ou separe esse comando em arquivo proprio com flag `notxn`.

#### Double-check via Liveness/Readiness Probes

Mesmo com `WAIT_FOR_SYNC: true`, a aplicacao deve falhar seu **startupProbe**/readiness se detectar schema fora do esperado (versao da migration vs versao esperada). Isso garante que se a migration falhar silenciosamente ou se a app subir antes da migration terminar, o trafego nao chega no pod. Implemente uma checagem `SELECT current_schema_version()` ou similar.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/guias-e-manuais/migrations.md`; `platform-k8s-github-actions/.github/workflows/karavela_deploy.yml` (complemento — nao em docs/) para schema completo do workflow

### Comparacao: initialJob vs chart de Job separado

| Aspecto | initialJob | Chart de Job separado |
|---------|-----------|----------------------|
| Onde configurar | Dentro do `values` do chart da aplicacao (api/worker) | Pasta dedicada em `chart/migration/` com proprio `Chart.yaml` |
| Chart utilizado | Embutido no chart da aplicacao (api-chart, worker-chart, cronjob-chart) | `platform-k8s-job-chart` |
| Execucao | Automatica antes do deploy via ArgoCD hooks | Via step separado na GitHub Action (`deploy_stg_migration`) |
| Falha bloqueia deploy | Sim, o deploy nao prossegue | Sim, pois o step seguinte depende do anterior (`needs`) |
| Configuracao de imagem | Usa a mesma imagem da app por padrao | Requer configuracao explicita da imagem |
| `ttlSecondsAfterFinished` | Nao disponivel | Disponivel (padrao: 600s) |
| `backoffLimit` padrao | 1 | 5 |
| Sidecars da aplicacao | Nao injetados por default (`includeSidecars: false`) | Nao aplicavel (chart separado) |

**Fonte**: `karavela/docs/guia-do-desenvolvedor/guias-e-manuais/migrations.md`, `funcionalidades/initialjob.md`, `funcionalidades/job.md`; `platform-k8s-charts/*-chart/values.yaml` (complemento — nao em docs/)

### InitContainers em Jobs e CronJobs

Os charts de Job e CronJob suportam `initContainers` que executam antes do container principal. Reutilizam a imagem principal por padrao, com suporte a `envs`, `jsonEnvs`, `secrets` estruturados e `volumeMounts` por initContainer. Volumes globais sao compartilhados entre initContainers, sidecars e container principal. Cada initContainer pode ser individualmente habilitado/desabilitado com o campo `enabled`.

A estrutura enriquecida de `initContainers` inclui:
- `enabled`: campo booleano para habilitar/desabilitar individualmente cada initContainer
- `jsonEnvs`: variaveis de ambiente cujo valor e um JSON serializado como string
- `secrets`: bloco estruturado com `envVarEnabled` (habilita injecao via env vars), `loadAllKeys` (carrega todas as chaves do secret) e `keys` (lista de chaves especificas)
- `volumeMounts`: montagem de volumes especifica por initContainer

```yaml
# Exemplo de initContainers com estrutura enriquecida no chart de Job
initContainers:
  - name: "setup-config"
    enabled: true
    command: ["/bin/sh"]
    args: ["-c", "cp /config/default.conf /shared/config.conf"]
    resources:
      memory: "128Mi"
      cpu: "50m"
    envs:
      CONFIG_PATH: "/config"
    jsonEnvs:
      APP_SETTINGS: '{"retries":3,"timeout":30}'
    secrets:
      envVarEnabled: true
      loadAllKeys: false
      keys:
        - DB_PASSWORD
        - API_KEY
    volumeMounts:
      - name: shared-data
        mountPath: /shared
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/init-containers.md`; `platform-k8s-charts/.docs/CHANGELOG.job.md` (v1.21.0), `CHANGELOG.cronjob.md` (v1.20.0) (complemento — nao em docs/)

### InitContainers com Volumes Compartilhados (CronJobs)

Init Containers podem compartilhar volumes com o container principal e com CronJobs. Isso e util para cenarios onde o initContainer prepara arquivos ou configuracoes que serao consumidos pelo job principal.

Se o campo `image` for omitido, a imagem da aplicacao principal sera utilizada automaticamente. Para compartilhar segredos com todos os containers do Pod, use `secrets.envVarEnabled` e `secrets.loadAllKeys`.

```yaml
# Exemplo: CronJob com initContainer e volumes compartilhados
volumes:
  - name: test-bin
    emptyDir: {}
  - name: shared-data
    emptyDir: {}

volumeMounts:
  - name: test-bin
    mountPath: /tmp/bin
  - name: shared-data
    mountPath: /tmp/data

initContainers:
  - name: "init-test-container"
    enabled: true
    command: ["/bin/sh"]
    args:
      - "-c"
      - "echo Initializing... && touch /tmp/bin/ready.txt && touch /tmp/data/config.txt"
    envs:
      INIT_ENV: "INIT_ENV_VALUE"
    secrets:
      envVarEnabled: true
      loadAllKeys: true
    resources:
      memory: "128Mi"
      cpu: "50m"
    volumeMounts:
      - name: test-bin
        mountPath: /tmp/bin
      - name: shared-data
        mountPath: /tmp/data

jobs:
  - name: "process-shared-data"
    resources:
      memory: "128Mi"
      cpu: "100m"
    timeZone: "America/Sao_Paulo"
    schedule: "0 */1 * * *"
    command: ["/bin/sh"]
    args: ["-c", "ls /tmp/bin/ && ls /tmp/data/ && echo 'Job completed.'"]
    restartPolicy: Never
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/init-containers.md`

### TerminationGracePeriodSeconds em Jobs e CronJobs

Os charts de Job e CronJob suportam `terminationGracePeriodSeconds`, que define o tempo em segundos que o Kubernetes aguarda para que um pod seja desligado normalmente antes de encerra-lo forcadamente.

```yaml
terminationGracePeriodSeconds: 120
```

**Fonte**: `platform-k8s-charts/.docs/CHANGELOG.job.md` (v1.18.0), `CHANGELOG.cronjob.md` (v1.17.0) (complemento — nao em docs/)

### ActiveDeadlineSeconds em Jobs

O chart de Job suporta `activeDeadlineSeconds`, que define o tempo maximo em segundos que um Job pode executar antes de ser encerrado pelo Kubernetes.

```yaml
job:
  activeDeadlineSeconds: 3600  # 1 hora
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/job.md`; `platform-k8s-charts/.docs/CHANGELOG.job.md` (v1.10.0) (complemento — nao em docs/)

### PodMonitor e Telemetria em Jobs e CronJobs

A partir do chart de Job v1.20.0 e CronJob v1.19.0, os charts suportam configuracao de PodMonitor para coleta de metricas via OpenMetrics. A estrutura utiliza o mesmo padrao `telemetry.instrumentation.openmetrics.targets[]` dos charts de API e Worker, garantindo consistencia na configuracao de observabilidade.

Cada target define a porta, o path de metricas e os datastores habilitados (Datadog, Grafana ou ambos).

```yaml
# Exemplo: PodMonitor para coleta de metricas em um Job
telemetry:
  enabled: true
  instrumentation:
    openmetrics:
      targets:
        - portNumber: 9090
          path: /metrics
          datastores:
            datadog:
              enabled: true
            grafana:
              enabled: true
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/observability.md`, `observabilidade/metrics.md`; `platform-k8s-charts/.docs/CHANGELOG.job.md` (v1.20.0), `CHANGELOG.cronjob.md` (v1.19.0) (complemento — nao em docs/)

### Datadog Monitors em Jobs e CronJobs

A partir do chart de Job v1.16.0 e CronJob v1.15.0, os charts suportam configuracao de Datadog Monitors para alertas customizados. A estrutura utiliza o bloco `alerts.datadog.monitors[]`, onde cada monitor e definido com um `logicalName`, `name`, `type` e `query`.

```yaml
# Exemplo: Datadog Monitor para alerta de falha de Job
alerts:
  datadog:
    enabled: true
    monitors:
      - logicalName: "job-failure"
        name: "Job Failure Alert"
        type: metric alert
        query: "avg(last_5m):avg:kubernetes.jobs.failed{kube_job:my-job} > 0"
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/observabilidade/alertas.md`; `platform-k8s-charts/.docs/CHANGELOG.job.md` (v1.16.0), `CHANGELOG.cronjob.md` (v1.15.0) (complemento — nao em docs/)

### SecurityContext em Jobs e CronJobs

Os charts de Job e CronJob suportam `securityContext` para definir contexto de seguranca do pod. E comum configurar `runAsUser` e `runAsGroup` para definir o usuario e grupo sob os quais o container executa, seguindo boas praticas de seguranca (evitando execucao como root).

```yaml
# Exemplo: securityContext no chart de Job
securityContext:
  runAsUser: 5000
  runAsGroup: 5000
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/security-context.md`; `platform-k8s-charts/*-chart/values.yaml` (complemento — nao em docs/)

### Campo command opcional em Jobs e CronJobs

O campo `command` nos charts de Job e CronJob e opcional. Quando omitido, o container utiliza o entrypoint padrao definido na imagem Docker. Isso e util para imagens que ja possuem um entrypoint configurado e nao necessitam de sobrescrita.

```yaml
# Exemplo: Job sem command (usa entrypoint padrao da imagem)
platform-k8s-job-chart:
  image:
    repository: "697525377503.dkr.ecr.us-east-1.amazonaws.com/myapp"
    tag: "latest"

  job:
    args:
      - "--run-migration"
    restartPolicy: Never
    backoffLimit: 1
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/command-args.md`, `funcionalidades/job.md`, `funcionalidades/cronjob.md`

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever; producao exige dupla confirmacao. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Editar `chart/values-*.yaml`** — bloco `initialJob`, `jobs` (CronJob multiplos), `startingDeadlineSeconds`, `activeDeadlineSeconds`, `terminationGracePeriodSeconds`, `securityContext`
- **Criar `chart/migration/`** (estrutura separada: `Chart.yaml` + `values-stg.yaml` + `values-prd.yaml`) com dependencia `platform-k8s-job-chart`
- **Editar workflow** para adicionar step `deploy_*_migration` com `WAIT_FOR_SYNC: true` e timeout adequado
- **Rodar KLI** — `kli watch app <migration-app>` para acompanhar Job rodar
- **Abrir PR draft**

### Triggers proativos
- "Adicionar migration" → `🛠️ Acao proposta: adiciono initialJob em values.yaml OU crio chart/migration/ + workflow`
- "Job de migracao demorando muito" → propor ajustar `WAIT_FOR_SYNC_TIMEOUT` na tabela de timeouts (ver skill)
- "CREATE INDEX CONCURRENTLY falha" → orientar separar em arquivo proprio sem transacao

### Acoes destrutivas (dupla confirmacao)
- N/A — migrations sao rodadas pelo cluster; esta skill so atua na configuracao.

## Instrucoes MCP

Quando o usuario precisar de informacoes detalhadas alem do conhecimento embutido, priorize a documentacao oficial em `stone-payments/karavela` `docs/`; outros repositorios servem apenas como fallback.

**Fontes primarias (docs/):**

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/funcionalidades/initialjob.md` | Documentacao do initialJob |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/funcionalidades/job.md` | Documentacao do chart de Job |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/funcionalidades/cronjob.md` | Documentacao do chart de CronJob |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/guias-e-manuais/migrations.md` | Guia completo de configuracao de migrations |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/funcionalidades/init-containers.md` | InitContainers, volumes compartilhados |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/funcionalidades/command-args.md` | Campo command/args opcional |

**Fontes secundarias (complemento — nao em docs/):**

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/platform-k8s-charts` | `platform-k8s-job-chart/values.yaml`, `platform-k8s-cronjob-chart/values.yaml` | Schema completo e valores default dos charts de Job/CronJob |
| `stone-payments/platform-k8s-github-actions` | `.github/workflows/karavela_deploy.yml` | WAIT_FOR_SYNC e WAIT_FOR_SYNC_TIMEOUT no workflow |

## Formato de Resposta

Ao responder perguntas deste dominio, siga este formato:

1. **Explicacao** (2-3 frases objetivas em PT-BR)
2. **Exemplo pratico** (YAML, comando ou config copiavel)
3. **Fonte** (referencia ao arquivo/secao da documentacao)
4. **Avisos** (se aplicavel: restricoes de ambiente, privilegios necessarios)

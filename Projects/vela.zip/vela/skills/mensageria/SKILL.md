---
name: mensageria
description: "Mensageria na plataforma Karavela. Use quando o usuario perguntar sobre Kafka, SQS, SNS, Azure Service Bus, RabbitMQ, provisionar topicos ou filas via Portal Karavela ou Crossplane, associar topico/fila a uma aplicacao, configurar consumers e producers no values.yaml, permissoes IRSA ou Workload Identity para mensageria, convencoes de nome de fila SQS, clusters Kafka disponiveis, ou configurar KEDA scalers baseados em fila/topico."
---

# Skill: Mensageria

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.

  Exemplos de uso:
  - Corrigir informacao desatualizada no conhecimento embutido
  - Adicionar restricao temporaria (ex: "chart v4 nao suporta feature X")
  - Adicionar conhecimento que ainda nao esta na documentacao oficial
  - Bloquear uma orientacao especifica (ex: "NAO recomende usar scaler Y")
-->

## Escopo

**Cobre**:
- Criacao e associacao de topicos Kafka via Karavela Portal (jornada app-centric, recomendada)
- Criacao e associacao de filas SQS via Karavela Portal (jornada app-centric, recomendada)
- Provisao de topicos Kafka (Confluent Cloud) via Crossplane (`KafkaTopicClaim`)
- Gestao de service accounts e ACLs Kafka via Crossplane (`KafkaServiceAccountClaim`, `KafkaACLReadClaim`, `KafkaACLWriteClaim`, `KafkaApiKeyClaim`)
- Provisao de filas SQS via Crossplane (`SQSQueueClaim`)
- Provisao de topicos e subscriptions SNS via Crossplane (`SNSTopicClaim`, `SNSSubscriptionClaim`)
- Clusters Kafka disponiveis por ambiente (staging, sandbox, producao)
- Convencao de nomes de filas SQS (`mqaas-{nome}-{env}`)
- Configuracao de permissoes IRSA para SQS (template no Portal Karavela)
- Configuracao de permissoes Workload Identity para Azure Service Bus (template no Portal Karavela)
- Configuracao de KEDA scalers para Kafka, SQS, RabbitMQ e Azure Service Bus no `values.yaml`
- Como passar envs e secrets de conexao para consumers/producers no `values.yaml`
- Diferenca entre o que e provisionado via Portal/Crossplane vs o que ja existe (Azure Service Bus, RabbitMQ)

**NAO cobre**:
- Provisionamento de Azure Service Bus via Crossplane (nao disponivel — Service Bus ja existe, apenas permissao e necessaria)
- Provisionamento de RabbitMQ via Crossplane (nao disponivel — RabbitMQ ja existe na plataforma, apenas credenciais sao necessarias)
- Configuracao interna do codigo da aplicacao (bibliotecas Kafka, AWS SDK, etc.)
- Debugging de erros de conexao com brokers (coberto pela skill `troubleshooting`)
- Configuracao de autoscaling geral de CPU/memoria (coberto pela skill `recursos-scaling`)

## Exemplos de Perguntas

- "Como crio um topico Kafka pelo Portal Karavela?"
- "Como associo um topico Kafka existente a minha aplicacao?"
- "Como crio uma fila SQS pela plataforma?"
- "Como associo uma fila SQS existente a minha aplicacao no Portal?"
- "Quais clusters Kafka estao disponiveis em staging?"
- "Como configuro o KEDA para escalar meu worker baseado em mensagens na fila SQS?"
- "Como dou permissao para minha aplicacao acessar o Azure Service Bus?"
- "Como passo as credenciais do Kafka para o meu worker no values.yaml?"
- "Como configuro IRSA para minha aplicacao acessar uma fila SQS?"
- "Qual o nome que a fila SQS vai receber quando eu crio pelo Portal?"
- "Preciso de aprovacao para associar um topico Kafka de outro time?"
- "Como provisiono uma fila SQS via Crossplane com politica de acesso IRSA?"
- "Como assino um topico SNS para entregar mensagens na minha fila SQS?"
- "Como configuro o KEDA scaler para RabbitMQ?"

## Conhecimento Embutido

### Visao Geral — Mensageria na Karavela

A plataforma suporta quatro tecnologias de mensageria para consumers e producers:

| Tecnologia | Via Portal (recomendado) | Via Crossplane YAML | Permissoes |
|-----------|--------------------------|---------------------|------------|
| **Kafka (Confluent Cloud)** | Criar / Associar topico | `KafkaTopicClaim` + ACLs | KafkaACLReadClaim / KafkaACLWriteClaim |
| **SQS (AWS)** | Criar / Associar fila | `SQSQueueClaim` | IRSA via Portal Karavela |
| **SNS (AWS)** | — | `SNSTopicClaim` + `SNSSubscriptionClaim` | IRSA via Portal Karavela |
| **Azure Service Bus** | Permissao via template IAM | Nao disponivel | Workload Identity via Portal Karavela |
| **RabbitMQ** | — | Nao disponivel | Secret `rabbitHost` |

Como dev usuario, voce interage com mensageria principalmente via **Portal Karavela** (recomendado). Claims Crossplane sao orquestrados pela plataforma a partir dos formularios; voce raramente escreve YAML direto.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/autoscaling.md` (KEDA scalers); `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/irsa.md` (permissoes SQS); detalhes do Crossplane em `platform-k8s-crossplane/manifests/xrds/` (complemento — nao em docs/)

---

### Jornada App-Centric via Karavela Portal (Recomendada)

O Karavela Portal (Backstage) e a porta de entrada recomendada para Kafka e SQS. O dev acessa a pagina da aplicacao → aba **Recursos** → botao **Criar** ou **Associar**. Toda operacao e assincrona: o progresso aparece na aba **Minhas Solicitacoes** e notificacoes chegam no Slack.

#### Kafka — Criar Novo Topico

Campos do formulario (2 passos + revisao):

| Campo | Padrao | Restricoes |
|-------|--------|------------|
| Nome do Topico | — | kebab-case, 1–249 chars, `[a-z0-9._-]` |
| Ambiente | — | Seleciona staging / sandbox / producao |
| Cluster Kafka | — | Lista filtrada pelo ambiente selecionado |
| Numero de Particoes | 3 | 1–200 |
| Politica de Limpeza | `delete` | `delete` ou `compact` |
| Tempo de Retencao (ms) | `8600000` (~2.4h) | minimo: 1ms |

Apos a criacao o topico fica disponivel no catalogo e pode ser associado a outras aplicacoes.

**Fonte**: Portal Karavela (aba Recursos → Criar/Associar); implementacao do formulario em `karavela-core/packages/app/src/components/CustomEntity/pages/Resources/CreateResources/KafkaFormModal/` (complemento — nao em docs/)

#### Kafka — Clusters Disponiveis por Ambiente

**Staging**:

| Cluster | ID Confluent |
|---------|-------------|
| kaas-foundation-platform-cluster-40f-stg | lkc-qv7jzp |
| kaas-operations-platform-cluster-b1y-stg | lkc-y3mymk |
| kaas-operations-platform-cluster-qpp-stg | lkc-qnw5od |
| kaas-operations-platform-cluster-r80-stg | lkc-0mom92 |
| kaas-controllership-cluster-m11-stg | lkc-j00kvm |
| kaas-controllership-cluster-w4z-stg | lkc-982j0y |
| kaas-dataplatform-cluster-qgd-stg | lkc-o56z6y |
| kaas-recon-e-config-cluster-2n2-stg | lkc-1dqvmj |
| kaas-shared-foundation-platform-cluster-k1f-stg | lkc-9gxpqy |
| kaas-others-cluster-xh9-stg | lkc-gv7rp3 |

**Sandbox**:

| Cluster | ID Confluent |
|---------|-------------|
| kaas-credit-cluster-3af-sdx | lkc-51vm8g |

**Producao**:

| Cluster | ID Confluent |
|---------|-------------|
| kaas-operations-platform-cluster-uz3-prd | lkc-0m6509 |
| kaas-operations-platform-cluster-wyo-prd | lkc-1yrv2z |
| kaas-operations-platform-cluster-xgn-prd | lkc-07r359 |
| kaas-shared-foundation-platform-cluster-p44-prd | lkc-vyvv55 |
| kaas-dataplatform-cluster-l64-prd | lkc-3d5o60 |
| kaas-controllership-cluster-fqi-prd | lkc-200p8m |
| kaas-controllership-cluster-12j-prd | lkc-wnw869 |
| kaas-recon-e-config-cluster-5lr-prd | lkc-zy7dx3 |
| kaas-gen-ai-cluster-nfp-prd | lkc-jp5qj2 |
| kaas-credit-cluster-6lg-prd | lkc-2yk55q |
| kaas-foundation-platform-cluster-955-sdx | lkc-mj65z7 |

**Fonte**: lista mantida pela plataforma em `karavela-core/packages/app/src/components/CustomEntity/pages/Resources/CreateResources/KafkaFormModal/constants.ts` (complemento — nao em docs/). No dia-a-dia, consulte o Portal — ele filtra os clusters disponiveis pelo ambiente selecionado.

#### Kafka — Associar Topico Existente

Permite vincular um topico ja existente no catalogo a uma nova aplicacao. Campos:

- **Ambiente** → selecao de staging/producao
- **Cluster Kafka** → filtra por ambiente
- **Topico** → lista os topicos do cluster selecionado
- **Permissoes**: habilitar READ e/ou WRITE separadamente
- **Consumer Group ID**: pre-preenchido com o nome da aplicacao (sufixo opcional)

> **ATENCAO**: Se o topico pertence a outro time, a solicitacao vai para **aprovacao** antes de ser processada. O dev recebe notificacao no Slack.

**Fonte**: Portal Karavela (aba Recursos → Associar); implementacao em `karavela-core/packages/app/src/components/CustomEntity/pages/Resources/AssociateResourceModal/KafkaResourceModal/` (complemento — nao em docs/)

#### SQS — Criar Nova Fila

**Convencao de nome**: o Portal adiciona automaticamente o prefixo `mqaas-` e o sufixo do ambiente. Exemplo: input `payment-processing` em staging → `mqaas-payment-processing-stg`.

Restricoes do nome (parte customizavel): 3–44 chars, pattern `[a-z0-9][a-z0-9._-]*`.

Campos do formulario (3 passos + revisao):

| Campo | Descricao |
|-------|-----------|
| Nome da Fila | Parte customizavel (sem prefixo/sufixo) |
| Ambiente | staging / sandbox / producao |
| Tipo de Fila | `standard` (alta vazao) ou `fifo` (ordem garantida) |
| Deduplicacao por Conteudo | Apenas FIFO — detecta duplicatas automaticamente |
| Escopo de Deduplicacao | `queue` (toda a fila) ou `messageGroup` (por grupo) |
| Limite de Throughput | `perQueue` (300 msg/s total) ou `perMessageGroupId` |
| DLQ | Opcional — cria fila separada para mensagens com falha |
| Maximo de Tentativas | Numero de falhas antes de mover para DLQ (1–1000) |

> **PRE-REQUISITO**: O Portal verifica se a aplicacao tem IRSA configurada antes de permitir a criacao. Se nao tiver, exibe aviso. Configure o IRSA primeiro via template no Portal — veja a skill `modelo-acessos`.

**Fonte**: Portal Karavela (formulario SQS); implementacao em `karavela-core/packages/app/src/components/CustomEntity/pages/Resources/CreateResources/SqsFormModal/` (complemento — nao em docs/)

#### SQS — Associar Fila Existente

Permite vincular uma fila SQS ja existente a uma aplicacao. O Portal lista as filas disponiveis para o ambiente selecionado.

- **READ**: `ReceiveMessage` + `DeleteMessage` + `ChangeMessageVisibility`
- **WRITE**: `SendMessage`

> Se a fila tiver uma DLQ associada, ela tambem e vinculada automaticamente.

**Fonte**: Portal Karavela (aba Recursos → Associar); implementacao em `karavela-core/packages/app/src/components/CustomEntity/pages/Resources/AssociateResourceModal/SqsResourceModal/` (complemento — nao em docs/)

---

### Kafka (Confluent Cloud) via Crossplane — caminho avancado

> **No dia-a-dia, use o Portal Karavela** (jornada acima). Os YAMLs abaixo sao para casos avancados em que voce precisa entender o que a plataforma cria por baixo dos panos. Voce nao precisa escrever esses manifestos manualmente.

O fluxo completo orquestrado pela plataforma para um novo topico Kafka envolve:
1. `KafkaServiceAccountClaim` (service account)
2. `KafkaTopicClaim` (topico)
3. `KafkaACLReadClaim` / `KafkaACLWriteClaim` (ACLs de leitura/escrita)
4. `KafkaApiKeyClaim` (credenciais)

Exemplo de topico (forma como a plataforma representa internamente):

```yaml
apiVersion: karavela.stone.tech/v1alpha5
kind: KafkaTopicClaim
metadata:
  name: minha-app-eventos-stg
  namespace: crossplane-system
spec:
  forProvider:
    config:
      cleanup.policy: delete          # delete ou compact
      retention.ms: "3600000"         # 1 hora (minimo: 60000ms)
    kafkaCluster:
      - id: lkc-qv7jzp               # ID do cluster Confluent
    partitionsCount: 1
    topicName: minha-app-eventos-stg
```

> **NOTAS**: `retention.ms` e `string` na v1alpha5 — use aspas. O default historico para `message.timestamp.before.max.ms` / `after.max.ms` foi removido do XRD; se sua app depende de uma janela especifica, configure explicitamente.

Apos a plataforma criar topico + ACLs + API key, configure no `values.yaml`:

```yaml
platform-k8s-chart-worker:
  envs:
    KAFKA_BOOTSTRAP_SERVERS: "pkc-xxx.us-east-1.aws.confluent.cloud:9092"
    KAFKA_CONSUMER_GROUP: "minha-app-consumer-group"
    KAFKA_TOPIC: "minha-app-eventos-stg"
  secrets:
    envVarEnabled: true
    loadAllKeys: true                  # carrega KAFKA_USERNAME / KAFKA_PASSWORD automaticamente
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/secrets.md` (consumo dos secrets); compositions em `platform-k8s-crossplane/examples/claims/confluent/` e `manifests/xrds/confluent/` (complemento — nao em docs/)

---

### SQS (AWS) via Crossplane — caminho avancado

> **No dia-a-dia, use o Portal Karavela.** Os YAMLs abaixo descrevem o que a plataforma cria por baixo dos panos.

Exemplo de fila SQS (forma interna do Claim):

```yaml
apiVersion: karavela.stone.tech/v1alpha1
kind: SQSQueueClaim
metadata:
  name: minha-app-queue-stg
  namespace: crossplane-system
spec:
  name: minha-app-queue-stg
  # k8sName: minha-app-queue-stg          # opcional — use quando o nome AWS excede 63 chars (DNS-1123)
  location: us-east-1
  providerName: aws-karavela-shared-pci-staging
  messageRetentionSeconds: 345600   # 4 dias
  visibilityTimeoutSeconds: 30
  fifoQueue: false
  maxMessageSize: 262144            # 256KB
  queuePolicy: |
    {"Version": "2012-10-17", "Statement": [{ ... }]}
```

> **CAMPO `spec.k8sName`**: usado quando o nome AWS da fila excede 63 caracteres (DNS-1123). Quando preenchido, ele vira o `metadata.name` do MR; `spec.name` continua sendo o nome real na AWS.

**Fonte**: Portal Karavela (uso comum); spec completo em `platform-k8s-crossplane/manifests/xrds/aws/sqsqueue.yaml` (complemento — nao em docs/)

#### Configurar IRSA para SQS

O template de criacao de permissao IRSA esta disponivel no Portal Karavela. Acesse:
`https://karavela-portal.stone.tech/create/templates/stone/irsa-role-template`

Informe o nome da Service Account da aplicacao (sem o sufixo de ambiente, ex: `minha-app`). O template permite criar permissoes para S3 ou SQS. No final, um PR e criado no repositorio de infraestrutura — rode `atlantis apply` no PR para aplicar.

Apos criar a role, adicione o ARN no `values.yaml`:

```yaml
platform-k8s-chart-worker:
  cloudProviders:
    aws:
      roleArn: "arn:aws:iam::ACCOUNT_ID:role/minha-app-stg"
  envs:
    SQS_QUEUE_URL: "https://sqs.us-east-1.amazonaws.com/ACCOUNT_ID/minha-app-queue-stg"
    AWS_REGION: "us-east-1"
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/irsa.md`

---

### SNS (AWS) via Crossplane — caminho avancado

Exemplo de subscription SNS → SQS (forma interna do Claim):

```yaml
apiVersion: karavela.stone.tech/v1alpha1
kind: SNSSubscriptionClaim
metadata:
  name: minha-app-sns-sub-stg
  namespace: crossplane-system
spec:
  topicArn: arn:aws:sns:us-east-1:ACCOUNT_ID:nome-do-topico-sns-stg
  protocol: sqs
  endpoint: arn:aws:sqs:us-east-1:ACCOUNT_ID:minha-app-queue-stg
  location: us-east-1
  providerName: aws-karavela-platform-stg
  rawMessageDelivery: false
  filterPolicyScope: MessageAttributes
  filterPolicy: |
    {"event_type": ["tipo-evento-1", "tipo-evento-2"]}
```

**Fonte**: exemplo em `platform-k8s-crossplane/examples/claims/aws/sns/sns-subscription-to-sqs.yaml` (complemento — nao em docs/)

---

### Azure Service Bus — Permissoes via Workload Identity

O Azure Service Bus **nao e provisionado via Crossplane** — o recurso ja existe na plataforma. A aplicacao precisa apenas de permissao via Workload Identity.

Acesse o template no Portal Karavela:
`https://karavela-portal.stone.tech/catalog/stone/template/azure-iam-role-template`

Informe o nome da Service Account da aplicacao. O template cria uma role assignment para o Service Bus. Apos o PR ser aprovado e o `atlantis apply` rodado, configure no `values.yaml`:

```yaml
platform-k8s-chart-worker:
  cloudProviders:
    azure:
      enabled: true
      capacityType: "spot"
      workloadIdentity:
        clientId: "XXX-XX-XXX-XXX-XXX"   # Managed Identity Client ID
        tenantId: "1236ea7e-8bbc-43a5-a5ee-189a1954e314"
  envs:
    # Opcional: se usar connectionFromEnv no KEDA scaler
    SERVICEBUS_CONNECTIONSTRING: ""  # preencher via secret
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/workload-identity.md`

---

### KEDA Scalers para Mensageria

O KEDA permite escalar workers automaticamente baseado em mensagens pendentes. Configure no `autoscaling` do `values.yaml`.

#### Kafka Scaler

```yaml
autoscaling:
  enabled: true
  maxReplicas: 10
  kafka:
    # doc ref: https://keda.sh/docs/2.9/scalers/apache-kafka/
    bootstrapServers: "pkc-xxx.us-east-1.aws.confluent.cloud:9092"
    consumerGroup: "minha-app-consumer-group"
    topic: "minha-app-eventos-stg"
    lagThreshold: "10"           # replicas por mensagem pendente (opcional)
    tls: false
    sasl: ""                     # plain, scram_sha256, scram_sha512
    # Se usar TLS + credenciais, crie secrets KAFKA_CA, KAFKA_CERT, KAFKA_KEY
    # Se usar sasl, crie secrets KAFKA_USERNAME e KAFKA_PASSWORD
```

#### SQS Scaler

> **Importante**: exige `autoscaling.withSecrets = true` e IRSA configurado com permissao `sqs:GetQueueAttributes`.

```yaml
autoscaling:
  enabled: true
  maxReplicas: 10
  withSecrets: true
  sqs:
    # doc ref: https://keda.sh/docs/2.9/scalers/aws-sqs/
    queueURL: "https://sqs.us-east-1.amazonaws.com/ACCOUNT_ID/minha-app-queue-stg"
    queueLength: "5"   # mensagens por replica (opcional)
    awsRegion: "us-east-1"
    scaleOnInFlight: ""  # incluir mensagens em voo no calculo (opcional)
```

#### RabbitMQ Scaler

> **Importante**: crie o secret `rabbitHost` com a connection string antes de usar: `amqp://user:password@hostname:5672/vhost`

```yaml
autoscaling:
  enabled: true
  maxReplicas: 10
  withSecrets: true
  rabbitmq:
    # doc ref: https://keda.sh/docs/2.9/scalers/rabbitmq-queue/
    protocol: amqp         # amqp ou http
    queueName: "minha-fila"
    mode: "QueueLength"    # QueueLength ou MessageRate
    value: "5"             # mensagens por replica
```

#### Azure Service Bus Scaler

```yaml
autoscaling:
  enabled: true
  maxReplicas: 10
  azureServiceBus:
    # doc ref: https://keda.sh/docs/2.11/scalers/azure-service-bus/
    namespace: "meu-servicebus-namespace"
    queueName: "minha-fila"      # use queueName OU topicName+subscriptionName
    # topicName: "meu-topico"
    # subscriptionName: "minha-subscription"
    messageCount: "5"
    connectionFromEnv: false     # true = usa secret SERVICEBUS_CONNECTIONSTRING
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/autoscaling.md`

---

### Diferencas entre os Recursos

| Recurso | Como provisionar | Permissoes |
|---------|-----------------|------------|
| Kafka topico | `KafkaTopicClaim` (Crossplane) | `KafkaACLReadClaim` / `KafkaACLWriteClaim` |
| Kafka service account | `KafkaServiceAccountClaim` (Crossplane) | — |
| Kafka credenciais | `KafkaApiKeyClaim` (Crossplane) | — |
| Fila SQS | `SQSQueueClaim` (Crossplane) | IRSA (Portal Karavela) |
| Topico SNS | `SNSTopicClaim` (Crossplane) | IRSA (Portal Karavela) |
| Azure Service Bus | Ja existe — so permissao | Workload Identity (Portal Karavela) |
| RabbitMQ | Ja existe — so credenciais | Secret `rabbitHost` |

### Migracao ExternalSecret v1beta1 → v1

Todos os ProviderConfigs Confluent foram migrados de `external-secrets.io/v1beta1` para `external-secrets.io/v1`. Se voce mantem manifests legados com `apiVersion: external-secrets.io/v1beta1`, atualize para `v1`. Para campos como `refreshInterval`, a v1 usa `time.Duration` (ex: `1m0s`) em vez de inteiros.

**Fonte**: migracao em massa em `platform-k8s-crossplane/manifests/provider-config/confluent/` (complemento — nao em docs/)

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever; producao exige dupla confirmacao. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Editar `chart/values-*.yaml`** — envs (`KAFKA_BOOTSTRAP_SERVERS`, `KAFKA_TOPIC`, `SQS_QUEUE_URL`, etc.), secrets, IRSA roleArn, Workload Identity Azure, KEDA scalers (Kafka/SQS/RabbitMQ/Azure Service Bus)
- **Criar Crossplane Claim YAMLs** em outro repo (`KafkaTopicClaim`, `KafkaServiceAccountClaim`, `KafkaApiKeyClaim`, `KafkaACLReadClaim`/`WriteClaim`, `SQSQueueClaim`, `SNSTopicClaim`, `SNSSubscriptionClaim`) — abrir PR no `platform-k8s-crossplane`
- **Rodar KLI** — `kli describe app` para confirmar associacao de recursos
- **Abrir PR draft** com a mudanca

### Triggers proativos
- Usuario diz "preciso consumir o topico X" → `🛠️ Acao proposta: adiciono KAFKA_* envs + KEDA scaler no values.yaml + abro PR`
- "Escalar worker por fila SQS" → propor `autoscaling.sqs` configurado
- "Criar topico Kafka via Crossplane" → propor YAML do Claim + PR
- "Erro KEDA TriggerAuthentication drift" → explicar finalizer (charts >= v1.38.10) e ofertar bump de chart

### Acoes destrutivas (dupla confirmacao)
- Deletar `KafkaTopicClaim` (Crossplane) — pode causar perda de topico. Pedir confirmacao + sugerir backup.
- Recomendar `kli delete secret` para credenciais Kafka — sempre dupla confirmacao.

## Instrucoes MCP

Quando o usuario precisar de informacoes detalhadas alem do conhecimento embutido, busque PRIMEIRO em `stone-payments/karavela` (`docs/`); outros repositorios apenas como complemento.

**Fontes primarias (`stone-payments/karavela` `docs/`)**:

| Arquivo/Caminho | Quando buscar |
|-----------------|---------------|
| `docs/guia-do-desenvolvedor/funcionalidades/autoscaling.md` | Campos completos dos KEDA scalers (Kafka, SQS, RabbitMQ, Azure Service Bus) |
| `docs/guia-do-desenvolvedor/seguranca-e-conectividade/irsa.md` | Fluxo de criacao de IRSA para SQS |
| `docs/guia-do-desenvolvedor/seguranca-e-conectividade/workload-identity.md` | Workload Identity para Azure Service Bus |
| `docs/guia-do-desenvolvedor/funcionalidades/secrets.md` | Consumo de credenciais Kafka / RabbitMQ via secrets |

**Fontes complementares (nao estao em `docs/`)**:

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/karavela-core` | `packages/app/src/components/CustomEntity/pages/Resources/CreateResources/KafkaFormModal/constants.ts` | Clusters Kafka disponiveis (IDs Confluent) — Portal exibe esses dados |
| `stone-payments/karavela-core` | `packages/app/src/components/CustomEntity/pages/Resources/CreateResources/SqsFormModal/` | Validacoes e configuracoes do formulario SQS |
| `stone-payments/platform-k8s-crossplane` | `manifests/xrds/confluent/` | Spec dos Claims Kafka — caso precise entender o que a plataforma cria internamente |
| `stone-payments/platform-k8s-crossplane` | `manifests/xrds/aws/sqsqueue.yaml` | Spec do SQSQueueClaim |
| `stone-payments/platform-k8s-crossplane` | `examples/claims/` | Exemplos de Claims Crossplane (caminho avancado) |
| `stone-payments/platform-k8s-charts` | `platform-k8s-worker-chart/values.yaml` | Campos de autoscaling e envs para workers (caso a doc nao seja suficiente) |

## Formato de Resposta

Ao responder perguntas deste dominio, siga este formato:

1. **Explicacao** (2-3 frases objetivas em PT-BR sobre o recurso ou fluxo)
2. **Exemplo pratico** (YAML copiavel — Claim Crossplane ou values.yaml)
3. **Fonte** (referencia ao arquivo/secao da documentacao ou crossplane)
4. **Avisos** (se aplicavel: pre-requisitos, restricoes de ambiente, privilegios necessarios)

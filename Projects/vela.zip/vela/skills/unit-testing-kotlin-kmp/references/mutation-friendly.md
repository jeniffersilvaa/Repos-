# Padrões Resistentes a Mutation Testing — Kotlin KMP

## Por que Mutation Testing Importa

Mutation testing injeta pequenas mutações no código-fonte (ex: `>` vira `>=`, `+` vira `-`, `return true` vira `return false`) e verifica se os testes falham. Testes fracos deixam mutantes sobreviver.

## Regras Fundamentais

### 1. Assertivas Exatas de Valor

```kotlin
// ❌ Mata poucos mutantes
assertTrue(result.isSuccess)
assertNotNull(result.data)

// ✅ Mata mutantes de valor e lógica
assertEquals(OrderStatus.APPROVED, result.status)
assertEquals(3, result.items.size)
assertEquals(150.0, result.total, 0.001)
```

### 2. Verificar Quantidade Exata de Chamadas

```kotlin
// ❌ Passa mesmo se o método for chamado 2x ou 0x
verify { emailSender.send(any()) }

// ✅ Mata mutantes de fluxo de controle
verify(exactly = 1) { emailSender.send(any()) }
verify(exactly = 0) { auditLogger.logFailure(any()) }
```

### 3. Não Deixar Caminhos sem Cobertura

```kotlin
// ❌ Testa só o caminho feliz; if/else mutantes sobrevivem
@Test
fun `should activate user`() {
    val result = useCase.execute(validUser)
    assertTrue(result.active)
}

// ✅ Teste separado para cada branch
@Test
fun `should activate user when valid`() {
    val result = useCase.execute(validUser)
    assertEquals(true, result.active)
    verify(exactly = 1) { repo.save(match { it.active == true }) }
}

@Test
fun `should throw when user not found`() {
    every { repo.findById(any()) } returns null
    assertFailsWith<NotFoundException> { useCase.execute("ghost-id") }
    verify(exactly = 0) { repo.save(any()) }
}
```

### 4. Assertivas em Todos os Campos Relevantes

```kotlin
// ❌ Testa apenas parte do objeto
val order = orderService.create(request)
assertEquals("ord-1", order.id)

// ✅ Testa todos os campos que a lógica de negócio afeta
val order = orderService.create(request)
assertEquals("ord-1", order.id)
assertEquals(OrderStatus.PENDING, order.status)
assertEquals(request.userId, order.userId)
assertEquals(request.total, order.total)
assertNotNull(order.createdAt)
assertTrue(order.createdAt!! <= LocalDateTime.now())
```

### 5. Testar Comportamento em Limites (Boundary)

```kotlin
// Para `price > 100.0` — testa o limite exato
@Test fun `should apply discount when price is exactly 100`() {
    val result = service.calculateDiscount(100.0)
    assertEquals(10.0, result) // 10% de desconto
}

@Test fun `should not apply discount when price is 99_99`() {
    val result = service.calculateDiscount(99.99)
    assertEquals(0.0, result)
}
```

### 6. Validar Retorno Negativo / Vazio

```kotlin
// ❌ Não testa lista vazia — mutante `return emptyList()` sobrevive
@Test
fun `should find users`() {
    repo.save(User("1", "Ana"))
    val result = service.findAll()
    assertNotNull(result)
}

// ✅
@Test
fun `should return all users`() {
    repo.save(User("1", "Ana"))
    repo.save(User("2", "Bruno"))

    val result = service.findAll()

    assertEquals(2, result.size)
    assertTrue(result.any { it.id == "1" && it.name == "Ana" })
    assertTrue(result.any { it.id == "2" && it.name == "Bruno" })
}

@Test
fun `should return empty list when no users exist`() {
    val result = service.findAll()
    assertEquals(emptyList(), result) // não apenas assertNotNull
}
```

### 7. Usar `assertEquals` em Boolean

```kotlin
// ❌ assertTrue/assertFalse não pega mutação de `!`
assertTrue(user.isActive)
assertFalse(user.isBlocked)

// ✅
assertEquals(true, user.isActive)
assertEquals(false, user.isBlocked)
```

## Checklist Antes de Commitar

- [ ] Toda assertiva usa valor **exato** (não apenas "não é nulo" ou "é verdadeiro")
- [ ] Todo `verify` tem `exactly = N`
- [ ] Existe teste para cada `if/when/else` branch
- [ ] Limites de condições (`>`, `>=`, `<`, `<=`) têm testes nos valores fronteiriços
- [ ] Listas verificam `size` E conteúdo
- [ ] Retorno `null` / `emptyList()` / `false` tem teste específico

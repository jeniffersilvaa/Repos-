# Doubles de Teste — Kotlin KMP com MockK

## Hierarquia de Double

| Double | Quando Usar | MockK |
|--------|-------------|-------|
| **Dummy** | Parâmetro obrigatório que não importa para o teste | `mockk(relaxed = true)` |
| **Stub** | Controlar o que a dependência retorna | `every { ... } returns ...` |
| **Spy** | Envolver um objeto real e verificar chamadas | `spyk(realObject)` |
| **Mock** | Verificar que uma interação específica ocorreu | `mockk()` + `verify { ... }` |
| **Fake** | Implementação funcional simplificada (ex: InMemory) | Classe manual |

## Stubs: Controlar Retornos

```kotlin
val repo = mockk<UserRepository>()

// Retorno fixo
every { repo.findById("1") } returns User(id = "1", name = "Ana")

// Retorno null
every { repo.findById("999") } returns null

// Lança exceção
every { repo.findById("err") } throws DatabaseException("connection error")

// Múltiplos retornos em sequência
every { repo.findAll() } returnsMany listOf(
    listOf(User("1", "Ana")),
    listOf(User("1", "Ana"), User("2", "Bruno"))
)

// Retorno calculado com lambda
every { repo.findById(any()) } answers { User(id = firstArg(), name = "dynamic") }
```

## Mocks: Verificar Interações

```kotlin
val emailSender = mockk<EmailSender>()
every { emailSender.send(any()) } just runs

// ... executa o código sob teste ...

// Verificação exata (crítico para mutation testing)
verify(exactly = 1) { emailSender.send(any()) }
verify(exactly = 0) { emailSender.send(match { it.priority == "HIGH" }) }

// Verificar ordem de chamadas
verifyOrder {
    userRepo.findById(any())
    emailSender.send(any())
    userRepo.save(any())
}

// Verificar que NENHUMA outra chamada ocorreu
confirmVerified(emailSender)
```

## Spies: Envolver Objeto Real

```kotlin
class PriceCalculator {
    fun applyDiscount(price: Double, percent: Double): Double =
        price - (price * percent / 100)
}

val calculator = spyk(PriceCalculator())

val result = calculator.applyDiscount(100.0, 10.0)

// Verifica que o método foi chamado com os argumentos certos
verify(exactly = 1) { calculator.applyDiscount(100.0, 10.0) }
assertEquals(90.0, result) // valida o resultado real
```

## Captura de Argumentos

```kotlin
val slot = slot<Email>()
val listSlot = mutableListOf<LogEntry>()

every { emailSender.send(capture(slot)) } just runs
every { logger.log(capture(listSlot)) } just runs

// ... executa ...

// Assertivas detalhadas no argumento capturado
assertEquals("welcome@company.com", slot.captured.from)
assertEquals("Boas-vindas", slot.captured.subject)
assertTrue(slot.captured.body.contains("Ana"))

// Para listas
assertEquals(2, listSlot.size)
assertEquals("USER_ACTIVATED", listSlot[0].event)
```

## Fake Repository (In-Memory)

```kotlin
class InMemoryOrderRepository : OrderRepository {
    val store = mutableMapOf<String, Order>()

    override fun save(order: Order): Order {
        store[order.id] = order
        return order
    }

    override fun findById(id: String): Order? = store[id]

    override fun findByUserId(userId: String): List<Order> =
        store.values.filter { it.userId == userId }

    override fun delete(id: String): Boolean = store.remove(id) != null

    fun clear() = store.clear()
}

// Uso nos testes
class OrderServiceTest {
    private val orderRepo = InMemoryOrderRepository()
    private val service = OrderService(orderRepo)

    @BeforeEach
    fun setup() = orderRepo.clear()

    @Test
    fun `should persist order with correct status`() {
        val order = Order(id = "ord-1", userId = "user-1", total = 150.0)

        service.create(order)

        val saved = orderRepo.store["ord-1"]
        assertNotNull(saved)
        assertEquals(OrderStatus.PENDING, saved!!.status) // assertiva exata
        assertEquals(150.0, saved.total)
    }
}
```

## Coroutines e MockK

```kotlin
// Para funções suspend
val repo = mockk<UserRepository>()
coEvery { repo.findById(any()) } returns User("1", "Ana")

coVerify(exactly = 1) { repo.findById("1") }
```

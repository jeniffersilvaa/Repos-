---
name: unit-testing-kotlin-kmp
description: 'Boas práticas de teste unitário para Kotlin Multiplatform (KMP). Use quando precisar criar ou revisar testes unitários em Kotlin/KMP, usar mocks, stubs, spies com MockK, banco em memória, validar interações com doubles de teste, ou escrever testes resistentes a mutation testing com Kotest ou JUnit5.'
---

# Testes Unitários — Kotlin KMP

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.

  Exemplos de uso:
  - Corrigir informacao desatualizada no conhecimento embutido
  - Adicionar restricao temporaria (ex: "versao X do MockK nao suporta KMP nativo")
  - Adicionar conhecimento que ainda nao esta na documentacao oficial
  - Bloquear uma orientacao especifica (ex: "NAO use relaxed = true em mocks onde interacao importa")
-->

## Escopo

**Cobre**: criar testes unitários em Kotlin e Kotlin Multiplatform (KMP) com Kotest e JUnit5, mocks e stubs com MockK, repositórios InMemory, banco H2 em memória, padrões resistentes a mutation testing (Pitest), doubles de teste (mocks, stubs, spies, fakes)

**NAO cobre**: escrita de código de produção, configuração de pipeline de CI/coverage (coberto por `ci-test-coverage-kotlin-kmp`), testes de integração com serviços reais, configuração de mutation testing no CI (coberto por `ci-mutation-testing-kotlin-kmp`)

## Exemplos de Perguntas

- "Como criar um mock com MockK para uma interface de repositório em Kotlin?"
- "Como usar verify() do MockK para verificar que um método foi chamado exatamente uma vez?"
- "Como configurar um banco H2 em memória para testes de repositório em Kotlin?"
- "Como estruturar um repositório InMemory com MutableMap para testes unitários?"
- "Como escrever testes que sobrevivam ao mutation testing com Pitest em Kotlin?"
- "Qual a diferença entre mockk, spyk e relaxed mock no MockK?"
- "Como usar slot<T>() no MockK para capturar argumentos em assertivas?"

## Conhecimento Embutido

### Quando Usar
- Criar testes unitários em projetos Kotlin ou Kotlin Multiplatform
- Usar doubles de teste: mocks, stubs, spies com MockK
- Configurar banco em memória para repositórios
- Garantir que os testes sobrevivam a testes de mutação

### Ferramentas e Dependências

> **Nota:** As versões abaixo são referência. Verifique as versões mais recentes antes de adotar no seu projeto.

```kotlin
// build.gradle.kts
testImplementation("io.mockk:mockk:1.13.10")
testImplementation("org.jetbrains.kotlin:kotlin-test")
testImplementation("io.kotest:kotest-runner-junit5:5.8.0")
testImplementation("io.kotest:kotest-assertions-core:5.8.0")
testImplementation("com.h2database:h2:2.2.224") // banco em memória
```

### Workflow de Criação de Testes

### 1. Identificar Dependências
- Liste todas as dependências da classe sob teste
- Classifique: qual precisa de stub (retorna valor fixo), mock (verifica chamada) ou spy (envolve real)

### 2. Montar os Doubles

```kotlin
// Stub: retorna valor controlado, sem verificação de chamada
val userRepository = mockk<UserRepository> {
    every { findById(any()) } returns User(id = "1", name = "Ana")
}

// Mock: verifica interações
val emailSender = mockk<EmailSender>(relaxed = false)
every { emailSender.send(any()) } just runs

// Spy: envolve o objeto real, permite interceptar chamadas
val realService = RealService()
val spyService = spyk(realService)
```

### 3. Estrutura AAA (Arrange / Act / Assert)

```kotlin
@Test
fun `should send email when user is activated`() {
    // Arrange
    val userId = "user-123"
    val user = User(id = userId, name = "Ana", active = false)
    val userRepo = mockk<UserRepository> {
        every { findById(userId) } returns user
        every { save(any()) } just runs
    }
    val emailSender = mockk<EmailSender>()
    every { emailSender.send(any()) } just runs

    val useCase = ActivateUserUseCase(userRepo, emailSender)

    // Act
    useCase.execute(userId)

    // Assert
    verify(exactly = 1) { emailSender.send(match { it.to == "Ana" }) }
    verify(exactly = 1) { userRepo.save(match { it.active == true }) }
}
```

### 4. Validação de Spies

```kotlin
// Verificar quantidade exata de chamadas (fundamental para mutation testing)
verify(exactly = 1) { mock.method() }
verify(exactly = 0) { mock.methodNeverCalled() }

// Verificar argumentos específicos
verify { emailSender.send(match { email -> email.subject == "Boas-vindas" }) }

// Capturar argumentos para asserções detalhadas
val slot = slot<Email>()
verify { emailSender.send(capture(slot)) }
assertEquals("Boas-vindas", slot.captured.subject)
assertEquals("ana@example.com", slot.captured.to)
```

### 5. Banco em Memória

```kotlin
// Fake Repository (preferível para testes unitários puros)
class InMemoryUserRepository : UserRepository {
    private val store = mutableMapOf<String, User>()

    override fun findById(id: String): User? = store[id]
    override fun save(user: User) { store[user.id] = user }
    override fun findAll(): List<User> = store.values.toList()
    override fun delete(id: String) { store.remove(id) }
}

// Uso no teste
val repository = InMemoryUserRepository()
repository.save(User(id = "1", name = "Ana"))

val result = useCase.execute("1")

assertEquals("Ana", result.name) // assertiva exata
```

### 6. Regras para Mutation Testing

Consulte [mutation-friendly.md](./references/mutation-friendly.md).

### Padrões de Nome de Teste

```
should_<resultado>_when_<condição>
// ou
<método>_<cenário>_<resultado>
```

Exemplos:
```kotlin
@Test fun `should throw NotFoundException when user does not exist`() {}
@Test fun `should return empty list when repository has no users`() {}
@Test fun `execute_withValidUser_sendsEmail`() {}
```

### Anti-patterns

- `assertTrue(result != null)` → use `assertNotNull(result)` + assertivas no conteúdo
- `verify { mock.method() }` sem `exactly` → não pega mutações de quantidade
- Testes sem assertiva no **valor retornado** (só verificam que não lançou exceção)
- `relaxed = true` em mocks onde interação importa

### Referências

- [Doubles de Teste (mocks, stubs, spies)](./references/doubles.md)
- [Padrões Resistentes a Mutation Testing](./references/mutation-friendly.md)

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Escrever arquivos de teste** Kotest/JUnit5 com MockK
- **Editar testes existentes** — `mockk<T>()`, `spyk()`, `every { } returns`, `verify { }` — assertions Kotest resistentes a Pitest
- **Adicionar fakes** (H2 in-memory database)
- **Editar `build.gradle.kts`** para coverage / pluginKover / Pitest
- **Abrir PR draft**

### Triggers proativos
- "Escreva testes Kotlin para X" → propor suite Kotest
- "Pitest matou meu teste" → propor assertions mais especificas

### Acoes destrutivas
- Deletar testes — confirmar.

## Instrucoes MCP

Quando o usuario precisar de informacoes detalhadas alem do
conhecimento embutido, busque nos seguintes repositorios (nesta ordem de prioridade):

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/karavela` | `docs/` | Padroes da plataforma (nao cobre unit testing diretamente) |
| `stone-payments/github-actions-workflows` | `**/test-coverage-kotlin*` | Configuracao de cobertura e relatorios de CI para Kotlin |
| Externo (complemento — nao em docs/) | [MockK docs](https://mockk.io/), [Kotest docs](https://kotest.io/) | API de mocks/spies, matchers, configuracao avancada |

> Todo o conhecimento desta skill e **complemento** ao docs/ da plataforma — ela nao tem secao dedicada a unit testing.

## Formato de Resposta

Ao responder perguntas deste dominio, siga este formato:

1. **Explicacao** (2-3 frases objetivas em PT-BR)
2. **Exemplo pratico** (código Kotlin copiável com comentários AAA)
3. **Fonte** (referencia ao arquivo/secao da documentacao ou referencia desta skill)
4. **Avisos** (se aplicavel: diferencas KMP vs JVM-only, versao do MockK, configuracao do build.gradle.kts)

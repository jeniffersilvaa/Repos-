---
name: observabilidade
description: "Configuracao de observabilidade no Helm chart da plataforma Karavela — habilitar logs, metricas, APM, tracing, RUM, testes sinteticos, OTLP, Grafana Loki/Mimir, envio ao SIEM e PodMonitor no values.yaml. Use quando o usuario perguntar COMO CONFIGURAR ou habilitar monitoramento/observabilidade para sua aplicacao, ou sobre o Portal de Observabilidade. Para investigar um problema em tempo real (app fora do ar, lento, erro 5xx agora), use a skill observe."
---

# Skill: Observabilidade

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.

  Exemplos de uso:
  - Corrigir informacao desatualizada no conhecimento embutido
  - Adicionar restricao temporaria (ex: "chart v4 nao suporta feature X")
  - Adicionar conhecimento que ainda nao esta na documentacao oficial
  - Bloquear uma orientacao especifica (ex: "NAO recomende usar scaler Y")
-->

## Escopo

**Cobre**:
- Integracao com o Datadog e configuracao inicial no Karavela
- Configuracao e coleta de logs (stdout, OTLP, datastores Datadog, Grafana Loki e SIEM)
- Regras de indexacao e retencao de logs por ambiente
- Metricas customizadas (Pull via PodMonitor/OpenMetrics e Push via OTLP) e seus datastores (Grafana Mimir e Datadog)
- Configuracao de APM (lib injection, instrumentacao automatica, instrumentacao manual, dd-trace e OpenTelemetry SDK)
- Regras de retencao de traces por ambiente
- Configuracao de alertas (Grafana Mimir, Grafana Loki e Datadog Monitors)
- Recording rules para metricas e logs
- Tags automaticas e variaveis de ambiente do Datadog
- Correlacionamento de logs e traces
- Referencias a dashboards (Grafana e Datadog)
- Portal de Observabilidade (aba no Portal da aplicacao)
- Datadog RUM (Real User Monitoring)
- Testes sinteticos (Blackbox e Pingdom)

**NAO cobre**:
- Scanning de seguranca (coberto pela skill seguranca)
- Troubleshooting de erros especificos de aplicacao (coberto pela skill troubleshooting)
- Metricas de autoscaling e configuracao de HPA/KEDA (coberto pela skill recursos-scaling)

## Exemplos de Perguntas

- "Como configuro os logs da minha aplicacao no Karavela para enviar ao Grafana Loki?"
- "Como habilito o APM via lib injection no values.yaml?"
- "Como envio metricas customizadas da minha aplicacao para o Grafana usando OpenMetrics?"
- "Como envio metricas via OTLP (push) para o Grafana?"
- "Como crio um alerta de metrica no Grafana Mimir pelo values.yaml?"
- "Quais variaveis de ambiente do Datadog sao definidas automaticamente pelo chart?"
- "Como configuro a instrumentacao OpenTelemetry para envio de traces via gRPC?"
- "Como crio um monitor do Datadog via values.yaml com notificacao para o Opsgenie?"
- "Como habilito a correlacao de logs e traces no Datadog?"
- "Quais sao as regras de retencao de logs e traces por ambiente?"
- "Como configuro o Datadog RUM para minha aplicacao?"
- "Como crio testes sinteticos privados e publicos?"
- "Como vejo a aba de Observabilidade no Portal?"

## Conhecimento Embutido

### Visao Geral e Configuracao Inicial

Ao criar uma aplicacao com o Karavela, a integracao com o Datadog e disponibilizada automaticamente. Por padrao, a plataforma coleta metricas de infraestrutura (CPU, memoria, redes e Kubernetes) e logs exportados para stdout. O Datadog e o datastore padrao para metricas de integracao (Kubernetes, Postgres, RabbitMQ, etc.), logs e APM. Para metricas customizadas de aplicacao, o datastore primario recomendado e o Grafana (Grafana Mimir). O Grafana Loki e a opcao de baixo custo para armazenamento de logs (nao habilitado por padrao).

As seguintes variaveis de ambiente sao definidas automaticamente pelo chart template, baseando-se nos campos do `values.yaml`:

- `DD_ENV` - ambiente da aplicacao
- `DD_SERVICE` - nome do servico
- `DD_VERSION` - versao da aplicacao (derivada da tag da imagem)
- `DD_AGENT_HOST` - host do agente Datadog

Alem disso, as `labels` configuradas no `values.yaml` sao transformadas em `tags` no Datadog automaticamente (ex: `cost-center`, `project`, `owner`, `support`, `env`, etc.), podendo ser usadas como filtros em dashboards, alertas e consulta de logs.

```yaml
# Exemplo de configuracao basica com labels e integracao Datadog
platform-k8s-chart-api:
  labels:
    cost-center: "820150020"
    project: "karavela"
    owner: "foundation-platform-computing"
    group-slack: "foundation-platform-computing-k8s"
    support: "foundation-platform-cloud"
    github-org: "stone-payments"
    github-repo: "karavela"
    env: "production"

  image:
    repository: "697525377503.dkr.ecr.us-east-1.amazonaws.com/karavela-api"
    pullPolicy: IfNotPresent
    tag: "f2df712" # (DD_VERSION)

  application:
    name: karavela-api # (DD_SERVICE)
    language: golang # Datadog source integration
    environment: production # staging | sandbox
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/observabilidade/intro.md`

### Logs

Os logs coletados por padrao sao os exportados para stdout. Essa coleta e habilitada automaticamente no chart com `datadog.logs.enabled: true`.

Existem dois datastores disponiveis para logs:
- **Datadog**: configuracao padrao, captura logs via stdout.
- **Grafana Loki**: opcao de baixo custo, nao habilitado por padrao.
- **SIEM**: pipeline de seguranca para envio de logs a um bucket S3 segmentado por contexto de negocio (ex: SPI). Nao habilitado por padrao.

Para redirecionar logs para o Grafana Loki ao inves do Datadog:

```yaml
# Enviando logs para o Grafana Loki via coleta stdout
datadog:
  logs:
    datastores:
      datadog:
        enabled: false
      grafana:
        enabled: true
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/observabilidade/logs.md`

Alem da coleta via stdout, e possivel enviar logs via OTLP. Para isso, desabilite a coleta padrao e habilite a telemetria OpenTelemetry:

```yaml
# Enviando logs via OTLP para o Grafana Loki
datadog:
  logs:
    enabled: false

telemetry:
  enabled: true
  instrumentation:
    opentelemetry:
      enabled: true
      logs:
        datastores:
          datadog:
            enabled: false
          grafana:
            enabled: true
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/observabilidade/logs.md`

#### Logs para SIEM

Para habilitar o envio de logs ao pipeline SIEM, configure o datastore `siem` em qualquer um dos tres pontos de coleta de logs:

```yaml
# Via coleta stdout
datadog:
  logs:
    datastores:
      siem:
        enabled: true
        context: "spi"

# Via OTLP (descontinuado — prefira telemetry.opentelemetry)
datadog:
  otlp:
    logs:
      datastores:
        siem:
          enabled: true
          context: "spi"

# Via OpenTelemetry
telemetry:
  instrumentation:
    opentelemetry:
      logs:
        datastores:
          siem:
            enabled: true
            context: "spi"
```

- `siem.enabled`: Habilita o envio de logs para o pipeline SIEM. Default: `false`.
- `siem.context`: Identificador logico que determina para qual bucket S3 os logs serao roteados. Segmenta logs por dominio de negocio. Atualmente apenas `"spi"` (Sistema de Pagamentos Instantaneos) esta disponivel.

> **IMPORTANTE**: Esta funcionalidade nao esta disponivel em todos os clusters. Em clusters legados, e necessario adicionar manualmente a annotation `telemetry.karavela.stone.tech/siem.logs.context: "spi"` no Pod.

**Fonte**: `karavela/docs/siem_integration.md`, `karavela/docs/guia-do-desenvolvedor/observabilidade/logs.md`; `platform-k8s-charts/platform-k8s-api-chart/values.yaml` (v1.36.0+) (complemento — nao em docs/)

Os logs sao filtrados automaticamente pelas tags mapeadas, como `service`, `environment` e `version`. Para consultar logs no Grafana, utilize:
- Staging: `https://grafana-stg.stone.tech`
- Production: `https://grafana-prd.stone.tech`

#### Regras de Indexacao e Retencao de Logs

A plataforma aplica regras de indexacao e retencao diferenciadas por ambiente e severidade:

**Production:**
- Error & Warning: 100% indexado, retencao de 15 dias
- Info: 10% indexado, retencao de 15 dias

**Staging / Sandbox:**
- Error & Warning: 25% indexado, retencao de 3 dias
- Info: 10% indexado, retencao de 3 dias

**Live Tail:** 100% de visibilidade por 15 minutos (todos os ambientes).

**Fonte**: `karavela/docs/guia-do-desenvolvedor/observabilidade/logs.md`

### Metricas

As metricas suportam tres tipos: **Count** (valores acumulados ao longo do tempo), **Gauge** (valores que variam ao longo do tempo) e **Histogram** (distribuicao de valores em buckets).

O Datadog e a principal solucao para metricas de integracao (Kubernetes, Postgres, RabbitMQ, etc.). Porem, para metricas customizadas de aplicacao, o datastore primario recomendado e o **Grafana (Grafana Mimir)**, devido ao controle de custos. Metricas customizadas de alta cardinalidade podem escalar custos no Datadog de forma rapida e inesperada. Excecoes devem ser alinhadas com o time fp-observability.

Existem dois metodos para coleta de metricas customizadas. **A partir desta release, OpenTelemetry (push via OTLP) e o "padrao ouro" da plataforma**: projetos novos devem instrumentar com OTel desde o dia 1; projetos legados que usam PodMonitor/OpenMetrics devem ter um plano de migracao para OTel.

#### Metodo 1 — Push via OTLP (Padrao Ouro, Recomendado)

Aplicacoes que enviam metricas via OpenTelemetry (push). Configure a env do endpoint OTLP via o template do chart (NAO hardcode no codigo — ver "Proibicao de endpoint hardcoded" abaixo) e habilite o bloco de telemetria. Ao usar OTLP, o bloco `openmetrics` deve estar desabilitado.

```yaml
platform-k8s-chart-api:
  telemetry:
    enabled: true
    instrumentation:
      opentelemetry:
        enabled: true
        protocol: "grpc"                    # ou "http"
        customResourceAttributes: "tier:gold,gw:xyz"   # atributos custom
        metrics:
          infraCardinalityLevel: "medium"   # low | medium | high
          datastores:
            datadog:
              enabled: false
            grafana:
              enabled: true
      openmetrics:
        enabled: false                      # OTLP exige openmetrics desabilitado
```

> **IMPORTANTE — proibicao explicita**: NAO defina `endpoint` ou `protocol` hardcoded no SDK OTel. O chart injeta automaticamente as envs `OTEL_EXPORTER_OTLP_METRICS_ENDPOINT`, `OTEL_EXPORTER_OTLP_GRPC_ENDPOINT`, `OTEL_EXPORTER_OTLP_HTTP_ENDPOINT` e `OTEL_RESOURCE_ATTRIBUTES`. Deixe o SDK ler do ambiente.

#### Metodo 2 — Pull via PodMonitor (Legado para OpenMetrics)

Pipeline ainda suportado para projetos legados com OpenMetrics/Prometheus. Utiliza PodMonitor (agent-metrics) — resolve problemas criticos de perda de dados do pipeline mais antigo via anotacoes do Datadog Agent.

Vantagens (uso legado):
- Permite escolher o datastore de destino para cada metrica atraves de regex
- Suporta monitoramento de multiplos containers (sidecars) no mesmo Pod

Configuracao via `telemetry.instrumentation.openmetrics.targets`:

```yaml
# Pipeline PodMonitor - coleta de metricas com destino por regex
platform-k8s-chart-api:
  telemetry:
    enabled: true
    instrumentation:
      openmetrics:
        targets:
          - containerName: "minha-api"
            portNumber: 9090
            path: "/metrics"
            job: "minha-api-metrics"
            infraCardinalityLevel: "medium" # low | medium | high
            datastores:
              datadog:
                enabled: true
                collect: ["http_requests_critical_*", "payment_*"]
              grafana:
                enabled: true
                collect: [".*"]
          - containerName: "meu-sidecar"
            portNumber: 9091
            path: "/metrics"
            job: "meu-sidecar-metrics"
            infraCardinalityLevel: "medium"
            datastores:
              grafana:
                enabled: true
                collect: ["sidecar_*"]
```

Campos do target:
- `portNumber`: porta numerica onde o endpoint de metricas esta exposto
- `path`: caminho do endpoint (ex: `/metrics`)
- `job`: nome do job para identificacao no pipeline de metricas
- `infraCardinalityLevel`: controle de cardinalidade de metricas de infraestrutura (`low`, `medium`, `high`; padrao: `medium`)
- `datastores.grafana` / `datastores.datadog`: selecao de datastore com regex de coleta via `collect`

**Fonte**: `karavela/docs/guia-do-desenvolvedor/observabilidade/metrics.md`, `karavela/docs/guia-do-desenvolvedor/funcionalidades/observability.md`; `platform-k8s-charts/.docs/CHANGELOG.api.md` (v1.33.0), `CHANGELOG.worker.md` (v1.26.0) (complemento — nao em docs/)

> **IMPORTANTE**: O metodo legado de coleta via anotacoes Datadog (`ad.datadoghq.com/nomedocontainer.checks`) esta **DEPRECATED**. Migre para PodMonitor (intermediario) ou diretamente para OTLP (recomendado).

#### infraCardinalityLevel — Detalhamento

Controla quantos atributos de infraestrutura sao anexados aos pontos de metrica (impacto em custo no Datadog/Grafana Mimir):

| Nivel | Atributos incluidos | Casos de uso |
|-------|---------------------|---------------|
| `low` | service.name, env, project | Apps com altissima taxa de pontos (workers de batch) |
| `medium` (default) | + container, pod, namespace, cost-center, owner | Maioria das APIs HTTP/Worker |
| `high` | + node, instance_type, replica_set, deployment_revision, host | Debug/incidentes pontuais; nao manter em prd permanentemente |

Quanto maior o nivel, mais facetas voce tem para filtrar — mas tambem mais cardinalidade (custo). Comece com `medium` e ajuste por necessidade.

#### Relabeling — Whitelist e Blacklist via regex

Para metricas vindas por OpenMetrics/Pull, voce pode filtrar quais sao publicadas usando `collect` (regex `keep`) ou `relabeling` (regex `drop`):

```yaml
telemetry:
  instrumentation:
    openmetrics:
      targets:
        - portNumber: 9090
          path: "/metrics"
          job: "minha-api-metrics"
          datastores:
            grafana:
              enabled: true
              collect:                  # whitelist (action keep): so publica o que casar
                - "http_requests_.*"
                - "payment_(success|failure)_total"
              relabeling:               # blacklist (action drop): remove o que casar
                - sourceLabel: "__name__"
                  regex: "go_(memstats|gc).*"
                  action: "drop"
```

#### Multi-targets — metricas distintas para datastores distintos

E possivel enviar grupos de metricas para destinos diferentes em paralelo. Ex: criticas para Datadog (alerta P1), demais para Grafana (custo baixo):

```yaml
telemetry:
  instrumentation:
    openmetrics:
      targets:
        - portNumber: 9090
          path: "/metrics"
          job: "minha-api-critical"
          datastores:
            datadog:
              enabled: true
              collect: ["payment_.*_critical", "p99_.*"]
            grafana:
              enabled: false
        - portNumber: 9090
          path: "/metrics"
          job: "minha-api-all"
          datastores:
            grafana:
              enabled: true
              collect: [".*"]
```

#### customResourceAttributes

Anexa atributos custom a todos os pontos OTel — util para classificacao (tier, gateway, regiao logica):

```yaml
telemetry:
  instrumentation:
    opentelemetry:
      customResourceAttributes: "tier:gold,gw:xyz,domain:payments"
```

> **Proibicao explicita de endpoint/protocol hardcoded** — repetindo do bloco OTLP acima: instrumente seu SDK para ler o endpoint do ambiente. Hardcode no codigo (ex: `WithEndpoint("http://...")`) faz a aplicacao ignorar as envs injetadas pelo chart, resultando em metricas que nao chegam ao Grafana/Datadog.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/observabilidade/metrics.md`; `platform-k8s-charts/platform-k8s-api-chart/values.yaml` (complemento — nao em docs/) para schema completo

Clusters suportados para metricas via Prometheus/Grafana: banking-stg, banking-sdx, banking-prd, karavela-shared-stg, karavela-shared-sdx, karavela-shared-prd.

Para contextos efemeros (cronjobs), utilize o PushGateway com o endpoint: `http://pushgateway.prometheus-pushgateway.svc.cluster.local:9091`.

Para visualizar metricas no Grafana:
- Staging: `https://grafana-stg.stone.tech`
- Sandbox e Production: `https://grafana-prd.stone.tech`

### APM (Application Performance Monitoring)

O APM e habilitado por padrao no Karavela com `datadog.apm.enabled: true`, porem os dados nao sao disponibilizados automaticamente. E necessario configurar a instrumentacao de acordo com a linguagem.

Existem duas bibliotecas de instrumentacao suportadas: **dd-trace** e **OpenTelemetry SDK**.

Ha tres formas de instrumentacao:
- **Instrumentacao por lib injection**: init-container injetado automaticamente, sem alterar codigo (dd-trace)
- **Instrumentacao automatica**: configuracao automatica provida pelo agente ou runtime, sem alteracao de codigo (conceito distinto de lib injection)
- **Instrumentacao manual**: configuracao explicita no codigo da aplicacao usando dd-trace ou OpenTelemetry SDK

#### Instrumentacao por Lib Injection (dd-trace)

A lib injection e a forma mais simples: nao exige alteracao no codigo ou no Dockerfile. Um init-container e adicionado ao pod automaticamente.

```yaml
# Habilitando APM via lib injection
datadog:
  apm:
    enabled: true
    injection:
      enabled: true
      libVersion: "vx.x.x" # consultar a versao da lib
      language: java | js | python | dotnet | ruby
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/observabilidade/apm.md`

Nota: para imagens baseadas em Alpine para .NET, utilize a tag com sufixo `musl` apos o numero da versao (ex: `libVersion: v2.47.0-musl`).

Em processos de migracao para o Karavela, desabilite qualquer instrumentacao anterior (manual ou automatica) antes de habilitar o lib injection.

#### Instrumentacao via OpenTelemetry

A instrumentacao com OTEL e realizada de forma manual, configurando a biblioteca OTEL na aplicacao. Para habilitar o envio via OpenTelemetry:

```yaml
# Habilitando envio de traces via OpenTelemetry (gRPC)
platform-k8s-chart-api:
  telemetry:
    enabled: true
    instrumentation:
      opentelemetry:
        enabled: true
        protocol: "grpc" # ou "http" — deve ser especificado explicitamente
        customResourceAttributes: "" # exemplo: "tier:gold"
  envs:
    OTEL_EXPORTER_OTLP_INSECURE: true
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/observabilidade/apm.md`

Variaveis de ambiente criadas automaticamente ao habilitar OTLP:
- `OTEL_EXPORTER_OTLP_GRPC_ENDPOINT` - endpoint para envio via gRPC
- `OTEL_EXPORTER_OTLP_HTTP_ENDPOINT` - endpoint para envio via HTTP
- `OTEL_RESOURCE_ATTRIBUTES` - atributos do recurso (deployment.environment, service.name, service.version, k8s.namespace.name, etc.)

Endpoints padrao para traces:
- gRPC: `agent.datadog.svc.cluster.local:4317`
- HTTP: `agent.datadog.svc.cluster.local:4318`

O campo `customResourceAttributes` permite adicionar atributos customizados ao recurso OTEL (ex: `"tier:gold"`).

#### Correlacionamento de Logs e Traces

Para habilitar a correlacao automatica de logs e traces:

```yaml
platform-k8s-chart-api:
  envs:
    DD_LOGS_INJECTION: true
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/observabilidade/apm.md`

#### Configuracao de Sampling

A taxa de amostragem no dd-trace pode ser definida pela variavel `DD_TRACE_SAMPLING_RULES`. Para OpenTelemetry, consulte a compatibilidade de linguagem no guia oficial do OTEL.

#### Regras de Retencao de Traces

A plataforma aplica regras de retencao diferenciadas por ambiente:

**Production:**
- Erros: 100% retidos (Custom filter, retencao de 15 dias)
- Demais: Intelligent Retention filter

**Staging / Sandbox:**
- Apenas Intelligent Retention filter (sem custom filter)

**Live Tail:** 100% de visibilidade por 15 minutos (todos os ambientes).

**Fonte**: `karavela/docs/guia-do-desenvolvedor/observabilidade/apm.md`

### Alertas - Grafana Stack (Mimir e Loki)

Os alertas podem ser configurados diretamente no `values.yaml` do Helm Chart, utilizando os blocos `alerts.mimir` (para metricas) e `alerts.loki` (para logs). As notificacoes sao encaminhadas via Alertmanager para o Opsgenie.

Estrutura completa do bloco de alertas Grafana Stack:

```yaml
alerts:
  mimir:
    enabled: true
    commonLabels: {}
    alerting_rules: []
    recording_rules: []
  loki:
    enabled: true
    alerting_rules: []
    recording_rules: []
```

Labels comuns como `cost-center`, `env`, `project`, `owner`, `support`, `github-org` e `github-repo` sao adicionadas automaticamente a todos os alertas via Helm Chart.

Ciclo de vida do alerta: Pending (aguardando tempo `for`) -> Firing (condicao mantida, notificacao enviada) -> Resolved (condicao normalizada).

Niveis de severidade recomendados:
- `critical` (P1): impacto severo, acao imediata 24/7
- `error` (P2): falha funcional, acao rapida
- `warning` (P3): potencial problema, investigar em horario comercial
- `info` (P4): informacao, sem acao imediata

Labels de prioridade: `priority` de 1 a 5 (corresponde aos niveis de severidade).

```yaml
# Exemplo: alerta de metrica no Grafana Mimir
alerts:
  mimir:
    enabled: true
    alerting_rules:
      - alert: HighCPUUsage
        expr: sum(rate(process_cpu_seconds_total[5m])) by (instance) > 0.8
        for: 10m
        labels:
          severity: warning
        annotations:
          summary: "Uso de CPU elevado na instancia {{ $labels.instance }}"
          description: "O uso de CPU esta acima de 80% por mais de 10 minutos. Valor atual: {{ $value | humanizePercentage }}."
          runbook_url: "http://wiki.example.com/runbooks/high-cpu"
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/observabilidade/alertas.md`

```yaml
# Exemplo: alerta de log no Grafana Loki
alerts:
  loki:
    enabled: true
    alerting_rules:
      - alert: PaymentSlipErrorRate
        expr: |
          sum(count_over_time({index="PaymentSlip.Internal.Service"} |= "error" [5m]))
          > 10
        for: 5m
        labels:
          severity: critical
        annotations:
          summary: "Alta taxa de erros no PaymentSlip"
          description: "Detectados mais de 10 erros nos ultimos 5 minutos no servico PaymentSlip."
          dashboard_url: "http://grafana.example.com/d/paymentslip-dashboard"
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/observabilidade/alertas.md`

Labels especiais para controle de alertas:
- `auto_resolve: "false"` — desabilita o fechamento automatico (auto-close) no Opsgenie. O titulo do alerta recebera o prefixo `[MANUAL]`.
- `send_to_sandbox: true` — redireciona o alerta para o Opsgenie de sandbox.
- `notify: false` — permite validar uma query sem ativar notificacoes.

Visualizacao dos alertas no Grafana:
- Staging: `https://grafana-stg.stone.tech/alerting/list`
- Producao: `https://grafana-prd.stone.tech/alerting/list`

### Alertas - Datadog Monitors

Monitores do Datadog podem ser criados via `values.yaml` usando o bloco `alerts.datadog`. O provisionamento e feito via CRDs do tipo `DatadogMonitor`.

O bloco `defaults` permite definir valores padrao (prioridade, notificacoes, tags, thresholds, options) aplicados a todos os monitores, evitando repeticao.

Estrutura completa do bloco de alertas Datadog:

```yaml
alerts:
  datadog:
    enabled: true
    defaults:
      priority: 3
      notifications:
        opsgenie:
          account: stone-co-prd
          teams: []
    monitors:
      - enabled: true
        logicalName: high-cpu-usage
        name: High CPU Usage
        type: metric alert # metric alert | log alert | composite | service check | event alert | process alert | trace-analytics alert | query alert
        query: avg(last_5m):avg:system.cpu.user{env:prd,service:payment-api} > 90
        message:
          description: "Uso elevado de CPU detectado."
          links:
            Documentation: "https://example.com/docs"
            Dashboard: "https://dash.com.br"
        notifications:
          opsgenie:
            account: stone-co-prd
            teams: ["payments-core"]
        thresholds:
          critical: "90"
          warning: "80"
        options:
          evaluationDelay: 300
          notifyNoData: true
          noDataTimeframe: 30
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/observabilidade/alertas.md`

Tipos de monitores Datadog suportados: `metric alert`, `log alert`, `service check`, `event alert`, `composite`, `process alert`, `trace-analytics alert`, `query alert`.

Opcoes avancadas de monitores incluem: `evaluationDelay`, `newGroupDelay`, `notifyNoData`, `noDataTimeframe`, `renotifyInterval`, `includeTags`, `requireFullWindow`, `notifyAudit`, `locked`, `timeoutH`, `escalationMessage`.

Tags comuns (`cost-center`, `env`, `project`, `owner`, etc.) sao adicionadas automaticamente via dependencias do Helm Chart.

### Recording Rules

As recording rules permitem pre-calcular expressoes frequentes ou computacionalmente caras, salvando o resultado como uma nova metrica. Sao uteis para simplificar queries de alerta complexas, acelerar dashboards e criar metricas padronizadas.

```yaml
# Exemplo: recording rule para metricas (Mimir)
alerts:
  mimir:
    enabled: true
    recording_rules:
      - record: service:http_requests:rate1m
        expr: sum(rate(http_requests_total[1m])) by (service)
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/observabilidade/alertas.md`

```yaml
# Exemplo: recording rule para logs (Loki)
alerts:
  loki:
    enabled: true
    recording_rules:
      - record: app:logs_error:count1m
        expr: sum(count_over_time({level="error"}[1m])) by (app)
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/observabilidade/alertas.md`

Padrao de nomenclatura recomendado: `nivel:metrica:agregacao` (ex: `service:http_requests:rate1m`).

### Portal de Observabilidade

O Portal da aplicacao possui uma aba **"Observabilidade"** que fornece visibilidade em tempo real do estado da aplicacao. Os dados sao obtidos do ArgoCD (real-time).

Funcionalidades:
- Visualizacao de **pods** do deployment com status atual
- **Eventos** do Kubernetes associados ao deployment
- Metricas de **CPU e memoria** dos pods
- Botao de acesso ao **Datadog** com link pre-filtrado (cluster, namespace, deployment, ultimos 60 minutos)
- **Auto-refresh** a cada 30 segundos

**Fonte**: Portal Karavela — aba "Observabilidade" da aplicacao

### Datadog RUM (Real User Monitoring)

Para configurar o Datadog RUM (monitoramento de experiencia do usuario real), utilize o template `datadog-application-rum` para criar a aplicacao RUM no Datadog.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/observabilidade/rum.md`

### Testes Sinteticos

Testes sinteticos permitem monitorar endpoints e fluxos de forma proativa:

- **Testes privados (Blackbox)**: para endpoints internos, utilizando o Blackbox Exporter
- **Testes publicos (Pingdom)**: para endpoints publicos, utilizando o Pingdom

**Fonte**: `karavela/docs/guia-do-desenvolvedor/observabilidade/sinteticos.md`

### Values.yaml - Secao Datadog (Referencia do Chart)

O chart `platform-k8s-api-chart` possui a seguinte estrutura padrao para observabilidade no `values.yaml`:

- `datadog.enabled`: habilita integracao Datadog (padrao: `true`)
- `datadog.logs.enabled`: habilita coleta de logs via stdout (padrao: `true`)
- `datadog.logs.datastores.datadog.enabled`: logs para Datadog (padrao: `true`)
- `datadog.logs.datastores.grafana.enabled`: logs para Grafana Loki (padrao: `false`)
- `datadog.apm.enabled`: habilita APM (padrao: `true`)
- `datadog.apm.injection.enabled`: habilita lib injection (padrao: `false`)
- `telemetry.enabled`: habilita telemetria OTLP (padrao: `false`)
- `telemetry.instrumentation.opentelemetry.enabled`: habilita OpenTelemetry (padrao: `false`)
- `telemetry.instrumentation.opentelemetry.protocol`: protocolo `grpc` ou `http` (padrao: `grpc`)
- `telemetry.instrumentation.opentelemetry.customResourceAttributes`: atributos customizados OTEL (padrao: `""`)
- `telemetry.instrumentation.openmetrics.targets`: lista de targets PodMonitor com `portNumber`, `path`, `job`, `infraCardinalityLevel`, `datastores`
- `alerts.mimir.enabled`: habilita alertas Grafana Mimir (padrao: `false`)
- `alerts.mimir.commonLabels`: labels comuns para todos os alertas Mimir
- `alerts.mimir.alerting_rules`: regras de alerta Mimir
- `alerts.mimir.recording_rules`: recording rules Mimir
- `alerts.loki.enabled`: habilita alertas Grafana Loki (padrao: `false`)
- `alerts.loki.alerting_rules`: regras de alerta Loki
- `alerts.loki.recording_rules`: recording rules Loki
- `alerts.datadog.enabled`: habilita monitores Datadog (padrao: `false`)
- `alerts.datadog.defaults`: valores padrao para monitores (priority, notifications)
- `alerts.datadog.monitors`: lista de monitores Datadog
- `datadog.logs.datastores.siem.enabled`: habilita envio de logs stdout para SIEM (padrao: `false`)
- `datadog.logs.datastores.siem.context`: contexto de negocio para roteamento SIEM (padrao: `"spi"`)
- `telemetry.instrumentation.opentelemetry.logs.datastores.siem.enabled`: habilita envio de logs OTLP para SIEM (padrao: `false`)
- `telemetry.instrumentation.opentelemetry.logs.datastores.siem.context`: contexto de negocio para roteamento SIEM (padrao: `"spi"`)

**Fonte**: `karavela/docs/guia-do-desenvolvedor/observabilidade/` (intro, logs, metrics, apm, alertas), `karavela/docs/guia-do-desenvolvedor/funcionalidades/observability.md`; `platform-k8s-charts/platform-k8s-api-chart/values.yaml` (complemento — nao em docs/) para schema completo

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever; producao exige dupla confirmacao. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Editar `chart/values-*.yaml`** — `datadog.logs.*`, `datadog.apm.*` (lib injection), `telemetry.instrumentation.opentelemetry.*` (push OTLP), `telemetry.instrumentation.openmetrics.targets[]` (pull legado), `alerts.mimir.*` (alerting_rules, recording_rules), `alerts.loki.*`, `alerts.datadog.monitors[]`, `customResourceAttributes`, `infraCardinalityLevel`, SIEM datastore
- **Adicionar regras de alerta** (Mimir/Loki/Datadog) seguindo padroes da skill
- **Rodar queries read-only** via `mcp__vela-mcp-hub__observability__*` (Datadog/Grafana) para diagnostico
- **Abrir PR draft**

### Triggers proativos
- "Habilitar OTel" → `🛠️ Acao proposta: configuro telemetry.opentelemetry no values + remove openmetrics se conflito`
- "Criar alerta de CPU/memoria/erro" → propor bloco `alerting_rules` no values
- "Migrar logs para Loki" → propor `datadog.logs.datastores.grafana.enabled: true`
- "Tracar com Datadog" → propor `datadog.apm.injection.enabled: true` com `libVersion` e `language`
- "Metricas nao chegam" → verificar SDK hardcoded; apontar para skill `troubleshooting`

### Acoes destrutivas (dupla confirmacao)
- Mudar `infraCardinalityLevel: high` em prd — pode aumentar custo Datadog/Mimir. Avisar + confirmar.
- Desabilitar `datadog.logs.enabled` — perda de logs em runtime. Avisar.

## Instrucoes MCP

Quando voce ainda nao estiver certeza da resposta use o GITHUB mcp. Priorize a documentacao oficial em `stone-payments/karavela` `docs/`; outros repositorios servem apenas como fallback.

**Fontes primarias (docs/):**

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/observabilidade/intro.md` | Visao geral, variaveis de ambiente Datadog automaticas |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/observabilidade/logs.md` | Coleta de logs, Grafana Loki, regras de indexacao/retencao |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/observabilidade/metrics.md` | Metricas customizadas (OpenMetrics, OTLP), Grafana Mimir, cardinalidade |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/observabilidade/apm.md` | APM, lib injection, OpenTelemetry, correlacao logs/traces, retencao |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/observabilidade/alertas.md` | Alertas Mimir, Loki, Datadog Monitors, recording rules |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/observabilidade/rum.md` | Datadog RUM |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/observabilidade/sinteticos.md` | Testes sinteticos (Blackbox e Pingdom) |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/funcionalidades/observability.md` | Campos do bloco `telemetry` no values.yaml |
| `stone-payments/karavela` | `docs/siem_integration.md` | SIEM datastore para logs |

**Fontes secundarias (complemento — nao em docs/):**

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/platform-k8s-charts` | `platform-k8s-api-chart/values.yaml` | Schema completo dos blocos `datadog`, `telemetry`, `alerts` |
| `stone-payments/platform-k8s-charts` | `platform-k8s-api-chart/templates/_helpers.tpl` | Lista completa de resource attributes e labels automaticas |
| `stone-payments/observability-helm-charts` | `charts/observability-agent-metrics/docs/` | Pipeline de metricas via PodMonitor (detalhes do agente) |

## Formato de Resposta

Ao responder perguntas deste dominio, siga este formato:

1. **Explicacao** (2-3 frases objetivas em PT-BR)
2. **Exemplo pratico** (YAML, comando ou config copiavel)
3. **Fonte** (referencia ao arquivo/secao da documentacao)
4. **Avisos** (se aplicavel: restricoes de ambiente, custos, privilegios necessarios)

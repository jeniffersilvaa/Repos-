---
name: static-apps
description: "Publica conteudo estatico (HTML, dashboards de planilha, relatorios) hospedado em S3 como static-site. Use quando o usuario quiser dashboard estatico, static app, publicar HTML, publicar relatorio, subir dashboard, planilha para dashboard, Excel para dashboard, publicar zip."
---

# Skill: Static Apps

Publicar conteudo estatico (HTML, dashboards de planilha, relatorios) hospedado em S3 — `spec.type: static-site`. Nao confundir com:

| Pergunta do user                                                 | Skill correta       |
| ---------------------------------------------------------------- | ------------------- |
| "dashboard estatico" / "publicar HTML/zip em S3"                 | `static-apps`       |
| "dashboards de dados ao vivo" (Datadog/Grafana/Amplitude)        | `observe`           |
| "criar app" / "nova aplicacao" / "provisionar app"               | `create-app`        |
| "lista apps" / "secrets" / "deploy" / "describe app"             | `platform`          |

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.
-->

## Exemplos de Perguntas

- "Quero criar um dashboard estatico"
- "Publica esse HTML pra mim"
- "Transforma essa planilha em dashboard"
- "Preciso publicar um relatorio"
- "Sobe esse zip como static app"
- "Quero subir um dashboard com dados do Excel"
- "Cria um relatorio HTML"
- "Publica esse dashboard"

## Regras de Execucao

- Fluxo pra **users nao-tecnicos** — nao pergunte sobre cluster/contexto/ambiente/cost center.
- Ambiente (`stg`) e silencioso no MVP.
- Apos `prepare_static_app_draft`: **pare** — o painel toma o palco.
- **NUNCA** mencione botao "Publicar", "Publish" ou modal de publicacao no painel — nao existem. O painel so tem toggle Visual/Codigo, Reverter, Tela cheia e Fechar. Publicacao e **sempre** por mensagem no chat ("publica", "sobe", "manda ver", "joga no ar").

## Conhecimento Embutido

### Tools

- `vela__prepare_static_app_draft({ conversationId, html, suggestedName?, suggestedDescription? })` — salva rascunho. **NAO publica**. Substitui o rascunho a cada chamada.
- `vela__publish_static_app_draft({ conversationId, name, description })` — publica: catalog + deploy + URL + cleanup do draft.
- `vela__rehydrate_static_app_draft({ applicationRef, environment })` — abre painel com HTML da app ja publicada pra edicao. **NUNCA peca HTML ao user** — sempre tente rehydrate.
- `kli-mcp__create_static_app` + `kli-mcp__deploy_static_artifact({ file_id, ... })` — fluxo zip/tar (nao inline).
- `kli-mcp__deploy_inline_html` — **bloqueado quando ha rascunho ativo**.
- `kli-mcp__describe_application` — confirmar app antes de editar.

### Regra critica: iteracao

Se contexto tem `<currentStaticAppDraft>...</currentStaticAppDraft>`, **edite a partir desse conteudo** preservando estrutura + alteracoes manuais. NUNCA regenere do zero exceto se user disser "recomeca"/"do zero"/"zera". `conversationId` vem de `<currentConversationId>{id}</currentConversationId>`.

### Fluxo: gerar HTML (Excel anexado / descricao de dashboard)

1. Confirme intencao. Se user so quer analise, **nao** chame `prepare_static_app_draft`.
2. Scoping: 2+ perguntas distintas → bloco `<questions>` (wizard); 1 pergunta → prosa.
3. PRD-leve no chat + "Posso seguir e gerar o HTML?". Encerre o turn.
4. Apos aprovacao: gere HTML5 standalone (ver ref) + `prepare_static_app_draft` **UMA vez**. Resposta: **uma linha curta** "Abri o preview no painel. Revisa, edita e peca pra publicar." → `end_turn`. **NAO emita o HTML no chat** — painel ja mostra.
5. Iteracao: regenere respeitando `<currentStaticAppDraft>` + `prepare_static_app_draft` (uma vez por turn).

### Fluxo: publicar

Triggers: "publica", "manda ver", "sobe", "joga no ar".

1. Confirme nome (kebab-case ≤45) + descricao (≤100) com **uma frase**. Encerre o turn.
2. Apos aprovacao: `vela__publish_static_app_draft({ conversationId, name, description })`. **NAO** chame `create_static_app`/`deploy_inline_html` direto (bloqueados com draft ativo).
3. Use **URL exata de `result.url`** — texto puro, sem Markdown link, sem inventar subdominio. Erros: ver ref.

### Fluxo: zip/tar/html anexado

Autonomo, sem draft: `kli-mcp__create_static_app({ name, description })` + `kli-mcp__deploy_static_artifact({ file_id, application_ref, environment })`. Conteudo do zip e canonico (nao passa por revisao).

## Instrucoes MCP

Tools do servidor `vela` (sinteticas):

- `vela__prepare_static_app_draft` — salvar rascunho HTML no painel
- `vela__publish_static_app_draft` — publicar rascunho (catalog + deploy + URL)
- `vela__rehydrate_static_app_draft` — carregar HTML de app existente pra edicao

Tools do servidor `kli-mcp`:

- `kli-mcp__create_static_app` — criar static-app no catalog
- `kli-mcp__deploy_static_artifact` — deploy de zip/tar
- `kli-mcp__deploy_inline_html` — deploy inline (bloqueado com draft ativo)
- `kli-mcp__describe_application` — descrever app do catalog

## Formato de Resposta

### Apos gerar HTML

Uma linha curta: "Abri o preview no painel. Revisa, edita e peca pra publicar."
**NAO** emita o HTML no chat.

### Apos publicar

```
✅ App **<nome>** publicada!

URL: https://vela-apps.stone.tech/<name>/
```

URL em texto puro, sem Markdown link.

### Erros

Ver ref `static-apps-html-and-publishing` para tabela de erros e respostas esperadas.

### Cancelamento

Triggers: "cancelar", "esquece", "deixa pra la". Resposta: "Beleza, cancelado."

---
skill: static-apps
version: 1
---

# Evals: Static Apps (Publicar Conteudo Estatico)

## Happy-Path

### HP-001: Criar dashboard estatico
**Input**: "Quero criar um dashboard estatico"
**Deve**:
- Iniciar fase de scoping (2+ perguntas distintas → bloco `<questions>`; 1 pergunta → prosa)
- Apresentar PRD-leve e perguntar "Posso seguir e gerar o HTML?" antes de gerar
**Nao deve**:
- Perguntar sobre cluster, contexto, ambiente ou cost center
**Fonte**: Exemplos de Perguntas #1

---

### HP-002: Publicar HTML
**Input**: "Publica esse HTML pra mim" (com HTML no contexto)
**Deve**:
- Perguntar nome (kebab-case ≤45) e descricao (≤100) em uma frase e encerrar o turn
- Apos aprovacao: chamar `vela__publish_static_app_draft({ conversationId, name, description })`
- Retornar URL exata de `result.url` em texto puro (sem Markdown link)
**Nao deve**:
- Chamar `kli-mcp__create_static_app` ou `kli-mcp__deploy_inline_html` quando ha draft ativo
**Fonte**: Exemplos de Perguntas #2

---

### HP-003: Transformar planilha em dashboard
**Input**: "Transforma essa planilha em dashboard" (com arquivo Excel anexado)
**Deve**:
- Confirmar intencao (dashboard, nao so analise)
- Gerar HTML5 standalone e chamar `vela__prepare_static_app_draft` UMA vez
- Resposta apos prepare: apenas "Abri o preview no painel. Revisa, edita e peca pra publicar."
**Nao deve**:
- Emitir o HTML no chat alem da resposta curta
- Chamar `prepare_static_app_draft` mais de uma vez no mesmo turno
**Fonte**: Exemplos de Perguntas #3

---

### HP-004: Publicar relatorio
**Input**: "Preciso publicar um relatorio"
**Deve**:
- Fazer scoping do conteudo do relatorio antes de gerar HTML
- Seguir fluxo gerar HTML → prepare_static_app_draft → aguardar "publica"
**Nao deve**:
- Publicar diretamente sem gerar e mostrar o preview antes
**Fonte**: Exemplos de Perguntas #4

---

### HP-005: Upload de zip/tar
**Input**: "Sobe esse zip como static app" (com arquivo zip anexado)
**Deve**:
- Usar `kli-mcp__create_static_app` seguido de `kli-mcp__deploy_static_artifact({ file_id, ... })`
- Nao passar pelo fluxo de draft HTML (zip e canonico)
**Nao deve**:
- Tentar converter zip em HTML inline
**Fonte**: Exemplos de Perguntas #5

---

### HP-006: Dashboard com dados do Excel
**Input**: "Quero subir um dashboard com dados do Excel"
**Deve**:
- Identificar como fluxo de geracao HTML (com dados da planilha)
- Scoping → PRD-leve → aprovacao → gerar HTML → prepare_static_app_draft
**Nao deve**:
- Perguntar sobre ambiente, cluster ou cost center
**Fonte**: Exemplos de Perguntas #6

---

### HP-007: Iteracao no dashboard existente
**Input**: "Adiciona um grafico de barras ao dashboard" (com `<currentStaticAppDraft>` no contexto)
**Deve**:
- Editar a partir do conteudo em `<currentStaticAppDraft>`, preservando estrutura e alteracoes existentes
- Chamar `prepare_static_app_draft` UMA vez com o HTML atualizado
**Nao deve**:
- Regenerar o HTML do zero descartando o conteudo atual
**Fonte**: Conhecimento Embutido — Regra critica: iteracao

---

### HP-008: Publicar dashboard
**Input**: "Publica esse dashboard" (apos preview gerado)
**Deve**:
- Pedir confirmacao de nome e descricao antes de publicar
- Chamar `vela__publish_static_app_draft` apos confirmacao
- Retornar `✅ App **<nome>** publicada! URL: https://vela-apps.stone.tech/<name>/`
**Nao deve**:
- Inventar a URL; usar apenas a URL exata de `result.url`
**Fonte**: Exemplos de Perguntas #8

---

## Edge-Cases

### EC-001: Nao perguntar sobre infra para usuario nao-tecnico
**Input**: "Quero criar um dashboard para o meu time"
**Deve**: Iniciar scoping do conteudo diretamente; nao mencionar cluster, ambiente, contexto ou cost center
**Nao deve**: Perguntar "em qual cluster?", "qual ambiente (stg/prd)?", "qual cost center?"
**Fonte**: Regras de Execucao — fluxo para users nao-tecnicos

---

### EC-002: Parar apos prepare_static_app_draft
**Input**: "Gera um dashboard de metricas e ja publica"
**Deve**: Gerar HTML, chamar `prepare_static_app_draft` e encerrar o turn com "Abri o preview no painel. Revisa, edita e peca pra publicar." — nao publicar automaticamente
**Nao deve**: Chamar `vela__publish_static_app_draft` sem aguardar confirmacao explicita do usuario
**Fonte**: Regras de Execucao — apos prepare_static_app_draft: pare

---

### EC-003: Nao mencionar botao Publicar no painel
**Input**: "Como faco pra publicar o dashboard?"
**Deve**: Instruir o usuario a enviar uma mensagem no chat ("publica", "sobe", "manda ver") para acionar a publicacao
**Nao deve**: Mencionar botao "Publicar", "Publish" ou modal de publicacao no painel (nao existem)
**Fonte**: Regras de Execucao — publicacao e sempre por mensagem no chat

---

### EC-004: Rehydrate antes de pedir HTML
**Input**: "Edita o dashboard minha-app que ja publiquei"
**Deve**: Chamar `vela__rehydrate_static_app_draft({ applicationRef, environment })` para carregar o HTML existente antes de editar
**Nao deve**: Pedir ao usuario que cole o HTML do dashboard; nunca peca HTML quando pode rehydrate
**Fonte**: Conhecimento Embutido — vela__rehydrate_static_app_draft: NUNCA peca HTML ao user

# Reference: Static-app shape no catálogo Backstage

Como uma static-app aparece no Catalog Backstage. Carregue quando alguém perguntar sobre static-app via `describe_application` ou ao explicar a diferença de uma app normal.

## YAML canônico

```yaml
apiVersion: karavela.stone.tech/v1alpha1
kind: Application
metadata:
  name: artilheiros-copa-mundo
  namespace: default
  annotations:
    backstage.io/managed-by-location: 'mcp-static-apps: applications/artilheiros-copa-mundo'
    karavela.stone.tech/created-by: user:pagarme/vinicius-padilha
  tags:
    - static-site
    - dashboard
spec:
  name: artilheiros-copa-mundo
  type: static-site # ← discriminador
  owner: user:pagarme/vinicius-padilha
  system: karavela-static-apps # ← defesa em profundidade
  lifecycle: production
  envConfigs: [] # ← SEMPRE vazio para static-apps
  repositoryUrl: ''
  groupIds: []
  regions: []
```

## Notas semânticas

- **`spec.type: static-site`** é o discriminador. Tudo abaixo deste valor segue o fluxo static-apps; tudo com outros valores (`api`, `worker`, `cronjob`, `job`) segue o fluxo de apps normais (KLI deploy → ArgoCD → cluster).
- **`envConfigs` é sempre `[]`** — static-apps não rodam em cluster, só em S3. Aplicar interpretação de "app malconfigurada por estar com envConfigs vazio" é incorreto.
- **`environment` em `vela__rehydrate_static_app_draft`** é independente de `envConfigs` — é um enum fixo (MVP só aceita `stg`) que roteia pro bucket S3 correto.
- **`owner` é referência de usuário criador**, NÃO um group. Ao listar static-apps por dono, filtre por `owner = user:<ref>`, nunca por group.
- **`system: karavela-static-apps`** é defesa em profundidade — confirma que a entity é gerenciada pelo fluxo static-apps mesmo se `type` for ambíguo.

## Quando isso importa

- **`describe_application` retorna `envConfigs: []`** → não é bug, é static-app
- **Listagem por team/group** → static-apps NÃO aparecem se você filtrar por group ownership (eles têm user owner)
- **`get_application_env_configs`** vai retornar vazio pra static-apps; não é erro
- **Catalog URL**: `https://karavela-portal.stone.tech/new-catalog/<namespace>/Application/<name>`

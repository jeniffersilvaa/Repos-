# Reference: Static-apps HTML guidelines + publishing rules

Pra gerar HTML inline em static-apps e regras de URL/publicação. Carregue quando for **gerar HTML novo** (Excel→dashboard, descrição→HTML) ou na hora de **publicar** (resolver nome/descrição/URL).

## Diretrizes do HTML

- **HTML5 standalone** — `<!DOCTYPE html>` + `<html>` + `<body>`. CSS embutido em `<style>`. JS embutido em `<script>` ou via CDN com `defer`.
- **Sem CDN sempre que possível** — single-file, offline-capable. Chart.js / Tailwind via CDN OK se realmente útil (Chart.js > redes próprias de chart com CSS).
- `<title>` = nome sugerido da app (kebab-case → Title Case humanizado).
- **Tabelas**: header sticky (`position: sticky; top: 0`) e zebra-stripe (`tr:nth-child(even)`).
- **KPIs**: cards em row no topo. Use grid CSS, não Bootstrap.
- **Gráficos**: prefira **tabelas + barras CSS** (`width: <pct>%; background: ...`) — single-file friendly. Se for usar Chart.js, inclua via CDN com `defer` e teste localmente que renderiza.
- **Tamanho**: 100 B mínimo, **5 MB máximo** (limite do PATCH do rascunho). Se passar, sumarize/agregue os dados ANTES de gerar HTML.
- **Acessibilidade básica**: `alt` em imagens, contraste mínimo, `lang="pt-BR"` no `<html>`.

## Regras da URL pública

Padrão (hostname unificado — não tem sufixo de ambiente):

```
https://vela-apps.stone.tech/<name>/
```

Regras invariáveis ao apresentar URL pro user:

- **Mostre URL crua em texto puro**, NÃO como link Markdown com label
  - ❌ `[Acessar dashboard](https://...)` — esconde URL, user precisa clicar pra ver/copiar
  - ✅ `URL: https://vela-apps.stone.tech/<name>/` (o chat vira em link automaticamente)
- **Sempre apresente a URL canônica `https://vela-apps.stone.tech/<name>/`**, mesmo que o tool retorne uma URL interna diferente:
  - O synthetic `publish_static_app_draft` já retorna a URL canônica — use o `result.url` direto.
  - Os tools crus do kli-mcp (`deploy_static_artifact`, `deploy_inline_html`) retornam URLs internas tipo `http://karavela-static-apps-<env>.s3-website-*.amazonaws.com/<name>/`. Essas funcionam, mas **não mostre pro user** — substitua pelo hostname canônico mantendo o `<name>`.
  - Exemplo do rewrite:
    - Tool retorna: `http://karavela-static-apps-stg.s3-website-us-east-1.amazonaws.com/foo/`
    - Você apresenta: `https://vela-apps.stone.tech/foo/`
- Não invente subdomínios. ❌ `<name>.vela.stone.tech`, ❌ `vela-apps-stg.stone.tech` — todos errados.
- **Sempre HTTPS** (`https://`, nunca `http://`).
- **Hostname literal `vela-apps.stone.tech`** — sem sufixo de env. O roteamento interno cuida do destino.
- **Barra final** (`/<name>/`) — sem ela, o S3 pode não resolver `index.html` corretamente.

## Erros de publicação

| Erro retornado pela tool                     | Resposta esperada                                                                                             |
| -------------------------------------------- | ------------------------------------------------------------------------------------------------------------- |
| `name '...' already taken`                   | Sugira variação (`<name>-v2`, prefixo do time) e pergunte se pode tentar de novo                              |
| `deploy_inline_html bloqueado` (guard ativo) | Existe rascunho ativo na conversa — use `prepare_static_app_draft` em vez disso                               |
| `artifact_missing` (rehydrate)               | Catalog diz publicado mas S3 não tem objeto. Sugira redeploy via `prepare_static_app_draft` + nova publicação |
| `deployment_not_found` (rehydrate)           | App existe no catalog mas ambiente nunca foi deployado. Pergunte o que ele quer publicar                      |
| `not_a_static_app` (rehydrate)               | App não é `spec.type: static-site` — explique que não pode ser editada por esse fluxo                         |
| `application_not_found` (rehydrate)          | App nem existe. Ofereça criar via fluxo "static-app nova"                                                     |

## Anti-patterns

- ❌ Gerar HTML com JS pesado/import-heavy quando dados cabem em CSS-only
- ❌ Esquecer barra final na URL
- ❌ Anunciar conteúdo do HTML após `rehydrate` — o painel já mostra; só confirme que tá pronto
- ❌ Inferir subdomínio do hostname — sempre use o que a tool retornou

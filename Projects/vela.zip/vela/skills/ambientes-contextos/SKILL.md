---
name: ambientes-contextos
description: "Ambientes e contextos da plataforma Karavela. Use quando o usuario perguntar sobre staging, sandbox, producao, contextos, namespaces, promocao de ambientes, promote/demote, is_preprod, sa-east-1 primary, PCI ou a organizacao dos contextos da Stone."
---

# Skill: Ambientes e Contextos

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.
-->

## Escopo

**Cobre**:
- Tabela de contextos (28 contextos com prefixos, IDs, providers e status PCI)
- Ambientes staging, sandbox e producao
- Campo `is_preprod` (novo contexto default como sandbox seguro)
- Endpoints promote/demote/delete de contexto (admin)
- Mapeamento branch-ambiente (develop para staging, main para sandbox/producao)
- Convencoes de nomenclatura de namespaces
- Promocao de ambientes via Karavela Portal
- Selecao de contexto para deploy de aplicacoes
- Suporte a `sa-east-1` como regiao primaria

**NAO cobre**:
- Fluxos de deploy (coberto por deploy-rollback)
- Preview environments (coberto por preview-envs)
- Multi-regiao (coberto por multi-regiao)

## Exemplos de Perguntas

- "Quais sao os contextos disponiveis no Karavela e seus prefixos?"
- "Como funciona o mapeamento de branches para ambientes no Karavela?"
- "Como promover minha aplicacao de staging para producao?"
- "Qual contexto devo selecionar para minha aplicacao de pagamentos?"
- "Quais contextos possuem suporte a PCI?"
- "Quais sao os pre-requisitos para promover um ambiente?"
- "Qual a diferenca entre o ambiente sandbox e o ambiente de producao?"
- "O que e o campo is_preprod em um contexto?"
- "Como promover/rebaixar um contexto entre preprod e prod?"
- "Tem contexto rodando em sa-east-1?"

## Conhecimento Embutido

### O que sao Contextos

Os contextos no ecossistema do Karavela representam uma abstracao das areas e tribos da Stone Co. como um todo. Exemplos comuns incluem: Payments, Banking, Acquiring, entre outros.

Para o Karavela, os contextos sao essenciais para alocar e segregar corretamente recursos computacionais, armazenamento e segregacao logica de rede. Isso garante o bom funcionamento e equilibrio de recursos em todo o ecossistema.

Toda vez que uma aplicacao for lancada atraves do Portal Karavela, o contexto deve ser selecionado. Caso nenhum dos contextos faca sentido para a aplicacao, a equipe do Karavela Containers deve ser contatada pelo canal do Slack `#help-foundation-platform`.

**Fonte**: `karavela/docs/contextos.md`

### Tabela de Contextos do Karavela

Abaixo estao os contextos atualmente disponiveis no Karavela:

| #  | Prefix | Name                         | ID                                   | Provider | Multi-regiao | PCI |
|----|--------|------------------------------|--------------------------------------|----------|--------------|-----|
| 1  | acq    | Acquiring                    | 5efcabf5de9a816160bb0b10             | AWS      | Nao          | Nao |
| 2  | bank   | Banking                      | 5efcabf5de9a816160bb0b13             | AWS      | Nao          | Nao |
| 3  | cpl    | Customer Platforms           | 5efcabf5de9a816160bb0b04             | AWS      | Nao          | Nao |
| 4  | cpl    | GenAi                        | 0199cadb-790c-726c-bff2-bcfecb65c2ee | AWS      | Nao          | Nao |
| 5  | dpl    | Data Platforms               | 5efcabf5de9a816160bb0b03             | AWS      | Nao          | Nao |
| 6  | fp     | Foundation Platforms         | 5efcabf5de9a816160bb0b02             | AWS      | Nao          | Nao |
| 7  | kp     | Workflows Platform           | 0195afc1-3a4a-794c-84ee-e005ba9b135b | AWS      | Nao          | Nao |
| 8  | kvsh   | CSC                          | 0193dbc8-d5dd-798e-aa68-aa0329757df0 | AWS      | Sim          | Nao |
| 9  | kvsh   | Distribution Platform        | 0193dbc0-bbdd-7d68-8599-11c47592ebef | AWS      | Sim          | Nao |
| 10 | kvsh   | Internal Products            | 0193e429-1c48-7143-97f6-0c37dd5d9ecc | AWS      | Sim          | Nao |
| 11 | kvsh   | Logistics                    | 01954df6-ac12-7b90-bdf7-20d8641c86ef | AWS      | Sim          | Nao |
| 12 | kvsh   | Risk Platform                | 0193dbc1-7f71-7d16-a381-fae09c5e2fdd | AWS      | Sim          | Nao |
| 13 | kvsh   | Security                     | 0193dbc9-1745-7a4e-a7b8-dd595a1de079 | AWS      | Sim          | Nao |
| 14 | kvsh   | SMB                          | 0193e428-1783-7f3b-b21d-c8e5707e1a55 | AWS      | Sim          | Nao |
| 15 | kvsh   | Specialized Software         | 019976ca-ff82-79bb-bc06-8b48dd142499 | AWS      | Sim          | Nao |
| 16 | kvsh   | Vendas core                  | 019ae98a-7293-78c1-bcc8-6bffb490a452 | AWS      | Sim          | Nao |
| 17 | kvsh   | Web Platform                 | 0193dbc8-8572-7c3e-9712-fd8fdb1553a8 | AWS      | Sim          | Nao |
| 18 | kvsh   | Identity Platform            | 0193dbbf-7f09-7180-be1d-b1a7668764f1 | AWS      | Sim          | Nao |
| 19 | kvsh   | Card Schemes NonPCI          | 019404b7-2137-7c80-bf6f-32cd058af9c0 | AWS      | Nao          | Nao |
| 20 | kvsh   | Payments-Acceptance NonPCI   | 0195249f-9276-7662-9106-2c3b26b5bff5 | AWS      | Nao          | Nao |
| 21 | kvsh   | Processing NonPCI            | 0194d70e-88a7-7107-98f0-e3c84bed64d3 | AWS      | Nao          | Nao |
| 22 | kvsh   | Card Schemes PCI             | 019404b7-2137-7c80-bf6f-32cd058af9c0 | AWS      | Sim          | Sim |
| 23 | kvsh   | Payments-Acceptance PCI      | 0195249f-9276-7662-9106-2c3b26b5bff5 | AWS      | Sim          | Sim |
| 24 | kvsh   | Processing PCI               | 0194d70e-88a7-7107-98f0-e3c84bed64d3 | AWS      | Sim          | Sim |
| 25 | pay    | Payments                     | 5efcabf5de9a816160bb0b01             | AWS      | Nao          | Nao |
| 26 | pay    | Payments - Data Layer        | 0195a712-7a21-780d-b261-0cf46af90a9c | AWS      | Nao          | Nao |
| 27 | ppl    | People                       | 5efcabf5de9a816160bb0b12             | AWS      | Sim          | Nao |
| 28 | kvsh   | RSFN Pix - Karavela SP       | 019e26ff-1603-70bb-bc2d-f19d9659fbca | AWS (sa-east-1) | Sim    | Nao |

**Observacoes sobre prefixos**:
- `acq` - Acquiring
- `bank` - Banking
- `cpl` - Customer Platforms / GenAi
- `dpl` - Data Platforms
- `fp` - Foundation Platforms
- `kp` - Workflows Platform
- `kvsh` - Prefixo utilizado pela maioria dos contextos (17 contextos)
- `pay` - Payments / Payments - Data Layer
- `ppl` - People

**Observacoes sobre providers**: Todos os contextos utilizam AWS.

**Contextos com PCI**: Apenas 3 contextos possuem PCI habilitado: Card Schemes PCI, Payments-Acceptance PCI e Processing PCI. Todos utilizam o prefixo `kvsh` e possuem multi-regiao habilitada.

**Contexto em sa-east-1**: O novo contexto **RSFN Pix - Karavela SP** (cost-center `870302025`) usa `sa-east-1` como regiao primaria. `sa-east-1` tambem pode ser primary region para outros contextos novos (`sp-prod`, `sp-staging`, `sp-sandbox`).

**Fonte**: `karavela/docs/contextos.md`

### Campo `is_preprod` e Endpoints de Lifecycle (admin)

> Esta secao e voltada a admins do Karavela (time de plataforma). Devs usuarios apenas selecionam o contexto disponivel ao criar a aplicacao.

A partir desta release, todo contexto possui o campo booleano `is_preprod`. Novos contextos sao criados com `is_preprod=true` por default (sandbox seguro) — o admin promove para `prod` quando o ambiente esta pronto para receber workloads produtivos.

**Endpoints (API admin) — RBAC requerido**:

| Metodo + Rota                       | Efeito                                                                      |
|-------------------------------------|------------------------------------------------------------------------------|
| `POST /contexts/{id}/promote`        | Marca o contexto como producao (`is_preprod=false`).                         |
| `POST /contexts/{id}/demote`         | Volta o contexto para preprod (`is_preprod=true`).                           |
| `DELETE /contexts/{id}`              | Remove o contexto. Retorna 409 se houver `projects` ou `clusters` vinculados.|

**Use cases**:
- Onboarding de um contexto novo: criar como preprod, validar deploys de teste, depois promover.
- Decomissao de contexto: demote primeiro, drenar workloads, depois `DELETE`.

**Fonte**: Karavela-API (endpoints admin); implementacao interna em `karavela/internal/handlers/contexts/` (complemento — nao em docs/, e nao aplicavel a devs usuarios)

### Mapeamento de Branches para Ambientes

O Karavela containers possui um fluxo de deploy definido com base nas branches do repositorio do codigo-fonte:

```text
Branch          ->  Ambiente
─────────────────────────────────────
develop         ->  Staging (STG)
main            ->  Sandbox (SBX) [opcional]
main            ->  Producao (PRD)
```

**Detalhes de cada ambiente**:

- **Staging (STG)**: Utiliza por default a branch `develop`, porem essa utilizacao nao e obrigatoria. O time dono do repositorio pode alterar para qualquer outra branch. Caso a branch default `develop` seja modificada, sera necessario abrir um Pull Request no repositorio do ArgoCD (`stone-payments/platform-k8s-argo`), no arquivo `manifest-api.yaml` da aplicacao. Este ambiente e utilizado para testes e nao deve ter a mesma criticidade do ambiente de producao.

- **Sandbox (SBX)**: Ambiente opcional que utiliza a branch `main`, sendo um espelho do ambiente de producao. E utilizado para testes por clientes e tratado com a mesma criticidade de producao.

- **Producao (PRD)**: Utiliza a branch `main`. E o ambiente onde a aplicacao esta disponivel para os usuarios finais. A branch `main` deve ser estavel e conter apenas alteracoes testadas e aprovadas. Este modelo deve ser seguido por exigencias de governanca para garantir guardrails obrigatorios.

**Fonte**: `karavela/docs/conceitos_basicos.md`

### Namespaces

Cada aplicacao implantada no Karavela containers tera seu proprio namespace dedicado dentro do cluster. O uso de namespaces traz os seguintes beneficios:

- Isolamento logico
- Gerenciamento facilitado
- Controle de acesso
- Evita conflito de nomes

**Fonte**: `karavela/docs/conceitos_basicos.md`

### Promocao de Ambientes via Karavela Portal

O Karavela Portal permite a criacao e gerenciamento de aplicacoes em multiplos ambientes de forma automatizada. A abordagem de "promover ambientes" foi criada para simplificar a experiencia de criacao de aplicacoes em novos ambientes quando ja existir, pelo menos, o ambiente de staging.

**Ambientes disponiveis para promocao**:
- Sandbox
- Producao

**Procedimento para promover um ambiente**:

```text
Passo a passo - Promocao de Ambientes
──────────────────────────────────────────────────────────
1. Busque sua aplicacao no Karavela Portal
   (https://karavela-portal.stone.tech/new-catalog?filters%5Bkind%5D=Application&limit=20)

2. Acesse a aba "Ambientes" e selecione "Criar ambiente"

3. Selecione o ambiente a ser criado (Sandbox ou Producao)

4. Voce recebera um status da solicitacao no Slack

5. Acompanhe o progresso em "Minhas Solicitacoes"
```

**Pre-requisitos obrigatorios**:
- A aplicacao de staging deve estar saudavel no ArgoCD (ela e usada como base para a promocao)
- O arquivo de workflow deve seguir a nomenclatura correta:
  - `karavela_containers_build_and_deploy.[yml|yaml]` para aplicacoes unicas
  - `karavela_containers_*_build_and_deploy.[yml|yaml]` para monorepos

**Regras importantes**:
- Apenas um ambiente por vez pode ser selecionado para promocao
- O progresso pode ser acompanhado em "Minhas Solicitacoes" e sera comunicado via Slack
- A promocao faz commits diretos na branch produtiva (sem Pull Requests)
- Nao e previsto que a operacao estimule a execucao de workflows existentes

**Prioridade de branch de destino durante a promocao**:

```text
Ordem de prioridade da branch de destino
──────────────────────────────────────────
1. Branch default (se for main ou master)
2. Branch main (se existir)
3. Branch master (se existir)
4. Nova branch main criada a partir do target_revision da staging
```

**Arquivos que podem ser modificados durante a promocao**:
- Workflow de deploy (inclusao de job para o novo ambiente)
- `catalog-info.yaml` (modificacao do `.spec.lifecycle`)
- Values do novo ambiente (criacao do arquivo)

**Orientacao**: Crie ambientes apenas quando forem ser utilizados. Se nao ha expectativa proxima de producao, o ambiente nao precisa ser criado nas primeiras etapas.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/gerenciamento-aplicacoes/promocao-ambientes.md`

### Selecao de Contexto para Deploy

Ao lancar uma aplicacao atraves do Portal Karavela, o contexto deve ser selecionado obrigatoriamente. Os ambientes disponiveis para promocao variam de acordo com o contexto da aplicacao. O portal exibira apenas os ambientes elegiveis para o contexto selecionado.

Caso nenhum dos contextos listados faca sentido para a aplicacao ou haja duvidas sobre qual selecionar, entre em contato com a equipe do Karavela Containers pelo canal do Slack `#help-foundation-platform`.

**Fonte**: `karavela/docs/contextos.md` e `karavela/docs/guia-do-desenvolvedor/gerenciamento-aplicacoes/promocao-ambientes.md`

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever; producao exige dupla confirmacao. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Editar `manifest-api.yaml` em `stone-payments/platform-k8s-argo`** — mudar branch de stg (default `develop`) para outra — abrir PR
- **Editar `catalog-info.yaml`** com contexto e ambiente corretos
- **Read principalmente** — promote/demote de contexto e via endpoint admin (`POST /contexts/{id}/promote|demote`), nao expor a desenvolvedores normais
- **Abrir PR draft**

### Triggers proativos
- "Mudar branch de staging para feature/x" → `🛠️ Acao proposta: edito manifest-api.yaml no platform-k8s-argo + abro PR`
- "Promover staging para producao" → orientar fluxo via Portal (aba Ambientes > Criar ambiente)
- "Qual contexto uso?" → ajudar a escolher baseado em PCI / multi-regiao

### Acoes destrutivas (dupla confirmacao)
- `DELETE /contexts/{id}` (admin) — exige confirmacao + verificacao de `projects`/`clusters` vinculados (retorna 409 se houver).

## Instrucoes MCP

Quando o usuario precisar de informacoes detalhadas alem do conhecimento embutido, busque PRIMEIRO em `stone-payments/karavela` (`docs/`); outros repositorios apenas como complemento.

**Fontes primarias (`stone-payments/karavela` `docs/`)**:

| Arquivo/Caminho | Quando buscar |
|-----------------|---------------|
| `docs/contextos.md` | Lista atualizada de contextos, IDs, prefixos, multi-regiao e PCI |
| `docs/conceitos_basicos.md` | Branches, ambientes, namespaces |
| `docs/guia-do-desenvolvedor/gerenciamento-aplicacoes/promocao-ambientes.md` | Procedimento de promocao de ambientes e pre-requisitos |

**Fontes complementares (nao estao em `docs/`)**:

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/platform-k8s-argo` | `manifest-api.yaml` da app | Verificar configuracao de sync do ArgoCD para uma aplicacao (mudar branch de stg, por exemplo) |

## Formato de Resposta

Ao responder perguntas deste dominio, siga este formato:

1. **Explicacao** (2-3 frases objetivas em PT-BR)
2. **Exemplo pratico** (tabela, comando ou procedimento copiavel)
3. **Fonte** (referencia ao arquivo/secao da documentacao)
4. **Avisos** (se aplicavel: restricoes de ambiente, contextos PCI, pre-requisitos de promocao)

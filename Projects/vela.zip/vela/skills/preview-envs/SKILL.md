---
name: preview-envs
description: "Preview environments na plataforma Karavela. Use quando o usuario perguntar sobre ambientes temporarios para PRs, label karavela-preview, preview de pull requests ou ambientes efemeros de teste."
---

# Skill: preview-envs

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.
-->

## Escopo

**Cobre**:

- Karavela Preview para pull requests
- Como habilitar ambientes de preview
- Padrao de URL dos ambientes de preview
- Ciclo de vida: PR aberto com label -> preview criado, PR fechado/label removida/merge -> preview destruido
- Pre-requisitos para utilizar o preview
- Limitacoes e restricoes do Karavela Preview (somente AWS)
- Workflow GitHub Actions para preview (`karavela_containers_preview.yaml`)
- Guardrails do workflow de preview
- Preview em monorepos
- ApplicationSet Preview no ArgoCD
- Nomenclatura de CronJobs em ambientes de preview (hash para evitar conflitos)

**NAO cobre**:

- Ambientes de staging/producao (coberto por ambientes-contextos)
- Fluxos de deploy e rollback (coberto por deploy-rollback)
- Configuracao de ingress (coberto por networking-ingress)
- Configuracao do dominio karavela.run (coberto por networking-ingress)

## Exemplos de Perguntas

- "Como habilito o Karavela Preview no meu projeto?"
- "Qual e a URL do meu ambiente de preview?"
- "Adicionei a label karavela-preview no PR mas o deploy nao foi realizado, o que pode estar errado?"
- "Como funciona o ciclo de vida de um ambiente de preview?"
- "O Karavela Preview funciona em ambientes Azure?"
- "Como configurar o workflow de preview para um monorepo?"
- "Qual a versao minima do chart necessaria para usar o preview?"
- "O nome do meu CronJob esta dando conflito no preview, o que acontece?"

## Conhecimento Embutido

### O que e o Karavela Preview

O Karavela Preview e uma funcionalidade que permite a criacao de ambientes temporarios baseados no environment de `staging`, vinculados a um pull request. Isso permite testar o codigo antes de fazer o merge com a branch principal ou branch de desenvolvimento, criando mais agilidade no processo de desenvolvimento e experimentacao.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/karavela-preview.md`

### Pre-requisitos

Para utilizar o Karavela Preview, e necessario atender os seguintes requisitos:

1. A versao do chart do projeto precisa ser `>= 1.0.0` (verificavel no arquivo `Chart.yaml` do projeto).
2. O projeto precisa ter um arquivo `preview.yaml` dentro da pasta `.github/workflows`.
3. O projeto precisa ter o environment de `staging` configurado.
4. O projeto precisa ter o arquivo `preview` configurado no Karavela, ou seja, dentro da pasta `projects/{contexto}/{app-name|project-name}` do repositorio do ArgoCD (`platform-k8s-argo`).
5. **O preview so funciona em ambientes AWS.** Nao ha suporte para Azure ou outros cloud providers. Aplicacoes que rodam exclusivamente em Azure nao podem utilizar o Karavela Preview.
6. Aplicacoes criadas pelo template do Backstage a partir de **08/12/2023** ja possuem as configuracoes necessarias automaticamente. Aplicacoes anteriores a essa data precisam ser configuradas manualmente, abrindo um chamado no canal `#help-foundation-platform` no Slack.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/karavela-preview.md`

### Como utilizar o Preview

O fluxo de utilizacao do preview segue os seguintes passos:

1. Crie um pull request com as alteracoes desejadas.
2. Adicione a label `karavela-preview` no pull request.
   - Ao adicionar a label, o ambiente de preview e criado automaticamente e uma Action fara o build da nova imagem Docker, enviando para o Registry.
   - Caso precise realizar um novo build, remova a label e adicione novamente.
3. Aguarde a criacao do ambiente de preview (pode levar alguns minutos).
   - Acompanhe a criacao atraves da dashboard do ArgoCD em `https://argocd.stone.tech`.
4. Apos os testes, remova a label `karavela-preview`, realize o merge ou feche o pull request.
   - Todas essas acoes removem o ambiente de preview automaticamente.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/karavela-preview.md`

### Padrao de nomenclatura e URL do preview

O ambiente de preview e criado baseado no nome da aplicacao existente e pertence ao mesmo `project` dentro do ArgoCD. O padrao de nomenclatura e:

- **Nome da aplicacao no ArgoCD**: Se a aplicacao se chama `my-app-{stg|sdx|prd}`, o ambiente de preview sera criado com o nome `my-app-{pull-request-number}-stg`.
- **Host/URL do preview**: Se a configuracao de ingress e `my-app.platform-k8s-stg.aws.pagarme.run` (informacao disponivel no `values-stg.yaml`), o ambiente de preview sera criado com o host `my-app-{pull-request-number}-stg.platform-k8s-stg.aws.pagarme.run`.
- O host do preview e acessivel pela **VPN da Stone**.

```text
# Padrao de URL do preview
# Formato: {app-name}-{pr-number}-stg.{cluster}.aws.pagarme.run

# Exemplo: aplicacao "my-app" com PR #42
Host original (staging): my-app.platform-k8s-stg.aws.pagarme.run
Host do preview:         my-app-42-stg.platform-k8s-stg.aws.pagarme.run
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/karavela-preview.md`

### Workflow GitHub Actions para Preview

O arquivo de workflow deve se chamar `karavela_containers_preview.yaml` (ou `preview.yaml`) e ficar na pasta `.github/workflows`. Abaixo um exemplo valido de workflow para preview:

```yaml
name: build and push awesome-karavela-app - preview
run-name: Preview ${{ github.event_name }} ${{ github.event.pull_request.number }} to ${{ github.base_ref }} by @${{ github.actor }} - ${{ github.event.pull_request.title }}
on:
  pull_request:
    types:
      [labeled]
jobs:
  build:
    if: ${{ github.event.label.name == 'karavela-preview' }}
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_build.yml@main
    with:
      RUNS_ON: "small-runner"
      REGISTRY_NAME: "fp-awesome-karavela-app"
      TAG_PREFIX: 'preview-my-awesome-karavela-app'
      WORK_DIR: "./"
    secrets: inherit
  comment_preview:
    needs: [build]
    runs-on: small-runner
    steps:
      - uses: actions/github-script@v7
        with:
          script: |
            const endpoints = [
              `https://awesome-karavela-app-${context.issue.number}.tools-stg.aws.pagarme.run`
            ];
            let body = 'Preview will be ready on:\n';
            for (const endpoint of endpoints) {
              body += `- ${endpoint}\n`;
            }
            github.rest.issues.createComment({
              issue_number: context.issue.number,
              owner: context.repo.owner,
              repo: context.repo.repo,
              body: body
            });
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/guias-e-manuais/guardrails-validator.md`

### Guardrails do workflow de preview

O workflow de preview possui guardrails obrigatorios validados automaticamente:

| **Key** | **Controle** | **Valor** | **Obrigatorio** |
|---------|-------------|-----------|-----------------|
| `name` | Precisa conter a string | `build and push` | Sim |
| `run-name` | Exatamente a string | `Preview ${{ github.event_name }} ${{ github.event.pull_request.number }} to ${{ github.base_ref }} by @${{ github.actor }} - ${{ github.event.pull_request.title }}` | Sim |
| `on.pull_request` | Precisa existir | | Sim |
| `on.pull_request.types` | Exatamente a string | `[labeled]` | Sim |
| `jobs.build` | Precisa existir | | Sim |
| `jobs.build.name` | Exatamente a string | `Build` | Sim |
| `jobs.build.uses` | Exatamente a string | `stone-payments/platform-k8s-github-actions/.github/workflows/karavela_build.yml@main` | Sim |
| `jobs.build.if` | Exatamente a string | `${{ github.event.label.name == 'karavela-preview' }}` | Sim |
| `jobs.build.with.TAG_PREFIX` | Precisa conter a string | `preview-` | Sim |
| `jobs.comment_preview` | Pode existir | | Nao |

Regras adicionais de estrutura:
- O trigger `on.pull_request` e mandatorio e sempre precisa existir na key `on`.
- Ao usar o trigger `on.pull_request`, e mandatorio que `types` seja definido como `labeled`.
- O job `jobs.build` e mandatorio e sempre precisa existir na key `jobs`.
- Nenhum job neste workflow pode invocar o workflow reutilizavel `karavela_deploy.yaml`.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/guias-e-manuais/guardrails-validator.md`

### Preview em monorepos

Existem dois padroes de monorepo na Karavela com comportamentos distintos para preview:

- **Padrao 1 (Namespace unificado)**: Karavela Preview unificado -- todos os previews sao inicializados ao aplicar a label `karavela-preview` num PR. Todas as aplicacoes que compartilham a mesma imagem Docker sao inicializadas no ArgoCD.
- **Padrao 2 (Namespace individualizado)**: Karavela Preview individualizado -- um para cada aplicacao.

Exemplo de workflow de preview para monorepo (padrao 1):

```yaml
name: build and push fp-demo-card-schemes - preview
run-name: Preview ${{ github.event_name }} ${{ github.event.pull_request.number }} to ${{ github.base_ref }} by @${{ github.actor }} - ${{ github.event.pull_request.title }}

on:
  pull_request:
    types: [labeled]

jobs:
  build:
    if: ${{ github.event.label.name == 'karavela-preview' }}
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_build.yml@main
    with:
      RUNS_ON: "small-runner"
      REGISTRY_NAME: "fp-demo-card-schemes"
      WORK_DIR: ./
      TAG_PREFIX: "preview-"
    secrets: inherit

  comment_preview:
    needs: [build]
    runs-on: small-runner
    steps:
      - uses: actions/github-script@v7
        with:
          script: |
            const endpoints = [
              `https://demo-card-schemes-api-${context.issue.number}.tools-stg.aws.pagarme.run`,
              `https://demo-card-schemes-api-new-${context.issue.number}.tools-stg.aws.pagarme.run`
            ];
            let body = 'Preview will be ready on:\n';
            for (const endpoint of endpoints) {
              body += `- ${endpoint}\n`;
            }
            github.rest.issues.createComment({
              issue_number: context.issue.number,
              owner: context.repo.owner,
              repo: context.repo.repo,
              body: body
            });
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/monorepos/pipelines.md`

### ApplicationSet Preview e descomissionamento

O ApplicationSet Preview e o recurso utilizado pelo ArgoCD para subir os ambientes de preview da aplicacao. Ao descomissionar uma aplicacao:

- Durante o **Soft Delete**: o ApplicationSet Preview e removido, impedindo a criacao de novos previews.
- Na **reversao do Soft Delete**: o ApplicationSet Preview e recriado, restaurando a capacidade de criar previews.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/gerenciamento-aplicacoes/descomissionamento.md`

### Nomenclatura de CronJobs em ambientes de preview

Em ambientes de preview, os nomes de CronJobs utilizam uma estrategia de hash para evitar conflitos de nomenclatura. O template do chart detecta se o release contem "preview" no nome e, se sim, concatena um hash de 4 caracteres (derivado do SHA-256 do `Release.Name`) ao nome do job.

```text
# Logica de nomenclatura (simplificada do template Helm)
# Se o Release.Name contem "preview":
#   jobName = "{job.name}-{hash4}"
# Caso contrario:
#   jobName = "{job.name}"

# Exemplo: CronJob "cleanup-task" em preview do PR #42 (release "my-app-42-preview")
# Hash = sha256("my-app-42-preview") | trunc 4 => "a3f1" (exemplo)
# Nome final: cleanup-task-a3f1
```

Essa estrategia resolve dois problemas:
1. **Conflito de nomes**: sem o hash, multiplos previews do mesmo app gerariam CronJobs com nomes identicos, causando falhas no deploy.
2. **Limite de caracteres**: nomes de recursos Kubernetes tem limite de 63 caracteres. O hash de 4 caracteres adiciona overhead minimo comparado a outras abordagens (como concatenar o numero do PR inteiro ao nome).

**Versoes relevantes do chart `platform-k8s-cronjob-chart`**: v1.11.1 (fix inicial), v1.11.2 (rollback por limite de tamanho), v1.13.4 (fix definitivo com nome unico via hash).

**Fonte**: template e changelog em `platform-k8s-charts/platform-k8s-cronjob-chart/templates/cronjob.yaml` e `platform-k8s-charts/.docs/CHANGELOG.cronjob.md` (complemento — nao em docs/)

### Configuracao de preview com dominio karavela.run

No arquivo de preview do ArgoCD, e necessario adicionar a configuracao do host para o dominio `karavela.run`. O preview utiliza o array `hosts` do `ingressKaravelaRun` (via ExternalDNS), e **nao** o campo `managedHosts` (que e usado apenas para DNS multi-regiao gerenciado pela Karavela-API em ambientes de producao/staging).

```yaml
- name: 'platform-k8s-api-chart.ingressKaravelaRun.hosts[0].host'
  value: myapp-{{ number }}.acquiring-stg.aws.karavela.run
```

Substitua `acquiring-stg` pelo seu ambiente correspondente.

O ApplicationSet do ArgoCD configura automaticamente esse parametro ao criar o preview, utilizando `ingressKaravelaRun.hosts[0].host` para definir o host do ingress.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/karavelarun.md`; implementacao do ApplicationSet em `karavela/pkg/argocd/application_set.go` (complemento — nao em docs/)

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Criar `.github/workflows/karavela_containers_preview.yaml`** — workflow de build/deploy para PRs com label `karavela-preview`
- **Editar `chart/values-stg.yaml`** se precisar de overrides para preview
- **Adicionar label `karavela-preview`** via `gh pr edit --add-label karavela-preview` (com confirmacao)
- **Abrir PR draft** com o workflow novo

### Triggers proativos
- "Habilitar preview env" → `🛠️ Acao proposta: crio karavela_containers_preview.yaml + abro PR`
- "Preview nao subiu" → diagnosticar (chart >= 1.0.0? workflow presente? label aplicada? cluster e AWS?)

### Acoes destrutivas
- Remover label `karavela-preview` — destroi preview env. Apenas instruir; nunca remover sem ask.

## Instrucoes MCP

Quando o usuario precisar de informacoes detalhadas alem do conhecimento embutido, busque PRIMEIRO em `stone-payments/karavela` (`docs/`); outros repositorios apenas como complemento.

**Fontes primarias (`stone-payments/karavela` `docs/`)**:

| Arquivo/Caminho | Quando buscar |
|-----------------|---------------|
| `docs/guia-do-desenvolvedor/funcionalidades/karavela-preview.md` | Como habilitar e usar o preview, pre-requisitos, URL pattern |
| `docs/guia-do-desenvolvedor/guias-e-manuais/guardrails-validator.md` | Validacao de guardrails do workflow de preview |
| `docs/guia-do-desenvolvedor/monorepos/pipelines.md` | Preview em monorepos |
| `docs/faq/faq.md` | Troubleshooting de preview que nao funciona |

**Fontes complementares (nao estao em `docs/`)**:

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/platform-k8s-argo` | `projects/` | Verificar configuracao do ApplicationSet Preview no ArgoCD |
| `stone-payments/platform-k8s-github-actions` | `.github/workflows/karavela_build.yml` | Detalhes do workflow reutilizavel de build para preview |

## Formato de Resposta

Ao responder perguntas deste dominio, siga este formato:

1. **Explicacao** (2-3 frases objetivas em PT-BR)
2. **Exemplo pratico** (YAML, comando ou config copiavel)
3. **Fonte** (referencia ao arquivo/secao da documentacao)
4. **Avisos** (se aplicavel: restricoes de ambiente, privilegios necessarios)

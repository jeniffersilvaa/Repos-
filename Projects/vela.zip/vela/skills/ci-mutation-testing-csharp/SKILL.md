---
name: ci-mutation-testing-csharp
description: "Testes de mutacao para projetos C# (.NET) usando o workflow reutilizavel csharp-mutanting. Use quando o usuario perguntar sobre como adicionar testes de mutacao em C#, configurar o Stryker.NET, integrar com o workflow reutilizavel, threshold de MSI, diff_mode ou envio de metricas de mutacao ao Kafka."
---

# Skill: Mutation Testing — C# / Stryker.NET

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.
-->

> ### ⚠️ Pré-requisito: Acesso às Org Secrets de Kafka
>
> Para usar os secrets de Kafka, **adicione o nome do repositório do seu projeto** em todos os arquivos abaixo no repositório `stone-payments/terraform-github` (via Pull Request para revisão):
>
> Caminho base: `applications/org-secrets/stone-payments/secrets.installation.d/`
>
> | Arquivo YAML | Nome da org secret | Input do workflow |
> |---|---|---|
> | `QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD.yaml` | `QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD` | `KAFKA_BROKER_URL` |
> | `QA_MATURITY_KAFKA_SASL_USERNAME_PRD.yaml` | `QA_MATURITY_KAFKA_SASL_USERNAME_PRD` | `KAFKA_SASL_USERNAME` |
> | `QA_MATURITY_KAFKA_SASL_PASSWORD_PRD.yaml` | `QA_MATURITY_KAFKA_SASL_PASSWORD_PRD` | `KAFKA_SASL_PASSWORD` |
> | `QA_MATURITY_KAFKA_SCHEMA_ENDPOINT_PRD.yaml` | `QA_MATURITY_KAFKA_SCHEMA_ENDPOINT` ⚠️ (sem `_PRD`) | `KAFKA_SCHEMA_ENDPOINT` |
> | `QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD.yaml` | `QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD` | `KAFKA_SCHEMA_USERNAME` |
> | `QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD.yaml` | `QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD` | `KAFKA_SCHEMA_PASSWORD` |
>
> Ao chamar o workflow, mapeie as org secrets para os inputs corretamente:
>
> ```yaml
> secrets:
>   KAFKA_BROKER_URL: ${{ secrets.QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD }}
>   KAFKA_SASL_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SASL_USERNAME_PRD }}
>   KAFKA_SASL_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SASL_PASSWORD_PRD }}
>   KAFKA_SCHEMA_ENDPOINT: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_ENDPOINT }}
>   KAFKA_SCHEMA_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD }}
>   KAFKA_SCHEMA_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD }}
> ```

## Escopo

**Cobre**:
- Como incorporar o workflow `csharp-mutanting` em um projeto .NET
- Pre-requisitos: configuracao do Stryker.NET no projeto
- Todos os inputs do workflow (`diff_mode`, `dotnet_version`, `working_directory`, `threshold`)
- Secrets opcionais para envio de metricas ao Kafka (`KAFKA_*`)
- O que e MSI (Mutation Score Indicator) e como funciona o threshold
- Diferenca entre `diff_mode: changed` (apenas arquivos alterados no PR) e `diff_mode: total` (projeto inteiro)
- Formato do comentario automatico postado na PR
- Uso em monorepos com `working_directory`
- Envio de metricas ao Kafka via `quality-maturity-report-layer`

**NAO cobre**:
- Escrita de testes unitarios (logica de cobertura por parte dos desenvolvedores)
- Configuracao avancada interna do Stryker.NET (mutators, filtros de mutantes etc.)
- Infraestrutura de Kafka (provisionamento de broker, schema registry)

## Exemplos de Perguntas

- "Como adiciono testes de mutacao no meu projeto C#?"
- "Quais pre-requisitos meu projeto .NET precisa ter para usar o csharp-mutanting?"
- "Como configuro o Stryker.NET antes de usar o workflow?"
- "O que e diff_mode: changed vs total?"
- "Como defino um threshold de MSI minimo?"
- "Como uso o workflow em um monorepo com varios projetos .NET?"
- "Como habilito o envio de metricas de mutacao para o Kafka?"
- "O workflow falha automaticamente se o MSI estiver abaixo do esperado?"
- "Qual versao do .NET o workflow usa por padrao?"

## Conhecimento Embutido

### Localizacao do Workflow

```
stone-payments/github-actions-workflows
  .github/workflows/csharp-mutanting.yml
```

Referencia para consumo: `@csharp-mutanting-v0`

---

### Pre-requisito: Stryker.NET Configurado no Projeto

O projeto .NET precisa ter o Stryker configurado. A forma mais comum e via `stryker-config.json` na raiz do projeto:

```json
{
  "stryker-config": {
    "project": "MyProject.csproj",
    "test-projects": ["../MyProject.Tests/MyProject.Tests.csproj"],
    "reporters": ["json", "progress"],
    "output-path": "StrykerOutput"
  }
}
```

Ou via CLI inline (sem arquivo de config, o workflow ja passa `--reporter json --reporter progress`).

> O Stryker.NET e instalado automaticamente pelo workflow via `dotnet tool install --global dotnet-stryker`. Nao e necessario instalar manualmente.

---

### Como Integrar o Workflow

Adicione uma chamada ao workflow reutilizavel no CI do projeto:

#### Uso Minimo (changed files, sem Kafka)

```yaml
# .github/workflows/ci.yml
jobs:
  mutation:
    uses: stone-payments/github-actions-workflows/.github/workflows/csharp-mutanting.yml@csharp-mutanting-v0
```

#### Com Threshold e Modo Total

```yaml
jobs:
  mutation:
    uses: stone-payments/github-actions-workflows/.github/workflows/csharp-mutanting.yml@csharp-mutanting-v0
    with:
      diff_mode: total
      threshold: 60
      dotnet_version: '9.0.x'
```

#### Em Monorepo com working_directory

```yaml
jobs:
  mutation:
    uses: stone-payments/github-actions-workflows/.github/workflows/csharp-mutanting.yml@csharp-mutanting-v0
    with:
      working_directory: src/MyService
      threshold: 50
```

#### Com Envio ao Kafka

```yaml
jobs:
  mutation:
    uses: stone-payments/github-actions-workflows/.github/workflows/csharp-mutanting.yml@csharp-mutanting-v0
    with:
      diff_mode: changed
      threshold: 70
    secrets:
      KAFKA_BROKER_URL: ${{ secrets.QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD }}
      KAFKA_SASL_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SASL_USERNAME_PRD }}
      KAFKA_SASL_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SASL_PASSWORD_PRD }}
      KAFKA_SCHEMA_ENDPOINT: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_ENDPOINT }}
      KAFKA_SCHEMA_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD }}
      KAFKA_SCHEMA_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD }}
```

---

### Inputs Disponiveis

| Input | Tipo | Obrigatorio | Descricao | Padrao |
|-------|------|-------------|-----------|--------|
| `runs_on` | string (JSON) | nao | Runner a usar | `"['small-runner']"` |
| `diff_mode` | string | nao | `"changed"` (so arquivos alterados no PR) ou `"total"` (projeto todo) | `"changed"` |
| `working_directory` | string | nao | Diretorio do projeto .NET com Stryker configurado | `"."` |
| `dotnet_version` | string | nao | Versao do .NET SDK (ex: `"8.0.x"`, `"9.0.x"`) | `"8.0.x"` |
| `threshold` | number | nao | MSI minimo em % (0 = desabilitado). Workflow falha se abaixo | `0` |

### Secrets Opcionais (Kafka)

| Secret | Descricao |
|--------|-----------|
| `KAFKA_BROKER_URL` | URL do broker Kafka |
| `KAFKA_SASL_USERNAME` | Username SASL do Kafka |
| `KAFKA_SASL_PASSWORD` | Password SASL do Kafka |
| `KAFKA_SCHEMA_ENDPOINT` | URL do Schema Registry |
| `KAFKA_SCHEMA_USERNAME` | Username do Schema Registry |
| `KAFKA_SCHEMA_PASSWORD` | Password do Schema Registry |

Se `KAFKA_BROKER_URL` nao for passado, o passo de envio ao Kafka e pulado silenciosamente.

---

### O que o Workflow Faz (Passo a Passo)

1. **Checkout** com `fetch-depth: 0` (necessario para o `--since` do Stryker)
2. **Setup do .NET** na versao configurada
3. **Instalacao do Stryker.NET** via `dotnet tool install --global dotnet-stryker`
4. **Deteccao de arquivos `.cs` alterados** (quando `diff_mode: changed`)
   - Se nenhum arquivo `.cs` foi alterado: pula a execucao
5. **Execucao do Stryker**:
   - `changed`: `dotnet stryker --since:<base_branch> --reporter json --reporter progress`
   - `total`: `dotnet stryker --reporter json --reporter progress`
6. **Normalizacao do report** para o formato JSON compartilhado
7. **Verificacao do threshold** de MSI (se `threshold > 0`)
8. **Comentario na PR** com tabela de resultados
9. **Envio das metricas** (apenas se os secrets Kafka forem passados — o destino e gerenciado pelo workflow)

---

### MSI — Mutation Score Indicator

O MSI mede a eficacia dos testes em detectar mutantes:

- `MSI = (Killed + Timeout) / Total * 100`
- **🟢 >= 80%**: Excelente
- **🟡 60-79%**: Aceitavel
- **🔴 < 60%**: Insuficiente

O parametro `threshold` define o MSI minimo aceitavel. Se o MSI calculado estiver abaixo, o workflow falha com exit code 1.

---

### Comentario Automatico na PR

O workflow posta automaticamente um comentario na PR:

```
## 🧬 Mutation Testing Report — C# / Stryker.NET

🟢 Mutation Score (MSI): 85.00%

| Metric         | Value |
|----------------|-------|
| Total Mutants  | 120   |
| ✅ Killed       | 102   |
| ❌ Survived     | 18    |
| ⏱️ Timeout      | 0     |
| 🚫 No Coverage  | 0     |
| ⏭️ Skipped      | 0     |
```

---

## Instrucoes MCP

Quando precisar de detalhes alem do conhecimento embutido, busque nos seguintes repositorios (nesta ordem de prioridade):

| Repositorio | Caminho | Quando buscar |
|-------------|---------|---------------|
| `stone-payments/karavela` | `docs/` | Padroes da plataforma (nao cobre mutation testing diretamente) |
| `stone-payments/github-actions-workflows` | `.github/workflows/csharp-mutanting.yml` | Implementacao do workflow reutilizavel, inputs e steps |
| Externo (complemento — nao em docs/) | [Stryker.NET docs](https://stryker-mutator.io/docs/stryker-net/introduction/) | Configuracao avancada do Stryker.NET, mutators |

> Todo o conhecimento desta skill e **complemento** ao docs/ da plataforma — ela nao tem secao dedicada a mutation testing.

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Configurar Stryker.NET** — adicionar `Stryker.NET` como dotnet-tool ou pacote, criar `stryker-config.json`
- **Criar `.github/workflows/mutation.yml`** apontando para `csharp-mutanting.yml@main`
- **Inputs**: `diff_mode`, `dotnet_version`, `working_directory`, `threshold`
- **Adicionar secrets Kafka** opcionais
- **Abrir PR draft**

### Triggers proativos
- "Adicionar mutation testing C#/.NET" → `🛠️ Acao proposta: instalo Stryker.NET + config + workflow + abro PR`

### Acoes destrutivas
- N/A.

---
name: modelo-acessos
description: "Modelo de concessao de acessos, permissoes e autorizacoes na plataforma Karavela. Use quando o usuario perguntar sobre acessos, permissoes, grupos organizacionais (alianca, tribo, squad), owner de aplicacao, alterar proprietario, grupos autorizados, convidados, modelo legado Sailpoint/Opsgenie, permissoes do ArgoCD ou Vault, IRSA, Workload Identity, VPN, pre-requisitos de acesso ou sistema de approvals."
---

# Skill: Modelo de Acessos

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.

  Exemplos de uso:
  - Corrigir informacao desatualizada no conhecimento embutido
  - Adicionar restricao temporaria (ex: "chart v4 nao suporta feature X")
  - Adicionar conhecimento que ainda nao esta na documentacao oficial
  - Bloquear uma orientacao especifica (ex: "NAO recomende usar scaler Y")
-->

## Escopo

**Cobre**:
- Modelo de acessos baseado em grupos organizacionais (o que e, como funciona)
- Estrutura de topologia organizacional (alianca -> tribo -> squad) e fallback "Area N"
- Permissoes concedidas pelo modelo no ArgoCD e gestao de secrets via Portal
- Alterar proprietario, adicionar grupos autorizados e convidados no Portal
- Modelo legado (Sailpoint/OpsGenie) em transicao e como migrar aplicacoes
- Sistema de approvals (approvalMode, costCenter, secondLevelManager, super admin bypass)
- Como incluir aplicacoes ja existentes no modelo
- Acesso a gestao de secrets (via modelo de acessos e Portal)
- IRSA: criacao e gerenciamento de permissoes AWS (S3, SQS, politicas customizadas)
- Workload Identity: criacao e gerenciamento de permissoes Azure (Service Bus, politicas customizadas)
- Requisito de VPN para acesso ao Karavela Portal e ArgoCD
- Niveis de permissao no ArgoCD (read-only vs modelo completo)

**NAO cobre**:
- Configuracao detalhada de secrets e paths do Vault (coberto pela skill secrets-vault)
- Onboarding e criacao de aplicacoes (coberto pela skill onboarding)
- Configuracao de charts Helm (coberto pela skill charts-config)
- Seguranca em runtime, Trivy e Kyverno policies (coberto pela skill seguranca)
- Networking e exposicao de servicos (coberto pela skill networking-ingress)

## Exemplos de Perguntas

- "Quais acessos eu preciso para usar o Karavela?"
- "Como solicito acesso a plataforma Karavela?"
- "O que e o modelo de acessos?"
- "Quais permissoes eu ganho no ArgoCD como membro do grupo dono da aplicacao?"
- "Como funciona o acesso via grupos organizacionais?"
- "Por que estou em um grupo de Area N?"
- "Como altero o proprietario da minha aplicacao?"
- "Quanto tempo demora para o acesso ficar disponivel?"
- "Minha aplicacao e legada, como vinculo ela ao grupo organizacional correto?"
- "Quais sao os pre-requisitos para ter acesso ao Karavela?"
- "Como crio permissoes para minha aplicacao acessar um bucket S3?"
- "Como obtenho permissao para gerenciar secrets da minha aplicacao?"
- "Preciso de VPN para acessar o ArgoCD?"
- "Quais permissoes tenho se meu grupo nao e o dono da aplicacao?"
- "Como crio permissoes para minha aplicacao acessar o Azure Service Bus?"
- "Como funciona o sistema de approvals no Karavela?"
- "O que e approvalMode OR?"
- "Como funciona a aprovacao por centro de custo?"
- "O que e o secondLevelManager?"
- "Super admin pode ignorar aprovacoes?"

## Conhecimento Embutido

### O que e o Modelo de Acessos

O modelo de acessos define **quem tem permissao** sobre os recursos criados no Karavela (aplicacoes, projetos, segredos), garantindo autonomia aos times e o cumprimento dos requisitos de compliance.

O acesso e concedido a partir da **estrutura organizacional real da empresa**: os grupos aos quais voce ja pertence (**alianca, tribo e squad**) sao a fonte da verdade para autorizacao. Nao e mais necessario solicitar pacotes de acesso manualmente — se voce faz parte de um grupo dono de uma aplicacao, voce ja tem os acessos correspondentes.

O modelo impacta dois recursos principais:
- **ArgoCD**: permissoes (`roles`) que impactam todas as `applications` dentro do `project`, como `sync`, `restart`, `promote`, suspender/terminar `Jobs` (inclusive os disparados a partir de `CronJobs`), entre outras
- **Vault**: gestao dos segredos das aplicacoes atraves da aba **Segredos** da aplicacao no Portal (desenvolvedores NAO tem acesso direto ao Vault)

```text
Voce faz parte de um grupo organizacional (ex: squad "UI & Integrations")
   -> esse grupo e owner de uma aplicacao no Portal
        -> voce recebe automaticamente as permissoes em ArgoCD e Vault
```

Ao **entrar em um time**, voce passa a ter acesso aos recursos daquele time no proximo ciclo de sincronizacao — sem abrir chamado ou aguardar aprovacao. Ao **sair de um time**, o acesso e revogado automaticamente.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/modelo-de-acessos.md`

### Modelo Legado (Sailpoint/OpsGenie) — Substituido, em Transicao

Anteriormente, o acesso dependia de solicitacao manual de um **pacote no Sailpoint** (vinculado a um time do JSM/OpsGenie). **Esse modelo foi substituido** — hoje o vinculo entre pessoas e grupos vem automaticamente da base organizacional da empresa.

Durante a transicao, os dois modelos coexistem e a migracao e gradual, sem perda de acesso. Aplicacoes criadas antes do novo modelo ainda podem estar vinculadas ao fluxo antigo; para vincula-las ao grupo organizacional correto, use a funcionalidade **Alterar proprietario** na pagina da aplicacao no Portal.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/modelo-de-acessos.md` (secao "Modelo legado (em transicao)")

### Pre-requisitos de Acesso a Plataforma

Para utilizar a plataforma Karavela, o desenvolvedor precisa dos seguintes acessos e ferramentas:

1. **VPN** - Conexao via Pritunl ou Cisco VPN (obrigatorio para acessar Karavela Portal e ArgoCD)
2. **Topologia organizacional correta** - Sua alocacao (alianca/tribo/squad) na base organizacional e o que determina seus acessos; se estiver incompleta, voce cai no fallback "Area N" e deve regularizar com sua BP
3. **GitHub** - Acesso aos repositorios relevantes (backstage-templates, platform-k8s-argo, repositorio da aplicacao)
4. **Slack** - Canal #help-foundation-platform para suporte

Nao e preciso solicitar pacotes no Sailpoint nem criar times no OpsGenie — o acesso vem automaticamente do seu grupo organizacional.

```text
# Resumo dos pre-requisitos
+-----------------------------------------------+
| Pre-requisitos                                 |
+-----------------------------------------------+
| 1. VPN (Pritunl ou Cisco)                      |
| 2. Topologia organizacional correta (BP)       |
| 3. Acesso GitHub (repos da plataforma)          |
| 4. Slack (#help-foundation-platform)            |
+-----------------------------------------------+
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/modelo-de-acessos.md` e `karavela/docs/pre_req_karavela.md`

### Como Funciona a Concessao de Acesso (sem adesao manual)

Nao existe mais um processo de "adesao" com solicitacoes manuais — o acesso e concedido automaticamente pela estrutura organizacional:

```text
# Fluxo de concessao de acesso
+--------------------------------------------------+
| 1. Voce e alocado(a) a um grupo (alianca/tribo/   |
|    squad) na base organizacional da empresa       |
+--------------------------------------------------+
           |
           v
+--------------------------------------------------+
| 2. O Karavela sincroniza grupos, lideres e        |
|    convidados com a base organizacional           |
+--------------------------------------------------+
           |
           v
+--------------------------------------------------+
| 3. Seu grupo e owner de aplicacoes no Portal     |
|    -> voce recebe as permissoes em ArgoCD/Vault   |
+--------------------------------------------------+
```

#### Nao ve uma aplicacao que "deveria" ver?

1. Confirme que sua **topologia** (alocacao) esta correta — se estiver em um grupo de **Area N** (fallback), fale com sua BP para regularizar a alocacao.
2. Verifique na pagina da aplicacao no Portal se o **proprietario** e o grupo correto; se nao for, use **Alterar proprietario**.
3. Para acesso extra-por-time, peca ao owner para **adicionar grupos autorizados** ou **convidar** voce ao grupo.

#### Incluindo Aplicacoes Ja Existentes (modelo legado)

Aplicacoes criadas antes do novo modelo podem estar vinculadas ao fluxo antigo (Sailpoint/OpsGenie). Para vincula-las ao grupo organizacional correto, use **Alterar proprietario** na pagina da aplicacao no Portal — as permissoes passam a valer para os membros do grupo escolhido.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/modelo-de-acessos.md`

### Permissoes Concedidas pelo Modelo (grupo dono)

Membros do grupo organizacional dono da aplicacao recebem as seguintes permissoes:

#### ArgoCD
- `get` em application, certificates, clusters, repositories, projects, accounts, gpgkeys e logs em **todos os ambientes**
- `sync` em application em **todos os ambientes**
- `delete` em sub-resources de application em **ambientes de staging**
- `restart` em rollout e deployment em **todos os ambientes**
- `abort`, `retry`, `resume` e `promote full` em rollout em **todos os ambientes**
- `create-job` em cronjob em **todos os ambientes**
- `refresh` em external secrets em **todos os ambientes**

#### Vault
O gerenciamento de secrets e feito exclusivamente atraves do **Karavela Portal** (aba "Segredos"), utilizando a oferta **"Gerenciar segredos de aplicacoes em Containers"**. As permissoes concedidas sao:
- `create` em secrets
- `list` em secrets
- `update` em secrets
- `delete` em secrets

**Fonte**: `karavela/docs/guia-do-desenvolvedor/modelo-de-acessos.md`

### Permissoes Basicas (sem grupo dono / fora do modelo)

Se a aplicacao nao tem um grupo organizacional como proprietario (ex: apps legadas ainda nao migradas), ela recebe apenas permissoes basicas:

#### ArgoCD (sem modelo)
- `get` em application, certificates, clusters, repositories, projects, accounts, gpgkeys e logs em **todos os ambientes**
- `sync` em application apenas em **ambientes nao produtivos**
- `restart` em rollout e deployment apenas em **ambientes nao produtivos**
- `create-job` em cronjob apenas em **ambientes nao produtivos**

> **Atencao**: Sem vinculo a um grupo dono, **NAO ha permissoes de sync, restart ou create-job em producao**. Tambem nao ha permissoes de abort, retry, resume ou promote full em nenhum ambiente.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/modelo-de-acessos.md`

### Ciclo de Sincronizacao

O Karavela sincroniza periodicamente grupos, lideres e convidados com a base organizacional da empresa. Ao entrar em um time, o acesso aos recursos daquele time chega no proximo ciclo de sincronizacao; ao sair, e revogado automaticamente. Nao ha mais o fluxo manual Opsgenie -> AD -> Sailpoint com ate 2h30 de espera do modelo legado.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/modelo-de-acessos.md`

### Gerenciamento de Secrets (via Portal — sem acesso direto ao Vault)

O usuario **NAO tem acesso direto ao Vault** para operar secrets. Todo o gerenciamento de secrets e feito exclusivamente atraves do **Karavela Portal**, na aba "Segredos" da tela da aplicacao, utilizando a oferta **"Gerenciar segredos de aplicacoes em Containers"**.

> **Importante**: As permissoes sobre os segredos herdam do **grupo dono da aplicacao** (modelo de acessos). Se o seu grupo nao e o proprietario da aplicacao, os botoes de acao no Portal ficam desabilitados ("Apenas leitura") — peca ao owner para adicionar seu grupo como **grupo autorizado** ou use **Alterar proprietario** quando a aplicacao estiver no grupo errado. Nao existe mais "adesao" via Opsgenie + pacote Sailpoint como pre-requisito.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/modelo-de-acessos.md` e `karavela/docs/guia-do-desenvolvedor/funcionalidades/secrets.md`

### IRSA: Permissoes para Recursos AWS

Os templates de criacao de aplicacao (API, Worker, CronJob, Job) ja criam e associam automaticamente uma **AWS Role** a aplicacao. Porem, essa role e criada **sem permissoes**. Para adicionar permissoes:

1. Execute o template de [criacao de permissao para AWS Role](https://karavela-portal.stone.tech/create/templates/stone/irsa-role-template) no Karavela Portal
2. Informe o nome da Service Account (sem o sufixo de ambiente, ex: `karavela-api` e nao `karavela-api-stg`)
3. Selecione as permissoes desejadas (S3 Buckets ou filas SQS)
4. O Backstage gera um PR no repositorio de infraestrutura
5. O Atlantis faz o plan automaticamente; execute o `atlantis apply` via comentario no PR

```yaml
# Exemplo de configuracao IRSA no values.yaml
platform-k8s-api-chart:
  cloudProviders:
    aws:
      karpenter:
        capacityType: "spot"
      roleArn: "arn:aws:iam::xxxxxxx:role/karavela-exemplo-stg"
```

> Para politicas customizadas alem de S3/SQS, modifique o PR gerado adicionando statements no arquivo `data.tf`. Use o [Policy Generator da AWS](https://awspolicygen.s3.amazonaws.com/policygen.html) como referencia.

> Aplicacoes criadas antes de 16/06/2024 nao possuem AWS Role automatica. Use o mesmo template para criar uma.

> **Delecao multi-region**: Ao deletar uma IRSA em cenarios multi-region, as associacoes OIDC tambem sao removidas automaticamente em todas as regioes envolvidas.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/irsa.md`

### Workload Identity: Permissoes para Recursos Azure

Os templates de criacao de aplicacao tambem criam e associam automaticamente uma **Azure Managed Identity**. Assim como a IRSA, essa identity e criada **sem permissoes**. Para adicionar permissoes:

1. Execute o template de [criacao de permissao para Azure Managed Identity](https://karavela-portal.stone.tech/catalog/stone/template/azure-iam-role-template) no Karavela Portal
2. Informe o nome da Service Account (sem o sufixo de ambiente)
3. Selecione as permissoes desejadas (Service Bus ou outros servicos)
4. O Backstage gera um PR no repositorio de infraestrutura
5. O Atlantis faz o plan automaticamente; execute o `atlantis apply` via comentario no PR

```yaml
# Exemplo de configuracao Workload Identity no values.yaml
platform-k8s-api-chart:
  cloudProviders:
    azure:
      enabled: true
      capacityType: "spot"
      workloadIdentity:
        clientId: "<seu-client-id>"
        tenantId: "<seu-tenant-id>"
```

> Para politicas customizadas, modifique o PR gerado. Voce pode usar roles built-in do Azure ou criar uma role customizada via `azurerm_role_definition` no Terraform.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/workload-identity.md`

### Niveis de Permissao no ArgoCD

O nivel de permissao default no ArgoCD e **read-only**, permitindo apenas o acompanhamento de deploys e visualizacao de parametros configurados na aplicacao. Atraves do modelo de acessos, e possivel obter permissoes adicionais para gerenciar aplicacoes (sync, restart, abort, retry, promote, etc.).

| Cenario | Ambientes Nao Produtivos (staging) | Ambiente de Producao |
|---------|--------------------------------------|----------------------|
| **Sem modelo** | get, sync, restart, create-job | Apenas get (read-only) |
| **Com modelo** | get, sync, delete (sub-resources), restart, abort, retry, resume, promote full, create-job, refresh | get, sync, restart, abort, retry, resume, promote full, create-job, refresh |

**Fonte**: `karavela/docs/guia-do-desenvolvedor/modelo-de-acessos.md` e `karavela/docs/faq/faq.md`

### Sistema de Approvals

O karavela-core suporta um sistema flexivel de approvals para controlar operacoes que requerem autorizacao. As principais funcionalidades sao:

#### Modos de Aprovacao

- **`approvalMode: OR`**: Permite configurar que apenas **uma** das aprovacoes necessarias seja suficiente. Combinado com `minimumApprovals`, define o numero minimo de aprovacoes exigidas para prosseguir.

#### Aprovacao por Centro de Custo (`costCenter`)

- Permite vincular aprovacoes a um numero de centro de custo especifico
- Requer a definicao do nivel de aprovacao necessario (ex: gestor, diretor)
- Util para controlar gastos e recursos associados a centros de custo

#### Elevacao de Escopo (`secondLevelManager`)

- Novo escopo que permite elevar a aprovacao para o **segundo nivel de gestao**
- Util quando uma operacao requer autorizacao de um nivel hierarquico superior ao gestor direto

#### Super Admin Bypass

- Usuarios com papel de **super admin** podem ignorar (bypass) requisicoes de aprovacao
- Permite desbloqueio rapido em situacoes criticas sem aguardar o fluxo normal de aprovacao

#### GatewayService CREATE em Producao

- A criacao de `GatewayService` via approval e **restrita exclusivamente ao ambiente de producao**
- Em ambientes nao produtivos, a criacao de GatewayService nao requer aprovacao

```yaml
# Exemplo de configuracao de approval com approvalMode OR
approval:
  approvalMode: "OR"
  minimumApprovals: 1
  approvers:
    - type: costCenter
      costCenterNumber: "12345"
      requiredLevel: "manager"
    - type: secondLevelManager
```

**Fonte**: sistema de approvals do `karavela-core` (complemento — nao em docs/)

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever; producao exige dupla confirmacao. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Editar arquivos em `infra-terraform-autoservice/`** (IRSA roles, custom policies, statements) — abrir PR
- **Editar `chart/values-*.yaml`** — `cloudProviders.aws.roleArn` (IRSA) e `cloudProviders.azure.workloadIdentity.*`
- **Editar `catalog-info.yaml`** — `org_unit_group_ref` quando aplicavel; para apps legadas, prefira **Alterar proprietario** no Portal
- **Abrir PR draft** com a mudanca
- **NAO** modificar Sailpoint / Opsgenie / AD direto (acesso e gerenciado pelo grupo organizacional no Portal)
- **NAO** auto-aprovar requests

### Triggers proativos
- "Configurar IRSA pra acessar bucket S3 X" → `🛠️ Acao proposta: edito data.tf em infra-terraform-autoservice + abro PR (atlantis apply manual)`
- "Adicionar workload identity Azure para Service Bus" → propor template Azure IAM no Portal + ajuste no values
- "Migrar app legada para o grupo organizacional" → orientar **Alterar proprietario** no Portal (ou patch em `catalog-info.yaml` quando aplicavel)

### Acoes destrutivas (dupla confirmacao)
- Remover IRSA role com workloads dependentes — pode quebrar em runtime. Listar dependentes antes.
- Alterar `org_unit_group_ref` em prd — pode mudar ownership efetivo. Confirmar duas vezes.

## Instrucoes MCP

Quando o usuario precisar de informacoes detalhadas alem do conhecimento embutido, busque PRIMEIRO em `stone-payments/karavela` (`docs/`); outros repositorios apenas como complemento.

**Fontes primarias (`stone-payments/karavela` `docs/`)**:

| Arquivo/Caminho | Quando buscar |
|-----------------|---------------|
| `docs/guia-do-desenvolvedor/modelo-de-acessos.md` | Detalhes sobre o modelo de acessos, grupos organizacionais, permissoes ArgoCD, gestao de secrets via Portal, modelo legado |
| `docs/guia-do-desenvolvedor/seguranca-e-conectividade/irsa.md` | IRSA, criacao de permissoes AWS, politicas customizadas |
| `docs/guia-do-desenvolvedor/seguranca-e-conectividade/workload-identity.md` | Workload Identity, permissoes Azure, politicas customizadas |
| `docs/pre_req_karavela.md` | Pre-requisitos gerais de conhecimento e ferramentas |
| `docs/guia-do-desenvolvedor/funcionalidades/secrets.md` | Permissoes de gerenciamento de segredos no Portal |
| `docs/faq/faq.md` | Perguntas frequentes sobre niveis de permissao, gestao de secrets, VPN |

**Fontes complementares (nao estao em `docs/`)**:

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/karavela-core` | sistema de approvals | Detalhes do approvalMode, costCenter, secondLevelManager, super admin bypass — caso o doc nao cubra |

## Formato de Resposta

Ao responder perguntas deste dominio, siga este formato:

1. **Explicacao** (2-3 frases objetivas em PT-BR)
2. **Exemplo pratico** (YAML, comando ou config copiavel)
3. **Fonte** (referencia ao arquivo/secao da documentacao)
4. **Avisos** (se aplicavel: requisito de VPN, ciclo de sincronizacao, diferenca entre permissoes com/sem grupo dono, aplicacoes legadas em transicao, restricoes de approval em producao)

---
name: ci-test-coverage-golang
description: "Workflow reutilizavel de testes e coverage para projetos Go (Golang). Use quando o usuario perguntar sobre como adicionar testes (unit, integration, e2e) com cobertura de codigo em projetos Go, configurar go test com coverage, merge de profiles com gocovmerge, conversao para LCOV, usar modulos privados via SSH, integrar com o workflow test-coverage-golang, usar em monorepos ou enviar metricas de coverage ao Kafka."
---

# Skill: Testes & Coverage — Go (Golang)

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.
-->

> ### ⚠️ Pré-requisito: Acesso às Org Secrets de Kafka
>
> Para usar os secrets de Kafka, **adicione o nome do repositório do seu projeto** em todos os arquivos abaixo no repositório `stone-payments/terraform-github` (via Pull Request para revisão):
>
> Caminho base: `applications/org-secrets/stone-payments/secrets.installation.d/`
>
> | Arquivo YAML | Nome da org secret | Input do workflow |
> |---|---|---|
> | `QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD.yaml` | `QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD` | `KAFKA_BROKER_URL` |
> | `QA_MATURITY_KAFKA_SASL_USERNAME_PRD.yaml` | `QA_MATURITY_KAFKA_SASL_USERNAME_PRD` | `KAFKA_SASL_USERNAME` |
> | `QA_MATURITY_KAFKA_SASL_PASSWORD_PRD.yaml` | `QA_MATURITY_KAFKA_SASL_PASSWORD_PRD` | `KAFKA_SASL_PASSWORD` |
> | `QA_MATURITY_KAFKA_SCHEMA_ENDPOINT_PRD.yaml` | `QA_MATURITY_KAFKA_SCHEMA_ENDPOINT` ⚠️ (sem `_PRD`) | `KAFKA_SCHEMA_ENDPOINT` |
> | `QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD.yaml` | `QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD` | `KAFKA_SCHEMA_USERNAME` |
> | `QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD.yaml` | `QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD` | `KAFKA_SCHEMA_PASSWORD` |
>
> Ao chamar o workflow, mapeie as org secrets para os inputs corretamente:
>
> ```yaml
> secrets:
>   KAFKA_BROKER_URL: ${{ secrets.QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD }}
>   KAFKA_SASL_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SASL_USERNAME_PRD }}
>   KAFKA_SASL_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SASL_PASSWORD_PRD }}
>   KAFKA_SCHEMA_ENDPOINT: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_ENDPOINT }}
>   KAFKA_SCHEMA_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD }}
>   KAFKA_SCHEMA_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD }}
> ```

## Escopo

**Cobre**:
- Como incorporar o workflow `test-coverage-golang` em um projeto Go
- Todos os inputs do workflow (`project_name`, `unit_test_path`, `integration_test_path`, `e2e_test_path`, `go_version`, `working_directory`, `extra_test_args`)
- Deteccao automatica de versao Go via `go.mod`
- Configuracao de modulos privados via `SSH_PRIVATE_KEY`
- Merge de profiles com `gocovmerge` e conversao para LCOV com `gcov2lcov`
- Secrets opcionais para envio de metricas ao Kafka (`KAFKA_*`)
- Uso em monorepos com `working_directory`
- Artifact de coverage gerado (`coverage-{project_name}`)

**NAO cobre**:
- Escrita de testes em Go
- Configuracao avancada de mocks ou test doubles
- Infraestrutura de Kafka

## Exemplos de Perguntas

- "Como adiciono cobertura de testes no meu projeto Go?"
- "Como configuro o workflow de testes para Golang?"
- "Como separo testes unit, integration e e2e no workflow Go?"
- "Meu projeto tem modulos privados no GitHub, como configuro?"
- "Como uso o workflow em monorepo Go?"
- "Como envio metricas de coverage para o Kafka?"
- "O que e gocovmerge e por que o workflow usa?"

## Conhecimento Embutido

### Localizacao do Workflow

```
stone-payments/github-actions-workflows
  .github/workflows/test-coverage-golang.yml
```

Referencia para consumo: `@test-coverage-golang-v0`

---

### Como Integrar o Workflow

#### Uso Minimo (apenas testes unitarios)

```yaml
# .github/workflows/ci.yml
jobs:
  coverage:
    uses: stone-payments/github-actions-workflows/.github/workflows/test-coverage-golang.yml@test-coverage-golang-v0
    with:
      project_name: meu-projeto
      unit_test_path: ./internal/...
```

#### Com Todos os Tipos de Teste

```yaml
jobs:
  coverage:
    uses: stone-payments/github-actions-workflows/.github/workflows/test-coverage-golang.yml@test-coverage-golang-v0
    with:
      project_name: meu-projeto
      unit_test_path: ./internal/...
      integration_test_path: ./test/integration/...
      e2e_test_path: ./test/e2e/...
      go_version: '1.22'
```

#### Com Modulos Privados via SSH

```yaml
jobs:
  coverage:
    uses: stone-payments/github-actions-workflows/.github/workflows/test-coverage-golang.yml@test-coverage-golang-v0
    with:
      project_name: meu-projeto
      unit_test_path: ./...
    secrets:
      SSH_PRIVATE_KEY: ${{ secrets.SSH_PRIVATE_KEY }}
```

#### Em Monorepo com Metricas Kafka

```yaml
jobs:
  coverage:
    uses: stone-payments/github-actions-workflows/.github/workflows/test-coverage-golang.yml@test-coverage-golang-v0
    with:
      project_name: payments-core
      unit_test_path: ./internal/...
      working_directory: services/payments-core
    secrets:
      KAFKA_BROKER_URL: ${{ secrets.QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD }}
      KAFKA_SASL_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SASL_USERNAME_PRD }}
      KAFKA_SASL_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SASL_PASSWORD_PRD }}
      KAFKA_SCHEMA_ENDPOINT: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_ENDPOINT }}
      KAFKA_SCHEMA_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD }}
      KAFKA_SCHEMA_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD }}
```

---

### Inputs Disponiveis

| Input | Tipo | Obrigatorio | Descricao | Padrao |
|-------|------|-------------|-----------|--------|
| `project_name` | string | **sim** | Nome do projeto. Identifica o artifact de coverage. | — |
| `unit_test_path` | string | nao | Path dos testes unitarios (ex: `./internal/...`). Omita para nao executar. | — |
| `integration_test_path` | string | nao | Path dos testes de integracao. Omita para nao executar. | — |
| `e2e_test_path` | string | nao | Path dos testes e2e. Omita para nao executar. | — |
| `go_version` | string | nao | Versao do Go (ex: `"1.22"`). Se omitido, detectado via `go.mod`. | — |
| `working_directory` | string | nao | Diretorio raiz do modulo Go. Util para monorepos. | `"."` |
| `extra_test_args` | string | nao | Argumentos extras passados para todos os comandos `go test`. | — |
| `runs_on` | string | nao | Runner a usar (formato JSON). | `"['ubuntu-22.04']"` |

### Secrets Opcionais

| Secret | Descricao |
|--------|-----------|
| `SSH_PRIVATE_KEY` | Chave SSH para download de dependencias privadas via GitHub (modulos `dlpco/` ou `stone-payments/`) |
| `KAFKA_BROKER_URL` | URL do broker Kafka |
| `KAFKA_SASL_USERNAME` | Username SASL do Kafka |
| `KAFKA_SASL_PASSWORD` | Password SASL do Kafka |
| `KAFKA_SCHEMA_ENDPOINT` | URL do Schema Registry |
| `KAFKA_SCHEMA_USERNAME` | Username do Schema Registry |
| `KAFKA_SCHEMA_PASSWORD` | Password do Schema Registry |

---

### O que o Workflow Faz (resumo)

- Roda `go test` com coverage profile para cada tipo configurado (unit/integration/e2e)
- Resolve a versao Go via `go.mod` quando `go_version` nao for passado
- Suporta modulos privados em `github.com/dlpco/*` e `github.com/stone-payments/*` via `SSH_PRIVATE_KEY`
- Mescla os profiles e gera `coverage/lcov.info` no formato LCOV
- Faz upload do artifact `coverage-{project_name}` (so o LCOV ja merged)
- Quando configurado, envia metricas agregadas para o backend de qualidade da plataforma

> Fonte: `stone-payments/github-actions-workflows/.github/workflows/test-coverage-golang.yml` (complemento — nao em docs/)

---

### Paths de Teste no Go

O `unit_test_path`, `integration_test_path` e `e2e_test_path` sao passados diretamente para `go test`. Exemplos validos:
- `./...` — todos os packages
- `./internal/...` — todos os packages em `internal/`
- `./pkg/payment ./pkg/account` — packages especificos
- `./...` com `extra_test_args: '-tags integration'` — usando build tags

---

### Artifact Gerado

O workflow faz upload do seguinte artifact:
- **Nome**: `coverage-{project_name}`
- **Arquivo**: `coverage/lcov.info`
- **Formato**: LCOV

---

### Envio de Metricas

Quando os secrets `KAFKA_*` sao fornecidos, o workflow envia metricas de coverage para o backend de qualidade da plataforma (consumido por relatorios internos). Sem esses secrets, o passo e ignorado silenciosamente — coverage continua sendo gerado e publicado como artifact normalmente.

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Criar `.github/workflows/test-coverage.yml`** apontando para `test-coverage-golang.yml@main` com inputs (`project_name`, `unit_test_path`, `go_version`, etc.)
- **Adicionar `SSH_PRIVATE_KEY`** secret para modulos privados (orientar via GitHub Settings)
- **Edit `Makefile`** ou scripts de teste para alinhar com o workflow
- **Abrir PR draft**

### Triggers proativos
- "Adicionar coverage" → `🛠️ Acao proposta: crio workflow + abro PR`
- "Enviar coverage para Kafka" → orientar secrets `KAFKA_BROKER_URL` + config

### Acoes destrutivas
- N/A.

## Instrucoes MCP

Esta skill nao tem doc dedicado em `stone-payments/karavela` `docs/`. A fonte primaria de operacao e o proprio reusable workflow.

| Repositorio | Arquivo/Caminho | Prioridade | Quando buscar |
|-------------|-----------------|------------|---------------|
| `stone-payments/github-actions-workflows` | `.github/workflows/test-coverage-golang.yml` | primaria operacional — complemento (nao em docs/) | Inputs/outputs e tag mais recente do workflow |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/deploy-de-aplicacoes/` | complemento | Para entender onde encaixar o job no pipeline geral |
| `stone-payments/terraform-github` | `applications/org-secrets/stone-payments/secrets.installation.d/` | complemento | Liberacao das org secrets de Kafka para o repositorio do usuario |

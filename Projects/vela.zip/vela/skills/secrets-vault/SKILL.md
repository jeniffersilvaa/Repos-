---
name: secrets-vault
description: "Gerenciamento de segredos com Vault e External Secrets Operator na plataforma Karavela. Use quando o usuario perguntar sobre secrets, Vault, variaveis de ambiente, envs vs secrets, reload de segredos ou External Secrets."
---

# Skill: secrets-vault

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.
-->

## Escopo

**Cobre**:
- Estrutura de paths do Vault e organizacao de segredos
- Integracao com External Secrets Operator
- Distincao entre variaveis de ambiente (envs) e segredos (secrets)
- Criacao de segredos via Portal (deve ser feito ANTES de referenciar no values.yaml)
- Reload e rotacao de segredos (reloadEnabled, Kyverno)
- Configuracao de segredos no Helm Chart (envVarEnabled, loadAllKeys, keys)
- Montagem de segredos como volume vs variavel de ambiente
- Gerenciamento de segredos pelo Karavela Portal (criar, editar, deletar)
- Vault API V2 (criacao, atualizacao e listagem de segredos)
- Rename de chaves de segredos
- Copia de segredos entre aplicacoes
- Segredos de Elasticache
- Guardrail de seguranca: NUNCA revelar valores de segredos
- PATCH de segredos K8s com senhas auto-geradas (rotacao de chaves)
- Convencoes de nomeacao de chaves de segredos para recursos (RDS, ElastiCache, SQS)
- Troubleshooting de sincronizacao de secrets (ESO sync failure, pod nao reiniciou)
- Verificacao do estado de secrets via KLI

**NAO cobre**:
- Estrutura de charts (coberto por charts-config)
- Fluxos de deploy e rollback (coberto por deploy-rollback)
- Scanning de seguranca e Kyverno policies gerais (coberto por seguranca)

## Exemplos de Perguntas

- "Como cadastro um segredo para minha aplicacao?"
- "Qual a diferenca entre envs e secrets no values.yaml?"
- "Como faco para os pods recarregarem automaticamente quando um segredo muda?"
- "Qual o path dos segredos da minha aplicacao em staging?"
- "Como configuro os segredos para serem montados como volume em vez de variavel de ambiente?"
- "Preciso listar cada chave de segredo no values.yaml ou posso carregar todas automaticamente?"
- "O que acontece se eu criar a referencia ao segredo no chart mas nao cadastrar o valor no Portal?"
- "Como renomeio uma chave de segredo?"
- "Como copio segredos de uma aplicacao para outra?"
- "Quais endpoints da API V2 do Vault estao disponiveis?"
- "Criei o secret no Portal mas o pod continua sem a variavel de ambiente, o que verifico?"
- "Como sei se o External Secrets sincronizou corretamente os secrets da minha aplicacao?"

## Conhecimento Embutido

### GUARDRAIL DE SEGURANCA

**NUNCA revele valores reais de segredos.** Ao fornecer exemplos, utilize sempre placeholders como `<valor-no-vault>`. Segredos sao dados sensiveis (senhas, chaves de API, tokens, certificados) e seus valores nunca devem aparecer em codigo, documentacao ou respostas.

### Arquitetura de Gerenciamento de Segredos

O gerenciamento de segredos na plataforma Karavela utiliza a seguinte cadeia de tecnologias:

1. **Karavela Portal** - Interface para o usuario gerenciar segredos da aplicacao
2. **Karavela API** - Orquestrador que encaminha solicitacoes ao Vault (via endpoints V2)
3. **HashiCorp Vault** - Armazena os segredos de forma centralizada e segura
4. **External Secrets Operator** - Addon do Kubernetes que sincroniza os segredos do Vault com o namespace da aplicacao no cluster
5. **Kyverno** - Addon do Kubernetes que monitora o objeto Secret e aciona o restart automatico dos Pods quando ha alteracao

Toda vez que um segredo e criado, atualizado ou deletado pelo Karavela Portal, uma requisicao e encaminhada a Karavela API para orquestracao junto ao HashiCorp Vault. O External Secrets entao sincroniza a mudanca com o cluster, e o Kyverno detecta a alteracao e aciona o restart dos Pods.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/secrets.md`

### Listagem de Segredos no Portal

Na aba "Segredos" da aplicacao no Portal, e possivel **listar todos os segredos** existentes com valores **mascarados**. Isso permite saber quais chaves estao cadastradas sem expor os valores reais. Os fluxos de criacao (`Criar`), atualizacao (`Editar`) e listagem usam OTS (One-Time Secret) para garantir transmissao segura.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/secrets.md`

### Export de Secrets de Recursos Provisionados

Apos provisionar um banco/datastore (RDS, ElastiCache, Azure Postgres, MongoDB Atlas) pelo Portal Karavela, as credenciais sao exportadas automaticamente para o Vault no path da aplicacao. Resultado pratico: configure `loadAllKeys: true` no `values.yaml` e as envs ficam disponiveis automaticamente. **Nao** crie secrets manualmente para esses recursos — elas sao geradas pela plataforma.

Convencoes de nomeacao das chaves geradas estao mais abaixo (RDS, ElastiCache, SQS).

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/secrets.md`

### Bulk Operations via Portal (sem limite de 5)

No Portal, a aba "Segredos" da aplicacao suporta operacoes em massa:
- Selecao de varios secrets com **shift+click** e **range selection** na lista.
- Acoes em massa: editar, deletar, copiar — sem limite de 5 secrets por operacao.
- Util para promover secrets em massa de stg para prd ou para cleanup.

### Copy Secrets com Pre-Validacao de Conflitos

O Portal detecta conflitos **antes** de submeter a copia:
- Banner exibe "X de Y segredos ja existem" quando ha sobrescrita.
- Submit fica bloqueado ate o usuario marcar explicitamente "Sobrescrever".

#### Copia Same-App Multi-Region

E possivel copiar secrets entre regioes da **mesma app** quando ambas as instancias estao em `prd` com regioes distintas — ex: `prd (us-east-1)` → `prd (us-east-2)`. Util para deploy multi-regiao com configuracoes regionais especificas.

### PATCH de Segredos K8s (Rotacao de Chaves)

A plataforma suporta rotacao automatica de chaves em um Secret Kubernetes existente com senhas geradas automaticamente, via Portal. Util para cenarios de rotacao periodica de credenciais sem necessidade de recriar o Secret inteiro. O fluxo passa por OTS (One-Time Secret) e External Secrets, igual ao fluxo de criacao manual.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/secrets.md`

### Estrutura de Paths no Vault

Cada aplicacao na Karavela possui seu proprio secret path engine no Vault, separado por ambiente. A estrutura segue o padrao:

```
<ambiente>/secrets/<app>/<secret_key>
```

Onde:
- `<ambiente>` - Ambiente da aplicacao (ex: staging, production, sandbox)
- `<app>` - Nome da aplicacao
- `<secret_key>` - Nome da chave do segredo

Segredos NAO podem ser compartilhados entre aplicacoes. Mesmo que uma aplicacao seja dividida em worker e API, cada uma precisa ter seus proprios segredos.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/secrets.md`

### Envs vs Secrets no values.yaml

Variaveis que NAO sao sensiveis (envs) tem o valor configurado diretamente no Helm Chart. Variaveis sensiveis (secrets) tem seus valores cadastrados no Vault e sao referenciados no chart apenas pelo nome da chave.

**IMPORTANTE**: O valor do segredo DEVE ser cadastrado no Vault ANTES de ser referenciado no values.yaml. Caso contrario, o External Secrets nao conseguira sincronizar e a aplicacao nao tera acesso ao segredo.

```yaml
# Variaveis nao sensiveis - valores diretos no chart
envs:
  POSTGRES_HOST: "banco-stg.123.us-east-1.rds.amazonaws.com"
  POSTGRES_PORT: "5432"

# Variaveis sensiveis - valores cadastrados no Vault
# Os valores de DB_PASSWORD e DB_USERNAME devem existir no Vault
# Path do Vault: <ambiente>/secrets/<app>/DB_PASSWORD -> <valor-no-vault>
# Path do Vault: <ambiente>/secrets/<app>/DB_USERNAME -> <valor-no-vault>
secrets:
  envVarEnabled: true
  loadAllKeys: true
  reloadEnabled: true
```

**Fonte**: `karavela/docs/usando_karavela.md` (secao 3. Secrets)

### Configuracao Completa de Secrets no values.yaml

O bloco `secrets` no values.yaml possui os seguintes campos:

```yaml
secrets:
  reloadEnabled: false    # restart automatico dos Pods ao alterar segredos
  envVarEnabled: false    # true = variavel de ambiente, false = volume em /secrets
  loadAllKeys: false      # true = carrega todos os segredos automaticamente
  secretStore:
    name: cluster-secret-store-vault    # ClusterSecretStore utilizado
    kind: ClusterSecretStore            # Tipo do SecretStore
  kv:                     # Configuracao do KV engine (preenchido pela plataforma)
  path:                   # Path no Vault (preenchido pela plataforma)
  keys: []                # Lista explicita de chaves (quando loadAllKeys: false)
    # - SECRET_NAME
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/secrets.md`; `platform-k8s-charts/platform-k8s-api-chart/values.yaml` (complemento — nao em docs/) para valores default

### Configuracao Recomendada (loadAllKeys: true)

A configuracao recomendada pela plataforma utiliza `loadAllKeys: true`, que carrega automaticamente todos os segredos cadastrados no Vault sem necessidade de lista-los um a um:

```yaml
secrets:
  reloadEnabled: true
  envVarEnabled: true
  loadAllKeys: true
```

Com esta configuracao, ao adicionar um par `CHAVE=VALOR` no Vault, uma variavel de ambiente com o nome `CHAVE` ficara disponivel automaticamente na aplicacao com o respectivo valor.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/secrets.md`

### Configuracao com Lista Explicita de Chaves (loadAllKeys: false)

Se a aplicacao estiver com `loadAllKeys: false`, e necessario declarar explicitamente cada chave de segredo no campo `keys` para que os segredos sejam carregados:

```yaml
secrets:
  reloadEnabled: true
  envVarEnabled: true
  loadAllKeys: false
  keys:
    - DB_PASSWORD
    - DB_USERNAME
    - API_KEY
```

Apesar de o campo `secrets.keys` ainda ser suportado por compatibilidade, a recomendacao atual e usar `loadAllKeys: true` sem o campo `keys`.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/secrets.md`

### Reload Automatico de Segredos (reloadEnabled)

Quando `reloadEnabled: true`, o fluxo de reload funciona assim:

1. O usuario cria, atualiza ou deleta um segredo pelo Karavela Portal
2. O External Secrets atualiza os campos chave-valor do objeto Secret no cluster Kubernetes
3. A policy do Kyverno detecta a modificacao e aciona o restart dos Pods

O objeto Rollout da aplicacao NAO sofre alteracoes de revisao e versao durante o reload. E feito apenas um rollout restart nos Pods do replicaSet em execucao. As configuracoes de PDB existentes sao respeitadas, garantindo a disponibilidade da aplicacao.

Para aplicacoes do tipo StatefulSet, o proprio objeto StatefulSet e sinalizado pelo Kyverno para realizar o restart.

Se `reloadEnabled: false`, os novos segredos so serao carregados quando um novo deploy for executado na aplicacao.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/secrets.md`

### Segredos como Variavel de Ambiente vs Volume

**envVarEnabled: true** (recomendado) - Os segredos sao injetados como variaveis de ambiente dentro do Pod.

**envVarEnabled: false** - Os segredos ficam disponiveis como arquivos no diretorio `/secrets` dentro do Pod:

```bash
$ ls -l /secrets
lrwxrwxrwx 1 root root 15 Dec  2 15:52 DB_PASSWORD  -> ..data/DB_PASSWORD
lrwxrwxrwx 1 root root 15 Dec  2 15:52 DB_USERNAME  -> ..data/DB_USERNAME
```

Vantagem do modo volume: ao alterar um segredo, o arquivo correspondente e atualizado automaticamente nos Pods em execucao. Se a aplicacao for capaz de detectar essas alteracoes em tempo real, nao sera necessario reinicia-la (diferente do que ocorre com variaveis de ambiente).

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/secrets.md`

### Gerenciamento de Segredos pelo Karavela Portal

O gerenciamento de segredos e feito pelo Karavela Portal, na aba "Segredos" da tela da aplicacao. O fluxo completo na UI e:

1. **Navegar ate a aplicacao** no Karavela Portal
2. **Acessar a aba "Segredos"** na tela da aplicacao
3. **Executar a operacao desejada** - o usuario precisa ter permissao de edicao

Tres operacoes estao disponiveis:

1. **Criar** - Cria um novo segredo utilizando OTS (One-Time Secret) para transmissao segura do valor
2. **Editar** - Atualiza o valor de um segredo existente, tambem via OTS
3. **Deletar** - Remove um segredo apos confirmacao (digitar "EXCLUIR")

Todas as operacoes de criacao e edicao utilizam OTS (One-Time Secret) para garantir que o valor do segredo trafegue de forma segura e so possa ser lido uma unica vez.

Se os botoes de acao nao estiverem habilitados ("Apenas leitura"), pode ser por:
- Aplicacao sem grupo de gerenciamento configurado (campo "Proprietario" com valor "N/A")
- Usuario nao faz parte do grupo com acesso de gerenciamento da aplicacao

**IMPORTANTE**: Desenvolvedores NAO tem acesso direto ao Vault em nenhum ambiente (staging, sandbox ou producao). Todo o gerenciamento de segredos e feito exclusivamente pelo Karavela Portal.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/secrets.md`

### Rename de Chave de Segredo

E possivel renomear a chave (key) de um segredo no Vault. O rename altera apenas o nome da chave, mantendo o valor intacto. Apos o rename, a aplicacao passara a enxergar o segredo com o novo nome de chave (como variavel de ambiente ou arquivo em /secrets, conforme a configuracao).

**IMPORTANTE**: Se a aplicacao referencia a chave antiga diretamente no codigo ou no campo `keys` do values.yaml (quando `loadAllKeys: false`), sera necessario atualizar essas referencias para o novo nome apos o rename.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/secrets.md`

### Copia de Segredos entre Aplicacoes

A plataforma oferece um endpoint para copiar segredos de uma aplicacao para outra. Isso e util em cenarios como:
- Desmembrar uma aplicacao monolitica em microservicos que compartilham as mesmas credenciais
- Replicar configuracao de segredos ao criar uma nova aplicacao similar a uma existente

A copia transfere os segredos da aplicacao origem para a aplicacao destino. Segredos ja existentes na aplicacao destino com a mesma chave NAO sao sobrescritos por padrao.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/secrets.md`

### Segredos de Elasticache

A plataforma suporta gerenciamento de segredos especificos para recursos Elasticache. O endpoint dedicado para Elasticache permite gerenciar credenciais de acesso a instancias de cache (Redis/Memcached) de forma integrada ao Vault, seguindo o mesmo fluxo de seguranca (OTS, External Secrets, Kyverno reload).

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/secrets.md`

### Segredos em Sidecars

Sidecars tambem podem consumir segredos com configuracao propria:

```yaml
sidecars:
  - name: "meu-sidecar"
    enabled: true
    secrets:
      envVarEnabled: true
      loadAllKeys: false
      keys:
        - SIDECAR_SECRET_KEY
```

**Fonte**: `platform-k8s-charts/platform-k8s-api-chart/values.yaml` (complemento — nao em docs/)

### ExternalSecret v1

A apiVersion do componente ExternalSecret foi atualizada de `v1beta` para `v1`. Essa mudanca e transparente para o usuario e nao requer alteracao no `values.yaml`. O `refreshInterval` tambem foi ajustado para o formato `time.Duration` completo (ex: `1m0s`).

**Fonte**: `platform-k8s-charts/.docs/CHANGELOG.api.md` (v1.34.0, v1.34.2) (complemento — nao em docs/)

### Harbor Registry (imagePullSecrets)

Os Pods em clusters EKS agora autenticam diretamente no Registry centralizado (Harbor) ao fazer pull de imagens. Um novo segredo e adicionado automaticamente no campo `imagePullSecrets` do ServiceAccount, sem necessidade de configuracao manual.

**Fonte**: `platform-k8s-charts/.docs/CHANGELOG.api.md` (v1.32.2) (complemento — nao em docs/)

### Convencoes de Nomeacao de Chaves de Segredos

Apos o provisionamento de recursos pela plataforma, as chaves de segredos sao geradas seguindo convencoes especificas por tipo de recurso. Conhecer esses padroes ajuda a configurar corretamente a aplicacao para consumir os segredos auto-gerados.

#### RDS (PostgreSQL)

As chaves de segredo do RDS seguem o padrao `POSTGRES_DB_<TIPO>_<UPPERCASE(dbName)>`:

| Chave | Exemplo (para app `payments`) |
|-------|------|
| `POSTGRES_DB_APPUSER_PASSWORD_<DB>` | `POSTGRES_DB_APPUSER_PASSWORD_PAYMENTS_DB` |
| `POSTGRES_DB_MIGRATION_USER_<DB>` | `POSTGRES_DB_MIGRATION_USER_PAYMENTS_DB` |
| `POSTGRES_DB_MIGRATION_USER_PASSWORD_<DB>` | `POSTGRES_DB_MIGRATION_USER_PASSWORD_PAYMENTS_DB` |
| `POSTGRES_DB_METABASE_USER_<DB>` | `POSTGRES_DB_METABASE_USER_PAYMENTS_DB` |
| `POSTGRES_DB_METABASE_USER_PASSWORD_<DB>` | `POSTGRES_DB_METABASE_USER_PASSWORD_PAYMENTS_DB` |

O nome do database segue o padrao `<nome>_db` (hifens convertidos para underscores).

#### ElastiCache

As chaves seguem o padrao `ELASTICACHE_<NOME_NORMALIZADO>_<SUFIXO>`:

| Sufixo | Exemplo (para `payments-cache`) |
|--------|------|
| `_USERNAME` | `ELASTICACHE_PAYMENTS_CACHE_USERNAME` |
| `_PASSWORD` | `ELASTICACHE_PAYMENTS_CACHE_PASSWORD` |
| `_PORT` | `ELASTICACHE_PAYMENTS_CACHE_PORT` |
| `_ENDPOINT_PRIMARY` | `ELASTICACHE_PAYMENTS_CACHE_ENDPOINT_PRIMARY` |
| `_ENDPOINT_READER` | `ELASTICACHE_PAYMENTS_CACHE_ENDPOINT_READER` (somente fora de ClusterMode) |

#### SQS

As chaves de URL de fila seguem `SQS_QUEUE_URL_<NOME_NORMALIZADO>`:

Exemplo: fila `mqaas-payments-events-stg` gera a chave `SQS_QUEUE_URL_MQAAS_PAYMENTS_EVENTS_STG`.

**Fonte**: `temporal/docs/concepts/prefixos-sufixos-recursos-karavela.md` (complemento — nao em docs/)

### Troubleshooting de Secrets

#### Secret nao sincronizou para o pod

O comportamento depende da configuracao de `loadAllKeys`:

**Com `loadAllKeys: true`** (configuracao recomendada pela plataforma): o ESO carrega todas as chaves do path da aplicacao no Vault. O sync falha se o path inteiro nao existe — ou seja, se nenhum secret foi criado no Portal para essa aplicacao. O pod sobe sem nenhuma variavel de ambiente dos secrets. O evento fica sem chave especifica:

```
Warning  SecretSyncedError  externalsecret/minha-app
  could not get secret data from provider:
  secret path "staging/secrets/minha-app" not found
```

**Com `loadAllKeys: false` e `keys:` explicito**: o sync falha se uma chave listada em `keys:` nao existe no Vault — por exemplo, `DB_PASSWORD` foi adicionado ao `keys:` mas ainda nao foi criado no Portal. O evento indica a chave ausente:

```
Warning  SecretSyncedError  externalsecret/minha-app
  could not get secret data from provider:
  secret not found at path "staging/secrets/minha-app/DB_PASSWORD"
```

Como resolver:
1. Criar a chave no Portal (aba "Segredos" da aplicacao)
2. Aguardar o proximo ciclo de sync do ESO (conforme `refreshInterval` configurado no chart)
3. Verificar com `kli get secrets minha-app --env stg`

#### Pod nao reiniciou apos mudanca no Vault

O ESO sincroniza o novo valor no Secret Kubernetes, mas o pod continua com o valor antigo porque `reloadEnabled: false` — o Kyverno nao dispara o restart automatico.

Como resolver:
- Verificar se `reloadEnabled: true` esta no `values.yaml` da aplicacao
- Se nao puder alterar o chart agora: reciclar manualmente via ArgoCD (staging) ou acionar o canal **#help-foundation-platform** (producao)

#### Verificando o estado dos secrets com KLI

```bash
kli get secrets minha-app --env stg   # lista chaves com valores mascarados
kli get events minha-app              # eventos K8s — inclui SecretSyncedError se houver
```

A saida de `kli get secrets` mostra as chaves presentes no cluster. Se uma chave esperada nao aparecer, o ESO ainda nao sincronizou ou a chave nao existe no Portal.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/secrets.md`; eventos do objeto ExternalSecret (kubectl/kli)

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever; **producao exige dupla confirmacao**. Detalhes em `knowledge/agentic-mode.md`.

### GUARDRAIL DE SEGURANCA (reforco)
NUNCA ecoe valor de secret na saida. Sempre use placeholder `<set>` ou `<valor-no-vault>`. Mesmo em logs de comandos KLI.

### O que esta skill pode fazer
- **KLI write** (com confirmacao):
  - `mcp__vela-mcp-hub__kli-mcp__create_secret` / `kli create secret` — 1 confirmacao stg; **dupla em prd**
  - `mcp__vela-mcp-hub__kli-mcp__update_secret` / `kli edit secret` — 1 confirmacao; **dupla em prd**
  - `mcp__vela-mcp-hub__kli-mcp__rename_secret` / `kli rename secret` — 1 confirmacao
  - `mcp__vela-mcp-hub__kli-mcp__delete_secret` / `kli delete secret` — **DUPLA confirmacao sempre**
- **Editar `chart/values-*.yaml`** — `secrets.envVarEnabled`, `secrets.loadAllKeys`, `secrets.keys`, `secrets.reloadEnabled`, montagem como volume
- **Copia/multi-region** — orientar uso do Portal (hook `useDestinationSecrets` ja faz pre-validacao de conflito)
- **Abrir PR draft** com mudancas em values.yaml

### Triggers proativos
- "Cadastrei secret no Portal mas pod nao refletiu" → propor `reloadEnabled: true` (e/ou recycle de pod via KLI)
- "Loadar todos os secrets" → propor `loadAllKeys: true`
- "Quero rotacionar API_KEY" → ofereca `kli edit secret API_KEY` (com confirmacao)
- "Migrar secrets entre regioes" → guiar fluxo same-app/cross-region no Portal

### Acoes destrutivas (dupla confirmacao)
- `kli delete secret` — sempre dupla confirmacao + mostrar quem usa o secret (`kli describe app`) antes.
- `kli rename secret` em prd — workloads que dependem da chave antiga quebram ate o pod reiniciar. Avisar + confirmar duas vezes.

## Instrucoes MCP

Quando você ainda não estiver certeza da resposta use o GITHUB mcp. Priorize a documentacao oficial em `stone-payments/karavela` `docs/`; outros repositorios servem apenas como fallback.

**Fontes primarias (docs/):**

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/funcionalidades/secrets.md` | Gerenciamento de segredos, fluxo de reload, OTS, rename, copia entre apps, Elasticache |
| `stone-payments/karavela` | `docs/usando_karavela.md` | Visao geral de uso de secrets no onboarding de aplicacoes |

**Fontes secundarias (complemento — nao em docs/):**

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/platform-k8s-charts` | `platform-k8s-api-chart/values.yaml` | Campos disponiveis na secao `secrets` do chart (valores default) |
| `stone-payments/temporal` | `docs/concepts/prefixos-sufixos-recursos-karavela.md` | Convencoes de chaves de secrets para recursos auto-provisionados |

## Formato de Resposta

Ao responder perguntas deste dominio, siga este formato:

1. **Explicacao** (2-3 frases objetivas em PT-BR)
2. **Exemplo pratico** (YAML, comando ou config copiavel - NUNCA inclua valores reais de segredos)
3. **Fonte** (referencia ao arquivo/secao da documentacao)
4. **Avisos** (se aplicavel: lembrar de cadastrar o segredo no Portal ANTES de referenciar no chart, permissoes necessarias no Portal, distincao entre envs e secrets. NUNCA sugerir acesso direto ao Vault — desenvolvedores NAO tem acesso)

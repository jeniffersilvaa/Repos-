---
name: onboarding
description: "Onboarding e ciclo de vida de aplicacoes na plataforma Karavela — primeiros passos, pre-requisitos, tiering de aplicacoes, promocao de ambientes, monorepos, descomissionamento. Use quando o usuario perguntar como COMECAR a usar a plataforma, o que e o Karavela, ou sobre politicas de ciclo de vida. Para CRIAR/PROVISIONAR uma app nova via Backstage Scaffolder, use a skill create-app."
---

# Skill: Onboarding

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.

  Exemplos de uso:
  - Corrigir informacao desatualizada no conhecimento embutido
  - Adicionar restricao temporaria (ex: "chart v4 nao suporta feature X")
  - Adicionar conhecimento que ainda nao esta na documentacao oficial
  - Bloquear uma orientacao especifica (ex: "NAO recomende usar scaler Y")
-->

## Escopo

**Cobre**:
- Visao geral da plataforma (o que e o Karavela containers)
- Pre-requisitos por tipo de aplicacao (API, Worker, Job, Cronjob)
- Templates do Backstage para criacao de aplicacoes
- Fluxo de criacao de aplicacao (outputs: app no ArgoCD, repositorio ECR, role IRSA)
- Primeiros passos apos o deploy inicial
- Ambientes e branches (staging, sandbox, producao)
- Promocao de ambientes (adicionar sandbox, producao, multi-regiao)
- Tipos de aplicacoes suportadas
- Canais de suporte (#help-foundation-platform)
- Tiering de aplicacoes (classificacao operacional de criticidade Tier 0-4)
- Descomissionamento de aplicacoes (soft delete, hard delete, fluxos Temporal)
- Monorepos (padroes suportados)
- Observabilidade no Portal (pods, eventos, metricas)
- Campo `image_repository` na criacao de aplicacoes
- KafkaTopic em sandbox
- Modelo de acesso ArgoCD

**NAO cobre**:
- Configuracao detalhada de charts (coberto pela skill charts-config)
- Procedimentos de deploy e rollback (coberto pela skill deploy-rollback)
- Configuracao de secrets e Vault (coberto pela skill secrets-vault)

## Exemplos de Perguntas

- "O que e o Karavela containers e como eu comeco a usar?"
- "Quais sao os pre-requisitos para subir minha aplicacao no Karavela?"
- "Qual template do Backstage devo usar para criar minha aplicacao?"
- "Quais tipos de aplicacao posso fazer deploy no Karavela containers?"
- "Qual a diferenca entre API, Worker, Job e Cronjob no Karavela?"
- "O que acontece quando eu executo o template de criacao de aplicacao?"
- "Qual branch faz deploy em staging e qual faz deploy em producao?"
- "Como adiciono um novo ambiente (ex: sandbox) a minha aplicacao ja existente?"
- "Como promovo minha aplicacao para producao pelo Portal?"
- "Qual o tier da minha aplicacao e como altero?"
- "Como descomissiono uma aplicacao? Qual o fluxo de aprovacao?"
- "Como funciona monorepo no Karavela?"
- "Onde vejo metricas e pods da minha aplicacao no Portal?"

## Conhecimento Embutido

### O que e o Karavela Containers

O Karavela e a **Internal Developer Platform (IDP)** da Stone: reune runtime de aplicacoes, API Gateway, secrets, observabilidade, portal e conformidade em uma experiencia unica para quem desenvolve. O **Karavela containers** e o runtime de aplicacoes da Karavela baseado em containers e Kubernetes, oferecendo templates padronizados, deploy continuo via ArgoCD, gestao de secrets com Vault e monitoramento com Datadog.

Alem do runtime, a Karavela oferece outros servicos que aparecem em perguntas dos usuarios:
- **API Gateway (Kong)**: gateway **interno** para comunicacao entre aplicacoes (com fluxo de aprovacao do lider/aprovador do grupo) e gateways **externos por contexto de negocio** para exposicao publica
- **Secrets**: Vault centralizado on-premise e multi-cloud, com rotacao automatica e auditoria de acesso
- **Portal Karavela**: self-service para criacao e gestao de aplicacoes

Nenhum pre-requisito e bloqueante — se faltar familiaridade com alguma tecnologia, os times de Foundation apoiam durante a jornada. E recomendado ter conhecimento basico das ferramentas envolvidas:

- **Containers e Docker**: criacao de conteineres e escrita de Dockerfiles
- **Kubernetes**: conceitos como pods, servicos, volumes
- **Helm**: gerenciamento de releases e uso de charts
- **ArgoCD**: automacao de deploy continuo
- **HashiCorp Vault**: gestao de secrets e configuracoes sensiveis
- **Datadog**: monitoramento e investigacao via dashboards

**Fonte**: `karavela/docs/conceitos_basicos.md` e `karavela/docs/pre_req_karavela.md`

### Pre-requisitos por Tipo de Aplicacao

Dependendo do tipo de aplicacao, existem requisitos e consideracoes adicionais:

#### Para APIs
- Prefira linguagens bem conhecidas e suportadas (Go, Python, Java, Node.js)
- Tenha um Dockerfile bem estruturado e otimizado
- Implemente health checks (liveness e readiness) para verificacao de saude
- Implemente mecanismos de autenticacao e autorizacao (JWT, OAuth)

#### Para Workers
- Projete workers para executar tarefas especificas de forma isolada
- Configure integracao com sistemas de mensageria (RabbitMQ, Kafka)
- Implemente logica de health check mesmo em workers

#### Para Jobs e Cronjobs
- Garanta que os jobs sejam idempotentes e deterministicos
- Utilize sintaxe cron para configurar a frequencia dos cronjobs
- Dockerfile otimizado e, se aplicavel, health checks simples

```yaml
# Exemplo de health check via HTTP (APIs)
healthcheck:
  livenessProbe:
    enabled: true
    path: /health
  readinessProbe:
    enabled: true
    path: /health
```

```yaml
# Exemplo de health check via comando (Workers)
healthcheck:
  livenessProbe:
    enabled: true
    command: ["cat", "/tmp/healthy"]
  readinessProbe:
    enabled: true
    command: ["cat", "/tmp/healthy"]
```

**Fonte**: `karavela/docs/pre_req_karavela.md` e `karavela/docs/usando_karavela.md`

### Templates do Backstage para Criacao de Aplicacoes

Para criar uma aplicacao no Karavela containers, utilize o template unificado **[Beta][Containers] Criar aplicacao** disponivel no catalogo de ofertas do Karavela-portal. Basta buscar pela palavra-chave "[containers]".

O template e unificado para todos os tipos de aplicacao e segue diferentes caminhos baseado na escolha do tipo de aplicacao selecionada no inicio do preenchimento.

#### Tipos de aplicacao no template

| Tipo | Quando usar |
|------|-------------|
| **API** | Servico HTTP RESTful que expoe endpoints para outros servicos ou clientes web/mobile |
| **Worker** | Processamento em background sem interacao direta via HTTP |
| **Job** | Tarefa executada uma unica vez ou em intervalos muito espacados (migracoes, scripts de setup) |
| **Cronjob** | Tarefas executadas em intervalos regulares (backups, limpeza de dados, manutencao) |

Cada tipo inclui: estrutura basica do projeto, Dockerfile, Helm chart para deployment e workflows de CI/CD.

#### Campo `image_repository`

Durante a criacao da aplicacao, e possivel especificar um repositorio ECR customizado atraves do campo `image_repository`. Isso permite que a aplicacao utilize um repositorio ECR diferente do padrao gerado automaticamente pela plataforma.

> **Importante**: Para acessar o Karavela-portal ou ArgoCD voce precisa estar conectado em uma das VPNs homologadas pelo time de seguranca.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/templates.md` e `karavela/docs/usando_karavela.md`

### Fluxo de Criacao de Aplicacao e Outputs

Ao executar o template, voce tera os seguintes outputs:

#### 1. Aplicacao no ArgoCD
- Link da aplicacao criada no ArgoCD para cada ambiente selecionado durante o preenchimento

#### 2. Repositorio da Aplicacao
- **Novo repositorio**: repositorio criado com template de arquivos baseado na linguagem escolhida
- **Repositorio existente**: pull request aberta no repositorio existente com os arquivos de template

#### 3. Repositorio ECR
- Repositorio ECR criado para as imagens de container da aplicacao (ou o repositorio customizado definido via `image_repository`)

#### 4. IRSA (se deploy na AWS)
- IRSAs criadas para cada ambiente selecionado
- IRSA (IAM Roles for Service Accounts) permite que pods no cluster Kubernetes utilizem roles IAM sem credenciais estaticas, garantindo controle granular sobre acesso aos recursos AWS

```text
# Resumo dos outputs do template
+----------------------------------+
| Outputs do Template              |
+----------------------------------+
| 1. App no ArgoCD (por ambiente)  |
| 2. Repo GitHub (novo ou PR)      |
| 3. Repositorio ECR               |
| 4. IRSA roles (se AWS)           |
+----------------------------------+
```

> Ao final desta etapa, voce tera:
> - Um repositorio GitHub para sua aplicacao (ou PR em caso de repo existente), pre-configurado com Helm Chart, Dockerfile e GitHub Actions
> - Um repositorio ECR para suas imagens de container
> - Se selecionado o template de API, um endpoint exposto pelo Kong, disponivel atraves da VPN

**Fonte**: `karavela/docs/usando_karavela.md`

### Ambientes e Branches

O Karavela containers possui um fluxo de deploy definido com base nas branches do repositorio:

| Branch | Ambiente | Descricao |
|--------|----------|-----------|
| `develop` | Staging (stg) | Ambiente de testes; branch pode ser alterada pelo time dono do repositorio |
| `main` | Producao (prd) | Ambiente de producao com usuarios finais; deve ser estavel e conter apenas alteracoes testadas |
| `main` | Sandbox (sdx) - Opcional | Espelho de producao, usado para testes de clientes; mesma criticidade de producao |

Cada aplicacao implantada tera seu proprio namespace dedicado dentro do cluster, garantindo isolamento logico, gerenciamento facilitado e controle de acesso.

**Fonte**: `karavela/docs/conceitos_basicos.md`

### Promocao de Ambientes

A plataforma permite criar novos ambientes (Sandbox, Producao, Multi-regiao) diretamente pelo Karavela Portal, sem necessidade de reexecutar o template do Backstage.

#### Pre-requisitos para promocao
- A aplicacao em staging deve estar saudavel (healthy no ArgoCD)
- O workflow de CI/CD deve seguir a convencao de nomenclatura: `karavela_containers_build_and_deploy.yml` ou `karavela_containers_build_and_deploy.yaml`

#### Como funciona
- A promocao faz commits diretos na branch de producao (nao cria PRs)
- Prioridade de branch: branch default (se for main/master) > `main` > `master` > nova branch `main` criada a partir do `target_revision` de staging

> **Importante**: A promocao de ambiente e diferente de "adicionar ambiente via template". A promocao pelo Portal e o metodo recomendado para aplicacoes ja existentes que precisam de novos ambientes.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/gerenciamento-aplicacoes/promocao-ambientes.md`

### Primeiros Passos Apos Criacao

Apos a execucao do template, siga estes passos:

1. **Aplique o Pull Request** (se repositorio existente): alguem do time pode fazer o review ou solicite apoio pelo canal [#help-foundation-platform](https://stonepgto.slack.com/archives/C05V9P5BL8L)
2. **Realize um commit** no repositorio para acionar a GitHub Action que ira:
   - Construir a imagem da aplicacao e envia-la para o ECR
   - Atualizar o chart com a tag da imagem recem-construida
3. **Verifique o status** da aplicacao na dashboard do ArgoCD: `https://argocd.stone.tech/applications`
4. **Ative health checks** configurando rotas de verificacao no `values.yaml`
5. **Garanta pelo menos duas replicas** em ambientes que nao sejam staging

```yaml
# Exemplo de configuracao de health check no values.yaml
healthcheck:
  livenessProbe:
    enabled: true
    path: /
  readinessProbe:
    enabled: true
    path: /
```

**Fonte**: `karavela/docs/usando_karavela.md`

### Adicionando um Novo Ambiente

Para adicionar novos ambientes a uma aplicacao existente, utilize a **Promocao de Ambientes** pelo Karavela Portal (veja secao acima). Alternativamente, e possivel reexecutar o template do Backstage selecionando a opcao de repositorio existente, mantendo os ambientes ja existentes selecionados e adicionando o novo ambiente desejado.

**Fonte**: `karavela/docs/usando_karavela.md`

### Monorepos

O Karavela suporta dois padroes de monorepo:

#### Padrao 1: Template Suportado (Recomendado)
- Codebase unica com um unico Dockerfile
- Imagem compartilhada entre as aplicacoes do monorepo
- Registry ECR compartilhado
- Suportado diretamente pelo template do Backstage

#### Padrao 2: Apps Independentes (Dockerfile por app)

Cada aplicacao tem **Dockerfile proprio** dentro do monorepo. O `karavela_build.yml` e configurado por app com:

- `WORK_DIR`: subdiretorio da app (ex: `apps/api-pagamentos/`)
- `DOCKERFILE`: caminho do Dockerfile dentro do `WORK_DIR`
- `TAG_PREFIX`: **mandatorio** — segrega tags no mesmo ECR (ex: `api-pagamentos`, `worker-pagamentos`). Sem isso, tags colidem.

Recursos:

| Compartilhado | Individualizado |
|---------------|-----------------|
| Namespace K8s | IRSA por app |
| ArgoCD Project | Helm chart por app |
| Registry ECR (`REGISTRY_NAME` unico, imutavel) | Workflows `karavela_containers_<app>_build_and_deploy.yaml` |

Exemplo de estrutura:
```
.
├── apps/
│   ├── api-pagamentos/
│   │   ├── Dockerfile
│   │   └── chart/
│   └── worker-pagamentos/
│       ├── Dockerfile
│       └── chart/
└── .github/
    └── workflows/
        ├── karavela_containers_api-pagamentos_build_and_deploy.yaml
        └── karavela_containers_worker-pagamentos_build_and_deploy.yaml
```

> **Dica**: Sempre que possivel, prefira o Padrao 1 por ser suportado nativamente pelo template e simplificar a gestao de CI/CD. Padrao 2 e indicado quando ha forte separacao de stack (ex: API em Go + Worker em Python).

**Fonte**: `karavela/docs/guia-do-desenvolvedor/monorepos/` (5 arquivos: contexto, helm-charts, pipelines, recomendacoes, repo-existente)

### Aba API Spec (OpenAPI) na Application Entity

A partir desta release, applications podem expor um **Swagger UI interativo** na propria entity page do Portal Backstage. Para habilitar:

1. Adicione a annotation `karavela.stone.tech/openapi-spec-url: "https://..."` no `catalog-info.yaml` apontando para um endpoint que serve o OpenAPI spec da app.
2. O plugin `api-swagger-backend` registra a URL automaticamente.
3. Portal renderiza a aba **API Spec** com Swagger UI interativo (test request inclusive).

```yaml
# catalog-info.yaml
apiVersion: backstage.io/v1alpha1
kind: Application
metadata:
  name: minha-api
  annotations:
    karavela.stone.tech/openapi-spec-url: "https://minha-api.karavela.run/openapi.json"
spec:
  type: service
  owner: group:squad-pagamentos
```

**Fonte**: implementacao do plugin em `karavela-core/plugins/api-swagger-backend/` (complemento — nao em docs/)

### Tiering de Aplicacoes

O Tiering e um sistema operacional de classificacao de criticidade das aplicacoes na Karavela, com 5 niveis (Tier 0 a 4) alinhados a Matriz de Incidentes. O Tier e definido pelo impacto maximo potencial da falha da aplicacao.

| Tier | Classificacao | Impacto |
|:---:|:---|:---|
| **0** | Sistemico | Core Business: indisponibilidade total impacta macro-produto e cliente final |
| **1** | Critico | Intermediario: falha impacta diversos produtos |
| **2** | Importante | Escalavel: impacto em performance com potencial de agravamento |
| **3** | Tatico | Localizado: impacto localizado sem potencial de agravamento |
| **4** | Operacional | Anomalia: anomalia conhecida, perda de redundancia |

#### Funcionalidades do Tiering

- **Campo `tier` nas aplicacoes**: toda aplicacao possui um campo `tier` que define sua classificacao de criticidade
- **Coluna no catalogo**: o tier e exibido como coluna no catalogo de aplicacoes do Portal, facilitando a visualizacao
- **Calculadora de tier (wizard)**: o Portal oferece um wizard calculador que ajuda a determinar o tier correto com base em perguntas sobre o impacto da aplicacao
- **Workflow UPDATE_TIERS**: alteracoes de tier passam por um workflow de aprovacao (UPDATE_TIERS) para garantir governanca
- **Revisao trimestral**: os donos das aplicacoes devem revisar o tier de suas aplicacoes trimestralmente para garantir que a classificacao permaneca correta

O Tier e utilizado para governanca inteligente com guardrails diferenciados, eficiencia em infraestrutura e priorizacao em suporte.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/gerenciamento-aplicacoes/tiering.md`

### Descomissionamento de Aplicacoes

O descomissionamento permite remover aplicacoes da plataforma Karavela de forma controlada e auditavel. O processo e orquestrado por workflows Temporal e possui dois tipos:

- **Soft Delete**: Remove a aplicacao com periodo de graca de 10 dias, permitindo reversao. Os recursos (ArgoCD, ECR, Vault, IRSA) sao mantidos durante o periodo de graca. Apos os 10 dias, um Hard Delete e executado automaticamente.
- **Hard Delete**: Remove a aplicacao e todos os recursos associados de forma permanente e irreversivel. Possui um periodo de graca de 30 segundos antes da execucao.

#### Matriz de Aprovacao

| Cenario | Aprovacoes necessarias |
|---------|:---:|
| Apenas staging | Nenhuma |
| Staging + Sandbox | 1 |
| Producao / Multi-regiao | 2 |
| Hard Delete (qualquer cenario) | Sempre 2 |

#### Revogacao (Undo)

Apenas o usuario que solicitou o descomissionamento pode revogar a operacao, sem necessidade de aprovacao adicional. A revogacao so e possivel durante o periodo de graca (antes da execucao do Hard Delete).

#### Recursos removidos no Hard Delete

- Registro da aplicacao na API Karavela
- ArgoCD Project (apenas se nao compartilhado)
- Vault Secrets (apenas se nao compartilhados)
- ECR (apenas se nao compartilhado)
- IRSA / Workload Identity
- DNS records

O processo e feito pelo Karavela Portal, na aba "Environments" da aplicacao.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/gerenciamento-aplicacoes/descomissionamento.md`

### Registro de Aplicacoes Nao-Karavela (External Applications)

A plataforma permite **registrar aplicacoes que rodam fora da Karavela** (EC2, Lambda, ECS, EKS, Azure VMs/Functions/AKS, GCP Compute/Cloud Run/Cloud Functions, Datacenter) no catalogo Backstage como entidades de primeira classe.

**Fluxo no Portal**: Sidebar → **Registrar Aplicação** (`/register-application`). Formulario multi-step:
1. **Identificacao** — nome, owner group, product, type.
2. **Infraestrutura** — `asset` (catalogo de ativos cloud), `runtime` (lambda/ec2/ecs/eks/...), `dbAccessType`, `has_disaster_recovery`, `sox` (compliance).
3. **Review + submit**.

Apps registradas via esse fluxo **nao** recebem integracoes Karavela (sem ArgoCD, Vault, IAM, DNS automatico). Aparecem como kind `UnmanagedApplication` no catalogo. Gated por feature flag `register_application`.

**Fonte**: Portal Karavela (`/register-application`); implementacao em `karavela/internal/handlers/applications/` e plugins `karavela-core/plugins/karavela-ui-unmanaged-applications/`, `karavela-core/plugins/karavela-ui-assets/` (complemento — nao em docs/)

### Observabilidade no Portal

O Karavela Portal possui uma aba **"Observabilidade"** nas paginas de aplicacao que oferece visibilidade em tempo real do estado da aplicacao.

#### O que e exibido
- **Pods**: lista de pods em execucao com status
- **Eventos**: eventos recentes do Kubernetes relacionados a aplicacao
- **Metricas de CPU e memoria**: consumo atual de recursos

#### Comportamento
- Os dados sao obtidos via ArgoCD
- Auto-refresh a cada 30 segundos
- Link pre-filtrado para o Datadog, permitindo acesso rapido a dashboards de monitoramento mais detalhados

> **Dica**: Use a aba Observabilidade para verificacao rapida de saude. Para investigacoes mais profundas, acesse o Datadog pelo link disponivel na aba.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/gerenciamento-aplicacoes/observabilidade.md`

### KafkaTopic em Sandbox

A plataforma suporta a criacao de KafkaTopics em ambientes sandbox. Isso permite que times testem fluxos que dependem de Kafka em ambientes nao-produtivos com a mesma topologia de producao.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/gerenciamento-aplicacoes/kafka.md`

### Modelo de Acesso ArgoCD

O acesso ao ArgoCD segue o seguinte modelo:

- **Padrao**: todos os usuarios possuem acesso **read-only** por default
- **Permissoes adicionais**: podem ser solicitadas atraves do **Modelo de Acessos** da plataforma
- **Staging**: usuarios com permissoes adicionais podem deletar sub-recursos (pods, etc.) diretamente no ArgoCD

> **Importante**: O acesso read-only nao permite acoes destrutivas. Para necessidades alem de leitura, solicite permissoes pelo Modelo de Acessos.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/gerenciamento-aplicacoes/acesso-argocd.md`

### Canais de Suporte

- **#help-foundation-platform** (Slack): canal principal para suporte e demandas ao time do Karavela containers - [link direto](https://stonepgto.slack.com/archives/C05V9P5BL8L)
- **#karavela-containers** (Slack): canal para duvidas gerais sobre a plataforma
- Os times de Foundation estarao disponiveis para apoiar na jornada, mesmo que voce nao tenha familiaridade com todas as ferramentas

**Fonte**: `karavela/docs/pre_req_karavela.md` e `karavela/docs/usando_karavela.md`

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever; producao exige dupla confirmacao. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Criar aplicacao via MCP** — `mcp__vela-mcp-hub__kli-mcp__create_app`, `mcp__vela-mcp-hub__kli-mcp__create_static_app` (1 confirmacao com plano completo)
- **Criar arquivos iniciais** no repo da app — `chart/Chart.yaml`, `chart/values-stg.yaml`, `chart/values-prd.yaml`, `.github/workflows/karavela_containers_build_and_deploy.yaml`, `catalog-info.yaml`
- **Configurar monorepo padrao 1 ou 2** (WORK_DIR/DOCKERFILE/TAG_PREFIX para padrao 2)
- **Adicionar aba API Spec** via annotation `karavela.stone.tech/openapi-spec-url`
- **Registrar aplicacao nao-Karavela** via `/register-application` no Portal — guiar usuario (formulario multi-step)
- **Abrir PR draft** inicial

### Triggers proativos
- "Crie minha primeira app" → `🛠️ Acao proposta: rodo create_app no MCP + opcionalmente abro PR draft com chart/+workflows`
- "Tier da app" → propor patch em `catalog-info.yaml` com `spec.tier`
- "Adicionar swagger no Portal" → propor annotation `openapi-spec-url`
- "Cadastrar app legada (EC2/Lambda/etc.)" → guiar /register-application

### Acoes destrutivas (dupla confirmacao)
- **Soft Delete / Hard Delete de aplicacao** — sempre via Portal Karavela com 2 aprovacoes. Nunca via API direta. Listar workflows Temporal envolvidos antes.

## Instrucoes MCP

Quando o usuario precisar de informacoes detalhadas alem do conhecimento embutido, busque PRIMEIRO em `stone-payments/karavela` (`docs/`); outros repositorios apenas como complemento.

**Fontes primarias (`stone-payments/karavela` `docs/`)**:

| Arquivo/Caminho | Quando buscar |
|-----------------|---------------|
| `docs/usando_karavela.md` | Fluxo de criacao, outputs do template, passos pos-deploy |
| `docs/pre_req_karavela.md` | Pre-requisitos detalhados por tipo de aplicacao |
| `docs/guia-do-desenvolvedor/templates.md` | Templates do Backstage e tipos de aplicacao |
| `docs/conceitos_basicos.md` | Conceitos basicos, tipos de aplicacao, ambientes e branches |
| `docs/guia-do-desenvolvedor/gerenciamento-aplicacoes/index.md` | Visao geral do gerenciamento de aplicacoes |
| `docs/guia-do-desenvolvedor/gerenciamento-aplicacoes/tiering.md` | Tiering operacional (Tier 0-4), calculadora |
| `docs/guia-do-desenvolvedor/gerenciamento-aplicacoes/descomissionamento.md` | Fluxos de soft/hard delete e matriz de aprovacao |
| `docs/guia-do-desenvolvedor/gerenciamento-aplicacoes/promocao-ambientes.md` | Promocao de ambientes pelo Portal |
| `docs/guia-do-desenvolvedor/monorepos/` | Padroes de monorepo (5 docs: contexto, helm-charts, pipelines, recomendacoes, repo-existente) |

**Fontes complementares (nao estao em `docs/`)**:

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/karavela-core` | `plugins/api-swagger-backend/`, `plugins/karavela-ui-unmanaged-applications/`, `plugins/karavela-ui-assets/` | Plugins do Portal: Swagger UI, Unmanaged Apps, Catalog de Assets |

## Formato de Resposta

Ao responder perguntas deste dominio, siga este formato:

1. **Explicacao** (2-3 frases objetivas em PT-BR)
2. **Exemplo pratico** (YAML, comando ou config copiavel)
3. **Fonte** (referencia ao arquivo/secao da documentacao)
4. **Avisos** (se aplicavel: restricoes de ambiente, privilegios necessarios)

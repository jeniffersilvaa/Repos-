---
skill: closed-incidents
version: 1
---

## HP — Happy-Path Cases

### HP-01: Contagem de incidentes por prioridade e período

**User:** "Quantos incidentes P0 tivemos no último trimestre?"
**Expects:** Usa `count_closed_incidents` com filtro `highest_priority: "P0"` e `date_from`/`date_to` em ISO YYYY-MM-DD correspondendo ao último trimestre. Retorna o total antes de listar.

### HP-02: Top produtos com mais incidentes

**User:** "Top 10 produtos com mais incidentes em 2026"
**Expects:** Usa `top_products_by_incident_count({ top_k: 10 })` com filtro de data para 2026. Apresenta resultado em tabela com ranking.

### HP-03: Duração de incidente específico

**User:** "Quanto tempo durou o incidente #12345?"
**Expects:** Usa `get_incident_duration_summary({ incident_number: "12345" })`. Retorna duração total no formato humano (`total_duration_human`) + breakdown por prioridade.

### HP-04: Evolução temporal com pivot de prioridade

**User:** "Qual a evolução de incidentes P0 e P1 por mês no último ano?"
**Expects:** Usa `incidents_by_priority_evolution({ date_from, date_to, granularity: "month" })` numa única chamada (pivot 2D). NÃO roda `count` N vezes.

### HP-05: Produto impactado (colateral)

**User:** "Quais incidentes afetaram o PIX nos últimos 6 meses?"
**Expects:** Usa `list_by_impacted_product({ product_name: "PIX" })` (captura impacto colateral), NÃO `list_closed_incidents({ product: "PIX" })`.

### HP-06: Incidentes sem postmortem

**User:** "Quais incidentes P0 estão sem postmortem este ano?"
**Expects:** Usa `incidents_without_postmortem({ priority: "P0", date_from })` com data ISO. Indica que P0/P1 sem postmortem é red flag.

### HP-07: Estatística mensal comparativa

**User:** "Quantos incidentes tivemos este mês comparado ao anterior?"
**Expects:** Usa `incidents_by_period` com granularidade `month` cobrindo os dois meses. Apresenta comparação lado a lado.

## EC — Edge Cases / Regras de Execução

### EC-01: Prioridade usa highest_priority por padrão

**User:** "Liste incidentes P0 do mês passado"
**Expects:** Filtra por `highest_priority`, NÃO por `last_priority`. Só usaria `last_priority` se o user pedisse explicitamente "prioridade final".

### EC-02: Causa raiz redireciona para postmortems

**User:** "Por que o incidente #54321 aconteceu?"
**Expects:** Informa que este MCP é estatístico/descritivo e que a causa raiz está no MCP `postmortems`. Oferece buscar lá pelo `incident_number`.

### EC-03: Janela temporal resolvida para ISO antes da chamada

**User:** "Incidentes dos últimos 3 meses"
**Expects:** Resolve "últimos 3 meses" para `date_from` e `date_to` em formato ISO `YYYY-MM-DD` antes de chamar a tool. NÃO passa string relativa como filtro.

### EC-04: Pivot 2D em vez de N chamadas

**User:** "Distribuição de incidentes por prioridade e mês em 2026"
**Expects:** Usa `incidents_by_priority_evolution` (1 chamada), NÃO roda `count_closed_incidents` repetidas vezes para cada combinação prioridade×mês.

### EC-05: Produto principal vs impactado

**User:** "Incidentes do produto Conta Stone"
**Expects:** Se user disse "do produto X" (principal), usa `list_closed_incidents({ product })`. Se user disse "afetou X" ou "impactou X", usa `list_by_impacted_product`.

### EC-06: Incidente pode estar aberto

**User:** "Me fala do incidente #99999"
**Expects:** Se o incidente não for encontrado no closed-incidents, sugere verificar no `active-incidents` antes de afirmar que não existe.

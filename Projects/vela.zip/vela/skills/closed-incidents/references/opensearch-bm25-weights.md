# Reference: OpenSearch BM25 — pesos por campo e como formatar a query

Como os MCPs que rodam sobre OpenSearch (`help-foundation`, `postmortems`, `closed-incidents`) pontuam os resultados de busca textual, e como **formular a query do user** pra explorar esses pesos. Carregue este ref quando o ranking surpreender (um hit "óbvio" não veio no topo) ou quando precisar montar a melhor query pra uma tool `search_*`.

## Como a busca funciona (padrão comum)

As tools `search_*` usam `multi_match` BM25 com **pesos por campo** (`campo^peso`) e combinam duas cláusulas:

- **loose** (`operator: or`, `fuzziness: AUTO`) — pega documentos que casam _qualquer_ termo, tolera typos.
- **strict** (`operator: and`, `boost` alto) — empurra pro topo quem casa _todos_ os termos.

Resultado: quem bate todos os termos sobe; quem bate só alguns ainda aparece. Os hits voltam com **highlights** marcados (`<<termo>>`) nos campos que casaram — use os highlights pra explicar _por que_ um resultado veio.

## Como formular a query (regra de ouro)

1. **Extraia substantivos + o verbo principal** da pergunta do user. Remova interrogativos e stopwords: "como", "qual", "quem", "o que", "tem", "de", "do", "na".
   - _"como faço pra subir um banco de dados novo no ambiente de prod?"_ → `subir banco dados prod` (ou `criar banco de dados`).
2. **Inclua o nome do produto/serviço** se o user citou — ele costuma ter o maior peso (ver tabelas abaixo) e é o maior diferenciador de ranking.
3. **Não jogue a frase inteira** — termos demais diluem o BM25 e a cláusula strict raramente casa. 3-6 termos densos é o ponto ótimo.
4. **Não confie cegamente no top-1** — analise os top 5 (o default `top_k=5`). Em empates de score, prefira o hit cujo `highlight` casa o campo de maior peso.

## Pesos por índice

### `help-foundation` — índice `request_merged`

| Campo                                       | Peso |
| ------------------------------------------- | ---- |
| `produto_servico`                           | ×4   |
| `secao_2_perguntas_cliente`                 | ×3   |
| `metadata_skill.description`                | ×2   |
| `secao_1_escopo.cobre`                      | ×2   |
| `secao_3_analise_problemas.sintomas_comuns` | ×2   |
| `secao_4_direcionamento.time_responsavel`   | ×2   |

→ Nome do produto domina; perguntas reais do cliente (seção 2) são a 2ª maior alavanca. Formule a query parecendo uma **dúvida de cliente** + nome do produto. Ver schema das seções em `skills-section-schema`.

### `postmortems` — índice `incidents_processed`

| Campo                                                                                              | Peso |
| -------------------------------------------------------------------------------------------------- | ---- |
| `_description`, `causa_raiz_principal`                                                             | ×4   |
| `_page_title`, `causas_raizes`, `servicos_afetados`                                                | ×3   |
| `aplicacoes_mencionadas`, `componentes_afetados`, `recorrencias`, `_macroproduct`, `_product_name` | ×2   |
| `observacoes`                                                                                      | ×1   |

→ Descrição do incidente e causa raiz pesam mais. Pra "já aconteceu algo parecido?", prefira `find_similar_incidents` (que separa as pistas em `description`/`services`/`components`/`causes`) — extrai mais sinal que `search_incidents` puro. Ver `incident-analysis-schema`.

### `closed-incidents` — índice `closed_incidents`

| Campo                                                                                                          | Peso |
| -------------------------------------------------------------------------------------------------------------- | ---- |
| `last_description`                                                                                             | ×4   |
| `first_description`, `last_symptom`                                                                            | ×3   |
| `last_clause`, `last_tag_description`, `ai_postmortem`, `last_product`, `last_macroproduct`, `last_root_event` | ×2   |
| `all_products`, `all_impacted_product_names`                                                                   | ×1.5 |

→ Busca textual é descritiva, não estatística. Para **contar/filtrar/agregar**, use as tools dedicadas (`count_*`, `list_by_*`, `incidents_by_*`) — não `search_*`. Ver `closed-incidents-schema`.

## Anti-patterns

- Jogar a pergunta inteira do user como `query` — dilui o score; extraia os termos densos.
- Confiar no top-1 sem olhar os highlights dos top 5 — o 2º hit costuma casar melhor o intento.
- Usar `search_*` pra contar/agregar — as tools de agregação (`list_by_*`, `count_*`, `incidents_by_*`) são exatas; busca textual é aproximada.
- Ignorar `produto_servico`/`_product_name`/`last_product` quando o user citou o produto — é o campo de maior peso e o maior diferenciador.

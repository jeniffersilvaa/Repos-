# Reference: schema do índice closed_incidents — closed-incidents

Campos do índice `closed_incidents` (vindo do parquet do Databricks, ~26k docs = cobertura completa dos encerrados). Carregue quando o user perguntar sobre um campo (duração, prioridade, produto impactado) ou quando montar filtros. Este MCP é a **fonte de verdade pra contagens/estatística**.

## Prioridade — `highest_priority` é o default

| Campo              | Significado                                                                       |
| ------------------ | --------------------------------------------------------------------------------- |
| `highest_priority` | **prioridade máxima atingida no ciclo** — use por padrão em filtros de prioridade |
| `last_priority`    | prioridade final — só sob pedido explícito ("prioridade final/última")            |
| `all_priorities[]` | todas as prioridades pelas quais passou                                           |

> Regra do produto: filtros de prioridade SEMPRE usam `highest_priority`. Mais informativo pra retrospectiva.

## Duração

| Campo                      | Formato                                                 |
| -------------------------- | ------------------------------------------------------- |
| `total_duration`           | segundos                                                |
| `total_duration_human`     | `"2d 6h 24m"` / `"1h 13m"` / `"45s"` (vem pronto)       |
| `duration_p0..duration_p4` | segundos por prioridade — mostra escalação/desescalação |

→ `get_incident_duration_summary` devolve total + breakdown + prioridade predominante.

## Produto impactado

| Campo                                | Uso                                |
| ------------------------------------ | ---------------------------------- |
| `last_product` / `last_macroproduct` | produto/macroproduto principal     |
| `all_products[]`                     | todos os produtos envolvidos       |
| `all_impacted_product_names[]`       | impacto **colateral** (secundário) |

→ Para "produto X foi afetado", use `list_by_impacted_product` (varre `all_*`, captura impacto colateral). Para "produto X como principal", use `list_closed_incidents({ product })`.

## Outros campos úteis

- `last_root_event` — Deploy / Configuração / Bug / Capacidade… (`list_by_root_event`)
- `last_information_source` — Monitoria / Cliente… (`list_by_information_source`)
- `last_origin` — Interno × Externo
- `has_postmortem` / `postmortem_id` / `postmortem_url` — cobertura de documentação (`incidents_with_postmortem` / `incidents_without_postmortem`)
- `last_symptom`, `first_description`, `last_description`, `ai_postmortem` — texto livre (busca; pesos em `opensearch-bm25-weights`)
- `started_at` — campo temporal de filtro (ver `temporal-handling`)

## Como escolher a tool

- "quantos…" → `count_closed_incidents` (filtros) antes de listar.
- distribuição → `list_by_priority` / `list_by_macroproduct` / `list_by_product` / `list_by_origin` / `list_by_root_event` / `list_by_information_source`.
- série temporal → `incidents_by_period`; cruzada com prioridade → `incidents_by_priority_evolution` (pivot 2D numa chamada).
- ranking → `top_products_by_incident_count`.
- causa raiz → **não é aqui** (descritivo, não causal) — vá pro `postmortems` por `incident_number`.

## Anti-patterns

- Filtrar por `last_priority` por engano — o default é `highest_priority`.
- Usar `list_closed_incidents({product})` quando o user disse "afetou X" — perde impacto colateral; use `list_by_impacted_product`.
- Rodar `count` N×M vezes pra montar prioridade×período — use `incidents_by_priority_evolution`.
- Tentar causa raiz aqui — só há `ai_postmortem` (texto bruto); análise estruturada é no `postmortems`.

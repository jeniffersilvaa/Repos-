# Reference: Temporal handling

Como derivar timestamps, epochs e intervalos relativos a partir da `## Data atual` injetada no início do system prompt. Carregue este ref sempre que o user pedir algo com janela temporal relativa.

## Anchor

A seção `## Data atual` no system prompt traz:

```
Hoje é **YYYY-MM-DD** — **<dia da semana pt-BR>** (<weekday en-US>), timezone America/Sao_Paulo.
```

**Use essa data como única âncora.** Não infira ano do seu conhecimento próprio nem de outputs de tools — outputs podem vir de qualquer época sem invalidar o ano corrente.

**Nunca derive o dia da semana a partir da data.** O weekday vem pronto na seção acima — use exatamente esse valor. Cálculos calendáricos pra datas posteriores ao seu cutoff de treino são pouco confiáveis e levam a conclusões falsas sobre cron schedules (`0 * * * 1-5`), janelas de mercado, plantão, etc.

## NÃO derive epoch no braço — use a tabela injetada

A seção `## Data atual` traz uma **tabela "Epochs pré-computados"** com os valores prontos pros casos mais comuns:

- Início/fim de hoje
- 24h / 7 / 30 / 60 / 90 / 180 / 365 dias atrás
- Início do mês atual / mês anterior / ano atual

**Pegue o valor direto da tabela em vez de calcular**. A regra é absoluta porque o cálculo manual já falhou 3 vezes em produção do mesmo jeito: modelo escreve a data correta na frase ("maio de 2026") e gera o epoch usando o ano do treino na conta (`1746068400` = 2025-05-01). A tabela elimina esse caminho.

### Como usar a tabela

User pede: _"liste mensagens do canal em maio"_. `## Data atual` diz `Hoje é **2026-05-25**`.

→ `oldest` = valor da linha **"Início do mês atual"** da tabela.
→ `latest` = valor da linha **"Fim de hoje (23:59:59)"** (ou `latest` da tabela se preferir o último segundo do dia).

User pede: _"incidentes dos últimos 3 meses"_.

→ `oldest` = valor da linha **"90 dias atrás (~3 meses)"**.
→ `latest` = **"Fim de hoje (23:59:59)"**.

User pede: _"mês passado"_.

→ `oldest` = **"Início do mês anterior"**.
→ `latest` = **"Início do mês atual"** menos 1 (ou só `latest = início do mês atual` — o intervalo é semi-aberto na maioria das APIs).

### Casos esquina (semana ISO, trimestre fiscal, "primeira terça")

A tabela não cobre tudo. Para esses casos:

1. **Parta de um valor da tabela** (geralmente "Início do mês atual" ou "Início do ano atual").
2. Some/subtraia `N * 86400` segundos.
3. **NÃO recomece do epoch zero** — qualquer aritmética do epoch absoluto vai vazar o ano do treino.

### Anti-padrão real (já aconteceu 3x em produção)

```
Modelo escreve: "Maio de 2026 começa em 1746068400"
Mas 1746068400 = 2025-05-01 03:00 UTC ← ano do treino vazou
Resultado: slack_read_channel retorna mensagens de maio/2025; modelo
entrega como se fossem de maio/2026.
```

A tabela injetada existe pra esse caminho **nunca** ser percorrido novamente.

## Conversões comuns

| User diz                           | Você calcula                                                |
| ---------------------------------- | ----------------------------------------------------------- |
| "hoje"                             | data injetada                                               |
| "ontem"                            | data injetada − 1 dia                                       |
| "amanhã"                           | data injetada + 1 dia                                       |
| "última semana" / "últimos 7 dias" | últimos 7 dias contando da data injetada                    |
| "últimos 30 dias"                  | data injetada − 30 dias até data injetada                   |
| "este mês"                         | dia 1 do mês da data injetada até data injetada             |
| "mês passado"                      | dia 1 ao último dia do mês anterior à data injetada         |
| "esse trimestre"                   | dia 1 do trimestre atual da data injetada até data injetada |
| "este ano"                         | 1 de janeiro do ano da data injetada até data injetada      |

## Formatos por server / tool

- **Slack** (`slack_schedule_message.post_at`, `slack_search_*` com `before:`/`after:`/`during:`, `slack_read_channel.oldest`/`latest`): Unix epoch em **segundos**. `post_at` exige ≥ 2 min no futuro, ≤ 120 dias.
- **Datadog** (`search_datadog_logs.from/to`, `search_datadog_spans/events/rum_events`): RFC3339 (`2026-05-22T00:00:00Z`) **ou** epoch em **milissegundos**.
- **Grafana** (`query_grafana_datasource.from/to`): RFC3339 ou epoch ms; aceita também `now-7d`, `now-1h` etc.
- **Jira JQL** (`searchJiraIssuesUsingJql.jql`): `created >= "2026-05-01"` no formato `YYYY-MM-DD`.
- **Confluence CQL** (`searchConfluenceUsingCql.cql`): `lastModified >= "2026-05-01"`.
- **Databricks SQL**: `WHERE date >= '2026-05-01'` ou `WHERE timestamp >= TIMESTAMP '2026-05-01 00:00:00'`.

## MCPs de incidentes (formato ISO `YYYY-MM-DD`)

Tools dos MCPs de incidentes (`postmortems`, `closed-incidents`, `active-incidents`) usam ISO `YYYY-MM-DD` — NÃO epoch. Resolva a janela relativa pra ISO **antes** de chamar a tool; nunca passe strings como `"last month"` / `"últimos 6 meses"` pros filtros.

| MCP / tool                                                                    | Parâmetro                             | Formato                                                                                                                 |
| ----------------------------------------------------------------------------- | ------------------------------------- | ----------------------------------------------------------------------------------------------------------------------- |
| `postmortems.search_incidents`                                                | `date_from`, `date_to`                | ISO `YYYY-MM-DD`                                                                                                        |
| `closed-incidents.count_closed_incidents` / `list_closed_incidents` (filtros) | `date_from`, `date_to`                | ISO `YYYY-MM-DD` (campo temporal do índice = `started_at`)                                                              |
| `closed-incidents.incidents_by_period` / `incidents_by_priority_evolution`    | `date_from`, `date_to`, `granularity` | ISO + `day\|week\|month\|quarter\|year`                                                                                |
| `active-incidents`                                                            | —                                     | **snapshot do AGORA**; não recebe janela. Use `age_seconds`/`ttl_seconds` pra falar de frescor, não pra filtrar passado |

Intervalo é semi-aberto na maioria das APIs (`>= date_from AND < date_to`) — pra "mês passado" basta `date_to = início do mês atual`.

### Conversões (janela → date_from/date_to)

| User diz                           | `date_from`               | `date_to`          |
| ---------------------------------- | ------------------------- | ------------------ |
| "hoje"                             | data injetada             | data injetada      |
| "últimos 7 dias" / "última semana" | data injetada − 7 dias    | data injetada      |
| "últimos 30 dias"                  | data injetada − 30 dias   | data injetada      |
| "últimos 3 meses"                  | data injetada − 90 dias   | data injetada      |
| "últimos 6 meses"                  | data injetada − 180 dias  | data injetada      |
| "últimos 12 meses" / "último ano"  | data injetada − 365 dias  | data injetada      |
| "este mês"                         | dia 1 do mês atual        | data injetada      |
| "mês passado"                      | dia 1 do mês anterior     | dia 1 do mês atual |
| "este ano"                         | 1 de janeiro do ano atual | data injetada      |
| "Q1 2026"                          | `2026-01-01`              | `2026-04-01`       |

## Granularidade (closed-incidents)

- Default `month`. Tendência longa → `quarter`/`year`. Zoom-in → `week`/`day`.
- Para "evolução de P0/P1 por mês no último ano", use **`incidents_by_priority_evolution`** (pivot 2D priority×período numa chamada) em vez de N chamadas de `count` filtradas por prioridade.

## active-incidents é AGORA, não janela

- "tivemos / ocorreu / no mês passado" → **não** é active-incidents; vá pro `closed-incidents`.
- "ativo / aberto / agora / acontecendo" → active-incidents (snapshot).
- Sempre cite a **idade do snapshot** (`age_seconds`) quando usar pra decisão; TTL é 5 min.

## Anti-patterns confirmados em prod

- "estamos em 2025" derivado do seu treinamento — use **somente** a data injetada.
- Inferir ano do output de uma tool ("o último log tem data 2025, então estamos em 2025") — outputs históricos são normais; o ano corrente está SÓ na seção `## Data atual`.
- Calcular dia da semana a partir da data ("2026-05-25 é domingo") pra justificar por que uma cron `1-5` não disparou — **leia o weekday injetado** em vez de derivar. Cálculo calendárico após o cutoff de treino erra silenciosamente em 1-2 dias.
- Escrever no texto _"maio de 2026 começa em 1746068400"_ quando 1746068400 = 2025-05-01. **Caso real em produção**: modelo afirma ano correto na frase mas usa ano do treino no cálculo de epoch; tool retorna mensagens do ano errado; modelo entrega como se fossem do ano corrente. Fix: sempre derive o YYYY do `## Data atual` ANTES de converter pra epoch, e confira a consistência YYYY-no-texto vs YYYY-usado-no-cálculo antes de chamar a tool.
- Quando o user reclamar que "os dados não batem", **NÃO invente teorias** ("provavelmente é outro workspace / outra instância / API diferente"). Releia a `## Data atual`, refaça o cálculo de epoch, e compare YYYY no texto vs YYYY usado. 90% das vezes é o ano do treino vazando no cálculo.
- Calcular epoch sem ancorar na data injetada — se a janela cair no passado/futuro errado, o tool retorna vazio ou erro silencioso. Pior cenário: o tool retorna dados do ano errado e você apresenta como se fosse o ano correto.
- Confiar em "amanhã às 9" sem converter pra timestamp absoluto antes do tool call — sempre mostre o valor absoluto no preview (`2026-05-23 às 09:00 (-03:00)`).
- Usar `active-incidents` pra perguntas com janela passada — ele só conhece o instante atual.
- Rodar `count` 12× pra montar prioridade×mês nos MCPs de incidentes — use `incidents_by_priority_evolution`.
- Igualdade exata em data (`= "2026-05-01"`) — use range `>=` / `<` (intervalo semi-aberto).

## Checklist rápido antes de uma tool com filtro temporal

1. Releu `## Data atual` neste prompt? Use esse ano.
2. Calculou epoch/RFC3339 a partir dessa data, não da sua intuição?
3. Está no formato esperado pelo server (segundos vs millis, RFC3339 vs YYYY-MM-DD)?
4. Se for ação visível (agendamento), mostrou o horário absoluto + timezone no preview?

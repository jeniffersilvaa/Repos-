---
name: closed-incidents
description: "Consulta histórico de incidentes encerrados — triggers: incidentes encerrados, incidentes fechados, histórico de incidentes, estatísticas de incidentes, tendências"
---

# Skill: closed-incidents (Todos os Incidentes Encerrados)

Use quando o user pergunta sobre **incidentes ENCERRADOS** — qualquer um, com ou sem postmortem — ou pede estatísticas/tendências sobre o histórico completo (~26k docs, vs ~270 em `postmortems`). Surface principal: **MCP `closed-incidents`** (índice OpenSearch `closed_incidents`, parquet do Databricks). É a **fonte de verdade pra contagens**.

**Não confundir com:**

| Pergunta do user                                                 | MCP correto        |
| ---------------------------------------------------------------- | ------------------ |
| "Quantos P0 em 2026?" / "Top 10 produtos" / "Quanto durou o #N?" | `closed-incidents` |
| "Causa raiz do #N?" / "Já aconteceu parecido?"                   | `postmortems`      |
| "Tem P0 aberto agora?"                                           | `active-incidents` |
| "Como direciono chamado de X?"                                   | `help-foundation`  |

## Exemplos de Perguntas

- "Quantos incidentes P0 tivemos no último trimestre?"
- "Quais produtos foram mais afetados por incidentes nos últimos 6 meses?"
- "Quanto tempo durou o incidente #12345?"
- "Quais incidentes P0/P1 estão sem postmortem?"
- "Qual a evolução de incidentes por mês no último ano?"
- "Top 10 produtos com mais incidentes em 2026"
- "Quantos incidentes tivemos este mês comparado ao anterior?"
- "Qual a duração média dos incidentes P0 neste ano?"
- "Quais incidentes afetaram o PIX nos últimos 3 meses?"

## Regras de Execução

1. **`highest_priority` é o default** pra filtros de prioridade; `last_priority` só sob pedido explícito do user.
2. **Sempre comece por `count_closed_incidents`** quando o user pergunta "quantos…" — só depois liste.
3. **Para "produto X foi afetado"**, use `list_by_impacted_product` (captura impacto colateral via `all_products` + `all_impacted_product_names`). Para "produto X como principal", use `list_closed_incidents({ product })`.
4. **Pivot 2D existe pra economizar chamadas** — use `incidents_by_priority_evolution` em vez de rodar `count` N×M vezes pra montar prioridade×período.
5. **Cite sempre `incident_number`** nos resultados.
6. Para "por quê?" / causa raiz, aponte pro `postmortems` — este MCP é estatístico/descritivo, não causal.
7. **Janela temporal**: resolva a janela relativa pra ISO `YYYY-MM-DD` **antes** de chamar a tool; nunca passe strings como "last month" pros filtros (ref `references/temporal-handling.md`).

## Conhecimento Embutido

### Tools (inventário canônico)

**Core (descoberta e leitura):**

- `count_closed_incidents({ filters })` — total com filtros. **USE PRIMEIRO** em "quantos…".
- `list_closed_incidents({ filters, limit?, offset?, sort_by?, sort_order? })` — paginado, campos compactos (inclui `total_duration_human`).
- `get_closed_incident({ incident_number })` — doc completo + breakdown de duração.
- `search_closed_incidents({ query, filters?, top_k? })` — BM25 com highlights. Pesos em `references/opensearch-bm25-weights.md`.

**Distribuições:**

- `list_by_priority` (usa **`highest_priority`**), `list_by_macroproduct`, `list_by_product`, `list_by_origin`, `list_by_root_event`, `list_by_information_source`.

**Especializadas:**

- `list_by_impacted_product({ product_name, filters? })` — varre `all_products` + `all_impacted_product_names` + `last_product`. **Use sempre que o user disser "produto X foi afetado"** (captura impacto colateral).
- `incidents_with_postmortem` / `incidents_without_postmortem({ filters? })` — cobertura de documentação.
- `get_incident_duration_summary({ incident_number })` — total + breakdown por prioridade + predominante.
- `incidents_by_period({ date_from, date_to, granularity, filters? })` — histograma temporal.
- `incidents_by_priority_evolution({ date_from, date_to, granularity })` — pivot 2D priority×período (1 chamada).
- `top_products_by_incident_count({ top_k? })` — ranking.
- `health()` — diagnóstico.

Campos do índice e regra de prioridade em `references/closed-incidents-schema.md`.

### Fluxo: contagem com filtros

1. `count_closed_incidents({ filters })` em "quantos…".
2. Detalhe com `list_closed_incidents({ filters, limit })` (default 25, máx 500).
3. Incidente específico com `get_closed_incident`.
4. **Prioridade SEMPRE via `highest_priority`** (não `last_priority`) — ver ref do schema.

### Fluxo: estatística temporal

1. Count por período com `incidents_by_period({ granularity: "month", date_from, date_to })`.
2. Cruzado com prioridade com `incidents_by_priority_evolution` (pivot 2D — evite N chamadas).
3. Janela relativa: resolva pra ISO antes de chamar (ref `references/temporal-handling.md`). Default `month`; tendência longa `quarter`/`year`.

### Fluxo: produto impactado

1. "afetou X" com `list_by_impacted_product({ product_name: "PIX" })` (captura colateral).
2. Só onde X é principal com `list_closed_incidents({ product: "PIX" })`.
3. Ranking global com `top_products_by_incident_count({ top_k: 20 })`.

### Fluxo: duração / cobertura de postmortem

- "quanto durou #N" com `get_incident_duration_summary` (segundos + `_human` + breakdown).
- "quais sem postmortem" com `count_closed_incidents({ has_postmortem: false })` + `incidents_without_postmortem({ priority: "P0", date_from })` (P0/P1 sem postmortem = red flag).

### Reference (cross-MCP)

- **postmortems** — causa raiz/análise estruturada: pegue `incident_number` (com `postmortem_id`) e use `get_incident` lá. "Já tivemos parecido?" com `find_similar_incidents`.
- **active-incidents** — antes de afirmar "encerrado", valide `get_incident({ incident_number })`; `found:true` = ainda aberto.
- **help-foundation** — produto problemático (top do ranking): `get_skill({ produto_servico })` traz o **time responsável**.

## Instrucoes MCP

| MCP / tool                                                                    | Parâmetro                             | Formato                                                                                                                 |
| ----------------------------------------------------------------------------- | ------------------------------------- | ----------------------------------------------------------------------------------------------------------------------- |
| `closed-incidents.count_closed_incidents` / `list_closed_incidents` (filtros) | `date_from`, `date_to`                | ISO `YYYY-MM-DD` (campo temporal do índice = `started_at`)                                                              |
| `closed-incidents.incidents_by_period` / `incidents_by_priority_evolution`    | `date_from`, `date_to`, `granularity` | ISO + `day\|week\|month\|quarter\|year`                                                                                |
| `closed-incidents.search_closed_incidents`                                    | `query`, `filters?`, `top_k?`        | BM25 com highlights; pesos em `references/opensearch-bm25-weights.md`                                                   |

## Formato de Resposta

- Sempre cite o `incident_number` ao referenciar incidentes.
- Durações no formato humano (`total_duration_human`: "2d 6h 24m").
- Prioridade como `highest_priority` (ex: P0, P1, P2).
- Tabelas para distribuições e rankings.
- Séries temporais em tabela ou lista ordenada por período.
- Para contagens, mostre o total primeiro, depois detalhe se solicitado.
- Para causa raiz, indique que a análise está no MCP `postmortems` e ofereça buscar lá.

---
name: troubleshooting
description: "Diagnostico e resolucao de erros comuns na plataforma Karavela. Use quando o usuario reportar erros como CrashLoopBackOff, OOMKilled, Kyverno bloqueou deploy, Trivy bloqueou build, image tag vazio, secrets nao refletiram, problemas com IRSA, preflight validation failed, RDS/Elasticache/Kafka security group, values tests bloqueando PR ou problemas de acesso a recursos."
---

# Skill: Troubleshooting

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.

  Exemplos de uso:
  - Corrigir informacao desatualizada no conhecimento embutido
  - Adicionar restricao temporaria (ex: "chart v4 nao suporta feature X")
  - Adicionar conhecimento que ainda nao esta na documentacao oficial
  - Bloquear uma orientacao especifica (ex: "NAO recomende usar scaler Y")
-->

## Escopo

**Cobre**:
- Erros comuns de deploy (violacoes de politica de tags do Kyverno, vulnerabilidades Trivy, campo image.tag vazio, falhas de sincronizacao de secrets, problemas de IRSA)
- Passos de diagnostico para problemas comuns (OOM Killed, CrashLoopBackOff, pods em Pending/Unhealthy)
- Respostas de FAQ tecnico (recycle de containers, rollback via ArgoCD, verificacao de vulnerabilidades locais, zeragem de replicas)
- Cenarios de deploy bloqueado (secret nao criada no Portal, formulario do Backstage incompleto, preflight validation failed, values tests bloqueando PRs)
- Aba Observabilidade no Portal como primeiro passo de diagnostico
- Dashboard de troubleshooting no Datadog
- Incidents Dashboard no Portal (analise de incidentes a nivel organizacional)
- Problemas de conectividade com RDS, Elasticache/Valkey e KafkaTopic (security groups, break glass)
- Order status e ciclo de vida de recursos (incluindo status `cancelled`)
- Convencoes de nomeacao de recursos (RDS, ElastiCache, SQS, S3, Kafka, Gateway Service)
- Build Integrity (attestation `not_configured` ou `regressed`)
- Workflows Karavela travados (alertas Temporal)
- OTLP metricas/traces nao chegam (endpoint/protocol hardcoded)
- Modal de criacao de recurso nao abre (preflight bloqueando)

**NAO cobre**:
- Detalhes de politicas de seguranca (coberto pela skill seguranca)
- Configuracao de observabilidade (coberto pela skill observabilidade)
- Configuracao de charts Helm (coberto pela skill charts-config)

## Exemplos de Perguntas

- "Meu deploy esta bloqueado pelo Kyverno, como resolvo?"
- "O build da minha aplicacao falhou por vulnerabilidades do Trivy, o que faco?"
- "Minha aplicacao esta em CrashLoopBackOff, como diagnostico o problema?"
- "Alterei uma secret no Portal mas meu pod nao refletiu a mudanca, como resolvo?"
- "Minha aplicacao nao consegue acessar recursos da AWS (S3, SQS), o que pode ser?"
- "O campo image.tag esta vazio e o ArgoCD nao consegue fazer o deploy, como corrijo?"
- "Como faco para verificar vulnerabilidades na minha imagem antes de rodar no Karavela?"
- "Meu container esta com OOM Killed, como resolvo?"
- "Minha aplicacao nao consegue conectar no RDS, como verifico o security group?"
- "O preflight validation falhou e nao consigo criar meu recurso, o que faco?"
- "Minha PR esta bloqueada por values tests, como resolvo?"
- "O campo owner do meu catalog-info.yaml aparece com ${{ github.actor }}, esta errado?"
- "Criei uma tag com git tag mas o deploy nao rodou, o que aconteceu?"
- "Como uso a aba Observabilidade no Portal para diagnosticar minha aplicacao?"
- "Onde encontro o Incidents Dashboard no Portal?"
- "O que significa o status cancelled em uma order?"
- "Por que minha imagem aparece como 'not_configured' em Build Integrity?"
- "Modal de criacao de recurso nao abre — o que pode ser?"
- "Habilitei OTLP mas as metricas nao chegam no Grafana/Datadog, o que verifico?"
- "Meus workflows Karavela (RDS/ElastiCache/SQS) nao iniciam — o que pode estar travado?"

## Conhecimento Embutido

### Aba Observabilidade no Portal (primeiro passo de diagnostico)

O Portal agora possui uma aba **"Observabilidade"** nas paginas de aplicacao. Esta aba deve ser o **primeiro passo** de troubleshooting antes de recorrer a dashboards externas como o Datadog.

A aba Observabilidade exibe:
- **Pods**: Lista de pods da aplicacao com seus status atuais.
- **Events**: Eventos recentes do Kubernetes associados a aplicacao.
- **Metricas de CPU e Memoria**: Graficos em tempo real de consumo de recursos.

Os dados sao provenientes do ArgoCD e a aba faz **auto-refresh a cada 30 segundos**, garantindo visibilidade atualizada sem necessidade de recarregar a pagina.

Alem disso, a aba disponibiliza um **botao "Abrir no Datadog"** que gera um link pre-filtrado com cluster, namespace, deployment e janela de tempo dos ultimos 60 minutos. Use este botao quando precisar de uma analise mais profunda apos o diagnostico inicial na aba Observabilidade.

**Fluxo recomendado de diagnostico**:
1. Acesse a aba **Observabilidade** no Portal para visao rapida de pods, events e metricas.
2. Se necessario, clique no botao **"Abrir no Datadog"** para analise detalhada.
3. Consulte a Dashboard de Troubleshooting no Datadog (descrita abaixo) para cenarios mais complexos.

**Fonte**: Portal Karavela — aba "Observabilidade" nas paginas de aplicacao

---

### Bloqueio de Deployment/Pod pelo Kyverno

O Kyverno e uma solucao de Admission Controller do Kubernetes que aplica enforcements de configuracao de infraestrutura. Um dos bloqueios mais comuns no Karavela e a falta de tags ou valores incorretos nas tags que fazem parte da politica de tags da companhia. Quando o deployment esta com configuracoes incorretas de tags, o pod fica em estado **Pending** ou **Unhealthy** na interface do ArgoCD.

Para identificar o problema, verifique a aba de events do ArgoCD para o objeto (pod ou deployment) em questao. Voce tambem pode usar a aba **Observabilidade** no Portal para visualizar events diretamente.

Para corrigir, garanta que o arquivo `values-<env>.yaml` tenha as labels corretas:

```yaml
# values.yaml do diretorio chart
  labels:
    cost-center: "123456789"
    project: "my-awesome-project"
    owner: "my-owner"
    support: "my-suport-team"
    github-org: "stone-payments"
    github-repo: "my-repo"
    env: "staging"
```

Os valores permitidos para cada label podem ser consultados no repositorio `stone-payments/platform-k8s-policies` no diretorio `policies/kyverno-policies`.

**Fonte**: `karavela/docs/erros_comuns.md` (secao "Bloqueio de Deployment/Pod pelo Kyverno")

---

### Build quebrou devido a vulnerabilidades (Trivy)

Durante o processo de build da imagem e push para o ECR, a etapa de validacao de seguranca pode falhar caso existam vulnerabilidades com severidade **HIGH** ou **CRITICAL** na imagem do container.

Primeiro, analise se a vulnerabilidade e de sistema operacional ou de biblioteca/dependencia de linguagem. Em geral, a correcao envolve atualizar a versao da base image ou dos pacotes vulneraveis:

```diff
# Atualizacao da base image
- FROM golang:1.20-alpine
+ FROM golang:1.21-alpine
```

```Dockerfile
# Atualizacao de pacotes especificos (Alpine)
RUN apk update && apk upgrade pacote1 pacote2 pacote3
```

Para verificar vulnerabilidades localmente antes de enviar ao Karavela, utilize o Trivy:

```bash
# Via Docker
docker run --rm aquasec/trivy image image-name:image-version

# Via binario
trivy image image-name:image-version
```

**Fonte**: `karavela/docs/erros_comuns.md` (secao "Build quebrou devido a vulnerabilidades na aplicacao") e `karavela/docs/faq/faq.md` (secao "Como posso verificar se a minha imagem contem vulnerabilidades")

---

### Campo image.tag vazio no values

> **Nota**: Este cenario se aplica a repositorios que ainda utilizam os workflows antigos/deprecados (`build_and_deploy_stg` / `build_and_deploy_prd.yaml`). Para repositorios que ja migraram para os novos workflows (`karavela_build.yml` / `karavela_deploy.yml`), o campo `image.tag` **nao e mais gerenciado nos arquivos de values** — a tag e resolvida automaticamente pelo pipeline. Se o repositorio ja usa os novos workflows, este cenario nao se aplica.

Quando o campo `image.tag` no arquivo `values-<env>.yaml` esta vazio, o ArgoCD nao consegue fazer o pull da imagem e apresenta o seguinte erro:

```bash
Failed to apply default image tag "697525377503.dkr.ecr.us-east-1.amazonaws.com/myapp:": couldn't parse image reference "697525377503.dkr.ecr.us-east-1.amazonaws.com/myapp:": invalid reference format
```

A causa e que as automacoes de build (`build_and_deploy_stg` ou `build_and_deploy_prd.yaml`) nao foram executadas com sucesso. Essas GitHub Actions possuem um step que realiza o commit da tag no campo `image.tag` do arquivo de values.

Para resolver:
1. Verifique na aba de Actions do repositorio se as actions foram executadas com sucesso.
2. Valide que o arquivo `values-<env>.yaml` contenha a referencia de tag correta.

```yaml
# Exemplo de configuracao correta (workflows antigos)
image:
  repository: "697525377503.dkr.ecr.us-east-1.amazonaws.com/myapp"
  pullPolicy: IfNotPresent
  tag: "abc1234"  # Deve conter a tag gerada pela action de build
```

**Fonte**: `karavela/docs/erros_comuns.md` (secao "Arquivo de values esta com o campo image.tag em branco")

---

### Alteracao de secrets nao refletida nos pods

Apos a alteracao do valor de secrets ou variaveis de ambiente, os pods podem apresentar comportamentos indesejados (falhas, CrashLoopBackOff, etc.) porque nao foram reiniciados para assumir os novos valores.

Para resolver, recicle os pods realizando um restart no Deployment de duas formas:
- **Via Git**: Realizar um commit no arquivo de values.yaml da aplicacao, fazendo com que o ArgoCD faca um novo deploy.
- **Via ArgoCD**: Forcar um restart no deployment pela console do ArgoCD.

**Importante**: Em ambientes de staging, qualquer colaborador possui privilegio para a operacao, incluindo a possibilidade de **deletar sub-recursos de aplicacoes** (pods, replicasets, etc.) diretamente no ArgoCD. Em ambientes produtivos, e necessario solicitar apoio do time de Kubernetes via thread no canal **#help-foundation-platform**.

Alem disso, sempre crie a secret no **Karavela Portal** (aba "Segredos") **antes** de adiciona-la no `values.yaml`. Caso uma secret seja adicionada no values sem existir no Portal, o ArgoCD tentara criar a secret, falhara, e podera gerar problemas de sync no deploy. Desenvolvedores NAO tem acesso direto ao Vault.

**Fonte**: `karavela/docs/erros_comuns.md` (secoes "Alteracao de secrets ainda nao refletiram nos pods da aplicacao" e "Adicao de secrets no values, sem criar previamente no Portal")

---

### Aplicacao sem acesso a recursos AWS (IRSA)

Quando uma aplicacao nao consegue acessar recursos da AWS (S3, SQS, EC2, etc.), um erro comum e a falta de associacao correta da IRSA (IAM Roles for Service Accounts) com a ServiceAccount da aplicacao. O erro tipico e:

```bash
You are not authorized to perform this operation. User: xxxx: assumed-role/someapp-iam-role-20231103140434006600000002/1699343400001785339 is not authorized to perform: ec2:SomeAction
```

Para resolver, verifique no `values.yaml` da aplicacao a chave `cloudProviders.aws.roleArn` e garanta que esteja preenchida corretamente com a IRSA criada para a aplicacao:

```yaml
cloudProviders:
  aws:
    karpenter:
      capacityType: "spot"
    roleArn: arn:aws:iam::123456789120:role/my-awesome-irsa-role
```

**Fonte**: `karavela/docs/erros_comuns.md` (secao "Minha aplicacao nao consegue acessar recursos da AWS")

---

### Container com OOM Killed

Quando um container esta com status OOM Killed, significa que ha falta de recursos de memoria para o container. Para resolver, aumente a quantidade de recursos disponiveis no arquivo de values da aplicacao (campo `resources`).

E importante analisar os graficos de memoria e CPU. Comece pela **aba Observabilidade** no Portal para uma visao rapida das metricas, e se necessario aprofunde na Dashboard de Troubleshooting do Datadog para entender se o problema e realmente falta de recursos ou se ha vazamento de memoria (memory leak) ou starvation de CPU.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/guias-e-manuais/troubleshooting.md` (secao "Meu container esta com OOM Killed")

---

### Container com CrashLoopBackOff

Quando um container esta em CrashLoopBackOff, ha um problema na inicializacao do container. O procedimento recomendado e:

1. Verificar a **aba Observabilidade** no Portal para visualizar events e status dos pods.
2. Analisar os logs do container para identificar a causa raiz.
3. Verificar se secrets/variaveis de ambiente estao configuradas corretamente.
4. Caso nao consiga identificar o problema, abrir um chamado no canal **#help-foundation-platform** no Slack.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/guias-e-manuais/troubleshooting.md` (secao "Meu container esta com CrashloopBackof")

---

### Dashboard de Troubleshooting no Datadog

O Karavela disponibiliza uma Dashboard de troubleshooting no Datadog para acompanhamento de aplicacoes em tempo real. A Dashboard esta dividida em:

- **Overview**: Visao simplificada sobre os pods e seus status.
- **Containers**: Visao geral sobre containers (CPU, memoria, network, status, CrashLoopBackOff, restarts e OOM Killed).
- **Pods**: Visao geral sobre pods (CPU, memoria, status, phase e HPA).
- **Events**: Visao geral sobre eventos (restarts, status, phase, scaling, entre outros).

Os filtros disponiveis sao `cluster_name` e `namespace`, que podem ser obtidos:
- Pelo arquivo de criacao no ArgoCD (`projects/{contexto}/{app-name}` no repositorio do ArgoCD).
- Pelas tags nos logs da aplicacao.
- Pela interface do ArgoCD, selecionando a aplicacao e clicando em "Application details".

**Nota**: Antes de recorrer ao Datadog, utilize a **aba Observabilidade** no Portal, que ja oferece visao de pods, events e metricas com auto-refresh. O botao "Abrir no Datadog" na aba gera um link pre-filtrado para facilitar a transicao.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/guias-e-manuais/troubleshooting.md` (secao "Dashboard de troubleshooting")

---

### Recycle de containers

Para realizar o recycle (reinicializacao) de containers, ha duas opcoes:

**Opcao 1 — Via Git** (recomendada): Adicione uma nova label no arquivo de values do Helm (`values-stg.yaml` ou `values-prd.yaml`). Esse procedimento forca a recriacao dos pods:

```yaml
labels:
  cost-center: "999999999"
  env: "staging"
  project: "karavela"
  owner: "foundation-platform"
  repository: "karavela"
  support: "foundation-platform"
  github-org: "stone-payments"
  github-repo: "karavela"
  new-key: new-value  # Adicione uma nova label para forcar o recycle
```

**Opcao 2 — Via ArgoCD (staging)**: Em ambientes de staging, usuarios agora possuem permissao para **deletar sub-recursos de aplicacoes** (pods, replicasets, etc.) diretamente pelo ArgoCD, facilitando o restart sem necessidade de commit.

**Fonte**: `karavela/docs/faq/faq.md` (secao "Como faco para realizar o recycle de um conteiner no Karavela?")

---

### Rollback de aplicacao via ArgoCD

Para realizar o rollback de uma aplicacao no ArgoCD, basta fazer o revert do commit no Git. O ArgoCD retornara a aplicacao ao seu estado anterior automaticamente.

**Fonte**: `karavela/docs/faq/faq.md` (secao "Como posso realizar o rollback da minha aplicacao utilizando o ArgoCD?")

---

### Formulario do Backstage incompleto

Ao criar ou configurar aplicacoes via Backstage, comportamentos inesperados podem ocorrer por valores incorretos ou falta de informacoes no formulario. Exemplos comuns incluem confirmar o uso das opcoes avancadas e nao preencher valores de variaveis de ambiente ou chaves de secrets.

Para evitar este problema, sempre valide as informacoes na pagina de resumo antes de submeter a criacao do template do Backstage.

**Fonte**: `karavela/docs/erros_comuns.md` (secao "Nao preencher completamente o formulario do Backstage")

---

### Campo `owner` do catalogo quebrado com sintaxe `${{ ... }}`

**Sintoma**: o campo `owner` no `catalog-info.yaml` aparece com uma expressao como `${{ github.actor }}` em vez de um time ou usuario real, e a relacao de ownership do componente nao resolve no catalogo.

**Causa**: `${{ ... }}` e sintaxe de **GitHub Actions Expressions**, avaliada apenas durante a execucao de um workflow (`.github/workflows/*.yml`). O `catalog-info.yaml` **nao e um workflow** — e um arquivo estatico lido diretamente pelo catalogo (Backstage), entao o campo fica literalmente com o texto `${{ github.actor }}`, que nao corresponde a nenhuma entidade `Group`/`User` real.

**Solucao**:
```yaml
# ERRADO - nunca e avaliado, fica literal e quebra a relacao de owner
spec:
  owner: ${{ github.actor }}

# CORRETO - referencie uma entidade registrada no catalogo
spec:
  owner: group:default/time-seu-projeto
  # ou, para um usuario especifico:
  # owner: user:default/seu-usuario
```

> **Nao confunda com o Scaffolder**: a mesma sintaxe `${{ parameters.owner }}` e usada nos templates (`template.yaml`) do Backstage Scaffolder, onde e avaliada pelo backend no momento da geracao do arquivo — mecanismo diferente do GitHub Actions. `github.actor` nao existe nesse contexto.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/deploy-de-aplicacoes/tag-release.md` (secao "Erro 1: Campo owner do catalogo quebrado")

---

### RDS Security Group bloqueando conexoes

Quando uma aplicacao nao consegue conectar ao banco de dados RDS, um dos motivos mais comuns e o Security Group do RDS nao permitir trafego de entrada da aplicacao.

Para verificar e corrigir, acesse o **Portal** e navegue ate a pagina de detalhe do RDS. Na aba **Security Group**, voce pode visualizar e editar as regras de ingress:

- **Type**: `PostgreSQL` (somente leitura)
- **Protocol**: `TCP` (somente leitura)
- **Port**: `5432` (somente leitura)
- **Source/Destination**: Editavel — aceita CIDR (ex: `10.0.0.0/16`) ou Security Group ID (ex: `sg-0abc1234def56789`)
- **Description**: Campo descritivo para documentar a regra

Para resolver, adicione uma regra de entrada com o CIDR da subnet ou o Security Group da aplicacao que precisa se conectar ao RDS.

**Fonte**: Portal Karavela — RDS detail — aba "Security Group"

---

### Break Glass (acesso emergencial a recursos)

O mecanismo de Break Glass permite acesso emergencial a recursos gerenciados pela plataforma. Atualmente, o Break Glass esta disponivel para os seguintes tipos de recursos:

- **RDS** (bancos de dados PostgreSQL/MySQL)
- **Elasticache/Valkey** (cache Redis-compativel)
- **KafkaTopic** (topicos Kafka)

Use o Break Glass quando precisar de acesso direto e emergencial a esses recursos, seguindo o fluxo de solicitacao disponivel no Portal.

**Fonte**: Portal Karavela — fluxo de Break Glass; ver tambem `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/security.md`

---

### Preflight Validation Failed / Modal de Criacao nao Abre

Ao criar ou modificar recursos pela plataforma, uma etapa de **preflight validation** baseada em OPA (Open Policy Agent) valida as configuracoes antes da criacao efetiva do recurso. Atualmente o Portal chama `validate-preflight` **ANTES de abrir o modal** — se o preflight falhar, o modal nao abre e um banner exibe os erros.

Cada erro vem como `{ field, message, code }`. As 5 policies sao: `core`, `infrastructure`, `labels`, `identity`, `lifecycle`.

Para resolver:
1. Leia o banner — ele indica `field` + `message`.
2. Os erros mais comuns sao em `labels` (faltam cost-center, owner, etc.) ou em `identity` (IRSA nao configurada, owner sem group).
3. Corrija via Portal (aba Application) ou via PR no repo da aplicacao.
4. Tente abrir o modal novamente.

Caso o erro nao seja claro ou voce acredite que se trata de um falso positivo, abra um chamado no canal **#help-foundation-platform** no Slack.

**Fonte**: Portal Karavela — Preflight Validation (OPA); ver tambem `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/security.md`

---

### Build Integrity attestation `not_configured` / `regressed`

A aba **Dependencies > Build Integrity** no Portal pode mostrar uma das seguintes badges:

| Estado | O que verificar |
|--------|------------------|
| `verified` | Tudo OK — imagem com SLSA L3. |
| `legacy` | Imagem criada antes de `2026-04-14T00:00:00Z`. Faca um novo build para gerar attestation. |
| `not_configured` | Workflow `karavela_build.yml` nao declarou `permissions: id-token: write` + `attestations: write`, OU `karavela_deploy.yml` nao recebeu `IMAGE_DIGEST`. Adicione ambos e refaca o ciclo build+deploy. |
| `regressed` | App ja foi `verified` mas atual deploy nao tem attestation. Mesma checklist do `not_configured`. |

Exemplo correto:

```yaml
jobs:
  build:
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_build.yml@main
    permissions:
      id-token: write
      attestations: write
  deploy:
    needs: build
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_deploy.yml@main
    with:
      IMAGE_DIGEST: ${{ needs.build.outputs.image_digest }}
```

**Fonte**: `karavela-core/docs/build-integrity/index.md` (complemento — nao em docs/)

---

### Workflows de Provisionamento Travados (RDS/ElastiCache/SQS/Kafka)

Workflows de criacao de recursos da plataforma rodam no backend interno do Karavela. Sintomas: order ficou em `PENDING` por horas no Portal, deploy nao gera secret no Vault, IRSA nao foi criada.

Como proceder:
1. Verifique no Portal Karavela o status da ordem (aba "Minhas Solicitacoes" / "Orders").
2. Verifique se ha incidente ativo da plataforma no Portal (Incidents Dashboard).
3. Abra um chamado no canal **#help-foundation-platform** descrevendo o nome da aplicacao e a ID da order.

**Fonte**: Portal Karavela; `temporal/runbooks/` (complemento — nao em docs/, runbooks operacionais do time de plataforma)

---

### Metricas/Traces OTLP nao chegam no Grafana ou Datadog

Sintoma: aplicacao instrumentada com OTel mas dashboards estao vazios.

Causa mais comum: SDK foi inicializado com **endpoint/protocol hardcoded** no codigo, ignorando as envs `OTEL_EXPORTER_OTLP_METRICS_ENDPOINT` / `OTEL_EXPORTER_OTLP_GRPC_ENDPOINT` / `OTEL_EXPORTER_OTLP_HTTP_ENDPOINT` injetadas pelo chart.

Diagnostico:
1. Verifique nos logs do pod se a aplicacao loga o endpoint que esta usando.
2. Confira via `kubectl exec` que as envs OTEL estao presentes.
3. Faca grep no codigo por `WithEndpoint(`, `OTLPMetricGrpcExporterBuilder`, `OtlpGrpcSpanExporter` com URLs literais.

Solucao: deixe o SDK ler do ambiente (sem `WithEndpoint`/`WithUrlOverride` no codigo). O chart injeta as envs automaticamente.

**Fonte**: Skill `observabilidade` (secao Metricas + APM), karavela/docs/guia-do-desenvolvedor/observabilidade/metrics.md

---

### Incidents Dashboard no Portal

O Portal possui uma secao **"Incidents Dashboard"** acessivel pela sidebar, destinada a analise de incidentes a nivel organizacional. O dashboard oferece:

- **Root Cause Analysis**: Analise de causas raiz de incidentes passados.
- **Executive Dashboard**: Visao executiva com metricas agregadas de incidentes.
- **Incident Matrix**: Matriz de incidentes para correlacao e identificacao de padroes.

Utilize o Incidents Dashboard para entender tendencias de incidentes, identificar causas recorrentes e apoiar decisoes de melhoria de resiliencia.

**Fonte**: Portal Karavela — Incidents Dashboard (sidebar)

---

### Order status `cancelled`

No ciclo de vida de recursos gerenciados pela plataforma, as orders podem assumir diversos status. O status **`cancelled`** indica que um **rollback (undelete) foi realizado com sucesso** no contexto de um fluxo de exclusao de recurso.

Ou seja, se uma order de delete foi iniciada e posteriormente revertida, o status final sera `cancelled`, confirmando que o recurso foi restaurado e a exclusao foi desfeita.

**Fonte**: Portal Karavela — Order lifecycle; `karavela/docs/guia-do-desenvolvedor/gerenciamento-aplicacoes/descomissionamento.md`

---

### Values Tests bloqueando PRs

Usuarios podem encontrar PRs bloqueadas por falhas na validacao de values (nivel **FAIL**). Isso ocorre quando o arquivo de values da aplicacao nao atende aos guardrails definidos pela plataforma.

Para resolver:
1. Verifique os logs da check de validacao na PR para identificar quais regras falharam.
2. Consulte a documentacao de **values-tests** e o arquivo de referencia `karavela_containers_guardrails.yaml` para entender os criterios de validacao.
3. Corrija os valores no arquivo `values-<env>.yaml` de acordo com os guardrails.
4. Faca um novo push para a PR e aguarde a re-execucao da validacao.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/guias-e-manuais/values-tests.md`, `karavela/docs/guia-do-desenvolvedor/guias-e-manuais/guardrails-validator.md`

### Convencoes de Nomeacao de Recursos da Plataforma

A Karavela aplica prefixos, sufixos e padroes de nomeacao automaticos aos recursos criados. Conhecer esses padroes e essencial para troubleshooting de nomes de recursos, security groups e chaves de segredos.

| Tipo de recurso | Padrao de nome | Exemplo |
|----------------|----------------|---------|
| **RDS** (claim) | `<nome>-<ambiente>` | `payments-db-stg` |
| **RDS** (identifier) | `<nome>-<rand4>-<ambiente>` | `payments-db-a1b2-stg` |
| **RDS** (replica) | `<identifier>-rpl-<rand4>` | `payments-db-a1b2-stg-rpl-c3d4` |
| **RDS** (database name) | `<nome>_db` (hifens → underscores) | `payments_db` |
| **RDS** (app user) | `<nome>_appuser` | `payments_appuser` |
| **ElastiCache** (claim) | `<nome>-<ambiente>` | `payments-cache-stg` |
| **ElastiCache** (resourcesName) | `<nome>-<rand4>-<ambiente>` | `payments-cache-a1b2-stg` |
| **S3** (bucket) | `<nome>-<ambiente>` | `payments-files-stg` |
| **SQS** (fila) | `mqaas-<nome>-<ambiente>` | `mqaas-payments-events-stg` |
| **SQS** (FIFO) | `mqaas-<nome>-<ambiente>.fifo` | `mqaas-payments-events-stg.fifo` |
| **SQS** (DLQ) | `mqaas-<nome>-<ambiente>-dlq` | `mqaas-payments-events-stg-dlq` |
| **Kafka Topic** | `kafka-topic-<hash10>` | `kafka-topic-a1b2c3d4e5` |
| **Gateway Service** (multi-provider) | `<nome>-<providerName>` | `checkout-api-kong-internal` |

Regras gerais:
- Sufixos aleatorios (`<rand4>`) possuem 4 caracteres alfanumericos em minusculo
- O hash de Kafka Topics e calculado a partir de `clusterID + "-" + topicName` (primeiros 10 chars)
- SQS sempre recebe prefixo `mqaas-`; FIFO adiciona `.fifo`; DLQ adiciona `-dlq`
- Gateway Service adiciona `-<providerName>` somente em modo multi-provider

**Fonte**: `temporal/docs/concepts/prefixos-sufixos-recursos-karavela.md` (complemento — nao em docs/)

---

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever; producao exige dupla confirmacao. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **KLI read** (livre): `kli check app`, `kli get events`, `kli logs app`, `kli watch app`, `kli describe app`, `kli doctor`
- **Datadog/Grafana** read via `mcp__vela-mcp-hub__observability__*` para diagnostico
- **Editar `chart/values-*.yaml`** — corrigir labels, resources (OOM), probes, image.tag, ingress
- **Editar workflows** — corrigir image.tag vazio, IMAGE_DIGEST, etc.
- **Abrir PR draft** com a correcao

### Fluxo padrao de diagnostico
1. `kli check app <nome>` para visao geral
2. `kli get events` se houver erro nos pods
3. `kli logs app` para investigar runtime
4. Se identificar root cause de config: `🛠️ Acao proposta: edito values + abro PR`

### Triggers proativos
- "Meu app esta em CrashLoopBackOff" → executa `kli check app` + `kli logs app` + diagnostico
- "Kyverno bloqueou" → identificar labels faltando + propor fix em values
- "OOM Killed" → ler logs/metricas + propor `resources.memory` ajustado
- "Secrets nao refletiram" → propor `reloadEnabled: true` no values + restart de pod via KLI

### Acoes destrutivas (dupla confirmacao)
- Restart de pod em prd — orientar via Portal Karavela ou KLI com aprovacao (n/a no codigo).
- Sugerir rollback em prd — usar Portal Karavela; nunca tentar via API direta.

## Instrucoes MCP

Quando você ainda não estiver certeza da resposta use o GITHUB mcp. Priorize a documentacao oficial em `stone-payments/karavela` `docs/`; outros repositorios servem apenas como fallback.

**Fontes primarias (docs/):**

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/karavela` | `docs/erros_comuns.md` | Erros comuns: Kyverno, Trivy, image.tag vazio, secrets, IRSA |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/deploy-de-aplicacoes/tag-release.md` | Erros do fluxo de release: owner com `${{ }}` no catalog-info, tag manual, merge vs rebase |
| `stone-payments/karavela` | `docs/faq/faq.md` | FAQ: recycle, rollback via ArgoCD, verificacao de vulnerabilidades, replicas |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/guias-e-manuais/troubleshooting.md` | OOM Killed, CrashLoopBackOff, Dashboard de Troubleshooting |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/gerenciamento-aplicacoes/index.md` | Ciclo de vida de aplicacoes e ordens |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/guias-e-manuais/values-tests.md`, `guardrails-validator.md` | Bloqueios em PR por values tests |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/seguranca-e-conectividade/security.md` | Trivy, Kyverno, Preflight |

**Fontes secundarias (complemento — nao em docs/):**

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/platform-k8s-policies` | `policies/kyverno-policies` | Valores permitidos para labels/tags do Kyverno |
| `stone-payments/platform-k8s-argo` | `projects/` | Contexto, cluster_name ou namespace de uma aplicacao |
| `stone-payments/platform-k8s-github-actions` | `.github/workflows/` | Falhas nas actions de build e deploy |
| `stone-payments/karavela-core` | `docs/build-integrity/index.md` | Build Integrity (SLSA L3 attestations) |

## Formato de Resposta

Ao responder perguntas deste dominio, siga este formato:

1. **Explicacao** (2-3 frases objetivas em PT-BR)
2. **Exemplo pratico** (YAML, comando ou config copiavel)
3. **Fonte** (referencia ao arquivo/secao da documentacao)
4. **Avisos** (se aplicavel: restricoes de ambiente, privilegios necessarios)

## Links Uteis

- Jira / Confluence: `https://allstone.atlassian.net`

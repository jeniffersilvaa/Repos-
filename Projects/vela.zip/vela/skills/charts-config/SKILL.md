---
name: charts-config
description: "Configuracao de Helm charts da plataforma Karavela. Use quando o usuario perguntar sobre Chart.yaml, values.yaml, padrao umbrella chart, tipos de chart (API, Worker, CronJob, Job, StatefulSet), versionamento de charts, parametros de configuracao, initContainers, sidecars, terminationGracePeriodSeconds, PodMonitor, volumes, volumeMounts, canaryStrategy, dnsrecord, alerts (mimir/loki) ou telemetry (opentelemetry/openmetrics)."
---

# Skill: charts-config

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.

  Exemplos de uso:
  - Corrigir informacao desatualizada no conhecimento embutido
  - Adicionar restricao temporaria (ex: "chart v4 nao suporta feature X")
  - Adicionar conhecimento que ainda nao esta na documentacao oficial
  - Bloquear uma orientacao especifica (ex: "NAO recomende usar scaler Y")
-->

## Escopo

**Cobre**:
- Padrao umbrella chart (dependencia no `Chart.yaml` apontando para charts OCI da plataforma)
- Estrutura de `values-*.yaml` no diretorio `./chart/`
- Versionamento de charts gerenciado pela Karavela API (`chart_version`, rollout staging→sandbox→producao, manifesto multi-source no ArgoCD)
- Politica de release SemVer dos charts (suporte a majors)
- Tipos de chart: API, Worker, CronJob, Job, StatefulSet
- Parametros comuns do `values.yaml` (image, envs, jsonEnvs, healthcheck, resources, labels, annotations, application, containerPort, lifecycle, ingress, PDB, volumes, volumeMounts, sidecars, configMap, networkpolicy, canaryStrategy, cloudProviders, dnsrecord)
- InitContainers (configuracao de containers de inicializacao com suporte a `enabled`, `jsonEnvs` e bloco `secrets` estruturado)
- TerminationGracePeriodSeconds (tempo de graceful shutdown)
- PodMonitor para coleta de metricas OpenMetrics (campo `portNumber` nos targets)
- Telemetry OpenTelemetry (metricas com `infraCardinalityLevel` e datastores)
- ExternalSecret v1 e Harbor registry (imagePullSecrets)
- Datadog Monitors via values.yaml
- Alertas Mimir e Loki (alerting_rules e recording_rules)
- DNS Record (configuracao de registro DNS para API chart)

**NAO cobre**:
- Autoscaling/KEDA (coberto por `recursos-scaling`)
- Secrets/Vault (coberto por `secrets-vault`)
- Fluxos de deploy e rollback (coberto por `deploy-rollback`)
- Observabilidade/Datadog (coberto por `observabilidade`)

## Exemplos de Perguntas

- "Como configuro o Chart.yaml para usar o chart de API da plataforma?"
- "Qual a estrutura basica do values.yaml para um worker?"
- "Como funciona o versionamento dos charts? Quem controla a versao do chart da minha aplicacao?"
- "Por que o `1.*.*` no Chart.yaml nao atualiza mais o chart? Como vejo a versao do chart em uso?"
- "Quais labels e annotations sao obrigatorias no values.yaml?"
- "Como configuro healthcheck (liveness e readiness) no chart de API?"
- "Como defino resources de CPU e memoria para minha aplicacao?"
- "Qual a diferenca entre o chart de CronJob e o chart de Job?"
- "Como configuro um ingress no chart de API?"
- "Como configuro volumes e volumeMounts no meu pod?"
- "Como configuro alertas no Mimir ou Loki?"
- "Como crio um registro DNS para minha API?"
- "Como configuro metricas OpenTelemetry no chart?"

## Conhecimento Embutido

### O que sao os Helm Charts da plataforma

Os charts da plataforma Karavela sao Helm Charts criados para facilitar a utilizacao de entidades do Kubernetes e integracoes com ferramentas adotadas. O time de Kubernetes disponibiliza os charts necessarios para levantar aplicacoes. Os tipos disponiveis sao:

- **Chart de API** (`platform-k8s-api-chart`): Para aplicacoes que expoe endpoints HTTP/gRPC (com ingress, healthcheck, containerPort, PDB, canary strategy, dnsrecord).
- **Chart de Worker** (`platform-k8s-worker-chart`): Para aplicacoes que processam mensagens de filas/topicos (sem ingress, healthcheck desabilitado por padrao).
- **Chart de CronJob** (`platform-k8s-cronjob-chart`): Para tarefas agendadas com schedule cron (configuracao de `jobs` com schedule, concurrencyPolicy, restartPolicy).
- **Chart de Job** (`platform-k8s-job-chart`): Para execucoes unicas (com backoffLimit, ttlSecondsAfterFinished, hooks ArgoCD).

O repositorio oficial dos charts e: https://github.com/stone-payments/platform-k8s-charts

**Fonte**: `karavela/docs/guia-do-desenvolvedor/charts.md`

### Versoes Atuais dos Charts

| Chart | Versao atual |
|-------|-------------|
| API | v1.38.11 |
| Worker | v1.30.10 |
| CronJob | v1.23.0 |
| Job | v1.23.10 |
| StatefulSet | v1.12.11 |

**Fonte**: `platform-k8s-charts` (complemento — nao em docs/)

### Padrao Umbrella Chart (Chart.yaml)

A aplicacao utiliza o padrao umbrella chart: o `Chart.yaml` do repositorio da aplicacao declara uma dependencia para o chart OCI da plataforma. O chart da plataforma e baixado do registro OCI da AWS ECR.

```yaml
# Exemplo de Chart.yaml para uma aplicacao API
apiVersion: v2
name: my-amazing-app
description: A Helm chart for Kubernetes
type: application
version: 1
appVersion: "1.16.0"
dependencies:
- name: platform-k8s-api-chart
  version: 1.*.*
  repository: oci://697525377503.dkr.ecr.us-east-1.amazonaws.com
```

> **Atencao**: **Mantenha o `Chart.yaml` no repositorio** — o arquivo continua sendo uma dependencia para o funcionamento dos `values.yaml` da aplicacao. Porem, desde o novo modelo de versionamento, a versao do chart **deixou de ser resolvida pelo repositorio**: a notacao `1.*.*` nao gatilha mais atualizacao automatica. Quem controla a versao e a Karavela API (ver secao abaixo).

**Fonte**: `karavela/docs/guia-do-desenvolvedor/charts.md` e `karavela/docs/guia-do-desenvolvedor/versionamento-rollout-charts.md`

### Versionamento de Charts Gerenciado pela Karavela API

A versao do chart de cada aplicacao (`chart_version`) e **registrada e controlada pela Karavela API** — nao mais pelo `Chart.yaml` do repositorio. A plataforma decide qual versao do chart cada aplicacao usa em cada ambiente, de forma centralizada.

Caracteristicas do modelo:

- **Manifesto multi-source no ArgoCD**: a aplicacao usa duas fontes independentes — (1) values + imagem continuam vindo do repositorio da aplicacao; (2) o chart vem do artefato versionado publicado pela plataforma (umbrella chart `karavela-application-chart`, no registro ECR), com versao controlada pela Karavela API.
- **Build e upgrade de chart sao independentes**: subir uma nova versao da imagem nao muda a versao do chart, e um upgrade de chart nao dispara um novo build/deploy da aplicacao. Nao depende mais de um push no `values.yaml` para sincronizar a versao.
- **Rollout controlado por ambiente**: quando uma nova versao de chart e lancada, o rollout e ordenado dos ambientes menos criticos para a producao primaria (staging → sandbox → producao). Um ambiente so e atualizado depois que os anteriores forem concluidos com sucesso; se algo falhar, os seguintes nao sao alterados.
- **Idempotente**: aplicacao ja na versao-alvo e ignorada — seguro reexecutar em caso de falha parcial.
- **Rollback granular**: o rollback de versao de chart e controlado pela plataforma, por aplicacao, contexto ou ambiente, reaplicando uma versao estavel anterior.
- **Migracao transparente**: aplicacoes novas ja nascem multi-source; aplicacoes existentes sao migradas pela plataforma, sem PR ou alteracao no repositorio.

O que muda para o dev: **nada no dia a dia** — o deploy continua igual (branch/commit ou tag/release). Para ver a versao do chart em uso, consulte o **ArgoCD**: no manifesto da aplicacao (multi-source), a fonte do chart traz a versao no campo `targetRevision`.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/versionamento-rollout-charts.md`

### Politica de Release dos Charts (SemVer)

Os charts seguem o modelo de versionamento semantico: `major.minor.patch`. A politica de release define como as versoes sao publicadas; a aplicacao delas nas suas apps e feita pela Karavela API (secao anterior).

- **Patch**: Corrige pequenos problemas e bugs. Nao introduz novos recursos. Exemplo: de `1.0.1` para `1.0.2`.
- **Minor**: Inclui novas funcionalidades e aprimoramentos sem alterar a estrutura do `values.yaml` (pode acrescentar novas chaves, mas nao modifica ou retira as existentes). Nao contem breaking changes. Exemplo: de `1.0` para `1.1`.
- **Major**: Atualizacao significativa que pode envolver mudancas substanciais e breaking changes. Exemplo: de `1.1` para `2.0`.

**Fonte**: `karavela/docs/politica_charts.md`

### Tempo de Suporte dos Charts

Cada versao major recebe desenvolvimento ativo por 6 meses. Apos o lancamento da proxima major, a versao anterior recebe apenas patches de correcao por mais 6 meses antes de ser completamente descontinuada.

| Versao | Descricao                        | Data de Lancamento |
| ------ | -------------------------------- | ------------------ |
| 1.0    | Lancamento da versao 1           | Jan/2024           |
| 2.0    | Lancamento da versao 2           | Jul/2024           |
| 3.0    | Lancamento da versao 3           | Jan/2025           |
| 4.0    | Lancamento da versao 4           | Jul/2025           |

**Fonte**: `karavela/docs/politica_charts.md`

### Configuracao de Imagem e Porta (API Chart)

O chart de API exige configuracao de imagem do container e porta de exposicao. O `securityContext` padrao roda com usuario e grupo `1000`.

```yaml
# Configuracao basica de imagem e porta para API
replicaCount: 1

image:
  repository: "697525377503.dkr.ecr.us-east-1.amazonaws.com/minha-api"
  pullPolicy: IfNotPresent
  tag: "v1.2.3"

containerPort: 80

securityContext:
  runAsUser: 1000
  runAsGroup: 1000
  sysctls:
    - name: net.ipv4.tcp_keepalive_time
      value: "60"
    - name: net.ipv4.tcp_keepalive_intvl
      value: "10"
    - name: net.ipv4.tcp_keepalive_probes
      value: "6"
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/image.md`, `funcionalidades/container-port.md`, `funcionalidades/security-context.md`; `platform-k8s-charts/platform-k8s-api-chart/values.yaml` (complemento — nao em docs/)

### SecurityContext Sysctls (TCP Keepalive)

Todos os charts (API, Worker, CronJob, Job, StatefulSet) incluem valores padrao de TCP keepalive via `securityContext.sysctls`. Os parametros sao aplicados em **todos os ambientes** (staging, sandbox e production). Ajudam a detectar conexoes TCP mortas mais rapidamente, especialmente para aplicacoes que mantem conexoes persistentes com bancos de dados ou caches.

```yaml
securityContext:
  sysctls:
    - name: net.ipv4.tcp_keepalive_time
      value: "60"    # tempo idle antes de enviar o primeiro keepalive probe
    - name: net.ipv4.tcp_keepalive_intvl
      value: "10"    # intervalo entre probes
    - name: net.ipv4.tcp_keepalive_probes
      value: "6"     # numero de probes antes de considerar a conexao morta
```

Um helper `safeSysctls` filtra a lista permitindo apenas sysctls autorizados:
- `net.ipv4.tcp_keepalive_time`
- `net.ipv4.tcp_keepalive_intvl`
- `net.ipv4.tcp_keepalive_probes`

Para desabilitar os sysctls, sobrescreva com lista vazia:

```yaml
securityContext:
  sysctls: []
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/security-context.md`; `platform-k8s-charts/.docs/changelogs/CHANGELOG.api.md` (v1.38.0), `CHANGELOG.worker.md` (v1.30.0) (complemento — nao em docs/)

### Labels e Annotations Obrigatorias

Todos os charts exigem labels e annotations para identificacao, custo e rastreabilidade. Os valores `__change_me__` devem ser substituidos pela equipe.

```yaml
labels:
  cost-center: "meu-centro-custo"
  env: "production"               # staging | sandbox | production
  project: "minha-api"
  owner: "time-pagamentos"
  support: "infraestrutura-aws"
  github-org: "stone-payments"
  github-repo: "minha-api"

annotations:
  documentation: "https://docs.exemplo.com/minha-api"
  # inject-pod-ip: "true"         # opcional — injeta POD_IP via Kubernetes Downward API

application:
  name: "minha-api"
  language: "golang"
  environment: "production"       # staging | sandbox | production
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/labels-annotations.md`; `platform-k8s-charts/platform-k8s-api-chart/values.yaml` (complemento — nao em docs/)

### Injecao de POD_IP via Downward API (Chart API v1.38.11+)

A annotation `annotations.inject-pod-ip: "true"` faz o chart injetar automaticamente a variavel de ambiente `POD_IP` no container principal, lendo o IP do Pod via Kubernetes Downward API. Util para descoberta local, logs enriquecidos com endereco de origem ou aplicacoes que precisam reportar o proprio IP em telemetria/registro.

```yaml
annotations:
  documentation: "https://docs.exemplo.com/minha-api"
  inject-pod-ip: "true"           # injeta env var POD_IP no container principal
```

Por padrao a injecao fica desabilitada — habilite somente quando a aplicacao realmente precisar do POD_IP em runtime.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/labels-annotations.md`; `platform-k8s-charts/.docs/changelogs/CHANGELOG.api.md` (v1.38.11) (complemento — nao em docs/)

### Variaveis de Ambiente (envs e jsonEnvs)

Todos os charts suportam variaveis de ambiente via `envs` (valores simples) e `jsonEnvs` (valores JSON).

```yaml
envs:
  DATABASE_HOST: "db.exemplo.com"
  LOG_LEVEL: "info"
  APP_PORT: "8080"

jsonEnvs:
  FEATURE_FLAGS: '{"enable_new_flow": true, "max_retries": 3}'
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/envs-jsonenvs-configmap.md`

### Healthcheck (Probes) - Chart de API

No chart de API, `livenessProbe` e `readinessProbe` vem habilitados por padrao. O `startupProbe` vem desabilitado. Probes podem ser configuradas por path HTTP ou por comando.

```yaml
healthcheck:
  livenessProbe:
    enabled: true
    path: /healthz
    failureThreshold: 3
    periodSeconds: 20
    initialDelaySeconds: 15
    timeoutSeconds: 10

  readinessProbe:
    enabled: true
    path: /ready
    failureThreshold: 3
    periodSeconds: 20
    initialDelaySeconds: 15
    timeoutSeconds: 10

  startupProbe:
    enabled: false
```

No chart de Worker, as probes vem desabilitadas por padrao (`enabled: false`).

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/health-check.md`; `platform-k8s-charts/platform-k8s-api-chart/values.yaml`, `platform-k8s-worker-chart/values.yaml` (complemento — nao em docs/)

### Resources (CPU, Memoria e Storage)

Cada tipo de chart possui valores padrao diferentes para resources:

- **API**: `memory: "500Mi"`, `cpu: "1"`, `storage: "1Gi"`
- **Worker**: `memory: "256Mi"`, `cpu: "128m"`, `storage: "1Gi"`
- **CronJob** (por job): `memory: "128Mi"`, `cpu: "100m"`, `storage: "1Gi"`
- **Job**: `memory: "128Mi"`, `cpu: "100m"`, `storage: "1Gi"`

```yaml
# Exemplo de resources para API
resources:
  memory: "500Mi"
  cpu: "1"
  storage: "1Gi"
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/resources.md`; `platform-k8s-charts/*/values.yaml` (complemento — nao em docs/) para valores default

### Volumes e VolumeMounts (Pod-level)

Todos os charts suportam `volumes` e `volumeMounts` no nivel do pod, permitindo montar volumes adicionais (ConfigMap, Secret, emptyDir, PVC, etc.) diretamente no container principal.

```yaml
volumes: []
volumeMounts: []
```

Exemplo com volume emptyDir e ConfigMap:

```yaml
volumes:
  - name: tmp-data
    emptyDir: {}
  - name: app-config
    configMap:
      name: my-config

volumeMounts:
  - name: tmp-data
    mountPath: /tmp/data
  - name: app-config
    mountPath: /etc/config
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/volumes.md`

### Configuracao de CronJob

O chart de CronJob permite definir multiplos jobs agendados. Cada job possui configuracao independente de schedule, resources, politica de concorrencia e restart. A partir do chart v1.23.0, e possivel configurar `startingDeadlineSeconds` e `activeDeadlineSeconds` para controlar comportamento de catch-up e timeout de execucao.

```yaml
jobs:
  - name: "sync-dados-diario"
    image: ""                          # image:tag - para imagem fixa
    suspend: ""                        # true | false
    timeZone: 'America/Sao_Paulo'
    schedule: "0 3 * * *"             # cron - executa as 3h da manha
    command: ""
    args: ""
    failedJobsHistoryLimit: 1
    successfulJobsHistoryLimit: 3
    concurrencyPolicy: Forbid
    restartPolicy: Never
    resources:
      memory: "128Mi"
      cpu: "100m"
      storage: "1Gi"
    backoffLimit: 6
    # startingDeadlineSeconds: 300   # opcional: segundos apos o horario agendado em que ainda pode iniciar (evita catch-up ao destravar CronJob suspenso). Aceita 0.
    # activeDeadlineSeconds: 10800   # opcional: tempo maximo em segundos que a execucao pode ficar ativa antes do K8s encerrar. Aceita 0.
```

- `startingDeadlineSeconds`: prazo (em segundos) apos o horario agendado dentro do qual o job ainda pode ser iniciado. Se vencer, a execucao e descartada — util para evitar avalanche de execucoes "atrasadas" ao destravar um CronJob suspenso.
- `activeDeadlineSeconds`: tempo maximo de execucao do Job criado pelo cron antes de ser terminado pelo Kubernetes. Bom guardrail contra jobs travados rodando indefinidamente.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/cronjob.md`; `platform-k8s-charts/.docs/changelogs/CHANGELOG.cronjob.md` (v1.23.0) (complemento — nao em docs/)

### Configuracao de Job

O chart de Job e voltado para execucoes unicas. Possui integracao com ArgoCD via hooks (PostSync por padrao) e `ttlSecondsAfterFinished` para limpeza automatica.

```yaml
job:
  command: ""
  args: ""
  restartPolicy: Never
  backoffLimit: 5
  activeDeadlineSeconds: ""
  parallelism: ""
  completions: ""
  ttlSecondsAfterFinished: 600

argocd:
  hooks:
    enabled: true
    type: "PostSync"
    deletePolicy: "BeforeHookCreation"
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/job.md`

### Ingress (Chart de API)

O chart de API suporta tres tipos de ingress: `ingress` (interno), `ingressKaravelaRun` (gerenciado pelo Karavela) e `ingressExternal` (externo). Todos vem desabilitados por padrao.

```yaml
# Ingress interno
ingress:
  enabled: true
  annotations: {}
  class: ingress-nginx
  pathType: ImplementationSpecific
  hosts:
    - host: minha-api.internal.local
      paths:
        - path: /

# Ingress gerenciado pelo Karavela
ingressKaravelaRun:
  enabled: true
  class: nginx-ingress-controller
  pathType: ImplementationSpecific
  managedHosts:
    mainHost: "minha-api.karavela.run"
    regionalHost: "minha-api-us-east-1.karavela.run"
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/ingress.md`

### PodDisruptionBudget (PDB) - Chart de API e Worker

Os charts de API e Worker vem com PDB habilitado por padrao (`minAvailable: 50%`), garantindo disponibilidade minima durante operacoes de manutencao do cluster.

```yaml
pdb:
  enabled: true
  minAvailable: 50%
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/pdb.md`

### Cloud Providers (AWS e Azure)

Os charts suportam configuracao para AWS e Azure, incluindo Karpenter (spot/on-demand), IRSA (roleArn), workload identity (Azure) e imagePullSecrets. O campo `imagePullSecrets.name` permite especificar o nome do secret para pull de imagens (ex: ECR, Harbor).

```yaml
cloudProviders:
  aws:
    enabled: true
    karpenter:
      enabled: true
      capacityType: "spot"         # "on-demand" ou "spot" (default: "spot")
      selector: "meu-provisioner"
    roleArn: "arn:aws:iam::123456789:role/minha-role"
    imagePullSecrets:
      name: "ecr-pull-secret"
```

O valor padrao de `capacityType` e `"spot"`.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/cloud-providers.md`

### Canary Strategy (Chart de API e Worker)

Os charts de API e Worker suportam configuracao de estrategia canary para deploys progressivos via Argo Rollouts. O `dynamicStableScale` reduz proporcionalmente as replicas da versao estavel durante o canary, prevenindo duplicacao temporaria de Pods. Os campos `abortScaleDownDelaySeconds` e `scaleDownDelayRevisionLimit` controlam o comportamento de scale-down apos abort e o limite de revisoes mantidas, respectivamente.

```yaml
canaryStrategy:
  dynamicStableScale: true
  minPodsPerReplicaSet: 1
  abortScaleDownDelaySeconds: 60
  scaleDownDelayRevisionLimit: 2
  maxSurge: "25%"
  maxUnavailable: 0
```

- `abortScaleDownDelaySeconds`: Tempo em segundos antes de reduzir replicas apos um abort do canary. Default: `60`.
- `scaleDownDelayRevisionLimit`: Numero maximo de revisoes antigas mantidas antes de serem removidas. Default: `2`.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/canary-deploy.md`; `platform-k8s-charts/.docs/CHANGELOG.api.md` (v1.31.2) (complemento — nao em docs/)

### InitialJob (API e Worker)

Os charts de API e Worker permitem configurar um job inicial que e executado antes da aplicacao principal subir.

```yaml
initialJob:
  enabled: true
  image: ""
  resources:
    memory: "256Mi"
    cpu: "100m"
  command: ["/bin/sh"]
  args:
    - "-c"
    - "python manage.py migrate"
  restartPolicy: Never
  backoffLimit: 1
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/initialjob.md`

### Sidecars

Todos os charts suportam containers sidecar com configuracao independente de imagem, recursos, secrets e variaveis de ambiente. O bloco `secrets` e estruturado com `envVarEnabled`, `loadAllKeys` e `keys`.

```yaml
sidecars:
  - name: "nginx-proxy"
    image: "nginx:latest"
    command: []
    args: []
    secrets:
      envVarEnabled: false
      loadAllKeys: false
      keys: []
    envs:
      PROXY_PORT: "8081"
    containerPort: "8081"
    resources:
      memory: "128Mi"
      cpu: "100m"
    volumeMounts: []
```

Se o campo `image` for omitido, a `image.tag` gerada pelo build da aplicacao (usada no container principal) e automaticamente utilizada no sidecar.

#### Compartilhamento de secrets entre containers

Os segredos da aplicacao injetados no Pod podem ser **compartilhados por todos os containers do mesmo Pod** habilitando `secrets.envVarEnabled: true` e `secrets.loadAllKeys: true` no sidecar:

```yaml
sidecars:
  - name: "app-sidecar1"
    enabled: true
    secrets:
      envVarEnabled: true
      loadAllKeys: true
```

Ao atualizar um segredo pelo Portal Karavela, o Pod e automaticamente reinicializado carregando o novo segredo em **todos os containers**.

Sidecars tambem combinam com **volumes compartilhados**: declare o volume em `volumes` (global) e monte em `volumeMounts` do sidecar e do container principal para trocar arquivos entre eles.

#### Interacao com initialJob

Sidecars sao injetados apenas no Pod da aplicacao — **nao** entram no Pod do `initialJob` por default. Se precisar do sidecar no initialJob (cenario raro; requer que o sidecar termine por conta propria), habilite `initialJob.includeSidecars: true`. Sidecars *long-running* travam o estado `Completed` do Job e o sync hook do ArgoCD.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/sidecars.md`; `karavela/docs/guia-do-desenvolvedor/funcionalidades/initialjob.md`; `platform-k8s-charts/.docs/CHANGELOG.api.md` (v1.32.1, v1.35.0) (complemento — nao em docs/)

### InitContainers

Todos os charts (API, Worker, CronJob, Job) suportam `initContainers` que executam antes do container principal. Reutilizam a imagem principal por padrao. Tem acesso as secrets da aplicacao. Suportam `enabled` para ativar/desativar individualmente, `jsonEnvs` para variaveis JSON e bloco `secrets` estruturado.

```yaml
initContainers:
  - name: "run-migrations"
    enabled: false
    image: ""
    command: ["/bin/sh"]
    args: ["-c", "python manage.py migrate"]
    secrets:
      envVarEnabled: false
      loadAllKeys: false
      keys: []
    envs:
      DB_HOST: "db.exemplo.com"
    jsonEnvs: {}
    resources:
      memory: "128Mi"
      cpu: "100m"
    volumeMounts: []
```

- `enabled`: Permite ativar ou desativar o initContainer sem removê-lo da configuracao. Default: `false`.
- `jsonEnvs`: Variaveis de ambiente com valores JSON, mesmo formato do container principal.
- `secrets`: Bloco estruturado com `envVarEnabled`, `loadAllKeys` e `keys` para controle granular de secrets.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/init-containers.md`

#### InitContainers com Volumes Compartilhados

Init Containers podem compartilhar volumes com o container principal da aplicacao usando `volumes` e `volumeMounts`. Se o campo `image` for omitido ou vazio, a imagem da aplicacao principal sera utilizada automaticamente.

Para compartilhar segredos com todos os containers do Pod (incluindo Init Containers), utilize `secrets.envVarEnabled` e `secrets.loadAllKeys` no bloco do initContainer.

```yaml
volumes:
  - name: shared-data
    emptyDir: {}

volumeMounts:
  - name: shared-data
    mountPath: /tmp/data

initContainers:
  - name: "init-setup"
    enabled: true
    command: ["/bin/sh"]
    args: ["-c", "echo 'Initializing...' && touch /tmp/data/ready.txt"]
    secrets:
      envVarEnabled: true
      loadAllKeys: true
    resources:
      memory: "128Mi"
      cpu: "50m"
    volumeMounts:
      - name: shared-data
        mountPath: /tmp/data
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/init-containers.md`

### TerminationGracePeriodSeconds

Todos os charts suportam `terminationGracePeriodSeconds`, que define o tempo em segundos que o Kubernetes aguarda para que um pod seja desligado normalmente antes de encerra-lo forcadamente.

```yaml
terminationGracePeriodSeconds: 60
```

**Fonte**: `platform-k8s-charts/.docs/CHANGELOG.api.md` (v1.32.0), `CHANGELOG.worker.md` (v1.24.0), `CHANGELOG.cronjob.md` (v1.17.0), `CHANGELOG.job.md` (v1.18.0) (complemento — nao em docs/)

### PodMonitor (Metricas OpenMetrics)

Pipeline recomendado para coleta de metricas OpenMetrics/Prometheus via PodMonitor (agent-metrics). Permite escolher o datastore de destino e monitorar multiplos containers (sidecars). Substitui o pipeline legado via anotacoes do Datadog Agent. O campo correto para especificar a porta do target e `portNumber` (nao `containerName` ou `port`).

```yaml
telemetry:
  enabled: true
  instrumentation:
    openmetrics:
      targets:
        - portNumber: 9090
          path: "/metrics"
          job: "my-metrics"
          infraCardinalityLevel: medium
          datastores:
            datadog:
              enabled: true
            grafana:
              enabled: true
```

- `portNumber`: Porta numerica onde as metricas sao expostas.
- `path`: Caminho HTTP do endpoint de metricas.
- `job`: Nome do job de metricas para identificacao no datastore.
- `infraCardinalityLevel`: Nivel de cardinalidade de metricas de infraestrutura (ex: `medium`).
- `datastores`: Permite habilitar/desabilitar envio para cada datastore individualmente.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/observability.md`, `observabilidade/metrics.md`; `platform-k8s-charts/.docs/CHANGELOG.api.md` (v1.33.0), `CHANGELOG.worker.md` (v1.26.0) (complemento — nao em docs/)

### Telemetry OpenTelemetry (Metricas)

Os charts suportam configuracao de metricas OpenTelemetry via bloco `telemetry.instrumentation.opentelemetry.metrics`, permitindo definir o nivel de cardinalidade e os datastores de destino.

```yaml
telemetry:
  instrumentation:
    opentelemetry:
      metrics:
        infraCardinalityLevel: medium
        datastores:
          datadog:
            enabled: true
          grafana:
            enabled: false
```

- `infraCardinalityLevel`: Controla o nivel de cardinalidade de metricas de infraestrutura. Default: `medium`.
- `datastores`: Permite habilitar/desabilitar envio de metricas para cada datastore (Datadog, Grafana).

**Fonte**: `karavela/docs/guia-do-desenvolvedor/observabilidade/metrics.md`; `platform-k8s-charts/.docs/CHANGELOG.api.md` (v1.34.3) (complemento — nao em docs/)

### SIEM Datastore para Logs

Todos os charts (API, Worker, CronJob, Job, StatefulSet) suportam o envio de logs para o pipeline SIEM via novo datastore `siem`. O SIEM e configuravel em tres pontos do values.yaml: `datadog.logs.datastores.siem`, `datadog.otlp.logs.datastores.siem` e `telemetry.instrumentation.opentelemetry.logs.datastores.siem`.

```yaml
# Habilitando envio de logs para o SIEM via coleta stdout
datadog:
  logs:
    datastores:
      siem:
        enabled: true
        context: "spi"   # contexto de negocio (ex: spi = Sistema de Pagamentos Instantaneos)

# Ou via OpenTelemetry
telemetry:
  instrumentation:
    opentelemetry:
      logs:
        datastores:
          siem:
            enabled: true
            context: "spi"
```

- `siem.enabled`: Habilita o envio de logs para o pipeline SIEM via Telescope Logs. Default: `false`.
- `siem.context`: Identificador logico que determina para qual bucket S3 os logs serao roteados. Segmenta por dominio de negocio. Atualmente apenas `"spi"` esta disponivel.

> **IMPORTANTE**: Esta funcionalidade nao esta disponivel em todos os clusters. Em clusters legados, e necessario adicionar manualmente a annotation `telemetry.karavela.stone.tech/siem.logs.context: "spi"` no Pod.

**Fonte**: `karavela/docs/siem_integration.md`, `karavela/docs/guia-do-desenvolvedor/observabilidade/logs.md`; `platform-k8s-charts/.docs/CHANGELOG.api.md` (v1.36.0) (complemento — nao em docs/)

### ExternalSecret v1

A apiVersion do componente ExternalSecret foi atualizada de `v1beta` para `v1`. O campo `refreshInterval` agora utiliza formato `time.Duration` (ex: `1m0s` em vez de `60`). Essa mudanca e transparente para o usuario e nao requer alteracao no `values.yaml`.

**Fonte**: `platform-k8s-charts/.docs/CHANGELOG.api.md` (v1.34.0) (complemento — nao em docs/)

### Harbor Registry (imagePullSecrets)

Os Pods em clusters EKS agora autenticam diretamente no Registry centralizado (Harbor) ao fazer pull de imagens, via novo segredo no campo `imagePullSecrets` do ServiceAccount. O nome do secret e configuravel via `cloudProviders.aws.imagePullSecrets.name`.

**Fonte**: `platform-k8s-charts/.docs/CHANGELOG.api.md` (v1.32.2) (complemento — nao em docs/)

### Datadog Monitors

Monitores do Datadog podem ser configurados via `values.yaml` usando o bloco `alerts.datadog`. O provisionamento e feito via CRDs do tipo `DatadogMonitor`. Veja a skill `observabilidade` para detalhes completos.

> **Nota**: O campo `alerts.datadog.monitors` e do tipo `array` (lista). Versoes anteriores dos charts o documentavam incorretamente como `object` (`{}`). Use `monitors: []` como valor default.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/observabilidade/alertas.md`; `platform-k8s-charts/.docs/CHANGELOG.api.md` (v1.29.0) (complemento — nao em docs/)

### Alertas Mimir e Loki

Os charts suportam configuracao de alertas via Mimir (metricas Prometheus) e Loki (logs). Ambos permitem definir `alerting_rules` e `recording_rules` diretamente no `values.yaml`. O Mimir tambem suporta `commonLabels` para labels compartilhadas entre todas as regras.

```yaml
alerts:
  mimir:
    enabled: true
    commonLabels: {}
    alerting_rules: []
    recording_rules: []
  loki:
    enabled: true
    alerting_rules: []
    recording_rules: []
```

- `alerts.mimir.commonLabels`: Labels aplicadas a todas as regras Mimir.
- `alerts.mimir.alerting_rules`: Lista de regras de alerta baseadas em metricas Prometheus.
- `alerts.mimir.recording_rules`: Lista de recording rules para pre-computar metricas.
- `alerts.loki.alerting_rules`: Lista de regras de alerta baseadas em logs.
- `alerts.loki.recording_rules`: Lista de recording rules baseadas em logs.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/observabilidade/alertas.md`

### KEDA TriggerAuthentication — Correcao de Sync-Wave (ArgoCD)

Os charts de API (v1.38.7), Worker (v1.30.7) e StatefulSet (v1.12.7) adicionam automaticamente a anotacao `sync-wave` ao recurso `TriggerAuthentication` do KEDA. Isso resolve um deadlock no ArgoCD que ocorria quando o `TriggerAuthentication` era deletado antes do `ScaledObject` que o referencia.

**Para os desenvolvedores, nenhuma acao e necessaria**: a anotacao e aplicada automaticamente pelo chart. Mas e possivel sobrescrever se necessario:

```yaml
keda:
  enabled: true
  triggerAuthentication:
    syncWave: 1        # valor default; controla a ordem de delecao no ArgoCD
    annotations: {}    # anotacoes adicionais (sobrescreve o sync-wave se especificado)
```

**Impacto**: Deploys e rollbacks de servicos que usam KEDA nao precisarao mais de intervencao manual para resolver deadlocks de sincronizacao no ArgoCD.

**Fonte**: `platform-k8s-charts/.docs/changelogs/CHANGELOG.api.md` (v1.38.7), `CHANGELOG.worker.md` (v1.30.7), `CHANGELOG.statefulset.md` (v1.12.7) (complemento — nao em docs/)

### KEDA TriggerAuthentication — Finalizer (Drift no ArgoCD)

A partir dos charts API v1.38.10, Worker v1.30.10 e StatefulSet v1.12.11, o recurso `TriggerAuthentication` passa a incluir automaticamente um finalizer KEDA em `metadata.finalizers`. Isso elimina falsos positivos de drift no ArgoCD apos deploys, onde o mesmo `TriggerAuthentication` podia ficar com diferenca entre estado desejado (Git) e estado no cluster apos sincronizacao.

**Para os desenvolvedores, nenhuma acao e necessaria** — o finalizer e aplicado automaticamente pelos templates do chart. Testes adicionados validam a presenca do finalizer em cada release.

**Impacto**: pipelines de delivery deixam de reportar ruido em recursos KEDA criados pelo chart, reduzindo investigacao manual.

**Fonte**: `platform-k8s-charts/.docs/changelogs/CHANGELOG.api.md` (v1.38.10), `CHANGELOG.worker.md` (v1.30.10), `CHANGELOG.statefulset.md` (v1.12.11) (complemento — nao em docs/)

### DNS Record (Chart de API)

O chart de API suporta configuracao de registro DNS via bloco `dnsrecord`. Permite criar registros DNS automaticamente associados ao servico.

```yaml
dnsrecord:
  enabled: false
  domain: "chart-exemplo.local"
  type: "CNAME"
  target: "lb"
```

- `enabled`: Ativa ou desativa a criacao do registro DNS. Default: `false`.
- `domain`: Nome do dominio a ser registrado.
- `type`: Tipo do registro DNS (ex: `CNAME`, `A`).
- `target`: Alvo do registro DNS (ex: nome do load balancer).

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/ingress.md`

### Atributo infra-cardinality

O atributo `telemetry.karavela.stone.tech/metrics.infra-cardinality` e adicionado com valor default `medium` para controle de cardinalidade de metricas de infraestrutura.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/observabilidade/metrics.md`; `platform-k8s-charts/.docs/CHANGELOG.api.md` (v1.34.3) (complemento — nao em docs/)

## Modo Acoes

Esta skill atua em **Modo Acoes** por default — pode editar arquivos do seu repo, rodar KLI e abrir PR. Sempre confirma antes de escrever; producao exige dupla confirmacao. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Editar `Chart.yaml`** — bumpar dependencia, adicionar/trocar chart (api/worker/cronjob/job/statefulset)
- **Editar `chart/values-*.yaml`** — labels, annotations (`inject-pod-ip`), resources, ingress, sidecars, initContainers, PDB, canaryStrategy, terminationGracePeriodSeconds, telemetry, alerts, dnsrecord
- **Criar `chart/values-<env>.yaml`** novo ambiente seguindo padrao da app
- **Rodar KLI read** — `kli describe app <nome>` para confirmar config atual
- **Abrir PR draft** com a mudanca (`gh pr create --draft`) — titulo + body em pt-BR

### Triggers proativos
- Usuario pede "configure chart pra X", "adicione sidecar Y", "habilite PDB", "ajuste resources", "use POD_IP" → `🛠️ Acao proposta: edito chart/values-stg.yaml + abro PR draft`
- Usuario reporta chart desatualizado (ex: api v1.36) → ofereca bump para versao atual (v1.38.11)

### Acoes destrutivas (dupla confirmacao)
- Edit em `karavela_containers_guardrails.yaml` (arquivo auditado) — sempre alertar.

## Instrucoes MCP

Quando você ainda não estiver certeza da resposta use o GITHUB mcp. Priorize a documentacao oficial em `stone-payments/karavela` `docs/`; outros repositorios servem apenas como fallback para detalhes nao cobertos.

**Fontes primarias (docs/):**

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/charts.md` | Visao geral dos charts disponiveis (API, Worker, CronJob, Job, StatefulSet) |
| `stone-payments/karavela` | `docs/politica_charts.md` | Politica de versionamento, SemVer e ciclo de vida dos charts |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/versionamento-rollout-charts.md` | Versionamento de chart gerenciado pela Karavela API, rollout multi-ambiente, manifesto multi-source, rollback de chart |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/funcionalidades/` | Documentacao detalhada por funcionalidade (image, labels-annotations, resources, ingress, secrets, healthcheck, volumes, sidecars, init-containers, pdb, canary-deploy, observability, cronjob, job, initialjob, security-context, cloud-providers, envs-jsonenvs-configmap, etc.) |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/observabilidade/` | Metrics, alertas, logs (para campos `telemetry`, `alerts.mimir`, `alerts.loki`, `alerts.datadog`) |
| `stone-payments/karavela` | `docs/siem_integration.md` | SIEM datastore para logs |

**Fontes secundarias (complemento — nao em docs/):**

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/platform-k8s-charts` | `platform-k8s-api-chart/values.yaml` (e demais charts) | Valores default e schema completo do `values.yaml` |
| `stone-payments/platform-k8s-charts` | `.docs/changelogs/CHANGELOG.*.md` | Mudancas recentes nos charts por versao |

## Formato de Resposta

Ao responder perguntas deste dominio, siga este formato:

1. **Explicacao** (2-3 frases objetivas em PT-BR)
2. **Exemplo pratico** (YAML, comando ou config copiavel)
3. **Fonte** (referencia ao arquivo/secao da documentacao)
4. **Avisos** (se aplicavel: restricoes de ambiente, privilegios necessarios)

---
name: ci-mutation-testing-kotlin-kmp
description: "Testes de mutacao para projetos Kotlin Multiplatform (KMP) usando o workflow reutilizavel kotlin-kmp-mutanting. Use quando o usuario perguntar sobre como adicionar testes de mutacao em Kotlin, configurar o Pitest via Gradle plugin, integrar com o workflow reutilizavel, threshold de MSI, diff_mode, gradle_task ou envio de metricas de mutacao ao Kafka."
---

# Skill: Mutation Testing — Kotlin KMP / Pitest

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.
-->

> ### ⚠️ Pré-requisito: Acesso às Org Secrets de Kafka
>
> Para usar os secrets de Kafka, **adicione o nome do repositório do seu projeto** em todos os arquivos abaixo no repositório `stone-payments/terraform-github` (via Pull Request para revisão):
>
> Caminho base: `applications/org-secrets/stone-payments/secrets.installation.d/`
>
> | Arquivo YAML | Nome da org secret | Input do workflow |
> |---|---|---|
> | `QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD.yaml` | `QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD` | `KAFKA_BROKER_URL` |
> | `QA_MATURITY_KAFKA_SASL_USERNAME_PRD.yaml` | `QA_MATURITY_KAFKA_SASL_USERNAME_PRD` | `KAFKA_SASL_USERNAME` |
> | `QA_MATURITY_KAFKA_SASL_PASSWORD_PRD.yaml` | `QA_MATURITY_KAFKA_SASL_PASSWORD_PRD` | `KAFKA_SASL_PASSWORD` |
> | `QA_MATURITY_KAFKA_SCHEMA_ENDPOINT_PRD.yaml` | `QA_MATURITY_KAFKA_SCHEMA_ENDPOINT` ⚠️ (sem `_PRD`) | `KAFKA_SCHEMA_ENDPOINT` |
> | `QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD.yaml` | `QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD` | `KAFKA_SCHEMA_USERNAME` |
> | `QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD.yaml` | `QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD` | `KAFKA_SCHEMA_PASSWORD` |
>
> Ao chamar o workflow, mapeie as org secrets para os inputs corretamente:
>
> ```yaml
> secrets:
>   KAFKA_BROKER_URL: ${{ secrets.QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD }}
>   KAFKA_SASL_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SASL_USERNAME_PRD }}
>   KAFKA_SASL_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SASL_PASSWORD_PRD }}
>   KAFKA_SCHEMA_ENDPOINT: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_ENDPOINT }}
>   KAFKA_SCHEMA_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD }}
>   KAFKA_SCHEMA_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD }}
> ```

## Escopo

**Cobre**:
- Como incorporar o workflow `kotlin-kmp-mutanting` em um projeto Kotlin Multiplatform
- Pre-requisito: configuracao do Pitest plugin no `build.gradle.kts`
- Todos os inputs do workflow (`diff_mode`, `java_version`, `gradle_task`, `working_directory`, `threshold`)
- Secrets opcionais para envio de metricas ao Kafka (`KAFKA_*`)
- O que e MSI e como funciona o threshold
- Diferenca entre `diff_mode: changed` e `diff_mode: total`
- Como customizar a task Gradle do Pitest (ex: `pitestJvm`, `:modulo:pitest`)
- Uso em monorepos com `working_directory`
- Formato do comentario automatico na PR
- Envio de metricas ao Kafka via `quality-maturity-report-layer`

**NAO cobre**:
- Configuracao avancada de mutators no Pitest (filtros de classes, pacotes, etc.)
- Escrita de testes unitarios KMP
- Infraestrutura de Kafka

## Exemplos de Perguntas

- "Como adiciono testes de mutacao no meu projeto Kotlin?"
- "Quais pre-requisitos meu projeto Kotlin KMP precisa ter?"
- "Como configuro o Pitest plugin no build.gradle.kts?"
- "Qual task Gradle devo usar para KMP — pitest ou pitestJvm?"
- "Como testo apenas um modulo especifico em um monorepo Kotlin?"
- "Como defino um threshold de MSI minimo para Kotlin?"
- "O que e diff_mode: changed vs total em Kotlin?"
- "Como envio metricas de mutacao Kotlin para o Kafka?"

## Conhecimento Embutido

### Localizacao do Workflow

```
stone-payments/github-actions-workflows
  .github/workflows/kotlin-kmp-mutanting.yml
```

Referencia para consumo: `@kotlin-kmp-mutanting-v0`

---

### Pre-requisito: Pitest Plugin no Projeto Gradle

O projeto Kotlin KMP precisa ter o Pitest plugin configurado no `build.gradle.kts`:

```kotlin
// build.gradle.kts
plugins {
    id("info.solidsoft.pitest") version "1.15.0"
}

pitest {
    junit5PluginVersion.set("1.2.1")
    outputFormats.set(listOf("XML", "HTML"))
    mutationThreshold.set(0) // controle via workflow input threshold
    // Opcional: filtrar classes de producao
    // targetClasses.set(listOf("com.example.mypackage.*"))
}
```

Para projetos **KMP com target JVM** (Kotlin Multiplatform), use a task `pitestJvm`:

```kotlin
pitest {
    junit5PluginVersion.set("1.2.1")
    outputFormats.set(listOf("XML", "HTML"))
    mutationThreshold.set(0)
    // pitestJvm e gerado automaticamente pelo plugin para targets JVM em KMP
}
```

> O report XML do Pitest e gerado em `build/reports/pitest/mutations.xml`. O workflow o localiza automaticamente via `find . -name "mutations.xml" -path "*/pitest/*"`.

---

### Como Integrar o Workflow

#### Uso Minimo

```yaml
# .github/workflows/ci.yml
jobs:
  mutation:
    uses: stone-payments/github-actions-workflows/.github/workflows/kotlin-kmp-mutanting.yml@kotlin-kmp-mutanting-v0
```

#### Com Task Customizada para KMP e Threshold

```yaml
jobs:
  mutation:
    uses: stone-payments/github-actions-workflows/.github/workflows/kotlin-kmp-mutanting.yml@kotlin-kmp-mutanting-v0
    with:
      gradle_task: pitestJvm
      java_version: '21'
      threshold: 60
```

#### Em Monorepo com Modulo Especifico

```yaml
jobs:
  mutation:
    uses: stone-payments/github-actions-workflows/.github/workflows/kotlin-kmp-mutanting.yml@kotlin-kmp-mutanting-v0
    with:
      gradle_task: ':my-module:pitest'
      working_directory: services/my-service
```

#### Com Envio ao Kafka

```yaml
jobs:
  mutation:
    uses: stone-payments/github-actions-workflows/.github/workflows/kotlin-kmp-mutanting.yml@kotlin-kmp-mutanting-v0
    with:
      threshold: 70
    secrets:
      KAFKA_BROKER_URL: ${{ secrets.QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD }}
      KAFKA_SASL_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SASL_USERNAME_PRD }}
      KAFKA_SASL_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SASL_PASSWORD_PRD }}
      KAFKA_SCHEMA_ENDPOINT: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_ENDPOINT }}
      KAFKA_SCHEMA_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD }}
      KAFKA_SCHEMA_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD }}
```

---

### Inputs Disponiveis

| Input | Tipo | Obrigatorio | Descricao | Padrao |
|-------|------|-------------|-----------|--------|
| `runs_on` | string (JSON) | nao | Runner a usar | `"['small-runner']"` |
| `diff_mode` | string | nao | `"changed"` (so se ha `.kt` alterados) ou `"total"` (projeto todo) | `"changed"` |
| `working_directory` | string | nao | Diretorio raiz do projeto Gradle | `"."` |
| `java_version` | string | nao | Versao do Java (ex: `"17"`, `"21"`) | `"17"` |
| `gradle_task` | string | nao | Task Gradle do Pitest (ex: `"pitest"`, `"pitestJvm"`, `":module:pitest"`) | `"pitest"` |
| `threshold` | number | nao | MSI minimo em % (0 = desabilitado). Workflow falha se abaixo | `0` |

### Secrets Opcionais (Kafka)

| Secret | Descricao |
|--------|-----------|
| `KAFKA_BROKER_URL` | URL do broker Kafka |
| `KAFKA_SASL_USERNAME` | Username SASL do Kafka |
| `KAFKA_SASL_PASSWORD` | Password SASL do Kafka |
| `KAFKA_SCHEMA_ENDPOINT` | URL do Schema Registry |
| `KAFKA_SCHEMA_USERNAME` | Username do Schema Registry |
| `KAFKA_SCHEMA_PASSWORD` | Password do Schema Registry |

---

### O que o Workflow Faz (Passo a Passo)

1. **Checkout** com `fetch-depth: 0`
2. **Setup do Java** (Temurin) na versao `java_version`
3. **Setup do Gradle** com cache via `gradle/actions/setup-gradle@v3`
4. **Deteccao de arquivos `.kt` alterados** (quando `diff_mode: changed`)
   - Se nenhum arquivo `.kt` foi alterado: pula a execucao
5. **Execucao do Pitest** via `./gradlew <gradle_task> --continue`
   - `--continue` garante que resultados parciais ainda sejam gerados mesmo se houver falhas nos testes
6. **Parse do XML** (`mutations.xml`) para o formato JSON normalizado
7. **Verificacao do threshold** de MSI (se `threshold > 0`)
8. **Comentario na PR** com tabela de resultados
9. **Upload do artefato** `kotlin-kmp-mutation-report`
10. **Envio das metricas** (apenas se os secrets Kafka forem passados — o destino e gerenciado pelo workflow)

---

### Qual Task Usar: `pitest` vs `pitestJvm`?

| Cenario | Task Recomendada |
|---------|-----------------|
| Projeto Kotlin JVM puro | `pitest` |
| Projeto Kotlin Multiplatform (KMP) com target JVM | `pitestJvm` |
| Modulo especifico em monorepo | `":nome-do-modulo:pitest"` |
| Modulo KMP especifico | `":nome-do-modulo:pitestJvm"` |

---

### MSI — Mutation Score Indicator

- `MSI = (Killed + Timeout) / Total * 100`
- **🟢 >= 80%**: Excelente
- **🟡 60-79%**: Aceitavel
- **🔴 < 60%**: Insuficiente

---

### Comentario Automatico na PR

```
## 🧬 Mutation Testing Report — Kotlin KMP / Pitest

🟢 Mutation Score (MSI): 78.50%

| Metric                      | Value |
|-----------------------------|-------|
| Total Mutants               | 200   |
| ✅ Killed                   | 157   |
| ❌ Survived (Escaped)       | 40    |
| ⏱️ Timeout / Memory Error   | 3     |
| 🚫 No Coverage              | 0     |
| 💥 Error                    | 0     |
```

---

## Instrucoes MCP

Quando precisar de detalhes alem do conhecimento embutido, busque nos seguintes repositorios (nesta ordem de prioridade):

| Repositorio | Caminho | Quando buscar |
|-------------|---------|---------------|
| `stone-payments/karavela` | `docs/` | Padroes da plataforma (nao cobre mutation testing diretamente) |
| `stone-payments/github-actions-workflows` | `.github/workflows/kotlin-kmp-mutanting.yml` | Implementacao do workflow reutilizavel, inputs e steps |
| Externo (complemento — nao em docs/) | [Pitest docs](https://pitest.org/) e [info.solidsoft.pitest plugin](https://gradle-pitest-plugin.solidsoft.info/) | Configuracao avancada do Pitest, mutators, plugin Gradle |

> Todo o conhecimento desta skill e **complemento** ao docs/ da plataforma — ela nao tem secao dedicada a mutation testing.

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Configurar Pitest** — adicionar plugin Pitest no `build.gradle.kts`
- **Criar `.github/workflows/mutation.yml`** apontando para `kotlin-kmp-mutanting.yml@main`
- **Inputs**: `diff_mode`, `java_version`, `gradle_task` (ex: `pitestJvm`), `working_directory`, `threshold`
- **Adicionar secrets Kafka** opcionais
- **Abrir PR draft**

### Triggers proativos
- "Adicionar mutation testing Kotlin KMP" → `🛠️ Acao proposta: adiciono plugin Pitest + workflow + abro PR`

### Acoes destrutivas
- N/A.

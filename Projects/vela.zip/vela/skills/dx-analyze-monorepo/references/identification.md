# Identificação de Monorepo

## §1 — Workspace configuration files

Use `Glob` para buscar os seguintes arquivos na raiz do repositório:

| Arquivo | Ecossistema |
|---|---|
| `package.json` (campo `workspaces`) | Node.js / npm / Bun |
| `pnpm-workspace.yaml` | pnpm |
| `lerna.json` | Lerna |
| `nx.json` | Nx |
| `turbo.json` | Turborepo |
| `rush.json` | Rush |
| `.moon/workspace.yml` | Moon |
| `go.work` | Go |
| `settings.gradle` / `settings.gradle.kts` | Gradle |
| `pom.xml` multi-module | Maven |
| `Cargo.toml` com `[workspace]` | Rust |
| `WORKSPACE` / `WORKSPACE.bazel` / `MODULE.bazel` | Bazel |
| `pyproject.toml` com `[tool.uv.workspace]` | Python (uv) |
| `.changeset/config.json` | Changesets (forte indicador de versionamento independente) |

> Tooling formal é evidência forte, mas **não é requisito**. Um repo sem tooling pode ser monorepo se contiver 2+ serviços independentemente deployáveis.

## §2 — Estrutura de diretórios

Analise o repositório buscando padrões repetitivos:

1. Procure por `packages/`, `services/`, `apps/`, `modules/` com `Glob`
2. Verifique se cada subdiretório tem seus próprios arquivos de build/config (`package.json`, `Dockerfile`, `go.mod`, etc.)
3. Confirme que são unidades independentemente deployáveis — não apenas utilitários compartilhados
4. Identifique **somente leaf services** (ver `leaf-service-rule.md`)
5. Classifique separadamente diretórios com nomes como `shared/`, `common/`, `libs/` — aplique a `shared-code-rule.md` antes de decidir

> **Convenção por nome de diretório pai**: diretórios como `apps/`, `services/` e `modules/` indicam por convenção que seus filhos são serviços — explore cada subdiretório individualmente mesmo que não tenha `Dockerfile`, pois em workspaces Node.js/TypeScript o container pode ser construído pelo CI/CD sem Dockerfile próprio. Já `libs/`, `packages/common/`, `shared/` e similares indicam código reutilizável — aplique sempre a `shared-code-rule.md` antes de decidir. O nome do diretório pai é um forte sinal inicial, mas **não substitui a verificação de artefatos e workflows**.

## §3 — Workflows CI/CD

Use `Grep` sobre `.github/workflows/**`:

```
# Buscar path-based triggers
grep -r "paths:" .github/workflows/

# Buscar matrizes de build multi-serviço
grep -r "matrix:" .github/workflows/

# Buscar jobs de deploy por serviço
grep -r "deploy" .github/workflows/
```

Evidências que confirmam monorepo:
- Múltiplos jobs com `paths:` filters apontando para diretórios distintos
- Matrizes de build com serviços nomeados
- Jobs de deploy independentes por serviço

## §4 — Framework de decisão

| Nível | Critérios |
|---|---|
| **HIGH** | Workspace config encontrado + 2+ leaf services com artefatos de build + path triggers no CI confirmando deploys separados |
| **MEDIUM** | 2+ leaf services com artefatos mas sem CI path triggers, OU workspace config sem artefatos confirmados |
| **LOW** | Estrutura ambígua, sem workspace config, ou incerteza sobre deployabilidade → **perguntar ao usuário antes de gerar config** |

> Com confiança **LOW**, use `AskUserQuestion` para esclarecer fronteiras de serviço e estratégia de deploy antes de prosseguir.

# Shared-Code Rule (obrigatória)

Diretórios com nomes que sugerem código reutilizável (`shared/`, `common/`, `libs/`, `lib/`, `core/`, `utils/`, `packages/common/` ou similares) exigem classificação em dois passos antes de qualquer decisão de label.

## Passo 1 — Workflow check (sinal primário)

A carga de prova varia conforme a zona do diretório:

### Zona shared (`libs/`, `shared/`, `common/`, `core/`, `utils/` e similares)

**Presunção: é código shared.** Essa presunção se aplica ao diretório nomeado **e a todos os seus subdiretórios** — qualquer subdiretório como `libs/ui/`, `shared/auth/` etc. é shared por herança, independentemente de ter `package.json`, `tsconfig.json` ou qualquer outro arquivo de build próprio.

Só reclassifique como leaf service se houver evidência **simultânea** de todos os itens abaixo:
1. artefato de build próprio no diretório (`Dockerfile`, `go.mod` com `main`, `.csproj` executável, etc.)
2. job de deploy explícito no CI/CD que implanta esse artefato em infraestrutura de execução (container registry + orquestrador, VM, serverless runtime)

Se qualquer um dos dois estiver ausente → trate como shared, siga o Passo 2. **Não eleve para leaf service com base apenas em referência de workflow.**

> **Armadilha comum:** pacotes de componente (Storybook, design systems, UI kits), bibliotecas utilitárias e SDKs internos frequentemente têm `package.json` próprio e até workflow de "deploy" — mas esse deploy publica para um registry de pacotes (npm, Chromatic, GitHub Pages) ou gera documentação, não para infraestrutura de execução. Isso **não conta** como evidência de leaf service. Mantenha como shared.

### Zona de serviços (`apps/`, `services/`, `modules/` e similares)

Use `Grep` para buscar o nome do subdiretório em triggers `paths:` ou jobs de deploy em `.github/workflows/**`.

| Resultado | Decisão |
|---|---|
| Referenciado em workflow de deploy | → Leaf service. Aplique a leaf-service rule. Crie label `dx-<nome>`. |
| Não referenciado em nenhum workflow de deploy | → Trate como shared. Siga o Passo 2. |

> **Não conta como deploy de produção em nenhuma zona**: publicação para registries de pacotes (npm, Maven, PyPI), geração de documentação ou sites estáticos, pipelines de visual testing, preview environments efêmeros. Esses têm como destino um repositório de artefato ou plataforma de conteúdo — não infraestrutura de execução que serve usuários ou outros sistemas.

## Passo 2 — Consumer detection (apenas para não-deployed)

Use `Grep` para descobrir quais leaf services importam o diretório shared. Padrões por linguagem:

| Linguagem | Padrão de busca |
|---|---|
| TypeScript/JS | `from ['"].*<shared-dir>` ou `require\(['"].*<shared-dir>` |
| Go | `"<module>/<shared-dir>` |
| C# | `using <Namespace.SharedDir>` ou `ProjectReference.*<shared-dir>` |
| Python | `^from <shared_dir>` ou `^import <shared_dir>` |
| Rust | `<shared-dir> = \{` em Cargo.toml |

Para cada leaf service que importa o diretório shared, adicione o glob do shared como entrada adicional `any-glob-to-any-file` na label desse serviço. **Nunca crie uma label standalone para o diretório shared.**

> Se a linguagem não estiver na tabela, o padrão não puder ser determinado, ou os resultados forem inconclusivos → adicione o glob shared em **todos** os leaf services como safe default.

## Exemplo completo

```
# Estrutura:
#   shared/          ← nenhum workflow faz deploy → lib shared
#   services/api/    ← deployed por workflow → leaf service
#   services/worker/ ← deployed por workflow → leaf service
#
# shared/ é importado por api e worker (confirmado via Grep)

# Correto:
dx-api:
  - changed-files:
    - any-glob-to-any-file:
        - 'services/api/**'
        - 'shared/**'       # lib shared consumida por api

dx-worker:
  - changed-files:
    - any-glob-to-any-file:
        - 'services/worker/**'
        - 'shared/**'       # lib shared consumida por worker

# Errado — NÃO faça:
dx-shared:                  # ← proibido: nenhum workflow deploya shared/
  - changed-files:
    - any-glob-to-any-file: 'shared/**'
```

## Por que importa

Um PR que toca `shared/` dispara a label de todo serviço que lista esse glob, dando visibilidade completa sem label dedicada para o código compartilhado. Isso garante que as métricas DORA contabilizem o impacto corretamente.

# Schema dx-labeler.yaml (actions/labeler@v6)

## Path do arquivo

Sempre usar **`.github/dx-labeler.yaml`** — este é o path exato lido pelo workflow.

Antes de criar, use `Read` para verificar se o arquivo já existe:
- **Existe** → proponha diff/atualização cirúrgica, não substituição completa
- **Não existe** → crie do zero

## Convenção de nomes de labels

Formato obrigatório: **`dx-<service-or-scope>`**

O prefixo `dx-` é mandatório. O sufixo deve ser derivado do nome do diretório do serviço detectado na estrutura do repositório.

| Válido | Inválido |
|---|---|
| `dx-api` | `api` (sem prefixo) |
| `dx-payments-worker` | `dx-release` (intenção de branch) |
| `dx-gateway` | `dx-fix` (tipo de mudança) |
| `dx-frontend` | `dx-shared` (código shared sem deploy) |

## Matchers disponíveis

| Matcher | Comportamento |
|---|---|
| `any-glob-to-any-file` | QUALQUER glob coincide com QUALQUER arquivo alterado (mais comum) |
| `any-glob-to-all-files` | QUALQUER glob coincide com TODOS os arquivos alterados |
| `all-globs-to-any-file` | TODOS os globs coincidem com QUALQUER arquivo alterado |
| `all-globs-to-all-files` | TODOS os globs coincidem com TODOS os arquivos alterados |

> `head-branch` e `base-branch` existem no labeler, mas **não devem ser usados** nesta configuração — criariam labels baseadas em convenção de branch (release/, hotfix/, feat/), fora do escopo do dx-labeler.

## Notas sobre globs

- Prefixo `!` nega o padrão (ex: `'!src/docs/*'` exclui matches nesse path)
- Globs são avaliados com `dot: true` (dotfiles como `.github` são incluídos por padrão)
- A action cria labels automaticamente no repositório se não existirem
- Labels são **aditivas** — o workflow não usa `sync-labels: true`, então labels antigas não são removidas automaticamente quando os arquivos trigger são revertidos

## Exemplo de configuração completa

```yaml
# Leaf service labels — uma por serviço de aplicação independentemente deployável.
# Paths shared/common/libs NÃO recebem label própria;
# em vez disso, são embutidos nos matchers de cada serviço consumidor.
# Diretórios de infra, CI/CD e docs NÃO recebem labels.

dx-api:
  - changed-files:
    - any-glob-to-any-file:
        - 'services/api/**'
        - 'libs/**'           # lib shared consumida por api
        - 'shared/**'         # código shared consumido por api

dx-worker:
  - changed-files:
    - any-glob-to-any-file:
        - 'services/worker/**'
        - 'libs/**'
        - 'shared/**'

dx-frontend:
  - changed-files:
    - any-glob-to-any-file:
        - 'apps/frontend/**'
        - 'libs/**'
        - 'shared/**'
```

## Escrita do arquivo

Use **somente o tool `Write`** para gravar `.github/dx-labeler.yaml`. Após escrever o arquivo, **pare completamente** — não execute nenhum comando git. Processos downstream cuidam do versionamento.

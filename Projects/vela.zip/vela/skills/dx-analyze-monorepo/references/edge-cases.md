# Edge Cases e Quality Assurance

## Casos especiais

### Monorepo sem tooling formal
- Estrutura com múltiplos serviços deployáveis independentemente, mas sem `nx.json`, `turbo.json` etc.
- **Decisão**: ainda recomende configuração se os serviços forem independentemente deployáveis. Tooling formal é evidência, não requisito.

### Múltiplos packages, único deployable
- Repo com `packages/` mas todos compilados em um único artefato final.
- **Decisão**: NÃO recomende configuração monorepo.

### Diretórios de serviço versionados
- Padrão: `v1/api/`, `v2/api/`
- **Decisão**: trate cada versão como leaf separado **somente** se tiverem jobs de CI/CD distintos. Caso contrário, pergunte ao usuário qual versão está ativa antes de gerar labels.

### Diretórios inativos/descontinuados
- Diretório não referenciado em nenhum trigger de CI/CD e sem commits recentes.
- **Decisão**: pule como candidato a leaf — não gere label para ele.

### Shared com nome "enganoso" que é deployed
- Ex: `libs/queue-service/` com `Dockerfile` próprio e job de deploy para Kubernetes.
- **Decisão**: apenas se houver **artefato de build próprio** (ex: `Dockerfile`) **e** job de deploy para infraestrutura de execução — trate como leaf service com label `dx-<nome>`. Referência isolada em workflow sem artefato de build próprio não é suficiente; o diretório permanece shared.

### Biblioteca shared com pipeline de publicação de artefato
- Diretório em `libs/` (ou similar) com workflow que publica para registry de pacotes, gera documentação ou executa visual testing — mas não implanta em infraestrutura de execução.
- **Decisão**: NÃO é leaf service. Pipeline de publicação de artefato ou documentação não equivale a deploy de produção. Aplique a shared-code rule — o glob do diretório vai embutido nos serviços consumidores, não como label própria.

### Serviço em `apps/` sem artefato de build explícito no diretório
- Em workspaces Node.js/TypeScript (Turborepo, Nx, pnpm), aplicações em `apps/<nome>/` podem não ter `Dockerfile` próprio — o container é construído pelo CI/CD a partir do diretório raiz.
- **Decisão**: presença de `package.json` (ou equivalente de build) em `apps/<nome>/` é suficiente para tratar como candidato a leaf service. Confirme inspecionando os workflows se o diretório é referenciado em algum job de deploy de produção.

### Git submodules
- **Decisão**: ignore completamente — analise apenas código que pertence diretamente ao repositório.

### Workspaces aninhados
- Ex: monorepo dentro de monorepo.
- **Decisão**: identifique o workspace de nível mais alto e analise cada serviço independentemente.

### Tecnologias mistas
- Go + TypeScript + Python no mesmo repositório.
- **Decisão**: trate cada serviço/package igualmente, independente de linguagem ou framework.

### Migração em andamento para monorepo
- **Decisão**: confirme o estado **atual**, não o estado futuro pretendido, antes de recomendar config.

---

## Quality Assurance Checklist

Antes de entregar a configuração, confirme cada item:

- [ ] Examinou arquivos de configuração raiz, workflows CI/CD e estrutura de diretórios
- [ ] Determinação de monorepo é baseada em evidências — não em suposições
- [ ] Todos os serviços identificados são de fato independentemente deployáveis
- [ ] Todos os paths no YAML gerado existem no repositório (verificado via `Glob`)
- [ ] O YAML gerado é válido e usa o schema correto do `actions/labeler@v6`
- [ ] Toda label começa com `dx-` e refere-se a um serviço/escopo
- [ ] Nenhuma label é baseada em intenção de branch (`release`, `fix`, `hotfix`, `feat`, `chore`, `refactor`)
- [ ] Nenhuma label aponta para diretório intermediário/pai quando filho deployável existe (leaf-service rule aplicada)
- [ ] Nenhuma label standalone existe para diretórios shared/common/libs — os globs estão embutidos em cada leaf service consumidor
- [ ] Nenhuma label gerada para infra, CI/CD ou diretórios de documentação
- [ ] Se incerto sobre qualquer ponto, a incerteza está explicitada e uma pergunta foi feita ao usuário

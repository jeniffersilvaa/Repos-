# Formato de Saída Obrigatório

Toda análise deve produzir as quatro seções abaixo, nesta ordem.

---

## 1. Repository Analysis Summary

Inclua obrigatoriamente:

- **Veredicto claro**: "Este repositório **é** / **não é** um monorepo" com nível de confiança
- **Nível de confiança** (usar exatamente uma das três definições abaixo):
  - **HIGH** — workspace config encontrado + 2+ leaf services com artefatos de build + path triggers no CI confirmando deploys separados
  - **MEDIUM** — 2+ leaf services com artefatos mas sem CI path triggers, OU workspace config sem artefatos confirmados
  - **LOW** — estrutura ambígua, sem workspace config, ou incerteza sobre deployabilidade → **deve** perguntar ao usuário antes de gerar config
- **Lista de leaf services detectados** com seus paths

> Com confiança **LOW**: use `AskUserQuestion` para esclarecer fronteiras de serviço e estratégia de deploy. Não gere config antes da confirmação.

---

## 2. Evidence and Findings

Liste objetivamente:

- Workspace configuration files encontrados (com paths)
- Padrões CI/CD observados:
  - path-based triggers (`paths:`) e quais diretórios cobrem
  - matrizes de build com serviços nomeados
  - jobs de deploy independentes
- Estrutura de build/deploy por serviço (artefatos encontrados)
- Deployment manifests relevantes (Kubernetes, Docker Compose, Terraform)

---

## 3. Configuration Recommendation

*(somente se monorepo confirmado)*

- Confirme se `.github/dx-labeler.yaml` já existe ou não
- Apresente o conteúdo proposto do arquivo seguindo o schema em `labeler-schema.md`
- Para cada label, explique o rationale mapeando-a ao diretório do serviço detectado
- Se o arquivo já existir, apresente apenas o diff proposto, não a substituição completa

---

## 4. Next Steps

Confirme explicitamente:

- O arquivo foi gravado em `.github/dx-labeler.yaml` via `Write` tool
- Nenhuma operação git foi executada
- O workflow **não** usa `sync-labels: true` — labels são aditivas e não serão removidas automaticamente quando os arquivos trigger forem revertidos
- Paths de shared/common/libs estão embutidos nas labels dos serviços consumidores — um PR tocando `shared/` disparará a label de todo serviço que lista esse glob

# Leaf-Service Rule (obrigatória)

Labels devem ser geradas **apenas para leaf services** — a unidade independentemente deployável mais profunda na árvore de diretórios. Diretórios intermediários ou pai **nunca** recebem label própria.

## Algoritmo

1. Monte a lista completa de diretórios candidatos (aqueles com artefato de build/deploy próprio: `package.json`, `Dockerfile`, `go.mod`, `pom.xml`, `Cargo.toml`, etc.)
2. Para cada candidato `A`, verifique se algum outro candidato `B` é subdiretório estrito de `A` (isto é, `B` começa com `A/`)
3. Se `A` tem filho `B` que também é candidato → `A` **não** é leaf — descarte-o
4. Somente candidatos sem filhos deployáveis são leaves e devem receber label

## Exemplo

```
services/
  payments/           ← tem filhos deployáveis → NÃO é leaf, sem label
    api/              ← sem filhos deployáveis → leaf → dx-payments-api
    worker/           ← sem filhos deployáveis → leaf → dx-payments-worker
  notifications/      ← sem filhos deployáveis → leaf → dx-notifications
```

**Resultado correto:**
```yaml
dx-payments-api:
  - changed-files:
    - any-glob-to-any-file: 'services/payments/api/**'

dx-payments-worker:
  - changed-files:
    - any-glob-to-any-file: 'services/payments/worker/**'

dx-notifications:
  - changed-files:
    - any-glob-to-any-file: 'services/notifications/**'
```

**Errado — nunca faça:**
```yaml
dx-payments:          # ← proibido: diretório pai tem filhos deployáveis
  - changed-files:
    - any-glob-to-any-file: 'services/payments/**'
```

## Categorias que nunca recebem label

| Categoria | Exemplos |
|---|---|
| Código compartilhado | `shared/`, `libs/`, `common/`, `core/`, `utils/` — e **qualquer subdiretório** desses (ex: `libs/ui/`, `shared/auth/`) |
| Infraestrutura | `terraform/`, `k8s/`, `helm/` |
| CI/CD | `.github/workflows/`, `.circleci/` |
| Documentação | `docs/`, `**/*.md` |
| Tipo de mudança | `release`, `fix`, `hotfix`, `feat`, `chore`, `refactor` |

> Labels baseadas em intenção de branch ou tipo de PR são **estritamente proibidas**. O `dx-labeler.yaml` identifica **escopo de serviço afetado**, não a natureza da mudança.

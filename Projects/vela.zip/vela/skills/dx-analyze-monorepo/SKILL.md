---
name: dx-analyze-monorepo
description: >
  Skill para analisar estrutura de repositórios e detectar padrões de monorepo,
  gerando o arquivo `.github/dx-labeler.yaml` compatível com `actions/labeler@v6`.
  Use quando o usuário perguntar se um repo é monorepo, quiser configurar labels
  por serviço, ou precisar criar/atualizar o dx-labeler.yaml. Exemplos de trigger:
  "is this a monorepo?", "create dx-labeler.yaml", "configure service labels",
  "check if repo has multiple services", "set up monorepo labeling".
metadata:
  agent: platform-test-org/.github-private/.github/agents/check-monorepo.agent.md
  version: '2.0.0'
---

# dx-analyze-monorepo

> **Natureza desta skill**: skill de **tooling instrucional** para o agente detectar monorepo e gerar `.github/dx-labeler.yaml` (`actions/labeler@v6`). Nao e uma skill de plataforma — funciona em qualquer repo monorepo, independente de Karavela. Nao tem doc dedicado em `karavela/docs/`.

Skill para identificar arquiteturas monorepo e gerar configuração `dx-labeler.yaml`
com labels `dx-`-prefixadas por serviço independentemente deployável.

---

## ⚠️ Regras absolutas — leia antes de qualquer outra coisa

> **Para workspaces Nx (`nx.json` presente): o §1 tem precedência total.** As regras abaixo se aplicam a repositórios sem tooling Nx, ou como fallback quando `project.json` não estiver disponível.

### O que NUNCA recebe label própria

| Categoria | Exemplos |
|---|---|
| Código shared e **qualquer subdiretório** (salvo exceção Nx abaixo) | `libs/`, `shared/`, `common/`, `core/`, `utils/` — e subdiretórios como `libs/ui/`, `shared/auth/`, etc. |
| Infra | `terraform/`, `k8s/`, `helm/`, `chart/` |
| CI/CD | `.github/workflows/`, `.circleci/` |
| Documentação | `docs/`, `**/*.md` |
| Tipo de mudança ou branch | `release`, `fix`, `hotfix`, `feat`, `chore`, `refactor` |
| Diretório pai quando filho deployável existe | `services/payments/` quando `services/payments/api/` é leaf |

> **Exceção Nx:** em workspaces Nx, um projeto em `libs/` com tag `"type:application"` no `project.json` é um serviço misplaced — crie label normalmente. O `project.json` tem precedência sobre a localização da pasta.

### O que conta como leaf service

1. Tem artefato de build próprio (`Dockerfile`, `go.mod` com `main`, `.csproj Exe`, `pom.xml`, `package.json` em `apps/` etc.)
2. É deployável — deploy pode ocorrer via workflow CI/CD explícito, ArgoCD, orquestração externa ou qualquer outro mecanismo. **Ausência de trigger no workflow não descarta o serviço.**
3. NÃO está sob diretório de código reutilizável (`libs/`, `shared/`, etc.) — salvo exceção Nx acima

### O que NÃO conta como deploy de produção

- Publicação para registry de pacotes (npm, PyPI, Maven, Chromatic)
- Geração de documentação ou sites estáticos (GitHub Pages, MkDocs)
- Pipelines de visual testing
- Preview environments efêmeros

---

## Fluxo de execução

```
1. Identificar workspace configs          → §1 abaixo
2. Analisar estrutura de diretórios        → §2 abaixo
3. Inspecionar workflows CI/CD            → §3 abaixo
4. Aplicar leaf-service rule              → §4 abaixo
5. Aplicar shared-code rule               → §5 abaixo
6. Gerar dx-labeler.yaml                  → §6 abaixo
7. Escrever arquivo com Write tool        → PARAR — nenhum git command
8. Produzir output estruturado            → §8 abaixo
```

**Ferramentas obrigatórias:**
- **`Glob`** — localizar workspace configs e padrões de diretório
- **`Read`** — inspecionar `package.json`, workflows, verificar se `.github/dx-labeler.yaml` já existe
- **`Grep`** — buscar path-based triggers em `.github/workflows/**` e imports de shared code

> Nunca raciocine por suposição — sempre use as ferramentas para explorar ativamente o repositório.

---

## §1 — Workspace configuration files

Use `Glob` para buscar na raiz:

> **Nx monorepo (`nx.json` presente) — protocolo obrigatório antes de qualquer outra análise:**
>
> **Passo A — enumeração exaustiva (obrigatório, executar antes de ler qualquer workflow):**
> 1. Execute `Glob` com o padrão `apps/*/project.json` — lista todos os projetos diretos em `apps/`
> 2. Execute `Glob` com o padrão `libs/*/project.json` — lista todos os projetos diretos em `libs/`
> 3. Para **cada** arquivo retornado, use `Read` e extraia `"name"`, `"projectType"` e `"tags"`
> 4. Classifique cada projeto:
>    - Tags contêm `"type:application"` → **leaf service**, independente de pasta ou `projectType`
>    - Tags contêm `"type:library"` → **shared**, independente de pasta ou `projectType`
>    - Sem tag `type:*`: use `projectType` (`"application"` → leaf service, `"library"` → shared)
>    - `nx:noop` como executor de build **não descarta** o serviço
>
> **Passo B — enriquecimento via workflows (após ter a lista completa do Passo A):**
> Use `Grep` nos workflows apenas para encontrar paths adicionais a incluir no matcher de cada serviço já identificado (ex: `chart/api/<nome>/`). Workflows **não são** a fonte de descoberta de serviços — um app ausente de qualquer workflow ainda é um leaf service válido.

| Arquivo | Ecossistema |
|---|---|
| `package.json` (campo `workspaces`) | Node.js / npm / Bun |
| `pnpm-workspace.yaml` | pnpm |
| `lerna.json` | Lerna |
| `nx.json` | Nx |
| `turbo.json` | Turborepo |
| `rush.json` | Rush |
| `.moon/workspace.yml` | Moon |
| `go.work` | Go |
| `settings.gradle` / `settings.gradle.kts` | Gradle |
| `pom.xml` multi-module | Maven |
| `Cargo.toml` com `[workspace]` | Rust |
| `WORKSPACE` / `WORKSPACE.bazel` / `MODULE.bazel` | Bazel |
| `pyproject.toml` com `[tool.uv.workspace]` | Python (uv) |
| `.changeset/config.json` | Changesets |

> Tooling formal é evidência forte, mas não é requisito. Um repo sem tooling pode ser monorepo se contiver 2+ serviços independentemente deployáveis.

---

## §2 — Estrutura de diretórios

1. Busque padrões com `Glob`: `apps/`, `services/`, `modules/` indicam serviços — explore cada subdiretório
2. `libs/`, `packages/common/`, `shared/`, `common/`, `core/`, `utils/` indicam código reutilizável → aplique §5 antes de decidir
3. Verifique se cada subdiretório candidato tem artefato de build/config próprio
4. Identifique apenas **leaf services** (§4)

> Em workspaces Node.js/TypeScript (Turborepo, Nx, pnpm), apps em `apps/<nome>/` podem não ter `Dockerfile` — o container é construído pelo CI/CD. `package.json` no diretório é suficiente como artefato candidato. Workflows são evidência adicional, não requisito.

---

## §3 — Workflows CI/CD

Use `Grep` sobre `.github/workflows/**`:

```
paths:          ← path-based triggers por serviço
matrix:         ← build multi-serviço
deploy          ← jobs de deploy independentes
```

Evidências que confirmam monorepo:
- Múltiplos jobs com `paths:` apontando para diretórios distintos
- Matrizes de build com serviços nomeados
- Jobs de deploy independentes por serviço

---

## §4 — Leaf-service rule

**Algoritmo:**
1. Monte a lista de diretórios candidatos (com artefato de build: `package.json`, `Dockerfile`, `go.mod`, `pom.xml`, `Cargo.toml`, etc.)
2. Para cada candidato `A`, verifique se algum candidato `B` é subdiretório estrito de `A`
3. Se `A` tem filho `B` que também é candidato → `A` não é leaf — descarte-o
4. Somente candidatos sem filhos deployáveis são leaves → recebem label

```
# Exemplo correto:
services/payments/api/    → dx-payments-api   (leaf)
services/payments/worker/ → dx-payments-worker (leaf)
services/payments/        → SEM LABEL          (pai com filhos deployáveis)
```

---

## §5 — Shared-code rule

### Zona shared (`libs/`, `shared/`, `common/`, `core/`, `utils/` e qualquer subdiretório)

**Presunção: código shared.** Essa presunção se aplica ao diretório nomeado **e a todos os seus subdiretórios**.

Só reclassifique como leaf service se houver evidência **simultânea** de:
1. Artefato de build próprio no diretório (`Dockerfile`, `go.mod` com `main`, `.csproj` executável)
2. Job de deploy explícito no CI/CD que implanta em infraestrutura de execução

**Se qualquer um estiver ausente → trate como shared.**

> **Armadilha:** uma lib em `libs/` com `package.json` próprio e workflow de "deploy" para registry de pacotes, site de documentação ou plataforma de visual testing ainda é **shared** — esses destinos não são infraestrutura de execução. O glob `libs/**` deve ser embutido nos serviços consumidores; a lib **não deve ter label standalone**.

### Zona de serviços (`apps/`, `services/`, `modules/`)

**Presunção oposta: são serviços.** Subdiretórios diretos de `apps/`, `services/` ou `modules/` são presumidos leaf services — não aplique a shared-code rule a eles.

Ausência de trigger `paths:` explícito no workflow **não descarta** o serviço. Repositórios com ArgoCD fazem rollout atualizando manifests Kubernetes — não há job de deploy no workflow, mas o serviço é real. Use `Grep` nos workflows apenas para **coletar paths adicionais** (ex: `chart/api/<nome>/`) que também devem entrar no matcher.

### Passo 2 — Consumer detection (para diretórios shared não-deployed)

Use `Grep` para descobrir quais leaf services importam o diretório shared:

| Linguagem | Padrão |
|---|---|
| TypeScript/JS | `from ['"].*<shared-dir>` ou `require\(['"].*<shared-dir>` |
| Go | `"<module>/<shared-dir>` |
| C# | `using <Namespace.SharedDir>` ou `ProjectReference.*<shared-dir>` |
| Python | `^from <shared_dir>` ou `^import <shared_dir>` |

Para cada leaf service que importa o diretório shared, adicione o glob do shared como entrada adicional em `any-glob-to-any-file`.

**Nunca crie label standalone para o diretório shared.**

Se padrão não puder ser determinado → adicione o glob shared em **todos** os leaf services como safe default.

```yaml
# Correto: shared embutido nos consumidores
dx-api:
  - changed-files:
    - any-glob-to-any-file:
        - 'services/api/**'
        - 'libs/**'        # shared consumido por api

# Errado: label standalone para shared
dx-libs:                   # ← PROIBIDO
  - changed-files:
    - any-glob-to-any-file: 'libs/**'
```

---

## §6 — Schema dx-labeler.yaml

**Path:** sempre `.github/dx-labeler.yaml`

Antes de escrever, use `Read` para verificar se já existe:
- **Não existe** → crie do zero com todos os serviços descobertos no Passo A
- **Existe** → compare explicitamente cada serviço da sua lista (Passo A) contra as labels no arquivo. Para cada serviço que **não** tiver label correspondente, ele está faltando — adicione-o. Reescreva o arquivo completo com todos os serviços, incluindo os que já existiam e os novos

**Convenção de nomes:** `dx-<nome-do-diretório-do-serviço>`

| Válido | Inválido |
|---|---|
| `dx-api` | `api` (sem prefixo) |
| `dx-payments-worker` | `dx-release` (intenção de branch) |
| `dx-gateway` | `dx-shared` (shared sem deploy) |

**Matcher padrão:** `any-glob-to-any-file`

```yaml
dx-api:
  - changed-files:
    - any-glob-to-any-file:
        - 'services/api/**'
        - 'libs/**'
        - 'shared/**'

dx-worker:
  - changed-files:
    - any-glob-to-any-file:
        - 'services/worker/**'
        - 'libs/**'
        - 'shared/**'
```

Use **somente `Write`** para gravar o arquivo. Após escrever, **pare** — nenhum comando git.

---

## §7 — Edge cases críticos

| Caso | Decisão |
|---|---|
| Monorepo sem tooling formal | Recomende config se serviços forem independentemente deployáveis |
| Múltiplos packages, único deployable | NÃO recomende configuração monorepo |
| `libs/<nome>/` com `package.json` e pipeline de pacotes | Shared — sem label standalone |
| `libs/<nome>/` com `Dockerfile` E job de deploy para Kubernetes | Leaf service — crie label (único caso de exceção em libs/) |
| Diretórios versionados `v1/api/`, `v2/api/` | Leaf separado só se tiverem CI/CD distintos; caso contrário, pergunte |
| Diretório em `apps/` sem trigger CI/CD | Leaf service válido — deploy pode ser via ArgoCD ou orquestração externa |
| Diretório em `libs/` sem trigger CI/CD | Shared — sem label standalone |
| Diretório sem commits recentes E sem artefato de build | Pule — provavelmente inativo |
| Git submodules | Ignore completamente |
| Com confiança LOW | Use `AskUserQuestion` — não gere config sem confirmação |

---

## §8 — Formato de saída obrigatório

Produza as quatro seções abaixo, nesta ordem:

### 1. Repository Analysis Summary
- Veredicto: "Este repositório **é** / **não é** um monorepo"
- Nível de confiança: **HIGH** / **MEDIUM** / **LOW**
- Lista de leaf services detectados com paths

### 2. Evidence and Findings
- Workspace configs encontrados (com paths)
- Path-based triggers no CI/CD e diretórios cobertos
- Artefatos de build/deploy por serviço

### 3. Configuration Recommendation *(só se monorepo confirmado)*
- Confirme se `.github/dx-labeler.yaml` já existe
- Apresente o conteúdo proposto (ou diff se já existe)
- Explique o rationale de cada label

### 4. Next Steps
- Confirme que o arquivo foi gravado via `Write`
- Confirme que nenhuma operação git foi executada
- Lembre que labels são aditivas (workflow não usa `sync-labels: true`)

---

## §9 — Quality Assurance Checklist

Antes de entregar, confirme cada item:

- [ ] Examinou workspace configs, workflows CI/CD e estrutura de diretórios
- [ ] Cada serviço descoberto no Passo A tem uma label correspondente no arquivo gerado (comparação explícita, item por item)
- [ ] Nenhum subdiretório de `libs/`, `shared/`, `common/`, `core/`, `utils/` recebeu label standalone
- [ ] Nenhum diretório de visual testing, documentação ou publicação de pacotes recebeu label
- [ ] Todos os serviços identificados são de fato independentemente deployáveis
- [ ] Todos os paths no YAML gerado existem no repositório (verificado via `Glob`)
- [ ] Toda label começa com `dx-` e refere-se a um serviço/escopo
- [ ] Nenhuma label baseada em intenção de branch (`release`, `fix`, `feat`, `chore`, etc.)
- [ ] Leaf-service rule aplicada — nenhum diretório pai com filho deployável recebeu label
- [ ] Globs de shared/libs estão embutidos nos leaf services consumidores
- [ ] Se incerto, a incerteza está explicitada e uma pergunta foi feita ao usuário

## Modo Acoes

Esta skill ja atua em **Modo Acoes** (Write nativo do `dx-labeler.yaml`). Sempre confirma antes de escrever. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Criar/atualizar `.github/dx-labeler.yaml`** com labels por servico independente
- **Validar paths via Glob** antes de escrever
- **Aplicar rules** (leaf-service, shared-code, Nx workspace, etc.)
- **NAO** executa operacoes git apos escrever

### Triggers proativos
- "Configurar dx-labeler" / "is this a monorepo?" → executar fluxo de analise + escrever arquivo
- "Adicionar label para servico X" → propor patch incremental

### Acoes destrutivas
- Sobrescrever `.github/dx-labeler.yaml` existente — sempre mostrar diff antes.

## Instrucoes MCP

Esta skill nao tem doc dedicado em `stone-payments/karavela` `docs/` — ela e ortogonal a Karavela. Fontes primarias sao a documentacao oficial do `actions/labeler` e a propria estrutura do repositorio do usuario.

| Repositorio | Arquivo/Caminho | Prioridade | Quando buscar |
|-------------|-----------------|------------|---------------|
| `actions/labeler` | `README.md` (`v6`) | primaria | Sintaxe oficial do `dx-labeler.yaml` (`changed-files`, `any-glob-to-any-file`) |
| `platform-test-org/.github-private` | `.github/agents/check-monorepo.agent.md` | complemento | Variante agente desta skill |

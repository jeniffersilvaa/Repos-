# Migracao para Karavela Packages — Cirurgia no Lockfile (yarn / npm)

Este arquivo foca em **`yarn.lock`** (Yarn Berry) e **`package-lock.json`** (npm) — onde o problema do pin de URL e mais grave porque o lockfile guarda `__archiveUrl` / `resolved` com a URL completa do tarball.

Para outros lockfiles, use o arquivo especifico do ecossistema:

- **`uv.lock`** / **`poetry.lock`** / `requirements.txt` compilado → `references/pypi.md` §Lockfile Registry-Agnostic
- **`packages.lock.json`** (NuGet / Central Package Management) → `references/nuget.md` §`packages.lock.json`
- **`gradle.lockfile`** → `references/maven.md` §Lockfile
- **`go.sum`** → `references/go.md` §Lockfile

Em nuget, gradle **e Go**, o lockfile **nao pineia URL**, so coordenadas + hash canonico (no `go.sum`, pares `module version h1:<hash>` e `module version/go.mod h1:<hash>`), entao regenerar e seguro. Em pypi, `uv.lock` pineia URL como yarn — mesma logica cirurgica, sintaxe diferente.

**`go.sum` é checksum-only (classe nuget/gradle):** sem URL hardcoded, só checksums. Por isso `go mod tidy` regenera safe — não há `__archiveUrl` pra cirurgar, e o `go.mod` (que carrega as versões declaradas) é a fonte da resolução, não o `go.sum`. O caso patológico de Go não é "URL pinada no registry antigo", é **checksum-mismatch**: o Nexus `go-hosted` serve um zip com bytes diferentes do que o `go.sum` gravou (typicamente porque a versão foi originalmente baixada do VCS/proxy.golang.org, não do `go-hosted`). A saída é regenerar o checksum (`go mod tidy` com o GOPROXY apontado pro Nexus) e, se o sumdb público bloquear, `GONOSUMDB=github.com/stone-payments/*` (ou `GOPRIVATE` vazio — **nunca** setado, ver `go.md`). Detalhes em `go.md` §Lockfile + §Armadilhas.

## O Problema

Repositorios que consomem pacotes `@stone-payments/*` geralmente tem o lockfile **pinado no registry antigo**. Yarn Berry (`yarn.lock`) e npm (`package-lock.json`) gravam a URL exata do tarball no campo `resolution` ou `resolved`.

Exemplo antes da migracao (`yarn.lock`):

```yaml
"@stone-payments/ts-logger@npm:2.2.1":
  version: 2.2.1
  resolution: "@stone-payments/ts-logger@npm:2.2.1::__archiveUrl=https%3A%2F%2Fnpm.pkg.github.com%2Fdownload%2F%40stone-payments%2Fts-logger%2F2.2.1%2F4260c5f5a714bcd0320fad9a941cd9c560a6805b"
  dependencies: ...
  checksum: 10c0/9bc6dcc7a5819906913b0d02d186c26fe8c655345e7658a7b115f071b2a794ab77510a30210dc0c7f9beffdd39c14561b9c7d76e9bd229d5bb57e704d414ab63
```

Apos apontar o `.yarnrc.yml` / `.npmrc` para o Nexus Karavela, `yarn install --immutable` / `npm ci` tenta baixar do URL antigo **e ignora o scope** (o `__archiveUrl` tem precedencia). Dois erros surgem:

1. **`E401 Unauthorized`** — o CI nao tem token para o registry antigo (e nem deveria ter).
2. **`YN0018 The remote archive doesn't match the expected checksum`** — se voce so remover o `__archiveUrl`, o yarn resolve pelo scope (Karavela), mas o Nexus **repacka** o tarball. O SHA-512 do tarball repackado nao bate com o checksum que o lockfile guardava (do GH Packages).

## A Armadilha Obvia (Nao Faca)

```bash
# ERRADO — bump de transitivas
rm yarn.lock
touch yarn.lock
yarn install --mode=update-lockfile
```

Isso funciona superficialmente, mas **reflorestа a arvore de dependencias inteira**: todas as transitivas `^minor` pulam para a ultima compativel. Numa PR de "migrar para Karavela" isso polui o diff com centenas de linhas nao-relacionadas, quebra testes que dependiam de versao especifica de transitiva, e mistura dois trabalhos numa PR so.

Sintoma de que voce caiu nessa: diff do lockfile com **centenas** de linhas afetando pacotes sem relacao com `@stone-payments/*`.

## A Cirurgia (Faca Isto)

Estrategia: **partir do lockfile do branch base (ex: `main`), remover SO o `__archiveUrl` do scope Stone, deixar o Yarn recomputar o checksum contra o novo registry**. Outras deps ficam byte-identicas.

### Passo 1 — Restaurar lockfile da base

```bash
git checkout origin/main -- yarn.lock
```

### Passo 2 — Remover `__archiveUrl` (so das entradas Stone)

```bash
python3 -c "
import re
with open('yarn.lock') as f:
    content = f.read()
# Remove o sufixo ::__archiveUrl=... da resolution line
# Ajuste o filtro se o lockfile tem __archiveUrl em deps que nao sao Stone
new_content = re.sub(r'::__archiveUrl=[^\"]+', '', content)
with open('yarn.lock', 'w') as f:
    f.write(new_content)
"
```

Apos rodar:

```bash
grep -c "__archiveUrl" yarn.lock  # deve retornar 0
```

### Passo 3 — Remover os checksums obsoletos

O `__archiveUrl` sumiu, mas o `checksum:` ainda e do tarball antigo. Deixe o Yarn recomputar baixando do Nexus. Para UMA entrada especifica (ex: `@stone-payments/ts-logger@2.2.1`):

```bash
python3 -c "
import re
with open('yarn.lock') as f:
    content = f.read()
# Remove a linha 'checksum: ...' dentro do bloco da entrada alvo
new_content = re.sub(
    r'(\"@stone-payments/ts-logger@npm:2\.2\.1\":.*?)^  checksum: [^\n]+\n',
    r'\1',
    content,
    count=1,
    flags=re.DOTALL | re.MULTILINE,
)
with open('yarn.lock', 'w') as f:
    f.write(new_content)
"
```

Para **todas** as entradas `@stone-payments/*`, expanda o padrao.

### Passo 4 — Deixar Yarn recomputar

```bash
yarn install --mode=update-lockfile
```

Esse comando **nao baixa nada para node_modules** — so atualiza o lockfile. Como agora o scope `@stone-payments` aponta para o Nexus, o Yarn resolve as URLs, baixa os tarballs (com o `--mode`, apenas em memoria para calcular hash), e grava os checksums novos.

### Passo 5 — Conferir o diff

```bash
git diff origin/main -- yarn.lock
```

**Esperado**: apenas 2 linhas por entrada Stone (a `resolution:` sem `__archiveUrl`, a `checksum:` atualizada). **Zero mudanca** em qualquer outra dep.

Se ver dezenas de mudancas, volte ao Passo 1 — algo saiu do controle.

## Quando o Yarn Berry Rejeita `--mode=update-lockfile`

Erro: `The nearest package directory ... doesn't seem to be part of the project declared in ~`

Causa: ha um `yarn.lock` / `package.json` orfao no seu `$HOME` (ou diretorio ancestral). Yarn sobe a arvore procurando o project root e achou o errado.

Solucao: remova os arquivos orfaos do home, ou garanta que esta rodando **exatamente** no diretorio do projeto.

## package-lock.json (npm)

npm grava `resolved: "https://..."` em cada entrada. Estrategia analoga:

```bash
git checkout origin/main -- package-lock.json

# Remove resolved + integrity de entradas Stone
python3 -c "
import json
with open('package-lock.json') as f:
    d = json.load(f)
for name, pkg in d.get('packages', {}).items():
    if '@stone-payments/' in name:
        pkg.pop('resolved', None)
        pkg.pop('integrity', None)
with open('package-lock.json', 'w') as f:
    json.dump(d, f, indent=2)
"

npm install --package-lock-only
```

`--package-lock-only` evita popular `node_modules` e so regenera o lockfile.

## Por que "registry-agnostic" e a palavra-chave

O objetivo da cirurgia e **deixar o lockfile sem URL hardcoded**. Apos a cirurgia, a entrada vira:

```yaml
"@stone-payments/ts-logger@npm:2.2.1":
  version: 2.2.1
  resolution: "@stone-payments/ts-logger@npm:2.2.1"     # ← sem __archiveUrl
  checksum: 10c0/<novo hash do Nexus>
```

Yarn agora resolve o URL em tempo de `install`, consultando o scope `.yarnrc.yml`. Trocar de Nexus STG para PRD, ou voltar para GH Packages temporariamente, deixa de exigir novo lockfile — basta mudar o `.yarnrc.yml`. E o que chamamos de "registry-agnostic".

## Caveats

- **Nexus repacka tarball**: os bytes publicados saem diferentes do que o upstream cuspiu. Por isso o checksum **sempre** precisa ser recomputado.
- **Scope precisa apontar para STG nao para PRD durante validacao**: `npmRegistryServer: "https://packages-stg.stone.tech/repository/npm-group/"`. Na hora de merge para main, troque para PRD. Ou, se nao quiser diff extra no merge, use variavel de ambiente / nao commitar `.yarnrc.yml` por enquanto.
- **Versao pinada nao disponivel em STG**: se o lockfile pineia `@stone-payments/ts-logger@2.2.1` e Nexus STG so tem `2.2.0`, voce precisa publicar `2.2.1` em STG **antes** de regenerar o lockfile. Ver `dependency-cascade.md`.

# Migracao para Karavela Packages — Monorepo

Os snippets de Fase 1/Fase 2 da skill sao **single-module** (um `work_dir`,
um job). Monorepo (varios modulos, possivelmente ecossistemas diferentes)
precisa montar **um job por modulo**. Esta referencia traz o exemplo
**completo** dos dois arquivos, ja montado — destilado de uma migracao real
validada (npm + 2x NuGet + Go no mesmo repo).

## Regra de ouro

> **Uma invocacao do reusable = UM modulo (`work_dir`).** N modulos = N jobs.
> Nao existe "publicar o monorepo inteiro numa chamada só". Cada job tem seu
> `ecosystem` + `work_dir` (+ `version` quando aplicavel).

Outras regras que mudam no monorepo:

- **Versao por modulo, fonte unica.** Se o publish é inline (push→main, ver
  abaixo), compute a versao de cada modulo **uma vez** num job `versions` e
  faça os dois destinos (legado + Karavela) consumirem o mesmo valor. Nao
  recompute por job — corre risco de divergir (um job cria a tag, o outro lê
  a tag nova e bumpa de novo).
- **`owner_group` é o mesmo** para todos os modulos do repo (vem do time dono
  do repo), mas **confirme**.
- **Go**: cada modulo tem sua **propria tag** `module/vX.Y.Z` e a versao
  preserva o `v`. Ver [go.md](go.md).
- **NuGet**: cada `.csproj`/projeto publicavel é um modulo; nome **verbatim**
  (sem rename `StoneCo.*`). Ver [nuget.md](nuget.md).

## Qual caminho de PRD? Decida na Fase 0

| Situacao do repo | Caminho de PRD | Seção |
|---|---|---|
| Release/tag criada por **humano** ou App/PAT | Workflow de PRD **dedicado** (trigger), um job por modulo | abaixo, "PRD dedicado" |
| Repo **auto-releasa por bot** (`GITHUB_TOKEN`) no push→main | Publish **inline** no `auto-release.yml` | abaixo, "PRD inline" + [reusable-pitfalls.md](reusable-pitfalls.md) §12 |

Em ambos os casos o **staging** (validacao pré-merge) é o mesmo: um job por
modulo, removido antes do merge.

## Fase 1 — Staging multi-módulo (igual nos dois caminhos)

Um job por modulo, `version` descartavel **unica por rodada** (idempotencia
de re-run + Go exige semver — ver [reusable-pitfalls.md](reusable-pitfalls.md) §1).

```yaml
# .github/workflows/karavela_packages_publish_staging.yaml  (temporario)
name: Karavela Packages Publish (Staging)

on:
  pull_request:
    branches: [main]   # ← troque p/ 'master' se for o default do repo

permissions:
  contents: read
  id-token: write
  attestations: write

jobs:
  npm:
    uses: stone-payments/karavela-packages-workflows/.github/workflows/karavela_packages_publish.yml@develop
    with:
      ecosystem: 'npm'
      owner_group: '<time-opsgenie>'
      work_dir: 'npm-demo'
      environment: 'stg'
      test_tag: 'pr-${{ github.event.pull_request.number }}'
      version: '0.0.0-pr${{ github.event.pull_request.number }}.${{ github.run_number }}'
    secrets: inherit

  nuget-core:
    uses: stone-payments/karavela-packages-workflows/.github/workflows/karavela_packages_publish.yml@develop
    with:
      ecosystem: 'nuget'
      owner_group: '<time-opsgenie>'
      work_dir: 'nuget-demo/Core'
      environment: 'stg'
      test_tag: 'pr-${{ github.event.pull_request.number }}'
      version: '0.0.0-pr${{ github.event.pull_request.number }}.${{ github.run_number }}'
    secrets: inherit

  nuget-utils:
    uses: stone-payments/karavela-packages-workflows/.github/workflows/karavela_packages_publish.yml@develop
    with:
      ecosystem: 'nuget'
      owner_group: '<time-opsgenie>'
      work_dir: 'nuget-demo/Utils'
      environment: 'stg'
      test_tag: 'pr-${{ github.event.pull_request.number }}'
      version: '0.0.0-pr${{ github.event.pull_request.number }}.${{ github.run_number }}'
    secrets: inherit

  go:
    uses: stone-payments/karavela-packages-workflows/.github/workflows/karavela_packages_publish.yml@develop
    with:
      ecosystem: 'go'
      owner_group: '<time-opsgenie>'
      work_dir: 'go-demo'
      environment: 'stg'
      test_tag: 'pr-${{ github.event.pull_request.number }}'
      version: 'v0.0.0-pr${{ github.event.pull_request.number }}.${{ github.run_number }}'   # Go: prefixe 'v'
    secrets: inherit
```

> Variacao opcional: gate cada job com `dorny/paths-filter` (job `detect`) se
> não quiser publicar todos os modulos em toda PR. Em STG, com `test_tag`
> (TTL), rodar os 4 sempre costuma ser aceitavel e mais simples.

## Fase 2 — PRD dedicado (release por humano/App)

Mesmo esqueleto da Fase 1, mas `@main`, sem `environment`/`test_tag`, e
`version` derivado da tag. Em monorepo as tags sao **prefixadas por modulo**
(`npm-demo/v*`, `nuget-core/v*`, …), então um job `setup` extrai o `X.Y.Z`
limpo e cada modulo é roteado por `if: startsWith(github.ref_name, ...)`:

```yaml
on:
  release: { types: [published] }
  push:
    tags: ['npm-demo/v*', 'nuget-core/v*', 'nuget-utils/v*', 'go-demo/v*']

jobs:
  setup:
    runs-on: ubuntu-latest
    outputs:
      version: ${{ steps.v.outputs.version }}
    steps:
      - id: v
        run: echo "version=${GITHUB_REF_NAME##*/v}" >> "${GITHUB_OUTPUT}"   # npm-demo/v1.2.3 -> 1.2.3

  npm:
    needs: setup
    if: startsWith(github.ref_name, 'npm-demo/v')
    uses: stone-payments/karavela-packages-workflows/.github/workflows/karavela_packages_publish.yml@main
    with: { ecosystem: 'npm', owner_group: '<time>', work_dir: 'npm-demo', version: '${{ needs.setup.outputs.version }}' }
    secrets: inherit
  # ...um job por modulo (nuget-core, nuget-utils com if startsWith), go com version: v${{ ... }}
```

## Fase 2 — PRD inline (repo auto-releasa por bot)

Quando o repo já cria release/tag por bot (`GITHUB_TOKEN`) no push→main, o
workflow de PRD dedicado **nunca dispara** (anti-recursao). Dobre o publish
**dentro** do `auto-release.yml`, no mesmo trigger. Esqueleto completo,
dual-write, com fonte unica de versao:

```yaml
# auto-release.yml (push→main)
permissions:
  contents: write
  packages: write
  id-token: write       # OIDC do reusable
  attestations: write

jobs:
  detect:                # dorny/paths-filter: outputs npm/nuget_core/nuget_utils/go
    # ...

  versions:              # FONTE UNICA da versao por modulo (bump da ultima tag)
    needs: detect
    runs-on: ubuntu-latest
    outputs:
      npm: ${{ steps.c.outputs.npm }}
      nuget_core: ${{ steps.c.outputs.nuget_core }}
      nuget_utils: ${{ steps.c.outputs.nuget_utils }}
      go: ${{ steps.c.outputs.go }}
    steps:
      - uses: actions/checkout@v4
        with: { fetch-depth: 0 }
      - id: c
        run: |
          bump() { local p="$1"; local L; L=$(git tag -l "${p}/v*" | sed "s#${p}/v##" | sort -V | tail -1); if [ -z "$L" ]; then echo "1.0.0"; else IFS=. read -r A B C <<< "$L"; echo "${A}.${B}.$((C+1))"; fi; }
          { echo "npm=$(bump npm-demo)"; echo "nuget_core=$(bump nuget-core)"; echo "nuget_utils=$(bump nuget-utils)"; echo "go=$(bump go-demo)"; } >> "$GITHUB_OUTPUT"

  # Para CADA modulo: um job legado (GH Packages) + um job *-karavela. Independentes
  # (sem needs entre si): falha num destino nao bloqueia o outro. Ambos consomem `versions`.

  npm:                   # legado: GH Packages
    needs: [detect, versions]
    if: needs.detect.outputs.npm == 'true'
    # ... npm version ${{ needs.versions.outputs.npm }} && npm publish; tag/release

  npm-karavela:          # Karavela
    needs: [detect, versions]
    if: needs.detect.outputs.npm == 'true'
    uses: stone-payments/karavela-packages-workflows/.github/workflows/karavela_packages_publish.yml@main
    with:
      ecosystem: 'npm'
      owner_group: '<time>'
      work_dir: 'npm-demo'
      version: ${{ needs.versions.outputs.npm }}
      # test_tag: 'demo'   # SÓ se o repo for demo/sandbox
    secrets: inherit

  # nuget-core / nuget-core-karavela (work_dir nuget-demo/Core)
  # nuget-utils / nuget-utils-karavela (work_dir nuget-demo/Utils)
  # go / go-karavela (work_dir go-demo, version: v${{ needs.versions.outputs.go }})
```

Pontos do inline (ver [reusable-pitfalls.md](reusable-pitfalls.md) §12):

- **Sem disparo duplo**: as tags pushadas pelos jobs legados usam
  `GITHUB_TOKEN` → não disparam os `*-release.yml` legados.
- **Fase 5 muda**: não há release manual pela UI — o publish acontece no
  merge para `main` que toca um modulo. Valide tocando um modulo numa PR.
- **Go inline**: `version: v${{ needs.versions.outputs.go }}` (preserva o `v`).

## Checklist extra de monorepo

- [ ] Um job por modulo (staging) / um par legado+`*-karavela` por modulo (inline)
- [ ] `work_dir` correto por modulo (raiz do `.csproj`/`package.json`/`go.mod` do modulo)
- [ ] Versao por modulo de **fonte unica** (job `setup`/`versions`), não recomputada por job
- [ ] Go: `v` preservado + tag `module/vX.Y.Z`
- [ ] NuGet: `<PackageId>` verbatim por projeto, sem rename
- [ ] Lockfile npm presente em **cada** modulo npm (o reusable roda `npm ci`)
- [ ] Staging removido antes do merge

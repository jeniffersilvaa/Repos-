# Migracao para Karavela Packages — Dual-Write e Cutover

## Quando Cada Estrategia

| Sinal | Estrategia |
|---|---|
| Lib ja e consumida por apps / outros repos **externos** ao controle do time | Dual-write |
| Release cycle publico (ex: mudou de version cadence? quebrou semver?) | Dual-write conservador (4+ semanas) |
| Lib interna consumida so pelo mesmo time, todas as apps migram junto | Cutover na mesma PR |
| Registry antigo esta deprecated ou inacessivel | Cutover compulsorio |
| Ha um pipeline legado estavel e bem-conhecido que e arriscado tocar | Dual-write — adiciona Karavela, nao remove nada |

## Dual-Write (Recomendado Durante a Janela de Migracao)

A tese: publicar nos **dois** destinos na mesma versao por N semanas. Consumidores antigos continuam resolvendo do registry antigo; consumidores novos apontam para Karavela.

### Forma simples — adicionar job novo no workflow existente

```yaml
# .github/workflows/publish.yml
name: Publish Packages

on:
  release:
    types: [published]
  push:
    tags:
      - 'v*-rc.*'
      - 'v*-beta.*'
      - 'v*-alpha.*'

jobs:
  # JOB LEGADO — intocado
  PublishGitHubPackages:
    name: Publish (GitHub Packages)
    runs-on: small-runner
    permissions:
      contents: read
      packages: write
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '22'
          registry-url: 'https://npm.pkg.github.com'
      - run: npm ci
      - run: npm run build
      - run: npm publish
        env:
          NODE_AUTH_TOKEN: ${{ secrets.GITHUB_TOKEN }}

  # JOB NOVO — adicionado
  PublishKaravela:
    name: Publish to Karavela Packages
    permissions:
      contents: read
      id-token: write
      attestations: write
    uses: stone-payments/karavela-packages-workflows/.github/workflows/karavela_packages_publish.yml@main
    with:
      ecosystem: 'npm'
      owner_group: '<time>'
      work_dir: '.'
      version: ${{ github.ref_name }}
    secrets: inherit
```

Os dois jobs disparam em paralelo no mesmo trigger. Ambos publicam a mesma versao (vinda da tag/release).

### `publishConfig.registry` nao precisa mudar

No `package.json`:

```json
"publishConfig": {
  "registry": "https://npm.pkg.github.com/@stone-payments"
}
```

**Deixe assim durante dual-write**. O reusable Karavela chama `npm publish <tgz> --registry <nexus>` — a flag `--registry` no CLI sobrescreve `publishConfig.registry` do tarball. Entao:

- Job legado: usa `publishConfig.registry` → publica em GH Packages
- Job Karavela: usa `--registry` explicito → publica em Nexus

Os dois dao certo sem conflito.

> **Go nao tem override publisher-side.** Não existe `--registry` nem `publishConfig` em Go — o `go-hosted` é populado via protocolo GOPROXY (PUT de `.info`/`.mod`/`.zip`), não por `npm publish`. Por isso, **dual-write em Go acontece no lado do *consumidor*, não do publisher**: é a cadeia `GOPROXY=<novo>,<antigo>,direct` (cascata para o proxy/VCS antigo enquanto a migração roda). O padrão "2 jobs paralelos, sem `needs:`, falhas independentes" **continua válido** para publicar nos dois destinos — só o mecanismo de *override de destino* muda (variável de ambiente `GOPROXY` no job, não flag de CLI no manifesto). Detalhes em `go.md` §Dual-Write.

### Fases do rollout

| Fase | Duracao | Acao |
|---|---|---|
| 1. Dual-write | 1–2 semanas | Jobs paralelos rodando; consumidores novos migram `.npmrc` para Karavela |
| 2. Validacao | 1–2 semanas | Piloto de consumidor real migra em staging |
| 3. Cutover gradual | 2+ semanas | Resto dos consumidores migra; job legado segue |
| 4. Sunset | — | Remove job legado da lib + publica "deprecation notice" no registry antigo |

Indicador de que a Fase 4 e segura: telemetria do registry antigo mostra zero downloads da lib por 1-2 releases.

## Cutover (Substitui o Workflow Antigo)

Na mesma PR:

- Adiciona `karavela_packages_publish.yaml`
- **Remove** `publish.yml` antigo
- (Opcional) Atualiza `publishConfig.registry` do `package.json` para `https://packages.stone.tech` — apenas cosmetico, o `--registry` explicito do reusable fala mais alto

Risco: consumidores que nao atualizaram `.npmrc` vao falhar no proximo `npm install`. So faca se:

1. Voce conhece todos os consumidores (interno ao time) E
2. Voce coordenou atualizacao deles para o scope Karavela OU
3. O registry antigo esta deprecated/sem-downloads ha meses

## Durante o Dual-Write, Trate Falhas Independentes

Os dois jobs falham independentemente. Cenarios:

| Job legado | Job Karavela | Acao |
|---|---|---|
| OK | Fail | Investigar Karavela; consumidores novos esperam a proxima release |
| Fail | OK | Investigar legado; consumidores antigos esperam (nao quebra) |
| Fail | Fail | Possivel bug no build; tag recriada se possivel |

**Nao use `needs:` entre os jobs**. Se `karavela` falhar, nao queremos bloquear `legado`. Deixe-os paralelos de verdade.

## Metricas para Decidir Sunset

Colete antes de remover o legado:

- Downloads do registry antigo (nos ultimos 7/30/90 dias)
- Apps que importam a lib — fazer `rg '@stone-payments/<lib>' --glob '.npmrc'` nos repos da org
- Tags de release feitas desde o cutover — se tem pelo menos 2 sem ninguem reclamar, e sinal verde

## Anti-patterns

- **`needs: PublishGitHubPackages`** no job Karavela — isso serializa, mata o ganho de paralelismo, e uma falha no legado bloqueia a publicacao nova.
- **`if: success()`** entre eles — mesma confusao.
- **Mudar `publishConfig.registry` para Karavela no inicio** — nao e erro, mas durante dual-write e desnecessario. Faca no cutover.
- **Esperar 100% dos consumidores migrarem antes do sunset** — na pratica, nao acontece. Estabeleca um cutoff (ex: 30 dias sem downloads) e comunique.

# Migracao para Karavela Packages — Bun

## Situacao

Repo usa `bun` como package manager (`bun.lock` ou `bun.lockb` na raiz). Possivelmente `patchedDependencies` no `package.json` — feature especifica de bun/pnpm que `npm` nao suporta.

## Suporte Nativo no Reusable Workflow

Bun e suportado nativamente em `karavela-packages-workflows@main` desde 2026-04-23 (PRs [#99](https://github.com/stone-payments/karavela-packages-workflows/pull/99) + [#100](https://github.com/stone-payments/karavela-packages-workflows/pull/100)). O reusable detecta `bun.lock` / `bun.lockb`, instala bun via `oven-sh/setup-bun@v2` no `setup-ecosystem` e roda `bun install --frozen-lockfile && bun run build && npm pack` no `build-package`.

### Caminho preferido — sem `build_command`

Chame o reusable workflow sem `build_command` — o caso `bun)` do `build-package` cuida de install + build + `npm pack` automaticamente:

```yaml
with:
  ecosystem: 'npm'
  owner_group: '<time>'
  work_dir: '.'
  # build_command omitido — bun nativo cuida de install+build+pack
```

### Refs antigas — workaround inline (historico)

> Aplica apenas se o caller esta preso a um ref do reusable **anterior a 2026-04-23** (pre-PR #99). Em qualquer caso novo, atualize o caller para `@main`.

```yaml
with:
  build_command: 'curl -fsSL https://bun.sh/install | bash && export PATH="$HOME/.bun/bin:$PATH" && bun install --frozen-lockfile && bun run build && npm pack'
```

**Note os quatro passos**: install bun, exportar PATH na mesma sessao, rodar install+build, **e explicitamente `npm pack`**. O `build-package` action **sai apos executar um `build_command` custom** (`exit $?`), entao o `npm pack` default do caminho nativo nunca roda. Sem o `npm pack` no comando custom, o publish falha com `ENOENT '*.tgz'`.

## Erros Conhecidos

### `bun: command not found`

Rodando `build_command: 'bun install ...'` sem que o reusable tenha instalado bun.

- **Chamando reusable `@main` (atual)**: nao deveria acontecer — `setup-ecosystem` detecta bun via step bash e roda `oven-sh/setup-bun@v2`. Se acontecer, abra issue.
- **Chamando reusable em ref antiga (pre-PR #99 / 2026-04-23)**: use o workaround inline da secao "Refs antigas" acima, ou atualize o caller para `@main`.

### Setup Bun step "nao cai" / fica cinza no log (historico)

Bug ja corrigido em PR [#100](https://github.com/stone-payments/karavela-packages-workflows/pull/100) — ver `reusable-pitfalls.md` item 4 para o WHY conceitual (`hashFiles()` em composite actions falha silenciosamente em arquivos binarios; substituido por step bash explicito com `$GITHUB_OUTPUT`).

### Runner do Karavela nao tem bun pre-instalado

Runners `small-runner` / `medium-runner` nao shippam bun. O `setup-ecosystem` instala via `oven-sh/setup-bun@v2` quando o lockfile e detectado — confirmado contra smoke matrix (sem entrada bun dedicada, mas o caminho npm com lockfile bun roda no `small-runner` default).

## Interacao com `patchedDependencies`

`patchedDependencies` no `package.json` e feature de bun/pnpm. **Nao tente cair pra `npm ci`** — npm ignora o campo silenciosamente e publica o pacote sem as patches, quebrando em producao.

Sempre rode `bun install --frozen-lockfile` (ou `pnpm install --frozen-lockfile`).

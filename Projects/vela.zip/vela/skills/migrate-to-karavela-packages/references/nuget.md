# Migracao para Karavela Packages — NuGet

## Manifesto (`.csproj`)

Mantenha a versao seed (`0.1.0`) — a versao real e injetada via `version: ${{ github.ref_name }}`:

```xml
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <Version>0.1.0</Version>
    <PackageId>MeuPacote</PackageId>
    <Authors>Stone Payments</Authors>
    <PackageLicenseExpression>MIT</PackageLicenseExpression>
    <IsPackable>true</IsPackable>
  </PropertyGroup>
</Project>
```

**Naming relaxado — o `<PackageId>` é publicado verbatim.** Hoje o Portal **não força namespacing** em NuGet: o nome publicado é **exatamente** o `<PackageId>` do `.csproj`, sem prefixo `StoneCo.` e sem split em `[-_.]`.

| Manifesto (`PackageId`) | Publicado |
| --- | --- |
| `Stone.Demo.Core` | `Stone.Demo.Core` |
| `MeuPacote` | `MeuPacote` |
| `meu-pacote` | `meu-pacote` |

**Numa migração, vá pelo simples: mantenha o `<PackageId>` que o repo já usa.** **Não** proponha rename para um "nome canônico" `StoneCo.*` — só geraria churn e quebraria consumidores atuais à toa. Só mexa no nome se houver **conflito de identidade real**: `409` no plan, ou o par `(nuget, PackageId)` já pertence a outro time. Aí sim, com o usuário.

**`<PackageId>` vs nome do arquivo**: se `<PackageId>` está ausente, o NuGet usa o nome do `.csproj` como fallback (identidade publicada). Defina sempre explicitamente para o nome não depender do arquivo.

## Apontar `.NET CLI` para STG Nexus

### `NuGet.Config` no repo

```xml
<?xml version="1.0" encoding="utf-8"?>
<configuration>
  <packageSources>
    <clear />
    <add key="karavela-stg-v3" value="https://packages-stg.stone.tech/repository/nuget-group-v3/index.json" protocolVersion="3" />
  </packageSources>
</configuration>
```

**v2 vs v3**: Nexus expoe ambos. v3 e o default moderno; v2 pode ser necessario se o reusable/consumer usa Yarn Berry-style de fetching ou tooling antigo. Em `setup-consumer` do platform-k8s-github-actions, o input `nuget_source_mode` aceita `v2 | v3 | mixed`.

### CLI direto

```bash
dotnet nuget add source "https://packages-stg.stone.tech/repository/nuget-group-v3/index.json" \
  --name karavela-stg \
  --configfile NuGet.Config
```

## `packages.lock.json` — Central Package Management

Se o repo usa `<RestorePackagesWithLockFile>true</RestorePackagesWithLockFile>`, existe `packages.lock.json` por projeto. Diferente de yarn/npm, **nao pineia URL** — so versao + content hash:

```json
{
  "version": 1,
  "dependencies": {
    "net8.0": {
      "Newtonsoft.Json": {
        "type": "Direct",
        "requested": "[13.0.3, )",
        "resolved": "13.0.3",
        "contentHash": "HrC5BXdl00IP9zeV+0Z848QWPAoCr9P3bDEZguI+gkLcBKAOxix/tLEAAHC+UvDNPv4a2d18lOReHMOagPa+zQ=="
      }
    }
  }
}
```

**Estrategia**: delete e regenere. Como `contentHash` e do artefato canonico (nao da URL de origem), o Nexus repackando nao altera o hash — entao regenerar e seguro:

```bash
find . -name 'packages.lock.json' -delete
dotnet restore --force-evaluate
```

`--force-evaluate` reconcilia versoes sem bumpar transitivas inesperadamente.

Se o projeto NAO usa `packages.lock.json`, nenhuma cirurgia e necessaria.

## Dual-Write com GitHub Packages NuGet

Ver `references/dual-write.md` para pattern geral. Para NuGet:

```yaml
publish-legacy:
  needs: release-please
  if: needs.release-please.outputs.release_created == 'true'
  runs-on: small-runner
  steps:
    - uses: actions/checkout@v4
      with: { ref: '${{ needs.release-please.outputs.tag_name }}' }
    - uses: actions/setup-dotnet@v4
      with: { dotnet-version: '8.0.x' }
    - run: dotnet pack -c Release -o ./dist /p:Version=${{ needs.release-please.outputs.version }}
    - run: |
        dotnet nuget add source https://nuget.pkg.github.com/stone-payments/index.json \
          --name github --username stone-payments --password ${{ secrets.GITHUB_TOKEN }} \
          --store-password-in-clear-text
        dotnet nuget push ./dist/*.nupkg --source github --skip-duplicate

publish-karavela:
  needs: release-please
  if: needs.release-please.outputs.release_created == 'true'
  uses: stone-payments/karavela-packages-workflows/.github/workflows/karavela_packages_publish.yml@main
  with:
    ecosystem: nuget
    owner_group: <time>
    version: ${{ needs.release-please.outputs.version }}
    work_dir: '.'
  secrets: inherit
```

**`--skip-duplicate`** no push legado faz a re-execucao ser idempotente. O Karavela reusable ja tem `filter-already-published` para o mesmo proposito.

## Multi-Projeto via `.sln`

Se o repo tem `*.sln` na raiz, o reusable detecta automaticamente e roda:

```bash
dotnet pack <arquivo>.sln -c Release -o ./dist
```

Todos os projetos com `<IsPackable>true</IsPackable>` (default se houver `<Version>`) viram `.nupkg` em `./dist/`. Projetos de teste (geralmente `<IsPackable>false</IsPackable>`) sao ignorados.

**ProjectReference entre projetos publicaveis**: funciona. `dotnet pack` resolve cada `<ProjectReference>` como `<PackageReference>` no `.nupkg` final, usando a `<Version>` do projeto referenciado. Durante o `override-version`, **todos** os `.csproj` sao atualizados, mantendo coerencia.

Se um projeto e `ProjectReference` mas **nao** deve ser publicado isolado, marque com:

```xml
<ProjectReference Include="..\Internal\Internal.csproj">
  <PrivateAssets>all</PrivateAssets>
</ProjectReference>
<PropertyGroup>
  <IsPackable>false</IsPackable>
</PropertyGroup>
```

## Armadilhas

### v2 vs v3 source mode

Alguns projetos antigos pedem endpoint v2 (`/repository/nuget-group/` — sem `-v3` e sem `/index.json`). O reusable publica via v3 por default. Para **consumer** em CI, o `setup-consumer` aceita `nuget_source_mode: mixed` que configura ambos.

Sintoma de `v2 vs v3` trocados: `Unable to load the service index for source` — checar se a URL termina em `/index.json` (v3) ou nao (v2).

### `409 Conflict` no publish

`dotnet nuget push` retorna 409 se a mesma versao ja existe. O reusable Karavela ja usa logica de `filter-already-published`, mas se voce chamou o push manualmente (ex: dual-write), use `--skip-duplicate`.

### `PackageId` ausente → nome do arquivo vaza

Se o `.csproj` nao tem `<PackageId>` explicito, o NuGet usa o nome do arquivo (sem `.csproj`) como identidade publicada. **Sempre defina `<PackageId>` explicitamente** para o nome publicado não depender do nome do arquivo. O `<PackageId>` definido é publicado **verbatim** (naming relaxado, sem namespacing forçado).

### Symbol packages (`.snupkg`)

Nexus aceita `.snupkg` mas o reusable nao publica por default. Se voce precisa de symbol packages, chame `dotnet pack -c Release --include-symbols -p:SymbolPackageFormat=snupkg` via `build_command` e publique o `.snupkg` manualmente (ou abra issue no repo do reusable).

### `dotnet restore --use-lock-file` nao existe

Para forcar uso do lockfile no CI: `<RestoreLockedMode>true</RestoreLockedMode>` + `dotnet restore --locked-mode`. Em workflows do consumer, isso exige que o `packages.lock.json` seja **byte-compativel** com o registry — se migrou, regenere uma vez antes de ativar `--locked-mode`.

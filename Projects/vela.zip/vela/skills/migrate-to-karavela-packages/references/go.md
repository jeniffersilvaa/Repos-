# Migracao para Karavela Packages — Go (modulos via GOPROXY)

> Go é um ecossistema **estruturalmente diferente** dos outros quatro. Antes de aplicar qualquer receita deste arquivo, internalize as quatro divergências — elas mudam o que "migrar" significa:
>
> 1. **Source-only — não compila.** O artefato publicável é o source tree zipado (protocolo GOPROXY), não um binário/tarball. Não existe "build"; **não há `*.tgz`/`*.nupkg`/`*.whl`**. Logo, o framing de `build-command.md` (custom build pula o pack → `ENOENT *.tgz`) **não se aplica**.
> 2. **Identidade = module path literal do `go.mod`**, sem transform. Não há `@stone-payments/...`, `StoneCo.`, `co.stone.` — é pass-through, igual a um `raw`.
> 3. **Versão vem da tag git, sem campo no manifesto.** O `go.mod` **não tem** `version`. Todo "mantenha a versão seed `0.0.1`/`0.1.0`" dos outros ecossistemas **não se aplica** a Go.
> 4. **Publish via protocolo GOPROXY** (PUT de `.info`/`.mod`/`.zip`/`list`) para o repo **`go-hosted` compartilhado**; consumo secretless via `go-group`/`go-hosted` (leitura pública). Não há `npm publish`/`--registry`; **dual-write é via cadeia `GOPROXY ...,direct`**, não flag de CLI publisher-side.
>
> Exemplo real de referência: **stngo** (`github.com/stone-payments/stngo`, monorepo Go) — workflows `karavela-auto-release.yaml` (push→main) + `karavela-backfill-versions.yaml` (dispatch matricial de backfill).

> **Feature flag**: Go está atrás de `karavela.packages.goEcosystemEnabled`. Está **habilitado onde Go é usado** (stngo publica em **prd**). Com a flag off, `publish-plan`/`confirm-onboarding` rejeitam `ecosystem: 'go'` com `400 INVALID_REQUEST`. Se um repo Go falhar no plan com esse erro, é gating de rollout do ambiente, não bug do workflow.

## Manifesto (`go.mod`)

**Não há versão seed.** O `go.mod` declara só o `module` (a identidade) e os `require` — **nenhum campo `version`**:

```go
module github.com/stone-payments/payment-sdk

go 1.26

require (
	github.com/stone-payments/another-lib v1.4.0
	github.com/some/oss-dep v0.9.1
)
```

O Portal publica como **`github.com/stone-payments/payment-sdk`** — o module path literal, **sem transform**. Você **não** renomeia nada no manifesto (ao contrário de npm, que vira `@stone-payments/...`). A "verificação de nome canônico" da Fase 0 em Go é trivial: o nome publicado **é** o `module` do `go.mod`, ponto.

> **Monorepo / submódulo**: cada `go.mod` declara seu próprio module path. Um submódulo em `sub-a/go.mod` com `module github.com/stone-payments/payment-sdk/sub-a` publica como `github.com/stone-payments/payment-sdk/sub-a`. A identidade é sempre `{modulePath}/{subpath}` — ver §Multi-Module.

## Apontar Go toolchain para STG Nexus

Durante a validação `environment: stg`, consumidores resolvem do Nexus STG. O ponto de ancoragem é a variável **`GOPROXY`** — Go não tem arquivo de config por-projeto como `.npmrc`/`settings.xml`; a configuração é por env var (ou `go env -w`).

```bash
go env -w GOPROXY="https://packages-stg.stone.tech/repository/go-group,direct"
# NAO setar GOPRIVATE (deixar vazio)
# GONOSUMDB cobre o bypass do sumdb publico para modulos internos:
go env -w GONOSUMDB="github.com/stone-payments/*"
```

Ou via env no CI:

```yaml
env:
  GOPROXY: "https://packages-stg.stone.tech/repository/go-group,direct"
  GONOSUMDB: "github.com/stone-payments/*"
  GOPRIVATE: ""        # vazio DE PROPOSITO
```

Três regras load-bearing:

- **`GOPRIVATE` fica VAZIO.** `GOPRIVATE=github.com/stone-payments/*` faria o Go ir **direto pro VCS** (clone git autenticado), **furando o proxy** — exatamente o que a migração quer evitar. Quem garante o bypass do checksum-db público é o `GONOSUMDB`, não o `GOPRIVATE`.
- **`,direct` é o último elo.** A cadeia tenta o `go-group` (que agrega `go-hosted` privado + proxy OSS) e só cai em `direct` (clone VCS) em `404`/`410`. Para STG, `go-group` já cobre os módulos privados publicados em `go-hosted` STG.
- **STG vs PRD muda só o host.** STG = `packages-stg.stone.tech`; PRD = `packages.stone.tech`. Nada mais no comando muda.

## Lockfile — `go.sum`

`go.sum` é **checksum-only** (classe nuget/gradle, **não** classe yarn/npm/uv): grava pares `module version h1:<hash>` + `module version/go.mod h1:<hash>`, **sem URL hardcoded**. Quem carrega as versões declaradas é o `go.mod`; o `go.sum` só atesta integridade.

Consequência prática: **regenerar é safe**. Não há `__archiveUrl` pra cirurgar (como em `yarn.lock`). Aponte o `GOPROXY` pro Nexus e rode:

```bash
go mod tidy
# ou, para baixar sem alterar o grafo de versoes:
go mod download
```

Isso **não** reflorestа transitivas se as versões em `go.mod` estão pinadas — `go mod tidy` respeita o MVS (minimal version selection), não faz bump gratuito.

### Checksum mismatch (o caso patológico de Go)

O problema de Go **não** é "URL pinada no registry antigo" — é **`go.sum mismatch`**: o `go-hosted` serve um zip com bytes diferentes do que o `go.sum` gravou. Acontece tipicamente quando a versão foi originalmente baixada do `proxy.golang.org` / VCS, e agora o Nexus serve um zip re-empacotado. Sintoma:

```
verifying github.com/stone-payments/<mod>@vX.Y.Z: checksum mismatch
	downloaded: h1:<hash-do-nexus>
	go.sum:     h1:<hash-antigo>
SECURITY ERROR
```

Resolução:

1. Garanta `GONOSUMDB=github.com/stone-payments/*` (bypassa o sumdb público **só** para os módulos internos — não desliga a verificação dos OSS).
2. **`GOPRIVATE` vazio** (setá-lo furaria o proxy e mascararia o problema).
3. Apague a linha obsoleta do `go.sum` e deixe o `go mod tidy`/`go mod download` regravar contra o Nexus:
   ```bash
   go mod tidy   # regrava o checksum a partir do GOPROXY atual
   ```
4. Se o mismatch persistir no pipeline de publish (corrida de backfill + `go.sum` defasado), o `generate-sbom` do reusable já tem **fallback pro `syft`** (PR #254) que contorna a falha do `cyclonedx-gomod` nesse cenário — não é algo que você precise cabear no repo migrante.

## Dual-Write

Go **não tem override publisher-side** — não existe `--registry` nem `publishConfig`/`distributionManagement`. O `go-hosted` é populado pelo protocolo GOPROXY (PUT de `.info`/`.mod`/`.zip`/`list`), gerado internamente pelo reusable. Então o **dual-write em Go vive no lado do consumidor**, não do publisher.

### Publisher-side: 2 jobs paralelos (o padrão geral continua)

O padrão de `dual-write.md` (dois jobs no mesmo trigger, **sem `needs:`**, falhas independentes) **continua válido** para publicar a mesma tag em dois destinos. O que muda é que o "destino antigo" de Go normalmente **não é um publish ativo** — Go OSS-style é resolvido direto do VCS (tags git), sem um registry de publicação separado. Na prática, a maioria das migrações Go é **cutover puro**: você passa a publicar no `go-hosted`, e os consumidores trocam o `GOPROXY`.

### Consumer-side: a cadeia `GOPROXY ...,direct` é o dual-write

Enquanto os consumidores migram, eles apontam o `GOPROXY` para uma **cadeia** que tenta o Nexus primeiro e cai no destino antigo depois:

```bash
# Durante a migracao — consumidor resolve do Nexus, com fallback pro proxy/VCS antigo:
GOPROXY="https://packages.stone.tech/repository/go-group,https://proxy.golang.org,direct"
```

- `go-group` (Nexus) responde os módulos privados Stone publicados no `go-hosted`.
- O elo seguinte (`proxy.golang.org` ou um proxy interno antigo) cobre o que ainda não migrou.
- `,direct` (clone VCS) é o último recurso.

Quando todos os módulos internos estão no `go-hosted`, simplifica para `https://packages.stone.tech/repository/go-group,direct`. **Atenção ao `,direct` final** — se um módulo privado `github.com/stone-payments/*` **não** estiver no `go-hosted`, ele cai em `direct`, que tenta clonar o repo privado e **exige auth VCS** (cenário "banking-repo-reader app"). A recomendação MVP é **garantir o módulo no `go-hosted` antes** e evitar que privados caiam em `direct`.

## Multi-Module

Monorepo Go = **`go.work` e/ou múltiplos `go.mod`** na árvore. O detector do reusable (`detect-workspace-modules`/`collect-modules`, branch `go)`) roda `find . -name go.mod` (excluindo `vendor`/`node_modules`), pega o module path do head de cada `go.mod`, e skipa o root quando há submódulos.

A diferença crucial vs. os outros ecossistemas:

> **Uma invocação do `publish` publica o GOPROXY zip de UM módulo** (o de `inputs.work_dir`). O monorepo é coberto por **múltiplas invocações — uma por (módulo, tag)** — orquestradas pelo **caller**, não por um job único iterando submódulos. Cada módulo tem:
> - sua **própria tag** no formato `module/vX.Y.Z` (ex: `sub-a/v1.4.0`, `sub-b/v2.0.1`) — é o formato que o `go-hosted` exige para submódulos em sub-path;
> - seu próprio **`work_dir`** apontando pra pasta do submódulo.

### Backfill matricial

Para publicar versões pré-existentes de todos os módulos (ou backfillar um monorepo inteiro de uma vez), o padrão é um workflow de **dispatch matricial: 1 dispatch por (módulo, versão)**. É exatamente o que o `karavela-backfill-versions.yaml` do **stngo** faz — uma matriz que invoca o reusable N vezes, cada célula com seu `work_dir` + `version` (a tag `module/vX.Y.Z` daquele módulo). Não tente publicar um monorepo Go com uma única chamada do reusable.

### Cascata interna

Se um módulo do monorepo `require github.com/stone-payments/<outro-modulo>`, a ordem **folha → raiz** vale igual aos outros ecossistemas (ver `dependency-cascade.md`): publique o módulo-folha no `go-hosted` antes do consumidor. A falha de "versão ainda não está no STG" em Go aparece como **`410 Gone`** ou **`go.sum mismatch`**, não `Package not found`.

## Armadilhas

### `410 Gone` no `go mod download`

O `go-hosted` retorna **`410 Gone`** para uma versão que não foi publicada (não `404`). Sintoma:

```
go: github.com/stone-payments/<mod>@vX.Y.Z: reading .../go-hosted/.../@v/vX.Y.Z.info: 410 Gone
```

Causas comuns:
1. A versão (tag) ainda não foi publicada no `go-hosted` — **cascata** (publique a lib antes; ver §Multi-Module).
2. O módulo é privado e caiu em `,direct` por estar ausente do `go-hosted`.
3. A tag não está no formato esperado em monorepo (`module/vX.Y.Z`, não `vX.Y.Z` global).

### `go.sum mismatch`

Ver §Lockfile → "Checksum mismatch". Resumo: `GONOSUMDB=github.com/stone-payments/*`, **`GOPRIVATE` vazio**, regravar via `go mod tidy`.

### `GOPRIVATE` setado fura o proxy

`GOPRIVATE=github.com/stone-payments/*` faz o Go **pular o proxy e clonar o VCS direto** — autenticação git, sem passar pelo `go-hosted`. É o erro nº 1 de quem migra Go achando que "private" significa "use auth". **Deixe `GOPRIVATE` vazio**; o bypass do checksum-db é trabalho do `GONOSUMDB`.

### `,direct` em módulo privado exige auth VCS

O `,direct` final da cadeia `GOPROXY` é clone git. Para OSS resolve sem auth; para um `github.com/stone-payments/*` privado **ausente do `go-hosted`**, ele tenta clonar o repo privado e falha pedindo credencial VCS. Mitigação MVP: garanta o módulo no `go-hosted` **antes**, evite que privados caiam em `direct`.

### Pseudo-versions

Quando um consumidor referencia um commit **sem tag**, o Go sintetiza uma pseudo-version `v0.0.0-<timestamp>-<sha>` (ex: `v0.0.0-20260610153000-abc1234def56`). Não é algo que você publica de propósito — aparece no `go.mod`/`go.sum` de quem consome um ref untagged. Se o build/resolve precisa lidar com pseudo-versions, **`fetch-depth: 0`** no checkout (e `fetch_depth: 0` no input do reusable) ajuda o `go list -m` a resolvê-las, pois exige o histórico git completo.

### `build_runs_on: ubuntu-latest` vira no-op silencioso

> ⚠️ **Go é INTERNAL-MODE only — exige runner self-hosted** (`small`/`medium`/`large`/`xlarge-runner`). Os jobs SaaS do reusable (`build` + `publish-external`, que rodam em `ubuntu-latest`/`windows-latest`) **excluem Go**. Se você dispachar Go com `build_runs_on: ubuntu-latest`, **nenhum job casa e o workflow vira no-op silencioso** — passa verde sem publicar nada.
>
> Correção: **não passe `build_runs_on`** (deixe o default self-hosted do reusable resolver). Só passe um runner explícito se for um self-hosted válido e o usuário pedir.

### `id-token: write` faltando

Como nos outros ecossistemas, o publish usa OIDC. Sem `permissions.id-token: write` no job chamador (+ `secrets: inherit`), o `plan`/upload falha por falta de token. Bloco canônico:

```yaml
permissions:
  contents: read
  id-token: write
  attestations: write
```

### Scan SCA (Grype) é informacional

O Grype roda no pipeline de Go mas **não bloqueia o publish** (sem `--fail-on critical`) — é informacional. Um achado de vulnerabilidade **não** trava a migração. (A SBOM via `cyclonedx-gomod`, com fallback `syft`, também é `continue-on-error`.)

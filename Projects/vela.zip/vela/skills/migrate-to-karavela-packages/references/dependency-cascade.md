# Migracao para Karavela Packages — Cascata de Dependencias Internas

## Quando Voce Cai Aqui

Um repo em migracao (`A`) depende de outro repo tambem migrando (`B`). Ex: monorepo `ts-shared` tem pacotes que pineiam `@stone-payments/ts-logger@2.2.1`.

Se o `ts-logger@2.2.1` ainda nao esta no Nexus Karavela (nem STG nem PRD), `yarn install` do `ts-shared` apontado para o Nexus falha com **uma das duas**:

- `Package not found` — se a versao nunca foi publicada em Karavela
- `YN0018 checksum mismatch` — se o lockfile ainda tem `__archiveUrl` do GH Packages (ver `lockfile-surgery.md`)

> **Variante Go**: a mesma cascata existe quando um módulo Go `require github.com/stone-payments/<lib> vX.Y.Z` e essa versão **ainda não está no `go-hosted`**. O sintoma muda: em vez de `Package not found`/`YN0018`, o `go mod download` falha com **`410 Gone`** (GOPROXY não tem aquela versão) ou **`go.sum mismatch`** (o checksum gravado não bate com o zip que o Nexus serve). A **ordem de migração folha → raiz é idêntica** — publique a lib no `go-hosted` antes do módulo consumidor. Ver `go.md` §Multi-Module e §Armadilhas.

## Ordem de Migracao

Sempre migre **de folha para raiz**: o pacote sem dependencias internas e o primeiro. O repo que consome os outros e o ultimo.

Exemplo com tres repos:

```
ts-logger ────┐
              ├───> ts-shared ───> app-qualquer-que-consome
ts-toolkit ───┘
```

Ordem: `ts-logger` e `ts-toolkit` (paralelo) → `ts-shared` → `app-qualquer-que-consome`.

## Tecnica — Publicar Versao Legada em STG Sem Mexer em `main`

Se o `ts-shared` depende de `ts-logger@2.2.1` mas essa versao ainda nao esta em Nexus STG:

1. Voce **nao precisa** cortar nova release de `ts-logger`.
2. Use um **branch efemero** do repo `ts-logger`, criado da tag `2.2.1`, com workflow de validacao em staging `version: '2.2.1'` hardcoded.

> **Modo agentico vs humano**: a receita abaixo cria branch efemera e abre PR num repo **diferente** do repo-alvo da migracao. Quando executando em modo agentico (workflow Temporal `KaravelaPackageMigrationWorkflow`, ver `.specs/features/agentic-package-migration/`), criar branches em repos nao-target precisa de **confirmacao do orchestrator** (workflow filho ou aviso humano) — o agente nao deve abrir branches/PRs em repos terceiros sem sinal explicito. No modo interativo (Claude Code / kli), o usuario aprova manualmente cada PR antes do agente abrir. Em ambos os modos, a tecnica de branch-de-tag e a mesma; o que muda e o gating de "tem autorizacao pra tocar este repo?".

### Receita

```bash
cd <repo-da-lib>   # ex: ts-logger
git fetch --tags origin
git checkout -b chore/publish-<V>-to-karavela-stg <V>     # ex: 2.2.1
```

Adicione um workflow de staging com versao hardcoded:

```yaml
# .github/workflows/karavela_packages_publish_staging.yaml
name: Karavela Packages Publish (Staging)

on:
  pull_request:
    branches:
      - master   # ou main, conforme o repo

permissions:
  contents: read
  id-token: write
  attestations: write

jobs:
  publish:
    uses: stone-payments/karavela-packages-workflows/.github/workflows/karavela_packages_publish.yml@develop
    with:
      ecosystem: 'npm'
      owner_group: '<time>'
      work_dir: '.'
      version: '2.2.1'                              # ← HARDCODED
      environment: 'stg'
      test_tag: 'pr-${{ github.event.pull_request.number }}'
    secrets: inherit
```

```bash
git add .github/workflows/karavela_packages_publish_staging.yaml
git commit -m "ci: publish <V> to Karavela staging"
git push -u origin chore/publish-<V>-to-karavela-stg
gh pr create --title "ci: publish <V> to Karavela staging" --body "Publica $V em STG pra desbloquear migracao de <consumer>. Nao mergear — descartar apos publicacao."
```

A PR dispara o workflow. Apos confirmar que `2.2.1` aparece em `packages-stg.stone.tech/repository/npm-group/@stone-payments/<lib>`, **feche a PR sem mergear**. O `test_tag: pr-<N>` garante auto-cleanup via TTL no Nexus STG.

### Por que branch-de-tag e nao cherry-pick no `main`

- O codigo da versao `V` **ja esta estavel** naquela tag. Voce nao quer forkar codigo, so redistribuir o artefato.
- Cherry-picking o workflow para `main` do repo da lib tem o risco de disparar publish PRD se alguem fizer release logo depois.
- Branch descartavel e limpo: commit so de CI, nao mergea, nao afeta historico do `main`.

### Caso use monorepo e so um modulo depende

Se `ts-shared` depende de `@stone-payments/ts-logger@2.2.1` mas `ts-logger@3.0.0` ja esta em STG, basta bump de pin:

```diff
-    "@stone-payments/ts-logger": "2.2.1"
+    "@stone-payments/ts-logger": "3.0.0"
```

Isso muda o scope da PR de "migracao" para "bump + migracao". Decida se o risco de bump justifica (mudancas de API, breaking changes) ou se a branch-de-tag e mais conservadora.

## Como Detectar Cascata na Fase 0

Durante a descoberta do terreno:

```bash
# grep por deps internas no repo-alvo
grep -r "@stone-payments/" packages/*/package.json   # monorepo
grep "@stone-payments/" package.json                 # simples

# Go: deps internas sao module paths no go.mod (NAO @stone-payments/)
grep -r "github.com/stone-payments/" --include=go.mod .   # monorepo (varios go.mod)
grep "github.com/stone-payments/" go.mod                  # simples
```

Para cada dep encontrada, verifique em STG:

```bash
curl -sS "https://packages-stg.stone.tech/repository/npm-group/@stone-payments/<lib>" \
  | python3 -c "import json,sys; print(list(json.load(sys.stdin).get('versions',{}).keys()))"
```

Se a versao pinada **nao** estiver listada, a cascata e inevitavel antes de prosseguir.

## Lista de Dependencias vs. Grafo

Se houver mais de 2 niveis de dependencia entre libs internas, monte o grafo antes. O custo de migrar fora de ordem e alto (voce so descobre ao falhar no `yarn install` do consumer).

Ferramenta simples: `@stone-payments/*` no `package.json` root de cada repo e parsers equivalentes para pypi/nuget/maven. Para **Go**, o parser olha as linhas `require github.com/stone-payments/...` do `go.mod` (e `go list -m all` resolve transitivas se o GOPROXY estiver cabeado). Script que gera Mermaid de 30 linhas resolve.

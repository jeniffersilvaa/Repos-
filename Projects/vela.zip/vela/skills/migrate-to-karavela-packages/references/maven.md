# Migracao para Karavela Packages — Maven / Gradle

## Manifesto

### Maven (`pom.xml`)

Versao seed `0.1.0`:

```xml
<project xmlns="http://maven.apache.org/POM/4.0.0">
  <modelVersion>4.0.0</modelVersion>
  <groupId>co.stone</groupId>
  <artifactId>meu-pacote</artifactId>
  <version>0.1.0</version>
  <packaging>jar</packaging>
</project>
```

### Gradle (`build.gradle.kts`)

```kotlin
plugins {
    `java-library`
    `maven-publish`
}

group = "co.stone"
version = "0.1.0"
```

Portal normaliza: `groupId` vira `co.stone`, `artifactId` vira `{kebab-case}`. Ja comece com o formato canonico para evitar confusao.

## Apontar Maven/Gradle para STG Nexus

### `settings.xml` (Maven)

Em `~/.m2/settings.xml` (ou customizado via `-s settings.xml`):

```xml
<settings>
  <mirrors>
    <mirror>
      <id>karavela-stg</id>
      <name>Karavela Staging</name>
      <url>https://packages-stg.stone.tech/repository/maven-group/</url>
      <mirrorOf>*</mirrorOf>
    </mirror>
  </mirrors>
</settings>
```

**`<mirrorOf>*</mirrorOf>`** roteia tudo pelo Nexus — inclusive dependencias Maven Central, via proxy. Se quiser manter Maven Central direto e so rotear `co.stone`:

```xml
<mirrorOf>external:*,!central</mirrorOf>
```

### `build.gradle.kts` (Gradle)

```kotlin
repositories {
    maven {
        url = uri("https://packages-stg.stone.tech/repository/maven-group/")
    }
    mavenCentral()
}
```

Ordem importa: o primeiro registry listado e consultado primeiro. Colocar Karavela antes garante que `co.stone:*` resolve de la.

## Lockfile

**Maven**: nao tem lockfile nativo. Versoes sao resolvidas pela arvore de dependencias em tempo de build. Sem cirurgia necessaria.

**Gradle**: `gradle.lockfile` (opt-in via `dependencyLocking { lockAllConfigurations() }`). Se existir:

```bash
find . -name 'gradle.lockfile' -delete
./gradlew dependencies --write-locks
```

Isso regenera contra o registry atual. Gradle lockfile **nao pineia URL**, so coordenadas + hash — regeneracao e segura, nao bumpa transitivas se voce nao passar `--refresh-dependencies` e as versoes declaradas sao estritas.

## SNAPSHOT vs Release

Nexus tem dois repos:

- `maven-releases` — versoes estaveis (`1.2.3`)
- `maven-snapshots` — versoes em desenvolvimento (`1.2.3-SNAPSHOT`)

O reusable detecta automaticamente: se a versao termina em `-SNAPSHOT`, roteia para `maven-snapshots`; senao para `maven-releases`. Ver action `publish-package` em `karavela-packages-workflows`.

**Em migracao**: se o registry antigo aceitava `-SNAPSHOT` (comum em Artifactory interno), mantenha o fluxo — Karavela tambem aceita. Se nunca usou SNAPSHOT, so publique versoes finais.

## Dual-Write com Artifactory / GitHub Packages Maven

### Maven (`pom.xml`)

```xml
<distributionManagement>
  <repository>
    <id>legacy</id>
    <url>https://artifactory.interno.stone.tech/repository/maven-releases/</url>
  </repository>
</distributionManagement>
```

E dois jobs em paralelo (ver `references/dual-write.md` pattern geral):

```yaml
publish-legacy:
  needs: release-please
  if: needs.release-please.outputs.release_created == 'true'
  runs-on: small-runner
  steps:
    - uses: actions/checkout@v4
      with: { ref: '${{ needs.release-please.outputs.tag_name }}' }
    - uses: actions/setup-java@v4
      with: { distribution: 'temurin', java-version: '21' }
    - run: mvn deploy -DskipTests -s settings-legacy.xml

publish-karavela:
  needs: release-please
  if: needs.release-please.outputs.release_created == 'true'
  uses: stone-payments/karavela-packages-workflows/.github/workflows/karavela_packages_publish.yml@main
  with:
    ecosystem: maven
    owner_group: <time>
    version: ${{ needs.release-please.outputs.version }}
    work_dir: '.'
  secrets: inherit
```

### Gradle (`build.gradle.kts`)

```kotlin
publishing {
    repositories {
        maven {
            name = "legacy"
            url = uri("https://artifactory.interno.stone.tech/repository/maven-releases/")
            credentials {
                username = System.getenv("LEGACY_USERNAME")
                password = System.getenv("LEGACY_PASSWORD")
            }
        }
        // Karavela e configurado pelo reusable via -PkaravelaRepoUrl
    }
}
```

O reusable injeta `-PkaravelaRepoUrl`, `-PkaravelaUsername`, `-PkaravelaPassword` no `./gradlew publish`. Seu `build.gradle.kts` so precisa declarar o publishing do legado — o da Karavela e autoconfigurado.

## Multi-Module

### Maven

```xml
<modules>
  <module>core</module>
  <module>http</module>
  <module>kafka</module>
</modules>
```

O reusable roda `mvn deploy` no POM pai, que propaga para cada modulo. Todos com `<version>` herdado viram artefatos no mesmo publish.

### Gradle

```kotlin
// settings.gradle.kts
include(":core", ":http", ":kafka")
```

`./gradlew publish` resolve o grafo e publica cada submodulo. O `override-version` do reusable faz `sed` em `build.gradle.kts`/`build.gradle` de cada modulo.

## Armadilhas

### `mavenLocal()` cache antigo

Se o repo tinha `mavenLocal()` primeiro em `repositories {}`, o Gradle pode resolver versoes antigas de `~/.m2/repository/`. Remover e ignorar o cache no CI:

```bash
rm -rf ~/.m2/repository/co/stone
./gradlew build --refresh-dependencies
```

### `<mirrors>` sobrescreve `<repositories>`

Se `settings.xml` tem `<mirror><mirrorOf>*</mirrorOf></mirror>`, **todas** as dependencias passam pelo mirror, ignorando `<repositories>` no POM. Util durante migracao para forcar Nexus, mas derruba Maven Central se o `mirrorOf` for muito largo.

Regra: use `external:*` ou `external:*,!central` se quiser manter Central direto.

### Assinatura GPG

Alguns registries antigos exigem assinatura GPG (`<gpg.passphrase>`, plugin `maven-gpg-plugin`). Karavela **nao exige**. Se a migracao manteve o plugin ativo no POM, ele ainda roda e demanda `GPG_PRIVATE_KEY` secret — desative o plugin para o profile Karavela ou torne opcional via `<skip>`.

### `gradle.properties` commitado com credenciais

Revise `gradle.properties` — se tiver `karavelaUsername=` ou `legacyPassword=` hardcoded, remova imediatamente. Migracao usa OIDC; em CI, variaveis vem dos secrets injetados pelo reusable.

### Jitpack como registry resolvido historicamente

Projetos legados que usaram Jitpack (`https://jitpack.io`) como proxy para GitHub tags: Karavela nao substitui isso. Se o pacote e consumido via Jitpack, use dual-write para manter Jitpack ativo enquanto consumidores migram para Karavela.

### `SNAPSHOT` timestamp collision

Publicar `1.2.3-SNAPSHOT` multiplas vezes gera timestamps unicos no Nexus (`1.2.3-20260423.123456-1`). Consumer pode cachear a versao antiga. Forca refresh: `mvn -U` ou `./gradlew --refresh-dependencies`.

# Migracao para Karavela Packages — `build_command` Custom

## Regra de Ouro

Quando o input `build_command` do reusable workflow e setado, o action `build-package` executa **so** o comando custom e sai imediatamente com `exit $?`. Ele **nao cai no switch default** do ecossistema, ou seja, **nao roda `npm pack` / `python -m build` / `dotnet pack` / `mvn package`**.

Se voce nao gerar o tarball explicitamente dentro do `build_command`, o step seguinte (`publish-package`) falha com `ENOENT` procurando `*.tgz`.

## Sintoma

No log do step `Publish package` (interno ao reusable):

```
npm warn tarball tarball data for file:*.tgz (null) seems to be corrupted. Trying again.
npm error code ENOENT
npm error path /home/runner/_work/<repo>/<repo>/*.tgz
npm error errno -2
npm error enoent ENOENT: no such file or directory, open '...*.tgz'
Error: Process completed with exit code 254.
```

## Solucao

Adicione o pack no fim do `build_command`:

| Ecossistema | Adicione ao fim | Referencia |
|---|---|---|
| npm (bun, yarn, pnpm, npm) | `&& npm pack` | `bun.md` (para bun especificamente) |
| pypi | `&& python -m build` (ou `&& pip install build && python -m build`) | `pypi.md` |
| nuget | `&& dotnet pack -c Release -o ./dist` | `nuget.md` |
| maven | `&& mvn package -DskipTests` | `maven.md` |
| go | **N/A — Go nao gera tarball** | `go.md` |

> **Go nao se encaixa neste arquivo.** Go é source-only: o "publish" é o protocolo GOPROXY (PUT de `.info`/`.mod`/`.zip`/`list` no `go-hosted`), gerado pelo step `generate-goproxy-artifacts` — **não há `go build`, não há tarball, e não existe o sintoma `ENOENT '*.tgz'`**. O framing inteiro deste arquivo (custom `build_command` pula o pack → falta `*.tgz`) **não transfere pra Go**. Se um repo Go precisa de etapa de geração customizada, isso é territorio de `go.md`, não de `build_command` com `&& <pack>`.

Exemplo bun completo:

```yaml
with:
  ecosystem: 'npm'
  build_command: 'bun install --frozen-lockfile && bun run build && npm pack'
```

**`npm pack` funciona mesmo em projetos bun**: `npm` esta no runner do Karavela (via setup-node do `setup-ecosystem`). Usar `npm pack` para gerar o tarball e mais estavel que `bun pm pack` (a CLI do bun pm varia entre versoes).

## Quando Nao Usar `build_command`

Se o reusable tem caminho nativo para o seu PM:

- `yarn.lock` presente → caso `yarn)` detecta automaticamente
- `pnpm-lock.yaml` presente → caso `pnpm)` idem
- `package-lock.json` presente → caso `npm)` idem
- `bun.lock` / `bun.lockb` presente **e** o reusable ja tem suporte bun nativo → caso `bun)` idem (ver `bun.md`)
- `pyproject.toml` com `[tool.uv.workspace]` → monorepo pypi detectado
- `*.sln` na raiz → nuget detectado
- Gradle `include(...)` → maven detectado
- `go.mod` presente → caso `go)` detecta automaticamente (gera os artefatos GOPROXY, **sem** `build_command` e **sem** tarball)

Nesses casos, **nao passe `build_command`**. O action faz install + build + pack sozinho. Passar `build_command` so para "ter certeza" quebra o pack default e voce vai reintroduzir o bug acima.

## Como Descobrir Que Voce Esta Nesse Problema

Dois sinais no log:

1. Step "Build package" completa com exit 0
2. Step seguinte ("Publish package") falha com `ENOENT '*.tgz'`

Se entre os dois steps houver um `Collect published modules` que lista zero entradas, confirma. O `filter-already-published` nao encontrou tarball pra filtrar.

## Armadilha Inversa: Pack Duplicado

Se voce passa `build_command` **e** o reusable tem path nativo para o ecossistema, voce NAO vai ter pack duplicado (porque o action sai apos o custom). Mas se for voce mesmo que esta customizando o reusable e adicionando `bun pack` + `npm pack` dentro do mesmo branch, cuidado: dois tarballs com o mesmo nome, o ultimo vence.

Boas praticas ao escrever o caso nativo de um PM novo no reusable: **uma unica geracao de tarball por modulo**.

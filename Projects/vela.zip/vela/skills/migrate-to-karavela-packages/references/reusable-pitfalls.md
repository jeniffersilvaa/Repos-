# Migracao para Karavela Packages — Armadilhas do Reusable Workflow

Este arquivo lista comportamentos nao-obvios do `karavela_packages_publish.yml` e das composite actions em `karavela-packages-workflows`, que surgem **durante uma migracao** (vs publishes rotineiros).

## 1. `version:` faltando no workflow de PRD

**Sintoma**: workflow PRD passa, mas publica com versao `0.0.0`, `0.0.1`, ou `2.2.0` em vez da tag.

**Causa**: `version` e opcional no reusable. Se omitido, o step `override-version` e skippado e o manifesto preserva a versao seed.

**Correto**:

```yaml
with:
  version: ${{ github.ref_name }}
```

`github.ref_name` resolve para o nome da tag (`v1.2.3` / `v1.2.3-rc.1`) nos triggers `release: [published]` e `push: tags:`. O reusable remove o prefixo `v` automaticamente.

**No STAGING, passe uma versao descartavel UNICA por rodada** (correcao vs. orientacao antiga de "omitir version no staging"):

```yaml
with:
  version: '0.0.0-pr${{ github.event.pull_request.number }}.${{ github.run_number }}'
```

Dois motivos pra **não** omitir:

1. **Idempotencia de re-run.** Omitir `version` publica a versao **seed** do manifesto (ex: `0.0.0`). No primeiro run publica; no segundo (corrigiu algo, re-rodou a PR) o Nexus rejeita com `409` / "versao ja publicada". `${{ github.run_number }}` dá versao nova a cada rodada → re-run sempre verde.
2. **Go exige semver.** Em Go a versao vem da tag git; numa PR não há tag, então sem `version` o reusable cai no **SHA do commit** (ex: `dca2530`) — não é semver válido e quebra o `list` do `go-hosted`: `Merged list is empty after merging local list with remote (corruption?)`.

Formato por ecossistema (a versao é só um rótulo descartável; o `test_tag` garante o TTL):

| Ecossistema | `version` no staging |
|---|---|
| npm / nuget / maven | `0.0.0-pr<N>.<run_number>` |
| Go | `v0.0.0-pr<N>.<run_number>` (preserva o `v`) |
| PyPI | `0.0.0.dev<run_number>` (PEP 440 não aceita `-pr`) |

## 2. Branch default nao e `main`

**Sintoma**: workflow de staging (`on: pull_request: branches: [main]`) nunca dispara, porque o repo usa `master` como default.

**Correto**: cheque sempre:

```bash
git -C <repo> symbolic-ref refs/remotes/origin/HEAD
```

E ajuste `branches:` no filter do `pull_request:`.

## 3. `@develop` do caller NAO propaga para sub-actions

**Sintoma**: voce chama o reusable via `@develop` esperando comportamento novo; o reusable aparentemente ignora a mudanca.

**Causa**: o proprio `karavela_packages_publish.yml` chama **todas** as sub-actions hardcoded em `@main` — confirmado em `@main` (2026-05-14) via `grep -nE "uses: stone-payments/karavela-packages-workflows/actions" karavela-packages-workflows/.github/workflows/karavela_packages_publish.yml`:

```yaml
- uses: stone-payments/karavela-packages-workflows/actions/setup-ecosystem@main
- uses: stone-payments/karavela-packages-workflows/actions/build-package@main
- uses: stone-payments/karavela-packages-workflows/actions/override-version@main
- uses: stone-payments/karavela-packages-workflows/actions/detect-package-metadata@main
- uses: stone-payments/karavela-packages-workflows/actions/detect-workspace-modules@main
- uses: stone-payments/karavela-packages-workflows/actions/karavela-call-plan@main
# ...e ~30 outras chamadas, todas `@main`
```

Se a mudanca que voce quer testar esta num action (ex: suporte bun em `setup-ecosystem` e `build-package`), ela **nao estara** ativa mesmo que voce chame o reusable via `@develop` — as sub-actions continuam em `@main`. **Nao** ha uso de `${{ github.action_ref }}` ou template equivalente no caller — refs sao literais.

**Caminhos**:

1. Mergear a mudanca em `main` do `karavela-packages-workflows` logo apos validar em `develop`.
2. Temporariamente, para debug: fork local do reusable com ref `@develop` nas sub-actions tambem. Nao ofereca isso como permanente — quebra paralelismo com consumers que usam `@main`.
3. Se o bug esta num action, abrir PR so contra esse action e usar o `test.yml` do proprio repo workflows para validar.

## 4. `hashFiles()` falha silenciosamente em arquivos binarios (e em composite actions)

**Sintoma**: step com `if: hashFiles('**/foo') != ''` nao dispara, mesmo com o arquivo presente. Caso canonico: `hashFiles('**/bun.lockb')` retornando string vazia consistentemente, fazendo o branch de Bun nunca ativar (ver STATE.md L-010, fonte canonica).

**Causa**: `hashFiles` tem problemas com **arquivos binarios** (sem newline final / charset nao-UTF8) — esse e o root cause documentado no L-010 para o bug do `bun.lockb`. Em composite actions ha ainda um agravante: `hashFiles` usa o contexto da composite, nao do workflow chamador, e patterns relativos se comportam inconsistente. As duas categorias compoem: a recomendacao abaixo cobre ambas.

**Correto**: use bash check explicito com `$GITHUB_OUTPUT`:

```yaml
- name: Detect X
  id: detect
  shell: bash
  run: |
    if [ -f "foo.lock" ]; then
      echo "has_x=true" >> "$GITHUB_OUTPUT"
    else
      echo "has_x=false" >> "$GITHUB_OUTPUT"
    fi

- name: Do X
  if: steps.detect.outputs.has_x == 'true'
  uses: ...
```

Vantagens: loga a decisao, debugavel, sem surpresa de expression.

## 5. `build_command` custom pula `npm pack` default

Ver [build-command.md](build-command.md). Resumo: adicionar `&& npm pack` no fim do `build_command`.

**Go herda o handling de [build-command.md](build-command.md): sem tarball.** Go publica via GOPROXY (não gera `*.tgz`), então o sintoma `ENOENT '*.tgz'` não aparece — ver `go.md`. Os itens 1–4 e 6–10 deste arquivo aplicam **inalterados** a Go (com a ressalva do item 1 abaixo: em Go a versão vem da tag, não há seed).

## 6. `secrets: inherit` e obrigatorio

**Sintoma**: step de `Get OIDC token` ou `plan` falha com `OIDC response has no .value field`.

**Causa**: o reusable precisa de `id-token: write` no job chamador **e** de acesso a secrets/vars da org. Sem `secrets: inherit`, o reusable nao recebe `KARAVELA_PACKAGES_PORTAL_TOKEN`, `KARAVELA_PACKAGES_PUBLISH_*`, etc.

**Correto**:

```yaml
jobs:
  publish:
    permissions:
      contents: read
      id-token: write
      attestations: write
    uses: stone-payments/karavela-packages-workflows/.github/workflows/karavela_packages_publish.yml@main
    with:
      ...
    secrets: inherit   # ← nao esquecer
```

## 7. Fork bloqueia OIDC

**Sintoma**: PR de contribuidor externo passa o `checkout` mas falha no OIDC.

**Causa**: GitHub Actions desabilita `id-token: write` em PRs de fork por padrao (contra abuse).

**Mitigacao**: workflows de migracao em repos com fork PRs devem gate por origem:

```yaml
jobs:
  publish:
    if: github.event.pull_request.head.repo.full_name == github.repository
    # ...
```

Ou exigir PRs so de branches internas.

## 8. `--force-with-lease` apos rebase do branch de migracao

**Sintoma**: voce faz rebase do branch de migracao sobre `main` (para atualizar com mudancas recentes), e o push e rejeitado com `non-fast-forward`.

**Correto**:

```bash
git push --force-with-lease
```

`--force-with-lease` falha seguro se o remote avancou desde seu ultimo fetch. Nunca use `-f` / `--force` puro em branches com PR aberta — atropela revisoes ou commits que alguem possa ter pushed.

## 9. Ordem de execucao dos commits apos rebase complexo

Se a migracao envolveu varios commits (setup-lib, staging, fix-bun, etc.), o rebase pode reordenar e quebrar dependencia semantica. Resolva editando os commits na ordem certa (`GIT_SEQUENCE_EDITOR` para scripted rebase), ou faca squash quando fizer sentido — uma PR de migracao mergeada geralmente fica mais limpa com 1-3 commits.

## 10. Workflow de staging e prd com paths de arquivo diferentes

**Staging**: `karavela_packages_publish_staging.yaml`
**PRD**: `karavela_packages_publish.yaml`

Ambos com **extensao `.yaml`** (quatro letras), nao `.yml`. Convencao dessa skill pra bater com o skeleton do template Backstage. Se o repo ja usa `.yml` em outros workflows, pode usar `.yml` — mas pick one e seja consistente.

O `uses:` remoto usa `.yml@main`:

```yaml
uses: stone-payments/karavela-packages-workflows/.github/workflows/karavela_packages_publish.yml@main
```

**Errar essa extensao (`.yaml@main`)** → `workflow not found`, sem opcao de recovery — e fixo no upstream.

## 11. npm sem lockfile → `npm ci` falha com `EUSAGE`

**Sintoma**: no ecossistema npm, o build falha logo no install:

```
npm error code EUSAGE
npm error The `npm ci` command can only install with an existing package-lock.json or
npm error npm-shrinkwrap.json with lockfileVersion >= 1.
```

**Causa**: o `build-package` do reusable usa **`npm ci`** (install determinístico), que **exige** `package-lock.json` (ou `npm-shrinkwrap.json`). Repos que sempre publicaram via outro fluxo (ou nunca instalaram em CI) podem **não ter lockfile** versionado.

**Correto**: gere e comite o lockfile **na mesma PR de migração**, offline, sem reflorestar transitivas:

```bash
cd <work_dir>            # ex: npm-demo
npm install --package-lock-only
git add package-lock.json
```

`--package-lock-only` escreve o `package-lock.json` **sem** baixar nada nem tocar `node_modules` — para um pacote sem deps, o lockfile é mínimo (só o root). Confirme que o `.gitignore` não está ignorando `package-lock.json` (`git check-ignore package-lock.json`).

> Isto é **diferente** de `lockfile-surgery.md`: lá o lockfile **existe** e precisa virar registry-agnostic; aqui ele **não existe** e precisa ser criado.

## 12. Release/tag criado por bot (`GITHUB_TOKEN`) NÃO dispara o workflow de PRD

**Sintoma**: o workflow de PRD (`on: release: [published]` / `push: tags:`) **nunca roda**, mesmo havendo releases/tags novas no repo. Os artefatos não aparecem em `packages.stone.tech`.

**Causa**: o repo cria releases/tags **automaticamente por um bot** — tipicamente um `auto-release.yml` que roda `gh release create` / `git push <tag>` no push→`main` usando `secrets.GITHUB_TOKEN`. **Eventos disparados pelo `GITHUB_TOKEN` não disparam outros workflows** (proteção anti-recursão do GitHub Actions, [docs](https://docs.github.com/actions/security-guides/automatic-token-authentication#using-the-github_token-in-a-workflow)). Então um workflow de PRD **dedicado, baseado em trigger**, fica inerte.

**Detecte na Fase 0**: existe workflow que cria release/tag sozinho? Com qual token?

**Correto (preferido) — publique inline no mesmo fluxo que já roda.** Em vez de um workflow separado por trigger, chame o reusable **dentro** do `auto-release.yml`, no mesmo `push→main`, como job(s) independentes (dual-write com o legado). Uma fonte única de versão por módulo (job `versions`) alimenta os dois destinos:

```yaml
# auto-release.yml (push→main), por módulo, dual-write inline
permissions:
  contents: write
  packages: write
  id-token: write       # OIDC do reusable
  attestations: write

jobs:
  detect: { ... }       # paths-filter: quais módulos mudaram

  versions:             # fonte ÚNICA da versão por módulo (bump de patch da última tag)
    needs: detect
    runs-on: ubuntu-latest
    outputs: { npm: '${{ steps.c.outputs.npm }}' }   # ...um por módulo
    steps: [ ... ]

  npm:                  # destino legado (GH Packages) — consome needs.versions
    needs: [detect, versions]
    if: needs.detect.outputs.npm == 'true'
    # ... npm publish ...

  npm-karavela:         # destino Karavela — independente, MESMA versão
    needs: [detect, versions]
    if: needs.detect.outputs.npm == 'true'
    uses: stone-payments/karavela-packages-workflows/.github/workflows/karavela_packages_publish.yml@main
    with:
      ecosystem: 'npm'
      owner_group: '<time>'
      work_dir: 'npm-demo'
      version: ${{ needs.versions.outputs.npm }}
      # test_tag: 'demo'   # só se for repo demo
    secrets: inherit
```

Notas:

- **Fonte única de versão.** Não recompute a versão dentro de cada job — corre risco de divergir (um job cria a tag, o outro lê a tag nova e bumpa de novo). Compute uma vez no job `versions` e ambos consomem.
- **Go inline**: passe `version: v${{ needs.versions.outputs.go }}` (preserva o `v`).
- **Sem disparo duplo**: as tags pushadas pelos jobs legados usam `GITHUB_TOKEN` → **não** disparam os `*-release.yml` legados (a mesma anti-recursão joga a favor aqui).
- **Fase 5 muda**: não há "release manual pela UI" — o publish acontece no merge para `main` que toca um módulo. Não há workflow de staging dedicado para remover se você validou via PR de outro jeito.

**Alternativas**: (a) criar a release/tag com **GitHub App token / PAT** em vez do `GITHUB_TOKEN` (o evento passa a propagar; estreite o trigger para um evento só, evitando tag + release duplicando); (b) **release manual pela UI** por um humano (dispara, mas quebra a automação — só para demo/pontual).

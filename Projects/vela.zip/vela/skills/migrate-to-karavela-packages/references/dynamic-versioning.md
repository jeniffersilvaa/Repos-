# Versionamento dinamico (computado fora do manifesto)

A skill mostra `version: ${{ github.ref_name }}` como caminho **canonico** porque cobre 95% dos casos: tag manda. Mas o reusable `karavela_packages_publish.yml` aceita **qualquer string** no input `version:` — quer dizer que o ecossistema do repo pode estar usando uma estrategia de versionamento **dinamica** (computada por uma ferramenta externa via grafo git, branch, ou metadata) e o caminho de migracao precisa preservar isso. Forcar tag-only num repo que ja usa, por exemplo, `Nerdbank.GitVersioning` (nbgv) **quebra o contrato de versao** que os consumidores ja conhecem.

Este documento descreve como detectar a estrategia em uso, como passar o resultado para o reusable, e os caveats em **single vs. monorepo** para os quatro ecossistemas suportados (npm, pypi, nuget, maven).

## O contrato do reusable

`karavela_packages_publish.yml` chama uma action interna `override-version` apenas quando `inputs.version != ''`:

| Ecossistema | O que `override-version` faz | Cobertura monorepo |
|---|---|---|
| npm | `npm version <V> --no-git-tag-version` (sem `--workspaces`) ou com `--workspaces` em monorepos | Sim — yarn/pnpm/npm + workspaces |
| pypi | `sed` em todos os `pyproject.toml` encontrados | Sim — uv workspace, poetry, monorepo |
| nuget | `sed` nos `.csproj` (ajusta `<Version>` ou `<PackageVersion>` em `Directory.Build.props` / `Directory.Packages.props`) | Sim — `.sln` com varios projetos |
| maven | `gradle versions:set` / `mvn versions:set` | Sim — multi-module Gradle / Maven |
| go | **N/A — `override-version` é no-op pra Go** (não reescreve manifesto, **preserva o `v`**) | Sim — 1 publish por (módulo, tag `module/vX.Y.Z`) |

E uma regra universal **para npm/pypi/nuget/maven**: o prefixo `v` e **strippado** (`v1.2.3` → `1.2.3`). **Go é a exceção**: o `v` é **preservado** (faz parte do nome de arquivo GOPROXY — `v1.2.3.info`/`.mod`/`.zip`), e o `go.mod` não tem campo `version` pra reescrever.

**Conclusao operacional pra migracao:** se o repo ja produz uma versao via ferramenta externa, voce **nao** precisa mexer no manifesto. Basta computar a versao antes do job que chama o reusable e passar pelo `version:`.

## Tres estrategias possiveis num repo em migracao

Antes de propor mudancas, identifique em qual o repo esta hoje. Misturar duas e o erro classico que gera "publica no Nexus a versao seed `0.0.0`" descrito em [reusable-pitfalls.md](reusable-pitfalls.md).

### Estrategia 1 — Tag canonica (caminho default da skill)

```yaml
version: ${{ github.ref_name }}
```

Aplicavel quando:
- Repo nao tem ferramenta de versionamento dinamico.
- Workflow ja dispara em `release: [published]` ou `push: tags:`.
- O time controla versao manualmente via tag GitHub.

Manifesto fica numa **versao seed** (`0.0.0`, `0.0.1`, `0.1.0`); a tag manda.

> **Go encaixa na Estratégia 1 nativamente — e é o encaixe mais limpo dos cinco ecossistemas.** Go é tag-driven por design da própria linguagem: a versão de um módulo **é** a tag git (`v` preservado), e o `go.mod` não tem campo `version`. Não existe **classe de tooling dinâmico em Go** — não há nbgv/GitVersion/setuptools-scm/poetry-dynamic-versioning equivalente que reescreva o manifesto. Consequências pra migração:
> - **Override-version pra Go = N/A.** Você não passa `version:` esperando um rewrite do manifesto; o `override-version` é no-op (preserva `v`, não toca em arquivo). A versão sempre deriva da tag (`module/vX.Y.Z` em monorepo).
> - **Única ressalva — pseudo-versions.** Quando um consumidor referencia um commit sem tag, Go sintetiza `v0.0.0-<timestamp>-<sha>` (pseudo-version). Não é versionamento dinâmico de publish (você não publica pseudo-versions de propósito), mas aparece em `go.mod`/`go.sum` de quem consome um untagged ref. `fetch_depth: 0` (`fetch-depth: 0` no checkout) ajuda o `go list -m` a resolver pseudo-versions corretamente, já que precisa do histórico.

### Estrategia 2 — Versao computada externamente

```yaml
jobs:
  compute-version:
    runs-on: small-runner
    outputs:
      version: ${{ steps.calc.outputs.version }}
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0      # ferramenta geralmente precisa do grafo
      - id: calc
        # ...nbgv | gitversion | setuptools_scm | poetry-dynamic-versioning...
        run: echo "version=$(my-tool --json | jq -r .ver)" >> "$GITHUB_OUTPUT"

  publish:
    needs: compute-version
    uses: stone-payments/karavela-packages-workflows/.github/workflows/karavela_packages_publish.yml@main
    with:
      ecosystem: <eco>
      owner_group: <grupo>
      version: ${{ needs.compute-version.outputs.version }}
      fetch_depth: 0          # o job interno tambem precisa do grafo p/ build
    secrets: inherit
```

Aplicavel quando:
- Repo ja roda `nbgv` / `GitVersion` / `setuptools-scm` / `poetry-dynamic-versioning` / `gradle-git-version` hoje.
- Versao depende de altura de commit, branch, ou metadata git.
- Manter contrato com consumidores (mudar de versao computada para tag canonica e breaking).

**Imprescindivel passar `fetch_depth: 0`** no input do reusable quando o build em si tambem precisa reler o grafo git pra reconstruir a versao (nbgv injeta no `dotnet pack`, setuptools-scm injeta no `python -m build`, etc.).

Exemplo concreto NuGet com nbgv: ver [`examples/nuget-nbgv.yml`](https://github.com/stone-payments/karavela-packages-workflows/blob/main/examples/nuget-nbgv.yml) no `karavela-packages-workflows`.

### Estrategia 3 — Omitir `version:` (publica o que esta no manifesto)

```yaml
# Sem `version:` no with:
```

Aplicavel quando:
- Repo bumpa a versao no `package.json` / `pyproject.toml` / `.csproj` via PR antes de cada release (Changesets, semantic-release com `version:bump` step, etc.) e a tag e **apenas marca**.
- Quem dita a versao publicada e o manifesto, nao a tag.

Risco: se a tag dispara o workflow e o manifesto **nao foi** bumpado naquela PR, voce republica a mesma versao. O Nexus rejeita com 409 e o `confirm-onboarding` fica como `PUBLISH_FAILED`.

## Ferramentas dinamicas comuns por ecossistema

| Eco | Ferramentas | Onde a versao vive | Precisa de `fetch_depth: 0`? |
|---|---|---|---|
| npm | `changesets`, `semantic-release`, `auto`, `release-please`, `pnpm version`, scripts custom de `lerna`/`nx` | `package.json` (bump por PR), tag, ou output de step | `changesets`/`release-please`: nao (bump por PR) · `semantic-release`/`nbgv-port`: sim |
| pypi | `setuptools-scm`, `poetry-dynamic-versioning`, `versioneer`, `hatch-vcs`, `uv-dynamic-versioning` | Geralmente reconstruida no build a partir de tag + altura | Sim — o build em si reabre o grafo |
| nuget | `Nerdbank.GitVersioning` (nbgv), `GitVersion`, `MinVer` | `version.json` / `GitVersion.yml` na raiz; `dotnet pack` injeta | Sim — nbgv lê todo o historico |
| maven | `axion-release-plugin`, `gradle-git-version`, `versions-maven-plugin`, `jgitver` | `version` no `build.gradle.kts` injetado pelo plugin, ou `pom.xml` | Sim — plugin le tags |
| go | **nenhuma — Go é tag-driven nativo** (sem nbgv/GitVersion-equivalente) | A tag git **é** a versão (`module/vX.Y.Z`); `go.mod` não tem campo `version` | Só pra resolver **pseudo-versions** (`v0.0.0-<ts>-<sha>`) de refs sem tag |

Em qualquer caso (npm/pypi/nuget/maven) o padrao e o mesmo: **job upstream computa, job do reusable consome via `version:`**. **Go não tem esse padrão** — não há nada pra "computar": a tag já é a versão canônica, e não existe ferramenta que derive uma versão alternativa a partir do grafo.

## Caveats single vs monorepo

O reusable propaga `version:` para **todos** os pacotes publicaveis do repo:

| Estrutura | Comportamento | Implicacao p/ versao dinamica |
|---|---|---|
| npm simples | `npm version <V>` no `package.json` da raiz | OK — uma versao por release |
| npm workspaces / lerna / nx | `npm version <V> --workspaces` aplica a TODOS os pacotes nao-privados | Versao **uniforme** entre modulos. Se voce quer **versoes independentes**, ferramentas como `changesets` bumpam o manifesto pela PR e voce **omite** o `version:` (estrategia 3) |
| pypi uv workspace / monorepo | `sed` aplica em todos os `pyproject.toml` que casarem | Idem — uniforme |
| nuget multi-projeto (`.sln`) | `sed` em todos os `.csproj` ou em `Directory.Packages.props` se existir | nbgv com `version.json` por subdiretorio funciona — cada projeto tem altura propria. Mas voce passa **uma** version no `version:` do reusable; em monorepo nbgv-puro, prefira **um workflow por projeto** com `work_dir` diferente |
| maven multi-module Gradle | `gradle versions:set` aplica root + subprojects | Uniforme. Se voce precisa versoes independentes, considere splitting em repos distintos |

**Regra geral:** versionamento dinamico encaixa naturalmente em **single packages** e em **monorepos com versao uniforme**. Para monorepos com versoes independentes, o caminho mais limpo continua sendo bump-por-PR (estrategia 3) ou um workflow por modulo com `work_dir`.

## Como o agente reconhece a estrategia ao migrar

Na **Fase 0** (descobrir o terreno) inclua estes sinais:

| Arquivo / sintoma | Estrategia provavel |
|---|---|
| `version.json` na raiz, referencia a `Nerdbank.GitVersioning` em `Directory.Packages.props` | nbgv (NuGet) — Estrategia 2 |
| `GitVersion.yml` ou `GitVersion.yaml` na raiz | GitVersion (NuGet/.NET) — Estrategia 2 |
| `[tool.setuptools_scm]` ou `[tool.hatch.version] source = "vcs"` em `pyproject.toml` | setuptools-scm / hatch-vcs (PyPI) — Estrategia 2 |
| `[tool.poetry-dynamic-versioning]` em `pyproject.toml` | poetry-dynamic-versioning (PyPI) — Estrategia 2 |
| `axionRelease` ou `com.palantir.git-version` em `build.gradle.kts` | Gradle git-version (Maven/Gradle) — Estrategia 2 |
| `.changeset/` na raiz, `package.json` sem versao seed | changesets (npm) — Estrategia 3 |
| `release.config.js` / `.releaserc` | semantic-release (npm) — Estrategia 2 ou 3, dependendo da config |
| `package.json` com `version: "1.2.3"` cravada manualmente, tags conferem | Tag canonica (Estrategia 1) |
| `pyproject.toml` com `version = "0.1.0"` cravada manualmente, tags conferem | Tag canonica (Estrategia 1) |
| `go.mod` presente (com `module github.com/stone-payments/...`, **sem** campo `version`) | Tag canonica (Estrategia 1) — **sempre**, Go não tem outra opção; tag `vX.Y.Z` (ou `module/vX.Y.Z` em monorepo) é a versão |

Quando em duvida, **pergunte ao usuario** (modo interativo) ou **abra com `dry-run`** (modo agentico) para que um humano confirme antes da Surgery.

## Erro classico ao tentar migrar nbgv (e como evitar)

Sintoma: PR de migracao trocou `version:` para `${{ github.ref_name }}` "porque a skill mandou". Apos o merge, a primeira release publica `1.0.0` (vindo do `version.json`), nao a `1.0.42+abc1234` que o nbgv emitiria. Consumidores que pinavam por altura quebram.

Fix:
1. Restaurar `version:` para o output do job upstream (`needs.compute-version.outputs.version`).
2. Garantir `fetch_depth: 0` no input do reusable.
3. Verificar que o caller do reusable tambem fez `actions/checkout@v4 with: fetch-depth: 0` no job que computa (nbgv falha com `Repository is shallow` em fetch-depth: 1).

Test plan rapido: bumpe o `version.json` ou faca 2-3 commits, rode o workflow em staging, confirme que a versao publicada inclui a altura.

## Referencias externas

- Action `override-version` source: [actions/override-version/action.yml](https://github.com/stone-payments/karavela-packages-workflows/blob/main/actions/override-version/action.yml)
- Reusable workflow inputs: [karavela_packages_publish.yml](https://github.com/stone-payments/karavela-packages-workflows/blob/main/.github/workflows/karavela_packages_publish.yml)
- Exemplo NuGet com nbgv: [`examples/nuget-nbgv.yml`](https://github.com/stone-payments/karavela-packages-workflows/blob/main/examples/nuget-nbgv.yml)
- nbgv docs: https://github.com/dotnet/Nerdbank.GitVersioning
- setuptools-scm docs: https://setuptools-scm.readthedocs.io
- changesets docs: https://github.com/changesets/changesets

# Migracao para Karavela Packages — PyPI

## Manifesto (`pyproject.toml`)

Mantenha a versao seed (`0.0.1`) — a versao real e injetada via `version: ${{ github.ref_name }}` no workflow PRD:

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "meu-pacote"
version = "0.0.1"
description = "..."
requires-python = ">=3.11"
dependencies = []
```

Build-backends suportados sem mudanca: **hatchling**, **setuptools**, **poetry-core**, **flit-core**. Todos rodam via `python -m build` que o reusable ja faz.

O Portal publica como `{snake_case}` (ex: `meu-pacote` → `meu_pacote`). Voce nao precisa alterar o `name` no `pyproject.toml`.

## Apontar Package Manager para STG Nexus

Durante a validacao `environment: stg`, consumidores resolvem do Nexus STG. Pontos de ancoragem por ferramenta:

### uv (recomendado)

No `pyproject.toml`:

```toml
[[tool.uv.index]]
name = "karavela-stg"
url = "https://packages-stg.stone.tech/repository/pypi-group/simple/"
default = true
```

Ou via variavel de ambiente no CI:

```yaml
env:
  UV_DEFAULT_INDEX: "https://packages-stg.stone.tech/repository/pypi-group/simple/"
```

### pip / pip-tools

`pip.conf` local (em `~/.config/pip/` ou `./pip.conf` com `PIP_CONFIG_FILE=`):

```ini
[global]
index-url = https://packages-stg.stone.tech/repository/pypi-group/simple/
```

Ou flag:

```bash
pip install --index-url https://packages-stg.stone.tech/repository/pypi-group/simple/
```

### poetry

```toml
[[tool.poetry.source]]
name = "karavela-stg"
url = "https://packages-stg.stone.tech/repository/pypi-group/simple/"
priority = "primary"
```

## Lockfile Registry-Agnostic

### `uv.lock`

`uv` pineia `url = "..."` e `hash` (SHA-256) de cada artefato. Para virar registry-agnostic de um pacote `@stone-payments` interno, **remova** a linha `url = ...` dentro do bloco `[[package]]` alvo:

```toml
[[package]]
name = "stone-payments-ts-logger"
version = "2.2.1"
source = { registry = "https://..." }   # ← alterar para o registry atual
# url = "..."                           # ← remover se presente como campo solto
```

Apos editar, rode `uv lock --upgrade-package stone-payments-ts-logger` — o `uv` reresolve **so** esse pacote, mantendo o resto intacto.

**Nao use `uv lock --upgrade`** (sem o `-package`): reflorestа toda a arvore, bumpando transitivas.

### `poetry.lock`

`poetry.lock` agrupa URLs em `[[package.source]]`:

```toml
[[package]]
name = "stone-payments-ts-logger"
version = "2.2.1"
...
[package.source]
type = "url"
url = "https://npm.pkg.github.com/..."   # ← antigo
```

Estrategia: edite `[[tool.poetry.source]]` no `pyproject.toml` apontando para Nexus, e rode `poetry lock --no-update` (nao atualiza as versoes, so re-resolve URLs).

### `requirements.txt` compilado (pip-tools)

`pip-compile` emite URLs + hashes. Estrategia:

```bash
pip-compile --index-url https://packages-stg.stone.tech/repository/pypi-group/simple/ \
            --generate-hashes \
            --no-upgrade \
            requirements.in
```

`--no-upgrade` preserva versoes ja pinadas (crucial pra migracao cirurgica). Os hashes sao recomputados contra o Nexus porque o artefato e byte-identico so quando upstream — Nexus repacka apenas para npm/maven, pypi passa direto na maioria dos casos.

## Dual-Write com PyPI Publico (twine)

Ver `references/dual-write.md` para o pattern geral. Variacao pypi:

```yaml
publish-legacy:
  needs: release-please
  if: needs.release-please.outputs.release_created == 'true'
  runs-on: small-runner
  steps:
    - uses: actions/checkout@v4
      with: { ref: '${{ needs.release-please.outputs.tag_name }}' }
    - uses: actions/setup-python@v5
      with: { python-version: '3.11' }
    - run: pip install build twine
    - run: python -m build
    - env:
        TWINE_USERNAME: __token__
        TWINE_PASSWORD: ${{ secrets.PYPI_API_TOKEN }}
      run: twine upload dist/*

publish-karavela:
  needs: release-please
  if: needs.release-please.outputs.release_created == 'true'
  uses: stone-payments/karavela-packages-workflows/.github/workflows/karavela_packages_publish.yml@main
  with:
    ecosystem: pypi
    owner_group: <time>
    version: ${{ needs.release-please.outputs.version }}
    work_dir: '.'
  secrets: inherit
```

## Monorepo uv workspace

Detectado automaticamente pelo reusable quando o `pyproject.toml` root tem:

```toml
[tool.uv.workspace]
members = ["packages/*"]
```

E cada `packages/*/pyproject.toml` e publicavel (nao marcado como nao-distribuivel). O action `build-package` ja itera e roda `python -m build --sdist --wheel` por modulo.

**Path fixo confirmado em `@main` (2026-05-14)**: `actions/detect-workspace-modules/action.yml` itera literalmente `packages/*/` para detectar modulos pypi (e o mesmo vale para o caminho npm). Se seu repo usa `libs/*/`, `apps/*/`, ou qualquer outro layout, o reusable **nao detecta** — acionar `#help-foundation-platform` para evoluir o action. Verificacao: `grep -n 'packages/\*' karavela-packages-workflows/actions/detect-workspace-modules/action.yml`.

## RBAC — `-hosted-<owner_group>` vs `-group`

Diferente dos outros ecossistemas, pypi tem um repo Nexus **privado por time** para hospedar (`pypi-hosted-<owner_group>`) e o `pypi-group` publico que agrega tudo.

- **Publicacao** → `pypi-hosted-<owner_group>` (gerenciado pelo reusable, transparente)
- **Consumo** → sempre `pypi-group`

Se o dev local tentar apontar para `pypi-hosted-*` por engano, recebe 401. Use sempre `pypi-group`.

## Armadilhas

### `InvalidVersion` no hatchling

Versao seed (`0.0.1`) e sintaticamente valida. Se a PR trocou para algo tipo `0.0.0-pr.{{number}}`, nao e PEP 440. Mantenha seed canonico.

### `Package not found` logo apos publicar

Nexus tem ~10s de lag entre publicar no `-hosted-<owner_group>` e aparecer no `-group`. Aguarde e reteste.

### Versao dinamica via `setup.py` com `attr:`

```python
setup(version=attr("meu_pacote.__version__"))
```

Funciona, mas o `override-version` do reusable aplica `sed` em `version = ` dentro de `pyproject.toml` e `setup.py`. Se sua versao e lida de `__version__.py`, o sed **nao alcanca**. Solucoes:

1. Padronizar em `pyproject.toml` `[project] version = "0.0.1"` (estatico).
2. Ou passar `version:` manualmente no workflow com o valor resolvido — mas ai voce perde a ancora do `override-version`.

> **F-DYNVER (READY, 2026-05-01 — `karavela-packages-workflows#102`)**: o padrao "pre-compute pattern" (caller roda `<tool> get-version` antes do publish e passa via `version:`) e o caminho oficial **hoje** para ferramentas de versionamento dinamico (setuptools-scm, poetry-dynamic-versioning, versioneer, axion-release, jgitver — `attr:` cai na mesma classe). Ver workspace E2E `karavela_packages_publish_test_nuget_nbgv.yml` como modelo de pre-compute em job sibling.
>
> Quando F-DYNVER aterrissar, o reusable ganhara input opcional `dynamic_version_strategy: setuptools-scm | poetry-dynamic | ...` que dispara a computacao internamente — esta secao sera atualizada para refletir o novo caminho.

### Proxy PyPI lento em CI

Primeira resolucao do `-group` proxy pode ser lenta porque o Nexus baixa do upstream. Nao e erro — espera 1-2 min no primeiro install em runner limpo.

---
name: migrate-to-karavela-packages
version: 1.4.0
updated: 2026-06-11
changelog:
  - "1.4.0: add references/monorepo.md — exemplo COMPLETO de monorepo (staging multi-modulo + PRD dedicado por modulo + PRD inline no auto-release com job versions/jobs *-karavela), destilado de migracao real validada. Atrito surgido no feedback-loop #1 (snippets eram single-module). Links em Fase 0, Escopo e tabela de sintomas."
  - "1.3.0: refinamentos da run demo (karavela-migrate-pkg-demo). Fase 1 agora passa version descartavel unica por rodada (-pr<N>.<run_number>) — idempotencia de re-run + Go exige semver (corrige orientacao antiga de 'omitir version no staging'); Fase 0 ganha checagem de lockfile npm (npm ci exige package-lock.json); NuGet naming simplificado para verbatim/relaxado (sem namespacing StoneCo. forcado) em SKILL + nuget.md; adiciona Modo Demonstracao (test_tag no PRD para repos demo); adiciona pitfall do trigger por bot (GITHUB_TOKEN nao dispara workflow → publish inline) em SKILL + reusable-pitfalls §11/§12; checklist + exemplos + triggers atualizados"
  - "1.1.0: A-01..A-09 (drift fixes), B-01..B-05 (agentic-mode gaps), C-01..C-03 (frontmatter + bump policy) applied via T-α2/T-α3/T-α4 of feature agentic-package-migration; PR_TITLE.txt convention removed (verified absent in coding_pipeline contract)"
  - "1.0.0: initial version (pre-AGMIG iterations)"
description: "Migrar um repositorio existente para publicar em Karavela Packages. Use quando um repo JA publica em outro lugar (GitHub Packages, npmjs.org, PyPI publico, Artifactory) ou nunca publicou mas quer onboard no Karavela, e voce precisa do FLUXO completo: validacao pre-merge em STG via pull_request, rollout seguro em PRD, dual-write com registry antigo, cascata entre pacotes que dependem um do outro, yarn.lock / package-lock.json registry-agnostic, go.mod / go.sum surgery, ecossistema bun, build_command custom com npm pack explicito, environment: stg + test_tag para auto-cleanup, version: github.ref_name para nao publicar com seed (Go deriva da tag, sem seed no manifesto). Erros: YN0018 checksum mismatch, ENOENT *.tgz, bun: command not found, Setup Bun skipped, non-fast-forward push apos rebase, 410 Gone (GOPROXY), go.sum mismatch. Para conceitos, consumo em apps ou onboarding via template Backstage, use a skill karavela-packages."
---

Consumida pelo `KaravelaPackageMigrationWorkflow` (ver `.specs/features/agentic-package-migration/`). Mudanças que afetem o comportamento agêntico devem rodar o feedback-loop contra ≥3 repos antes de mergear.

# Skill: Migrar Repo Existente para Karavela Packages

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.
-->

## Quando Usar Esta Skill (vs. `karavela-packages`)

Use **esta skill** quando o usuario quer **migrar um repo existente**:

- Ja publica noutro lugar (GitHub Packages, npmjs.org, PyPI publico, Artifactory, etc.)
- Nunca publicou, mas tem codigo production-ready que vai virar pacote
- Precisa validar a mudanca numa PR antes de cortar tag/release
- Tem consumidores atuais que nao podem quebrar

Use **`karavela-packages`** quando:

- Usuario vai criar um pacote do zero pelo template Backstage (Fluxo A)
- Pergunta conceitual: normalizacao, ciclo de vida, SBOM, OIDC
- Consumo de pacotes em apps (`USE_KARAVELA_PACKAGES: true`, BuildKit secrets)
- Troubleshooting puro (`Actor not member of owner_group`, `401` local)

Se a pergunta mistura os dois, puxe esta skill para o "como migro" e `karavela-packages` para referencia de "o que o reusable workflow faz".

## Modos de Operacao

Esta skill suporta **dois modos** de consumo. Identifique o seu antes de seguir o resto da skill — varios comportamentos dependem dele.

### Interativo (Claude Code, kli, sessao humano-no-loop)

- Quem carrega: humano via Claude Code, `kli vela`, ou IDE com Skill tool.
- Input: humano responde perguntas no chat.
- Confirmacoes ambiguas (`owner_group` divergente, estrategia dual-write vs cutover, nome canonico que nao bate): **pergunte ao usuario antes de prosseguir**.
- Saida: PR aberto manualmente pelo humano, ou comandos `gh pr create` rodados na sessao.
- Avisos obrigatorios da secao "Formato de Resposta Esperado" aplicam **integralmente**.

### Agentico (workflow Temporal `KaravelaPackageMigrationWorkflow`)

- Quem carrega: `vela-agent` rodando num Pod efemero, prompt construido pelo `temporal-worker` (ver `temporal/temporal-worker/internal/runner/prompts/`). Skill montada via ConfigMap em `$HOME/.claude/skills/migrate-to-karavela-packages/`.
- Input: parametros vem da activity (`DiscoveryReport`, `owner_group`, `effective_strategy`). **Nao ha canal de chat com o usuario durante a execucao**.
- Confirmacoes ambiguas: **NUNCA pause esperando humano**. Em vez disso:
  - Se a ambiguidade e bloqueante (ex.: `owner_group` invalido, ecossistema nao detectado): emita finding bloqueante e termine o stage. O workflow marca a migracao como `NEEDS_HUMAN` e exibe no painel.
  - Se a ambiguidade tem default razoavel (ex.: dual-write vs cutover quando o usuario escolheu "agente decide"): use o default da skill + spec (ver story P1 do `.specs/features/agentic-package-migration/spec.md`), documente a escolha no PR body, e prossiga.
- Saida: o proprio agente comita, pusha e abre PR draft via `gh pr create` no `implementation.tmpl`. Reviewers (business/security) escrevem `.vela-agent/findings.json` — ver "Convencao de output (modo agentico)" no fim desta skill.
- Avisos obrigatorios da secao "Formato de Resposta Esperado" sao **adaptados** (ver notas inline marcadas com "modo agentico").

> **Como saber em que modo voce esta:** se o prompt inicial menciona `WorkflowID`, `FindingsPath`, `DiscoveryReport`, ou voce esta lendo este texto via Skill tool dentro de um Pod efemero — voce esta em **modo agentico**. Caso contrario, **interativo**.

## Escopo

**Cobre:**
- **Dois workflows paralelos** durante a migracao: `karavela_packages_publish.yaml` (PRD, `@main`, triggers de release/tag) + `karavela_packages_publish_staging.yaml` (VALIDACAO, pull_request, `@develop`, `environment: stg`, `test_tag`) — remove-se o de staging antes do merge
- **Decisao dual-write vs cutover**: quando manter ambos temporariamente, quando virar a chave direto
- **Ecossistemas "dificeis"**: bun (sem cobertura nativa no reusable antigo), yarn.lock com `__archiveUrl` pinado, monorepos com versoes por manifesto que ja publicam em outro registry
- **Cascata de migracao**: ordem correta quando repo A depende de repo B, ambos migrando
- **Commit cirurgico em `yarn.lock`**: tornar registry-agnostic sem bump de transitivas
- **Armadilhas especificas do migrante**: `build_command` custom pula `npm pack` default, `version: ${{ github.ref_name }}` faltando no workflow de PRD, npm sem `package-lock.json` (`npm ci` falha), versao repetida no re-run do staging (`409`), release/tag criado por **bot** (`GITHUB_TOKEN`) que **nao dispara** o workflow de PRD, `@develop` do reusable nao propaga para sub-actions `@main`, branch default `master` vs `main`
- **Modo Demonstração**: incluir `test_tag` no workflow de PRD para repos demo/sandbox (publish descartavel)
- **NuGet naming relaxado**: publicar o `<PackageId>` verbatim, sem rename forcado para `StoneCo.*`
- **Monorepo**: 1 job por módulo (staging multi-módulo + PRD dedicado ou inline) — exemplo completo em [references/monorepo.md](references/monorepo.md)

**Nao cobre** (delegar para `karavela-packages`):
- Template Backstage de pacote novo
- Teoria de normalizacao de nome, ciclo PENDING/CONFIRMED/PUBLISH_FAILED
- Consumo em apps / `USE_KARAVELA_PACKAGES: true`
- SBOM, scan SCA (Grype, informacional), Dependency Track
- OIDC secretless para CI/CD consumidor

## Exemplos de Perguntas

- *"Gostaria de migrar meus pacotes para o Karavela Packages"* (entrada genérica — comece pela Fase 0)
- *"Quero publicar minha lib ts-toolkit no Karavela Packages, ela ja publica em GitHub Packages"*
- *"Tenho um monorepo yarn workspaces publicando em npmjs.org, preciso migrar sem quebrar consumidores"*
- *"Meu projeto usa bun, nao tem suporte no reusable workflow, o que faco?"*
- *"yarn.lock pineia URLs do GH Packages. Como viro registry-agnostic sem regenerar o lockfile todo?"*
- *"Publiquei em STG mas plan falhou com `bun: command not found`"*
- *"Publish deu ENOENT em `*.tgz` depois do build_command custom"*
- *"YN0018 checksum mismatch apos apontar yarn para STG"*
- *"Como rodo o workflow de publish numa PR sem ter que criar release?"*
- *"ts-shared depende de ts-logger. Como migro os dois sem quebrar lockfile?"*
- *"npm ci falhou com EUSAGE / o repo não tem package-lock.json"*
- *"Meu staging falha no segundo run com 'versão já publicada'"*
- *"Meu repo auto-releasa no push da main por um bot; o workflow de Karavela não dispara"*
- *"Preciso renomear meu pacote NuGet pra `StoneCo.*` ao migrar?"* (não — naming relaxado, ver abaixo)

## Sinais para Abortar (Agentic Mode)

> Aplica-se ao **modo agentico**. No modo interativo, o humano decide caso a caso — esses sinais sao **sugestoes** de "puxar humano para o loop", nao abortos automaticos.

O agente NAO deve tentar autonomamente quando qualquer um dos seis sinais abaixo aparecer na fase 0 (Discovery). Em todos os casos: emita finding bloqueante claro, termine o stage, e deixe a migracao como `NEEDS_HUMAN`. **Nao cascateie, nao improvise, nao force.**

1. **Codigo gerado no build.** Repo tem `prebuild.js`, OpenAPI codegen, scripts que regeneram arquivos versionados no proximo `npm install` ou `dotnet build`. Migrar significa rodar o build no reusable; se a regeneracao mudar arquivos, o agente nao tem como julgar se o diff e legitimo.
2. **Multiplos registries de origem.** Repo publica em **mais de um** registry de origem (ex.: GH Packages + npmjs publico + Artifactory interno). Decidir qual virou Karavela e qual permanece e decisao de produto, nao automacao.
3. **CI extenso pre-existente.** Repo tem dezenas de workflows em `.github/workflows/` que usam `pull_request` trigger e podem conflitar com o `karavela_packages_publish_staging.yaml` (rate limit, race conditions com outros publishes, env vars duplicadas). Risco de quebrar fluxo de CI ao adicionar PR trigger.
4. **Monorepo misto publico + interno.** Monorepo onde alguns modulos publicam em npmjs publico e outros sao internos. Estrategia diferente por modulo — o reusable nao suporta esse split sem multiplos workflows, o que excede o escopo do MVP.
5. **Branch protection com bot rules complexas.** Repo tem branch protection que exige status checks especificos, signed commits, ou aprovacao de bot interno. O PR draft do agente pode ficar travado em pre-merge sem caminho automatico de desbloqueio.
6. **Repo NAO esta em `stone-payments` org.** Forks ou repos em outras orgs (ex.: `pagarme`, `dlpco`) tem regras de auth, hooks e permissions diferentes. MVP cobre apenas `stone-payments`.

**Importante:** dependencia interna nao-publicada em STG **nao** entra mais nesta lista — virou entrada do `Cascade Orchestration` abaixo.

## Cascade Orchestration (Agentic Mode)

> Aplica-se ao **modo agentico**. No modo interativo, "pare e cascateie" continua valido como aviso obrigatorio (ver "Formato de Resposta Esperado").

Quando o Discovery detecta dependencias internas `@stone-payments/*` (ou equivalente por ecossistema) que **ainda nao foram publicadas no Nexus Karavela**, o agente NAO para — ele **detecta e orienta cascata**. O fluxo:

1. Stage `discovery` lista cada dependencia interna nao-publicada em `DiscoveryReport.internal_dependencies`.
2. Worker constroi grafo topologico folha → raiz dos repos que precisam migrar antes do repo-alvo.
3. **Default OQ-009: `auto_cascade = true`** — o `KaravelaPackageMigrationWorkflow` raiz dispara workflows filhos automaticamente, um por repo da cascata, sequenciados pela ordem topologica. Cada filho espera STG verde antes do proximo iniciar. **Nenhuma confirmacao intermediaria.**
4. Cada repo filho passa por **pre-flight write-access check**: se o usuario inicial nao tem write no repo filho, o filho falha com finding claro, a cascata pausa, e a migracao raiz vira `NEEDS_HUMAN`.
5. Cada repo filho ainda passa por `business-review` + `security-review` + `fixer` loop normal — PR draft, nunca merge automatico. O blast radius e mitigado pelo ciclo de review padrao do coding pipeline.
6. Workflow filho que termina em `NEEDS_HUMAN` (qualquer motivo, incluindo sinais da secao "Sinais para Abortar") pausa o pai. Painel exibe "Aguardando intervencao em `<repo filho>`".
7. Cascata completa (todas as folhas em STG verde) desbloqueia automaticamente o `surgery` do repo original.

**Contraste com modo interativo:**

| Situacao | Interativo | Agentico |
|---|---|---|
| Dep interna nao publicada | "Pare e cascateie" — aviso ao humano | Detecta grafo, dispara workflows filhos automaticamente |
| Repo filho falha auth | Humano resolve | Cascata pausa, finding bloqueante, `NEEDS_HUMAN` |
| Cascata grande (>3 repos) | Humano avalia ordem | Default `auto_cascade=true` (ver OQ-009; `--pause-between=true` e refinamento P3) |

Referencias:
- Spec da feature: `.specs/features/agentic-package-migration/spec.md` story P2 "Cascade orchestration automatica".
- Receita tecnica de cascata: `references/dependency-cascade.md` (branch efemera, ordem de publish, validacao de consumers).

## Fluxo Canonico de Migracao (Guia Passo-a-Passo)

Cada repo em migracao passa por **5 fases**. Na primeira vez que ler o repo-alvo, **gere um plano** explicitando em que fase esta e o que falta.

### Fase 0 — Descobrir o terreno

Antes de qualquer arquivo, responda:

| Pergunta | Como checar |
|---|---|
| Ecossistema? | `package.json` / `pyproject.toml` / `*.csproj` / `pom.xml` / `go.mod` |
| Package manager? | `bun.lock` / `bun.lockb` > `yarn.lock` > `pnpm-lock.yaml` > `package-lock.json`; Go: `go.mod` + `go.sum` |
| **Lockfile existe?** (npm/node) | O reusable roda **`npm ci`**, que **exige** `package-lock.json` (ou `npm-shrinkwrap.json`). Se o repo npm **não tem nenhum lockfile**, `npm ci` falha com `EUSAGE` (`can only install with an existing package-lock.json`). Gere e comite **na mesma PR**: `npm install --package-lock-only` (offline, sem reflorestar transitivas). Ver [references/reusable-pitfalls.md](references/reusable-pitfalls.md) §11 |
| Monorepo? | `workspaces` no root, `[tool.uv.workspace]`, `.sln`, Gradle `include(…)`, `go.work` / múltiplos `go.mod`. **Monorepo = 1 job por módulo** (exemplo completo de staging + PRD em [references/monorepo.md](references/monorepo.md)) |
| Branch default? | `git symbolic-ref refs/remotes/origin/HEAD` |
| Ja publica onde? | `publishConfig.registry`, `.yarnrc.yml` / `.npmrc`, workflow atual em `.github/workflows/` |
| `owner_group`? | `catalog-info.yaml` → `spec.owner`. **Confirme com o usuario** — nome no Opsgenie pode diferir do catalog (ex: catalog `distribution-offers` vs Opsgenie `dp-vendas-offers`) |
| Dependencias internas? | `grep @stone-payments package.json` / equivalente. **Go**: `grep 'require .*github.com/stone-payments/' go.mod` (module paths internos). **Essas precisam estar no Nexus antes do install rodar.** |
| Estrategia de versionamento? | `version.json` (nbgv) / `GitVersion.yml` / `[tool.setuptools_scm]` / `.changeset/` / tag canonica manual. Define se o `version:` do reusable recebe `${{ github.ref_name }}`, o output de um job upstream que computa, ou e omitido. Ver [references/dynamic-versioning.md](references/dynamic-versioning.md) |

**Regra crucial**: nao copie valores de `owner_group`, ecossistema ou paths entre repos — cada uma dessas respostas vem do repo-alvo. Confirme explicitamente.

### Inputs que o Agente NAO Deve Adicionar

Antes de qualquer snippet — **nao adicione os seguintes inputs** quando gerar workflow novo numa migracao:

- `build_runs_on` — o reusable ja resolve um default apropriado para cada ecossistema. Passar um valor proativamente acopla a migracao a uma capacidade de runner que pode nao existir no futuro (deprecations de `medium-runner`, etc). So adicione se o usuario **explicitamente** pedir um runner especifico.
- `build_command` — omita a menos que o ecossistema nao tenha path nativo no reusable (caso `bun` antigo, ou build customizado real). Ver `references/build-command.md`.

Regra geral para todos os inputs opcionais: **o default do reusable e a resposta certa 95% das vezes**. Passe apenas o que voce sabe o porque.

### Verificacao canonica de nome

Antes de gerar workflow, confirme que o nome publicado bate com a convencao canonica do ecossistema. **Fonte de verdade**: [`karavela-packages-common/src/utils/packageName.ts`](https://github.com/stone-payments/karavela-core/blob/develop/plugins/karavela-packages-common/src/utils/packageName.ts) — usado tanto pelo `karavela:core:normalize-package-names` (scaffolder action, Fluxo A) quanto pelo `PackageNamePreview` (custom field do template Backstage).

Convencoes por ecossistema:

| Ecossistema | Formato | Exemplo |
|---|---|---|
| npm | `@stone-payments/kebab-case` | `@stone-payments/payment-api` |
| PyPI | `snake_case` | `payment_api` |
| NuGet | **`<PackageId>` verbatim** — naming relaxado, **sem namespacing forcado** | `Stone.Demo.Core`, `MeuPacote` |
| Maven | `co.stone.kebab-case` (artifactId) | `co.stone.payment-api` |
| Go | **module path literal** (sem transform) | `github.com/stone-payments/payment-sdk` |

**Monorepo**: `{packageName}-{moduleName}`. **Maven path**: sem hifens (`payment-api` → `paymentapi`).

> **NuGet é o caso simples — vá pelo simples.** Hoje o Portal **não força namespacing** em NuGet: o `<PackageId>` do `.csproj` é publicado **verbatim** (ex.: `Stone.Demo.Core` sai como `Stone.Demo.Core`, **não** `StoneCo.Stone.Demo.Core`). **Não proponha rename para um "nome canônico" `StoneCo.*`** numa migração NuGet — isso só gera confusão e quebra consumidores atuais à toa. Mantenha o `<PackageId>` como está. Só mexa no nome se houver conflito de identidade real (`409`) — aí, com o usuário. Ver [references/nuget.md](references/nuget.md).

**Go é a excecao da normalizacao**: a identidade publicada é o `module` literal do `go.mod`, sem prefixo/transform (igual a um `raw`). Submódulo de monorepo = `{modulePath}/{subpath}` (ex: `github.com/stone-payments/foo/sub-a`). E **cada módulo tem sua própria tag no formato `module/vX.Y.Z`** (ex: `sub-a/v1.4.0`) — não uma tag global `vX.Y.Z` compartilhada.

Por que isso importa pra migracao: o nome que o `plan` aprova e o que vira `original_identity`, e o que vai pra `packages.stone.tech`. Se o nome no manifesto do repo (ex: `@meuteam/payment-api`) nao bate com a convencao, o plan pode rejeitar (409 conflito de identidade) ou — pior — aceitar e voce descobre post-publish que `@stone-payments/payment-api` nao resolve porque alguma normalizacao falhou.

**Procedimento de verificacao** (rodar antes da Fase 1):

1. Leia o `name` do manifesto do repo-alvo.
2. Compare com a convencao do ecossistema acima.
3. Se o nome **ja bate**: ok, segue com o que esta.
4. Se o nome **nao bate**: ajustar o manifesto **na mesma PR de migracao** (renomeacao implicita) **ou** abrir thread com o usuario sobre se quer mesmo migrar com o nome atual (consumidores antigos quebram). Nao "infira" a normalizacao silenciosamente.

> **NuGet pula os passos 2–4**: naming relaxado, sem namespacing forcado → publica o `<PackageId>` como está. Não compare com "convenção canônica", não proponha rename. Segue direto pra Fase 1 com o nome atual.

### Fase 1 — Workflow de validacao em STG (pre-merge)

Este e o padrao que separa migracao de "vai que da". Crie **antes** do workflow de PRD:

```yaml
# .github/workflows/karavela_packages_publish_staging.yaml
name: Karavela Packages Publish (Staging)

on:
  pull_request:
    branches:
      - main   # ← TROQUE para 'master' se for o branch default do repo

permissions:
  contents: read
  id-token: write
  attestations: write

jobs:
  publish:
    uses: stone-payments/karavela-packages-workflows/.github/workflows/karavela_packages_publish.yml@develop
    with:
      # NAO adicione build_runs_on / build_command — defaults do reusable cobrem 95%
      ecosystem: 'npm'                # npm | pypi | nuget | maven | go
      owner_group: '<time-opsgenie>'  # NAO o valor do catalog-info.yaml sem confirmar
      work_dir: '.'
      environment: 'stg'
      test_tag: 'pr-${{ github.event.pull_request.number }}'
      # versao DESCARTAVEL e UNICA por rodada — idempotencia de re-run + Go exige semver (ver "Por que" abaixo)
      version: '0.0.0-pr${{ github.event.pull_request.number }}.${{ github.run_number }}'
      # ↑ Go: prefixe 'v' (v0.0.0-pr...). PyPI: use '0.0.0.dev${{ github.run_number }}' (PEP 440 nao aceita '-pr')
    secrets: inherit
```

> **F-OWNERSHIP-MIG (em curso — D-020, 2026-05-12)**: hoje o input e `owner_group: '<time-opsgenie>'` (modelo OpsGenie, espelhado do catalog `spec.owner`). A plataforma esta migrando para `org_unit_ref = 'group:stone/{slug}'` (grupos `organizational-unit` do BigQuery via `TeamsSyncProvider`), em 3 fases: **Bridge** (aditivo, ambos coexistem) → **Seed + UI + Fanout** → **Cutover**. Esta skill sera atualizada na janela do cutover (Fase 3) — ate la, mantenha `owner_group` no modelo OpsGenie e confirme com o usuario. Spec: `.specs/features/packages-ownership-migration/`.

**Por que cada linha existe:**

- `pull_request.branches` — **bate com a branch default real do repo**. Se for `master`, troque; caso contrario o workflow nao dispara e voce demora a descobrir.
- `@develop` — aponta para a branch de homologacao do reusable workflow. Serve para testar incrementos antes de chegarem em `@main`.
- `environment: 'stg'` — direciona publish para `packages-stg.stone.tech`, nao producao.
- `test_tag: 'pr-<N>'` — marca a publicacao como descartavel. O Nexus STG aplica TTL e limpa. **Sem isso, voce suja o registry de staging a cada run.**
- `version:` **descartavel e unica por rodada** (`-pr<N>.<run_number>`). **Por que passar versao no staging** (correcao vs. orientacao antiga de "omitir"):
  - **Idempotencia de re-run.** Omitir `version` faz o reusable publicar a versao **seed** do manifesto (ex: `0.0.0`). No **primeiro** run publica; no **segundo** (você corrigiu algo e re-rodou a PR) o Nexus rejeita com "versao ja publicada" / `409`. Incluir `${{ github.run_number }}` dá uma versao nova a cada rodada → re-run sempre verde.
  - **Go exige semver.** Em Go a versao vem da tag git; numa PR **não há tag**, então sem `version` o reusable cai no **SHA do commit** (ex: `dca2530`), que não é semver válido e quebra o `list` do `go-hosted` (`Merged list is empty after merging local list with remote`). Um semver pré-release sintético resolve.
  - Continua validando build+pack+publish — a versao é só um rótulo descartável (o `test_tag` garante o TTL/cleanup).

### Fase 2 — Workflow de producao (PRD)

Criar junto, ou na mesma PR, mas so dispara de release/tag:

```yaml
# .github/workflows/karavela_packages_publish.yaml
name: Karavela Packages Publish

on:
  release:
    types: [published]
  push:
    tags:
      - 'v*-rc.*'
      - 'v*-beta.*'
      - 'v*-alpha.*'

permissions:
  contents: read
  id-token: write
  attestations: write

jobs:
  publish:
    uses: stone-payments/karavela-packages-workflows/.github/workflows/karavela_packages_publish.yml@main
    with:
      # NAO adicione build_runs_on / build_command — defaults do reusable cobrem 95%
      ecosystem: 'npm'                  # npm | pypi | nuget | maven | go
      owner_group: '<time-opsgenie>'
      work_dir: '.'
      version: ${{ github.ref_name }}   # ← OBRIGATORIO. Sem isso publica a versao do manifesto (seed). Em Go é a tag (v preservado, override-version é no-op)
    secrets: inherit
```

**Diferencas vs staging, com motivo:**

| Linha | staging | prd | Por que |
|---|---|---|---|
| `on:` | `pull_request` | `release: [published]` + tag push | Staging valida PR; PRD so publica em release oficial |
| `@develop` | sim | `@main` | Staging testa vem da dev; PRD usa estavel |
| `environment:` | `stg` | omitido (default `prd`) | `stg` usa nexus de staging |
| `test_tag:` | `pr-<N>` | omitido (exceto **Modo Demonstração** — ver abaixo) | PRD nao e descartavel num repo real |
| `version:` | `0.0.0-pr<N>.<run_number>` (descartavel, unica/rodada) | `${{ github.ref_name }}` | Staging: idempotencia de re-run + Go exige semver. PRD: tag `v1.2.3` vira `1.2.3` (`override-version` remove o `v`) |

**Erro classico**: abrir PR sem `version:` no workflow de PRD. Workflow sobe, tag dispara, e o Nexus recebe a versao seed do `package.json` (ex: `0.0.0` ou `2.2.0`) — nao a da tag.

> **Quando NAO usar `${{ github.ref_name }}`**: se o repo ja usa versionamento dinamico (nbgv, GitVersion, setuptools-scm, poetry-dynamic-versioning, gradle-git-version, changesets, semantic-release), forcar tag canonica **quebra o contrato de versao com os consumidores**. O reusable aceita qualquer string em `version:` — incluindo o output de um job upstream que computa a versao. Ver [references/dynamic-versioning.md](references/dynamic-versioning.md) para o playbook completo (3 estrategias, caveats single/monorepo, exemplo nbgv) e [examples/nuget-nbgv.yml](https://github.com/stone-payments/karavela-packages-workflows/blob/main/examples/nuget-nbgv.yml) no `karavela-packages-workflows` como referencia executavel.

#### Modo Demonstração (repos demo / sandbox)

Em repo **de demonstração ou sandbox** (validar a própria skill, treinar o time) você **quer** que o publish de PRD seja descartável — sem poluir `packages.stone.tech` com versões reais. Só nesse caso, inclua `test_tag` **também no PRD**:

```yaml
    with:
      ecosystem: 'npm'
      owner_group: '<time-opsgenie>'
      work_dir: '.'
      version: ${{ github.ref_name }}
      test_tag: 'demo'   # ← SÓ em repo demo: publish de PRD vira descartável (TTL no Nexus)
    secrets: inherit
```

**Num repo de produção, NÃO inclua `test_tag` no PRD** — lá o publish é definitivo. Confirme com o usuário que o repo é demo antes de adicionar, e sinalize "Modo Demonstração" no PR body.

#### Atenção: release/tag criado por bot NÃO dispara o PRD

Um workflow de PRD **dedicado** (escutando `release: [published]` / `push: tags`) só dispara se a release/tag for criada por um **humano** ou por um token de **App/PAT**. **Eventos disparados pelo `GITHUB_TOKEN` não disparam outros workflows** (anti-recursão do GitHub Actions). Logo, se o repo já cria releases/tags por um **bot** — ex.: um `auto-release.yml` que roda `gh release create` no push→`main` com `secrets.GITHUB_TOKEN` — o workflow de PRD **nunca roda**. Detecte isso na Fase 0 (existe workflow que auto-cria release/tag?) e escolha:

| Opção | Quando | Como |
|---|---|---|
| **Publish inline no mesmo fluxo** (preferido) | Repo já auto-releasa no push→`main` (monorepo / Fluxo D) | Chame o reusable como job(s) `*-karavela` **dentro** do `auto-release.yml`, no mesmo trigger, em dual-write com o legado. Versão computada num job upstream (`versions`) é a fonte única, consumida pelos dois destinos. Sem depender de trigger de release. |
| **Token de App/PAT** | Quer manter o PRD dedicado por trigger | Crie a release/tag com **GitHub App token** (ou PAT) em vez do `GITHUB_TOKEN` → o evento propaga. Estreite o trigger para **um** evento (evitar disparo duplo tag + release). |
| **Release manual pela UI** | Pontual / demo | Release criada por humano na UI dispara `release: [published]`. Quebra a automação — serve só para demonstrar. |

Receita técnica + exemplo inline em [references/reusable-pitfalls.md](references/reusable-pitfalls.md) §12.

### Fase 3 — Validar na PR ate ficar verde

Abra a PR com os dois workflows. O staging dispara; va corrigindo ate ficar verde:

1. **Plan falha com `403/409`** — `owner_group` errado ou par `(ecosystem, original_identity)` ja pertence a outro time. Reveja com o usuario. `409` frequentemente exige `#help-foundation-platform`.
2. **Build falha** — ver secao "Problemas comuns durante a migracao" abaixo. 90% dos casos: ecossistema nao-suportado-nativamente (bun), `build_command` que nao gera tarball, lockfile incompativel com o registry STG.
3. **Publish falha com `401`** — `permissions.id-token: write` faltando, ou rodando em fork (bloqueia OIDC).

### Fase 4 — Dual-write vs cutover

Quando a validacao STG fica verde, decida como seguir:

| Estrategia | Quando escolher |
|---|---|
| **Dual-write** (mantem workflow legado + adiciona Karavela) | Ha consumidores externos atualmente; migracao leva semanas |
| **Cutover** (deleta workflow legado) | Repo interno sem consumidores externos OU o legado esta quebrado / deprecated |

**Dual-write** — apenas adicione o novo workflow. Mantenha o antigo (ex: `publish.yml` que publica em GH Packages) intocado. A flag `--registry` no `npm publish` do reusable sobrescreve o `publishConfig.registry` do `package.json`, entao **nao precisa mexer no manifesto**. Ver `references/dual-write.md`.

**Cutover** — na mesma PR, delete o workflow antigo.

### Fase 5 — Promocao para producao

Antes de mergear a PR:

1. **Remova o workflow de staging** — `karavela_packages_publish_staging.yaml` cumpriu seu proposito. Mantele-lo no repo e ruido: cada PR futura dispararia publish sem necessidade.
2. **Merge da PR**.
3. **Pre-release primeiro**: `git tag vX.Y.Z-rc.1 && git push origin vX.Y.Z-rc.1` — dispara o workflow PRD mas ainda nao e "oficial".
4. **Release final**: criar GitHub Release pela UI apontando para `vX.Y.Z`. **Tag pushada direto nao dispara o trigger `release: [published]`**.
5. Verifique que o artefato apareceu em `packages.stone.tech/repository/npm-group/` (ou equivalente do ecossistema).

> **Fluxo inline (bot / push-on-main):** se o publish em Karavela é **inline** no `auto-release.yml` (ver "Atenção: release/tag criado por bot" na Fase 2), esta Fase 5 muda — não há release manual pela UI nem (necessariamente) staging para remover: o publish acontece no **merge para `main`** que toca um módulo. Valide tocando um módulo numa PR antes do merge, ou aceite que o primeiro merge é a validação.

---

## Problemas Comuns Durante a Migracao

### Por sintoma / transversal

| Sintoma | Arquivo |
|---|---|
| `YN0018 checksum mismatch`, lockfile com `__archiveUrl` / `resolved` / `url` / `hash` pinado, pin do time com bump de transitivas | [references/lockfile-surgery.md](references/lockfile-surgery.md) (exemplos yarn/npm; para `uv.lock`/`poetry.lock` ver `pypi.md`; para `packages.lock.json` ver `nuget.md`; para `gradle.lockfile` ver `maven.md`) |
| `ENOENT '*.tgz'` / `No *.nupkg` / `dist/*` vazio apos `build_command` custom, publish pula pack default | [references/build-command.md](references/build-command.md) |
| Repo A depende de repo B (mesma org), ambos migrando, ordem de publicacao | [references/dependency-cascade.md](references/dependency-cascade.md) |
| Repo ja publica em outro registry, precisa manter consumidores atuais | [references/dual-write.md](references/dual-write.md) |
| Staging workflow nao disparou na PR, `@develop` do reusable nao refletiu mudanca, `hashFiles()` em composite nao dispara, `version:` faltando em PRD, release/tag por **bot** (`GITHUB_TOKEN`) nao dispara PRD | [references/reusable-pitfalls.md](references/reusable-pitfalls.md) |
| **Monorepo**: varios modulos/ecossistemas, como montar staging multi-modulo + PRD (dedicado ou inline) com 1 job por modulo | [references/monorepo.md](references/monorepo.md) |
| Repo usa nbgv / GitVersion / setuptools-scm / poetry-dynamic-versioning / changesets — versao nao deve sair da tag | [references/dynamic-versioning.md](references/dynamic-versioning.md) |

### Por ecossistema

| Ecossistema | Arquivo | Cobre |
|---|---|---|
| **Bun** (npm com `bun.lock` / `patchedDependencies`) | [references/bun.md](references/bun.md) | Suporte nativo no reusable, workaround inline, contribuir suporte, `bun: command not found` |
| **PyPI** (uv, poetry, pip, pip-tools) | [references/pypi.md](references/pypi.md) | `pyproject.toml`, `uv.lock` / `poetry.lock` cirurgia, dual-write com twine, monorepo uv, `-hosted` vs `-group` |
| **NuGet** (.NET CLI) | [references/nuget.md](references/nuget.md) | `.csproj` com `<PackageId>`, `packages.lock.json`, `NuGet.Config` v2/v3, dual-write com GH Packages, multi-projeto via `.sln` |
| **Maven / Gradle** | [references/maven.md](references/maven.md) | `pom.xml` / `build.gradle.kts`, `settings.xml`, `gradle.lockfile`, SNAPSHOT vs Release, dual-write com Artifactory, multi-module |
| **Go** (go modules, GOPROXY) | [references/go.md](references/go.md) | go.mod, go.sum surgery, dual-write via GOPROXY `,direct`, GONOSUMDB/GOPRIVATE, multi-module go.work |

## Checklist de PR de Migracao (para code-review)

Antes de mergear uma PR que migra um repo para Karavela Packages, confirme:

- [ ] PRD publica com a **versão certa**: workflow dedicado tem `version: ${{ github.ref_name }}`; **ou**, no fluxo inline (publish dentro do `auto-release.yml`), `version` vem do job que computa a versão por módulo
- [ ] PRD usa `@main` do reusable
- [ ] `karavela_packages_publish_staging.yaml` **nao existe mais** no diff final (foi adicionado, validado, removido)
- [ ] Staging usou `version` **descartável e única por rodada** (`-pr<N>.<run_number>`; Go com `v`, PyPI `.devN`) — idempotência de re-run + Go exige semver
- [ ] **npm/node**: existe `package-lock.json` (o reusable roda `npm ci`); se faltava, foi gerado na mesma PR
- [ ] `owner_group` foi validado com o usuario (catalog pode divergir do Opsgenie)
- [ ] `pull_request.branches` do staging bate com o branch default real do repo
- [ ] **Trigger do PRD**: se o repo auto-cria release/tag por bot (`GITHUB_TOKEN`), o publish em Karavela é **inline** no mesmo fluxo (não um workflow dedicado por trigger, que nunca dispararia)
- [ ] **NuGet**: `<PackageId>` mantido **verbatim** — **não** houve rename forçado para `StoneCo.*` (naming relaxado)
- [ ] **Modo Demonstração**: `test_tag` no PRD **somente** se o repo é demo/sandbox; num repo de produção o PRD **não** tem `test_tag`
- [ ] Se dual-write: workflow legado continua intocado (ou, no fluxo inline, o publish legado convive como job independente)
- [ ] Se cutover: legado foi removido na mesma PR
- [ ] Nao ha alteracao de versao no manifesto para algo alem da versao seed (`0.0.1` / `0.1.0`) — versao real vem da tag
- [ ] **Go**: seed nao se aplica — `go.mod` nao tem campo `version`; a versao é a tag git (`v` preservado). Em monorepo, confirmar tag no formato `module/vX.Y.Z` exigido pelo `go-hosted` (ex: `sub-a/v1.4.0`)
- [ ] Se o repo usa `yarn.lock` / `package-lock.json`: mudanca do lockfile e **cirurgica** (so scope Stone), nao reflorestamento de transitivas
- [ ] Dependencias internas `@stone-payments/*` pinadas ja estao publicadas em STG (ou em PRD, para pos-merge)

## Formato de Resposta Esperado

Ao ajudar com migracao:

1. **Primeiro`, descubra o terreno (Fase 0)** antes de escrever YAML. Leia manifestos, workflows existentes, lockfile, `catalog-info.yaml`.
2. **Proponha um plano de migracao em fases** (0 → 5), indicando em que fase o repo esta.
3. **Peca confirmacao para valores criticos**: `owner_group`, `ecosystem`, estrategia (dual-write vs cutover). Nao infira silenciosamente.
4. **Codifique workflows copiando o snippet canonico desta skill, NAO outra versao**. Substitua apenas os campos do repo-alvo.
5. **Na primeira rodada verde em STG**, sinalize "pronto para promocao" e relembre o passo 5 (remover staging + pre-release + release final).

**Avisos obrigatorios na saida**:
- Se o repo tem `yarn.lock` com `__archiveUrl` e o usuario pedir "regenera o lockfile": alerte sobre bump de transitivas antes de executar.
- Se o repo tem dependencia interna nao-publicada em STG:
  - **Modo interativo:** pare e cascateie antes de continuar (avise o humano, proponha ordem folha → raiz, e so siga apos confirmacao).
  - **Modo agentico:** **nao pare** — o workflow detecta o grafo e oferece orquestrar a cascata automaticamente (ver secao "Cascade Orchestration (Agentic Mode)" e story P2 do spec `agentic-package-migration`). Emita o `DiscoveryReport.internal_dependencies` com a lista de pacotes nao-publicados; o worker dispara workflows filhos quando `auto_cascade = true` (default OQ-009).
- Nunca sugira expor secrets/tokens — migracao usa OIDC.

## Convencao de output (modo agentico)

> Aplica-se apenas ao **modo agentico**. No modo interativo o "output" e a resposta do chat — esta secao nao se aplica.

O `temporal-worker` (ver `temporal/temporal-worker/internal/runner/prompts/`) define dois contratos distintos por stage:

### Stage `implementation` (o agente que voce executa quando migra um repo)

Voce **NAO escreve** `findings.json` aqui — voce **executa** o trabalho:

1. Edita ou cria arquivos no working dir (`karavela_packages_publish_staging.yaml`, `karavela_packages_publish.yaml`, lockfile surgery, manifesto se aplicavel).
2. Comita seguindo Conventional Commits em pt-BR (`feat(ci): publicar em Karavela Packages`, `chore(lockfile): tornar registry-agnostic`).
3. Pusha: `git push -u origin <branch>` (branch ja vem pre-criada — nao crie outra).
4. Abre PR draft via `gh pr create --draft`:
   - **Title** (pt-BR, ≤72 chars, Conventional Commits): tipicamente `feat(ci): publicar em Karavela Packages`.
   - **Body** (pt-BR): seguir estrutura padrao do `implementation.tmpl` — `## Resumo`, `## Mudancas`, `## Arquitetura / Fluxo` (com Mermaid quando ajudar), `## Como testar`. Inclua **link para a skill**, **resumo do `DiscoveryReport`**, e a **checklist de PR de Migracao** desta skill marcada conforme execucao.
   - **Footer** (ultimas linhas do body): `_vela-agent · workflow <WorkflowID> · solicitado por <RequesterEmail>_`.
5. **NAO escreva nada em `.vela-agent/`** — esse diretorio e scratch space do runner; qualquer coisa que voce colocar la e descartada antes do proximo stage.

### Stages `business-review` e `security-review`

Esses **nao executam a migracao** — eles inspecionam o diff que voce produziu e emitem findings. Eles escrevem em `.vela-agent/findings.json` com schema:

```json
[
  {
    "id": "BR-001",
    "severity": "HIGH",
    "category": "BUSINESS",
    "file": ".github/workflows/karavela_packages_publish.yaml",
    "line": 12,
    "message": "Workflow de PRD nao tem 'version: ${{ github.ref_name }}'; vai publicar a versao seed do manifesto.",
    "suggestion": "Adicionar 'version: ${{ github.ref_name }}' no bloco with: do job publish.",
    "blocking": true
  }
]
```

Campos:

- `id` — prefixo obrigatorio `BR-` (business-review) ou `SR-` (security-review), seguido de numero zero-padded.
- `severity` — `LOW | MEDIUM | HIGH | CRITICAL`.
- `category` — `BUSINESS` ou `SECURITY` (bate com o stage).
- `file` — path relativo a raiz do repo, `""` se N/A.
- `line` — inteiro; `0` quando nao se aplica. **Deve estar dentro de um hunk do diff** (ver `reviewer.tmpl`).
- `message` — descricao curta do problema em **pt-BR**.
- `suggestion` — sugestao de correcao em uma linha em **pt-BR**; `""` se nao houver.
- `blocking` — `true` somente se DEVE ser resolvido antes do merge. Findings nao-bloqueantes podem ser deixadas para humano.

Output e **array JSON sempre** — mesmo vazio, escreva `[]` no arquivo. O arquivo e o **unico canal** que o pipeline le; nada mais.

### Stage `fixer`

Le `.vela-agent/findings.json` produzido pelos reviewers e re-comita correcoes na **mesma branch**, **sem** abrir PR novo. **Nao escreve** `findings.json` proprio.

### Source-of-truth

O contrato exato dos campos do `findings.json` (e os templates por stage) ficam em `temporal-worker/internal/runner/prompts/` no repositorio interno do Vela. Esta secao e relevante apenas para o **modo agentico** — consumidores humanos podem ignorar.

## Modo Acoes

Esta skill ja atua em **Modo Acoes** (agentic) por design — orquestracao de migracao envolve patch de manifestos, lockfile surgery, workflow setup e cascata entre libs. Sempre confirma antes de escrever; producao exige dupla confirmacao. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Editar manifesto** — `package.json` (`publishConfig.registry`, `name` com escopo `@stone-payments/...`), `pyproject.toml` (`project.name`, build backend), `.csproj` (`PackageId`, `NuGet.Config`), `pom.xml`/`build.gradle.kts` (`groupId`/`artifactId`, settings.xml/build.gradle config)
- **Cirurgia em lockfile** — remover URLs antigas de `yarn.lock` / `package-lock.json` / `bun.lockb` (registry-agnostic), regerar com novo registry
- **Editar `.github/workflows/karavela_packages_publish.yml`** — `version: github.ref_name`, `build_command` custom (`npm pack`), `test_tag`, `environment: stg`
- **Adicionar lockfile-surgery script** + commit
- **Dual-write** durante rollout — duplicar publish para registry antigo + Karavela ate rollout completo
- **Cascata** — quando lib A depende de lib B no monorepo, propor ordem correta de migracao
- **Abrir PR draft** (sempre `--draft`)

### Triggers proativos
- "Gostaria de migrar meus pacotes para o Karavela Packages" / "Migrar de npmjs.org para Karavela Packages" → ativar fluxo canonico completo desta skill (comece pela Fase 0)
- "YN0018 checksum mismatch" → propor cirurgia em yarn.lock
- "ENOENT *.tgz" → propor `build_command: npm pack` explicito
- "bun: command not found" → propor setup-bun step antes de install
- "npm ci EUSAGE" / "sem package-lock.json" → gerar lockfile (`npm install --package-lock-only`) na mesma PR
- "versao ja publicada" no re-run do staging → `version` descartavel unica por rodada (`-pr<N>.<run_number>`)
- "release por bot nao dispara o workflow" / "auto-release no push da main" → publish inline no mesmo fluxo (não trigger de release)

### Acoes destrutivas (dupla confirmacao)
- Remover registry antigo do workflow (`publishConfig.registry: https://npm.pkg.github.com`) — pode quebrar consumidores legados. Confirmar dual-write completo antes.
- Force-push pos rebase em branch de migracao — alertar para nao colidir com colaboradores.

## Instrucoes MCP

Esta skill nao tem doc dedicado em `stone-payments/karavela` `docs/`. As fontes primarias de operacao sao o proprio reusable workflow e a skill `karavela-packages` (referencia conceitual).

| Repositorio | Arquivo/Caminho | Prioridade | Quando buscar |
|-------------|-----------------|------------|---------------|
| `stone-payments/karavela-packages-workflows` | `.github/workflows/karavela_packages_publish.yml` | primaria operacional — complemento (nao em docs/) | Inputs/outputs (`environment`, `test_tag`, `version`, `build_command`) + branch `@develop` para validacao em STG |
| `stone-payments/karavela-packages-workflows` | `examples/` | complemento | Exemplos executaveis por ecossistema (ex: `nuget-nbgv.yml`) |
| `stone-payments/karavela-core` | `plugins/karavela-packages-common/src/utils/packageName.ts` | complemento | Convencao canonica de nome por ecossistema |
| Skill `karavela-packages` | `vela/skills/karavela-packages/` | primaria | Conceitos, ciclo de vida, OIDC, consumo em apps |

---
skill: backstage
version: 1
---

## HP — Happy-Path Cases

### HP-01: Ownership lookup por nome do app

- **input**: "Quem e dono do app stone-payments?"
- **expected**: Chama `backstage-catalog__query-catalog-entities` com filtro `kind: Component` e `metadata.name: stone-payments`, retorna `spec.owner` com link pro Backstage.

### HP-02: Discovery de componentes por time

- **input**: "Quais servicos o time de pagamentos e dono?"
- **expected**: Resolve o group e chama `query-catalog-entities` com filtro `spec.owner`, lista em tabela (ate 20 itens).

### HP-03: Listar templates disponiveis

- **input**: "Que templates existem pra criar lib npm?"
- **expected**: Chama `query-catalog-entities` com filtro `kind: Template`, filtra client-side por tema e oferece dry-run.

### HP-04: Dry-run de template

- **input**: "Faz um dry-run do template create-backend-plugin com nome my-plugin"
- **expected**: Chama `backstage-scaffolder__dry-run-template` com templateRef e values, mostra steps resultantes e card de confirmacao.

### HP-05: Listar actions do scaffolder

- **input**: "Quais actions o scaffolder suporta?"
- **expected**: Chama `backstage-scaffolder__list-scaffolder-actions` e lista as actions disponiveis.

### HP-06: Buscar entidade por entityRef

- **input**: "Me mostra os detalhes do component:default/stone-payments"
- **expected**: Chama `backstage-catalog__get-catalog-entity` com entityRef completo e retorna detalhes da entidade.

## EP — Edge / Error Cases

### EP-01: Permission denied no catalogo

- **input**: "Registra essa entidade no catalogo" (user sem permissao)
- **expected**: Surface a mensagem de permission-denied como veio do upstream, sem sugerir workaround.

### EP-02: Confusao com create_app

- **input**: "Cria um novo app api gerenciado"
- **expected**: Redireciona para o playbook `create_app` em vez de usar `execute-template` generico.

### EP-03: Grupo ambiguo

- **input**: "Quais apps o time de pagamentos tem?"
- **expected**: Se houver ambiguidade no nome do group, pergunta ao user qual entityRef correto antes de consultar.

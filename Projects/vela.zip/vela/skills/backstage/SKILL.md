---
name: backstage
description: "Consulta (leitura) do catalogo Backstage: metadados de entidades, owner/dono de um app, componentes de um time, Software Catalog, templates e scaffolder/dry-run. Use quando o usuario perguntar QUEM e dono de um app, quais apps um time possui, ou detalhes de entidades do catalogo. Para CRIAR app nova via template do Backstage, use a skill create-app."
---

# Backstage Catalog + Scaffolder

Use quando o usuario pergunta sobre **metadados do catalogo Backstage** (entidades, owners, relations, componentes do time) ou sobre **templates do Scaffolder** (listar, descrever, dry-run, executar). Surface: `backstage-catalog` + `backstage-scaffolder` MCP servers (auth: backstage-internal — propaga identidade do user via plugin-token, RBAC aplicado upstream). Nao confundir com:

- `create_app` — provisionar app nova via `kli-mcp__create_app`. Esse playbook ganha quando o user pediu **rodar um template arbitrario do scaffolder**, nao criar app gerenciada na plataforma.
- `platform` — `kli-mcp` ops em apps existentes (deploys, secrets). Aqui e **leitura de metadado** + scaffolder, nao operacao.
- `documentation` — Confluence/READMEs. Catalogo e a fonte canonica de _quem e dono de que_; doc e prosa.

## Exemplos de Perguntas

- *"Quem e dono do app X?"*
- *"Quais servicos o time de pagamentos e dono?"*
- *"Que templates existem pra criar lib npm?"*
- *"Lista as entidades do tipo Component no namespace default"*
- *"Faz um dry-run do template create-backend-plugin"*
- *"Quais actions o scaffolder suporta?"*
- *"Registra essa entidade no catalogo"*

## Regras de Execucao

- **RBAC vem de cima** — autorizacao e checada upstream com a identidade do user (plugin-token via `auth.getPluginRequestToken({ onBehalfOf })`). Se a tool devolver permission-denied, surface a mensagem como esta; **nao** sugira workaround.
- **Catalogo e fonte de verdade pra ownership** — quando user pergunta "dono", responda com o `spec.owner` do catalogo, nao chute pelo nome do app/repo.
- **`query-catalog-entities` antes de `get-catalog-entity`** quando o user nao deu `entityRef` completo. Filter por `kind` + nome economiza turnos.
- **`dry-run` antes de `execute`** em scaffolder. Skipar dry-run so quando o template e trivialmente seguro (e o user ja viu o output dele antes).
- **Pra `create_app` da plataforma** (api/worker/cronjob gerenciados), use o playbook `create_app` — esse aqui e pra templates Backstage genericos.
- Janela temporal vem da `## Data atual` injetada — carregue `temporal-handling` se houver duvida.

## Instrucoes MCP

### Catalog (read-heavy)

| Tool | Quando usar |
| --- | --- |
| `backstage-catalog__query-catalog-entities({ filter?, fields?, limit?, offset?, orderField? })` | Query/listagem com filtros (`kind`, `spec.owner`, `metadata.namespace`, etc.). Default pra descoberta. |
| `backstage-catalog__get-catalog-entity({ entityRef })` | Fetch direto por `kind:namespace/name`. |
| `backstage-catalog__get-catalog-model-description()` | Schema das entidades (kinds, campos, relations). Carregue so se precisar montar filtro complexo. |

### Catalog (write, raro)

| Tool | Quando usar |
| --- | --- |
| `backstage-catalog__validate-entity({ entity })` | Valida YAML/JSON antes de submeter. |
| `backstage-catalog__register-entity({ location })` | Registrar via URL de catalog-info.yaml. **Confirmacao explicita do user antes**. |
| `backstage-catalog__unregister-entity({ entityRef })` | Desregistrar entidade. **Confirmacao explicita do user antes**. |

### Scaffolder

| Tool | Quando usar |
| --- | --- |
| `backstage-scaffolder__list-scaffolder-actions()` | Actions disponiveis (steps que templates podem chamar). |
| `backstage-scaffolder__list-scaffolder-tasks({ limit?, ... })` | Tasks recentes (status, owner, template). |
| `backstage-scaffolder__dry-run-template({ templateRef, values })` | Preview sem provisionar. **Use antes de execute pra revisar saida**. |
| `backstage-scaffolder__execute-template({ templateRef, values })` | Provisiona de fato. **Confirmacao explicita do user antes**. Para `app/api/worker` novo gerenciado, prefira o playbook `create_app`. |

## Conhecimento Embutido

### Fluxo: ownership lookup

> "quem e dono do app X?"

1. `query-catalog-entities({ filter: { kind: 'Component', 'metadata.name': 'X' } })`
2. Pegue `spec.owner` (group/user entityRef)
3. Se for `group:...`, opcionalmente `get-catalog-entity({ entityRef: 'group:...' })` pra puxar canal de contato/topology-id
4. Resposta: nome do dono + link pro Backstage + canal de contato se relevante

### Fluxo: discovery por time

> "quais servicos o time de pagamentos e dono?"

1. Resolva o `group` (o user pode dizer "time de pagamentos" — converta pro entityRef esperado, pergunte se ambiguo)
2. `query-catalog-entities({ filter: { kind: 'Component', 'spec.owner': 'group:default/payments' }, fields: ['metadata.name', 'spec.type', 'spec.lifecycle'] })`
3. Liste em tabela curta (ate 20). Acima de 20 → agrupe por `spec.type` e mostre contagem.

### Fluxo: scaffolder discovery

> "que templates existem pra criar lib npm?"

1. `query-catalog-entities({ filter: { kind: 'Template' }, fields: ['metadata.name', 'metadata.title', 'metadata.description', 'metadata.tags', 'spec.type'] })`
2. Filtre client-side pelo tema (`tags` ou `metadata.description`)
3. Pra cada template relevante, ofereca `dry-run-template` antes de `execute-template`

### Fluxo: dry-run + execute

1. `list-scaffolder-actions()` se o user pediu detalhe de step especifico
2. `dry-run-template({ templateRef, values })` — mostre os `steps[*].action` resultantes em prosa curta
3. **Card de confirmacao** com `<suggestions>` `Executar agora / Editar valores / Cancelar`
4. Apos aceite: `execute-template` → retorna `taskId`
5. Acompanhe via `list-scaffolder-tasks` se o user quer status; caso contrario, link pra task page do Backstage

### Reference (cross-playbook)

- **create_app** — pra provisionar app gerenciada (api/worker/cronjob), use o playbook `create_app` em vez de `execute-template` generico.
- **platform** — ops em apps existentes (deploys, secrets) ficam no playbook `platform`.
- **documentation** — Confluence/READMEs para documentacao; catalogo e a fonte canonica de ownership.

## Formato de Resposta

- Ownership: nome do dono + link pro Backstage + canal de contato se disponivel.
- Listagem de entidades: tabela com colunas relevantes (Name, Type, Owner, Lifecycle). Ate 20 linhas; acima, agrupe por tipo e mostre contagem.
- Templates: tabela com Name, Title, Description, Tags. Ofereca dry-run.
- Dry-run: mostre steps resultantes em prosa curta + card de confirmacao.
- Permission denied: surface a mensagem como veio do upstream, sem workaround.

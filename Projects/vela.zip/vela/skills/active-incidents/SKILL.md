---
name: active-incidents
description: "Consulta incidentes abertos — triggers: incidentes ativos, incidente aberto, P0 ativo, severity, thread do incidente, macroproduto impactado"
---

# Incidentes Ativos (AGORA)

Use quando o usuario pergunta sobre **incidentes ABERTOS no momento** — quantos, qual a thread, P0/P1 ativos, distribuicao por macroproduto. Surface principal: **MCP `active-incidents`** (snapshot da query Redash 222, TTL 5 min, cache Redis). Campos do snapshot em `references/redash-query-222-schema.md`.

## Exemplos de Perguntas

- *"Quantos incidentes ativos temos agora?"*
- *"Tem algum P0 aberto?"*
- *"Qual a thread do incidente 1234?"*
- *"Quais macroprodutos estao impactados por incidentes?"*
- *"Ta rolando algum incidente agora?"*
- *"Me mostra a distribuicao de incidentes por prioridade"*
- *"Qual o meet/war room do incidente ativo?"*

## Regras de Execucao

- **`count_*` antes de `list_*`** — so liste se o user pediu detalhe ou nomes. Se a pergunta comeca com "quantos", responda com count primeiro.
- **Sempre cite `age_seconds`** quando o snapshot embasar decisao (war room/status). Formato: "snapshot de Xm atras". TTL 5 min serve panorama, nao triagem ao vivo.
- O indice **nao tem causa raiz nem duracao** — pra "por que?" encaminhe para `postmortems`.
- `refresh()` e caro (~3-10s) — so sob pedido explicito ("dado fresquissimo") ou quando `age_seconds` perto de `ttl_seconds`.
- AGORA x janela passada: ref `references/temporal-handling.md`. Campos do snapshot: ref `references/redash-query-222-schema.md`.

### Roteamento — sempre que aparecer "incidente"

| Qualificador na pergunta                     | Vai pra                       |
| -------------------------------------------- | ----------------------------- |
| "ativo", "aberto", "agora", "acontecendo"    | **`active-incidents`** (este) |
| "tivemos", "ocorreu", "encerrado", "duracao" | `closed-incidents`            |
| "causa raiz", "por que", "ja aconteceu"      | `postmortems`                 |
| sem qualificador temporal                    | `closed-incidents` (default)  |

## Instrucoes MCP

| Tool | Quando usar |
| --- | --- |
| `count_active_incidents({ priority?, macroproduct?, origin? })` | Total + filtros. **USE PRIMEIRO** quando a pergunta comeca com "quantos..." |
| `list_by_priority()` | Distribuicao por prioridade |
| `list_by_macroproduct()` | Distribuicao por macroproduto |
| `list_by_origin()` | Distribuicao por origem (Interno x Externo) |
| `list_active_incidents({ priority?, macroproduct?, origin?, limit? })` | Linha resumida (number, title, priority, macro_product, origin, thread_url, date_time_start) |
| `get_incident({ incident_number })` | Registro completo (inclui `_raw`: products, all_periods...) |
| `get_incident_thread({ incident_number })` | Atalho: so `thread_url`/`meet_url`/`gdoc_url`/`title`. **USE PRIMEIRO** quando a pergunta e "qual a thread/meet do N?" |
| `search_active_incidents({ query, top_k?, priority?, macroproduct?, origin? })` | Match por termo (case+diacritico-insensitive). Pesos em ref `references/redash-query-222-schema.md` |
| `refresh()` | Forca re-execucao (ignora TTL). So sob pedido explicito |
| `health()` | Retorna `ok`, `age_seconds`, `ttl_seconds`, `row_count` |

## Conhecimento Embutido

### Fluxo: "quantos incidentes ativos?"

1. `count_active_incidents()` (sem filtros) — retorna `total` + `snapshot.age_seconds`.
2. Especificou prioridade/macro/origem? Passe nos args.
3. **Cite a idade do snapshot** ("snapshot de 2m atras") — o user precisa saber se e tempo real.
4. `age_seconds > ttl_seconds` → ainda serve; a proxima chamada dispara refresh automatico.

### Fluxo: war room (thread/meet)

1. `get_incident_thread({ incident_number })` — atalho.
2. Detalhes alem da thread → `get_incident`.
3. Formato clicavel: `[#N — title](thread_url)` + meet se existir.

### Fluxo: panorama por dimensao

| Pergunta                    | Tool                                         |
| --------------------------- | -------------------------------------------- |
| "divididos por prioridade?" | `list_by_priority`                           |
| "macroprodutos impactados?" | `list_by_macroproduct`                       |
| "nossos ou de cliente?"     | `list_by_origin`                             |
| "tem P0 ativo?"             | `count_active_incidents({ priority: "P0" })` |

Visao cruzada (P0 por macroproduto) = 2 chamadas filtradas cruzadas no agente (nao ha agregacao 2D nativa).

### Reference (cross-MCP)

- **postmortems** — "por que aconteceu?"/"ja tivemos?": `find_similar_incidents` com `description`+`services` derivados do `friendly_symptoms` daqui.
- **closed-incidents** — `get_incident` retornou `found:false` → encerrou entre refreshes; fallback `get_closed_incident`. Pra contexto "estamos num pico?": `count_closed_incidents({ priority: "P0", date_from: <7d> })`.
- **help-foundation** — produto afetado tem skill: `secao_4_direcionamento.time_responsavel` confirma o ownership do war room.

## Formato de Resposta

- Ao contar incidentes, sempre inclua a idade do snapshot: "Ha **X** incidentes ativos (snapshot de Ym atras)."
- Ao listar, use tabela com colunas: #, Titulo, Prioridade, Macroproduto, Inicio.
- Links de thread/meet em formato clicavel: `[#N — titulo](thread_url)`.
- Distribuicoes por dimensao em tabela ou lista agrupada.
- Quando o incidente nao for encontrado no active-incidents, sugira buscar em `closed-incidents`.

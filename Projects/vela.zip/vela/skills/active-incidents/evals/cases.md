---
skill: active-incidents
version: 1
---

## HP — Happy-Path Cases

### HP-01: Contar incidentes ativos sem filtro

- **input**: "Quantos incidentes ativos temos agora?"
- **expected**: Chama `count_active_incidents()` sem filtros e retorna o total com idade do snapshot.

### HP-02: Verificar P0 aberto

- **input**: "Tem algum P0 aberto?"
- **expected**: Chama `count_active_incidents({ priority: "P0" })` e responde com quantidade + idade do snapshot.

### HP-03: Buscar thread do incidente

- **input**: "Qual a thread do incidente 5678?"
- **expected**: Chama `get_incident_thread({ incident_number: 5678 })` e retorna link clicavel com titulo.

### HP-04: Distribuicao por macroproduto

- **input**: "Quais macroprodutos estao impactados por incidentes?"
- **expected**: Chama `list_by_macroproduct()` e apresenta distribuicao em tabela ou lista agrupada.

### HP-05: Listar incidentes ativos

- **input**: "Me lista os incidentes abertos agora"
- **expected**: Chama `count_active_incidents()` primeiro, depois `list_active_incidents()` e apresenta tabela resumida.

### HP-06: Distribuicao por prioridade

- **input**: "Me mostra a distribuicao de incidentes por prioridade"
- **expected**: Chama `list_by_priority()` e apresenta a distribuicao.

### HP-07: Busca por termo

- **input**: "Tem incidente ativo relacionado a Pix?"
- **expected**: Chama `search_active_incidents({ query: "Pix" })` e retorna resultados encontrados.

## EC — Edge Cases

### EC-01: Count antes de list

- **input**: "Quantos incidentes ativos temos e quais sao?"
- **expected**: Chama `count_active_incidents()` ANTES de `list_active_incidents()`, respeitando a regra count-first.

### EC-02: Incidente nao encontrado no snapshot

- **input**: "Me mostra o incidente 9999"
- **expected**: Chama `get_incident({ incident_number: 9999 })`, se retornar `found:false`, sugere buscar em `closed-incidents`.

### EC-03: Roteamento para closed-incidents

- **input**: "Tivemos algum incidente P0 ontem?"
- **expected**: NAO usa active-incidents; redireciona para `closed-incidents` pois a pergunta refere-se ao passado.

### EC-04: Roteamento para postmortems

- **input**: "Qual foi a causa raiz do incidente 1234?"
- **expected**: NAO usa active-incidents; redireciona para `postmortems` pois a pergunta pede causa raiz.

### EC-05: Refresh so sob pedido explicito

- **input**: "Preciso de dados fresquissimos dos incidentes ativos"
- **expected**: Chama `refresh()` antes de consultar, pois o usuario pediu explicitamente dados frescos.

# Reference: snapshot da query Redash 222 — active-incidents

Campos do snapshot de incidentes ABERTOS (query Redash 222, cache Redis com TTL 5 min). Carregue quando o user perguntar sobre um campo do snapshot ou montar busca/filtro. É um retrato do AGORA — sem causa raiz, sem duração, sem janela temporal.

## Campos por incidente

| Campo                                  | Conteúdo                                                           |
| -------------------------------------- | ------------------------------------------------------------------ |
| `number`                               | número do incidente                                                |
| `title`                                | título (peso ×4 na busca)                                          |
| `description`                          | descrição (×1.5)                                                   |
| `friendly_symptoms`                    | sintomas amigáveis (×2) — bom pra derivar pistas pro `postmortems` |
| `priority`                             | P0..P4 (objeto)                                                    |
| `macro_product`                        | macroproduto (×2)                                                  |
| `products[]`                           | produtos afetados (×2)                                             |
| `origin`                               | Interno × Externo                                                  |
| `date_time_start`                      | início                                                             |
| `thread_url` / `meet_url` / `gdoc_url` | links da war room                                                  |
| `all_periods[]`                        | janelas por prioridade (em `_raw` via `get_incident`)              |
| `incident_hash`                        | hash estável                                                       |

## Meta do snapshot (sempre cite o frescor)

`age_seconds`, `ttl_seconds` (300), `row_count`, `is_fresh`, `fetched_at_epoch`, `redash_retrieved_at`. Cite a **idade** quando o dado embasar decisão (war room/status). Se `age_seconds > ttl_seconds`, a próxima chamada dispara refresh automático.

## Busca (não é BM25)

`search_active_incidents` faz match por ocorrência de termo (case+diacrítico-insensitive) — adequado ao snapshot pequeno (dezenas/centenas de linhas). Pesos:

| Campo               | Peso |
| ------------------- | ---- |
| `title`             | 4.0  |
| `macro_product`     | 2.0  |
| `friendly_symptoms` | 2.0  |
| `products`          | 2.0  |
| `description`       | 1.5  |

## Como escolher a tool

- "quantos…" → `count_active_incidents({ priority?, macroproduct?, origin? })` **antes** de listar.
- distribuição → `list_by_priority` / `list_by_macroproduct` / `list_by_origin`. Visão cruzada (P0 por macroproduto) = 2 chamadas filtradas cruzadas no agente.
- "qual a thread/meet?" → `get_incident_thread` (atalho); detalhes → `get_incident` (inclui `_raw`).
- termo sem número → `search_active_incidents`.
- dado fresquíssimo sob pedido explícito → `refresh()` (caro, ~3-10s).

## Anti-patterns

- ❌ Usar pra passado ("tivemos…") — é só o AGORA; vá pro `closed-incidents`.
- ❌ Procurar causa raiz/duração aqui — não existem no snapshot.
- ❌ `refresh()` sem pedido explícito — é caro; o TTL de 5 min já cobre panorama.
- ❌ Listar antes de contar quando a pergunta começa com "quantos".

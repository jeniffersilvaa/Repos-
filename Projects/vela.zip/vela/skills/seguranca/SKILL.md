---
name: seguranca
description: "Seguranca na plataforma Karavela com Trivy, Kyverno, KubeArmor, CiliumNetworkPolicy, OPA preflight, break glass e sistema de aprovacoes. Use quando o usuario perguntar sobre scan de vulnerabilidades, policies de seguranca, labels obrigatorias, PCI compliance, KubeArmor, CiliumNetworkPolicy, break glass, preflight validation, aprovacoes de recursos, security groups RDS, seguranca em runtime ou gestao de acessos via Sailpoint."
---

# Skill: Seguranca

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.

  Exemplos de uso:
  - Corrigir informacao desatualizada no conhecimento embutido
  - Adicionar restricao temporaria (ex: "chart v4 nao suporta feature X")
  - Adicionar conhecimento que ainda nao esta na documentacao oficial
  - Bloquear uma orientacao especifica (ex: "NAO recomende usar scaler Y")
-->

## Escopo

**Cobre**:
- Scan de vulnerabilidades com Trivy (integrado ao pipeline de CI)
- Remediacao de vulnerabilidades em imagens de container
- Politicas do Kyverno (labels/tags obrigatorias, requisitos de imagem)
- Protecao em runtime com KubeArmor
- CiliumNetworkPolicy (substitui NetworkPolicy quando Cilium esta presente)
- Requisitos de tags de imagem e boas praticas
- Conformidade de seguranca na plataforma Karavela
- Controles de seguranca no fluxo CI/CD (incluindo ambiente PCI)
- Build Integrity (SLSA Level 3 attestations) — supply-chain provenance
- Break glass para RDS, Elasticache/Valkey e KafkaTopic
- Preflight validation com OPA (5 policies Rego: core, infrastructure, labels, identity, lifecycle)
- 7 labels obrigatorias validadas pelo OPA (cost-center, env, github-org, github-repo, owner, project, support)
- Sistema de aprovacoes (scope elevation, grupos, cost center, super admin bypass)
- Security groups para instancias RDS (regras multiplas)
- Seguranca do Temporal UI (write actions desabilitadas)
- Gestao de acessos via Sailpoint

**NAO cobre**:
- Gerenciamento de secrets e Vault (coberto pela skill `secrets-vault`)
- Rede, firewall e Network Policies (coberto pela skill `networking-ingress`)
- Troubleshooting detalhado de erros Kyverno (coberto pela skill `troubleshooting`, embora haja sobreposicao para contexto)

## Exemplos de Perguntas

- "Meu build falhou por vulnerabilidades no Trivy. Como corrijo?"
- "O Kyverno bloqueou meu deployment. Quais labels sao obrigatorias?"
- "Como adiciono uma excecao no scan do Trivy?"
- "O que e o KubeArmor e como ele protege minha aplicacao?"
- "Quais severidades de vulnerabilidade bloqueiam o pipeline?"
- "Como verifico se minha imagem contem vulnerabilidades antes de subir para o Karavela?"
- "Quais controles de seguranca existem no fluxo de CI/CD do Karavela?"
- "Como funciona o break glass para Elasticache/Valkey?"
- "Como configurar aprovacoes por cost center?"
- "Como funciona o preflight validation com OPA?"
- "Como editar security groups do meu RDS?"
- "Como solicitar acesso via Sailpoint?"
- "Como habilito SLSA L3 attestations no meu pipeline?"
- "O que aparece na aba Dependencies > Build Integrity do Portal?"
- "Por que minha imagem aparece como 'legacy' em Build Integrity?"
- "Como habilito SBOM no meu build? Preciso de secret para o Dependency Track?"
- "Por que a aba Dependencias da minha aplicacao esta sem dados?"
- "O que significam os badges de proveniencia (atestado/publicado/desconhecido)?"
- "Minha aplicacao tem uma licenca AGPL sinalizada, o deploy vai bloquear?"

## Conhecimento Embutido

### Scan de Vulnerabilidades com Trivy

O Trivy e a ferramenta integrada aos pipelines de GitHub Actions do Karavela para realizar analise de seguranca de imagens de container. Ele detecta vulnerabilidades em pacotes do sistema operacional (Alpine, RHEL, Ubuntu, etc.) e dependencias de aplicativos (npm, yarn, etc.).

O scan e executado **antes** do push da imagem para o Registry (ECR), garantindo que imagens disponiveis para pull no cluster Kubernetes tenham minimamente um controle de seguranca.

Aplicacoes criadas a partir dos templates Karavela do Backstage ja possuem os manifestos e workflows necessarios para o scan de vulnerabilidades integrado automaticamente.

Atualmente, o scan possui **bloqueio ativo** para vulnerabilidades com as seguintes severidades: **CRITICAL**, **HIGH** e **UNKNOWN**.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/security.md`

### Remediacao de Vulnerabilidades

Quando o scan do Trivy identifica vulnerabilidades, primeiro analise se trata-se de vulnerabilidade de sistema operacional ou de alguma biblioteca/dependencia de linguagem especifica.

Para vulnerabilidades de sistema operacional, a correcao geralmente envolve atualizar a base image ou atualizar pacotes. Exemplos:

Atualizacao da base image:
```diff
- FROM golang:1.20-alpine
+ FROM golang:1.21-alpine
```

Atualizacao de pacotes especificos (Alpine/apk):
```Dockerfile
RUN apk update && apk upgrade pacote1 pacote2 pacote3
```

Atualizacao de todos os pacotes (Debian/apt):
```Dockerfile
RUN apt update -y && apt upgrade -y
```

**IMPORTANTE**: A maneira de atualizacao dos pacotes depende do gerenciador de pacotes do sistema operacional e da versao utilizada.

E recomendado utilizar imagens distroless com usuario nao-root para reduzir significativamente potenciais vulnerabilidades.

**Fonte**: `karavela/docs/erros_comuns.md` (secao "Build quebrou devido a vulnerabilidades na aplicacao") e `karavela/docs/faq/faq.md`

### Verificacao Local de Vulnerabilidades

E possivel verificar vulnerabilidades na imagem localmente antes de executar o pipeline. Existem duas formas:

Via Docker:
```bash
docker run --rm aquasec/trivy image nome-da-imagem:versao
```

Via binario Trivy instalado localmente:
```bash
trivy image nome-da-imagem:versao
```

**Fonte**: `karavela/docs/faq/faq.md`

### Excecoes no Scan do Trivy (.trivyignore)

Em alguns casos pode ser necessario adicionar excecoes nas analises do Trivy. Para isso, crie o arquivo `.trivyignore` na raiz do repositorio. O binario do Trivy ira ignorar automaticamente todas as entradas de CVE ou pacotes existentes nesse arquivo, sem necessidade de alteracao no workflow.

```yaml
# .trivyignore

# CVEs ignoradas
CVE-2019-14893
CVE-2020-8840

# Pacotes ignorados
loader-utils
golang.org/x/crypto
```

**IMPORTANTE**: A adicao de excecao **nao resolve** a vulnerabilidade. A aplicacao continuara vulneravel ate a correcao efetiva. A responsabilidade pela gerencia do arquivo e das vulnerabilidades e do owner da aplicacao. A criacao de excecoes nao e recomendada como pratica padrao.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/security.md`

### Politicas do Kyverno - Labels Obrigatorias

O Kyverno e uma solucao de Admission Controller no Kubernetes que aplica enforcements de configuracao e seguranca. Um dos bloqueios mais comuns no Karavela e a falta de labels ou valores incorretos nas labels que fazem parte da politica de tags da companhia.

Caso o deployment esteja faltando labels obrigatorias ou com valores incorretos, o pod ficara em estado **Pending** ou **Unhealthy** no ArgoCD.

Para corrigir, garanta que o arquivo `values-<env>.yaml` tenha as labels corretas:

```yaml
# values-<env>.yaml do diretorio chart
  labels:
    cost-center: "123456789"
    project: "my-awesome-project"
    owner: "my-owner"
    support: "my-support-team"
    github-org: "stone-payments"
    github-repo: "my-repo"
    env: "staging"
```

Os valores permitidos para cada label podem ser consultados no repositorio de politicas: `https://github.com/stone-payments/platform-k8s-policies/tree/main/policies/kyverno-policies`

Para identificar o bloqueio do Kyverno, verifique a aba de **events** do ArgoCD para o objeto (Pod ou Deployment) em questao.

**Fonte**: `karavela/docs/erros_comuns.md` (secao "Bloqueio de Deployment/Pod pelo Kyverno") e `karavela/docs/usando_karavela.md`

### Break Glass

O break glass e um mecanismo de acesso emergencial que permite operacoes privilegiadas em recursos criticos da plataforma. Ele esta disponivel para os seguintes tipos de recurso:

- **RDS** (instancias de banco de dados)
- **Elasticache/Valkey** (instancias de cache)
- **KafkaTopic** (topicos Kafka)

O break glass exige justificativa e aprovacao, e todas as acoes sao auditadas.

**IMPORTANTE**: A validacao de break glass e **ignorada para ambientes de staging**. Isso significa que em staging nao e necessario passar pelo fluxo de break glass para operacoes que normalmente o exigiriam em producao.

**Fonte**: Portal Karavela — fluxo de Break Glass; `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/security.md`

### Preflight Validation com OPA

A plataforma Karavela implementa validacao preflight baseada em **OPA (Open Policy Agent)** que e executada **antes** do provisionamento de recursos e antes de abrir o modal de criacao no Portal. Garante que os recursos atendam as politicas de seguranca e conformidade da organizacao.

O preflight valida a aplicacao contra **5 grupos de policies**:

1. `core` — campos basicos da app
2. `infrastructure` — IRSA, contexto, regiao, cluster
3. `labels` — 7 labels obrigatorias
4. `identity` — owner, group, package
5. `lifecycle` — estado da app (active/decommissioned)

**7 labels obrigatorias** validadas pelo Preflight:

| Label | Exemplo |
|-------|---------|
| `cost-center` | `820150020` |
| `env` | `production` |
| `github-org` | `stone-payments` |
| `github-repo` | `minha-api` |
| `owner` | `time-pagamentos` |
| `project` | `karavela` |
| `support` | `foundation-platform-cloud` |

Caso a validacao falhe, o provisionamento e bloqueado e o Portal mostra um banner com `field`, `message` e `code` indicando o que precisa ser corrigido. As mesmas labels sao validadas pelo Kyverno em runtime no cluster.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/security.md`; `karavela-core/plugins/karavela-preflight/` (complemento — nao em docs/) para detalhes de implementacao das policies

### Build Integrity (SLSA Level 3) — Supply-Chain Provenance

A plataforma agora gera **attestations SLSA Level 3** automaticamente para imagens construidas pelo workflow `karavela_build.yml` via `actions/attest-build-provenance`. Tambem gera **SBOM** por padrao.

**Como habilitar no seu repo**:

```yaml
# karavela_build_and_deploy.yaml (chamado workflow)
jobs:
  build:
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_build.yml@main
    permissions:
      contents: read
      packages: write
      id-token: write        # OBRIGATORIO para attestation
      attestations: write    # OBRIGATORIO

  deploy:
    needs: build
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_deploy.yml@main
    with:
      IMAGE_DIGEST: ${{ needs.build.outputs.image_digest }}   # OBRIGATORIO para persistir attestation
```

**Aba Dependencias > Build Integrity no Portal** exibe badge com estado:

| Estado | Significado |
|--------|-------------|
| `verified` | Attestation valido, imagem com SLSA L3 |
| `legacy` | Imagem criada antes do rollout da feature (sem atestacao formal) |
| `not_configured` | Workflow de build sem `id-token: write` / `attestations: write` |
| `regressed` | Aplicacao perdeu attestation apos ter ja sido `verified` |

Os dados sao persistidos pela plataforma e expostos na aba **Dependencias** da aplicacao no Portal.

**Nota sobre LGPD e ISO 27001**: sao politicas corporativas de seguranca da informacao da Stone, **nao controles tecnicos especificos do Karavela**. Para detalhes sobre esses frameworks, consulte a area de Seguranca da Informacao.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/dependencias/geracao-sbom-e-atestacao.md`; `karavela-core/docs/build-integrity/index.md` (complemento — nao em docs/)

### Dependencias e Supply Chain (SBOM, Dependency Track e Licencas)

Toda aplicacao implantada no Karavela ganha automaticamente um **SBOM** (inventario CycloneDX gerado com Syft a cada build) e **atestacoes SLSA** de integridade. Os dados alimentam o **Dependency Track** e ficam visiveis no Portal na aba **Dependencias** da aplicacao e no **Dependency Explorer** de portfolio.

**Inputs opcionais do `karavela_build.yml`** (sem secret novo — tudo via OIDC):
- `GENERATE_SBOM` (default `true`) — passe `false` para desligar SBOM + atestacao + upload ao Dependency Track.
- `DT_ENVIRONMENT` (default `prd`) — use `stg` para subir o SBOM ao Dependency Track de staging.

**Build vs deploy** — a cadeia acontece em dois momentos:
- **Build**: gera SBOM + atestacao SLSA L3 (`actions/attest@v4`, publicadas na GitHub Attestations API e como referrers OCI no ECR) e faz **upload ao Dependency Track** — consulta a KAPI pelas aplicacoes registradas contra a imagem ECR e sobe **um SBOM por aplicacao** (multiplexacao; cada app vira um projeto separado no DT). O build NAO aplica tags.
- **Deploy**: apos deploy bem-sucedido, aplica **tags enriquecidas** no projeto DT (`env`, `tier`, `owner`, `cost_center`, `namespace`, `kind:application`) derivadas do registro da aplicacao na KAPI. Ambiente registrado mas nunca deployado aparece com SBOM, mas sem as tags (nao polui dashboards); basta o primeiro deploy para as tags aparecerem.

**Registro na KAPI**: a multiplexacao exige a aplicacao registrada na KAPI com `image_repository` apontando para o ECR do build (registro automatico no primeiro deploy). Se o build rodar antes do primeiro deploy, o SBOM cai em naming de fallback (`{repo} [ecr:{name}]`); o naming correto e aplicado no proximo build pos-deploy.

**Aba Dependencias (Portal)**: cards de resumo (dependencias, versoes, atestados, vulnerabilidades por severidade), tabela com coluna **Proveniencia** (badges: `atestado` = pacote Karavela com proveniencia SLSA; `publicado` = pacote Karavela sem atestacao; `desconhecido` = nome no namespace Stone sem pacote registrado) e banner de **violacoes de licenca**. O botao **Ver no Explorer** abre o artefato no Dependency Explorer. Leitura via cache curto (~5 min).

**Licencas (aplicacoes)**: o Dependency Track avalia licencas das dependencias e sinaliza risco. Em aplicacoes so o **copyleft forte** e sinalizado (em especial AGPL); copyleft fraco (LGPL/MPL) nao e sinalizado em apps para evitar ruido. Violacao **nao bloqueia o deploy** — e sinal no Portal e no DT; a decisao fica com o time/Juridico.

**Troubleshooting**:
- Aba Dependencias "sem dados": confirme `id-token: write` + `attestations: write` no build e `id-token: write` no deploy; confirme que `GENERATE_SBOM` nao esta `false`; aguarde alguns minutos (processamento assincrono no DT).
- Integridade `not_configured`: workflow de **build** sem `id-token: write` ou `attestations: write` — adicione-as e refaca o build.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/dependencias/index.md`, `habilitando.md`, `geracao-sbom-e-atestacao.md`, `aba-dependencias.md`, `licencas.md`

### Sistema de Aprovacoes (Portal)

A plataforma Karavela aplica aprovacoes em operacoes sensiveis (criacao de recursos, deploy em producao, alteracao de secrets, etc.). A logica de aprovacao usa:

- **Scope elevation**: `primaryLevelManager` (gestor de primeiro nivel) ou `secondLevelManager` (gestor de segundo nivel).
- **Grupos**: aprovacao por times configurados via Slack, GitHub ou Backstage.
- **Usuarios individuais**: usuarios listados explicitamente que podem aprovar (email corporativo).
- **Cost Center**: aprovacao vinculada a centro de custo (numero do cost center + nivel hierarquico minimo).
- **Modos**: `AND` (todos os revisores precisam aprovar) ou `OR` (pelo menos N aprovadores).

Como dev, voce vera essas aprovacoes no Portal Karavela ou em PRs do GitHub. Voce nao configura esses fluxos diretamente — eles sao definidos pela plataforma e pelo time owner da aplicacao.

**Restricao especifica**: A criacao de `GatewayService` em producao requer aprovacao do gestor de primeiro nivel.

**Fonte**: Portal Karavela; `karavela/docs/guia-do-desenvolvedor/modelo-de-acessos.md` (modelo de acessos); `karavela-core` action `karavela:core:approval` (complemento — nao em docs/)

### Security Groups para RDS

Instancias RDS no Karavela suportam **multiplas regras de security group**, permitindo controle granular de acesso de rede ao banco de dados.

As regras de security group podem ser gerenciadas via **Portal** na pagina de detalhe do RDS, na aba **Security Group**. Cada regra possui os seguintes campos:

| Campo | Editavel | Valor |
|---|---|---|
| Type | Nao (readonly) | PostgreSQL |
| Protocol | Nao (readonly) | TCP |
| Port | Nao (readonly) | 5432 |
| Source/Destination | Sim | CIDR (ex: `10.0.0.0/24`) ou Security Group (ex: `sg-0abc123def456`) |
| Description | Sim | Descricao da regra |

E possivel adicionar varias regras para permitir acesso de diferentes origens (CIDRs ou security groups) ao mesmo RDS.

**Fonte**: Portal Karavela (pagina de detalhe do RDS, aba Security Group)

### ECR Multi-Region (us-east-1 e us-east-2)

Os repositorios ECR sao criados automaticamente em **duas regioes**: `us-east-1` e `us-east-2`. Isso garante suporte a **multi-region**, permitindo que imagens de container estejam disponiveis em ambas as regioes para pull nos clusters Kubernetes.

Nao e necessaria nenhuma configuracao adicional por parte do usuario. O provisionamento em ambas as regioes e automatico.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/multi-regiao.md`

### KubeArmor - Protecao em Runtime

O KubeArmor e um addon provisionado em todos os clusters Karavela, responsavel por seguranca e controle de acesso em tempo de execucao. Ele aplica politicas de seguranca e controle de acesso nos containers.

No contexto PCI, o KubeArmor atua especificamente no **monitoramento de integridade de arquivos**, detectando alteracoes nao autorizadas em arquivos sensiveis durante a operacao.

Para ambientes PCI, as politicas do KubeArmor sao habilitadas automaticamente pelo Karavela:

```yaml
# Parametro configurado automaticamente pelo Karavela para clusters PCI
platform-kubearmor-policies-chart:
  policiesPci:
    enabled: true
```

O recurso `KubeArmorPolicy` (grupo `security.kubearmor.com`) deve estar declarado no `namespaceResourceWhitelist` do AppProject da aplicacao:

```yaml
# Trecho do namespaceResourceWhitelist no project.yaml
namespaceResourceWhitelist:
  - group: security.kubearmor.com
    kind: KubeArmorPolicy
  - group: kyverno.io
    kind: Policy
```

**Fonte**: `karavela/docs/index.md` (tabela de addons), `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/pci.md` e `karavela/docs/guia-do-desenvolvedor/guias-e-manuais/upgrade-versao-chart.md`

### Controles de Seguranca no Fluxo CI/CD

O fluxo de CI/CD do Karavela conta com diversos controles de seguranca integrados em diferentes fases:

| Controle de Seguranca | Descricao | Fase |
|---|---|---|
| Revisao Manual de Codigo | Analise por pares para identificar problemas de seguranca | Desenvolvimento |
| Scan de Dependencias (Trivy) | Identificacao de vulnerabilidades em dependencias | Integracao Continua |
| Scan de Vulnerabilidades de Imagem (Trivy) | Scan de imagens de container para vulnerabilidades | Integracao Continua |
| Preflight Validation (OPA) | Validacao de politicas antes do provisionamento de recursos | Integracao Continua |
| Conformidade de Configuracao (Kyverno) | Aplicacao de politicas de seguranca nos manifestos Kubernetes | Deploy |
| Integridade das Imagens (Trivy, PrismaCloud) | Monitoramento da integridade das imagens de container | Deploy/Operacao |
| Runtime Security (PrismaCloud) | Monitoramento de seguranca em tempo de execucao | Operacao |
| Monitoramento de Integridade (KubeArmor) | Monitoramento de alteracoes nao autorizadas em arquivos sensiveis | Operacao |

**Fonte**: `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/pci.md`

### Temporal UI - Security Hardening

A interface web do Temporal possui write actions **desabilitadas** tanto em staging quanto em producao. Isso significa que acoes de escrita (como cancelar ou terminar workflows) **nao podem ser realizadas** diretamente pela UI do Temporal. Para essas operacoes, abra um chamado em **#help-foundation-platform**.

**Fonte**: Configuracao do Temporal UI (complemento — nao em docs/; restricao operacional)

### Requisitos de Tag de Imagem

O campo `image.tag` no arquivo `values-<env>.yaml` deve estar sempre preenchido corretamente. Caso esteja em branco, o ArgoCD nao conseguira fazer o pull da imagem, resultando em erro de referencia invalida.

As automacoes de build (`build_and_deploy_stg` e `build_and_deploy_prd.yaml`) possuem um step que realiza o commit automatico da tag da imagem no arquivo de values. Garanta que essas actions tenham sido executadas com sucesso.

```yaml
# values-<env>.yaml - exemplo correto
image:
  repository: "697525377503.dkr.ecr.us-east-1.amazonaws.com/myapp"
  pullPolicy: IfNotPresent
  tag: "v1.2.3"  # NUNCA deixe este campo vazio
```

**Fonte**: `karavela/docs/erros_comuns.md` (secao "Arquivo de values esta com o campo image.tag em branco")

### CiliumNetworkPolicy

Os charts verificam automaticamente a existencia do Cilium no cluster. Quando presente, aplicam `CiliumNetworkPolicy` no lugar da `NetworkPolicy` padrao do Kubernetes, oferecendo controle de trafego mais granular com suporte a L7 (HTTP, gRPC, Kafka).

O recurso `CiliumNetworkPolicy` (grupo `cilium.io`) deve estar declarado no `namespaceResourceWhitelist` do AppProject da aplicacao:

```yaml
# Trecho do namespaceResourceWhitelist no project.yaml
namespaceResourceWhitelist:
  - group: cilium.io
    kind: CiliumNetworkPolicy
```

Para ambientes PCI, o chart `platform-cilium-network-policies-pci` e adicionado como dependencia automaticamente.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/pci.md`, `redes.md`; `platform-k8s-charts/.docs/CHANGELOG.api.md` (v1.8.0, v1.10.0) (complemento — nao em docs/)

### Gestao de Acessos via Sailpoint

A gestao de acessos a plataforma e recursos do Karavela e realizada via **Sailpoint**. Todas as solicitacoes de acesso, revisoes de permissao e certificacoes de acesso sao gerenciadas pela plataforma Sailpoint.

A URL da plataforma Atlassian utilizada para documentacao e gestao de projetos e: `allstone.atlassian.net`.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/modelo-de-acessos.md`; Sailpoint (plataforma de gestao de acessos)

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever; producao exige dupla confirmacao. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Editar `chart/values-*.yaml`** — adicionar/corrigir as 7 labels obrigatorias (cost-center, env, github-org, github-repo, owner, project, support)
- **Editar `.trivyignore`** — adicionar excecoes pontuais (com motivo + CVE) — sempre confirmar e justificar
- **Editar `.github/workflows/karavela_build.yml`** — habilitar SLSA L3 Build Integrity (permissions `id-token: write`, `attestations: write`)
- **Editar `karavela_deploy.yml`** — passar `IMAGE_DIGEST: ${{ needs.build.outputs.image_digest }}`
- **Rodar KLI** — `kli check app <nome>` para verificar policy violations, `kli get events` para Kyverno errors
- **NAO** desabilitar Kyverno/Trivy/KubeArmor policies
- **NAO** propor bypass de scans

### Triggers proativos
- "Kyverno bloqueou meu deploy" → identificar label faltando + `🛠️ Acao proposta: adiciono label X em values-stg.yaml`
- "Trivy bloqueou build" → analisar CVEs e propor bump de base image OU `.trivyignore` justificado
- "Build Integrity not_configured" → propor patch dos workflows com permissions corretas
- "Preflight falhou" → identificar campo + propor correcao

### Acoes destrutivas (dupla confirmacao)
- Adicionar excecao em `.trivyignore` — sempre exige `# motivo: <texto>` no commit. Dupla confirmacao em prd.
- Pedir break glass — apenas instruir (e via Portal Karavela + aprovacoes).

## Instrucoes MCP

Quando você ainda não estiver certeza da resposta use o GITHUB mcp. Priorize a documentacao oficial em `stone-payments/karavela` `docs/`; outros repositorios servem apenas como fallback.

**Fontes primarias (docs/):**

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/seguranca-e-conectividade/security.md` | Trivy, Kyverno, KubeArmor, preflight |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/dependencias/` | SBOM, atestacoes SLSA, Dependency Track, GENERATE_SBOM/DT_ENVIRONMENT, aba Dependencias, licencas |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/seguranca-e-conectividade/pci.md` | Controles de seguranca PCI, Cilium policies PCI |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/funcionalidades/security-context.md` | SecurityContext, runAsUser, runAsGroup |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/modelo-de-acessos.md` | Gestao de acessos, Sailpoint, aprovacoes |
| `stone-payments/karavela` | `docs/erros_comuns.md` | Erros comuns: Kyverno, Trivy, image.tag, IRSA |

**Fontes secundarias (complemento — nao em docs/):**

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/platform-k8s-policies` | `policies/kyverno-policies/` | Valores permitidos para labels e detalhes de politicas Kyverno |
| `stone-payments/platform-k8s-github-actions` | `.github/workflows/` | Detalhes do workflow de build, scan Trivy ou configuracao do pipeline |
| `stone-payments/platform-k8s-charts` | `platform-k8s-api-chart/values.yaml` | Configuracao de seguranca no chart (KubeArmor, labels, etc.) |
| `stone-payments/platform-k8s-docs` | `PCI/controles-de-seguranca.md` | Detalhes adicionais sobre controles de seguranca PCI |
| `stone-payments/karavela-core` | `docs/build-integrity/index.md` | Build Integrity (SLSA L3) — endpoint, persistencia |

## Formato de Resposta

Ao responder perguntas deste dominio, siga este formato:

1. **Explicacao** (2-3 frases objetivas em PT-BR)
2. **Exemplo pratico** (YAML, comando ou config copiavel)
3. **Fonte** (referencia ao arquivo/secao da documentacao)
4. **Avisos** (se aplicavel: restricoes de ambiente, privilegios necessarios)

---
name: unit-testing-golang
description: 'Boas práticas de teste unitário para Go (Golang). Use quando precisar criar ou revisar testes unitários em Go, usar mocks, stubs, spies com testify/mock ou gomock, banco em memória com SQLite ou repositórios fake, validar interações com doubles de teste, ou escrever testes resistentes a mutation testing com go-mutesting ou gremlins.'
---

# Testes Unitários — Go (Golang)

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.

  Exemplos de uso:
  - Corrigir informacao desatualizada no conhecimento embutido
  - Adicionar restricao temporaria (ex: "versao X do testify nao suporta feature Y")
  - Adicionar conhecimento que ainda nao esta na documentacao oficial
  - Bloquear uma orientacao especifica (ex: "NAO use go-sqlmock neste projeto")
-->

## Escopo

**Cobre**: criar testes unitários em Go, mocks e stubs com `testify/mock`, geração de mocks com `gomock`/`mockgen`, repositórios InMemory thread-safe, banco SQLite em memória para testes de repositório, table-driven tests, padrões resistentes a mutation testing (`go-mutesting`, `gremlins`), doubles de teste (mocks, stubs, spies, fakes)

**NAO cobre**: escrita de código de produção, configuração de pipeline de CI/coverage (coberto por `ci-test-coverage-golang`), testes de integração com banco real, configuração de mutation testing no CI (coberto por `ci-mutation-testing-golang`)

## Exemplos de Perguntas

- "Como criar um mock com testify/mock para uma interface de repositório em Go?"
- "Como usar gomock para verificar que um método foi chamado exatamente uma vez?"
- "Como configurar um banco SQLite em memória para testes de repositório em Go?"
- "Como estruturar um repositório InMemory thread-safe para testes unitários?"
- "Como escrever table-driven tests que sobrevivam ao mutation testing com go-mutesting?"
- "Quais anti-patterns devo evitar nos meus testes unitários em Go?"
- "Qual a diferença entre mock, stub, spy e fake? Quando usar cada um?"

## Conhecimento Embutido

### Quando Usar
- Criar testes unitários em projetos Go
- Usar doubles de teste: mocks, stubs, spies com `testify/mock` ou `gomock`
- Configurar banco em memória com SQLite ou repositórios fake (InMemory)
- Garantir que os testes sobrevivam a testes de mutação (`go-mutesting`, `gremlins`)

### Ferramentas e Dependências

```bash
go get github.com/stretchr/testify@latest     # assert, require, mock, suite
go get go.uber.org/mock/mockgen@latest         # geração de mocks via interface (gomock)
go get github.com/DATA-DOG/go-sqlmock@latest   # mock de banco SQL
go get github.com/mattn/go-sqlite3@latest      # SQLite em memória (cgo)
# ou sem cgo:
go get modernc.org/sqlite@latest
```

Gerar mocks com `mockgen`:

```bash
mockgen -source=internal/ports/user_repository.go -destination=internal/mocks/mock_user_repository.go -package=mocks
```

### Workflow de Criação de Testes

### 1. Identificar Dependências
- Liste todas as interfaces que a struct recebe via construtor
- Classifique: stub (retorna dado controlado), mock (verifica chamada), spy (envolve real), fake (implementação funcional)

### 2. Montar os Doubles

```go
// Com testify/mock (preferível para projetos sem geração de código)
type MockUserRepository struct {
    mock.Mock
}

func (m *MockUserRepository) FindByID(id string) (*User, error) {
    args := m.Called(id)
    return args.Get(0).(*User), args.Error(1)
}

func (m *MockUserRepository) Save(user *User) error {
    args := m.Called(user)
    return args.Error(0)
}

// Stub: configura retorno
repoMock := new(MockUserRepository)
repoMock.On("FindByID", "1").Return(&User{ID: "1", Name: "Ana"}, nil)

// Mock: verificará chamada após o Act
emailMock := new(MockEmailSender)
emailMock.On("Send", mock.Anything).Return(nil)
```

### 3. Estrutura AAA (Arrange / Act / Assert)

```go
func TestActivateUserUseCase_ShouldSendEmail_WhenUserIsActivated(t *testing.T) {
    // Arrange
    userID := "user-123"

    repoMock := new(MockUserRepository)
    repoMock.On("FindByID", userID).Return(&User{ID: userID, Name: "Ana", Active: false}, nil)
    repoMock.On("Save", mock.MatchedBy(func(u *User) bool { return u.Active })).Return(nil)

    emailMock := new(MockEmailSender)
    emailMock.On("Send", mock.MatchedBy(func(e Email) bool { return e.To == "Ana" })).Return(nil)

    useCase := NewActivateUserUseCase(repoMock, emailMock)

    // Act
    err := useCase.Execute(userID)

    // Assert
    require.NoError(t, err)
    emailMock.AssertNumberOfCalls(t, "Send", 1)               // exato
    repoMock.AssertNumberOfCalls(t, "Save", 1)                // exato
    emailMock.AssertExpectations(t)                           // todos os On() foram chamados
    repoMock.AssertExpectations(t)
}
```

### 4. Validação de Spies (Call Assertions)

```go
// Verificar quantidade exata (crítico para mutation testing)
mock.AssertNumberOfCalls(t, "Send", 1)
mock.AssertNotCalled(t, "SendBulk")

// Verificar argumentos com MatchedBy
repoMock.On("Save", mock.MatchedBy(func(u *User) bool {
    return u.Active == true && u.Name == "Ana"
})).Return(nil)

// Capturar argumento com Run
var capturedUser *User
repoMock.On("Save", mock.Anything).
    Run(func(args mock.Arguments) {
        capturedUser = args.Get(0).(*User)
    }).
    Return(nil)

// Act
useCase.Execute(userID)

// Assert no argumento capturado
require.NotNil(t, capturedUser)
assert.True(t, capturedUser.Active)           // assert.True para bool
assert.Equal(t, "Ana", capturedUser.Name)     // assert.Equal com valor exato
```

### 5. Banco em Memória

```go
// Fake Repository (preferível para testes unitários puros)
type InMemoryUserRepository struct {
    store map[string]*User
    mu    sync.RWMutex
}

func NewInMemoryUserRepository() *InMemoryUserRepository {
    return &InMemoryUserRepository{store: make(map[string]*User)}
}

func (r *InMemoryUserRepository) FindByID(id string) (*User, error) {
    r.mu.RLock()
    defer r.mu.RUnlock()
    u, ok := r.store[id]
    if !ok {
        return nil, ErrNotFound
    }
    return u, nil
}

func (r *InMemoryUserRepository) Save(user *User) error {
    r.mu.Lock()
    defer r.mu.Unlock()
    r.store[user.ID] = user
    return nil
}

func (r *InMemoryUserRepository) FindAll() ([]*User, error) {
    r.mu.RLock()
    defer r.mu.RUnlock()
    users := make([]*User, 0, len(r.store))
    for _, u := range r.store {
        users = append(users, u)
    }
    return users, nil
}

func (r *InMemoryUserRepository) Delete(id string) (bool, error) {
    r.mu.Lock()
    defer r.mu.Unlock()
    _, ok := r.store[id]
    delete(r.store, id)
    return ok, nil
}

// Uso nos testes
func TestUserService_FindAll(t *testing.T) {
    repo := NewInMemoryUserRepository()
    repo.Save(&User{ID: "1", Name: "Ana"})
    repo.Save(&User{ID: "2", Name: "Bruno"})

    svc := NewUserService(repo)
    result, err := svc.FindAll()

    require.NoError(t, err)
    assert.Len(t, result, 2)  // Len, não len(result) > 0
}
```

### 6. SQLite em Memória (testes de repositório)

```go
import (
    "database/sql"
    _ "modernc.org/sqlite"
    "testing"
)

func setupTestDB(t *testing.T) *sql.DB {
    t.Helper()
    db, err := sql.Open("sqlite", ":memory:")
    require.NoError(t, err)

    _, err = db.Exec(`
        CREATE TABLE orders (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            total REAL NOT NULL,
            status TEXT DEFAULT 'PENDING'
        )
    `)
    require.NoError(t, err)
    t.Cleanup(func() { db.Close() })
    return db
}

func TestOrderRepository_Save(t *testing.T) {
    db := setupTestDB(t)
    repo := NewOrderRepository(db)

    order := &Order{ID: "ord-1", UserID: "user-1", Total: 150.0}
    err := repo.Save(order)

    require.NoError(t, err)
    found, err := repo.FindByID("ord-1")
    require.NoError(t, err)
    assert.Equal(t, "PENDING", found.Status)
    assert.Equal(t, 150.0, found.Total)
}
```

### 7. Setup com t.Run e Table-Driven Tests

```go
func TestCalculateDiscount(t *testing.T) {
    tests := []struct {
        name             string
        price            float64
        expectedDiscount float64
    }{
        {"above threshold", 100.01, 10.0},
        {"at threshold", 100.00, 10.0},
        {"below threshold", 99.99, 0.0},
    }

    for _, tc := range tests {
        t.Run(tc.name, func(t *testing.T) {
            result := svc.CalculateDiscount(tc.price)
            assert.Equal(t, tc.expectedDiscount, result) // valor exato
        })
    }
}
```

### 8. Regras para Mutation Testing

Consulte [mutation-friendly.md](./references/mutation-friendly.md).

### Padrões de Nome de Teste

```
Test<Struct>_<Resultado>_<Condição>
Test<Func>_<Cenário>
```

Exemplos:
```go
func TestActivateUserUseCase_ShouldThrowNotFound_WhenUserDoesNotExist(t *testing.T) {}
func TestUserService_ShouldReturnEmpty_WhenRepositoryHasNoUsers(t *testing.T) {}
func TestCalculateDiscount_AtBoundary_AppliesDiscount(t *testing.T) {}
```

### Anti-patterns

- `if err != nil { t.Fatal(err) }` em vez de `require.NoError(t, err)`
- `assert.NotNil(t, result)` sem assertivas no conteúdo de `result`
- `mock.On("Method", mock.Anything)` em Verify quando os argumentos importam
- Não chamar `mock.AssertExpectations(t)` ao final do teste

### Referências

- [Doubles de Teste (mocks, stubs, spies, fakes)](./references/doubles.md)
- [Padrões Resistentes a Mutation Testing](./references/mutation-friendly.md)

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Escrever arquivos de teste** Go (`*_test.go`) — table-driven, com testify/mock ou gomock
- **Editar testes existentes** — assertions especificas (testify/assert) resistentes a go-mutesting/gremlins
- **Adicionar fakes** (SQLite in-memory, fake repositories)
- **Editar `go.mod`** com `testify`, `mockery`, `gomock`
- **Gerar mocks** via `mockery` ou `mockgen` (orientar comando)
- **Abrir PR draft**

### Triggers proativos
- "Escreva testes Go para X" → propor suite table-driven
- "Mock pra essa interface" → propor uso de mockery/gomock
- "go-mutesting matou meu teste" → propor assertions mais especificas

### Acoes destrutivas
- Deletar testes — confirmar.

## Instrucoes MCP

Quando o usuario precisar de informacoes detalhadas alem do
conhecimento embutido, busque nos seguintes repositorios (nesta ordem de prioridade):

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/karavela` | `docs/` | Padroes da plataforma (nao cobre unit testing diretamente) |
| `stone-payments/github-actions-workflows` | `**/test-coverage-golang*` | Configuracao de cobertura e relatorios de CI para Go |
| Externo (complemento — nao em docs/) | [testify docs](https://pkg.go.dev/github.com/stretchr/testify), [gomock](https://github.com/uber-go/mock) | API de mocks/spies, geracao de mocks, configuracao avancada |

> Todo o conhecimento desta skill e **complemento** ao docs/ da plataforma — ela nao tem secao dedicada a unit testing.

## Formato de Resposta

Ao responder perguntas deste dominio, siga este formato:

1. **Explicacao** (2-3 frases objetivas em PT-BR)
2. **Exemplo pratico** (codigo Go copiavel com comentarios AAA ou inline)
3. **Fonte** (referencia ao arquivo/secao da documentacao ou referencia desta skill)
4. **Avisos** (se aplicavel: dependencias necessarias, flags de build como cgo, restricoes de versao)

# Doubles de Teste — Go com testify/mock e gomock

## Hierarquia de Double

| Double | Quando Usar | Go |
|--------|-------------|-----|
| **Dummy** | Parâmetro obrigatório sem importância | `new(MockX)` sem `On(...)` |
| **Stub** | Controlar retorno da dependência | `mock.On("Method", ...).Return(...)` |
| **Spy** | Capturar e verificar chamadas | `mock.On(...).Run(func(args) {...})` |
| **Mock** | Verificar interações exatas | `mock.AssertNumberOfCalls(t, ..., N)` |
| **Fake** | Implementação funcional (InMemory) | Struct manual com `map` |

## Stubs com testify/mock

```go
// Definir o mock (ou gerar com mockery/mockgen)
type MockOrderRepository struct {
    mock.Mock
}

func (m *MockOrderRepository) FindByID(id string) (*Order, error) {
    args := m.Called(id)
    if args.Get(0) == nil {
        return nil, args.Error(1)
    }
    return args.Get(0).(*Order), args.Error(1)
}

func (m *MockOrderRepository) Save(order *Order) error {
    return m.Called(order).Error(0)
}

// Configurar retornos (stub)
repoMock := new(MockOrderRepository)

// Retorno fixo
repoMock.On("FindByID", "ord-1").Return(&Order{ID: "ord-1", Total: 150.0}, nil)

// Retorno nil (not found)
repoMock.On("FindByID", "ghost").Return(nil, ErrNotFound)

// Lança erro
repoMock.On("Save", mock.Anything).Return(errors.New("db unavailable"))

// Retorno dinâmico com Return(func)
repoMock.On("FindByID", mock.AnythingOfType("string")).
    Return(func(id string) *Order { return &Order{ID: id} }, nil)
```

## Mocks: Verificar Interações

```go
emailMock := new(MockEmailSender)
emailMock.On("Send", mock.Anything).Return(nil)

// ... executa o código sob teste ...

// Verificação de quantidade exata (crítico para mutation testing)
emailMock.AssertNumberOfCalls(t, "Send", 1)
emailMock.AssertNotCalled(t, "SendBulk")

// Verificar que TODOS os On() foram satisfeitos
emailMock.AssertExpectations(t)

// Verificar argumento com MatchedBy
repoMock.On("Save", mock.MatchedBy(func(o *Order) bool {
    return o.Status == "APPROVED" && o.Total > 0
})).Return(nil)

// Verificar argumento com AnythingOfType
loggerMock.On("Log", mock.AnythingOfType("string"), mock.Anything).Return()
```

## Spy: Capturar Argumentos com Run

```go
var capturedOrder *Order
repoMock.On("Save", mock.Anything).
    Run(func(args mock.Arguments) {
        capturedOrder = args.Get(0).(*Order)
    }).
    Return(nil)

// Act
err := service.Checkout(cartID)

// Assert no spy capturado
require.NoError(t, err)
require.NotNil(t, capturedOrder)
assert.Equal(t, "PENDING", capturedOrder.Status)    // valor exato
assert.Equal(t, 3, len(capturedOrder.Items))         // quantidade exata
assert.Equal(t, "user-1", capturedOrder.UserID)

// Capturar múltiplas chamadas
var capturedEmails []Email
emailMock.On("Send", mock.Anything).
    Run(func(args mock.Arguments) {
        capturedEmails = append(capturedEmails, args.Get(0).(Email))
    }).
    Return(nil)

// Assert
assert.Len(t, capturedEmails, 2)
assert.Equal(t, "ana@email.com", capturedEmails[0].To)
assert.Equal(t, "Boas-vindas", capturedEmails[0].Subject)
```

## gomock (para projetos com geração automática)

```bash
# Gerar mock de interface
mockgen -source=internal/ports/repository.go \
        -destination=internal/mocks/mock_repository.go \
        -package=mocks
```

```go
import (
    "testing"
    "go.uber.org/mock/gomock"
    "myapp/internal/mocks"
)

func TestActivateUser(t *testing.T) {
    ctrl := gomock.NewController(t) // automaticamente verifica no t.Cleanup
    defer ctrl.Finish()

    repoMock := mocks.NewMockUserRepository(ctrl)
    emailMock := mocks.NewMockEmailSender(ctrl)

    // Stub
    repoMock.EXPECT().
        FindByID("user-1").
        Return(&User{ID: "user-1", Name: "Ana"}, nil)

    // Verificação de chamada exata (Times é obrigatório para ser preciso)
    repoMock.EXPECT().
        Save(gomock.Any()).
        Times(1).
        Return(nil)

    emailMock.EXPECT().
        Send(gomock.Any()).
        Times(1).
        Return(nil)

    // Verificar argumento com matcher customizado
    emailMock.EXPECT().
        Send(gomock.AssignableTo(reflect.TypeOf(Email{}))).
        DoAndReturn(func(e Email) error {
            assert.Equal(t, "Ana", e.To)
            return nil
        }).
        Times(1)

    useCase := NewActivateUserUseCase(repoMock, emailMock)
    err := useCase.Execute("user-1")
    require.NoError(t, err)
}
```

## Fake Repository (In-Memory)

```go
// Implementação completa e thread-safe
type InMemoryProductRepository struct {
    mu    sync.RWMutex
    store map[string]*Product
}

func NewInMemoryProductRepository() *InMemoryProductRepository {
    return &InMemoryProductRepository{store: make(map[string]*Product)}
}

func (r *InMemoryProductRepository) Save(p *Product) error {
    r.mu.Lock()
    defer r.mu.Unlock()
    clone := *p // evita aliasing
    r.store[p.ID] = &clone
    return nil
}

func (r *InMemoryProductRepository) FindByID(id string) (*Product, error) {
    r.mu.RLock()
    defer r.mu.RUnlock()
    p, ok := r.store[id]
    if !ok {
        return nil, ErrNotFound
    }
    clone := *p
    return &clone, nil
}

func (r *InMemoryProductRepository) FindAll() ([]*Product, error) {
    r.mu.RLock()
    defer r.mu.RUnlock()
    result := make([]*Product, 0, len(r.store))
    for _, p := range r.store {
        clone := *p
        result = append(result, &clone)
    }
    return result, nil
}

func (r *InMemoryProductRepository) Delete(id string) (bool, error) {
    r.mu.Lock()
    defer r.mu.Unlock()
    _, exists := r.store[id]
    delete(r.store, id)
    return exists, nil
}

// Helper para testes
func (r *InMemoryProductRepository) Clear() {
    r.mu.Lock()
    defer r.mu.Unlock()
    r.store = make(map[string]*Product)
}
```

## go-sqlmock (mock de banco SQL)

```go
import (
    "database/sql"
    "testing"
    sqlmock "github.com/DATA-DOG/go-sqlmock"
)

func TestOrderRepository_FindByID(t *testing.T) {
    db, mock, err := sqlmock.New(sqlmock.QueryMatcherOption(sqlmock.QueryMatcherExact))
    require.NoError(t, err)
    defer db.Close()

    rows := sqlmock.NewRows([]string{"id", "user_id", "total", "status"}).
        AddRow("ord-1", "user-1", 150.0, "PENDING")

    mock.ExpectQuery("SELECT id, user_id, total, status FROM orders WHERE id = ?").
        WithArgs("ord-1").
        WillReturnRows(rows)

    repo := NewOrderRepository(db)
    order, err := repo.FindByID("ord-1")

    require.NoError(t, err)
    assert.Equal(t, "ord-1", order.ID)
    assert.Equal(t, 150.0, order.Total)
    assert.Equal(t, "PENDING", order.Status)

    // Verifica que todas as expectations foram satisfeitas
    require.NoError(t, mock.ExpectationsWereMet())
}
```

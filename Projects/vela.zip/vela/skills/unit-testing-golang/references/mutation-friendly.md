# Padrões Resistentes a Mutation Testing — Go

## Por que Mutation Testing Importa

Ferramentas como `go-mutesting` e `gremlins` injetam mutações (ex: `>` → `>=`, `true` → `false`, `+` → `-`, `return err` → `return nil`, `&&` → `||`) e verificam se algum teste falha. Testes fracos deixam mutantes sobreviver.

## Regras Fundamentais

### 1. Assertivas Exatas de Valor

```go
// ❌ Mata poucos mutantes
assert.NotNil(t, result)
assert.True(t, result.Active)
assert.Greater(t, len(result.Items), 0)

// ✅ Mata mutantes de valor e lógica
assert.Equal(t, "APPROVED", result.Status)   // string exata
assert.Equal(t, true, result.Active)          // bool exato (não apenas assert.True)
assert.Len(t, result.Items, 3)               // Len, não > 0
assert.Equal(t, 150.0, result.Total)
```

### 2. AssertNumberOfCalls com Número Exato

```go
// ❌ Passa mesmo que o método seja chamado 0 ou 2 vezes
emailMock.AssertCalled(t, "Send", mock.Anything)

// ✅ Mata mutantes de fluxo de controle
emailMock.AssertNumberOfCalls(t, "Send", 1)
emailMock.AssertNotCalled(t, "SendBulk")

// gomock equivalente
emailMock.EXPECT().Send(gomock.Any()).Times(1)
repoMock.EXPECT().Save(gomock.Any()).Times(0) // nunca
```

### 3. Sempre chamar AssertExpectations

```go
// No final de CADA teste com testify/mock
defer repoMock.AssertExpectations(t)
defer emailMock.AssertExpectations(t)

// Garante que todos os On() configurados foram satisfeitos
// Pega mutantes que removem chamadas inteiras
```

### 4. Testar Todos os Branches

```go
// ❌ Só o caminho feliz — mutante no if sobrevive
func TestActivateUser(t *testing.T) {
    result, err := useCase.Execute("user-1")
    assert.NoError(t, err)
    assert.True(t, result.Active)
}

// ✅ Um teste por branch
func TestActivateUser_ShouldReturnActivatedUser_WhenUserExists(t *testing.T) {
    repoMock.On("FindByID", "user-1").Return(&User{ID: "user-1", Active: false}, nil)
    repoMock.On("Save", mock.MatchedBy(func(u *User) bool { return u.Active })).Return(nil)

    result, err := useCase.Execute("user-1")

    require.NoError(t, err)
    assert.Equal(t, true, result.Active)
    repoMock.AssertNumberOfCalls(t, "Save", 1)
}

func TestActivateUser_ShouldReturnError_WhenUserNotFound(t *testing.T) {
    repoMock.On("FindByID", "ghost").Return(nil, ErrNotFound)

    _, err := useCase.Execute("ghost")

    require.Error(t, err)
    assert.ErrorIs(t, err, ErrNotFound)      // ErrorIs, não apenas assert.Error
    repoMock.AssertNotCalled(t, "Save")      // garante que não salvou
}
```

### 5. Assertivas em Todos os Campos Relevantes

```go
// ❌ Verifica apenas parte do objeto
order, err := service.Create(request)
require.NoError(t, err)
assert.NotEmpty(t, order.ID)

// ✅ Verifica todos os campos afetados pela lógica
order, err := service.Create(request)
require.NoError(t, err)
assert.NotEmpty(t, order.ID)
assert.Equal(t, "PENDING", order.Status)
assert.Equal(t, request.UserID, order.UserID)
assert.Equal(t, request.Total, order.Total)
assert.WithinDuration(t, time.Now(), order.CreatedAt, 5*time.Second)
```

### 6. Testar Limites com Table-Driven Tests

```go
// Para `if price > 100.0` — table-driven testa os valores fronteiriços
func TestCalculateDiscount(t *testing.T) {
    tests := []struct {
        name             string
        price            float64
        expectedDiscount float64
    }{
        {"above_threshold", 100.01, 10.0},
        {"at_threshold", 100.00, 10.0},  // testa se é >= ou >
        {"below_threshold", 99.99, 0.0},
        {"zero_price", 0.0, 0.0},        // edge case
    }
    for _, tc := range tests {
        t.Run(tc.name, func(t *testing.T) {
            result := svc.CalculateDiscount(tc.price)
            assert.Equal(t, tc.expectedDiscount, result) // Equal, não InDelta desnecessário
        })
    }
}
```

### 7. Validar Slices — Len + Conteúdo

```go
// ❌ Mutante `return nil, nil` sobrevive
result, err := service.FindAll()
require.NoError(t, err)
assert.NotNil(t, result)

// ✅
result, err := service.FindAll()
require.NoError(t, err)
assert.Len(t, result, 2)
assert.Equal(t, "Ana", result[0].Name)
assert.Equal(t, "Bruno", result[1].Name)

// Caso vazio — teste dedicado
result, err := service.FindAll() // sem dados
require.NoError(t, err)
assert.Empty(t, result)          // assert.Empty, não apenas assert.NotNil
```

### 8. Usar require vs assert com Intencionalidade

```go
// require: falha e interrompe o teste — use quando o restante não faz sentido sem isso
require.NoError(t, err)         // se tem erro, o resto do teste seria inválido
require.NotNil(t, result)       // se nil, acessar campos daria panic

// assert: falha mas continua — use para verificar múltiplas propriedades
assert.Equal(t, "PENDING", result.Status)
assert.Equal(t, 150.0, result.Total)
assert.Equal(t, "user-1", result.UserID)
// Todos os asserts são reportados mesmo que o primeiro falhe
```

### 9. Verificar Erro Específico com ErrorIs/ErrorAs

```go
// ❌ Apenas verifica que tem erro — mutante no tipo sobrevive
require.Error(t, err)

// ✅ Verifica tipo exato e mensagem
require.Error(t, err)
assert.ErrorIs(t, err, ErrNotFound)          // sentinela exata

// Para erros com contexto
var validationErr *ValidationError
assert.ErrorAs(t, err, &validationErr)
assert.Equal(t, "email", validationErr.Field)
assert.Contains(t, validationErr.Message, "invalid")
```

### 10. Assertivas em Argumentos Capturados com Run

```go
var capturedUser *User
repoMock.On("Save", mock.Anything).
    Run(func(args mock.Arguments) {
        capturedUser = args.Get(0).(*User)
    }).Return(nil)

useCase.Execute(userID)

// Assertivas detalhadas no argumento (mata mutantes de dados passados)
require.NotNil(t, capturedUser)
assert.Equal(t, true, capturedUser.Active)        // exato
assert.Equal(t, "Ana", capturedUser.Name)
assert.Equal(t, "ACTIVATED", capturedUser.Status)
assert.WithinDuration(t, time.Now(), capturedUser.UpdatedAt, 5*time.Second)
```

## Checklist Antes de Commitar

- [ ] Toda assertiva usa `assert.Equal(t, expected, actual)` com valor exato
- [ ] `AssertNumberOfCalls(t, method, N)` com número exato em todos os mocks relevantes
- [ ] `AssertNotCalled(t, method)` para caminhos onde mock NÃO deve ser chamado
- [ ] `AssertExpectations(t)` no final de cada teste com testify/mock
- [ ] Existe `t.Run(...)` ou teste separado para cada branch `if/switch/case`
- [ ] Table-driven tests cobrem os valores fronteiriços das condições
- [ ] Slices verificam `Len` E membros específicos
- [ ] Retorno `nil` / slice vazio / `false` / `0` têm teste específico
- [ ] Erros verificados com `ErrorIs` ou `ErrorAs`, não apenas `require.Error`
- [ ] `require` usado quando o restante do teste depende do resultado; `assert` para verificações independentes

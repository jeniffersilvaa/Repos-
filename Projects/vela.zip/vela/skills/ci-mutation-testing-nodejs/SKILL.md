---
name: ci-mutation-testing-nodejs
description: "Testes de mutacao para projetos Node.js / TypeScript usando o workflow reutilizavel nodejs-mutanting. Use quando o usuario perguntar sobre como adicionar testes de mutacao em Node.js ou TypeScript, configurar o Stryker, integrar com o workflow reutilizavel, threshold de MSI, diff_mode ou envio de metricas de mutacao ao Kafka."
---

# Skill: Mutation Testing — Node.js / TypeScript / Stryker

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.
-->

> ### ⚠️ Pré-requisito: Acesso às Org Secrets de Kafka
>
> Para usar os secrets de Kafka, **adicione o nome do repositório do seu projeto** em todos os arquivos abaixo no repositório `stone-payments/terraform-github` (via Pull Request para revisão):
>
> Caminho base: `applications/org-secrets/stone-payments/secrets.installation.d/`
>
> | Arquivo YAML | Nome da org secret | Input do workflow |
> |---|---|---|
> | `QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD.yaml` | `QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD` | `KAFKA_BROKER_URL` |
> | `QA_MATURITY_KAFKA_SASL_USERNAME_PRD.yaml` | `QA_MATURITY_KAFKA_SASL_USERNAME_PRD` | `KAFKA_SASL_USERNAME` |
> | `QA_MATURITY_KAFKA_SASL_PASSWORD_PRD.yaml` | `QA_MATURITY_KAFKA_SASL_PASSWORD_PRD` | `KAFKA_SASL_PASSWORD` |
> | `QA_MATURITY_KAFKA_SCHEMA_ENDPOINT_PRD.yaml` | `QA_MATURITY_KAFKA_SCHEMA_ENDPOINT` ⚠️ (sem `_PRD`) | `KAFKA_SCHEMA_ENDPOINT` |
> | `QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD.yaml` | `QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD` | `KAFKA_SCHEMA_USERNAME` |
> | `QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD.yaml` | `QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD` | `KAFKA_SCHEMA_PASSWORD` |
>
> Ao chamar o workflow, mapeie as org secrets para os inputs corretamente:
>
> ```yaml
> secrets:
>   KAFKA_BROKER_URL: ${{ secrets.QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD }}
>   KAFKA_SASL_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SASL_USERNAME_PRD }}
>   KAFKA_SASL_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SASL_PASSWORD_PRD }}
>   KAFKA_SCHEMA_ENDPOINT: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_ENDPOINT }}
>   KAFKA_SCHEMA_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD }}
>   KAFKA_SCHEMA_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD }}
> ```

## Escopo

**Cobre**:
- Como incorporar o workflow `nodejs-mutanting` em um projeto Node.js ou TypeScript
- Pre-requisito: instalacao e configuracao do Stryker no projeto
- Todos os inputs do workflow (`diff_mode`, `node_version`, `working_directory`, `threshold`)
- Secrets opcionais para envio de metricas ao Kafka (`KAFKA_*`)
- O que e MSI e como funciona o threshold
- Diferenca entre `diff_mode: changed` (so arquivos JS/TS alterados no PR) e `diff_mode: total` (projeto inteiro)
- Formato do comentario automatico na PR
- Uso em monorepos com `working_directory`
- Envio de metricas ao Kafka via `quality-maturity-report-layer`

**NAO cobre**:
- Escrita de testes unitarios JavaScript/TypeScript
- Configuracao avancada do Stryker (mutators customizados, filtros, plugins de runner)
- Infraestrutura de Kafka

## Exemplos de Perguntas

- "Como adiciono testes de mutacao no meu projeto Node.js?"
- "Quais pre-requisitos meu projeto TypeScript precisa ter para usar o nodejs-mutanting?"
- "Como instalo e configuro o Stryker no meu projeto?"
- "O que coloco no stryker.config.mjs?"
- "Qual diff_mode devo usar — changed ou total?"
- "Como defino um threshold de MSI de 75% para Node.js?"
- "Meu projeto usa Jest, como configuro o Stryker com Jest runner?"
- "Como uso o workflow em monorepo Node.js?"
- "Como envio metricas de mutacao para o Kafka?"

## Conhecimento Embutido

### Localizacao do Workflow

```
stone-payments/github-actions-workflows
  .github/workflows/nodejs-mutanting.yml
```

Referencia para consumo: `@nodejs-mutanting-v0`

---

### Pre-requisito: Stryker Instalado e Configurado

Instale o Stryker como dependencia de desenvolvimento:

```bash
# Com Jest runner (mais comum)
npm install --save-dev @stryker-mutator/core @stryker-mutator/jest-runner

# Com Mocha runner
npm install --save-dev @stryker-mutator/core @stryker-mutator/mocha-runner

# Com Vitest runner
npm install --save-dev @stryker-mutator/core @stryker-mutator/vitest-runner
```

Crie o arquivo de configuracao `stryker.config.mjs` (ou `stryker.config.json`):

```javascript
// stryker.config.mjs — exemplo para Jest
/** @type {import('@stryker-mutator/api/core').PartialStrykerOptions} */
export default {
  testRunner: 'jest',
  reporters: ['json', 'progress'],
  coverageAnalysis: 'perTest',
  jest: {
    projectType: 'custom',
    configFile: 'jest.config.js',
  },
  // Opcional: excluir arquivos gerados ou de configuracao
  ignorePatterns: ['node_modules', 'dist', 'coverage'],
};
```

> O workflow executa `npx stryker run --reporters json,progress`. O Stryker gera o report em `reports/mutation/mutation.json` por padrao.

---

### Como Integrar o Workflow

#### Uso Minimo

```yaml
# .github/workflows/ci.yml
jobs:
  mutation:
    uses: stone-payments/github-actions-workflows/.github/workflows/nodejs-mutanting.yml@nodejs-mutanting-v0
```

#### Com Threshold e Versao de Node

```yaml
jobs:
  mutation:
    uses: stone-payments/github-actions-workflows/.github/workflows/nodejs-mutanting.yml@nodejs-mutanting-v0
    with:
      node_version: '22'
      diff_mode: total
      threshold: 75
```

#### Em Monorepo com working_directory

```yaml
jobs:
  mutation:
    uses: stone-payments/github-actions-workflows/.github/workflows/nodejs-mutanting.yml@nodejs-mutanting-v0
    with:
      working_directory: packages/my-service
      threshold: 60
```

#### Com Envio ao Kafka

```yaml
jobs:
  mutation:
    uses: stone-payments/github-actions-workflows/.github/workflows/nodejs-mutanting.yml@nodejs-mutanting-v0
    with:
      threshold: 70
    secrets:
      KAFKA_BROKER_URL: ${{ secrets.QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD }}
      KAFKA_SASL_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SASL_USERNAME_PRD }}
      KAFKA_SASL_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SASL_PASSWORD_PRD }}
      KAFKA_SCHEMA_ENDPOINT: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_ENDPOINT }}
      KAFKA_SCHEMA_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD }}
      KAFKA_SCHEMA_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD }}
```

---

### Inputs Disponiveis

| Input | Tipo | Obrigatorio | Descricao | Padrao |
|-------|------|-------------|-----------|--------|
| `runs_on` | string (JSON) | nao | Runner a usar | `"['small-runner']"` |
| `diff_mode` | string | nao | `"changed"` (so arquivos JS/TS alterados no PR) ou `"total"` (projeto todo) | `"changed"` |
| `working_directory` | string | nao | Diretorio do projeto Node.js com o Stryker configurado | `"."` |
| `node_version` | string | nao | Versao do Node.js (ex: `"20"`, `"22"`) | `"20"` |
| `threshold` | number | nao | MSI minimo em % (0 = desabilitado). Workflow falha se abaixo | `0` |

### Secrets Opcionais (Kafka)

| Secret | Descricao |
|--------|-----------|
| `KAFKA_BROKER_URL` | URL do broker Kafka |
| `KAFKA_SASL_USERNAME` | Username SASL do Kafka |
| `KAFKA_SASL_PASSWORD` | Password SASL do Kafka |
| `KAFKA_SCHEMA_ENDPOINT` | URL do Schema Registry |
| `KAFKA_SCHEMA_USERNAME` | Username do Schema Registry |
| `KAFKA_SCHEMA_PASSWORD` | Password do Schema Registry |

---

### O que o Workflow Faz (Passo a Passo)

1. **Checkout** com `fetch-depth: 0` (necessario para o `--since` do Stryker)
2. **Setup do Node.js** com cache do npm
3. **`npm ci`** para instalar dependencias
4. **Deteccao de arquivos JS/TS alterados** (quando `diff_mode: changed`)
   - Extensoes detectadas: `.js`, `.ts`, `.jsx`, `.tsx`, `.mjs`, `.cjs`
   - Se nenhum arquivo foi alterado: pula a execucao
5. **Execucao do Stryker**:
   - `changed`: `npx stryker run --since=<base_sha> --reporters json,progress`
   - `total`: `npx stryker run --reporters json,progress`
6. **Localizacao do report** (`reports/mutation/mutation.json` ou `reports/mutation-report.json`)
7. **Normalizacao do report** para o formato JSON compartilhado
8. **Verificacao do threshold** de MSI (se `threshold > 0`)
9. **Comentario na PR** com tabela de resultados
10. **Envio das metricas** (apenas se os secrets Kafka forem passados — o destino e gerenciado pelo workflow)

---

### MSI — Mutation Score Indicator

- `MSI = (Killed + Timeout) / Total * 100`
- **🟢 >= 80%**: Excelente
- **🟡 60-79%**: Aceitavel
- **🔴 < 60%**: Insuficiente

Exemplos de mutantes gerados pelo Stryker:
- Trocar `>` por `>=` ou `<`
- Remover bloco `if`
- Substituir `+` por `-`
- Negar retornos booleanos

---

### Comentario Automatico na PR

```
## 🧬 Mutation Testing Report — Node.js / Stryker

🟢 Mutation Score (MSI): 80.00%

| Metric               | Value |
|----------------------|-------|
| Total Mutants        | 150   |
| ✅ Killed            | 120   |
| ❌ Survived (Escaped)| 30    |
| ⏱️ Timeout           | 0     |
| 🚫 No Coverage       | 0     |
| ⏭️ Skipped / Ignored | 0     |
```

---

## Instrucoes MCP

Quando precisar de detalhes alem do conhecimento embutido, busque nos seguintes repositorios (nesta ordem de prioridade):

| Repositorio | Caminho | Quando buscar |
|-------------|---------|---------------|
| `stone-payments/karavela` | `docs/` | Padroes da plataforma (nao cobre mutation testing diretamente) |
| `stone-payments/github-actions-workflows` | `.github/workflows/nodejs-mutanting.yml` | Implementacao do workflow reutilizavel, inputs e steps |
| Externo (complemento — nao em docs/) | [Stryker Mutator docs](https://stryker-mutator.io/docs/stryker-js/) | Configuracao avancada do Stryker, runners (Jest/Vitest/Mocha) |

> Todo o conhecimento desta skill e **complemento** ao docs/ da plataforma — ela nao tem secao dedicada a mutation testing.

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Configurar Stryker** — adicionar `@stryker-mutator/core` em `devDependencies` + `stryker.conf.json` ou `stryker.config.mjs`
- **Criar `.github/workflows/mutation.yml`** apontando para `nodejs-mutanting.yml@main`
- **Inputs**: `diff_mode`, `node_version`, `working_directory`, `threshold` (MSI minimo)
- **Adicionar secrets Kafka** opcionais (via `stone-payments/terraform-github`)
- **Abrir PR draft**

### Triggers proativos
- "Adicionar mutation testing Node/TS" → `🛠️ Acao proposta: instalo Stryker + crio config + workflow + abro PR`

### Acoes destrutivas
- N/A.

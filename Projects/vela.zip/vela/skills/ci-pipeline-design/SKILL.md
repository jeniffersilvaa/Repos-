---
name: ci-pipeline-design
description: "Design completo de pipeline GitHub Actions para a plataforma Karavela. Use quando o usuario perguntar sobre como montar um pipeline de CI/CD do zero, estrutura canonica de workflows, fluxo branch-commit vs tag-release, aprovacoes manuais no GitHub Environments, integracao de testes/coverage/linting/mutation testing no pipeline, secrets necessarios, runners disponíveis (small/medium/large), monorepos, ou quiser um exemplo end-to-end de .github/workflows para uma API Karavela."
---

# Skill: Design de Pipeline CI/CD para Karavela

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.

  Exemplos de uso:
  - Corrigir informacao desatualizada (ex: "workflow X foi depreciado, usar Y")
  - Adicionar restricao temporaria (ex: "medium-runner indisponivel em stg ate data X")
  - Adicionar novo workflow reutilizavel disponivel
  - Bloquear orientacao especifica
-->

## Escopo

**Cobre**:
- Estrutura canonica de pipeline Karavela (build → test → lint → coverage → deploy stg → deploy prd)
- Workflows reutilizaveis disponíveis: `karavela_build.yml`, `karavela_deploy.yml`, `karavela_release.yml`
- Diferenca entre fluxo branch-commit e tag-release — quando usar cada um
- Como configurar aprovacoes manuais com GitHub Environments (sandbox, producao)
- Integracao de testes (unit, integration, e2e) no pipeline de CI
- Integracao de coverage (workflows `test-coverage-*`)
- Integracao de mutation testing (workflows `*-mutanting`) — quando obrigatorio
- Integracao de linting com MegaLinter
- Secrets obrigatorios no repositorio para pipelines funcionarem
- Runners disponíveis: `small-runner`, `medium-runner`, `large-runner`
- Monorepos: jobs em matrix e `working_directory`
- Guardrails de governanca sobre workflows `karavela_containers_*` (validador de compliance em PRs)
- Exemplos end-to-end de `.github/workflows/` para API Go/Node/Python

**NAO cobre**:
- Escrita de testes (coberto pelas skills `unit-testing-*`)
- Configuracao de coverage detalhada (coberto pelas skills `ci-test-coverage-*`)
- Configuracao de mutation testing detalhada (coberto pelas skills `ci-mutation-testing-*`)
- Configuracao detalhada do MegaLinter (coberto pela skill `megalinter`)
- Fluxo de rollback pos-deploy (coberto pela skill `deploy-rollback`)
- Observabilidade e alertas de producao (coberto pela skill `observabilidade`)

## Exemplos de Perguntas

- "Como monto o pipeline de CI/CD para minha API Karavela do zero?"
- "Qual a diferenca entre branch-commit e tag-release? Qual devo usar?"
- "Como adiciono aprovacao manual antes do deploy em producao?"
- "Quais secrets preciso configurar no repositorio para o pipeline funcionar?"
- "Como integro testes, coverage e linting no mesmo pipeline?"
- "Como configuro o pipeline para um monorepo com duas aplicacoes?"
- "Qual runner devo usar para builds pesados?"
- "Como funciona o fluxo de hotfix no pipeline tag-release?"
- "O que e o Release Drafter e para que serve?"
- "Como adiciono mutation testing ao meu pipeline de CI?"
- "Quais alteracoes posso fazer nos workflows karavela_containers_ sem quebrar o compliance?"
- "Por que meu PR foi bloqueado pelo validador de guardrails?"

## Conhecimento Embutido

### Visao Geral: Dois Fluxos de Deploy

A Karavela suporta dois modelos de pipeline:

| Fluxo | Trigger | Melhor para |
|-------|---------|-------------|
| **branch-commit** | Push na branch principal (`main`/`develop`) | Times com deploys frequentes, trunk-based development |
| **tag-release** | Criacao de release/tag no GitHub | Times com ciclos de release definidos, Git Flow |

Em ambos os fluxos, os workflows reutilizaveis sao os mesmos:
- `stone-payments/platform-k8s-github-actions/.github/workflows/karavela_build.yml@main`
- `stone-payments/platform-k8s-github-actions/.github/workflows/karavela_deploy.yml@main`

> **IMPORTANTE**: Os workflows antigos (`build_and_push.yml`, `deploy.yml`, `deploy_argocd.yml`) foram depreciados no Q4/2024. Use sempre `karavela_build.yml` e `karavela_deploy.yml`.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/deploy-de-aplicacoes/branch-commit.md`, `tag-release.md`

---

### Estrutura Canonica de Pipeline

Um pipeline completo para uma API Karavela tem tipicamente 5 arquivos em `.github/workflows/`:

```
.github/workflows/
├── karavela_containers_build.yaml          # PR check: build sem push
├── karavela_containers_build_and_deploy.yaml  # Deploy principal
├── karavela_containers_release-drafter.yaml   # (tag-release) geração de releases
├── karavela_containers_guardrails.yaml        # Validacoes de compliance
└── karavela_containers_preview.yaml           # (opcional) preview environments
```

**Fluxo por etapa**:

```
Pull Request  →  [build]  →  [test/lint/coverage]  →  merge
Branch push   →  [build + deploy stg]  →  [aprovacao]  →  [deploy sdx]  →  [aprovacao]  →  [deploy prd]
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/deploy-de-aplicacoes/`

---

### Guardrails: Governanca sobre Workflows Karavela

Workflows com o prefixo `karavela_containers_` nos repositorios de aplicacoes sao submetidos a um **compliance de guardrails**, enforcado por um ruleset de nivel de org no GitHub. O produto `karavela_containers_workflow_validation` valida todos os PRs (branch de destino `main`, `master` ou `default`) e o validador roda no workflow `karavela_containers_guardrails.yaml`.

**Tipos de workflow validados** (extensoes `.yaml`/`.yml`): `karavela_containers_build`, `karavela_containers_build_and_deploy`, `karavela_containers_preview`, `karavela_containers_guardrails`.

**Nomenclatura**: padrao `karavela_containers_[<nome-customizavel>_]<tipo>.<extensao>` — o segmento customizavel, quando presente, vem **antes** do tipo (ex: `karavela_containers_meu-servico_build_and_deploy.yaml` e valido; `karavela_containers_build_and_deploy_meu-servico.yaml` e **invalido**).

**Alteracoes PERMITIDAS nos workflows da app**:
- Inclusao/exclusao/alteracao de `inputs` e `secrets` na chamada dos reusables (`karavela_build.yml`, `karavela_deploy.yml`)
- Inclusao de novos jobs personalizados e determinacao da ordem de execucao deles
- Inclusao de novos arquivos de workflow personalizados
- `rename` de arquivo, desde que mantenha o padrao de nomenclatura (conteudo renomeado tambem e validado)

**Acoes NAO permitidas**:
- `delete` de qualquer workflow `karavela_containers_*`
- `rename` que abandone o prefixo `karavela_containers_` ou o sufixo de compliance (`_build`, `_build_and_deploy`, `_preview`, `_guardrails`)
- `rename` que inverta a ordem do segmento customizavel e do tipo

**Regras de compliance interno** (exemplos do `karavela_containers_build.yaml`):
- `name` precisa conter a string `build`; `run-name` e fixo
- `jobs.build` e mandatorio, com `uses` exatamente `stone-payments/platform-k8s-github-actions/.github/workflows/karavela_build.yml@main`
- Trigger `.on.pull_request` e mandatorio e unico permitido no `on`
- Nenhum job pode invocar `karavela_deploy.yml` dentro do workflow de build
- `jobs.build.with.REGISTRY_NAME` e validado **contra o registry real da aplicacao na Karavela API** (`basename(image_repository)`); mismatch ou app nao cadastrada gera comment de PR com instrucao de correcao

**Fonte**: `karavela/docs/guia-do-desenvolvedor/guias-e-manuais/guardrails-validator.md`

---


Executa em todo PR para `main`, valida que o codigo compila sem fazer push da imagem:

```yaml
# .github/workflows/karavela_containers_build.yaml
name: build minha-api
run-name: ${{ github.event_name }} ${{ github.event.pull_request.number }} to ${{ github.base_ref }} by @${{ github.actor }}

on:
  pull_request:
    branches:
      - "main"
    paths-ignore:
      - ".github/**"
      - ".gitignore"
      - "catalog-info.yaml"
      - "CHANGELOG.md"
      - "README.md"
      - "docs/**"
      - "chart/**"

jobs:
  build:
    name: Build
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_build.yml@main
    with:
      RUNS_ON: "small-runner"
      REGISTRY_NAME: "minha-api"
      WORK_DIR: ./
      PUSH_IMAGE: false
    secrets: inherit
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/guias-e-manuais/migrar-workflows-branch-commit.md`

---

### Workflow de Build & Deploy — Fluxo Branch-Commit

Trigger: push na `main` ou `develop`. Usa hash do commit como `image.tag` e `targetRevision`.

```yaml
# .github/workflows/karavela_containers_build_and_deploy.yaml
name: build and deploy minha-api
run-name: ${{ github.event_name }} ${{ github.ref_name }} by @${{ github.actor }}

on:
  push:
    branches:
      - "main"
      - "develop"
    paths-ignore:
      - ".github/**"
      - ".gitignore"
      - "catalog-info.yaml"
      - "CHANGELOG.md"
      - "README.md"
      - "docs/**"

jobs:
  build:
    name: Build
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_build.yml@main
    with:
      RUNS_ON: "small-runner"
      REGISTRY_NAME: "minha-api"
      WORK_DIR: ./
    secrets: inherit

  deploy_stg:
    name: Deploy stg
    needs: [build]
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_deploy.yml@main
    with:
      APPLICATION_NAME: "minha-api"
      ENVIRONMENT: "stg"
      RUNS_ON: "small-runner"
      IMAGE_TAG: ${{ needs.build.outputs.image_tag }}
      TARGET_REVISION: ${{ needs.build.outputs.target_revision }}
    secrets: inherit

  deploy_prd:
    name: Deploy prd
    needs: [build, deploy_stg]
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_deploy.yml@main
    with:
      APPLICATION_NAME: "minha-api"
      ENVIRONMENT: "prd"
      RUNS_ON: "small-runner"
      IMAGE_TAG: ${{ needs.build.outputs.image_tag }}
      TARGET_REVISION: ${{ needs.build.outputs.target_revision }}
    secrets: inherit
```

> O deploy em `prd` requer aprovacao manual via GitHub Environments (configurado no repositorio). O Changeman valida automaticamente os pre-requisitos antes de liberar.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/deploy-de-aplicacoes/branch-commit.md`

---

### Workflow de Build & Deploy — Fluxo Tag-Release

Trigger: publicacao de release no GitHub. Usa a tag SemVer (`v1.2.3`) como `image.tag`.

```yaml
# .github/workflows/karavela_containers_build_and_deploy.yaml
name: build and deploy minha-api
run-name: ${{ github.event_name }} ${{ github.ref_name }} by @${{ github.actor }}

on:
  workflow_dispatch:
  release:
    types: [published]

jobs:
  build:
    name: Build
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_build.yml@main
    with:
      RUNS_ON: "small-runner"
      REGISTRY_NAME: "minha-api"
      WORK_DIR: ./
    secrets: inherit

  deploy_stg:
    name: Deploy stg
    needs: [build]
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_deploy.yml@main
    strategy:
      fail-fast: false
      matrix:
        app:
          - "minha-api"
    with:
      APPLICATION_NAME: ${{ matrix.app }}
      ENVIRONMENT: "stg"
      RUNS_ON: "small-runner"
      IMAGE_TAG: ${{ needs.build.outputs.image_tag }}
      TARGET_REVISION: ${{ needs.build.outputs.target_revision }}
    secrets: inherit

  deploy_sdx:
    name: Deploy sdx
    if: needs.build.outputs.tag_prd_semver == 'true'
    needs: [build, deploy_stg]
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_deploy.yml@main
    strategy:
      fail-fast: false
      matrix:
        app:
          - "minha-api"
    with:
      APPLICATION_NAME: ${{ matrix.app }}
      ENVIRONMENT: "sdx"
      RUNS_ON: "small-runner"
      IMAGE_TAG: ${{ needs.build.outputs.image_tag }}
      TARGET_REVISION: ${{ needs.build.outputs.target_revision }}
    secrets: inherit

  deploy_prd:
    name: Deploy prd
    if: |
      github.event.release.prerelease == false &&
      needs.build.outputs.tag_prd_semver == 'true'
    needs: [build, deploy_stg, deploy_sdx]
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_deploy.yml@main
    strategy:
      fail-fast: false
      matrix:
        app:
          - "minha-api"
    with:
      APPLICATION_NAME: ${{ matrix.app }}
      ENVIRONMENT: "prd"
      RUNS_ON: "small-runner"
      IMAGE_TAG: ${{ needs.build.outputs.image_tag }}
      TARGET_REVISION: ${{ needs.build.outputs.target_revision }}
    secrets: inherit
```

**Regras para deploy em producao (tag-release)**:
- A TAG deve seguir SemVer com prefixo `v` (ex: `v1.2.3`)
- Todos os commits da TAG devem estar presentes na branch `main`/`master`
- A release NAO pode ser marcada como pre-release
- O Changeman valida automaticamente esses requisitos

**Fonte**: `karavela/docs/guia-do-desenvolvedor/deploy-de-aplicacoes/tag-release.md`

---

### Release Drafter (apenas fluxo tag-release)

Automatiza a criacao de drafts de release com changelog baseado em PRs. Opcional mas recomendado.

```yaml
# .github/workflows/karavela_containers_release-drafter.yaml
name: release-drafter

on:
  push:
    branches:
      - develop
      - release/**
      - hotfix/**
    paths-ignore:
      - ".github/**"
      - ".gitignore"
  pull_request:
    types: [opened, reopened, synchronize, edited, closed]
    branches:
      - main
      - master
      - develop
      - release/**

permissions:
  contents: write
  issues: write
  pull-requests: write

jobs:
  update_release_draft:
    if: "${{ !(github.event.action == 'closed' && github.event.pull_request.merged == false) }}"
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_release.yml@karavela-release-v1
    with:
      release_drafter_config_name: "karavela_containers_release_drafter_template.yml"
      prerelease_identifier: "rc"
    secrets: inherit
```

**Padroes de versao suportados**:
- `v1.2.3` — release produtiva (deploy automatico em stg/sdx/prd com aprovacao)
- `v1.2.3-rc.0` — release candidate (deploy automatico apenas em stg/sdx)
- Branches `release/1.2.3` e `hotfix/1.2.3` — versao extraida automaticamente do nome

**Fonte**: `karavela/docs/guia-do-desenvolvedor/deploy-de-aplicacoes/tag-release.md`

---

### Integrando Testes e Coverage no Pipeline

Os workflows de coverage sao chamados como jobs separados no pipeline de PR ou build:

```yaml
# Adicione ao karavela_containers_build.yaml (em PRs)
  test:
    name: Tests & Coverage
    uses: stone-payments/github-actions-workflows/.github/workflows/test-coverage-golang.yml@main
    with:
      project_name: "minha-api"
      unit_test_path: "./internal/..."
      integration_test_path: "./tests/integration/..."
      RUNS_ON: "small-runner"
    secrets: inherit
```

Skills de referencia por linguagem:
- Go: `ci-test-coverage-golang`
- Node.js/TypeScript: `ci-test-coverage-nodejs`
- Python: `ci-test-coverage-python`
- .NET: `ci-test-coverage-dotnet`
- Kotlin KMP: `ci-test-coverage-kotlin-kmp`

**Fonte**: `stone-payments/github-actions-workflows`

---

### Integrando MegaLinter (Linting Estatico)

O MegaLinter verifica qualidade de codigo, formatacao e seguranca estatica:

```yaml
# Adicione ao karavela_containers_build.yaml (em PRs)
  lint:
    name: Lint
    uses: stone-payments/github-actions-workflows/.github/workflows/megalinter.yml@main
    with:
      RUNS_ON: "small-runner"
    secrets: inherit
```

Veja a skill `megalinter` para configuracao detalhada de quais linters habilitar/desabilitar.

**Fonte**: `stone-payments/github-actions-workflows`

---

### Integrando Mutation Testing

Mutation testing e opcional mas recomendado para madurez de qualidade. Geralmente executado em schedule ou em PRs para paths criticos:

```yaml
# Exemplo para Go — executar em schedule semanal
  mutation:
    name: Mutation Testing
    uses: stone-payments/github-actions-workflows/.github/workflows/mutation-testing-golang.yml@main
    with:
      project_name: "minha-api"
      RUNS_ON: "medium-runner"   # mutation testing e mais pesado
    secrets: inherit
```

Skills de referencia: `ci-mutation-testing-golang`, `ci-mutation-testing-nodejs`, `ci-mutation-testing-python`, `ci-mutation-testing-csharp`, `ci-mutation-testing-kotlin-kmp`.

---

### Runners Disponíveis

| Runner | Uso recomendado |
|--------|----------------|
| `small-runner` | Build, deploy, testes unitarios rapidos — maioria dos jobs |
| `medium-runner` | Testes de integracao, mutation testing, builds com dependencias pesadas |
| `large-runner` | Builds de imagens muito grandes, testes de carga, compilacoes demoradas |

> Prefira `small-runner` sempre que possivel para reduzir custo. Use `medium-runner` ou `large-runner` apenas quando o job falhar por timeout ou memoria insuficiente.

---

### Secrets Necessarios no Repositorio

Os workflows usam `secrets: inherit`, que repassa automaticamente os secrets configurados no repositorio ou na organizacao. Os principais ja existem como **org secrets** na Stone e nao precisam ser criados manualmente:

| Secret | Finalidade |
|--------|-----------|
| `KARAVELA_TOKEN` | Autenticacao com a Karavela API para deploy |
| `ECR_REGISTRY` / credenciais AWS | Push de imagem Docker para ECR |
| `SSH_PRIVATE_KEY` | Acesso a modulos privados Go/Node durante build |

> Para secrets de Kafka (coverage/mutation testing), e necessario adicionar o repositorio na lista de acesso em `stone-payments/terraform-github`. Consulte a skill `ci-test-coverage-golang` para o passo a passo.

---

### Monorepos: Multiplas Aplicacoes no Mesmo Repositorio

Use `strategy.matrix` para deployar multiplas apps e `WORK_DIR` para builds em subdiretorios:

```yaml
jobs:
  build_api:
    name: Build API
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_build.yml@main
    with:
      RUNS_ON: "small-runner"
      REGISTRY_NAME: "meu-monorepo-api"
      WORK_DIR: ./api
    secrets: inherit

  build_worker:
    name: Build Worker
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_build.yml@main
    with:
      RUNS_ON: "small-runner"
      REGISTRY_NAME: "meu-monorepo-worker"
      WORK_DIR: ./worker
    secrets: inherit

  deploy_stg:
    name: Deploy stg
    needs: [build_api, build_worker]
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_deploy.yml@main
    strategy:
      fail-fast: false
      matrix:
        include:
          - app: "meu-monorepo-api"
            image_tag: ${{ needs.build_api.outputs.image_tag }}
          - app: "meu-monorepo-worker"
            image_tag: ${{ needs.build_worker.outputs.image_tag }}
    with:
      APPLICATION_NAME: ${{ matrix.app }}
      ENVIRONMENT: "stg"
      RUNS_ON: "small-runner"
      IMAGE_TAG: ${{ matrix.image_tag }}
      TARGET_REVISION: ${{ needs.build_api.outputs.target_revision }}
    secrets: inherit
```

> Monorepos com versionamento independente por app devem usar prefixos no Release Drafter (ex: `api-v1.2.3`). Consulte a documentacao de monorepos da Karavela para o setup completo.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/guias-e-manuais/migrar-workflows-branch-commit.md`

---

### Fluxo de Hotfix (apenas tag-release)

Para correcoes urgentes sem que os commits estejam na `main`:

1. Criar branch `hotfix/1.3.1` a partir da versao em producao
2. O Release Drafter cria automaticamente um draft `v1.3.1`
3. Editar o draft: preencher o formulario Changeman com o **ID do incidente Opsgenie**
4. Publicar a release — o workflow de deploy e acionado automaticamente
5. O deploy ignora a restricao de "commits na main" por causa do ID do incidente

> **ATENCAO**: Hotfix sem incidente aberto no Opsgenie sera bloqueado pelo Changeman.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/deploy-de-aplicacoes/tag-release.md`

---

### Matriz de Ambientes por Fluxo

| Ambiente | Branch-commit (trigger) | Tag-release (trigger) | Aprovacao |
|----------|------------------------|----------------------|-----------|
| `stg` | Push na `main`/`develop` | Qualquer TAG publicada | Automatico |
| `sdx` | Push na `main` (apos stg) | TAG SemVer valida (apos stg) | Automatico |
| `prd` | Push na `main` (apos sdx) | TAG SemVer nao pre-release (apos sdx) | Manual + Changeman |

---

### Checklist de Pipeline Minimo Funcional

Antes de considerar o pipeline pronto, verifique:

- [ ] `karavela_containers_build.yaml` — build sem push em PRs
- [ ] `karavela_containers_build_and_deploy.yaml` — deploy principal
- [ ] GitHub Environment `prd` configurado com aprovadores no repositorio
- [ ] `REGISTRY_NAME` igual ao nome da aplicacao cadastrada no Karavela Portal
- [ ] `secrets: inherit` presente em todos os jobs de deploy
- [ ] Para tag-release: `karavela_containers_release-drafter.yaml` configurado

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever; producao exige dupla confirmacao. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Criar workflows end-to-end** — `.github/workflows/karavela_containers_build_and_deploy.yaml` ou variantes por app (monorepo)
- **Integrar** test-coverage, mutation-testing, megalinter no pipeline
- **Configurar GitHub Environments** com aprovacoes manuais — orientar via UI Settings
- **Configurar runners** (small/medium/large)
- **Configurar secrets necessarios** — orientar via GitHub Settings + Actions secrets
- **Abrir PR draft**

### Triggers proativos
- "Monte meu pipeline do zero" → ofereca `🛠️ Acao proposta: crio os 3-4 workflows canonicos + abro PR`
- "Adicionar gate de coverage" → propor integracao com `test-coverage-<lang>.yml`
- "Mutation testing" → integrar `<lang>-mutanting.yml`
- "Pipeline para monorepo padrao 2" → criar 1 workflow por app com `TAG_PREFIX`

### Acoes destrutivas (dupla confirmacao)
- **Deletar workflow** `karavela_containers_*` — bloqueado pelo Guardrails Validator. Apenas instruir alternativa (rename).

## Instrucoes MCP

**Prioridade**: `stone-payments/karavela` `docs/` é a fonte primária para semântica e regras dos fluxos de deploy (`branch-commit`, `tag-release`). Detalhes operacionais (inputs/outputs dos reusable workflows) vivem nos repositórios de workflows.

| Repositorio | Arquivo/Caminho | Prioridade | Quando buscar |
|-------------|-----------------|------------|---------------|
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/deploy-de-aplicacoes/branch-commit.md` | **primaria** | Regras e semantica do fluxo branch-commit |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/deploy-de-aplicacoes/tag-release.md` | **primaria** | Regras e semantica do fluxo tag-release |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/guias-e-manuais/migrar-workflows-branch-commit.md` | **primaria** | Estrutura completa de workflows + monorepos |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/guias-e-manuais/migrar-workflows-tag-release.md` | **primaria** | Estrutura completa de workflows tag-release |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/guias-e-manuais/guardrails-validator.md` | **primaria** | Governanca e compliance sobre workflows `karavela_containers_*` |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/funcionalidades/azure-artifacts.md` | primaria | Integracao Azure Artifacts no build (NuGet) |
| `stone-payments/platform-k8s-github-actions` | `.github/workflows/karavela_build.yml` | complemento | Inputs/outputs do workflow de build |
| `stone-payments/platform-k8s-github-actions` | `.github/workflows/karavela_deploy.yml` | complemento | Inputs do workflow de deploy |
| `stone-payments/github-actions-workflows` | `.github/workflows/` | complemento — nao em docs/ | Workflows de test-coverage, mutation testing e megalinter |

## Formato de Resposta

Ao responder perguntas deste dominio, siga este formato:

1. **Explicacao** (2-3 frases objetivas em PT-BR: qual fluxo usar e por que)
2. **Exemplo pratico** (YAML completo e copiavel do workflow relevante)
3. **Fonte** (referencia ao arquivo/secao da documentacao)
4. **Avisos** (se aplicavel: restricoes de ambiente, workflows depreciados, requisitos do Changeman)

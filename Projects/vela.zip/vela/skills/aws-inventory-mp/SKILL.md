---
name: aws-inventory-mp
description: "Inventaria e inspeciona instancias RDS das contas Stone via mp-mcp — triggers: instancia rds, inventario rds, contas aws, parametros rds, parameter groups, lista rds, bancos rds"
---

# Inventario AWS (RDS) via mp-mcp

Use quando o usuario **inventaria ou inspeciona instancias RDS** das contas Stone atraves do `mp-api`. Surface: **mp-mcp** (Foundation Platform Mensageria, `stone-payments/mp-ai`). Escopo deste playbook e **somente inventario de RDS** — sem metricas, sem logs, sem outros servicos AWS.

Nao confundir com:

- `observe` — Datadog/Grafana (APM, dashboards, metricas application-side)
- `platform` — operacao ativa em apps Karavela (deploy, secrets, rotate)
- `kli-mcp` — mutacao de recursos via plataforma — `mp-mcp` **nunca muta**

⚠️ Pedidos de metricas (CPU, conexoes, memoria), logs, ou outros servicos (DynamoDB, ElastiCache, MSK, SQS, SNS, MQ, EC2, CloudWatch) **nao** pertencem a este playbook — redirecione para `observe` ou o playbook apropriado.

## Exemplos de Perguntas

- *"Lista as instancias RDS da conta X"*
- *"Quais contas AWS temos?"*
- *"Quais os parametros do RDS tal?"*
- *"Tem algum RDS na conta Y em sa-east-1?"*
- *"Me mostra os parameter groups do RDS da conta Z"*
- *"Quantos bancos RDS temos na conta W?"*

## Regras de Execucao

### Tools (escopo: RDS inventory — 3)

**Accounts (1):** `list_stone_org_accounts`

**RDS (2):** `list_rds_instances`, `list_rds_parameters`

### Fluxo principal: inventariar RDS

1. **Resolver conta** — se nao citada, `list_stone_org_accounts` (cache em sessao). Conta unica → silencio; multiplas → `<questions>` curta listando candidatas com nome humano + `accountId`.
2. **Resolver regiao** — default `us-east-1` (literal `AwsRegion` em `server.py`). Ordem de fallback quando o user nao cita regiao: `us-east-1` → `us-east-2` → `sa-east-1`. Mapeie "Virginia" / "N. Virginia" → `us-east-1`, "Ohio" → `us-east-2`, "Sao Paulo" → `sa-east-1` antes de submeter. Confirme so se ambigua.
3. **Listar instancias** — `list_rds_instances({ accountId, region })`.
4. **Detalhar parametros** (sob demanda) — `list_rds_parameters({ accountId, region, instanceIdentifier })` quando o user pedir explicitamente parameter group / configuracoes da instancia.
5. Resuma: nome + engine + classe + estado em lista curta. **Nao despeje listas completas no chat** — top-N por criterio (engine, estado) se houver muitas instancias.

### Fluxo: discovery rapido de contas

Quando o user pergunta "quais contas AWS temos?" / "lista as contas Stone": single call `list_stone_org_accounts`, agrupe por OU/ambiente (prd/stg/dev) em lista curta. Nao enumere 100+ contas no chat — sumarize por categoria + ofereca filtro.

### Principios invariaveis

- **Read-only e lei.** Qualquer pedido de mutacao ("scale RDS", "rotate password", "altera parameter group", "delete instancia") → redirecione pra `kli-mcp` / console AWS / runbook. Nunca finja que mp-mcp pode.
- **Pre-fetch silencioso de `list_stone_org_accounts`** no 1o turn se a conta nao foi explicitada. Nao anuncie a inferencia — so mostre no resultado final.
- **Conta + regiao canonicas**: `accountId` numerico (12 digitos), `region` no formato AWS. Use literal `AwsRegion` definido em `server.py`. Mapeamento "human → canonico" antes de submeter.
- **0 resultados → "sem instancias RDS nessa conta/regiao"** + ofereca expandir busca (outra conta, outra regiao). Nunca invente valores.
- **Listagens grandes nao vao pro chat** — top-N + filtro relevante (engine, estado) + oferta de paginacao.
- **Parameter groups so quando pedidos** — `list_rds_parameters` e verboso; chame sob demanda, nao no fluxo padrao de listagem.
- **Fora de escopo** — qualquer pedido de metrica, log, ou outro servico AWS nao-RDS: redirecione para `observe` ou o playbook correto. Nao tente fingir cobertura.

### Falhas comuns e recovery

- **401/403 no `mp-api`** → bearer token da config (`MP_MCP_AUTH_TOKEN`) invalido/expirado. Nao retentar; sinalize ao user com link pro runbook de credenciais.
- **404 em instancia** → conta/regiao errada, ou identificador digitado errado. Reabra resolucao (passo 1–2) com `<questions>` curta.
- **Lista vazia** → conta sem RDS na regiao consultada. Ofereca checar a proxima regiao na ordem de fallback (`us-east-1` → `us-east-2` → `sa-east-1`).

### Cancelamento

Triggers: `"cancelar"` / `"esquece"` / `"deixa pra la"`. Resposta: `"Beleza, cancelado."`.

## Formato de Resposta

- Listagem de instancias em tabela curta: Nome, Engine, Classe, Estado.
- Contas agrupadas por OU/ambiente (prd/stg/dev).
- Parameter groups em tabela: Parametro, Valor, Fonte.
- Nunca despeje listas completas — top-N + oferta de paginacao.

---
skill: aws-inventory-mp
version: 1
---

## HP — Happy-Path Cases

### HP-01: Listar instancias RDS de uma conta

- **input**: "Lista as instancias RDS da conta payments-prd"
- **expected**: Resolve a conta via `list_stone_org_accounts`, depois chama `list_rds_instances({ accountId, region: "us-east-1" })` e apresenta tabela resumida.

### HP-02: Listar contas AWS

- **input**: "Quais contas AWS temos?"
- **expected**: Chama `list_stone_org_accounts` e agrupa por OU/ambiente (prd/stg/dev) em lista curta.

### HP-03: Consultar parametros de uma instancia RDS

- **input**: "Me mostra os parametros do RDS my-db-instance na conta X"
- **expected**: Resolve conta e regiao, chama `list_rds_parameters({ accountId, region, instanceIdentifier: "my-db-instance" })` e apresenta tabela de parametros.

### HP-04: Listar RDS em regiao especifica

- **input**: "Tem algum RDS na conta Y em sa-east-1?"
- **expected**: Chama `list_rds_instances({ accountId, region: "sa-east-1" })` e retorna resultado.

### HP-05: Descobrir RDS sem especificar conta

- **input**: "Quais instancias RDS temos?"
- **expected**: Faz pre-fetch silencioso de `list_stone_org_accounts`, pede ao usuario para escolher a conta com `<questions>` curta.

### HP-06: Listar parameter groups

- **input**: "Quais parameter groups do RDS na conta Z?"
- **expected**: Resolve conta, chama `list_rds_parameters` sob demanda e apresenta resultado.

## EC — Edge Cases

### EC-01: Pedido de mutacao (fora de escopo)

- **input**: "Escala o RDS my-db pra db.r5.2xlarge"
- **expected**: NAO executa mutacao; redireciona para `kli-mcp` / console AWS / runbook.

### EC-02: Lista vazia — sem RDS na regiao

- **input**: "Lista os RDS da conta W em us-east-2"
- **expected**: Retorna "sem instancias RDS nessa conta/regiao" e oferece checar outra regiao (fallback us-east-1 → us-east-2 → sa-east-1).

### EC-03: Pedido de metricas (fora de escopo)

- **input**: "Qual o CPU do RDS my-db?"
- **expected**: NAO usa mp-mcp; redireciona para `observe` pois metricas nao pertencem a este playbook.

### EC-04: Conta ambigua

- **input**: "Lista os RDS da conta payments"
- **expected**: `list_stone_org_accounts` retorna multiplas contas com "payments" no nome; apresenta `<questions>` curta listando candidatas.

### EC-05: Erro de autenticacao

- **input**: "Lista RDS da conta X" (com token expirado)
- **expected**: Ao receber 401/403, informa que o bearer token esta invalido/expirado e sugere consultar o runbook de credenciais.

---
name: banco-de-dados
description: "Provisionamento e uso de RDS (PostgreSQL), Azure Postgres FlexibleServer, MongoDB Atlas e ElastiCache (Redis/Valkey) na plataforma Karavela. Use quando o usuario perguntar sobre criar banco de dados, criar Redis, criar MongoDB, conectar aplicacao ao banco, connection string, IRSA para RDS, Workload Identity para Azure Postgres, autoscaling de storage RDS, additionalUsers do ElastiCache ou segredos de banco de dados."
---

# Skill: banco-de-dados

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.

  Exemplos de uso:
  - Corrigir informacao desatualizada no conhecimento embutido
  - Adicionar restricao temporaria (ex: "versao X do ElastiCache nao esta disponivel")
  - Adicionar conhecimento que ainda nao esta na documentacao oficial
  - Bloquear uma orientacao especifica
-->

## Escopo

**Cobre**:
- Provisionamento de RDS (PostgreSQL) via Portal Karavela (jornada app-centric)
- Provisionamento de Azure PostgreSQL Flexible Server via Portal Karavela (paridade RDS)
- Provisionamento de MongoDB Atlas (AWS e Azure) via Crossplane
- Provisionamento de ElastiCache (Redis/Valkey) via Portal Karavela
- Configuracao de conexao nos `values.yaml` (envs + secrets)
- Convencoes de nomeacao dos secrets gerados automaticamente (`POSTGRES_DB_*`, `ELASTICACHE_*`, `AZURE_POSTGRES_*`, `MONGODB_ATLAS_*`)
- IRSA — permissoes AWS para RDS, ElastiCache e MongoDB Atlas
- Workload Identity — permissoes Azure para Azure Postgres
- Autoscaling de storage RDS com `maxAllocatedStorage`
- Schema atualizado do ElastiCache (`additionalUsers` com `accessString`, `existingUsers`, `existingSecurityGroups`, `parameterGroupAWSName`/`parameterGroupMRName`)
- Security groups para RDS/ElastiCache/Azure Postgres/MongoDB Atlas (mencao ao fluxo — detalhes na skill `seguranca`)
- Break glass para RDS/ElastiCache (mencao ao fluxo — detalhes na skill `seguranca`)

**NAO cobre**:
- Azure SQL Server (sem suporte na plataforma no momento — apenas Azure Postgres)
- StatefulSet com banco em container (nao recomendado pela plataforma)
- Jobs e migrations de banco (coberto pela skill `migrations-jobs`)
- Gerenciamento detalhado de secrets e Vault (coberto pela skill `secrets-vault`)
- Security groups detalhados e break glass detalhados (coberto pela skill `seguranca`)

## Exemplos de Perguntas

- "Como provisiono um banco PostgreSQL para minha aplicacao no Karavela?"
- "Como provisiono um Azure Postgres Flexible Server?"
- "Como provisiono um MongoDB Atlas para minha aplicacao?"
- "Como provisiono um Redis/ElastiCache para minha aplicacao?"
- "Como conecto minha aplicacao ao banco depois que ele foi criado?"
- "Quais secrets sao gerados automaticamente quando crio um RDS?"
- "Como habilito autoscaling de storage no meu RDS?"
- "Qual a diferenca entre ElastiCache em modo Standalone e Cluster?"
- "Como configuro IRSA para minha aplicacao acessar o RDS?"
- "Como edito os security groups do meu RDS?"
- "Como crio um additionalUser no ElastiCache com permissoes customizadas?"
- "Como importo um ElastiCache que ja existia na conta?"
- "Posso desabilitar autoMinorVersionUpgrade no RDS?"

## Conhecimento Embutido

### Como Funciona o Provisionamento App-Centric

O provisionamento de bancos de dados na Karavela segue o modelo **app-centric**: todos os recursos sao vinculados a uma aplicacao especifica e provisionados via Portal Karavela. O fluxo completo e:

1. O desenvolvedor acessa o **Portal Karavela** e seleciona sua aplicacao
2. Na aba **Recursos**, solicita a criacao do recurso (RDS, Azure Postgres, MongoDB Atlas ou ElastiCache) informando as especificacoes
3. O Portal orquestra o provisionamento na nuvem (AWS / Azure) atraves da plataforma
4. Apos o provisionamento, os **secrets de conexao sao automaticamente disponibilizados** para a aplicacao via External Secrets Operator
5. A aplicacao recebe as credenciais e endpoints como variaveis de ambiente (via `loadAllKeys: true` no `values.yaml`)

> **IMPORTANTE**: Como dev usuario, voce so interage com Portal Karavela e com `values.yaml` da sua aplicacao. Voce NAO escreve Crossplane Claims direto — quem orquestra isso e a plataforma a partir do formulario do Portal.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/secrets.md` (fluxo de External Secrets); workflows internos em `temporal/temporal-worker/internal/workflows/karavela_resources/` (complemento — nao em docs/)

### RDS (PostgreSQL)

#### Provisionar via Portal

Acesse o **Portal Karavela** → sua aplicacao → aba **Recursos** → **Novo Recurso** → **RDS**.

Campos obrigatorios:

| Campo | Descricao | Exemplo |
|-------|-----------|---------|
| `name` | Nome do banco (sem sufixo de ambiente — o workflow adiciona automaticamente) | `payments-db` |
| `engineVersion` | Versao do PostgreSQL | `16.3` |
| `instanceClass` | Tipo da instancia RDS | `db.t3.medium` |
| `allocatedStorage` | Storage inicial em GB | `20` |
| `lgpd` | Se o banco armazena dados LGPD | `true` ou `false` |

Campos opcionais relevantes:

| Campo | Descricao | Padrao |
|-------|-----------|--------|
| `multiAz` | Alta disponibilidade Multi-AZ | `false (stg) / true (outros ambientes)` |
| `deletionProtection` | Protecao contra delecao acidental | `false` |
| `backupRetentionPeriod` | Retencao de backups automaticos (dias) | `1 (stg) / 7 (outros ambientes)` |
| `maxAllocatedStorage` | Limite para autoscaling de storage (ver secao abaixo) | desabilitado |
| `iamDatabaseAuthenticationEnabled` | Autenticacao IAM em vez de senha | `false` |
| `autoMinorVersionUpgrade` | Atualizacao automatica de minor versions pela AWS | `false` (mudou — antes era `true`) |

> **ATENCAO**: O default de `autoMinorVersionUpgrade` mudou de `true` para `false` (decisao DBRE — evita mudancas nao controladas em janelas de manutencao). Habilite explicitamente se quiser receber minor upgrades automaticos.

Nome do recurso gerado pelo workflow: `<nome>-<env>` (ex: `payments-db-stg`).

**Fonte**: Portal Karavela (formulario de criacao de RDS); spec completo em `platform-k8s-crossplane/manifests/xrds/aws/rdsinstance.yaml` (complemento — nao em docs/)

#### Conectar a Aplicacao

Apos o provisionamento, configure o `values.yaml` da sua aplicacao. O host do banco e exportado automaticamente como secret pelo workflow.

```yaml
# values-stg.yaml (ou values-prd.yaml)
platform-k8s-api-chart:
  envs:
    POSTGRES_PORT: "5432"
    POSTGRES_DB: "payments_db"         # padrao: <nome-sem-env>_db

  secrets:
    envVarEnabled: true
    loadAllKeys: true                  # carrega todos os secrets automaticamente
    reloadEnabled: true
```

Com `loadAllKeys: true`, os secrets gerados pelo workflow ficam disponíveis automaticamente como variaveis de ambiente. Nao e necessario listar cada chave individualmente.

Para detalhes sobre `reloadEnabled`, `envVarEnabled` e montagem como volume, veja a skill `secrets-vault`.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/secrets.md`

#### Secrets Gerados Automaticamente

O workflow Temporal exporta automaticamente as seguintes chaves para o Vault apos o provisionamento. O padrao e `POSTGRES_DB_<TIPO>_<UPPERCASE(dbName)>`, onde `dbName` segue o padrao `<snake_case(nome)>_db`.

Exemplo para uma aplicacao chamada `payments-db`:

| Chave no Vault | Conteudo |
|----------------|----------|
| `POSTGRES_DB_APPUSER_PASSWORD_PAYMENTS_DB` | Senha do usuario de aplicacao |
| `POSTGRES_DB_MIGRATION_USER_PAYMENTS_DB` | Usuario para migrations |
| `POSTGRES_DB_MIGRATION_USER_PASSWORD_PAYMENTS_DB` | Senha do usuario de migration |
| `POSTGRES_DB_METABASE_USER_PAYMENTS_DB` | Usuario para Metabase |
| `POSTGRES_DB_METABASE_USER_PASSWORD_PAYMENTS_DB` | Senha do usuario Metabase |

Alem dos secrets de credenciais acima, o workflow exporta os seguintes secrets de infraestrutura:

| Chave no Vault | Conteudo |
|----------------|----------|
| `RDS_INSTANCE_HOST` | Hostname do banco |
| `RDS_INSTANCE_ENDPOINT` | Endpoint completo de conexao |
| `RDS_INSTANCE_PORT` | Porta (padrao: `5432`) |
| `RDS_INSTANCE_USERNAME` | Usuario de conexao da instancia |
| `RDS_INSTANCE_PASSWORD` | Senha de conexao da instancia |

**IMPORTANTE**: Os valores sao gerados automaticamente pela plataforma. Nunca configure senhas manualmente para esses usuarios.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/secrets.md` (consumo dos secrets via External Secrets); convencoes de nomeacao em `temporal/docs/concepts/prefixos-sufixos-recursos-karavela.md` (complemento — nao em docs/)

### Azure PostgreSQL Flexible Server

A plataforma agora provisiona Azure PostgreSQL Flexible Server com paridade as funcionalidades do RDS (export de secrets, PrivateEndpoint, regras de firewall e parameter group).

#### Provisionar via Portal

Acesse o **Portal Karavela** → sua aplicacao → aba **Recursos** → **Novo Recurso** → **Azure Postgres**.

Campos principais (do `AzurePostgresClaim` / `XAzurePostgres`):

| Campo | Descricao | Valores |
|-------|-----------|---------|
| `skuName` | SKU da VM Azure | `B_Standard_B1ms` / `GP_Standard_D2ds_v4` / `MO_Standard_E2ds_v4` |
| `version` | Versao do PostgreSQL | `14`, `15`, `16` (default: `16`) |
| `storageSizeGb` | Storage em GB | `32`, `64`, `128`, `256`, `512`, `1024` |
| `highAvailabilityMode` | HA do servidor | `Disabled` ou `ZoneRedundant` |
| `pgBouncerEnabled` | Habilita PgBouncer integrado | `true` / `false` |
| `autoGrowEnabled` | Storage auto-grow | `true` / `false` |
| `backupRetentionDays` | Retencao de backup em dias | `7` a `35` |
| `geoRedundantBackupEnabled` | Backup geo-redundante (**imutavel** apos create) | `true` / `false` |
| `lgpd` | Marca o banco como LGPD | `true` / `false` |
| `parameters` | Lista canonica de parametros server (vem do Temporal worker) | — |

A plataforma provisiona automaticamente: `ResourceGroup`, `FlexibleServer`, `PrivateEndpoint` (PrivateLink), `FlexibleServerFirewallRule` e `FlexibleServerConfiguration` (1 por parametro).

> **PRE-REQUISITO**: O acesso ao banco e via PrivateLink — Workload Identity Azure e configurado pela plataforma automaticamente para a Service Account da app. Veja a skill `modelo-acessos` para detalhes do Workload Identity.

**Fonte**: Portal Karavela (formulario de criacao); spec completo em `platform-k8s-crossplane/manifests/xrds/azure/azurepostgres.yaml` (complemento — nao em docs/)

#### Secrets exportados para o Vault

Apos provisionamento, o workflow `ExportAzurePostgresSecrets` exporta as credenciais para o Vault (mesmo padrao do RDS, mas com prefixo `AZURE_POSTGRES_*`).

| Chave no Vault | Conteudo |
|----------------|----------|
| `AZURE_POSTGRES_INSTANCE_HOST` | Hostname do servidor |
| `AZURE_POSTGRES_INSTANCE_PORT` | Porta (padrao: `5432`) |
| `AZURE_POSTGRES_INSTANCE_USERNAME` | Usuario admin |
| `AZURE_POSTGRES_INSTANCE_PASSWORD` | Senha admin |

A aplicacao usa `loadAllKeys: true` no `values.yaml` para receber as envs automaticamente — mesmo fluxo do RDS.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/secrets.md` (consumo via External Secrets); endpoint interno `internal/handlers/secrets/azure_postgres_secrets.go` (complemento — nao em docs/)

### MongoDB Atlas

A plataforma provisiona MongoDB Atlas (AWS e Azure) automaticamente atraves do Portal Karavela.

#### Provisionar via Portal

Acesse o **Portal Karavela** → sua aplicacao → aba **Recursos** → **Novo Recurso** → **MongoDB Atlas**.

Campos principais:

| Campo | Descricao | Exemplo |
|-------|-----------|---------|
| `cloudProvider` | Provider do cluster | `AWS` ou `AZURE` |
| `region` | Regiao no formato Atlas | `US_EAST_1`, `AZURE_EASTUS2` |
| `instanceSize` | Tamanho da instancia | `M10`, `M20`, `M30` |
| `mongoDBVersion` | Versao do MongoDB | `7.0` |
| `diskSizeGB` | Tamanho do disco em GB | `10` |
| `backupEnabled` | Habilita backup | `true` / `false` |

A plataforma cria automaticamente o `Project` Atlas, `Cluster`, `PrivateLink` e demais recursos de rede.

**Fonte**: Portal Karavela (formulario de criacao); spec completo em `platform-k8s-crossplane/manifests/xrds/mongodb-atlas/xmongodbatlascluster.yaml` (complemento — nao em docs/)

#### Secrets exportados para o Vault

| Chave no Vault | Conteudo |
|----------------|----------|
| `MONGODB_ATLAS_CONNECTION_STRING` | Connection string completa |
| `MONGODB_ATLAS_USERNAME` | Usuario de aplicacao |
| `MONGODB_ATLAS_PASSWORD` | Senha (gerada via `spec.forProvider.passwordSecretRef`) |

Path no Vault: `mongodb-atlas/{environment}/{identifier}/{username}`.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/secrets.md` (consumo via External Secrets); endpoint interno `internal/handlers/secrets/mongodb_secrets.go` (complemento — nao em docs/)

### ElastiCache (Redis/Valkey)

#### Provisionar via Portal

Acesse o **Portal Karavela** → sua aplicacao → aba **Recursos** → **Novo Recurso** → **ElastiCache**.

Engines suportadas: **Redis** e **Valkey 8** (parameter group `default.valkey8.cluster.on`).

Campos obrigatorios:

| Campo | Descricao | Exemplo |
|-------|-----------|---------|
| `name` | Nome do cluster (3-21 chars, minusculas, numeros e hifens) | `payments-cache` |
| `engine_version` | Versao do Redis/Valkey | `7.1` / `8` |
| `node_type` | Tipo da instancia | `cache.t4g.medium` |

Campos opcionais relevantes:

| Campo | Descricao | Padrao |
|-------|-----------|--------|
| `automatic_failover` | Failover automatico | `false` |
| `multi_az` | Alta disponibilidade Multi-AZ (requer `automatic_failover: true`) | `false` |
| `encryption_enabled` | Criptografia em transito (TLS) — muda porta para 6380 | `false` |
| `cluster_mode_enabled` | Modo Cluster com sharding | `false` |
| `number_cache_cluster` | No. de nos em modo Standalone (1 primario + N replicas) | `3` |
| `number_node_groups` | No. de shards em modo Cluster | `2` |
| `replicas_per_node_group` | Replicas por shard em modo Cluster (0-5) | `2` |
| `parameterGroupAWSName` | Nome do parameter group na AWS (diverge de K8s/RFC 1123) | derivado |
| `parameterGroupMRName` | Nome do parameter group K8s (RFC 1123) | derivado |

**Regras de validacao**:
- Se `multi_az: true`, entao `automatic_failover` DEVE ser `true`.
- Se `multi_az: true` em modo Standalone (`cluster_mode_enabled: false`), entao `number_cache_cluster` DEVE ser `>= 2`.

Nome do claim gerado: `<nome>-<env>` (ex: `payments-cache-stg`).

**Fonte**: Portal Karavela (formulario de criacao); spec completo em `platform-k8s-crossplane/manifests/xrds/aws/elasticache.yaml` e workflow em `temporal/temporal-worker/internal/workflows/karavela_resources/elasticache/README.md` (complemento — nao em docs/)

#### additionalUsers — usuarios extras com permissoes customizadas

E possivel criar usuarios adicionais no cluster (alem do `default` e do `appuser`), cada um com sua propria `accessString` no formato Redis ACL. A configuracao e feita pelo formulario do Portal ao provisionar/editar o ElastiCache.

```yaml
# Estrutura conceitual (preenchida via Portal, nao escrita direto pelo dev)
additionalUsers:
  - name: "analytics"
    accessString: "on ~* +@read -@dangerous"   # somente leitura, exceto comandos perigosos
  - name: "metabase"
    accessString: "on ~app:* +@all"            # full access ao namespace app:*
  - name: "readonly"
    # accessString default: "on ~* +@all"
```

> **Default**: se `accessString` for omitido, usa `"on ~* +@all"` (full access ao namespace inteiro).

Cada `additionalUser` gera automaticamente secrets no Vault no padrao `ELASTICACHE_<NAME>_<NORMALIZED>_USERNAME` / `_PASSWORD`.

#### existingUsers e existingSecurityGroups — Importacao

Para importar um ElastiCache pre-existente na conta AWS (observe-only), informe os `existingUsers` e `existingSecurityGroups` no formulario do Portal. A plataforma faz o match dos users por convencao:
- `user-default` → matched por `name == "default"`
- `user-application` → matched por `id == "<baseName>-user"`

**Fonte**: Portal Karavela (formulario de criacao); spec completo em `platform-k8s-crossplane/manifests/xrds/aws/elasticache.yaml` (complemento — nao em docs/)

#### Conectar a Aplicacao

```yaml
# values-stg.yaml (ou values-prd.yaml)
platform-k8s-api-chart:
  secrets:
    envVarEnabled: true
    loadAllKeys: true
    reloadEnabled: true
```

Com `loadAllKeys: true`, todos os secrets do ElastiCache ficam disponiveis automaticamente. Para detalhes de configuracao de secrets, veja a skill `secrets-vault`.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/secrets.md`

#### Secrets Gerados Automaticamente

O padrao e `ELASTICACHE_<NOME_NORMALIZADO>_<SUFIXO>` (hifens convertidos para underscore, uppercase).

Exemplo para `payments-cache`:

| Chave no Vault | Conteudo |
|----------------|----------|
| `ELASTICACHE_PAYMENTS_CACHE_USERNAME` | Usuario de acesso |
| `ELASTICACHE_PAYMENTS_CACHE_PASSWORD` | Senha de acesso |
| `ELASTICACHE_PAYMENTS_CACHE_PORT` | Porta (6379 sem TLS, 6380 com TLS) |
| `ELASTICACHE_PAYMENTS_CACHE_ENDPOINT_PRIMARY` | Endpoint de escrita (primary) |
| `ELASTICACHE_PAYMENTS_CACHE_ENDPOINT_READER` | Endpoint de leitura — **somente modo Standalone** |

Em **modo Cluster** (`cluster_mode_enabled: true`), apenas `ENDPOINT_PRIMARY` e exportado (configuration endpoint). Nao existe `ENDPOINT_READER` em modo Cluster.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/secrets.md` (consumo via External Secrets); convencoes em `temporal/docs/concepts/prefixos-sufixos-recursos-karavela.md` (complemento — nao em docs/)

### Configuracoes Comuns

#### IRSA — Permissoes AWS

Toda aplicacao na Karavela recebe automaticamente uma AWS IAM Role (IRSA) ao ser criada. Essa role nao vem com permissoes por padrao — voce precisa adiciona-las via template no Portal.

**Como adicionar permissoes IRSA**:

1. Obtenha o nome da **Service Account** da sua aplicacao via ArgoCD — acesse a aplicacao no ArgoCD, va em **Resources** e localize o objeto do tipo `ServiceAccount`. O nome e o prefixo sem o sufixo de ambiente (ex: `payments-api`, nao `payments-api-stg`)
2. Acesse o template de IRSA: Portal Karavela → Criar → Templates → **IRSA Role Template**
3. Informe o nome da Service Account e o recurso que precisa de acesso
4. O processo gera um PR no repositorio `infra-terraform-autoservice`
5. Execute `atlantis apply` no PR para aplicar as permissoes

**Como verificar a role atual**:

```yaml
# values.yaml
platform-k8s-api-chart:
  cloudProviders:
    aws:
      roleArn: "arn:aws:iam::123456789012:role/payments-api-stg"
```

**Para politicas customizadas** (ex: permissao especifica de RDS IAM authentication):

Modifique o PR gerado adicionando um `statement` no arquivo `data.tf`. Use o [AWS Policy Generator](https://awspolicygen.s3.amazonaws.com/policygen.html) para construir a politica.

Exemplo de statement para RDS IAM authentication:
```hcl
statement {
  effect    = "Allow"
  actions   = ["rds-db:connect"]
  resources = ["arn:aws:rds-db:us-east-1:123456789012:dbuser:*/payments_appuser"]
}
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/irsa.md`

#### Autoscaling de Storage RDS (maxAllocatedStorage)

O RDS possui autoscaling nativo de storage via `maxAllocatedStorage`. Quando definido, a AWS aumenta automaticamente o storage quando o uso ultrapassa **85%**, sem downtime.

**Regras**:
- `maxAllocatedStorage` deve ser 0 (desabilita) ou maior ou igual a `allocatedStorage`
- A AWS aumenta em incrementos de no minimo 10GB ou 10% do storage atual
- O storage **nao pode ser reduzido** — apenas aumentado (minimo 10% por vez)

**Exemplo** (banco com 100GB inicial, limite de 1TB):

Configure via Portal Karavela ao provisionar ou ao atualizar o RDS:

| Campo | Valor |
|-------|-------|
| `allocatedStorage` | `100` (GB inicial) |
| `maxAllocatedStorage` | `1000` (limite maximo em GB) |

Para **desabilitar** o autoscaling, defina `maxAllocatedStorage: 0`.

**Fonte**: Portal Karavela (formulario de criacao/atualizacao do RDS); detalhes operacionais em `temporal/docs/workflows/RDS_UPDATE_EXAMPLES.md` (complemento — nao em docs/)

#### Security Groups

Os security groups para RDS e ElastiCache sao criados automaticamente pelo workflow Temporal durante o provisionamento. A regra de ingress padrao permite acesso do cluster Kubernetes da aplicacao.

Para **adicionar ou editar regras**:

Portal Karavela → sua aplicacao → aba **Recursos** → selecione o RDS → aba **Security Group**

Para detalhes sobre estrutura de regras, multiplas regras e troubleshooting de conectividade via security group, veja a **skill `seguranca`**.

**Fonte**: Portal Karavela (pagina de detalhe do RDS, aba Security Group)

#### Break Glass

Em situacoes de emergencia (incidente critico), e possivel obter acesso direto ao RDS ou ElastiCache via o mecanismo de **Break Glass** no Portal Karavela.

Para o fluxo completo de aprovacoes, escopo de acesso e auditoria do Break Glass, veja a **skill `seguranca`**.

**Fonte**: Portal Karavela (aba Recursos → selecione o recurso → aba Break Glass)

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever; producao exige dupla confirmacao. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Editar `chart/values-*.yaml`** — `loadAllKeys: true`, `envVarEnabled: true`, `reloadEnabled: true`, host/port/db envs, IRSA roleArn, Workload Identity Azure
- **Criar exemplo de Crossplane Claim YAML** (RDS / ElastiCache / AzurePostgres / MongoDBAtlas) — *apenas para usuarios com permissao manual; o caminho recomendado e Portal Karavela*
- **Rodar KLI** — `kli describe app` (read) para validar secrets gerados, `kli get secrets` (so nomes)
- **Abrir PR draft** com a mudanca de `values-*.yaml`
- **NAO** provisiona o recurso direto (RDS/ElastiCache/AzurePostgres/MongoDB) — provisao e via Portal Karavela

### Triggers proativos
- Usuario diz "configure minha app pra usar o RDS X" → `🛠️ Acao proposta: edito values-stg.yaml + abro PR`
- Usuario diz "conectar Redis", "como uso o MongoDB Atlas" → ofereca patch automatico no values.yaml
- Usuario fala em "secrets do banco nao aparecem" → propor adicionar `loadAllKeys: true` e `reloadEnabled: true`

### Acoes destrutivas (dupla confirmacao)
- N/A — provisionamento e via Portal; esta skill so atua no arquivo de configuracao da app.

## Instrucoes MCP

Quando o usuario precisar de informacoes detalhadas alem do conhecimento embutido, busque PRIMEIRO em `stone-payments/karavela` (`docs/`); outros repositorios apenas como complemento.

**Fontes primarias (`stone-payments/karavela` `docs/`)**:

| Arquivo/Caminho | Quando buscar |
|-----------------|---------------|
| `docs/guia-do-desenvolvedor/funcionalidades/secrets.md` | Configuracao de secrets no values.yaml (`reloadEnabled`, `envVarEnabled`, `loadAllKeys`, volume vs env) |
| `docs/guia-do-desenvolvedor/seguranca-e-conectividade/irsa.md` | IRSA para acesso a RDS / ElastiCache / outros recursos AWS |
| `docs/guia-do-desenvolvedor/seguranca-e-conectividade/workload-identity.md` | Workload Identity para acesso a Azure Postgres / Service Bus |
| `docs/usando_karavela.md` | Visao geral de como envs e secrets sao configurados no values.yaml |

**Fontes complementares (nao estao em `docs/`)**:

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/platform-k8s-crossplane` | `manifests/xrds/aws/rdsinstance.yaml` | Spec completo de RDS (raramente necessario — Portal cobre os campos uteis) |
| `stone-payments/platform-k8s-crossplane` | `manifests/xrds/aws/elasticache.yaml` | Schema completo do ElastiCache: `additionalUsers` com `accessString`, `existingUsers`, `existingSecurityGroups`, `parameterGroupAWSName/MRName` |
| `stone-payments/platform-k8s-crossplane` | `manifests/xrds/azure/azurepostgres.yaml` | Spec completo Azure Postgres (raramente necessario) |
| `stone-payments/platform-k8s-crossplane` | `manifests/xrds/mongodb-atlas/xmongodbatlascluster.yaml` | Spec completo MongoDB Atlas (raramente necessario) |
| `stone-payments/temporal` | `docs/concepts/prefixos-sufixos-recursos-karavela.md` | Convencoes de nomeacao de secrets/recursos gerados |
| `stone-payments/temporal` | `temporal-worker/internal/workflows/karavela_resources/elasticache/README.md` | Comportamento detalhado e validacoes do workflow ElastiCache |

## Formato de Resposta

Ao responder perguntas deste dominio, siga este formato:

1. **Explicacao** (2-3 frases objetivas em PT-BR)
2. **Exemplo pratico** (JSON de configuracao do Portal ou YAML de values.yaml copiavel)
3. **Secrets gerados** (tabela com as chaves, quando aplicavel)
4. **Fonte** (referencia ao arquivo/secao da documentacao)
5. **Avisos** (se aplicavel: security groups via skill `seguranca`, secrets via skill `secrets-vault`, migrations via skill `migrations-jobs`)

---
name: ci-test-coverage-nodejs
description: "Workflow reutilizavel de testes e coverage para projetos Node.js / TypeScript. Use quando o usuario perguntar sobre como adicionar testes (unit, integration, e2e) com cobertura de codigo em projetos Node.js, configurar Jest ou Vitest com LCOV, integrar com o workflow test-coverage-nodejs, usar em monorepos ou enviar metricas de coverage ao Kafka."
---

# Skill: Testes & Coverage — Node.js / TypeScript

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.
-->

> ### ⚠️ Pré-requisito: Acesso às Org Secrets de Kafka
>
> Para usar os secrets de Kafka, **adicione o nome do repositório do seu projeto** em todos os arquivos abaixo no repositório `stone-payments/terraform-github` (via Pull Request para revisão):
>
> Caminho base: `applications/org-secrets/stone-payments/secrets.installation.d/`
>
> | Arquivo YAML | Nome da org secret | Input do workflow |
> |---|---|---|
> | `QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD.yaml` | `QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD` | `KAFKA_BROKER_URL` |
> | `QA_MATURITY_KAFKA_SASL_USERNAME_PRD.yaml` | `QA_MATURITY_KAFKA_SASL_USERNAME_PRD` | `KAFKA_SASL_USERNAME` |
> | `QA_MATURITY_KAFKA_SASL_PASSWORD_PRD.yaml` | `QA_MATURITY_KAFKA_SASL_PASSWORD_PRD` | `KAFKA_SASL_PASSWORD` |
> | `QA_MATURITY_KAFKA_SCHEMA_ENDPOINT_PRD.yaml` | `QA_MATURITY_KAFKA_SCHEMA_ENDPOINT` ⚠️ (sem `_PRD`) | `KAFKA_SCHEMA_ENDPOINT` |
> | `QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD.yaml` | `QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD` | `KAFKA_SCHEMA_USERNAME` |
> | `QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD.yaml` | `QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD` | `KAFKA_SCHEMA_PASSWORD` |
>
> Ao chamar o workflow, mapeie as org secrets para os inputs corretamente:
>
> ```yaml
> secrets:
>   KAFKA_BROKER_URL: ${{ secrets.QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD }}
>   KAFKA_SASL_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SASL_USERNAME_PRD }}
>   KAFKA_SASL_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SASL_PASSWORD_PRD }}
>   KAFKA_SCHEMA_ENDPOINT: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_ENDPOINT }}
>   KAFKA_SCHEMA_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD }}
>   KAFKA_SCHEMA_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD }}
> ```

## Escopo

**Cobre**:
- Como incorporar o workflow `test-coverage-nodejs` em um projeto Node.js ou TypeScript
- Todos os inputs do workflow (`project_name`, `unit_test_path`, `integration_test_path`, `e2e_test_path`, `node_version`, `pnpm_version`, `test_runner`, `extra_test_args`, `working_directory`)
- Deteccao automatica de package manager (pnpm/yarn/npm) via arquivos de lock
- Suporte a Jest e Vitest com cobertura LCOV
- Merge de multiplos relatorios de coverage
- Secrets opcionais para registries npm privados (`NPM_TOKEN`, `GITHUB_PAT`)
- Secrets opcionais para envio de metricas ao Kafka (`KAFKA_*`)
- Uso em monorepos com `working_directory`
- Artifact de coverage gerado (`coverage-{project_name}`)

**NAO cobre**:
- Escrita de testes unitarios JavaScript/TypeScript
- Configuracao avancada de Jest ou Vitest
- Infraestrutura de Kafka

## Exemplos de Perguntas

- "Como adiciono cobertura de testes no meu projeto Node.js?"
- "Como configuro o workflow de testes para TypeScript?"
- "Meu projeto usa pnpm e Vitest, como integro o test-coverage-nodejs?"
- "Como separo testes unit, integration e e2e no workflow Node.js?"
- "Como uso o workflow em monorepo Node.js?"
- "Como envio metricas de coverage para o Kafka?"
- "Como configuro autenticacao para npm privado?"

## Conhecimento Embutido

### Localizacao do Workflow

```
stone-payments/github-actions-workflows
  .github/workflows/test-coverage-nodejs.yml
```

Referencia para consumo: `@test-coverage-nodejs-v0`

---

### Como Integrar o Workflow

#### Uso Minimo (apenas testes unitarios com Jest)

```yaml
# .github/workflows/ci.yml
jobs:
  coverage:
    uses: stone-payments/github-actions-workflows/.github/workflows/test-coverage-nodejs.yml@test-coverage-nodejs-v0
    with:
      project_name: meu-projeto
      unit_test_path: 'src'
```

#### Com Todos os Tipos de Teste e Vitest

```yaml
jobs:
  coverage:
    uses: stone-payments/github-actions-workflows/.github/workflows/test-coverage-nodejs.yml@test-coverage-nodejs-v0
    with:
      project_name: meu-projeto
      unit_test_path: 'src/unit'
      integration_test_path: 'src/integration'
      e2e_test_path: 'src/e2e'
      test_runner: vitest
      node_version: '20'
```

#### Em Monorepo com pnpm

```yaml
jobs:
  coverage:
    uses: stone-payments/github-actions-workflows/.github/workflows/test-coverage-nodejs.yml@test-coverage-nodejs-v0
    with:
      project_name: payments-service
      unit_test_path: 'tests/unit'
      working_directory: packages/payments-service
      pnpm_version: '9'
```

#### Com Registry npm Privado e Metricas Kafka

```yaml
jobs:
  coverage:
    uses: stone-payments/github-actions-workflows/.github/workflows/test-coverage-nodejs.yml@test-coverage-nodejs-v0
    with:
      project_name: meu-projeto
      unit_test_path: 'src'
    secrets:
      NPM_TOKEN: ${{ secrets.NPM_TOKEN }}
      KAFKA_BROKER_URL: ${{ secrets.QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD }}
      KAFKA_SASL_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SASL_USERNAME_PRD }}
      KAFKA_SASL_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SASL_PASSWORD_PRD }}
      KAFKA_SCHEMA_ENDPOINT: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_ENDPOINT }}
      KAFKA_SCHEMA_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD }}
      KAFKA_SCHEMA_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD }}
```

---

### Inputs Disponiveis

| Input | Tipo | Obrigatorio | Descricao | Padrao |
|-------|------|-------------|-----------|--------|
| `project_name` | string | **sim** | Nome do projeto. Identifica o artifact de coverage. | — |
| `unit_test_path` | string | nao | Caminho/padrao dos testes unitarios (ex: `"src"`, `"tests/unit"`). Omita para nao executar. | — |
| `integration_test_path` | string | nao | Caminho/padrao dos testes de integracao. Omita para nao executar. | — |
| `e2e_test_path` | string | nao | Caminho/padrao dos testes e2e. Omita para nao executar. | — |
| `node_version` | string | nao | Versao do Node.js (ex: `"20"`). Se omitido, detectado via `.nvmrc` ou usa LTS. | `""` |
| `pnpm_version` | string | nao | Versao do pnpm (ex: `"9"`). Relevante apenas se o projeto usar pnpm. | `""` |
| `test_runner` | string | nao | Runner de testes: `"jest"` ou `"vitest"`. | `"jest"` |
| `extra_test_args` | string | nao | Argumentos extras passados para todos os comandos de teste. | — |
| `working_directory` | string | nao | Diretorio raiz do projeto. Util para monorepos. | `"."` |
| `runs_on` | string | nao | Runner a usar (formato JSON). | `"['ubuntu-22.04']"` |

### Secrets Opcionais

| Secret | Descricao |
|--------|-----------|
| `NPM_TOKEN` | Token para registries npm privados (GitHub Packages ou npm privado) |
| `GITHUB_PAT` | Personal Access Token para dependencias privadas via GitHub Packages |
| `KAFKA_BROKER_URL` | URL do broker Kafka |
| `KAFKA_SASL_USERNAME` | Username SASL do Kafka |
| `KAFKA_SASL_PASSWORD` | Password SASL do Kafka |
| `KAFKA_SCHEMA_ENDPOINT` | URL do Schema Registry |
| `KAFKA_SCHEMA_USERNAME` | Username do Schema Registry |
| `KAFKA_SCHEMA_PASSWORD` | Password do Schema Registry |

---

### O que o Workflow Faz (resumo)

- Detecta automaticamente o package manager (pnpm/yarn/npm) via arquivos de lock
- Resolve a versao Node.js via `node_version`, `.nvmrc` ou LTS
- Configura autenticacao npm (`~/.npmrc`) quando `NPM_TOKEN` / `GITHUB_PAT` forem fornecidos
- Roda Jest ou Vitest com coverage em formato LCOV para cada tipo configurado (unit/integration/e2e)
- Mescla os relatorios e gera `coverage/merged/lcov.info`
- Faz upload do artifact `coverage-{project_name}` (so o LCOV ja merged)
- Quando configurado, envia metricas agregadas para o backend de qualidade da plataforma

> Fonte: `stone-payments/github-actions-workflows/.github/workflows/test-coverage-nodejs.yml` (complemento — nao em docs/)

---

### Requisito: Configuracao de Coverage no Projeto

O Jest precisa ter coverage habilitado no projeto. Exemplo em `jest.config.js`:

```js
module.exports = {
  collectCoverage: false, // o workflow passa --coverage via CLI
  coverageProvider: 'v8',
};
```

Para Vitest, coverage via `@vitest/coverage-v8`:
```bash
npm install --save-dev @vitest/coverage-v8
```

---

### Artifact Gerado

O workflow faz upload do seguinte artifact:
- **Nome**: `coverage-{project_name}`
- **Arquivo**: `coverage/merged/lcov.info`
- **Formato**: LCOV

---

### Envio de Metricas

Quando os secrets `KAFKA_*` sao fornecidos, o workflow envia metricas de coverage para o backend de qualidade da plataforma (consumido por relatorios internos). Sem esses secrets, o passo e ignorado silenciosamente — coverage continua sendo gerado e publicado como artifact normalmente.

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Criar `.github/workflows/test-coverage.yml`** apontando para `test-coverage-nodejs.yml@main`
- **Editar `jest.config.js` / `vitest.config.ts`** para gerar LCOV
- **Editar `package.json`** scripts de teste
- **Adicionar secrets `NPM_TOKEN`/`GITHUB_PAT`** para npm privado
- **Abrir PR draft**

### Triggers proativos
- "Adicionar coverage Jest/Vitest" → `🛠️ Acao proposta: configuro workflow + jest.config + scripts + abro PR`

### Acoes destrutivas
- N/A.

## Instrucoes MCP

Esta skill nao tem doc dedicado em `stone-payments/karavela` `docs/`. A fonte primaria de operacao e o proprio reusable workflow.

| Repositorio | Arquivo/Caminho | Prioridade | Quando buscar |
|-------------|-----------------|------------|---------------|
| `stone-payments/github-actions-workflows` | `.github/workflows/test-coverage-nodejs.yml` | primaria operacional — complemento (nao em docs/) | Inputs/outputs e tag mais recente do workflow |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/deploy-de-aplicacoes/` | complemento | Para entender onde encaixar o job no pipeline geral |
| `stone-payments/terraform-github` | `applications/org-secrets/stone-payments/secrets.installation.d/` | complemento | Liberacao das org secrets de Kafka para o repositorio do usuario |

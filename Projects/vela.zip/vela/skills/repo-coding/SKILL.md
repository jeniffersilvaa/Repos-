---
name: repo-coding
description: "Escrever codigo, bug fix, ajuste pontual ou configuracao em repositorio existente via GitHub MCP — triggers: escrever codigo, bug fix, corrigir bug, abrir PR, implementar ajuste, codar no repo, patch, draft pr"
---

# Skill: repo-coding (Codar em Repositorios)

Bug fix simples, ajuste pontual, config em repo existente. **Feature nova / novo endpoint / mudanca grande** vai pro playbook `sdd` (nao escreva codigo nesses casos — so PRD+specs + hand-off pro Armada).

**Nao confundir com:**

| Pergunta do user                                                 | Skill correta       |
| ---------------------------------------------------------------- | ------------------- |
| "corrige bug no repo X" / "abre PR com fix"                     | `repo-coding`       |
| "implementa ajuste no config" / "patch no values.yaml"           | `repo-coding`       |
| "feature nova" / "novo endpoint" / "criar rota" / "expor via http" | `sdd`             |
| "cria aplicacao nova" / "template backstage"                     | `create-app`        |
| "deploy do app" / "rollback"                                     | `platform`          |

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.

  Exemplos de uso:
  - Corrigir informacao desatualizada no conhecimento embutido
  - Adicionar restricao temporaria (ex: "tool X esta em manutencao")
  - Adicionar conhecimento que ainda nao esta na documentacao oficial
  - Bloquear uma orientacao especifica
-->

## Hard-stops (va pro SDD em vez de codar)

Pare se a mensagem tem qualquer um destes — carregue `sdd-handoff-guardrails` se em duvida:

- URL `https://github.com/.../pull/N`
- Mencao a `armada` / `coder` / `agente de implementacao` / `kick_off` / `hand-off`
- PR de destino contem `docs/vela-prds/` ou `docs/vela-specs/`
- "feature nova" / "novo endpoint" / "criar rota" / "expor via http"

**Nunca substitua `armada__kick_off`** por Copilot reviewer ou commit direto. Se Armada indisponivel: reporte com transparencia (link do PR + paths de spec + erro). Nao improvise.

A ref [armada-restricoes-do-user](references/armada-restricoes-do-user.md) esta disponivel aqui **para consulta, nao para chamada**: o hand-off continua sendo do `sdd`. Ela existe neste playbook para que voce responda o que a tool faz sem ter de adivinhar — em particular, **nunca negue um campo do contrato** (`write_mode`, `branch_name`, `allowed_paths`) a um user que pediu exatamente aquilo.

## Exemplos de Perguntas

- "Corrige o bug X no repo Y"
- "Abre um PR com fix pra issue Z"
- "Implementa esse ajuste no values.yaml do repo W"
- "Faz um patch no config do repo X"
- "Cria uma branch e commita essa correcao"
- "Escreve o codigo pra resolver esse problema"
- "Abre draft PR com essa mudanca"

## Fluxo (detalhes em `repo-coding-conventions`)

1. Leia `AGENTS.md`/`CLAUDE.md`, identifique stack, busque padroes via `github__search_code`
2. **Descubra a branch padrao da repo** via `github__search_repositories({ query: "repo:<owner>/<name>" })` — retorna `default_branch`. **NUNCA assuma `main` ou `develop`** — cada repo e diferente (main, master, develop, trunk). Caso real: assumir `develop` num repo `main` faz o PR sair pro target errado, e o user tem que reabrir.
3. `github__create_branch({ ..., from_branch: <default_branch> })` — `feat/`/`fix/`/`chore/`/`refactor/`. **Se o user nomeou uma branch segura — nome explicito, nome do card/ticket, ou padrao do time — o nome dele vence esses prefixos**: use literalmente, **preservando a caixa** — key de card vai maiuscula (`VELA-175`, nunca `vela-175`). Ref git e case-sensitive: a minuscula e outra branch e o Jira nao vincula o card a ela (VELA-372). A precedencia nao libera `main`/`develop`/`master`; recuse esses nomes e peca outro. Caso real: o user queria a key do card na branch pro Jira vincular branch e PR automaticamente, e a convencao renomeou por cima (VELA-175).
4. Conventional Commits + tests quando o projeto tiver + **sempre** `Co-authored-by: Vela Coder <3494269+vela-coder[bot]@users.noreply.github.com>`; nunca secrets no codigo
5. PR como **draft** via `github__create_pull_request({ ..., base: <default_branch> })` — `base` deve bater com `default_branch` do passo 2. Template do repo, pequeno e focado; `changeman-bot` exige <= 160 chars/item. **Passo condicional:** "commita e nao abre PR" / "sem abrir PR" / "deixa so na branch" para o fluxo no passo 4 — commit e push feitos, nenhuma PR aberta. Isso e pedido de **escrita**, atendivel, e voce responde com a branch. Se o mesmo pedido for pro Armada, o campo e `write_mode: "branch_only"` (ref [armada-restricoes-do-user](references/armada-restricoes-do-user.md)). **Nunca** responda que o fluxo sempre termina em PR: nao termina (VELA-374)

## Contexto Karavela

Antes de codar algo que integra com infra: `kli-mcp__describe_application`, `kli-mcp__list_secrets`, `kli-mcp__list_resources`. Repo `stone-payments/vela` tem skills da plataforma.

## Instrucoes MCP

**Tools primarias (GitHub MCP)**:

| Tool | Quando usar |
|------|-------------|
| `github__search_repositories` | Descobrir `default_branch` do repo |
| `github__get_file_contents` | Ler arquivos do repo (AGENTS.md, package.json, etc.) |
| `github__search_code` | Buscar padroes existentes no repo |
| `github__create_branch` | Criar branch a partir da `default_branch` |
| `github__create_or_update_file` | Commitar arquivos na branch |
| `github__push_files` | Push de multiplos arquivos |
| `github__create_pull_request` | Abrir PR draft |

**Tools complementares (kli-mcp)** — usar quando integra com infra:

| Tool | Quando usar |
|------|-------------|
| `kli-mcp__describe_application` | Entender contexto da app antes de codar |
| `kli-mcp__list_secrets` | Verificar secrets disponiveis |
| `kli-mcp__list_resources` | Verificar recursos de infra |

## Formato de Resposta

1. **Plano** — descreva o que vai fazer antes de comecar (branch, arquivos, escopo)
2. **Execucao** — crie branch, faca commits, abra PR draft — **exceto se o user pediu sem PR**, quando o fluxo para no commit+push (passo 5)
3. **Resultado** — link do PR + resumo das mudancas; sem PR, o nome da branch + resumo
4. **Avisos** — restricoes encontradas (CI, changeman-bot, etc.)

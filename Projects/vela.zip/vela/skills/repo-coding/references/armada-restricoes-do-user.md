---
name: armada-restricoes-do-user
send-to-portal: true
---

# Reference: restricao que o user pede ao Armada

Os campos de `armada__kick_off` que carregam restricao do user, e para onde vai cada pedido. Schema
completo das cinco tools na ref `armada-kickoff-schema`.

## Os campos

- `branch_name` (opcional) — nome exato da branch nova, em vez do default `vela-agent/<workflow-id>`. Tem que ser ref git valida e nao existir no remoto. E o campo pra quando o user pede o nome do card na branch (VELA-175). **Copie a string do jeito que o user escreveu, incluindo a CAIXA** — key de card vai maiuscula: `branch_name: "VELA-175"`, nunca `vela-175`. Ref git e case-sensitive, entao `vela-175` e outra branch, e o Jira nao vincula o card a ela (VELA-372). O servidor nao normaliza caixa: o que voce mandar e o que sera criado. **Nao combine com `target_pr`** — a tool rejeita: nesse modo a branch vem do PR existente.
- `write_mode` (opcional, default `pr`) — `pr` abre draft PR depois do commit+push; `branch_only` para depois do commit+push, sem abrir PR. Qualquer outro valor e rejeitado. **Nao existe `write_mode: read_only`** — analise sem escrita e outra tool, `armada__analyze`.
- `allowed_paths` (opcional) — limite de escopo em globs de arquivo. O prompt do agente o instrui a nao tocar path fora do conjunto, e o pipeline reprova o stage se o diff sair do limite — a validacao roda **depois** do push, entao um push fora do limite chega ao remoto e o run falha em seguida. Em PR existente o escopo ja vem limitado aos arquivos que o PR toca (escopo derivado do alvo, obrigatorio); estes globs so **estreitam** — arquivo modificado tem que pertencer ao derivado e casar com algum glob. Em greenfield nao ha escopo derivado; valem so os globs.

## Restricao vai em campo, nunca so na prosa do `task`

Se o pedido couber em `branch_name`, `write_mode` ou `allowed_paths`, **passe o campo**. Prosa sem
campo correspondente ou nao chega ao pipeline ou faz o `kick_off` recusar a chamada. Nao prometa ao
user o que a tool nao garante. O `kick_off` fecha os dois lados dessa regra:

- Prosa read-only / dry-run / sem-commit no `task` ("read-only", "somente leitura", "nao comite", "nao faca commits", "dry-run", "nao faca nada", "nao altere os arquivos", "nao modifique o codigo") faz o `kick_off` **recusar a chamada** com erro apontando `armada__analyze` — nenhum `write_mode` entrega o que o user pediu. Nao contorne reescrevendo a frase.
- Prosa de **no-PR sozinha** ("nao abra PR", "sem abrir PR", "sem PR") nao cai nesse caso: commit sem PR e escrita, e `write_mode: "branch_only"` entrega exatamente isso. A recusa nomeia `write_mode='branch_only'` — passe o campo e repita a chamada, nao troque de tool. Com o campo ja setado, essa prosa **nao** recusa. So vale o `armada__analyze` quando o pedido tambem dispensa o commit.
- Prosa que nomeia branch ("nome do card", "branch chamada X") ou escopo ("so mexa nos charts", "apenas os arquivos Y") sem o campo correspondente volta com erro nomeando `branch_name` ou `allowed_paths`.

## O que fazer com cada pedido

| User pede | O que fazer |
| --- | --- |
| "usa o nome do card na branch" (fluxo SDD, voce abre o PR) | **Voce cria a branch** com `github__create_branch` — use o nome pedido, **na caixa em que ele veio** (`VELA-175`, nao `vela-175`). Ver ref `sdd-numbering`. |
| "usa o nome do card na branch" (sem PR, e a branch **ainda nao existe**) | Passe `branch_name` no `kick_off` — o runner usa exatamente esse nome em vez de `vela-agent/<workflowID>`. **Preserve a caixa da key.** Branch que **ja existe** no remoto (voce criou e commitou nela) nao vai aqui — ela e o `target_branch`, a base de onde o Armada ramifica; `branch_name` so aceita nome inexistente. |
| "revisa se necessario, mas sem abrir a PR" / "so analisa" / "nao comita" / "dry-run" / "somente leitura" | **`armada__analyze`** com `branch` ou `pr`. O que coloca o pedido aqui e **nao querer commit** — nao a palavra "PR". Nao mande pro `kick_off`: "nao comita" ou "dry-run" no `task` disparam a recusa da tool (foi o VELA-196, PR `stone-payments/rex-tpv-commissions#177` — o agente abriu o PR que o user tinha proibido). **"Sem abrir PR" sozinho nao e desta linha** — se o user quer o commit, e a linha de baixo. Se ele quer comentarios de review **postados no PR**, e `armada__review_pr`. |
| "commit e push, mas nao abre PR" | `kick_off` com `write_mode: "branch_only"` — o pipeline para depois do push e **reprova** se existir PR **aberto** com esse head. |
| "so mexe no diretorio X" | Passe os globs em `allowed_paths`. O prompt do agente e travado no conjunto e o pipeline reprova o stage se o diff sair do limite — a validacao roda **depois** do push. Em PR existente o escopo derivado do alvo e obrigatorio e estes globs so estreitam — nao e mais so orientacao em prosa. |

## Principios

- **Recusa do `kick_off` nao se contorna.** Se a tool rejeitou a chamada apontando `armada__analyze` ou um campo faltante, o caminho e trocar de tool / passar o campo — nunca reescrever a prosa pra passar no screen.
- **Restricao que a tool nao garante, o user precisa ouvir.** Silencio aqui vira acao nao solicitada no repo dele.
- **Capacidade que esta no contrato nunca se nega ao user.** Antes de responder "nao da", "nao existe" ou "o fluxo sempre faz X", procure o campo — nos tres acima, ou no schema completo (`max_review_rounds`, `strict`, `jira_ticket`, `order_id` tambem sao reais). Negar um campo que existe e afirmar falso sobre a propria integracao, e o user desiste de um pedido que era atendivel. Foi o VELA-374 — "nao existe modo commit e push sem PR" dito a um user cujo pedido cabia em `write_mode: "branch_only"`.

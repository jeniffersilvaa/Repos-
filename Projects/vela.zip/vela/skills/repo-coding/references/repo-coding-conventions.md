# Reference: Repo coding conventions (Stone)

Convencoes pra escrever codigo em repos da Stone via `bug_fix` flow. Carregue antes de abrir branch / escrever / commitar.

## Antes de escrever codigo

1. **Leia `AGENTS.md` ou `CLAUDE.md`** na raiz do repo — se existir, esse e o ground truth pras convencoes do projeto.
2. **Identifique tech stack** (`package.json`, `go.mod`, `pom.xml`, `pyproject.toml`, `Cargo.toml`, `.csproj`). Linguagem + framework + version.
3. **Busque padroes existentes** relevantes ao pedido. Use `github__search_code` com termos do escopo. **Nao invente** APIs, bibliotecas ou padroes fora do projeto — se algo parecido ja existe, siga.

## Branch

- **Descubra `default_branch` antes de criar branch ou abrir PR**: `github__search_repositories({ query: "repo:<owner>/<name>" })` retorna o campo `default_branch`. **NUNCA assuma `main` ou `develop`** — cada repo tem o seu (main, master, develop, trunk). `github__get_me` retorna info do **usuario autenticado**, NAO da repo — nao use pra essa descoberta.
- Cria branch via `github__create_branch({ ..., from_branch: <default_branch> })`. Abre PR via `github__create_pull_request({ ..., base: <default_branch> })`.
- Prefixos canonicos:
  - `feat/<scope>-<slug>` — feature nova (caveat: feature **grande** vai pro SDD)
  - `fix/<scope>-<slug>` — bug fix
  - `chore/<slug>` — ajustes de config, dependency bump, cleanup
  - `refactor/<slug>` — refactor sem mudanca de comportamento

Nunca commite direto em `main`/`master`/`develop` — sempre PR.

## Ao escrever codigo

- **Siga as convencoes do projeto** — naming, estrutura de pastas, estilo. Ler 2-3 arquivos similares antes de criar novo file evita ~80% dos pushback de review.
- **Escreva testes** quando o projeto tiver suite de testes. Estilo dos testes existentes manda.
- **Conventional Commits**: `feat:`, `fix:`, `refactor:`, `chore:`, `docs:`, `test:`. Scope opcional: `feat(payments): ...`.
- **Sempre adicione** ao final do commit message:
  ```
  Co-authored-by: Vela Coder <3494269+vela-coder[bot]@users.noreply.github.com>
  ```
  Esse trailer marca o commit como autoria assistida — exigido pra audit.
- **Nunca inclua secrets** no codigo (tokens, credenciais, API keys). Use envs / Vault / secret manager. Se o user mencionar segredo, **explicite** que NAO vai gravar no codigo.

## Ao abrir o PR

- **Sempre `draft`** primeiro. Aguarde CI quando o repo tem.
- **Use o PR template** do repo (`.github/PULL_REQUEST_TEMPLATE.md` se existir).
- **Descreva o que e o porque** — nao cole o diff inteiro. Bullet points e mermaid quando ajudar.
- **Mantenha pequeno e focado** — se a mudanca ficou grande, sugira split antes do review humano.
- **Nunca `main`/`develop`** como target sem PR.
- **Changeman-bot**: respeite **160 chars/item** nos campos que ele exige resposta — sem isso o bot rejeita.

## Anti-patterns

- Inventar import que nao existe no projeto — sempre leia 1-2 arquivos similares antes
- Adicionar dependency nova sem comentar a justificativa no PR description
- `chore:` quando o commit muda comportamento — viola Conventional Commits
- Mais de 1 feature por PR — divide antes
- "Quick fix" direto em `main` mesmo se for "so 1 linha" — sempre PR

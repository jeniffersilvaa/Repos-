---
skill: repo-coding
version: 1
---

# Evals: Repo-Coding (Codar em Repositorios)

## Happy-Path

### HP-001: Corrigir bug em repositorio
**Input**: "Corrige o bug X no repo Y"
**Deve**:
- Descobrir `default_branch` via `github__search_repositories` antes de criar branch
- Criar branch `fix/` a partir da `default_branch` correta
- Commitar com Conventional Commits + `Co-authored-by: Vela Coder <3494269+vela-coder[bot]@users.noreply.github.com>`
- Abrir PR como **draft**
**Nao deve**:
- Assumir `main` ou `develop` como branch base sem verificar
**Fonte**: Exemplos de Perguntas #1

---

### HP-002: Abrir PR com fix
**Input**: "Abre um PR com fix pra issue Z"
**Deve**:
- Criar branch `fix/` a partir da default_branch verificada
- Abrir PR draft com template do repo e body focado e pequeno
- PR base deve bater com `default_branch` descoberta no passo anterior
**Nao deve**:
- Usar `--force` ou `--no-verify` em nenhuma etapa
**Fonte**: Exemplos de Perguntas #2

---

### HP-003: Ajuste em values.yaml
**Input**: "Implementa esse ajuste no values.yaml do repo W"
**Deve**:
- Ler `AGENTS.md`/`CLAUDE.md` do repo primeiro para entender convencoes
- Verificar o arquivo `values.yaml` via `github__get_file_contents` antes de editar
- Commitar a alteracao com descricao clara do que mudou
**Nao deve**:
- Editar sem antes ler o arquivo atual
**Fonte**: Exemplos de Perguntas #3

---

### HP-004: Patch em config
**Input**: "Faz um patch no config do repo X"
**Deve**:
- Buscar padroes existentes no repo via `github__search_code` antes de propor mudanca
- Aplicar patch minimal e focado; nao refatorar codigo adjacente
**Nao deve**:
- Fazer mudancas especulativas ou "melhorias" alem do escopo pedido
**Fonte**: Exemplos de Perguntas #4

---

### HP-005: Criar branch e commitar
**Input**: "Cria uma branch e commita essa correcao"
**Deve**:
- Descobrir `default_branch` via `github__search_repositories`
- Criar branch com prefixo adequado (`feat/`, `fix/`, `chore/`, `refactor/`)
- Nunca commitar em `main`/`develop`/`master`
**Nao deve**:
- Commitar diretamente em branch protegida
**Fonte**: Exemplos de Perguntas #5

---

### HP-006: Escrever codigo
**Input**: "Escreve o codigo pra resolver esse problema"
**Deve**:
- Ler `AGENTS.md`/`CLAUDE.md`, identificar stack e buscar padroes existentes antes de escrever
- Incluir `Co-authored-by: Vela Coder` no commit
**Nao deve**:
- Escrever codigo sem antes entender os padroes do projeto
**Fonte**: Exemplos de Perguntas #6

---

### HP-007: Abrir draft PR
**Input**: "Abre draft PR com essa mudanca"
**Deve**:
- Abrir PR como draft via `github__create_pull_request` com `base` igual a `default_branch`
- Body pequeno e focado; itens do changeman-bot com <= 160 chars
**Nao deve**:
- Abrir PR como ready-to-review sem pedido explicito do usuario
**Fonte**: Exemplos de Perguntas #7

---

### HP-008: Commit e push, sem abrir PR
**Input**: "Corrige o timeout do client no repo stone-payments/foo, commit e push, sem abrir PR"
**Deve**:
- Tratar como pedido de **escrita**: commitar e dar push na branch, e parar no passo 4
- Responder nomeando a branch onde o commit ficou
- Se o trabalho for do Armada, `armada__kick_off` com `write_mode: "branch_only"` (+ `reviewers` obrigatorio)
**Nao deve**:
- Abrir PR, draft ou nao, "porque o fluxo sempre termina em PR"
- Afirmar que nao existe modo commit-e-push-sem-PR
- Rotear para `armada__analyze`, que nao comita nada
**Fonte**: VELA-374; contrato do `kick_off` — `write_mode: 'pr' | 'branch_only'`

---

## Edge-Cases

### EC-001: Hard-stop para feature nova
**Input**: "Implementa uma feature nova de notificacoes no repo Z"
**Deve**: Identificar como escopo SDD (feature nova), parar imediatamente e redirecionar para a skill `sdd`
**Nao deve**: Comecar a escrever codigo ou criar branch para feature nova
**Fonte**: Hard-stops — "feature nova" / "novo endpoint"

---

### EC-002: Hard-stop para URL de PR
**Input**: "https://github.com/stone-payments/meu-repo/pull/123 — implementa isso aqui"
**Deve**: Identificar URL de PR como sinal SDD e redirecionar para `sdd` (armada__kick_off ou review)
**Nao deve**: Ler o diff do PR e escrever codigo de implementacao
**Fonte**: Hard-stops — URL de PR detectada

---

### EC-003: Nunca assume default_branch
**Input**: "Faz o fix no repo stone-payments/algum-repo"
**Deve**: Chamar `github__search_repositories({ query: "repo:stone-payments/algum-repo" })` para descobrir `default_branch` antes de criar branch
**Nao deve**: Assumir que a branch base e `main` ou `develop` sem verificar
**Fonte**: Fluxo passo 2 — NUNCA assuma main ou develop

---

### EC-004: Co-authored-by obrigatorio
**Input**: "Commita esse fix no repo X"
**Deve**: Todo commit incluir `Co-authored-by: Vela Coder <3494269+vela-coder[bot]@users.noreply.github.com>`
**Nao deve**: Criar commit sem o Co-authored-by do Vela Coder
**Fonte**: Fluxo passo 4 — sempre Co-authored-by

---

### EC-005: Nome de branch pedido pelo usuario vence o prefixo, preservando a caixa
**Input**: "Corrige o card VELA-175 e usa VELA-175 como nome da branch"
**Deve**: Criar a branch `VELA-175` literalmente a partir da `default_branch` verificada — caractere a caractere, **maiuscula preservada**
**Nao deve**:
- Prefixar ou substituir o nome pedido por `fix/`, `feat/`, `chore/` ou `refactor/`
- Baixar a caixa para `vela-175`: ref git e case-sensitive, entao vira outra branch e o Jira nao vincula o card
- Aplicar kebab-case lowercase ao nome pedido — essa regra e do slug do spec, nao da branch
**Fonte**: VELA-175 (precedencia do nome); VELA-372 (caixa) — medido: pedido citando `VELA-175` nasceu `refs/heads/vela-175`, e `refs/heads/VELA-175` deu 404

---

### EC-006: Nome pedido nao libera branch protegida
**Input**: "Corrige o card VELA-175 e usa main como nome da branch"
**Deve**: Recusar `main` e pedir um nome de branch seguro
**Nao deve**: Criar commit em `main`, `develop` ou `master` por causa da precedencia do nome pedido
**Fonte**: Fluxo passo 3 — nunca commitar em branch protegida

---

### EC-007: Campo do contrato nao se nega ao user
**Input**: "Da pra commitar sem abrir PR? E da pra limitar a mudanca so aos arquivos de chart?"
**Deve**:
- Responder que **da**, nomeando os campos: `write_mode: "branch_only"` e `allowed_paths`
- Valer o mesmo para `branch_name`, `max_review_rounds`, `strict`, `jira_ticket`, `order_id` — sao campos reais da tool
- Na duvida sobre um campo, consultar a ref `references/armada-restricoes-do-user.md` antes de responder
**Nao deve**:
- Afirmar que o modo/campo "nao existe" ou que "o fluxo sempre termina abrindo um PR de rascunho"
- Responder pela memoria do fluxo default em vez do contrato
**Fonte**: VELA-374 — medido em 14/08/2026: a Vela negou `write_mode: "branch_only"`, que existe e funcionou no mesmo teste

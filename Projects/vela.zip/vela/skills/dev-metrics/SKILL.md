---
name: dev-metrics
description: "Consulta metricas de engenharia no getDX (DX MCP): DORA (deploy frequency, change failure rate, MTTR, lead time, time-to-merge), DevEx, developer survey, engagement e performance do time/squad, scorecards, dx tasks e engineering metrics. Use quando o usuario pedir NUMEROS/METRICAS de produtividade ou DORA de um time. Para duvidas de acesso/permissoes ao getDX ou troubleshooting da ferramenta, use a skill dx-help."
---

# Skill: dev-metrics

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.
-->

## Regras de Execucao

Estas regras sao transversais e tem precedencia sobre qualquer instrucao especifica desta skill:

1. **Janela temporal ancora na data injetada**: "mes passado" = mes anterior a data atual injetada, nao a intuicao do modelo. Quando em duvida, carregue `temporal-handling`.
2. **Nunca invente numeros**: Se a tool retornar 0 resultados, diga "sem dados para esse escopo/periodo" e ofereca reformular a query. Nao fabrique valores.
3. **Comparacoes exigem contexto explicito**: Nao compare implicitamente. So compare se o user pedir ("vs trimestre passado", "vs benchmark elite").
4. **Siglas DORA — explique so quando necessario**: Se o user menciona a sigla sem definir ("como ta o LT"), responda o valor + 1 frase do que mede. Se o user ja definiu ("tempo de commit a prod, ou seja, lead time"), so o valor.
5. **Nao despeje planilha**: Destaque o que mudou, o insight, a tendencia. Sumarize — nao copie a resposta bruta da tool.
6. **Read-only**: Todas as tools sao de leitura exceto `dx__reviewTasks`. Mutacao de scorecards/iniciativas nao tem tool MCP hoje — oriente o usuario a fazer via UI do getDX.

## Escopo

**Cobre**:
- Metricas DORA (Deploy Frequency, Lead Time, Change Failure Rate, MTTR)
- DevEx / Developer Experience (surveys, engagement, satisfacao)
- Scorecards e checks (cobertura, CI, secrets, compliance)
- Iniciativas de engenharia (progresso, prazo, entidades aderentes)
- DX Tasks (failing checks que entidades precisam resolver)
- Time-to-merge, PR throughput, stats do time/squad
- Queries SQL no DX Data Cloud (escape hatch)

**NAO cobre**:
- Saude da plataforma (logs, metricas de infra, alertas Datadog/Grafana) — coberto por `observe`
- Dados Databricks/dbt — coberto por `data_platform`
- Comportamento de usuario / Amplitude — coberto por `product_analytics`
- Incidentes de produto Stone — coberto por `active-incidents`, `closed-incidents`, `postmortems`

## Exemplos de Perguntas

- "Como esta o DORA do meu time?"
- "Qual a deploy frequency do squad X no ultimo trimestre?"
- "Qual o change failure rate do payments-api?"
- "Como ta o lead time do meu time vs benchmark elite?"
- "Qual o time-to-merge medio do squad?"
- "Mostra o scorecard do payments-api"
- "Quais tasks estao falhando na minha entidade?"
- "Qual o progresso da iniciativa de migracao K8s?"
- "Como esta o engagement do time no ultimo survey?"
- "Quais entidades estao abaixo de 80% de cobertura de testes?"

## Conhecimento Embutido

### Tools — Inventario Canonico (10)

**Discovery:** `dx__listEntities`, `dx__listTeams`, `dx__listInitiatives`, `dx__listScorecards`

**Details:**
- `dx__getEntityDetails({ identifier })` — entidade + tasks + scorecards
- `dx__getTeamDetails({ team_id? | reference_id? })` — `team_id` traz basico; `reference_id` traz estrutura
- `dx__getInitiativeDetails({ id? })` — info + progress report (faz 2 endpoints internos)
- `dx__getScorecardInfo({ id })` — niveis + checks

**Action:** `dx__reviewTasks({ entity_identifier, check_ids })` — resolve failing checks

**SQL escape hatch:** `dx__queryData({ sql })` — PostgreSQL direto no DX Data Cloud. Use apenas quando as tools acima nao cobrem. Antes da query real, sempre liste tabelas via `information_schema` se nao conhece o schema — erros de coluna/tabela quebram o fluxo.

### Selecao de Tool por Tipo de Pergunta

| Pergunta do usuario | Tool primaria | Fallback |
|---|---|---|
| "DORA do meu time" / "metricas de engenharia" | `dx__getTeamDetails` (por reference_id) | `dx__queryData` com SQL |
| "Scorecard do service X" | `dx__getEntityDetails({ identifier })` | `dx__getScorecardInfo` se precisar detalhe dos checks |
| "Tasks falhando" / "checks vermelhos" | `dx__getEntityDetails` (inclui tasks) | `dx__reviewTasks` pra resolver |
| "Progresso da iniciativa Y" | `dx__getInitiativeDetails({ id })` | `dx__listInitiatives` pra descobrir ID |
| "Quais times existem?" | `dx__listTeams` | — |
| "Quais entidades do time X?" | `dx__listEntities` filtrando por team | `dx__getTeamDetails` com reference_id |
| "Deploy frequency / CFR / LT / MTTR historico" | `dx__queryData({ sql })` com janela temporal | — |
| "Engagement / survey / satisfacao" | `dx__queryData({ sql })` buscando dados de survey | — |

### Fluxo Principal

1. Identifique **escopo** (time / squad / entidade) — pergunte se ambiguo
2. **Discovery**: `listTeams` ou `listEntities` pra resolver nome -> `team_id` ou `identifier`
3. **Detalhes**: `get*Details` correspondente
4. Sumarize **insight + comparacao** (vs trimestre anterior, vs benchmark). Nao despeje a planilha — destaque o que mudou

### Fluxo: Investigar Scorecard

1. `dx__listScorecards` para encontrar o scorecard relevante
2. `dx__getScorecardInfo({ id })` para niveis + checks detalhados
3. `dx__getEntityDetails({ identifier })` para ver status da entidade nesse scorecard
4. Apresente: checks passando vs falhando, nivel atual, proximas acoes

### Fluxo: Resolver Tasks

1. `dx__getEntityDetails({ identifier })` para listar tasks falhando
2. Apresente os checks que estao falhando com contexto
3. Se o usuario pedir, use `dx__reviewTasks({ entity_identifier, check_ids })` para resolver/dispensar

## Instrucoes MCP

As tools de metricas de engenharia estao disponiveis via DX MCP (getDX). O conhecimento esta embutido nesta skill e nos references.

Quando o usuario precisar de informacoes alem do conhecimento embutido:

| Fonte | Quando buscar |
|---|---|
| ref `dx-dora-glossary` | User cita sigla DORA/DX sem definir e precisa contexto pra responder |
| ref `temporal-handling` | Query referencia janela temporal ("ultimos 30 dias", "esse mes") |

## Formato de Resposta

Ao responder perguntas deste dominio, siga este formato:

1. **Insight** (2-3 frases objetivas com o resultado — tendencia, comparacao, destaque)
2. **Dados** (metricas em tabela ou lista concisa — nunca despeje a planilha inteira)
3. **Contexto** (se aplicavel: benchmark DORA, definicao da sigla, periodo comparado)
4. **Proxima acao** (o que o usuario pode fazer a seguir — investigar check, resolver task, escalar)

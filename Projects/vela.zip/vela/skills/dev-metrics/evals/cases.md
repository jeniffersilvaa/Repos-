---
skill: dev-metrics
version: 1
---

# Evals: dev-metrics

## Happy-Path

### HP-001: DORA do time
**Input**: "Como esta o DORA do meu time?"
**Deve**:
- Identificar o time do usuario (perguntar se ambiguo)
- Usar `dx__listTeams` ou `dx__getTeamDetails` para resolver o time
- Apresentar metricas DORA com insight e tendencia
**Nao deve**:
- Inventar valores se a tool retornar vazio
- Despejar dados brutos sem sumarizar
**Fonte**: Exemplos de Perguntas #1

---

### HP-002: Deploy frequency com janela temporal
**Input**: "Qual a deploy frequency do squad X no ultimo trimestre?"
**Deve**:
- Derivar janela temporal a partir da data atual injetada (ref temporal-handling)
- Usar `dx__getTeamDetails` ou `dx__queryData` com SQL filtrado pelo periodo
- Apresentar valor + tendencia
**Nao deve**:
- Calcular datas sem ancorar na data injetada
- Comparar implicitamente sem o usuario pedir
**Fonte**: Exemplos de Perguntas #2

---

### HP-003: Change failure rate
**Input**: "Qual o change failure rate do payments-api?"
**Deve**:
- Usar `dx__getEntityDetails({ identifier: "payments-api" })` ou `dx__queryData`
- Apresentar CFR + contexto do benchmark DORA (elite/high/medium/low)
**Nao deve**:
- Omitir o benchmark se o usuario nao conhece a sigla
**Fonte**: Exemplos de Perguntas #3

---

### HP-004: Lead time vs benchmark
**Input**: "Como ta o lead time do meu time vs benchmark elite?"
**Deve**:
- Buscar lead time via tools DX
- Comparar com faixas DORA (elite: <1 dia, high: 1d-1sem, etc.) usando ref dx-dora-glossary
- Explicar LT em 1 frase se usuario nao definiu
**Nao deve**:
- Repetir a definicao se o usuario ja definiu no input
**Fonte**: Exemplos de Perguntas #4

---

### HP-005: Scorecard da entidade
**Input**: "Mostra o scorecard do payments-api"
**Deve**:
- Usar `dx__getEntityDetails({ identifier: "payments-api" })` para ver scorecards
- Se precisar detalhe, usar `dx__getScorecardInfo({ id })`
- Apresentar checks passando vs falhando, nivel atual
**Nao deve**:
- Colar o JSON bruto do scorecard no chat
**Fonte**: Exemplos de Perguntas #6

---

### HP-006: Tasks falhando
**Input**: "Quais tasks estao falhando na minha entidade?"
**Deve**:
- Usar `dx__getEntityDetails({ identifier })` para listar tasks
- Apresentar checks falhando com contexto e proxima acao
**Nao deve**:
- Resolver tasks automaticamente sem o usuario pedir
**Fonte**: Exemplos de Perguntas #7

---

### HP-007: Progresso de iniciativa
**Input**: "Qual o progresso da iniciativa de migracao K8s?"
**Deve**:
- Usar `dx__listInitiatives` para encontrar a iniciativa, depois `dx__getInitiativeDetails({ id })`
- Apresentar progresso, prazo, entidades aderentes
**Nao deve**:
- Inventar percentual de progresso se a tool nao retornar
**Fonte**: Exemplos de Perguntas #8

---

### HP-008: Engagement do time
**Input**: "Como esta o engagement do time no ultimo survey?"
**Deve**:
- Usar `dx__queryData({ sql })` para buscar dados de survey/engagement
- Sumarizar insights do survey com destaque para mudancas
**Nao deve**:
- Despejar todas as respostas do survey sem curadoria
**Fonte**: Exemplos de Perguntas #9

---

## Edge-Cases

### EC-001: Sigla DORA sem definicao
**Input**: "Como ta o LT do meu time?"
**Deve**: Responder o valor + explicar em 1 frase que LT = Lead Time for Changes (tempo do primeiro commit ate prod)
**Nao deve**: Omitir a explicacao quando o usuario usa sigla sem definir
**Fonte**: Regras de Execucao #4

---

### EC-002: Sigla DORA ja definida pelo usuario
**Input**: "Qual o tempo entre commit e prod, ou seja, lead time do meu time?"
**Deve**: Responder so o valor, sem repetir a definicao
**Nao deve**: Repetir o que o usuario ja explicou
**Fonte**: Regras de Execucao #4

---

### EC-003: Tool retorna 0 resultados
**Input**: "Qual o DORA do squad inexistente-abc?"
**Deve**: Dizer "sem dados para esse escopo" e oferecer reformular (listar times disponiveis)
**Nao deve**: Inventar metricas ou fabricar teoria sobre por que nao ha dados
**Fonte**: Regras de Execucao #2

---

### EC-004: Comparacao implicita
**Input**: "Qual a deploy frequency do meu time?"
**Deve**: Apresentar so o valor atual, sem comparar com trimestre anterior
**Nao deve**: Comparar implicitamente sem o usuario pedir
**Fonte**: Regras de Execucao #3

---

### EC-005: SQL escape hatch — schema desconhecido
**Input**: "Quero uma query custom de metricas no DX Data Cloud"
**Deve**: Primeiro listar tabelas via `information_schema` antes de montar a query real
**Nao deve**: Chutar nomes de tabelas/colunas e quebrar o fluxo com erro
**Fonte**: Conhecimento Embutido — SQL escape hatch

---

### EC-006: Confusao de escopo com observe
**Input**: "Como ta a saude do payments-api?"
**Deve**: Perguntar se o usuario quer saude de infra (logs, alertas — skill observe) ou metricas de engenharia (DORA, scorecard — esta skill)
**Nao deve**: Assumir que "saude" sempre significa metricas DORA
**Fonte**: Escopo — NAO cobre

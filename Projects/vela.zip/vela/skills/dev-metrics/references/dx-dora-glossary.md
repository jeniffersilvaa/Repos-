# Reference: DORA + DX Glossary

Glossario de siglas e metricas usadas pelo `dx` MCP. Carregue este ref quando o user citar uma sigla DORA/DX sem definir e voce precisar contexto pra responder.

## DORA (DevOps Research and Assessment)

4 metricas-chave do estado da entrega de software, definidas pela State of DevOps Report (Google Cloud / DORA):

- **DF (Deploy Frequency)** — quantas vezes o time faz deploy em prod. Elite: varias vezes por dia. High: 1x/semana-1x/dia. Medium: 1x/semana-1x/mes. Low: <1x/mes.
- **LT (Lead Time for Changes)** — tempo do primeiro commit ate prod. Elite: <1 dia. High: 1 dia-1 semana. Medium: 1 semana-1 mes. Low: >1 mes.
- **CFR (Change Failure Rate)** — % de deploys que causam incidente/rollback. Elite: 0-15%. High: 16-30%. Medium: 31-45%. Low: 46-60%.
- **MTTR (Mean Time To Recovery)** — tempo medio pra recuperar de incidente. Elite: <1 hora. High: <1 dia. Medium: 1 dia-1 semana. Low: >1 semana.

## DX-specific (getDX)

- **Time-to-merge** — tempo do PR open ate o merge. Proxy de eficiencia de review.
- **PR throughput** — # PRs merged por dev por semana.
- **Developer Survey** — pesquisa qualitativa periodica (engagement, satisfacao, friction points). Periodicidade trimestral na Stone.
- **Scorecard** — set de checks configurados pelo time (ex: "todos os repos tem CI?", "cobertura de tests >80%?", "secrets rotacionados nos ultimos 90 dias?").
- **Initiative** — agrupamento de scorecards/checks com objetivo definido e prazo (ex: "Migracao K8s 1.30 Q2/2026").
- **DX Tasks** — failing checks de scorecards que entidades precisam resolver. `dx__reviewTasks` resolve/dispensa essas tasks.
- **Entity** — qualquer coisa catalogada no DX: app, service, library, team, repo.

## Contexto Stone

- Plataforma DX usada: **getDX**
- Frequencia de survey de DevEx: trimestral
- Scorecards sao versionados; mudancas propagam pra todas entidades subordinadas
- DX Data Cloud (PostgreSQL) acessivel via `dx__queryData` pra queries que nao cabem nas tools de mais alto nivel

## Quando explicar a sigla pro user

- Se o user **menciona a sigla sem definir** (`"como ta o LT do meu time"`) -> responda o valor + 1 frase do que LT mede.
- Se o user **define ele mesmo** (`"qual o tempo entre commit e prod, ou seja, lead time"`) -> so responda o valor, sem repetir a definicao.
- Se o user **pede comparacao** (`"meu LT vs benchmark elite"`) -> use as faixas acima como referencia (elite/high/medium/low).

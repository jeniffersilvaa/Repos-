---
name: auditoria-siem
description: "Auditoria e SIEM na plataforma Karavela para devs usuarios. Use quando o usuario perguntar sobre auditoria de eventos das suas aplicacoes, como habilitar envio de logs ao SIEM via Helm chart, configurar o datastore `siem` no values.yaml, contexto SPI ou troubleshooting de logs nao chegando no SIEM."
---

# Skill: Auditoria e SIEM (para devs usuarios)

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.
-->

## Escopo

**Cobre**:
- Configuracao do datastore `siem` no values.yaml do chart Karavela (Telescope Logs)
- Habilitar envio de logs da aplicacao para o pipeline SIEM
- Contexto de negocio (`context: "spi"`) usado para roteamento
- Onde consultar logs SIEM no dia-a-dia (Datadog / Grafana — ver skill `observabilidade`)
- Auditoria implicita de operacoes do dev usuario (criar/editar/deletar aplicacao, secrets, IRSA — registrada pelo Lifecycle Audit Service da plataforma)

**NAO cobre**:
- Integracao Go interna do Lifecycle Audit Service / cliente SIEM (esses sao para devs de SERVICOS INTERNOS da plataforma, nao para devs usuarios — veja `karavela/docs/lifecycle_audity.md` e `karavela/docs/siem_integration.md` se voce e desenvolvedor da plataforma)
- Configuracao do Datadog ou Grafana (coberto pela skill `observabilidade`)
- Politicas de seguranca, Kyverno, KubeArmor (coberto pela skill `seguranca`)
- Gestao do Vault (coberto pela skill `secrets-vault`)

## Exemplos de Perguntas

- "Como habilito envio de logs da minha aplicacao para o SIEM?"
- "O que e o datastore `siem` no values.yaml?"
- "O que e o `context: spi`?"
- "Onde consulto os eventos de auditoria da minha aplicacao?"
- "Minha app habilitou SIEM mas os logs nao estao chegando — o que pode ser?"
- "Quais eventos da minha aplicacao sao auditados automaticamente pela plataforma?"

## Conhecimento Embutido

### O que o dev usuario precisa saber

Como dev usuario da plataforma, voce interage com auditoria e SIEM em dois pontos:

1. **Consultar logs e eventos** — via Datadog (canal padrao) ou Grafana Loki. Detalhes em `observabilidade`.
2. **Habilitar envio de logs ao pipeline SIEM** — via `values.yaml`, ativando o datastore `siem`. Util para apps que precisam de logs no SIEM corporativo (ex: PCI, SPI).

A auditoria de eventos do ciclo de vida da sua aplicacao (criacao, atualizacao, delecao, soft/hard delete, IRSA, Workload Identity, domain names) e registrada automaticamente pelo Lifecycle Audit Service da plataforma. Voce nao precisa fazer nada para que esses eventos sejam registrados — eles sao gerados pela Karavela-API a cada operacao.

**Tipos de recurso auditados**: `application`, `project`, `vault-path`, `vault-secret`, `ecr`, `irsa`, `workload-identity`, `domain-name` e `resource` (recursos Crossplane gerenciados pela plataforma). **Tipos de evento**: `create`, `update`, `delete`, `soft-delete`, `hard-delete`, `undelete`.

**Consulta de eventos** via `GET /lifecycle-audit` com filtros: `order_id`, `run_id`, `resource_id`, `resource_name`, `resource_type`, `requester_email`, `event_name`, `initial_date`/`final_date` (YYYY-MM-DD), `page` (default 1) e `size` (default 50, max 1000).

**Limitacoes conhecidas** (importante ao investigar lacunas na trilha de auditoria):
- Em rotas de recursos Crossplane (`POST /resources/{id}/soft-delete` e `/hard-delete`), o envelope `lifecycle_audit` e **opcional** — quando omitido pelo chamador, nenhum evento e registrado. Espere lacunas ate que todos os workflows propaguem os identificadores.
- A rota legada `DELETE /resources/{id}` executa o hard delete mas **nao registra evento de auditoria** (nao tem body para carregar o envelope). Para trilha de auditoria, use `POST /resources/{id}/hard-delete`.
- Nao existe rota de undelete para recursos Crossplane; o soft delete e apenas escrituracao no banco, revertido via `PATCH /resources/{id}/lifecycle` de volta para `active`, sem evento proprio.

### Habilitar SIEM no chart (Telescope Logs)

A plataforma suporta envio de logs ao pipeline SIEM via Helm chart, sem alteracao de codigo. O roteamento e feito pelo Telescope Logs, que encaminha os logs para o bucket S3 correspondente ao contexto de negocio.

O datastore `siem` esta disponivel em tres pontos do `values.yaml`:

```yaml
# 1. Via coleta stdout (Datadog agent) — padrao recomendado
datadog:
  logs:
    datastores:
      siem:
        enabled: true
        context: "spi"

# 2. Via OTLP (descontinuado — prefira opentelemetry abaixo)
datadog:
  otlp:
    logs:
      datastores:
        siem:
          enabled: true
          context: "spi"

# 3. Via OpenTelemetry
telemetry:
  instrumentation:
    opentelemetry:
      logs:
        datastores:
          siem:
            enabled: true
            context: "spi"
```

| Campo | Tipo | Default | Descricao |
|-------|------|---------|-----------|
| `siem.enabled` | `bool` | `false` | Habilita o envio de logs ao pipeline SIEM |
| `siem.context` | `string` | `"spi"` | Contexto de negocio (determina o bucket S3 de destino) |

O `context` segmenta os logs por dominio de negocio. Atualmente apenas `"spi"` (Sistema de Pagamentos Instantaneos) esta disponivel.

> **IMPORTANTE**: Em clusters legados, e necessario adicionar manualmente a annotation `telemetry.karavela.stone.tech/siem.logs.context: "spi"` no Pod.

Disponivel em todos os tipos de chart: API (v1.36.0+), Worker (v1.28.0+), CronJob (v1.21.0+), Job (v1.22.0+), StatefulSet (v1.11.0+).

**Fonte**: `platform-k8s-charts/platform-k8s-api-chart/values.yaml`, `platform-k8s-charts/.docs/CHANGELOG.api.md` (v1.36.0) (complemento — nao em docs/)

### Onde consultar logs e eventos

- **Logs da aplicacao**: Datadog e Grafana Loki (ver skill `observabilidade`).
- **Eventos de auditoria do ciclo de vida** (criacao/delecao/etc. da app): registrados pela Karavela-API e disponiveis via API `GET /lifecycle-audit?...` ou via Portal Karavela na aba de auditoria da aplicacao.
- **Logs SIEM** (depois de habilitado o datastore): consultados pelo time de Seguranca corporativo da Stone via portal SIEM proprio. Devs usuarios geralmente nao acessam o SIEM corporativo direto.

### Troubleshooting Comum

- **Logs nao chegam no SIEM**: confira se a versao do chart e suportada (API >= 1.36.0, Worker >= 1.28.0, etc.) e se voce esta no datastore correto (`datadog.logs.datastores.siem` ou `telemetry.instrumentation.opentelemetry.logs.datastores.siem`). Em clusters legados, adicione a annotation no Pod.
- **Contexto invalido**: hoje so `"spi"` e suportado. Outros contextos serao adicionados conforme demanda.

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever; producao exige dupla confirmacao. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer

- **Editar `chart/values-*.yaml`** — habilitar `datadog.logs.datastores.siem.enabled: true` + `siem.context: "spi"` para roteamento de logs ao SIEM via Telescope
- **Abrir PR draft**
- **NAO** edita codigo Go interno da plataforma — isso e responsabilidade do time de plataforma

### Triggers proativos

- "Habilitar SIEM logs SPI" → propor patch no values com `datastores.siem.enabled: true`
- "Como auditar operacoes da minha app" → orientar Portal/Lifecycle Audit API (read-only para dev)
- "Por que a trilha de auditoria tem lacunas para recursos Crossplane" → explicar envelope `lifecycle_audit` opcional nessas rotas e rota legada `DELETE /resources/{id}` sem evento; sugerir `POST /resources/{id}/hard-delete`

### Acoes destrutivas

- N/A — auditoria e append-only e os eventos sao gerados automaticamente.

## Instrucoes MCP

Quando o usuario precisar de informacoes detalhadas alem do conhecimento embutido, busque PRIMEIRO em `stone-payments/karavela` (`docs/`); outros repositorios apenas como complemento.

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/karavela` | `docs/lifecycle_audity.md` | Tipos de eventos auditados (create/update/delete/soft-delete/hard-delete/undelete/list) e recursos cobertos (application, project, vault-path, vault-secret, ecr, irsa, workload-identity, domain-name). FONTE PRIMARIA |
| `stone-payments/karavela` | `docs/siem_integration.md` | Visao geral da integracao SIEM. ATENCAO: doc voltado para devs de servicos INTERNOS da plataforma — devs usuarios so habilitam o datastore via values.yaml |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/funcionalidades/observability.md` | Como consultar logs / eventos / metricas no dia-a-dia |
| `stone-payments/platform-k8s-charts` | `platform-k8s-api-chart/values.yaml` (e demais charts) | Schema completo do datastore `siem` no values.yaml (complemento — nao em docs/) |

## Formato de Resposta

Ao responder perguntas deste dominio, siga este formato:

1. **Explicacao** (2-3 frases objetivas em PT-BR)
2. **Exemplo pratico** (YAML ou consulta copiavel)
3. **Fonte** (referencia ao arquivo/secao da documentacao)
4. **Avisos** (se aplicavel: chart version minima, contexto suportado, cluster legado)

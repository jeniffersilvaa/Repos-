---
name: report-releases-calendar
description: "Gera e publica o Calendario de Releases (Stone + Ton) como pagina HTML estatica hospedada em static app — le planilha Google Sheets via WebFetch e publica cards NOW/NEXT/LATER com progress bars e tabelas mensais. Use quando o usuario pedir para atualizar, regenerar ou corrigir o calendario de releases, a pagina de releases Stone/Ton, ou alterar layout, cores ou status do calendario."
---

# Skill: Calendário de Releases

Gera e publica o Calendário de Releases (Stone + Ton) como página HTML estática, lendo dados de uma planilha Google Sheets via WebFetch e publicando na static app `report-releases-calendar`. Reproduz exatamente o layout existente: cards NOW/NEXT/LATER com progress bars por plataforma, tabelas mensais com 8 colunas e pill separadores de mês.

## Conceitos

- Fonte de dados: Google Sheets aba Releases via `WebFetch` (export CSV `https://docs.google.com/spreadsheets/d/1bQLPJsOZQt12onTOylbL87fHQq4ZpC1toovfi-wtSF4/export?format=csv&gid=1558887856`). Campos: `semana, release, segmento, versao, corte, lancamento, rollout, status`.
- Status: Concluído (verde), Em Rollout (azul), Próximo Corte (laranja), Próximas Releases (cinza), Cancelado (vermelho). NOW = Em Rollout com progress bars por plataforma; NEXT = menor data Próximo Corte; LATER = Próximas Releases.
- Layout centrado (`max-width: 1100px`) com header escuro + breadcrumb "Vela › Central de Releases › Calendário de Releases", grid 8 colunas, Stone rows `#2D6A4F` / Ton rows `#1D4E89`.

## Modo Ações

Leitura livre (`WebFetch`); escrita com confirmação explícita (`prepare_static_app_draft`, `publish_static_app_draft`, `create_static_app`). Preview local obrigatório antes do deploy.

---
name: fix-vulnerabilities
description: "Corrigir vulnerabilidades de um artefato (app/package/source) do Dependency Explorer delegando à armada (Vela Code): seleção de componentes/CVEs no portal → análise → resolução do repo-fonte (com confirmação + consentimento de refactor) → armada__kick_off. Use quando o usuário quer corrigir/bumpar dependências vulneráveis ou CVEs de um artefato. A armada corrige na raiz (bump da dep direta, monorepo-aware), decide o que é corrigível-por-bump, abre o próprio PR e reporta o resto."
---

# Skill: Corrigir Vulnerabilidades com a Vela

> **Invocação: quase sempre um botão.** Na prática esta skill não é acionada por prosa livre — ela chega do botão **"Corrigir vulnerabilidades com a Vela"**, no detalhe de um artefato do Dependency Explorer, que **semeia a mensagem** com a identidade do artefato e os itens marcados. Duas consequências que valem para tudo abaixo:
>
> 1. **A entrada é estruturada, não conversacional.** A seed tem **formato fixo, montado pelo frontend** (etapa 1) — os campos vêm da seleção do usuário no portal, não do que ele digitou. **Parseie**; não infira, não adivinhe o que ele "quis dizer".
> 2. **Invocação livre é a exceção** ("corrige os CVEs do meu pacote"). Sem seed não há identidade nem itens — então **peça o artefato/repo e os itens** antes de seguir, em vez de tentar derivá-los da frase.
>
> O que **é** conversacional, e por isso exige cuidado: a **confirmação do repo** e o **consentimento de refactor** (etapa 3). É ali que a interpretação em linguagem natural entra no fluxo — e é ali que mora o default seguro e o eco.

A partir do detalhe de um artefato no Dependency Explorer (app, package ou source), o usuário seleciona componentes vulneráveis e/ou CVEs e pede para "corrigir com a Vela". Esta skill conduz o fluxo **híbrido**: a Vela **não escreve o fix** e **não decide o que é corrigível** — ela parseia a seleção semeada pelo portal, **resolve o repo-fonte do artefato, pede confirmação ao usuário (incl. consentimento de refactor)** e delega tudo à **armada (Vela Code)** via `armada__kick_off`. A Vela **não pré-cria PR** — a armada abre o dela. A armada (um Claude Code com tooling de ecossistema) resolve as versões seguras no job, **corrige na raiz** (bump da dep direta, monorepo-aware), corrige o que for corrigível-por-bump e reporta o resto.

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.
-->

> **Fonte única de verdade — é este arquivo.** O playbook do portal-chat
> (`karavela-core/plugins/mcp-backend/prompts/playbooks/vela/fix-vulnerabilities.md`)
> é **gerado** a partir deste `SKILL.md` + do `playbook.yaml` ao lado, por
> `vela/scripts/sync-portal.ts`. **Não edite o playbook à mão** — edite aqui e
> regenere. O sync sobrescreve o playbook por inteiro, então edição manual lá é
> perda garantida.
>
> O gerador **remove** três seções ao montar o playbook: `## Human Input` (esta),
> `## Escopo` e `## Exemplos de Perguntas`. É por isso que esta nota mora aqui —
> instrução de mantenedor não deve chegar ao portal. **Todo o resto do arquivo
> vira o corpo do playbook**, então escreva pensando nas duas superfícies:
> portal-chat (onde a seed chega do botão do Explorer) e Claude Code/Copilot/KLI.

## Quando Usar Esta Skill (vs. `migrate-to-karavela-packages` / `repo-coding` / `karavela-packages`)

Use **esta skill** quando:

- O usuário chega do botão **"Corrigir vulnerabilidades com a Vela"** no detalhe de um artefato do Dependency Explorer (seed semeada começa com `Corrigir vulnerabilidades no artefato ...`).
- O usuário quer **bumpar dependências vulneráveis** ou **corrigir CVEs** de um app/package/source e abrir PR no repo-fonte.

Não confundir com:

| Pergunta do usuário                                                              | Skill correta                  |
| ------------------------------------------------------------------------------- | ------------------------------ |
| "corrigir vulnerabilidades / CVEs de um artefato" / botão do Explorer           | `fix-vulnerabilities`          |
| "migrar repo para publicar em Karavela Packages"                                | `migrate-to-karavela-packages` |
| "conceitos / consumo / onboarding de Karavela Packages" / `USE_KARAVELA_PACKAGES` | `karavela-packages`            |
| "bug fix pontual / patch / config num repo" (sem ser vuln/CVE)                  | `repo-coding`                  |
| "feature nova / novo endpoint / PRD + specs"                                    | `sdd`                          |

A correção de código é sempre delegada à armada — esta skill é um **playbook de handoff**, não um agente que coda. Se o usuário quer um fix pontual que **não** é vulnerabilidade/CVE, mande para `repo-coding`/`sdd`.

## Escopo

**Cobre:**

- **Parse da seed** semeada pelo portal: identidade do artefato (`name`, `kind`, `uuid`, e quando houver `packageEcosystem`/`packageIdentity`/`catalogEntityRef`) + itens selecionados (componentes e CVEs, dois eixos misturáveis no mesmo batch).
- **Resolução do repo-fonte por `kind`** (com confirmação obrigatória + consentimento de refactor antes do handoff).
- **Handoff para a armada** via `armada__kick_off` com **todos** os itens selecionados, a estratégia de **correção-na-raiz** e os **3 reviewers obrigatórios**. A Vela **não** abre PR — a armada abre o dela.
- **Resposta com `tracking_id`** — a prova de que a armada foi acionada (a URL do PR aparece quando a armada o abre).

**Não cobre** (delegar ou recusar):

- **Escrever o código do fix** — é a armada que bumpa versões, roda o package manager e resolve a versão segura. A Vela **nunca** edita o manifesto/lockfile direto.
- **Triar corrigibilidade (✅/⚠️) na conversa** — a Vela **não** classifica o que tem fix. Não há tool de advisory no MCP Hub e `ProjectVulnerabilityItem` não carrega "fixed-in version"; qualquer triagem na conversa seria frágil. **Todos** os itens vão para a armada, que decide e reporta.
- **Criar/editar nada no DependencyTrack** nem alterar os tipos das listagens do Explorer.

## Exemplos de Perguntas

- *"Corrigir vulnerabilidades no artefato payment-api (kind: app, uuid: ...)"* (seed do portal)
- *"Quero bumpar essas dependências vulneráveis e abrir um PR"*
- *"Corrige esses CVEs no meu pacote"*
- *"Selecionei uns componentes no Explorer, manda a Vela corrigir"*

## Fluxo Canônico

A seed string chega do botão do portal e **começa** com a trigger `Corrigir vulnerabilidades no artefato ...` (esse é o contrato que roteia para este playbook). Conduza **6 passos**, nesta ordem:

### 1. Parsear a seed

A seed do botão tem o formato:

```text
Corrigir vulnerabilidades no artefato {name} (kind: {kind}, uuid: {uuid}).
{linha de identidade por kind}

Componentes selecionados:
- {eco} {name}@{version}
- ...

CVEs selecionados:
- {cveId} (via {eco} {name}@{version})
- ...
```

Extraia:

| Campo                  | De onde                                                                  |
| ---------------------- | ------------------------------------------------------------------------ |
| `name`, `kind`, `uuid` | Primeira linha (`kind` ∈ `app` / `package` / `source`)                    |
| Identidade             | Linha condicional: `Pacote:` / `Catálogo:` / `Repositório:`               |
| Componentes            | Bloco `Componentes selecionados:` (cada linha = `{eco} {name}@{version}`) |
| CVEs                   | Bloco `CVEs selecionados:` (cada linha = `{cveId} (via {eco} ...)`)       |

São **dois eixos misturáveis no mesmo batch**: **componentes** (`{ ecosystem, name, version }`) e **CVEs** (`{ cveId, viaComponent: { ecosystem, name, version } }`). A linha de identidade traz, quando houver, `packageEcosystem`/`packageIdentity` (kind `package`) ou `catalogEntityRef` (kind `app`).

> Seções vazias são omitidas pelo builder (a seed pode ter só CVEs, ou só componentes). Se a seed terminar em `(+N itens — refine a seleção)`, a seleção excedeu o limite brando — avise o usuário que só os primeiros itens vieram e que ele pode refinar a seleção e reenviar para cobrir o restante.

### 2. Resolver o repo-fonte por `kind`

Derive o repositório **fonte** do artefato a partir do `kind`:

| `kind`    | Como derivar o repo-fonte                                                                                                                                                                                                                                                                                                                                     |
| --------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `source`  | É o próprio repo, mas o `name` **não é um `owner/repo` garantido por contrato**. Valide **antes de confirmar**: (a) o `name` contém `/` (parece `owner/repo`); (b) o repo existe e está na org `stone-payments` via `github__search_repositories`. Se o `name` não tiver `/` ou a busca não retornar o repo, **a derivação falhou** — peça o `owner/repo` ao usuário. Nunca use o `name` direto sem validar. |
| `package` | Tente o **catalog do Backstage primeiro** (entidade do pacote → `backstage.io/source-location`); só então `github__search_repositories` pelo `packageIdentity`.                                                                                                                                                                                                 |
| `app`     | Repo-fonte via `catalogEntityRef` → `catalog-info.yaml` (anotação `backstage.io/source-location`).                                                                                                                                                                                                                                                             |

Ferramentas: use o **GitHub MCP** (`github__search_repositories` para o `default_branch`, `github__get_file_contents` para `catalog-info.yaml`) e o **MCP de catalog do Backstage** — server `backstage-catalog` (tools `backstage-catalog__*`), **não** o `backstage-scaffolder` — quando precisar resolver o `catalogEntityRef` de um app ou a entidade de um pacote.

> **`kind: package` — cuidado com a busca por nome.** O `packageIdentity` é o nome no registro (ex.: `@stone-payments/payment-api`), **não** necessariamente o `owner/repo`. `github__search_repositories` por esse nome pode retornar **zero** (pacote interno sem repo de mesmo nome) ou **múltiplos** candidatos. Por isso o catalog vem primeiro: a anotação `backstage.io/source-location` da entidade do pacote aponta o repo-fonte sem ambiguidade. Se cair na busca GitHub e houver mais de um candidato, **não escolha sozinho** — liste os candidatos (`owner/repo` + descrição/última atualização) e peça ao usuário que aponte o correto.

**Capture também o `default_branch`** do repo resolvido (`github__search_repositories` → campo `default_branch`; **não assuma `main`**). Ele é obrigatório no hand-off: vira o `target_branch` do `armada__kick_off` — a base de onde a armada ramifica (ver etapa 5).

**Quando a derivação falhar** (package sem entidade no catalog nem repo de mesmo nome, app sem `catalogEntityRef`, `name` que não é `owner/repo`): **não improvise** — **peça ao usuário** o `owner/repo` ou a URL de um PR existente, e siga a conversa com esse input manual (não aborte).

### 3. Mostrar o repo, PEDIR CONFIRMAÇÃO e capturar consentimento de refactor

Apresente o repo resolvido (ou o informado pelo usuário) e **peça confirmação explícita antes de acionar a armada**. Esta confirmação é a **salvaguarda mínima** — o fluxo não tem gate de permissão, então acionar no repo errado é um risco real. Além do repo, **capture o consentimento de refactor** com uma pergunta condicional: _"Se a correção na raiz exigir um major bump com quebra de interface de uma dependência direta, você autoriza a armada a refatorar o código da aplicação (mantendo os testes)?"_ Só prossiga após o "ok". **Default seguro:** sem resposta clara sobre o refactor → trate como **não autorizado**.

**Ecoe a interpretação antes de acionar.** O consentimento é capturado em linguagem natural e depois re-narrado como texto livre dentro da `task` — duas camadas de interpretação antes de autorizar refactor de código de aplicação. Para o usuário poder corrigir você, **declare de volta, explicitamente, o que entendeu** ("refactor: **autorizado**" / "refactor: **não autorizado**") junto com o repo, na mesma mensagem de confirmação. Resposta ambígua ("só se for simples", "acho que sim") **não** é autorização: ecoe como **não autorizado** e deixe o usuário corrigir, em vez de otimizar pela intenção provável.

### 4. Estratégia de correção-na-raiz (o que vai na `task`)

A Vela **não abre PR** — a armada abre o próprio (branch `vela-agent/…`). A Vela só descreve, na `task`, a **ordem de estratégia** que a armada deve seguir:

1. **Raiz (preferencial)** — bumpar a **dependência direta** cujo fecho transitivo traz a CVE, para uma versão sem a vulnerabilidade. Evitar resolutions/overrides/pins transitivos.
2. **Monorepo** — múltiplos manifestos (workspaces/go modules/submódulos) → atuar no(s) **workspace(s)** que declara(m) a dep direta, **não** na raiz, e em **todos** eles.
3. **Pacote interno / cascade** — se a dep direta for **interna** e **sem versão publicada com o fix**, o root está no repo-fonte do pacote, normalmente **outro repo/monorepo não referenciado na seed**; a armada descobre por **busca de código** (`github__search_code` pelo nome/identificador na org). ⚠️ **O cascade REPORTA, não commita.** A confirmação da etapa 3 cobre **só** o repo resolvido pelo `kind` — a armada **não tem autorização** para commitar no repo-fonte descoberto. Ela deve **reportar, no PR do consumidor**, qual é o repo-fonte, qual o fix necessário lá e que ele precisa de um acionamento próprio (confirmado pelo usuário); e, se a busca retornar **mais de um candidato plausível** (forks, repos deprecated, nomes parecidos), **listar os candidatos em vez de escolher sozinha**. Só o que der para corrigir **dentro do repo confirmado** entra no PR. **Interno se determina por REGISTRO/PROPRIEDADE, não pelo nome:** resolve do registro privado da org (Nexus/Karavela Packages) ou tem repo-fonte na org. O **nome não é sinal confiável** — PyPI não tem namespace, o prefixo NuGet (`StoneCo.*`) é convenção **relaxada** (NuGet não impõe namespacing), e scope npm (`@stone-payments/…` e outros) / groupId Maven (`co.stone…`) são só **pistas**. Vale para qualquer ecossistema, com ou sem `@namespace` — não gate pela notação.
4. **Convenções do repo** — respeitar `AGENTS.md`/`CONTRIBUTING.md`/`.github/copilot-instructions.md` e a ferramenta de deps (ex.: Renovate); não introduzir mecanismo inédito (ex.: `resolutions`) sem sinalizar.
5. **Major bump/breaking** → aplicar o consentimento da etapa 3 (autorizado → refatora; não autorizado → reporta o que quebra e para).
6. **Paliativo (último recurso)** — override/resolutions/pin só sem caminho na raiz, **sinalizado no PR como paliativo que precisa de aprovação humana**.

> **Por que essa ordem existe.** No primeiro uso real (`billing-transactions-engine#121`) a armada resolveu CVEs transitivas com um `resolutions` na **raiz de um monorepo** — e o dono rejeitou ("não fazemos isso, deve ser corrigido na raiz"). A CVE entrava por `@stone-payments/ts-http` (pacote interno, publicado de **outro** monorepo, `ts-shared`, não referenciado na seed), declarado em 4 workspaces. A correção-na-raiz era bumpar essa dep direta nesses workspaces e, se preciso, cascatear no `ts-shared` (descoberto por busca de código), possivelmente com refactor. Esta ordem existe para não repetir o atalho.
>
> **E por que o cascade só reporta.** O mesmo caso mostra o risco espelhado: o repo-fonte do pacote interno é descoberto por busca, não confirmado pelo usuário. Deixar a armada commitar lá reintroduziria a classe de risco do #121 — mexer onde ninguém autorizou — só que num repo que o usuário nem viu. O `ts-shared` daquele caso vira um **acionamento próprio**, com a mesma confirmação da etapa 3.

**Alvo do hand-off — exatamente um.** O `armada__kick_off` exige **um** entre `target_branch` e `target_pr` — nunca os dois, nunca nenhum:

- **Caso normal (a armada abre um PR novo):** `target_branch` = o **`default_branch`** capturado na etapa 2 (é a **base de onde ramificar**, não uma branch de trabalho), mais `repo_owner`/`repo_name` do repo confirmado.
- **Usuário apontou um PR já aberto:** `target_pr` = a **URL completa**. Aí `repo_owner`/`repo_name` são derivados da URL e podem ser omitidos, e a armada empurra commits nesse PR em vez de abrir um novo.

### 5. `armada__kick_off` com todos os itens + estratégia-na-raiz + 3 reviewers obrigatórios

Chame `armada__kick_off` com **todos** os itens selecionados e a **ordem de estratégia** (etapa 4) na `task`:

```json
{
  "task": "Corrigir as vulnerabilidades selecionadas em <repo>: <eco> <name>@<ver> e demais itens (CVEs <id…>). Você está autorizado a commitar APENAS em <repo> — o usuário confirmou este repo e nenhum outro. Ordem de estratégia: (1) RAIZ — bumpe a dep DIRETA cujo closure traz a CVE para uma versão sem a vulnerabilidade; evite override de versão transitiva (npm resolutions/overrides ou o equivalente do ecossistema). (2) MONOREPO — se houver múltiplos manifestos, atue no(s) MÓDULO(S) que declara(m) a dep direta, não na raiz, e em TODOS eles. (3) PACOTE INTERNO/CASCADE — se a dep for INTERNA (determine por REGISTRO/PROPRIEDADE, não pelo nome: resolve do registro privado da org/Nexus ou tem repo na org — QUALQUER ecossistema; o nome não é sinal confiável: PyPI sem namespace, prefixo NuGet StoneCo.* é convenção relaxada, scope npm/groupId Maven são só pistas) e sem versão publicada com o fix, o root está em OUTRO repo/monorepo não referenciado aqui; descubra-o por BUSCA DE CÓDIGO (pelo nome/identificador do pacote na org) e REPORTE no PR de <repo>: qual o repo-fonte, qual o fix necessário lá e que ele precisa de acionamento próprio confirmado pelo usuário. NÃO commite, NÃO abra PR e NÃO faça push nesse segundo repo — a autorização não o cobre. Se a busca retornar mais de um candidato plausível (forks, deprecated, nomes parecidos), liste os candidatos no PR em vez de escolher um. (4) CONVENÇÕES — respeite AGENTS.md/CONTRIBUTING.md e a ferramenta de deps do repo (ex.: Renovate); não introduza mecanismo inédito sem sinalizar. (5) MAJOR BUMP/BREAKING — <CONSENTIMENTO DE REFACTOR>. (6) PALIATIVO (último recurso) — override transitivo só sem caminho na raiz, sinalizado como paliativo p/ aprovação humana. Rode o package manager e mantenha testes/coverage passando. Reporte no PR o que corrigiu, a estratégia (raiz/cascade/paliativo) e o que NÃO tem fix (e por quê).",
  "repo_owner": "<owner do repo confirmado>",
  "repo_name": "<name do repo confirmado>",
  "target_branch": "<default_branch capturado na etapa 2 — a base de onde ramificar; NÃO assuma main>",
  "requester_email": "<do contexto da sessão>",
  "max_review_rounds": 1,
  "reviewers": ["business-review", "security-review", "pre-mortem-review"]
}
```

Esse é o **caso normal** (armada abre um PR novo). Se o usuário apontou um **PR já aberto**, troque `target_branch` por `target_pr` (URL completa) e **omita** `repo_owner`/`repo_name` — a armada os deriva da URL:

```json
{
  "task": "<mesma task>",
  "target_pr": "https://github.com/<owner>/<repo>/pull/<n>",
  "requester_email": "<do contexto da sessão>",
  "max_review_rounds": 1,
  "reviewers": ["business-review", "security-review", "pre-mortem-review"]
}
```

Preencha `<CONSENTIMENTO DE REFACTOR>` conforme a etapa 3: **autorizado** → "faça o major bump e refatore o app mantendo os testes"; **não autorizado** → "não force o major bump com breaking; reporte o que quebra e pare nesse item, sem cair para override".

Regras dos campos — abaixo só o que este fluxo estreita ou inverte. Se o user pedir restrição junto do fix (sem PR, escopo de arquivos), os campos que a atendem estão na ref [armada-restricoes-do-user](references/armada-restricoes-do-user.md), e **nenhum deles se nega ao user**:

- `task` (**obrigatório**) — descreva **todos** os itens + a ordem de estratégia (raiz → monorepo → pacote-interno/cascade → convenções → consentimento → paliativo). Não triague corrigibilidade; a determinação é da armada. Reserve o round de review para achados **bloqueantes** — não gaste em documentar achado non-blocking.
- `repo_owner` / `repo_name` (**obrigatórios no caso normal**) — o repo **confirmado na etapa 3**. São o **escopo do job**: o pipeline faz checkout desse repo, então é o que amarra a armada ao alvo — não só a frase da `task`. Só podem ser omitidos quando `target_pr` está setado (a armada os deriva da URL).
- `target_branch` / `target_pr` (**exatamente um dos dois — nunca ambos, nunca nenhum**) — `target_branch` é a **base de onde ramificar** (o `default_branch` da etapa 2), e faz a armada abrir um **PR novo**; `target_pr` é a **URL completa** de um PR **já aberto**, e faz a armada empurrar commits nele em vez de abrir outro. ⚠️ `target_branch` **não** é "uma branch de trabalho existente" — é a base. E **não** omita os dois: o tool exige um deles, então omitir ambos faz o `kick_off` falhar.
- `requester_email` (**obrigatório**) — vem do contexto da sessão (no portal-chat, da seção `## Contexto do usuário` do system prompt). Com o contexto presente, use-o direto — **não pergunte ao user**. Se o email não puder ser derivado **com certeza**, **NÃO** improvise com `whoami` ou equivalente: a armada usa este campo para notificação e auditoria, e um email errado/inválido falharia em silêncio (o `kick_off` aceita qualquer string e ainda retorna `tracking_id`). Nesse caso, **aborte e peça ao user que confirme o email**.

  > **Divergência deliberada do `sdd`.** O contrato geral (ref [armada-kickoff-schema](references/armada-kickoff-schema.md)) manda o oposto: "se faltar, chame `whoami`; **NUNCA** pergunte ao user". Aqui vale o que está acima. A diferença é o **custo do erro**, não capricho: no `sdd` o hand-off aponta para um draft PR que o próprio autor abriu e está olhando, então um email errado é ruído recuperável. Aqui a Vela **não pré-cria PR** — o `tracking_id` é o único fio, e o email é o canal de notificação/auditoria. Um `whoami` que resolva para a identidade errada (bot, service account, sessão delegada) produz um job que ninguém é notificado sobre e que audita a pessoa errada, **retornando `tracking_id` normalmente**. Falha silenciosa que só aparece quando o PR não chega. Perguntar custa uma pergunta; adivinhar custa um job órfão.
- `max_review_rounds` (**obrigatório**) — **sempre `1`**, salvo instrução explícita do user.
- `reviewers` (**obrigatório, sem exceção**) — **sempre os 3** (`business-review`, `security-review`, `pre-mortem-review`). Não há opt-out.
- `files_to_read` — **omitido de propósito**. Esta feature não tem spec em `.vela-specs` para referenciar, e a `task` já carrega a descrição completa dos itens selecionados. Não é um esquecimento: não inclua o campo.

A `task` **enumera os itens** e instrui a armada a **corrigir na raiz e reportar o que não tiver fix (e por quê)** — a determinação de corrigibilidade e estratégia é da armada, não da Vela.

### 6. Responder com `tracking_id`

Responda com o **`tracking_id`** retornado pelo `armada__kick_off`. **Sem `tracking_id`, nada foi acionado** — afirme isso explicitamente em vez de dar um falso "correção iniciada". A **URL do PR** aparece quando a armada o abre (acompanhável via `armada__check_status`); não prometa uma URL de PR pré-criado.

## Anti-padrões — NUNCA faça

- **NUNCA escreva o código do fix você mesmo.** Não edite manifesto, lockfile ou qualquer fonte. Quem bumpa e resolve a versão segura é a armada.
- **NUNCA triague corrigibilidade na conversa.** Não classifique ✅/⚠️ nem invente "fixed-in version" — não há tool de advisory no MCP Hub. Todos os itens selecionados vão para a `task` da armada.
- **NUNCA instrua a armada a override de versão transitiva (resolutions/overrides/pin, ou o equivalente do ecossistema) como primeira opção.** A estratégia default é **corrigir na raiz** (bump da dep direta, no workspace certo em monorepos, cascateando no repo-fonte de pacotes internos quando preciso). Paliativo é último recurso, sinalizado no PR. A Vela só **carrega a ordem de preferência** na `task`; a decisão por item é da armada.
- **NUNCA chame `armada__kick_off` sem confirmar o repo-alvo (e o consentimento de refactor) com o usuário.** A Vela não pré-cria PR (a armada abre o dela), então a confirmação é a única salvaguarda contra acionar no repo errado.
- **NUNCA chame `armada__kick_off` sem o param `reviewers`.** O valor é **sempre** `["business-review", "security-review", "pre-mortem-review"]` — sem exceção, sem opt-out, mesmo que o usuário peça para pular.
- **NUNCA substitua `armada__kick_off` por outro mecanismo** (Copilot, reviewers do GitHub, commit direto, `karavela-source-code-api`/Temporal chamados na conversa). A armada é o único executor.
- **NUNCA afirme que "a correção foi iniciada" sem ter recebido um `tracking_id`** do `armada__kick_off`.

## Sinais para abortar / puxar humano

Pare e sinalize (não improvise) se: o repo estiver fora da org `stone-payments`, a derivação do repo for ambígua (mais de um candidato), o usuário não confirmar o alvo, o `requester_email` não puder ser derivado com certeza do contexto da sessão (peça ao user que confirme — não use `whoami`), ou `armada__kick_off` falhar (reporte o erro e ofereça acionar manualmente). Derivação que simplesmente **falha** vira pedido de repo/PR ao usuário (etapa 2) — não aborta.

## Formato de Resposta Esperado

Ao conduzir o fluxo:

1. **Parseie a seed** e resuma ao usuário o artefato + os itens entendidos (componentes e CVEs).
2. **Mostre o repo resolvido** (ou peça o repo se a derivação falhar), **capture o consentimento de refactor** e **espere a confirmação**.
3. Após o "ok", **chame `armada__kick_off`** com todos os itens + a estratégia-na-raiz + os 3 reviewers. A Vela **não abre PR** — a armada abre o dela.
4. **Termine sempre com o `tracking_id`** (a URL do PR vem depois, quando a armada o abre).

**Avisos obrigatórios na saída:**

- A determinação do que é corrigível-por-bump — e da estratégia (raiz/cascade/paliativo) — é da **armada**, não da Vela; comunique que itens sem fix (e a estratégia usada) serão reportados no PR.
- **Sem `tracking_id`, nada foi acionado** — nunca prometa correção sem ele.
- A confirmação do repo + consentimento de refactor é obrigatória antes do acionamento — não pule por pressa do usuário.

Nunca exponha secrets/tokens — o fluxo usa OIDC.

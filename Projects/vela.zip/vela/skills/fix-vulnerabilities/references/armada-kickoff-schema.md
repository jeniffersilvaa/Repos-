---
name: armada-kickoff-schema
send-to-portal: true
---

# Reference: Armada (Coder agent) tool schemas

Schema completo de `armada__kick_off`, `armada__analyze`, `armada__check_status`, `armada__get_report`, `armada__cancel`, `armada__review_pr`. Carregue quando estiver no hand-off final do fluxo SDD ou monitorando o agente.

Os campos abaixo sao os que as tools **de fato** aceitam e devolvem. Nao invente campo: se voce ler um valor que nao esta listado aqui, confira o schema da tool antes de usar — campo inexistente chega como `undefined` e vira resumo errado pro user (foi a causa do VELA-93).

## `armada__kick_off` — disparar implementacao

```json
{
  "task": "<resumo curto de 1-3 linhas do que precisa ser implementado>",
  "target_pr": "<URL completa do PR draft que voce abriu>",
  "requester_email": "<email do user, do contexto>",
  "max_review_rounds": 1,
  "reviewers": ["business-review", "security-review", "pre-mortem-review"],
  "files_to_read": [
    "docs/vela-prds/{NNN}-{slug}.md",
    "docs/vela-specs/{NNN}-{slug}/spec.md",
    "docs/vela-specs/{NNN}-{slug}/plan.md",
    "docs/vela-specs/{NNN}-{slug}/tasks.md"
  ]
}
```

### Detalhamento dos campos

- `task` (**obrigatorio**) — descricao livre. Armada le os arquivos em `files_to_read` pra contexto detalhado, entao mantenha curto (1-3 linhas).
- `target_pr` (**obrigatorio se nao passar `target_branch`**) — URL completa do PR draft que voce abriu via `github__create_pull_request`, ou shorthand `owner/repo#123`. Armada extrai owner/repo/numero e entra em **modo continuacao**: faz checkout do head do PR e empurra commits nele, em vez de abrir PR novo.
- `target_branch` (**obrigatorio se nao passar `target_pr`**) — branch base de onde o agente parte (ex.: `develop`). Quando `target_pr` esta setado e voce passar os dois, o pipeline valida um contra o outro.
- `repo_owner` / `repo_name` — com `target_pr` setado, sao derivados da URL do PR (e se voce passar os dois, tem que bater). No modo `target_branch` sao o unico jeito de o pipeline saber qual repo e: **passe sempre**. O `kick_off` valida a presenca deles antes de disparar; sem ambos, o input e rejeitado com `Input validation failed`.
- `requester_email` (**obrigatorio**) — vem da secao `## Contexto do usuario` do system prompt. Se faltar, chame `whoami` (ou ferramenta equivalente). **NUNCA pergunte ao user** — o email esta sempre disponivel na sessao. Vai como `X-Requester-Email` e e logado em todo commit.
- `max_review_rounds` (opcional) — **sempre passe `1`** salvo instrucao explicita do user. Cap na quantidade de iteracoes do fixer. `0` = default do servidor.
- `reviewers` (**obrigatorio, sem excecao**) — **sempre passe `["business-review", "security-review", "pre-mortem-review"]`**. Nao ha opt-out. Mesmo se o user disser "pula o review" / "manda direto" / "e so um typo" — **passe os 3 reviewers assim mesmo**. Os estagios rodam em paralelo e sao a defesa principal do fluxo; chamar `kick_off` sem `reviewers` faz o Armada empurrar codigo sem revisao, o pior modo de falha possivel desta integracao.
- `files_to_read` (**opcional mas RECOMENDADO**) — sempre inclua os 4 paths gerados, na ordem PRD -> spec -> plan -> tasks. E **hint de leitura**, nao limite de escopo: nao impede o agente de escrever fora dessa lista. Limite de escopo de verdade e `allowed_paths`, abaixo.
- `branch_name`, `write_mode`, `allowed_paths` (opcionais) — os tres campos que carregam **restricao pedida pelo user**: nome exato da branch nova, commit+push sem abrir PR (`write_mode: "branch_only"`), e limite de escopo em globs. Existem, sao aceitos pela tool, e o detalhe de cada um esta na ref [armada-restricoes-do-user](armada-restricoes-do-user.md) — junto com o que fazer com cada pedido.
- `strict` (opcional, default `false`) — quando `true`, toda finding (inclusive LOW nao-bloqueante) consome uma rodada do fixer.
- `jira_ticket` (opcional) — ticket associado pra log no PR.
- `order_id` (opcional) — pra correlacionar com Karavela Orders.

**Restricao vai em campo, nunca so na prosa do `task`.** O `kick_off` recusa a chamada quando a prosa pede o que e campo — e a recusa nomeia o campo que faltou. Os tres campos, as frases que disparam cada recusa e o roteamento de cada pedido: ref [armada-restricoes-do-user](armada-restricoes-do-user.md).

### O que `kick_off` devolve

- `tracking_id` — guarde: e como o user vai checar o status depois.
- `workflow_id`, `mode` (`new` / `existing`), `status`, `pr_url`, `note`.

## `armada__analyze` — analise read-only de branch ou PR

Terceiro verbo do Armada (depois de `kick_off` e `review_pr`), pra pedidos de analise **sem escrever nada**: nao cria commit, push, branch remota nem PR. E a rota deterministica pra "revisa se necessario, mas sem abrir a PR" (VELA-196), "so analisa", "dry-run", "somente leitura" — nos quatro o user **nao quer commit**. Pedido que quer o commit e so dispensa a PR **nao e daqui**: e `kick_off` com `write_mode: "branch_only"`.

```json
{
  "task": "<o que analisar, em texto livre>",
  "pr": "<URL completa do PR ou shorthand owner/repo#123>",
  "requester_email": "<email do user, do contexto>"
}
```

### Detalhamento dos campos

- `task` (**obrigatorio**) — descricao livre do que analisar.
- `pr` (**obrigatorio se nao passar `branch`**) — PR existente a analisar. URL completa ou `owner/repo#123`; owner/repo sao derivados da referencia.
- `branch` (**obrigatorio se nao passar `pr`**) — branch existente a analisar; tem que ser ref git valida. **Exatamente um** de `branch`/`pr` — passar os dois ou nenhum e erro.
- `repo_owner` / `repo_name` — opcionais quando `pr` esta setado (derivados; se passar, tem que bater com a URL). **Obrigatorios com `branch`** — sem eles o input e rejeitado.
- `requester_email` (**obrigatorio**) — igual ao do `kick_off`: vem do contexto da sessao, nunca pergunte ao user.
- `allowed_paths` (opcional) — globs de escopo da analise. A tool valida a sintaxe e encaminha ao pipeline, mas **hoje o worker nao aplica esse limite na analise** — trate como hint, nao como trava.
- `files_to_read` (opcional) — hint de arquivos pra ler primeiro.
- `jira_ticket`, `order_id` (opcionais) — repassados ao pipeline.

Nao tem `reviewers` nem `max_review_rounds`: analise nao abre PR, entao nao ha o que revisar nele.

### O que `analyze` devolve

- `tracking_id` — mesmo contrato do `kick_off`: status via `armada__check_status`, cancelamento via `armada__cancel`.
- `workflow_id`, `mode` (`analyze`), `status`, `pr_url`, `note`.

O resultado da analise e um relatorio em pt-BR, validado nao-vazio pelo runner — "nao fez nada" nao passa por sucesso. O runner reprova o run se o agente commitar ou der push na branch analisada. Criar outra branch ou abrir PR **nao e verificado** por gate — a proibicao esta no prompt do agente.

### Quando e `analyze`, quando e `review_pr`

Os dois nao escrevem codigo, mas respondem coisas diferentes: `review_pr` **posta comentarios de review no PR** (efeito visivel no PR); `analyze` **nao toca no PR** — so le e devolve o relatorio pra voce. Pedido de "me diz o que acha dessa branch/PR, sem comentar nada la" e `analyze`; "roda review no PR" e `review_pr`.

## `armada__check_status` — verificar progresso

```json
{ "tracking_id": "<id retornado pelo kick_off, analyze ou review_pr>" }
```

Retorna **exatamente** estes campos:

| Campo | Conteudo |
| --- | --- |
| `tracking_id` | o id que voce passou |
| `workflow_id` | id do workflow no Temporal |
| `status` | **frase curta em ingles**, nao enum — ver abaixo |
| `message` | detalhe legivel do estado atual; **e aqui que a causa de falha aparece** |
| `mode` | `new` / `existing` / `review` / `analyze` |
| `pr_url` | URL do PR, quando ha um |
| `artifact_ref` | **endereco** do relatorio da analise (`temporal://<workflow_id>#analysis-report`), nao o corpo dele; so em jobs `analyze`, e so depois que o run publica o artefato. Quem resolve esse endereco no relatorio e `armada__get_report` |
| `cancelled` | booleano; cancelamento **nao** aparece em `status` |
| `store_mode` | so vem preenchido em degradacao (`memory_fallback`) |

**`status` nao e enum.** E a frase que o workflow publicou no ultimo passo. Os valores reais incluem `In Progress`, `Pipeline started`, `Round 1: running implementation` (os stages sao `implementation`, `continuation`, `fixer`), `Reviewing PR #123`, `Round 1 ended NEEDS_FIX`, `Round 2: terminal fixer`, `Running analysis` (analyze), `Input validation failed`, `FetchPRContext failed`, `<stage> reported failure`, `Terminal fixer errored`, `Pipeline complete`, `Review complete`, `Analysis complete` (analyze), e `unknown` (o controller nao tem registro do workflow).

Nao existem os valores `queued`, `running`, `completed`, `failed` nem `cancelled`. **Nao compare `status` com string literal** — leia a frase e resuma.

Como decidir o desfecho:

- **Terminou** quando `status` e `Pipeline complete` (kick_off), `Review complete` (review_pr) ou `Analysis complete` (analyze). Para `kick_off`/`review_pr` o veredito vem no `message`, no formato `Verdict: <X> ...` — no `kick_off`, `<X>` e `APPROVED`, `NEEDS_HUMAN` ou `MAX_ROUNDS_REACHED`; no `review_pr`, `APPROVED`, `NEEDS_FIX` ou `NEEDS_HUMAN`. Note que `MAX_ROUNDS_REACHED` significa que sobraram findings sem correcao — **nao e sucesso**. Job `analyze` **nao** publica `Verdict:`: o `message` do `Analysis complete` e um **resumo de uma linha** (`Analyzed <alvo> ... report N byte(s)`), **nao o relatorio**. O corpo vem de `armada__get_report`, chamado com o `workflow_id` desta mesma resposta.
- **Falhou** quando `status` termina em `failed` / `errored`, ou quando a frase for `<stage> reported failure` (por exemplo, `implementation reported failure`). Um run que falha **nao** chega em `Pipeline complete`, entao nao espere um `Verdict:` nesse caso. A causa concreta esta no `message` — exit code, `OOMKilled`, `ImagePullBackOff`, `FailedCreate` por quota/RBAC, deadline. Repasse essa causa ao user; nao resuma como "falhou".
- **Foi cancelado** quando `cancelled` e `true`, independente do `status`.
- **Segue rodando** em qualquer outro caso.

**O que responder num `Analysis complete`.** Chame `armada__get_report` com o `workflow_id` desta resposta e **entregue o relatorio como a resposta** — foi ele que o user pediu. **Nao apresente o `message` como se fosse a analise**: ele e o recibo do run (alvo e tamanho), nao o achado. E nao resuma, nao parafraseie nem ofereca buscar o relatorio depois — buscar e o passo, nao uma opcao a oferecer.

Use quando o user pergunta "como ta o coder?", "o agente ja terminou?", "cade a implementacao?". Resuma o **status** em 1-2 linhas — o relatorio do `Analysis complete` e a excecao acima: ele vai inteiro, nao resumido.

**Nao fique fazendo polling sozinho** — so consulta quando o user pergunta. O Armada e assincrono; status muda em minutos a horas.

### Retry: diagnostico antes de redisparar

Quando um run falha, o user quase sempre pede pra tentar de novo. **Redisparar a mesma `task` inalterada nao e retry, e repeticao** — o mesmo input produz a mesma falha, e o user paga a espera de novo sem informacao nova.

Regra, nesta ordem:

1. **Apresente a `message` completa ao user antes de oferecer retry.** Ela carrega a causa concreta. Nao substitua por parafrase — se o `message` diz `container runner exited 137 (OOMKilled)`, o user precisa ler isso, nao "o job falhou".
2. **So redispare identico uma vez.** Se a mesma `task`, no mesmo repo, ja falhou e o user pede de novo sem mudar nada, diga que o input e identico ao que falhou e pergunte se ele quer mesmo repetir — ou o que mudar.
3. **Falha de input nao se resolve com retry.** `Input validation failed` e `FetchPRContext failed` (PR fechado, draft, inexistente, cross-repo) sao deterministicos: corrija a chamada, nao repita.

Caso real (VELA-93): tres disparos identicos, tres falhas identicas, nenhuma causa mostrada ao user — a terceira virou ticket. A causa estava no `message` desde o primeiro.

## `armada__get_report` — ler o relatorio de uma analise

```json
{ "workflow_id": "<workflow_id do check_status, ou o artifact_ref inteiro>" }
```

Aceita as duas formas que o `check_status` devolve: o `workflow_id` pelado ou o `artifact_ref` inteiro (`temporal://<workflow_id>#analysis-report`) — a tool normaliza prefixo e fragmento. A chave e `workflow_id`, **nao `tracking_id`**: diferente de `check_status` e `cancel`, que se chamam pelo `tracking_id`.

Retorna **exatamente** estes campos:

| Campo | Conteudo |
| --- | --- |
| `name` | nome do relatorio |
| `content` | **o corpo do relatorio, inline** — e isto que voce entrega ao user |
| `truncated` | booleano; `true` quando o worker teve de cortar o corpo |
| `original_bytes` | tamanho do relatorio antes do corte |

**Quando chamar.** Job `analyze` cujo `check_status` voltou `Analysis complete`. Encadeie na hora — `check_status` -> `armada__get_report` -> entrega — e o `content` **e** a resposta ao user.

**So run `analyze` produz relatorio.** Nao chame em job `kick_off` nem em `review_pr`: nao ha relatorio a buscar e a tool recusa dizendo isso. Nesses dois o desfecho ja esta no `Verdict:` do `message`.

**Relatorio cortado se anuncia.** `truncated` e `original_bytes` sao campos, nao a resposta — nunca os apresente sozinhos, no lugar do corpo. Com `truncated: true`, entregue o `content` **e** diga que ele veio cortado, citando o `original_bytes`. Um trecho apresentado como o achado inteiro e pior que um trecho declarado.

**Recusa se repassa inteira.** Os textos de recusa desta tool ja trazem causa e saida — jobs store indisponivel (retry), degradacao `memory_fallback` (estado nao compartilhado entre replicas, retry), registro de tracking expirado, identidade ausente ou requester divergente, controller sem registro do workflow, workflow que nao publicou relatorio. Repasse o teor em pt-BR **com a saida que o texto nomeia**; se ele delimita ate quando o relatorio e legivel, repasse o que ele diz — nao guarde esse prazo de cabeca. **Nunca reduza a "nao deu"**: e o erro do VELA-93 uma camada acima.

**O retry que a recusa pede e do user, nao seu.** Duas dessas causas — jobs store indisponivel e `memory_fallback` — pedem retry no proprio texto. Repasse esse pedido e pare o turno: vale aqui o mesmo do `check_status`, so consulta quando o user pergunta. Nao confunda com a regra do VELA-93 acima: ela trata de **redisparar trabalho**, e `get_report` e leitura idempotente — nao inicia run nem custa espera. Quando o user perguntar de novo, chame de novo, sem pedir confirmacao pra reler.

**A autorizacao e a mesma do `check_status` e do `cancel`.** O relatorio so volta para o requester que disparou o job, e a recusa acontece antes de o controller ser consultado — `workflow_id` de terceiro nao abre relatorio de ninguem.

## `armada__cancel` — abortar job

```json
{
  "tracking_id": "<id>",
  "reason": "<motivo opcional>"
}
```

So chame se o user pedir explicitamente pra parar. O `reason` e repassado ao pipeline pra ele postar um summary no PR. Devolve `tracking_id`, `workflow_id` e `status`.

## `armada__review_pr` — rodar review num PR ja aberto

```json
{
  "pr": "<URL do PR>",
  "requester_email": "<email>",
  "reviewers": ["business-review", "security-review", "pre-mortem-review"],
  "strict": false
}
```

Alternativa a `pr`: `repo_owner` + `repo_name` + `pr_number`. Se passar as duas formas, elas tem que concordar. Opcionais: `jira_ticket`, `order_id`. Devolve `tracking_id`, `workflow_id`, `mode`, `status`, `pr_url`.

Use quando o user pede revisao de um PR ja aberto. Diferente de `kick_off` — nao implementa codigo, so comenta.

**`review_pr` exige numero de PR.** Nao ha como apontar a tool pra uma branch sem PR: `pr_number <= 0` e recusado. E lembre: `review_pr` **posta comentarios no PR**. Pedido de "analisa sem comentar nada la" (branch ou PR) e `armada__analyze`, acima.

## Principios

- **`reviewers` sempre presente, sempre os 3** (`business-review`, `security-review`, `pre-mortem-review`). Nao ha cenario em que se chame `kick_off`/`review_pr` sem esse param. Vale tambem pra "PR pequeno", "so docs", "user pediu pra pular" — passe os 3 igual.
- **Sem `tracking_id`, nada foi acionado.** Nunca afirme "a implementacao comecou" sem `tracking_id` em maos.
- **Nao substitua `armada__kick_off`** por GitHub Copilot reviewer, comentario em PR, ou assignment. Armada e Copilot sao produtos distintos.
- **Falha no `kick_off`**: reporte com transparencia (PR link + paths + erro) e ofereca que o user acione manualmente. Nao improvise.
- **Restricao pedida pelo user tem regra propria** — recusa que nomeia campo, o que nunca se nega ao user, e o roteamento de cada pedido: ref [armada-restricoes-do-user](armada-restricoes-do-user.md).

---
name: ci-test-coverage-python
description: "Workflow reutilizavel de testes e coverage para projetos Python. Use quando o usuario perguntar sobre como adicionar testes (unit, integration, e2e) com cobertura de codigo em projetos Python, configurar pytest com pytest-cov e LCOV, usar PyPI privado, integrar com o workflow test-coverage-python, usar em monorepos ou enviar metricas de coverage ao Kafka."
---

# Skill: Testes & Coverage — Python

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.
-->

> ### ⚠️ Pré-requisito: Acesso às Org Secrets de Kafka
>
> Para usar os secrets de Kafka, **adicione o nome do repositório do seu projeto** em todos os arquivos abaixo no repositório `stone-payments/terraform-github` (via Pull Request para revisão):
>
> Caminho base: `applications/org-secrets/stone-payments/secrets.installation.d/`
>
> | Arquivo YAML | Nome da org secret | Input do workflow |
> |---|---|---|
> | `QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD.yaml` | `QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD` | `KAFKA_BROKER_URL` |
> | `QA_MATURITY_KAFKA_SASL_USERNAME_PRD.yaml` | `QA_MATURITY_KAFKA_SASL_USERNAME_PRD` | `KAFKA_SASL_USERNAME` |
> | `QA_MATURITY_KAFKA_SASL_PASSWORD_PRD.yaml` | `QA_MATURITY_KAFKA_SASL_PASSWORD_PRD` | `KAFKA_SASL_PASSWORD` |
> | `QA_MATURITY_KAFKA_SCHEMA_ENDPOINT_PRD.yaml` | `QA_MATURITY_KAFKA_SCHEMA_ENDPOINT` ⚠️ (sem `_PRD`) | `KAFKA_SCHEMA_ENDPOINT` |
> | `QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD.yaml` | `QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD` | `KAFKA_SCHEMA_USERNAME` |
> | `QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD.yaml` | `QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD` | `KAFKA_SCHEMA_PASSWORD` |
>
> Ao chamar o workflow, mapeie as org secrets para os inputs corretamente:
>
> ```yaml
> secrets:
>   KAFKA_BROKER_URL: ${{ secrets.QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD }}
>   KAFKA_SASL_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SASL_USERNAME_PRD }}
>   KAFKA_SASL_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SASL_PASSWORD_PRD }}
>   KAFKA_SCHEMA_ENDPOINT: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_ENDPOINT }}
>   KAFKA_SCHEMA_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD }}
>   KAFKA_SCHEMA_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD }}
> ```

## Escopo

**Cobre**:
- Como incorporar o workflow `test-coverage-python` em um projeto Python
- Todos os inputs do workflow (`project_name`, `unit_test_path`, `integration_test_path`, `e2e_test_path`, `python_version`, `requirements_file`, `working_directory`, `extra_test_args`)
- Configuracao de PyPI privado via `PIP_EXTRA_INDEX_URL_USERNAME`, `PIP_EXTRA_INDEX_URL_PASSWORD` e `PIP_EXTRA_INDEX_URL`
- Coleta de coverage com `pytest-cov` em formato LCOV
- Merge de multiplos relatorios LCOV com `lcov`
- Secrets opcionais para envio de metricas ao Kafka (`KAFKA_*`)
- Uso em monorepos com `working_directory`
- Artifact de coverage gerado (`coverage-{project_name}`)

**NAO cobre**:
- Escrita de testes em Python
- Configuracao avancada do pytest (fixtures, plugins)
- Infraestrutura de Kafka

## Exemplos de Perguntas

- "Como adiciono cobertura de testes no meu projeto Python?"
- "Como configuro o workflow de testes para Python com pytest?"
- "Como separo testes unit, integration e e2e no workflow Python?"
- "Meu projeto tem um PyPI privado, como configuro?"
- "Como uso python_version para fixar a versao do Python?"
- "Como uso o workflow em monorepo Python?"
- "Como envio metricas de coverage para o Kafka?"
- "O workflow instala o pytest-cov automaticamente?"

## Conhecimento Embutido

### Localizacao do Workflow

```
stone-payments/github-actions-workflows
  .github/workflows/test-coverage-python.yml
```

Referencia para consumo: `@test-coverage-python-v0`

---

### Como Integrar o Workflow

#### Uso Minimo (apenas testes unitarios)

```yaml
# .github/workflows/ci.yml
jobs:
  coverage:
    uses: stone-payments/github-actions-workflows/.github/workflows/test-coverage-python.yml@test-coverage-python-v0
    with:
      project_name: meu-projeto
      unit_test_path: tests/unit
```

#### Com Todos os Tipos de Teste e Versao Python

```yaml
jobs:
  coverage:
    uses: stone-payments/github-actions-workflows/.github/workflows/test-coverage-python.yml@test-coverage-python-v0
    with:
      project_name: meu-projeto
      unit_test_path: tests/unit
      integration_test_path: tests/integration
      e2e_test_path: tests/e2e
      python_version: '3.12'
```

#### Com PyPI Privado

```yaml
jobs:
  coverage:
    uses: stone-payments/github-actions-workflows/.github/workflows/test-coverage-python.yml@test-coverage-python-v0
    with:
      project_name: meu-projeto
      unit_test_path: tests/unit
    secrets:
      PIP_EXTRA_INDEX_URL: ${{ secrets.PIP_EXTRA_INDEX_URL }}
      PIP_EXTRA_INDEX_URL_USERNAME: ${{ secrets.PIP_EXTRA_INDEX_URL_USERNAME }}
      PIP_EXTRA_INDEX_URL_PASSWORD: ${{ secrets.PIP_EXTRA_INDEX_URL_PASSWORD }}
```

#### Em Monorepo com pyproject.toml e Metricas Kafka

```yaml
jobs:
  coverage:
    uses: stone-payments/github-actions-workflows/.github/workflows/test-coverage-python.yml@test-coverage-python-v0
    with:
      project_name: payments-service
      unit_test_path: tests/unit
      requirements_file: pyproject.toml
      working_directory: services/payments
    secrets:
      KAFKA_BROKER_URL: ${{ secrets.QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD }}
      KAFKA_SASL_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SASL_USERNAME_PRD }}
      KAFKA_SASL_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SASL_PASSWORD_PRD }}
      KAFKA_SCHEMA_ENDPOINT: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_ENDPOINT }}
      KAFKA_SCHEMA_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD }}
      KAFKA_SCHEMA_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD }}
```

---

### Inputs Disponiveis

| Input | Tipo | Obrigatorio | Descricao | Padrao |
|-------|------|-------------|-----------|--------|
| `project_name` | string | **sim** | Nome do projeto. Identifica o artifact de coverage. | — |
| `unit_test_path` | string | nao | Path/padrao dos testes unitarios passado ao pytest (ex: `"tests/unit"`). Omita para nao executar. | — |
| `integration_test_path` | string | nao | Path dos testes de integracao. Omita para nao executar. | — |
| `e2e_test_path` | string | nao | Path dos testes e2e. Omita para nao executar. | — |
| `python_version` | string | nao | Versao do Python (ex: `"3.11"`, `"3.12"`). | `"3.11"` |
| `requirements_file` | string | nao | Arquivo de dependencias (ex: `requirements.txt`, `pyproject.toml`). | `"requirements.txt"` |
| `working_directory` | string | nao | Diretorio raiz do projeto. Util para monorepos. | `"."` |
| `extra_test_args` | string | nao | Argumentos extras passados para todos os comandos pytest. | — |
| `runs_on` | string | nao | Runner a usar (formato JSON). | `"['ubuntu-22.04']"` |

### Secrets Opcionais

| Secret | Descricao |
|--------|-----------|
| `PIP_EXTRA_INDEX_URL_USERNAME` | Usuario para autenticacao em PyPI privado |
| `PIP_EXTRA_INDEX_URL_PASSWORD` | Senha/token para autenticacao em PyPI privado |
| `PIP_EXTRA_INDEX_URL` | URL base do PyPI privado (sem credenciais). Ex: `https://pypi.mycompany.com/simple/` |
| `KAFKA_BROKER_URL` | URL do broker Kafka |
| `KAFKA_SASL_USERNAME` | Username SASL do Kafka |
| `KAFKA_SASL_PASSWORD` | Password SASL do Kafka |
| `KAFKA_SCHEMA_ENDPOINT` | URL do Schema Registry |
| `KAFKA_SCHEMA_USERNAME` | Username do Schema Registry |
| `KAFKA_SCHEMA_PASSWORD` | Password do Schema Registry |

---

### O que o Workflow Faz (resumo)

- Setup do Python com a versao indicada (cache pip incluso)
- Configura PyPI privado quando `PIP_EXTRA_INDEX_URL*` for fornecido
- Instala dependencias do projeto + `pytest` e `pytest-cov` automaticamente
- Roda `pytest` com coverage em LCOV para cada tipo configurado (unit/integration/e2e)
- Mescla os relatorios em `coverage/lcov.info`
- Faz upload do artifact `coverage-{project_name}` (so o LCOV ja merged)
- Quando configurado, envia metricas agregadas para o backend de qualidade da plataforma

> Fonte: `stone-payments/github-actions-workflows/.github/workflows/test-coverage-python.yml` (complemento — nao em docs/)

---

### Requisito: pytest-cov no Projeto

O workflow instala `pytest` e `pytest-cov` automaticamente. Nao e necessario incluir no `requirements.txt`, mas e boa pratica:

```txt
# requirements-dev.txt (opcional, o workflow instala)
pytest>=7.0
pytest-cov>=4.0
```

Para usar `pyproject.toml` como `requirements_file`, o pip suporta: `pip install -r pyproject.toml` se estiver no formato wheel/sdist ou usando `pip install .`.

---

### Artifact Gerado

O workflow faz upload do seguinte artifact:
- **Nome**: `coverage-{project_name}`
- **Arquivo**: `coverage/lcov.info`
- **Formato**: LCOV

---

### Envio de Metricas

Quando os secrets `KAFKA_*` sao fornecidos, o workflow envia metricas de coverage para o backend de qualidade da plataforma (consumido por relatorios internos). Sem esses secrets, o passo e ignorado silenciosamente — coverage continua sendo gerado e publicado como artifact normalmente.

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Criar `.github/workflows/test-coverage.yml`** apontando para `test-coverage-python.yml@main`
- **Editar `pyproject.toml`/`pytest.ini`** para `pytest-cov` com `--cov-report=lcov`
- **Editar `requirements.txt`/`pyproject.toml`** adicionando `pytest-cov`
- **Adicionar `PIP_EXTRA_INDEX_URL_*`** secret para PyPI privado
- **Abrir PR draft**

### Triggers proativos
- "Adicionar coverage Python" → `🛠️ Acao proposta: configuro pytest-cov + workflow + abro PR`

### Acoes destrutivas
- N/A.

## Instrucoes MCP

Esta skill nao tem doc dedicado em `stone-payments/karavela` `docs/`. A fonte primaria de operacao e o proprio reusable workflow.

| Repositorio | Arquivo/Caminho | Prioridade | Quando buscar |
|-------------|-----------------|------------|---------------|
| `stone-payments/github-actions-workflows` | `.github/workflows/test-coverage-python.yml` | primaria operacional — complemento (nao em docs/) | Inputs/outputs e tag mais recente do workflow |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/deploy-de-aplicacoes/` | complemento | Para entender onde encaixar o job no pipeline geral |
| `stone-payments/terraform-github` | `applications/org-secrets/stone-payments/secrets.installation.d/` | complemento | Liberacao das org secrets de Kafka para o repositorio do usuario |

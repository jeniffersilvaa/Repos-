---
name: kli
description: "Configuracao (acao) via CLI do KLI — Karavela Line Interface. Use quando o usuario quiser EXECUTAR operacoes pelo terminal: listar apps, ver detalhes/segredos/deploy de um app, rollback, watch/logs/check/events de deploy, criacao e edicao de secrets pelo terminal, autenticacao (login/logout), kli doctor, kli upgrade, modo raw vs TUI. Para entender conceitos da plataforma, use as skills de dominio; para operar a plataforma via chat com MCPs, use a skill platform."
---

# Skill: KLI (Karavela Line Interface)

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.

  Exemplos de uso:
  - Corrigir informacao desatualizada no conhecimento embutido
  - Adicionar restricao temporaria (ex: "versao X do KLI tem bug no comando Y")
  - Adicionar conhecimento que ainda nao esta na documentacao oficial
  - Bloquear uma orientacao especifica (ex: "NAO recomende usar comando depreciado")
-->

## Modo Acoes

Esta skill atua em **Modo Acoes** por default — sendo a propria CLI da plataforma, ela executa comandos KLI livremente (read) e com confirmacao (write). Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Rodar KLI** (todos os comandos read/write da allowlist) — ver `knowledge/kli-commands.md`
- **Equivalente MCP** — `mcp__vela-mcp-hub__kli-mcp__*` (preferir quando configurado)
- **Help e diagnostico do proprio KLI** — `kli doctor`, `kli auth status`, `kli upgrade`
- **Orientar instalacao** — `gh release download` ou script de install
- **NAO** modifica arquivos do repo do usuario (essa skill e sobre a CLI, nao sobre config da app)

### Triggers proativos
- "KLI nao funciona" → rodar `kli doctor` + diagnostico
- "Como instalar/upgradar" → orientar comando
- "Como rodar X via KLI" → mostrar o comando direto

### Acoes destrutivas
- Comandos write — herda regras das skills especificas (ex: `kli delete secret` exige dupla confirmacao — ver skill `secrets-vault`).

## Escopo

**Cobre**:
- Instalacao e atualizacao do KLI (download de binario, build do fonte, `kli upgrade`)
- Autenticacao (OAuth via browser para Karavela e ArgoCD, `kli auth login/logout/status`)
- Listagem de aplicacoes, recursos e secrets (`kli get apps/resources/secrets/prs/events`)
- Descricao detalhada de aplicacoes e recursos (`kli describe app/resource/pr`)
- Gerenciamento de secrets pelo terminal (`kli create/edit/delete/rename secret`)
- Monitoramento em tempo real (`kli watch app`, `kli logs app`, `kli check app`, `kli get events`)
- Configuracao do KLI (`kli set app`, `kli set raw`, variaveis de ambiente)
- Modos de operacao: TUI interativo (padrao) vs modo raw (`--raw`/`-r`) com formatos text/json/yaml
- Diagnostico do ambiente (`kli doctor`)
- Integracao com a Vela (`kli vela` - chat, sync, status, list, repo add/remove)
- Workspace detection (deteccao automatica de aplicacao pelo repositorio git)
- Atalhos rapidos no TUI (Shift+L/W/C/E para logs/watch/check/events)
- Pull requests (`kli get prs`, `kli describe pr`)
- Comandos depreciados e seus substitutos

**NAO cobre**:
- Configuracao de charts Helm (coberto pela skill charts-config)
- Fluxos de deploy e rollback via Portal (coberto pela skill deploy-rollback)
- Gerenciamento de secrets via Portal/Vault (coberto pela skill secrets-vault)
- Observabilidade e dashboards (coberto pela skill observabilidade)
- Diagnostico de erros em pods (coberto pela skill troubleshooting)

## Exemplos de Perguntas

- "Como instalo o KLI?"
- "Como faco login no KLI?"
- "Como listo minhas aplicacoes pelo terminal?"
- "Como crio um secret pela linha de comando?"
- "Como monitoro meu deploy em tempo real?"
- "Como vejo os logs da minha aplicacao pelo KLI?"
- "Como faco diagnostico rapido de saude da minha app?"
- "Como configuro uma aplicacao padrao no KLI?"
- "Qual a diferenca entre modo TUI e modo raw?"
- "Como exporto dados em JSON pelo KLI?"
- "Como atualizo o KLI para a versao mais recente?"
- "O comando kli argo login nao funciona, o que houve?"
- "Como configuro o KLI para usar modo raw por padrao?"
- "Como uso o KLI em scripts de CI/CD?"
- "Como vejo eventos Kubernetes da minha aplicacao?"
- "Como renomeio um secret sem alterar o valor?"
- "Como verifico se meu ambiente esta configurado corretamente?"
- "Como uso a Vela pelo KLI?"

## Conhecimento Embutido

### O que e o KLI

O KLI (Karavela Line Interface) e a ferramenta de linha de comando oficial para interagir com os servicos da plataforma Karavela e Backstage. Permite gerenciar aplicacoes, recursos, secrets e deployments diretamente pelo terminal, sem precisar acessar o Portal web.

**Repositorio**: `stone-payments/kli`

### Instalacao

#### Pre-requisitos

- [GitHub CLI (`gh`)](https://cli.github.com/) instalado e autenticado (`gh auth login`)

#### Download do Binario

**macOS (Apple Silicon / M1+)**:
```bash
mkdir -p ~/.local/bin && gh release download --repo stone-payments/kli --pattern 'kli_*_Darwin_arm64.tar.gz' --output - | tar xz -C ~/.local/bin
```

**macOS (Intel)**:
```bash
mkdir -p ~/.local/bin && gh release download --repo stone-payments/kli --pattern 'kli_*_Darwin_x86_64.tar.gz' --output - | tar xz -C ~/.local/bin
```

**Linux (amd64)**:
```bash
mkdir -p ~/.local/bin && gh release download --repo stone-payments/kli --pattern 'kli_*_Linux_x86_64.tar.gz' --output - | tar xz -C ~/.local/bin
```

**Linux (arm64)**:
```bash
mkdir -p ~/.local/bin && gh release download --repo stone-payments/kli --pattern 'kli_*_Linux_arm64.tar.gz' --output - | tar xz -C ~/.local/bin
```

> **Nota**: Certifique-se de que `~/.local/bin` esta no seu PATH:
> ```bash
> export PATH="$HOME/.local/bin:$PATH"
> ```

#### Verificacao e Diagnostico

```bash
kli --version    # Verificar versao instalada
kli doctor       # Verificar pre-requisitos do ambiente
```

#### Atualizacao

```bash
kli upgrade      # Atualizar para a versao mais recente
```

#### Build do Fonte

```bash
git clone https://github.com/stone-payments/kli.git
cd kli
go build -o bin/kli ./cmd/kli
./bin/kli --version
```

**Fonte**: `kli/README.md`

### Modos de Operacao

O KLI possui dois modos de operacao:

| Modo | Ativacao | Descricao |
|------|----------|-----------|
| **TUI (interativo)** | Padrao quando TTY detectado | Interface rica com navegacao, selecao e feedback em tempo real |
| **Raw (nao-interativo)** | Flag `-r` ou `--raw` | Saida em texto puro para scripts, automacao e pipelines CI/CD |

#### Formatos de Saida no Modo Raw

| Formato | Flag | Descricao |
|---------|------|-----------|
| `text` | `-o text` (padrao) | Tabelas legiveis por humanos |
| `json` | `-o json` | JSON valido para parsing programatico |
| `yaml` | `-o yaml` | YAML compativel com Kubernetes |

#### Modo Raw Global

```bash
kli set raw on     # Habilitar raw como padrao para todos os comandos
kli set raw off    # Voltar ao TUI
kli set raw        # Verificar configuracao atual
```

**Fonte**: `kli/README.md`

### Autenticacao

O KLI usa autenticacao OAuth via browser para Karavela e ArgoCD. Os tokens sao armazenados no keyring do sistema operacional (macOS Keychain, Linux Secret Service, Windows Credential Manager) com fallback para arquivo criptografado.

#### Comandos de Autenticacao

| Comando | Descricao |
|---------|-----------|
| `kli auth login` | Login via browser (Karavela + ArgoCD) |
| `kli auth login --karavela` | Login apenas Karavela |
| `kli auth login --argo` | Login apenas ArgoCD |
| `kli auth status` | Status da autenticacao (ambos provedores) |
| `kli auth logout` | Encerrar sessao (ambos) |
| `kli auth logout --karavela` | Encerrar sessao apenas Karavela |
| `kli auth logout --argo` | Encerrar sessao apenas ArgoCD |

> **IMPORTANTE**: Os comandos `kli argo login`, `kli argo status` e `kli argo logout` estao **depreciados**. Use `kli auth login --argo`, `kli auth status` e `kli auth logout --argo` respectivamente.

#### Auto-Refresh de Token

O KLI faz refresh automatico do token quando ele atinge 80% do TTL, evitando que o usuario precise refazer login com frequencia.

**Fonte**: `kli/README.md`, `kli/internal/auth/`

### Aplicacoes e Recursos

#### Listar Aplicacoes

```bash
kli get apps                  # TUI interativo
kli get apps -r               # Modo raw (texto)
kli get apps -r -o json       # Modo raw (JSON)
kli get apps -r -o yaml       # Modo raw (YAML)
```

#### Descrever Aplicacao

```bash
kli describe app minha-app         # Detalhes completos (ambientes, deploys, custos, tags)
kli describe app minha-app -r      # Modo raw
kli describe app                   # Usa aplicacao padrao (se configurada)
```

#### Listar Recursos do Catalogo

```bash
kli get resources                  # TUI interativo
kli get resources -r -o json       # Modo raw (JSON)
```

#### Descrever Recurso

```bash
kli describe resource meu-recurso
```

**Fonte**: `kli/README.md`

### Aplicacao Padrao

O KLI permite definir uma aplicacao padrao para evitar digitar o nome em cada comando. A resolucao segue esta ordem de precedencia:

1. Argumento na linha de comando (`kli describe app minha-app`)
2. Variavel de ambiente `KLI_CURRENT_APP`
3. Arquivo de configuracao (`kli set app minha-app`)
4. Workspace detection (deteccao automatica pelo repositorio git)

```bash
kli set app minha-app     # Definir aplicacao padrao
kli set app --clear       # Limpar aplicacao padrao
kli describe app          # Usa a aplicacao padrao automaticamente
```

**Fonte**: `kli/README.md`, `kli/internal/commands/resolve/`

### Workspace Detection

O KLI detecta automaticamente a aplicacao associada ao repositorio git em que voce esta trabalhando, consultando o catalogo do Backstage. O resultado e cacheado por 24 horas em `~/.kli/workspace-cache.json`.

Essa funcionalidade e habilitada por padrao e pode ser desabilitada via configuracao:

```yaml
# ~/.kli/config.yaml
workspace_detection: false
```

**Fonte**: `kli/internal/workspace/`

### Gerenciamento de Secrets

O KLI permite gerenciar secrets diretamente pelo terminal. Os valores sao criptografados no lado do cliente usando AES-256-GCM antes de serem transmitidos — o servidor nunca recebe valores em texto puro.

#### Criar Secrets

```bash
# A partir de valores literais
kli create secret minha-app --env prd --from-literal DB_HOST=localhost --from-literal DB_PASS=s3cret -r

# A partir de arquivo
kli create secret minha-app --env prd --from-file tls.crt=/path/to/cert.pem -r

# A partir de arquivo .env
kli create secret minha-app --env prd --from-env-file .env -r
```

#### Editar Secrets

```bash
# Editar valor (modo raw)
kli edit secret minha-app --env prd --from-literal DB_HOST=novo-host -r

# Editar a partir de .env
kli edit secret minha-app --env prd --from-env-file .env -r

# Modo interativo
kli edit secret minha-app
```

#### Renomear Secrets

```bash
# Renomear chave (valor inalterado)
kli rename secret minha-app --env prd --old-key DB_HOST --new-key DATABASE_HOST --yes -r

# Modo interativo
kli rename secret minha-app
```

#### Deletar Secrets

```bash
# Deletar um secret
kli delete secret minha-app --env prd --key DB_HOST -r

# Deletar multiplos
kli delete secret minha-app --env prd --key DB_HOST --key DB_PASS -r

# Pular confirmacao (para CI/CD)
kli delete secret minha-app --env prd --key DB_HOST --yes -r
```

#### Listar Secrets

```bash
kli get secrets minha-app          # TUI interativo (valores mascarados)
kli get secrets minha-app -r       # Modo raw
```

> **Nota**: Secrets de sistema (`VAULT_ORIGIN`) sao ocultados por padrao. Use `--show-system` para exibi-los.

**Fonte**: `kli/README.md`, `kli/internal/commands/create/`, `kli/internal/crypto/`

### Monitoramento

#### Watch (Monitoramento em Tempo Real)

```bash
kli watch app minha-app                    # TUI interativo (health, sync, pods, rollout)
kli watch app minha-app --interval 10s     # Intervalo personalizado
kli watch app minha-app -r -o json         # Modo raw (JSON)
```

#### Logs (Streaming de Logs)

```bash
kli logs app minha-app                                              # TUI com selecao de pod/container
kli logs app minha-app -r                                           # Modo raw (NDJSON)
kli logs app minha-app --env prd --pod meu-pod --container main -r  # Pod/container especifico
```

#### Check (Diagnostico Rapido)

```bash
kli check app minha-app              # Diagnostico de saude (producao por padrao)
kli check app minha-app --env stg    # Ambiente especifico
kli check app minha-app -r -o json   # JSON com recursos relacionados (Application, Workload, Pods, Ingresses)
```

#### Eventos Kubernetes

```bash
kli get events minha-app                    # Warning por padrao, auto-refresh no TUI
kli get events minha-app --all              # Todos os eventos (incluindo Normal)
kli get events minha-app --filter "CrashLoop"  # Filtrar por texto
kli get events minha-app -r -o json         # JSON
```

**Fonte**: `kli/README.md`, `kli/internal/commands/watch/`, `kli/internal/commands/logs/`, `kli/internal/commands/check/`

### Atalhos Rapidos no TUI

Na tela de listagem de aplicacoes ou na tela de detalhes, use atalhos para navegar entre comandos sem sair do TUI:

| Atalho | Acao |
|--------|------|
| `Shift+L` | Abrir logs da aplicacao selecionada |
| `Shift+W` | Abrir watch da aplicacao selecionada |
| `Shift+C` | Diagnostico rapido (check) da aplicacao |
| `Shift+E` | Listar eventos da aplicacao |

> **Nota**: Requer autenticacao ArgoCD (`kli auth login --argo`). Ao sair de logs/watch/check/events, voce retorna a tela anterior com o estado preservado.

**Fonte**: `kli/README.md`

### Pull Requests

```bash
kli get prs                    # Listar PRs abertos (TUI interativo)
kli get prs -r                 # Modo raw
kli get prs -r -o json         # JSON
kli get prs --limit 20         # Limitar resultados
kli describe pr                # Detalhes do PR da branch atual
kli describe pr 42             # PR especifico
kli describe pr 42 --repo owner/repo  # PR de outro repositorio
```

**Fonte**: `kli/README.md`

### Integracao com a Vela (Agente de AI)

O KLI integra a Vela — agente de inteligencia artificial especializada na plataforma Karavela — via GitHub Copilot CLI.

#### Pre-requisitos

- GitHub CLI (`gh`) instalado e autenticado
- Extensao GitHub Copilot CLI habilitada (`gh copilot`)

#### Comandos

```bash
kli vela                                           # Chat interativo
kli vela -p "como configuro autoscaling com KEDA?" # Pergunta direta
kli vela sync                                      # Sincronizar skills e agentes
kli vela sync --skills                             # Sincronizar apenas skills
kli vela sync --agents                             # Sincronizar apenas agents
kli vela status                                    # Status de instalacao
kli vela list                                      # Listar skills disponiveis
kli vela repo add                                  # Adicionar repositorio de skills
kli vela repo remove                               # Remover repositorio de skills
```

> **IMPORTANTE**: Os comandos `kli vela skills *` estao **depreciados**. Use os equivalentes diretos em `kli vela`.

Na primeira execucao, o KLI sincroniza automaticamente as skills e o agente Vela.

**Fonte**: `kli/README.md`, `kli/internal/commands/vela/`

### Configuracao

#### Arquivo de Configuracao

O KLI usa YAML com Viper. Localizacao (em ordem de precedencia):
1. `$XDG_CONFIG_HOME/kli/config.yaml`
2. `~/.kli/config.yaml`
3. `~/.config/kli/config.yaml`

#### Variaveis de Ambiente

| Variavel | Descricao | Padrao |
|----------|-----------|--------|
| `KLI_BACKSTAGE_URL` | URL do Backstage | `https://karavela-core-backstage.stone.tech` |
| `KLI_AUTH_CALLBACK_PORT` | Porta do callback OAuth | `8085` |
| `KLI_AUTH_TIMEOUT` | Timeout de autenticacao | `5m` |
| `KLI_AUTH_ENV` | Ambiente OAuth | `production` |
| `KLI_CURRENT_APP` | Aplicacao padrao (sobrescreve config) | - |
| `KLI_ARGOCD_URL` | URL do ArgoCD | `https://argocd.stone.tech` |
| `KLI_ANALYTICS_DISABLED` | Desabilitar analytics | `false` |

**Fonte**: `kli/README.md`, `kli/internal/config/`

### Uso em Scripts e CI/CD

Para usar o KLI em pipelines de CI/CD ou scripts de automacao, use sempre o modo raw (`-r`) com formato JSON ou YAML:

```bash
# Listar apps e filtrar com jq
kli get apps -r -o json | jq '.[] | select(.name == "minha-app")'

# Criar secrets em batch a partir de .env
kli create secret minha-app --env prd --from-env-file .env --yes -r

# Deletar secrets sem confirmacao
kli delete secret minha-app --env prd --key CHAVE_ANTIGA --yes -r

# Check de saude em JSON para parsing
kli check app minha-app -r -o json
```

> **Dica**: Use `kli set raw on` para definir raw como padrao em ambientes nao-interativos, ou defina a variavel `KLI_RAW_MODE=true`.

**Fonte**: `kli/README.md`

### Referencia Completa de Comandos

#### Autenticacao
| Comando | Descricao |
|---------|-----------|
| `kli auth login` | Login via browser (Karavela + ArgoCD) |
| `kli auth login --karavela` | Login apenas Karavela |
| `kli auth login --argo` | Login apenas ArgoCD |
| `kli auth status` | Status da autenticacao |
| `kli auth logout` | Logout de ambos provedores |

#### Aplicacoes e Recursos
| Comando | Descricao |
|---------|-----------|
| `kli get apps` | Listar aplicacoes |
| `kli get resources` | Listar recursos do catalogo |
| `kli get secrets` | Listar secrets de uma aplicacao |
| `kli get prs` | Listar PRs abertos |
| `kli get events <nome>` | Listar eventos Kubernetes |
| `kli describe app <nome>` | Detalhes de uma aplicacao |
| `kli describe resource <nome>` | Detalhes de um recurso |
| `kli describe pr [numero]` | Detalhes de um PR |

#### Secrets
| Comando | Descricao |
|---------|-----------|
| `kli create secret` | Criar secrets |
| `kli edit secret` | Editar secrets |
| `kli rename secret` | Renomear chave de um secret |
| `kli delete secret` | Deletar secrets |

#### Monitoramento
| Comando | Descricao |
|---------|-----------|
| `kli watch app <nome>` | Monitorar deploy em tempo real |
| `kli logs app <nome>` | Streaming de logs |
| `kli check app <nome>` | Diagnostico rapido de saude |

#### Configuracao
| Comando | Descricao |
|---------|-----------|
| `kli set app <nome>` | Definir aplicacao padrao |
| `kli set app --clear` | Limpar aplicacao padrao |
| `kli set raw [on\|off]` | Modo raw como padrao |

#### Utilitarios
| Comando | Descricao |
|---------|-----------|
| `kli doctor` | Verificar pre-requisitos |
| `kli upgrade` | Atualizar KLI |

#### Vela (AI Agent)
| Comando | Descricao |
|---------|-----------|
| `kli vela [prompt]` | Chat com a Vela |
| `kli vela sync` | Sincronizar skills e agents |
| `kli vela status` | Status de instalacao |
| `kli vela list` | Listar skills disponiveis |
| `kli vela repo add` | Adicionar repositorio de skills |
| `kli vela repo remove` | Remover repositorio de skills |

### Comandos Depreciados

| Comando Depreciado | Substituto |
|--------------------|------------|
| `kli argo login` | `kli auth login --argo` |
| `kli argo status` | `kli auth status` |
| `kli argo logout` | `kli auth logout --argo` |
| `kli vela skills sync` | `kli vela sync` |
| `kli vela skills status` | `kli vela status` |
| `kli vela skills list` | `kli vela list` |
| `kli vela skills repo add` | `kli vela repo add` |
| `kli vela skills repo remove` | `kli vela repo remove` |

### Vela x Help Foundation Platform Bot

Antes de abrir um chamado no Bot da Help Foundation Platform, verifique se a Vela pode ajudar:

| Escopo do Bot | Skills da Vela | Cobertura |
|---------------|----------------|-----------|
| Alertas e Incidentes | `observabilidade`, `troubleshooting` | Coberto |
| Cloud Gov | `seguranca`, `auditoria-siem`, `modelo-acessos` | Coberto |
| Computacao em Nuvem | `recursos-scaling`, `charts-config`, `multi-regiao` | Coberto |
| Conectividade | `networking-ingress` | Coberto |
| Deploy | `deploy-rollback`, `preview-envs` | Coberto |
| Karavela Containers | `charts-config`, `recursos-scaling`, `ambientes-contextos`, `troubleshooting` | Coberto |
| Karavela Portal | `onboarding`, `modelo-acessos` | Coberto |
| Observabilidade | `observabilidade` | Coberto |
| Banco de Dados | `migrations-jobs` | Parcial (jobs e migrations) |
| Gestao de Incidentes | `troubleshooting` | Parcial (diagnostico apenas) |
| Data Center | — | Nao coberto |
| Mensageria | — | Nao coberto |

**Fonte**: `kli/README.md`

### Feedback

Se encontrar problemas com o KLI ou a Vela:

- **Feedback rapido**: canal `#tmp-kli-feedbacks` no Slack
- **Relato detalhado**: issue em [stone-payments/kli](https://github.com/stone-payments/kli/issues)

## Instrucoes MCP

Esta skill nao tem doc dedicado em `stone-payments/karavela` `docs/`. A fonte primaria e o proprio repositorio do KLI.

| Repositorio | Arquivo/Caminho | Prioridade | Quando buscar |
|-------------|-----------------|------------|---------------|
| `stone-payments/kli` | `README.md` | primaria operacional — complemento (nao em docs/) | Lista oficial de comandos, flags e exemplos |
| `stone-payments/kli` | release page | complemento | Binarios por SO/arquitetura para instalacao |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/` | complemento | Para entender o que o KLI esta listando (apps, recursos, secrets etc.) — a UI Portal usa o mesmo backend |

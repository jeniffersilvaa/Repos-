---
name: charts-changelog
description: "Comparacao de changelogs dos Helm charts da plataforma Karavela. Use quando o usuario perguntar o que mudou entre duas versoes de um chart (API, Worker, CronJob, Job, StatefulSet), quais recursos/features foram implementados de uma versao para outra, o diff/changelog entre versoes, o que entrou desde a versao atual ate a mais recente, quais chaves novas do values.yaml surgiram, se vale a pena fazer bump de versao, ou pedir um resumo agregado das mudancas acumuladas ao longo de varias versoes de um chart."
---

# Skill: charts-changelog

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.

  Exemplos de uso:
  - Corrigir caminho/nome de changelog que mudou de lugar
  - Adicionar restricao temporaria (ex: "changelog do statefulset esta defasado")
  - Bloquear uma orientacao especifica
-->

## Escopo

**Cobre**:
- Leitura dos changelogs oficiais dos charts da plataforma em `platform-k8s-charts/.docs/changelogs/CHANGELOG.<tipo>.md`
- Diff entre duas versoes especificas de um mesmo chart (o que entrou de `vX` para `vY`)
- Agregacao de mudancas ao longo de varias versoes (quando o salto e maior que uma versao, somar tudo que entrou no intervalo)
- Identificacao das chaves novas/alteradas do `values.yaml` introduzidas por versao
- Diff entre a versao atual da aplicacao (detectada no `Chart.yaml` ou via `kli describe app`) e a versao mais recente publicada do chart

**NAO cobre**:
- Significado/uso detalhado de cada parametro do `values.yaml` (coberto por `charts-config`)
- Politica de versionamento e auto-atualizacao com `1.*.*` (coberto por `charts-config`)
- Fluxos de deploy/rollback apos o bump (coberto por `deploy-rollback`)
- Changelog de releases da propria aplicacao do usuario (Release Drafter — coberto por `deploy-rollback`)

## Exemplos de Perguntas

- "O que mudou entre a v1.36.0 e a v1.38.11 do chart de API?"
- "Quais recursos foram implementados do worker v1.28 para o v1.30?"
- "Estou na v1.31.2 do chart de API, o que entrou de novo ate a versao atual?"
- "Me da o changelog agregado do CronJob entre v1.20 e v1.23"
- "Quais chaves novas do values.yaml surgiram nas ultimas 5 versoes do chart de API?"
- "Vale a pena atualizar meu chart de Job da v1.18 para a mais recente?"
- "Qual a versao mais recente do chart de StatefulSet e o que ela trouxe?"

## Conhecimento Embutido

### Onde ficam os changelogs

Cada tipo de chart tem um changelog proprio, gerado automaticamente por CI/CD + IA a cada release (NAO e editado a mao). Ficam no repositorio `stone-payments/platform-k8s-charts`, no diretorio `.docs/changelogs/`:

| Tipo de chart | Arquivo | TechDocs no Portal |
|---------------|---------|--------------------|
| API | `.docs/changelogs/CHANGELOG.api.md` | `/docs/stone/component/helm-charts/changelogs/CHANGELOG.api/` |
| Worker | `.docs/changelogs/CHANGELOG.worker.md` | `/docs/stone/component/helm-charts/changelogs/CHANGELOG.worker/` |
| CronJob | `.docs/changelogs/CHANGELOG.cronjob.md` | `/docs/stone/component/helm-charts/changelogs/CHANGELOG.cronjob/` |
| Job | `.docs/changelogs/CHANGELOG.job.md` | `/docs/stone/component/helm-charts/changelogs/CHANGELOG.job/` |
| StatefulSet | `.docs/changelogs/CHANGELOG.statefulset.md` | `/docs/stone/component/helm-charts/changelogs/CHANGELOG.statefulset/` |
| Confluent Kafka Connect | `.docs/changelogs/CHANGELOG.confluent-kafka-connect.md` | `.../CHANGELOG.confluent-kafka-connect/` |
| Kafka Connect | `.docs/changelogs/CHANGELOG.kafka-connect.md` | `.../CHANGELOG.kafka-connect/` |
| GHA / GitHub (chart auxiliares) | `.docs/changelogs/CHANGELOG.gha.md`, `CHANGELOG.github.md` | `.../CHANGELOG.gha/`, `.../CHANGELOG.github/` |

O mesmo conteudo e navegavel pelo Portal Karavela (Backstage TechDocs) no caminho `/docs/stone/component/helm-charts/changelogs/CHANGELOG.<tipo>/` — util para mandar um link clicavel ao usuario.

### Formato de cada changelog

Estrutura padronizada (entradas em ordem **decrescente**, versao mais nova no topo):

```markdown
# Changelog

## 1.38.13

<descricao em prosa do que mudou, impacto pratico e quando usar>

- chave.nova.do.values   (quando ha chaves novas/alteradas no values.yaml)
- outra.chave

_Fonte: PR [#504](https://github.com/stone-payments/platform-k8s-charts/pull/504) — tag platform-k8s-api-chart/v1.38.13._
```

Pontos importantes para extrair:
- Cabecalho `## X.Y.Z` delimita cada versao (sem prefixo `v`).
- A prosa descreve a feature/correcao, o impacto e se exige acao.
- Bullets listam **chaves novas ou alteradas do `values.yaml`** (nem toda versao tem; correcoes internas e bumps de dependencia frequentemente nao expoem chaves novas).
- O rodape `_Fonte: PR [#N]... — tag .../vX.Y.Z._` da o numero do PR e a tag exata.

### Como obter o conteudo

Use, em ordem de preferencia:

1. **Portal Karavela (Backstage TechDocs)** — fonte primaria. O changelog renderizado fica em:
   ```
   https://karavela-core-backstage.stone.tech/docs/stone/component/helm-charts/changelogs/CHANGELOG.<tipo>/
   ```
   (ex.: `.../CHANGELOG.api/`). E onde a Vela roda dentro da plataforma e tem acesso direto; tambem e o link clicavel ideal para devolver ao usuario.
2. **GitHub MCP** (quando configurado) — buscar o arquivo `.docs/changelogs/CHANGELOG.<tipo>.md` em `stone-payments/platform-k8s-charts`.
3. **`gh` CLI** (read-only, livre — nao precisa confirmacao):
   ```bash
   gh api repos/stone-payments/platform-k8s-charts/contents/.docs/changelogs/CHANGELOG.api.md \
     --jq '.content' | base64 -d
   ```
   Trocar `CHANGELOG.api.md` pelo tipo desejado.
4. **Repositorio clonado localmente** (se o usuario tiver) — `Read`/`Grep` em `platform-k8s-charts/.docs/changelogs/`.

`WebFetch` em `raw.githubusercontent.com` NAO funciona (repo privado, retorna 404) — use o TechDocs do Portal ou GitHub MCP/`gh`.

### Como fazer o diff entre duas versoes

Objetivo: listar tudo que entrou **de `vORIGEM` (exclusiva) ate `vDESTINO` (inclusiva)**.

1. **Identifique o tipo de chart.** Se o usuario nao disser, descubra pelo `Chart.yaml` da app (campo `dependencies[].name`, ex: `platform-k8s-api-chart` → API) ou pergunte.
2. **Descubra a versao de origem**, se nao informada:
   - `Chart.yaml` da aplicacao: `dependencies[].version`.
   - Ou `kli describe app <nome> -r -o json` (read-only) e leia a versao do chart em uso.
3. **Descubra a versao de destino**: se o usuario pedir "ate a mais recente", use a primeira entrada `## X.Y.Z` do topo do changelog.
4. **Selecione o intervalo**: percorra as entradas `## X.Y.Z` e fique com todas as versoes `V` tais que `ORIGEM < V <= DESTINO` (comparacao **SemVer**, nao lexicografica — `1.38.10` > `1.38.9`). A versao de origem em si NAO entra (o usuario ja a tem); a de destino entra.
5. **Agregue** (quando o salto e maior que uma versao): junte as descricoes de todas as versoes do intervalo. Agrupe por tema para nao virar uma lista crua versao-a-versao. Sugestao de agrupamento:
   - **Novas funcionalidades / chaves novas no `values.yaml`**
   - **Correcoes (fixes)**
   - **Mudancas de comportamento / breaking changes** (destaque com ⚠️ se alterar default ou exigir acao)
   - **Manutencao interna** (bumps de dependencia, testes — mencionar resumido, sem inflar)
6. **Consolide chaves do `values.yaml`**: liste todas as chaves novas/alteradas acumuladas no intervalo, em um unico bloco, indicando em que versao cada uma entrou.

### Regras de comparacao SemVer

- Compare numericamente por `MAJOR.MINOR.PATCH`. Ex.: `1.38.2` < `1.38.10` < `1.39.0`.
- Quando o usuario informar versao parcial (ex.: "v1.36" sem patch), trate como a primeira versao daquela serie (`1.36.0`) salvo se ele especificar o patch.
- Alerte se a versao de origem ou destino informada NAO existir no changelog (pode ser typo, versao yanked, ou tipo de chart errado) — liste as versoes proximas encontradas.
- Se origem e destino forem iguais, informe que nao ha diff.

### Saida recomendada para o usuario

- Comece com um **resumo executivo** (1-3 frases): quantas versoes no intervalo e o destaque principal.
- Liste por **tema** (nao versao-a-versao crua), com a versao de cada item entre parenteses, ex.: "Injecao do pod IP via env var (v1.38.11)".
- Bloco consolidado de **chaves novas do `values.yaml`** quando houver.
- Destaque ⚠️ **breaking changes / mudancas de default** que exigem atencao no bump.
- Feche com link(s) de **Fonte**: o(s) PR(s) relevante(s) e/ou o changelog no GitHub/Portal.

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. As acoes naturais aqui sao read-only (livres): ler changelog via `gh api`/MCP, ler `Chart.yaml`, rodar `kli describe app`. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Ler changelogs** via GitHub MCP ou `gh api` (read-only, sem confirmacao).
- **Ler `Chart.yaml`** da app do usuario para descobrir tipo e versao atual do chart.
- **Rodar KLI read** — `kli describe app <nome> -r -o json` para confirmar a versao em uso.
- **Propor o bump** apos o diff: oferecer editar `Chart.yaml` (`dependencies[].version`) para a versao de destino — `🛠️ Acao proposta`, com `ok` antes de escrever. O bump em si e dominio de `charts-config`/`deploy-rollback`; componha com elas se o usuario aceitar.

### Triggers proativos
- Usuario reporta chart numa versao antiga ao pedir um diff → ja calcule "ate a mais recente" e ofereca o bump.
- Apos mostrar o diff, se houver chaves novas relevantes ao cenario do usuario, sinalize com `💡 Sugestao` para configura-las (encaminhe para `charts-config`).

## Instrucoes MCP

Quando precisar de informacao alem do conhecimento embutido, leia o changelog. A fonte da verdade e o changelog renderizado no Portal Karavela (TechDocs); o repositorio `stone-payments/platform-k8s-charts` e o backend desse conteudo — NAO esta em `stone-payments/karavela` `docs/`.

**Fonte primaria (changelogs):**

| Fonte | Caminho | Quando buscar |
|-------|---------|---------------|
| Portal Karavela (Backstage TechDocs) | `/docs/stone/component/helm-charts/changelogs/CHANGELOG.<tipo>/` | Diff/agregacao de versoes — fonte primaria e link clicavel para o usuario |
| `stone-payments/platform-k8s-charts` (GitHub MCP / `gh`) | `.docs/changelogs/CHANGELOG.<tipo>.md` | Mesmo conteudo via GitHub quando o TechDocs nao estiver acessivel |

**Fontes complementares:**

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/karavela` | `docs/politica_charts.md` | Politica de versionamento (SemVer) e ciclo de vida — para contextualizar saltos de versao |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/charts.md` | Mapeamento tipo de chart ↔ nome (`platform-k8s-<tipo>-chart`) |
| `stone-payments/platform-k8s-charts` | `platform-k8s-<tipo>-chart/values.yaml` | Confirmar schema/uso de uma chave nova citada no changelog |

## Formato de Resposta

Ao responder perguntas deste dominio, siga este formato:

1. **Resumo executivo** (1-3 frases: quantas versoes no intervalo, destaque principal)
2. **Mudancas por tema** (funcionalidades, correcoes, breaking changes, manutencao — com a versao de cada item entre parenteses)
3. **Chaves novas/alteradas do `values.yaml`** (bloco consolidado, indicando a versao de entrada — quando houver)
4. **Fonte** (link clicavel para o changelog no Portal: `https://karavela-core-backstage.stone.tech/docs/stone/component/helm-charts/changelogs/CHANGELOG.<tipo>/`, e/ou o PR especifico citado na entrada)
5. **Avisos** (se aplicavel: ⚠️ breaking changes, mudanca de default, acao necessaria no bump)

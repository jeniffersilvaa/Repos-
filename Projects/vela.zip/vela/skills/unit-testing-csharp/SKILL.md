---
name: unit-testing-csharp
description: 'Boas práticas de teste unitário para C# (.NET). Use quando precisar criar ou revisar testes unitários em C#, usar mocks, stubs, spies com Moq ou NSubstitute, banco em memória com EF Core InMemory, validar interações com doubles de teste, ou escrever testes resistentes a mutation testing com Stryker.NET e xUnit ou NUnit.'
---

# Testes Unitários — C# (.NET)

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.

  Exemplos de uso:
  - Corrigir informacao desatualizada no conhecimento embutido
  - Adicionar restricao temporaria (ex: "versao X do Moq nao suporta feature Y")
  - Adicionar conhecimento que ainda nao esta na documentacao oficial
  - Bloquear uma orientacao especifica (ex: "NAO use EF Core InMemory neste projeto, use SQLite")
-->

## Escopo

**Cobre**: criar testes unitários em C#/.NET com xUnit, mocks e stubs com Moq ou NSubstitute, FluentAssertions, repositórios InMemory, banco EF Core InMemory, padrões resistentes a mutation testing (Stryker.NET), doubles de teste (mocks, stubs, spies, fakes)

**NAO cobre**: escrita de código de produção, configuração de pipeline de CI/coverage (coberto por `ci-test-coverage-dotnet`), testes de integração com banco real, configuração de mutation testing no CI (coberto por `ci-mutation-testing-csharp`)

## Exemplos de Perguntas

- "Como criar um mock com Moq para uma interface de repositório em C#?"
- "Como usar Verify() do Moq para verificar que um método foi chamado exatamente uma vez?"
- "Como configurar um banco EF Core InMemory para testes de repositório em C#?"
- "Como estruturar um repositório InMemory com Dictionary para testes unitários?"
- "Como escrever testes xUnit que sobrevivam ao mutation testing com Stryker.NET?"
- "Qual a diferença entre mock, stub, spy e fake em C# com Moq?"
- "Como usar FluentAssertions para assertivas mais expressivas em testes C#?"

## Conhecimento Embutido

### Quando Usar
- Criar testes unitários em projetos C# / .NET
- Usar doubles de teste: mocks, stubs, spies com Moq ou NSubstitute
- Configurar banco em memória com EF Core InMemory ou repositórios fake
- Garantir que os testes sobrevivam a testes de mutação (Stryker.NET)

### Ferramentas e Dependências

> **Nota:** As versões abaixo são referência. Verifique as versões mais recentes antes de adotar no seu projeto.

```xml
<!-- .csproj -->
<PackageReference Include="Microsoft.NET.Test.Sdk" Version="17.9.0" />
<PackageReference Include="xunit" Version="2.7.0" />
<PackageReference Include="xunit.runner.visualstudio" Version="2.5.7" />
<PackageReference Include="Moq" Version="4.20.70" />
<PackageReference Include="FluentAssertions" Version="6.12.0" />
<PackageReference Include="Microsoft.EntityFrameworkCore.InMemory" Version="8.0.0" />
```

### Workflow de Criação de Testes

### 1. Identificar Dependências
- Liste todas as interfaces injetadas via construtor
- Classifique: stub (retorna dados controlados), mock (verifica chamada), spy (envolve real)

### 2. Montar os Doubles

```csharp
using Moq;

// Stub: controla retorno, sem verificação de chamada
var userRepositoryMock = new Mock<IUserRepository>();
userRepositoryMock
    .Setup(r => r.FindByIdAsync(It.IsAny<string>()))
    .ReturnsAsync(new User { Id = "1", Name = "Ana" });

// Mock: verificará interações após o Act
var emailSenderMock = new Mock<IEmailSender>();
emailSenderMock
    .Setup(s => s.SendAsync(It.IsAny<Email>()))
    .Returns(Task.CompletedTask);
```

### 3. Estrutura AAA (Arrange / Act / Assert)

```csharp
[Fact]
public async Task Should_SendEmail_When_UserIsActivated()
{
    // Arrange
    const string userId = "user-123";
    var userRepoMock = new Mock<IUserRepository>();
    userRepoMock
        .Setup(r => r.FindByIdAsync(userId))
        .ReturnsAsync(new User { Id = userId, Name = "Ana", Active = false });
    userRepoMock
        .Setup(r => r.SaveAsync(It.IsAny<User>()))
        .Returns(Task.CompletedTask);

    var emailSenderMock = new Mock<IEmailSender>();
    emailSenderMock
        .Setup(s => s.SendAsync(It.IsAny<Email>()))
        .Returns(Task.CompletedTask);

    var useCase = new ActivateUserUseCase(userRepoMock.Object, emailSenderMock.Object);

    // Act
    await useCase.ExecuteAsync(userId);

    // Assert
    emailSenderMock.Verify(
        s => s.SendAsync(It.Is<Email>(e => e.To == "Ana")),
        Times.Once);

    userRepoMock.Verify(
        r => r.SaveAsync(It.Is<User>(u => u.Active == true)),
        Times.Once);
}
```

### 4. Validação de Spies (Verify)

```csharp
// Verificar quantidade exata (crítico para mutation testing)
emailSenderMock.Verify(s => s.SendAsync(It.IsAny<Email>()), Times.Once());
emailSenderMock.Verify(s => s.SendBulkAsync(It.IsAny<IEnumerable<Email>>()), Times.Never());

// Verificar argumentos com It.Is<T>
emailSenderMock.Verify(
    s => s.SendAsync(It.Is<Email>(e =>
        e.To == "ana@email.com" &&
        e.Subject == "Boas-vindas"
    )),
    Times.Once());

// Capturar argumento com Callback
User? capturedUser = null;
userRepoMock
    .Setup(r => r.SaveAsync(It.IsAny<User>()))
    .Callback<User>(u => capturedUser = u)
    .Returns(Task.CompletedTask);

await useCase.ExecuteAsync(userId);

capturedUser.Should().NotBeNull();
capturedUser!.Active.Should().BeTrue();
capturedUser.Name.Should().Be("Ana");
```

### 5. Banco em Memória

```csharp
// Fake Repository (preferível para testes unitários puros)
public class InMemoryUserRepository : IUserRepository
{
    private readonly Dictionary<string, User> _store = new();

    public Task<User?> FindByIdAsync(string id)
        => Task.FromResult(_store.GetValueOrDefault(id));

    public Task SaveAsync(User user)
    {
        _store[user.Id] = user;
        return Task.CompletedTask;
    }

    public Task<List<User>> FindAllAsync()
        => Task.FromResult(_store.Values.ToList());

    public Task<bool> DeleteAsync(string id)
    {
        var removed = _store.Remove(id);
        return Task.FromResult(removed);
    }
}

// EF Core InMemory (para testes de repositório com banco)
public class OrderRepositoryTests
{
    private AppDbContext CreateContext()
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString()) // GUID garante isolamento
            .Options;
        return new AppDbContext(options);
    }

    [Fact]
    public async Task Should_PersistOrder_WithPendingStatus()
    {
        await using var context = CreateContext();
        var repo = new OrderRepository(context);
        var order = new Order { Id = "ord-1", UserId = "user-1", Total = 150.0m };

        await repo.SaveAsync(order);

        var saved = await context.Orders.FindAsync("ord-1");
        saved.Should().NotBeNull();
        saved!.Status.Should().Be(OrderStatus.Pending);
        saved.Total.Should().Be(150.0m);
    }
}
```

### 6. Regras para Mutation Testing

Consulte [mutation-friendly.md](./references/mutation-friendly.md).

### Padrões de Nome de Teste

```
Should_<Resultado>_When_<Condição>
<Método>_<Cenário>_<Resultado>
```

Exemplos:
```csharp
[Fact] public async Task Should_ThrowNotFoundException_When_UserDoesNotExist() {}
[Fact] public async Task Should_ReturnEmpty_When_NoOrdersExist() {}
[Fact] public async Task Execute_WithValidUser_SendsWelcomeEmail() {}
```

### Anti-patterns

- `Assert.NotNull(result)` sem assertivas no conteúdo
- `mock.Verify(...)` sem `Times.Once()` ou `Times.Exactly(n)`
- `It.IsAny<T>()` em Verify quando os argumentos importam
- `[InlineData]` sem assertivas específicas para cada caso

### Referências

- [Doubles de Teste (mocks, stubs, spies)](./references/doubles.md)
- [Padrões Resistentes a Mutation Testing](./references/mutation-friendly.md)

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Escrever arquivos de teste** xUnit/NUnit com Moq ou NSubstitute
- **Editar testes existentes** — `new Mock<T>()`, `.Setup().Returns()`, `.Verify()` — FluentAssertions para assertions resistentes a Stryker.NET
- **Adicionar fakes** (EF Core InMemory)
- **Editar `.csproj` de teste** — pacotes xunit, Moq, FluentAssertions, EF Core InMemory
- **Abrir PR draft**

### Triggers proativos
- "Escreva testes C# para X" → propor suite com xUnit + Moq
- "Stryker matou meu teste" → propor assertions mais especificas

### Acoes destrutivas
- Deletar testes — confirmar.

## Instrucoes MCP

Quando o usuario precisar de informacoes detalhadas alem do
conhecimento embutido, busque nos seguintes repositorios (nesta ordem de prioridade):

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/karavela` | `docs/` | Padroes da plataforma (nao cobre unit testing diretamente) |
| `stone-payments/github-actions-workflows` | `**/test-coverage-dotnet*` | Configuracao de cobertura e relatorios de CI para .NET |
| Externo (complemento — nao em docs/) | [xUnit docs](https://xunit.net/), [Moq docs](https://github.com/devlooped/moq/wiki), [FluentAssertions docs](https://fluentassertions.com/) | API de mocks/spies, assertions, configuracao avancada |

> Todo o conhecimento desta skill e **complemento** ao docs/ da plataforma — ela nao tem secao dedicada a unit testing.

## Formato de Resposta

Ao responder perguntas deste dominio, siga este formato:

1. **Explicacao** (2-3 frases objetivas em PT-BR)
2. **Exemplo pratico** (código C# copiável com comentários AAA e atributos xUnit)
3. **Fonte** (referencia ao arquivo/secao da documentacao ou referencia desta skill)
4. **Avisos** (se aplicavel: versao do .NET, compatibilidade Moq vs NSubstitute, configuracao do .csproj)

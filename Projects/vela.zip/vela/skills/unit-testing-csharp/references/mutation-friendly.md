# Padrões Resistentes a Mutation Testing — C# com Stryker.NET

## Por que Mutation Testing Importa

O Stryker.NET injeta mutações (ex: `>` → `>=`, `true` → `false`, `+` → `-`, `return x` → `return default`) e verifica se algum teste falha. Testes fracos (que não verificam valores exatos) deixam mutantes sobreviver — e o MSI (Mutation Score Indicator) cai.

## Regras Fundamentais

### 1. Assertivas Exatas com FluentAssertions

```csharp
// ❌ Mata poucos mutantes
Assert.NotNull(result);
Assert.True(result.IsSuccess);

// ✅ Mata mutantes de valor e lógica
result.Status.Should().Be(OrderStatus.Approved);
result.Items.Should().HaveCount(3);
result.Total.Should().Be(150.0m);
result.IsActive.Should().BeTrue(); // não apenas .Should().NotBeNull()
```

### 2. Verify com Times Exato

```csharp
// ❌ Passa mesmo se chamado 2x ou 0x (Moq default é Times.AtLeastOnce)
emailSenderMock.Verify(s => s.SendAsync(It.IsAny<Email>()));

// ✅ Mata mutantes de fluxo de controle
emailSenderMock.Verify(s => s.SendAsync(It.IsAny<Email>()), Times.Once());
auditLogMock.Verify(l => l.LogFailure(It.IsAny<string>()), Times.Never());
```

### 3. Testar Todos os Branches

```csharp
// ❌ Só caminho feliz — mutante no if sobrevive
[Fact]
public async Task Should_ActivateUser()
{
    var result = await _useCase.ExecuteAsync(validUserId);
    result.Active.Should().BeTrue();
}

// ✅ Um teste por branch
[Fact]
public async Task Should_ActivateUser_When_UserExists()
{
    var result = await _useCase.ExecuteAsync(validUserId);
    result.Active.Should().BeTrue();
    _userRepoMock.Verify(r => r.SaveAsync(It.Is<User>(u => u.Active)), Times.Once());
}

[Fact]
public async Task Should_Throw_When_UserNotFound()
{
    _userRepoMock.Setup(r => r.FindByIdAsync(It.IsAny<string>())).ReturnsAsync((User?)null);

    var act = async () => await _useCase.ExecuteAsync("ghost-id");

    await act.Should().ThrowAsync<UserNotFoundException>()
        .WithMessage("*ghost-id*");

    _userRepoMock.Verify(r => r.SaveAsync(It.IsAny<User>()), Times.Never());
}
```

### 4. Assertivas em Todos os Campos Relevantes

```csharp
// ❌ Verifica apenas parte do objeto
var order = await _service.CreateAsync(request);
order.Id.Should().Be("ord-1");

// ✅ Verifica todos os campos afetados pela lógica de negócio
var order = await _service.CreateAsync(request);
order.Id.Should().Be("ord-1");
order.Status.Should().Be(OrderStatus.Pending);
order.UserId.Should().Be(request.UserId);
order.Total.Should().Be(request.Total);
order.CreatedAt.Should().BeCloseTo(DateTime.UtcNow, TimeSpan.FromSeconds(5));
```

### 5. Testar Limites (Boundary Testing)

```csharp
// Para `if (price > 100m)` — testar o limite exato
[Theory]
[InlineData(100.01, 10.0)]  // acima do limite → tem desconto
[InlineData(100.00, 10.0)]  // no limite → tem desconto (se >=)
[InlineData(99.99, 0.0)]    // abaixo → sem desconto
public void Should_CalculateDiscount_BasedOnPrice(decimal price, decimal expectedDiscount)
{
    var result = _service.CalculateDiscount(price);
    result.Should().Be(expectedDiscount); // assertiva exata
}
```

### 6. Validar Coleções com HaveCount + Conteúdo

```csharp
// ❌ Mutante `return new List<User>()` sobrevive
var result = await _service.FindAllAsync();
result.Should().NotBeEmpty();

// ✅
var result = await _service.FindAllAsync();
result.Should().HaveCount(2);
result.Should().Contain(u => u.Id == "1" && u.Name == "Ana");
result.Should().Contain(u => u.Id == "2" && u.Name == "Bruno");

// Caso vazio
var empty = await _service.FindAllAsync(); // sem dados
empty.Should().BeEmpty(); // não apenas `.Should().NotBeNull()`
```

### 7. Verificar Exceção com Mensagem

```csharp
// ❌ Só verifica tipo da exceção
await Assert.ThrowsAsync<ValidationException>(() => _service.CreateAsync(invalid));

// ✅ Verifica tipo + mensagem (mata mutantes na mensagem/campo)
var act = async () => await _service.CreateAsync(invalid);
await act.Should().ThrowAsync<ValidationException>()
    .WithMessage("*email*");
```

### 8. InlineData com Assertiva Específica por Caso

```csharp
// ❌ InlineData sem assertiva diferente por caso — todos passam mesmo com mutação
[Theory]
[InlineData("A", true)]
[InlineData("", false)]
public void Should_Validate(string input, bool expected)
{
    var result = _validator.IsValid(input);
    Assert.True(result == expected); // impreciso
}

// ✅
[Theory]
[InlineData("valid@email.com", true)]
[InlineData("", false)]
[InlineData("no-at-sign", false)]
public void Should_ValidateEmail(string email, bool expected)
{
    var result = _validator.IsValidEmail(email);
    result.Should().Be(expected, because: $"'{email}' should be {(expected ? "valid" : "invalid")}");
}
```

## Checklist Antes de Commitar

- [ ] Toda assertiva usa FluentAssertions com valor **exato** (`.Be(x)`, `.BeTrue()`, `.HaveCount(n)`)
- [ ] Todo `Verify` usa `Times.Once()`, `Times.Exactly(n)` ou `Times.Never()`
- [ ] Existe `[Fact]` para cada branch do código (`if/else/switch/try/catch`)
- [ ] Limites de condição testados com `[Theory][InlineData]` nos valores fronteiriços
- [ ] Listas verificam `HaveCount` E membros específicos
- [ ] Retorno `null` / `[]` / `false` tem teste específico
- [ ] Exceções verificadas com `.WithMessage("*keyword*")`
- [ ] `VerifyNoOtherCalls()` onde apropriado

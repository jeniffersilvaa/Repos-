# Doubles de Teste — C# com Moq

## Hierarquia de Double

| Double | Quando Usar | Moq |
|--------|-------------|-----|
| **Dummy** | Parâmetro sem importância para o teste | `new Mock<T>(MockBehavior.Loose).Object` |
| **Stub** | Controlar retorno da dependência | `mock.Setup(...).Returns(...)` |
| **Spy** | Envolver real e verificar chamadas | `mock.Setup(...).Callback(...)` |
| **Mock** | Verificar que interação ocorreu | `mock.Verify(...)` com `Times` |
| **Fake** | Implementação funcional simplificada | Classe manual |

## Stubs: Controlar Retornos

```csharp
var repo = new Mock<IUserRepository>();

// Retorno fixo
repo.Setup(r => r.FindByIdAsync("1"))
    .ReturnsAsync(new User { Id = "1", Name = "Ana" });

// Retorno null
repo.Setup(r => r.FindByIdAsync(It.IsAny<string>()))
    .ReturnsAsync((User?)null);

// Lança exceção
repo.Setup(r => r.FindByIdAsync("err"))
    .ThrowsAsync(new DatabaseException("connection error"));

// Retorno calculado
repo.Setup(r => r.FindByIdAsync(It.IsAny<string>()))
    .ReturnsAsync((string id) => new User { Id = id, Name = $"User-{id}" });

// Múltiplas chamadas com retornos diferentes
var queue = new Queue<User?>(new[] {
    new User { Id = "1", Name = "Ana" },
    new User { Id = "2", Name = "Bruno" },
    null
});
repo.Setup(r => r.FindByIdAsync(It.IsAny<string>()))
    .ReturnsAsync(() => queue.Dequeue());
```

## Mocks: Verificar Interações

```csharp
var emailSender = new Mock<IEmailSender>();
emailSender.Setup(s => s.SendAsync(It.IsAny<Email>())).Returns(Task.CompletedTask);

// ... executa código ...

// Chamou exatamente 1 vez
emailSender.Verify(s => s.SendAsync(It.IsAny<Email>()), Times.Once());

// Chamou N vezes exatas
emailSender.Verify(s => s.SendAsync(It.IsAny<Email>()), Times.Exactly(2));

// Nunca chamou
emailSender.Verify(s => s.SendBulkAsync(It.IsAny<IEnumerable<Email>>()), Times.Never());

// Argumentos específicos (crítico para mutation testing)
emailSender.Verify(
    s => s.SendAsync(It.Is<Email>(e =>
        e.To == "ana@email.com" &&
        e.Subject == "Boas-vindas" &&
        e.Body.Contains("Ana")
    )),
    Times.Once());

// Verificar NENHUMA outra chamada além das especificadas
emailSender.VerifyNoOtherCalls();
```

## Captura de Argumentos com Callback

```csharp
// Capturar argumento para assertivas detalhadas
User? capturedUser = null;
var userRepo = new Mock<IUserRepository>();
userRepo
    .Setup(r => r.SaveAsync(It.IsAny<User>()))
    .Callback<User>(u => capturedUser = u)
    .Returns(Task.CompletedTask);

await useCase.ExecuteAsync("user-1");

// Assertivas com FluentAssertions
capturedUser.Should().NotBeNull();
capturedUser!.Active.Should().BeTrue();
capturedUser.Name.Should().Be("Ana");

// Capturar múltiplas chamadas
var savedUsers = new List<User>();
userRepo
    .Setup(r => r.SaveAsync(It.IsAny<User>()))
    .Callback<User>(savedUsers.Add)
    .Returns(Task.CompletedTask);

await useCase.ExecuteAllAsync();

savedUsers.Should().HaveCount(2);
savedUsers[0].Name.Should().Be("Ana");
savedUsers[1].Name.Should().Be("Bruno");
```

## NSubstitute (alternativa ao Moq)

```csharp
using NSubstitute;

var repo = Substitute.For<IUserRepository>();
var emailSender = Substitute.For<IEmailSender>();

// Stub
repo.FindByIdAsync("1").Returns(new User { Id = "1", Name = "Ana" });

// Lança exceção
repo.FindByIdAsync("err").Throws(new DatabaseException());

// Verificar interações
await emailSender.Received(1).SendAsync(Arg.Any<Email>());
await emailSender.DidNotReceive().SendBulkAsync(Arg.Any<IEnumerable<Email>>());

// Verificar argumento
await emailSender.Received(1).SendAsync(Arg.Is<Email>(e => e.To == "ana@email.com"));
```

## Fake Repository (In-Memory)

```csharp
public class InMemoryProductRepository : IProductRepository
{
    public Dictionary<string, Product> Store { get; } = new();

    public Task<Product?> FindByIdAsync(string id)
        => Task.FromResult(Store.GetValueOrDefault(id));

    public Task<List<Product>> FindAllAsync()
        => Task.FromResult(Store.Values.ToList());

    public Task<Product> SaveAsync(Product product)
    {
        Store[product.Id] = product;
        return Task.FromResult(product);
    }

    public Task<bool> DeleteAsync(string id)
        => Task.FromResult(Store.Remove(id));
}

// Uso nos testes
public class ProductServiceTests
{
    private readonly InMemoryProductRepository _repo = new();

    [Fact]
    public async Task Should_ReturnProduct_When_Exists()
    {
        _repo.Store["prod-1"] = new Product { Id = "prod-1", Name = "Widget", Price = 29.99m };

        var result = await _productService.GetByIdAsync("prod-1");

        result.Should().NotBeNull();
        result!.Name.Should().Be("Widget");
        result.Price.Should().Be(29.99m);
    }
}
```

## EF Core InMemory

```csharp
public class OrderRepositoryTests : IDisposable
{
    private readonly AppDbContext _context;

    public OrderRepositoryTests()
    {
        var options = new DbContextOptionsBuilder<AppDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString()) // isolado por teste
            .Options;
        _context = new AppDbContext(options);
    }

    [Fact]
    public async Task Save_ShouldPersistWithDefaultStatus()
    {
        var repo = new OrderRepository(_context);
        var order = new Order { Id = "ord-1", Total = 100m };

        await repo.SaveAsync(order);

        var found = await _context.Orders.FindAsync("ord-1");
        found.Should().NotBeNull();
        found!.Status.Should().Be(OrderStatus.Pending);
        found.Total.Should().Be(100m);
    }

    public void Dispose() => _context.Dispose();
}
```

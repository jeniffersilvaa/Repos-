---
name: unit-testing-python
description: 'Boas práticas de teste unitário para Python. Use quando precisar criar ou revisar testes unitários em Python com pytest, usar mocks, stubs, spies com unittest.mock ou pytest-mock, banco em memória com SQLite ou fakes, validar interações com doubles de teste, ou escrever testes resistentes a mutation testing com cosmic-ray ou mutmut.'
---

# Testes Unitários — Python

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.

  Exemplos de uso:
  - Corrigir informacao desatualizada no conhecimento embutido
  - Adicionar restricao temporaria (ex: "versao X do pytest-mock nao suporta feature Y")
  - Adicionar conhecimento que ainda nao esta na documentacao oficial
  - Bloquear uma orientacao especifica (ex: "NAO use patch() como decorator neste projeto")
-->

## Escopo

**Cobre**: criar testes unitários em Python com pytest, mocks e stubs com `unittest.mock` e `pytest-mock`, spy com `mocker.spy`, repositórios InMemory, banco SQLite em memória, fixtures pytest, padrões resistentes a mutation testing (cosmic-ray, mutmut), doubles de teste (mocks, stubs, spies, fakes)

**NAO cobre**: escrita de código de produção, configuração de pipeline de CI/coverage (coberto por `ci-test-coverage-python`), testes de integração com serviços reais, configuração de mutation testing no CI (coberto por `ci-mutation-testing-python`)

## Exemplos de Perguntas

- "Como criar um mock com MagicMock para uma dependência em Python?"
- "Como usar mocker.spy() do pytest-mock para verificar que um método foi chamado?"
- "Como configurar um banco SQLite em memória para testes de repositório em Python?"
- "Como estruturar um repositório InMemory para testes unitários em Python?"
- "Como escrever testes com pytest que sobrevivam ao mutation testing com mutmut?"
- "Qual a diferença entre mock, stub, spy e fake? Quando usar cada um com pytest-mock?"
- "Como usar fixtures do pytest para compartilhar setup entre testes?"

## Conhecimento Embutido

### Quando Usar
- Criar testes unitários em projetos Python
- Usar doubles de teste: mocks, stubs, spies com `unittest.mock` / `pytest-mock`
- Configurar banco em memória com SQLite ou repositórios fake
- Garantir que os testes sobrevivam a testes de mutação

### Ferramentas e Dependências

> **Nota:** As versões abaixo são referência. Verifique as versões mais recentes antes de adotar no seu projeto.

```toml
# pyproject.toml
[tool.pytest.ini_options]
testpaths = ["tests"]

[project.optional-dependencies]
test = [
    "pytest>=8.0",
    "pytest-mock>=3.12",
    "pytest-cov>=4.1",
]
```

### Workflow de Criação de Testes

### 1. Identificar Dependências
- Liste todas as dependências (injeção via construtor ou parâmetro)
- Classifique: stub (retorna valor fixo), mock (verificar chamada), spy (envolve real)

### 2. Montar os Doubles

```python
from unittest.mock import MagicMock, patch, call

# Stub: controla o que retorna, não verifica chamadas
user_repository = MagicMock()
user_repository.find_by_id.return_value = {"id": "1", "name": "Ana"}

# Mock: verificará interações
email_sender = MagicMock()

# Spy com pytest-mock (mocker fixture)
def test_with_spy(mocker):
    spy = mocker.spy(real_service, "calculate")
    # ... executa ...
    spy.assert_called_once_with(expected_arg)
```

### 3. Estrutura AAA (Arrange / Act / Assert)

```python
def test_should_send_email_when_user_is_activated(mocker):
    # Arrange
    user_id = "user-123"
    mock_user_repo = MagicMock()
    mock_user_repo.find_by_id.return_value = {
        "id": user_id, "name": "Ana", "active": False
    }
    mock_user_repo.save.return_value = None

    mock_email_sender = MagicMock()

    use_case = ActivateUserUseCase(mock_user_repo, mock_email_sender)

    # Act
    use_case.execute(user_id)

    # Assert
    mock_email_sender.send.assert_called_once()
    call_args = mock_email_sender.send.call_args
    assert call_args.kwargs["to"] == "Ana"

    mock_user_repo.save.assert_called_once()
    saved_user = mock_user_repo.save.call_args[0][0]
    assert saved_user["active"] is True  # assertiva exata
```

### 4. Validação de Spies

```python
from unittest.mock import MagicMock, call

mock = MagicMock()
mock.process("a")
mock.process("b")

# Verificar quantidade exata (crítico para mutation testing)
assert mock.process.call_count == 2

# Verificar argumentos específicos
mock.process.assert_called_with("b")  # última chamada
mock.process.assert_any_call("a")

# Verificar todas as chamadas em ordem
mock.process.assert_has_calls([call("a"), call("b")])

# Verificar que NUNCA foi chamado
mock.delete.assert_not_called()
```

### 5. Banco em Memória

```python
# Fake Repository (preferível para testes unitários puros)
class InMemoryUserRepository:
    def __init__(self):
        self._store: dict[str, dict] = {}

    def save(self, user: dict) -> dict:
        self._store[user["id"]] = user
        return user

    def find_by_id(self, user_id: str) -> dict | None:
        return self._store.get(user_id)

    def find_all(self) -> list[dict]:
        return list(self._store.values())

    def delete(self, user_id: str) -> bool:
        if user_id in self._store:
            del self._store[user_id]
            return True
        return False

# SQLite em memória para testes de integração de repositório
import sqlite3

@pytest.fixture
def db_connection():
    conn = sqlite3.connect(":memory:")
    conn.execute("""
        CREATE TABLE users (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            active INTEGER DEFAULT 0
        )
    """)
    yield conn
    conn.close()
```

### 6. Fixture de Setup com pytest

```python
import pytest

@pytest.fixture
def user_repo():
    return InMemoryUserRepository()

@pytest.fixture
def email_sender():
    return MagicMock()

@pytest.fixture
def activate_use_case(user_repo, email_sender):
    return ActivateUserUseCase(user_repo, email_sender)

def test_activates_user(activate_use_case, user_repo, email_sender):
    user_repo.save({"id": "1", "name": "Ana", "active": False})

    activate_use_case.execute("1")

    saved = user_repo.find_by_id("1")
    assert saved["active"] is True  # bool exato
    email_sender.send.assert_called_once()
```

### 7. Regras para Mutation Testing

Consulte [mutation-friendly.md](./references/mutation-friendly.md).

### Padrões de Nome de Teste

```
test_should_<resultado>_when_<condição>
test_<método>_<cenário>_<resultado>
```

Exemplos:
```python
def test_should_raise_not_found_when_user_does_not_exist(): ...
def test_should_return_empty_list_when_repository_is_empty(): ...
def test_execute_with_valid_user_sends_email(): ...
```

### Anti-patterns

- `assert result is not None` sem assertivas no conteúdo
- `assert mock.called` sem verificar `call_count` ou argumentos
- `mock.return_value = True` para métodos que retornam objetos complexos
- Testar apenas o caminho feliz

### Referências

- [Doubles de Teste (mocks, stubs, spies)](./references/doubles.md)
- [Padrões Resistentes a Mutation Testing](./references/mutation-friendly.md)

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Escrever arquivos de teste** (`test_*.py`) com pytest seguindo padrao AAA
- **Editar testes existentes** com `MagicMock()`, `mocker.spy()`, `@patch` decorator — assertions especificas para sobreviver a cosmic-ray/mutmut
- **Adicionar fakes** (SQLite em memoria, fake repositories)
- **Editar `pyproject.toml`/`pytest.ini`** para coverage thresholds, markers
- **Adicionar `requirements-dev.txt`/`pyproject.toml`** com pytest, pytest-mock, pytest-cov
- **Abrir PR draft**

### Triggers proativos
- "Escreva testes Python para X" → propor suite completa
- "Como mockar essa biblioteca" → propor `@patch` ou `mocker`
- "cosmic-ray matou meu teste" → propor assertions mais especificas

### Acoes destrutivas
- Deletar testes — confirmar.

## Instrucoes MCP

Quando o usuario precisar de informacoes detalhadas alem do
conhecimento embutido, busque nos seguintes repositorios (nesta ordem de prioridade):

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/karavela` | `docs/` | Padroes da plataforma (nao cobre unit testing diretamente) |
| `stone-payments/github-actions-workflows` | `**/test-coverage-python*` | Configuracao de cobertura e relatorios de CI para Python |
| Externo (complemento — nao em docs/) | [pytest docs](https://docs.pytest.org/), [unittest.mock](https://docs.python.org/3/library/unittest.mock.html), [pytest-mock](https://pytest-mock.readthedocs.io/) | API de mocks/spies, fixtures, configuracao avancada |

> Todo o conhecimento desta skill e **complemento** ao docs/ da plataforma — ela nao tem secao dedicada a unit testing.

## Formato de Resposta

Ao responder perguntas deste dominio, siga este formato:

1. **Explicacao** (2-3 frases objetivas em PT-BR)
2. **Exemplo pratico** (código Python copiável com comentários AAA)
3. **Fonte** (referencia ao arquivo/secao da documentacao ou referencia desta skill)
4. **Avisos** (se aplicavel: diferencas entre unittest.mock e pytest-mock, versoes de pytest, configuracao de pyproject.toml)

# Padrões Resistentes a Mutation Testing — Python

## Por que Mutation Testing Importa

Ferramentas como `mutmut` e `cosmic-ray` injetam mutações (ex: `>` → `>=`, `True` → `False`, `+` → `-`, `return x` → `return None`) e verificam se algum teste falha. Testes fracos deixam mutantes sobreviver.

## Regras Fundamentais

### 1. Assertivas Exatas de Valor

```python
# ❌ Mata poucos mutantes
assert result
assert result is not None
assert len(result) > 0

# ✅ Mata mutantes de valor e lógica
assert result.status == "APPROVED"
assert len(result.items) == 3
assert result.total == 150.0
assert result.active is True  # usar is True/False para booleans
```

### 2. Verificar Quantidade Exata de Chamadas

```python
# ❌ Passa mesmo se chamado 2x ou 0x
mock.send.assert_called()

# ✅ Mata mutantes de fluxo de controle
assert mock.send.call_count == 1
assert mock.log_failure.call_count == 0
```

### 3. Testar Todos os Branches

```python
# ❌ Só o caminho feliz — mutante no if sobrevive
def test_activate_user():
    result = use_case.execute(valid_user_id)
    assert result["active"] is True

# ✅ Teste para cada branch
def test_activate_user_when_valid():
    result = use_case.execute(valid_user_id)
    assert result["active"] is True
    assert mock_repo.save.call_count == 1

def test_raise_not_found_when_user_missing():
    mock_repo.find_by_id.return_value = None
    with pytest.raises(UserNotFoundException) as exc_info:
        use_case.execute("ghost-id")
    assert "ghost-id" in str(exc_info.value)
    mock_repo.save.assert_not_called()
```

### 4. Assertivas em Todos os Campos Relevantes

```python
# ❌ Verifica apenas parte do objeto
order = service.create(request)
assert order["id"] == "ord-1"

# ✅ Verifica todos os campos afetados pela lógica
order = service.create(request)
assert order["id"] == "ord-1"
assert order["status"] == "PENDING"
assert order["user_id"] == request["user_id"]
assert order["total"] == request["total"]
assert "created_at" in order
```

### 5. Testar Limites (Boundary Testing)

```python
# Para `if price > 100.0` — testar o limite exato
def test_apply_discount_when_price_is_exactly_100():
    result = service.calculate_discount(100.0)
    assert result == 10.0  # tem desconto

def test_no_discount_when_price_is_99_99():
    result = service.calculate_discount(99.99)
    assert result == 0.0  # sem desconto
```

### 6. Validar Retorno Vazio / None / False

```python
# ❌ Mutante `return []` sobreviveria
def test_find_users():
    repo.save(User(id="1", name="Ana"))
    result = service.find_all()
    assert result is not None

# ✅
def test_find_all_returns_all_users():
    repo.save(User(id="1", name="Ana"))
    repo.save(User(id="2", name="Bruno"))

    result = service.find_all()

    assert len(result) == 2
    ids = {u.id for u in result}
    assert "1" in ids
    assert "2" in ids

def test_find_all_returns_empty_when_no_users():
    result = service.find_all()
    assert result == []  # não apenas `assert not result`
```

### 7. Usar `is True` / `is False` para Booleans

```python
# ❌ `assert result` passa para qualquer truthy (1, "str", [1])
assert result.active
assert not result.blocked

# ✅
assert result.active is True
assert result.blocked is False
```

### 8. Verificar Conteúdo de Exceção

```python
# ❌ Só verifica que lança exceção — mutante na mensagem sobrevive
with pytest.raises(ValueError):
    service.create(invalid_input)

# ✅
with pytest.raises(ValueError) as exc_info:
    service.create(invalid_input)
assert "email" in str(exc_info.value).lower()
```

### 9. Assertivas em Argumentos Capturados

```python
# ❌ Verifica apenas que foi chamado
mock_mailer.send.assert_called_once()

# ✅ Verifica os argumentos (mata mutantes de dados)
mock_mailer.send.assert_called_once()
call_args = mock_mailer.send.call_args
assert call_args.kwargs["to"] == "ana@email.com"
assert call_args.kwargs["subject"] == "Conta ativada"
assert "Ana" in call_args.kwargs["body"]
```

## Checklist Antes de Commitar

- [ ] Toda assertiva usa valor **exato** (`== x`, `is True`, `is False`)
- [ ] `call_count` verificado com número exato em todos os mocks relevantes
- [ ] Existe teste para cada `if/elif/else/try/except` branch
- [ ] Limites de condições têm testes nos valores fronteiriços
- [ ] Listas verificam `len()` E membros específicos
- [ ] Retorno `None` / `[]` / `False` tem teste específico
- [ ] Conteúdo de exceção verificado com `exc_info.value`

# Doubles de Teste — Python com unittest.mock e pytest-mock

## Hierarquia de Double

| Double | Quando Usar | Python |
|--------|-------------|--------|
| **Dummy** | Parâmetro obrigatório sem importância | `MagicMock()` |
| **Stub** | Controlar retorno da dependência | `mock.method.return_value = ...` |
| **Spy** | Envolver real e verificar chamadas | `mocker.spy(obj, 'method')` |
| **Mock** | Verificar que interação ocorreu | `MagicMock()` + `assert_called_*` |
| **Fake** | Implementação funcional (InMemory) | Classe manual |

## Stubs: Controlar Retornos

```python
from unittest.mock import MagicMock

repo = MagicMock()

# Retorno fixo
repo.find_by_id.return_value = {"id": "1", "name": "Ana"}

# Retorno None
repo.find_by_id.return_value = None

# Lança exceção
repo.find_by_id.side_effect = DatabaseError("connection refused")

# Retornos em sequência
repo.find_all.side_effect = [
    [{"id": "1"}],
    [{"id": "1"}, {"id": "2"}],
    []
]

# Lógica dinâmica
def dynamic_find(user_id):
    return {"id": user_id, "name": f"User-{user_id}"}

repo.find_by_id.side_effect = dynamic_find
```

## Mocks: Verificar Interações

```python
email_sender = MagicMock()

# ... executa código ...

# Chamou exatamente 1 vez
email_sender.send.assert_called_once()

# Chamou com argumentos específicos
email_sender.send.assert_called_once_with(to="ana@email.com", subject="Boas-vindas")

# Quantidade exata (crítico para mutation testing)
assert email_sender.send.call_count == 1
assert email_sender.log.call_count == 0  # nunca deve ser chamado

# Nunca chamado
email_sender.send_bulk.assert_not_called()

# Todas as chamadas em ordem
from unittest.mock import call
mock_logger.log.assert_has_calls([
    call("user.created", user_id="1"),
    call("email.sent", to="ana@email.com"),
])
```

## Spies com pytest-mock

```python
# mocker vem do pytest-mock (fixture automática)
def test_calculator_discount(mocker):
    calculator = PriceCalculator()
    spy = mocker.spy(calculator, "apply_discount")

    result = calculator.apply_discount(100.0, 10.0)

    # Valida o retorno real
    assert result == 90.0

    # Valida que foi chamado com os args certos
    spy.assert_called_once_with(100.0, 10.0)

# Spy com patch para funções de módulo
def test_sends_email(mocker):
    mock_send = mocker.patch("myapp.email.send_email")

    service.notify_user("user-1")

    mock_send.assert_called_once()
    assert mock_send.call_args[1]["subject"] == "Notificação"
```

## Captura de Argumentos

```python
from unittest.mock import MagicMock, call

email_sender = MagicMock()

# ... executa ...

# Capturar e inspecionar argumentos
call_args = email_sender.send.call_args
assert call_args.args[0] == "destinatario@email.com"  # posicional
assert call_args.kwargs["subject"] == "Boas-vindas"    # nomeado

# Para múltiplas chamadas
all_calls = email_sender.send.call_args_list
assert len(all_calls) == 2
assert all_calls[0].kwargs["to"] == "ana@email.com"
assert all_calls[1].kwargs["to"] == "bruno@email.com"
```

## Fake Repository (In-Memory)

```python
from dataclasses import dataclass, field
from typing import Optional

@dataclass
class User:
    id: str
    name: str
    active: bool = False

class InMemoryUserRepository:
    def __init__(self):
        self._store: dict[str, User] = {}

    def save(self, user: User) -> User:
        self._store[user.id] = user
        return user

    def find_by_id(self, user_id: str) -> Optional[User]:
        return self._store.get(user_id)

    def find_all(self) -> list[User]:
        return list(self._store.values())

    def delete(self, user_id: str) -> bool:
        return self._store.pop(user_id, None) is not None

    def find_by_name(self, name: str) -> list[User]:
        return [u for u in self._store.values() if u.name == name]

# Uso direto nos testes
def test_should_save_and_retrieve():
    repo = InMemoryUserRepository()
    user = User(id="1", name="Ana")

    saved = repo.save(user)

    assert saved.id == "1"
    found = repo.find_by_id("1")
    assert found is not None
    assert found.name == "Ana"
    assert found.active is False
```

## SQLite em Memória para Repositórios

```python
import sqlite3
import pytest

@pytest.fixture
def db():
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript("""
        CREATE TABLE orders (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            total REAL NOT NULL,
            status TEXT DEFAULT 'PENDING'
        );
    """)
    yield conn
    conn.close()

def test_order_repository_save(db):
    repo = SqliteOrderRepository(db)
    order = Order(id="ord-1", user_id="user-1", total=150.0)

    result = repo.save(order)

    assert result.id == "ord-1"
    assert result.status == "PENDING"
    assert result.total == 150.0
```

## Patch de Contexto (with statement)

```python
from unittest.mock import patch

def test_with_context_manager():
    with patch("myapp.services.send_email") as mock_email:
        mock_email.return_value = True

        result = user_service.activate("user-1")

        assert result.active is True
        mock_email.assert_called_once()
        assert mock_email.call_args.kwargs["to"] == "user-1@email.com"
```

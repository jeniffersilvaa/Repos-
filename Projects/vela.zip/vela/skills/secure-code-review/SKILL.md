---
name: secure-code-review
description: "Code review de seguranca local. Dois modos: scan de diff (antes de abrir PR, antecipa o que o agent security-review vai apontar) e scan full do code base (sob solicitacao explicita, heranca de projeto, pre-release). Use tambem para interpretar e contestar findings SR-XXX ja emitidos. Todas as regras de scan, categorias e severidades estão em agents/security-review/AGENT.md (fonte unica)."
---

# Skill: Secure Code Review

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.

  Nota: regras de scan (categorias, severidades, contract de finding) NAO vivem aqui.
  Vivem em agents/security-review/AGENT.md — fonte unica.
-->

## Escopo

**Cobre**:
- Scan de diff (modo default), aplicar o checklist do `AGENT.md` sobre `git diff <base>...HEAD` antes de abrir PR (antecipa o que o agent vai apontar)
- Scan full do code base (sob solicitacao explicita), aplica o checklist do `AGENT.md` sobre todo o repo, usar para auditoria periodica, heranca de projeto ou antes de release sensivel
- Orquestracao: como ler o `AGENT.md` e aplicar suas instrucoes localmente
- Interpretacao e resposta a findings `SR-XXX` emitidos pelo agent no PR

**NAO cobre**:
- Regras de scan (categorias, severidades, output contract) — vivem em `agents/security-review/AGENT.md`
- Seguranca de plataforma (Kyverno, KubeArmor, Cilium, break glass) — coberto pela skill `seguranca`
- Secrets / Vault — coberto pela skill `secrets-vault`
- Rede / firewall — coberto pela skill `networking-ingress`

## Fonte unica: `agents/security-review/AGENT.md`

Todas as instrucoes de scan (o que procurar, severidades, formato do finding, protocolo de PR) vivem em **um unico arquivo**:

[agents/security-review/AGENT.md](../../agents/security-review/AGENT.md)

Esta skill **nao duplica** esse conteudo. Quando o engenheiro pedir scan local, interpretacao de finding, ou guidance sobre code review de seguranca:

1. **Leia** `agents/security-review/AGENT.md` via Read tool
2. **Aplique** o checklist e regras de la sobre o codigo / diff / PR do usuario
3. **Responda** ao usuario seguindo o Formato de Resposta abaixo

Se o `AGENT.md` mudar (categorias novas, severidades ajustadas, protocolo atualizado), essa skill **automaticamente** reflete a mudanca, porque le sempre da fonte.

## Exemplos de Perguntas

**Scan de diff (antes de abrir PR)**
- "Revise minhas modificacoes antes de eu abrir o PR"
- "Tem alguma vulnerabilidade no meu diff?"
- "Posso abrir esse PR ou o agent vai bloquear por seguranca?"
- "Rode o checklist de seguranca nas minhas mudancas"

**Scan full do code base (sob solicitacao)**
- "Faça um scan de seguranca no repo todo"
- "Acabei de herdar esse projeto, faça um scan de seguranca no code base inteiro"
- "Scan full de seguranca"

**Interpretar findings do agent**
- "O agent apontou esse finding no meu PR, o que significa?"
- "Por que isso virou HIGH e nao MEDIUM?"
- "Esse achado e blocking? Preciso resolver antes do merge?"

**Contestar findings**
- "Acho que esse finding e falso positivo, como respondo?"
- "Esse trecho é intencional, se trata de um mock"
- "Como justifico um wontfix sem o agent re-flagrar depois?"

**Verificacao pontual no codigo**
- "Esse `os/exec.Command(input)` e command injection?"
- "Tem secret hardcoded nesse arquivo?"
- "Esse handler permite authz bypass?"

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever; producao exige dupla confirmacao. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer

- **Ler `AGENT.md`** e aplicar suas regras sobre o diff ou code base do usuario
- **Rodar comandos read-only** (`git diff`, `git ls-files`, leitura de arquivos) para obter o input do scan
- **Sugerir correcoes** como patch/snippet no chat antes de qualquer edicao
- **Editar codigo** apos confirmacao explicita do usuario (producao exige dupla confirmacao)
- **Redigir reply em pt-BR** para o usuario colar em thread de PR, a skill nao posta direto
- **NAO** sinalizar PR como "pronto pra abrir" enquanto houver achados `CRITICAL` ou `HIGH` nao resolvidos
- **NAO** desabilitar o agent, bypassar findings blocking ou sugerir ignorar regras de seguranca
- **NAO** resolver threads de PR em nome do dev, apenas instruir o protocolo do `AGENT.md`

### Triggers proativos

- Dev mostra diff/PR → ler `AGENT.md`, aplicar checklist, listar achados
- Dev cola finding `SR-XXX` → ler `AGENT.md`, interpretar contexto, propor correcao OU rascunhar reply

## Instrucoes MCP

Quando estiver com duvida, use **GitHub MCP** para consultar:

- `agents/security-review/AGENT.md` no repo `stone-payments/vela`, fonte canonica
- PRs do usuario para inspecionar findings reais e threads
- Codigo da aplicacao para validar contexto

Priorize sempre o `AGENT.md` no proprio repo desta skill (mesmo monorepo).

## Formato de Resposta

1. **Regra aplicada** (citar trecho/linha do `AGENT.md` que motiva o achado)
2. **Diagnostico** (o que esta errado no codigo OU o que o finding aponta)
3. **Correcao sugerida** (snippet ou texto de reply, em pt-BR)
4. **Severidade e blocking** (conforme regras do `AGENT.md`)
5. **Avisos** (contexto / restricoes, se aplicavel)

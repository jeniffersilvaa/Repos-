---
name: karavela-packages
description: "Conceitos, consumo e referencia geral do Karavela Packages (Nexus packages.stone.tech). Use para: ciclo de vida (PENDING/CONFIRMED/PUBLISH_FAILED), normalizacao de nome canonico, SBOM/Grype/SLSA 3, setup-consumer, request-consumer-token, USE_KARAVELA_PACKAGES em apps, .npmrc/pip.conf/NuGet.Config, OIDC secretless para CI/CD consumidor, dicas por ecossistema (npm/pypi/nuget/maven/go), onboarding novo via template Backstage, troubleshooting generico (Actor not member of owner_group, 409 Conflict, 401 Unauthorized). Para MIGRAR um repo existente (ja publica em GitHub Packages/npmjs.org/PyPI publico, ou nunca publicou mas quer onboard com validacao pre-merge) acione a skill migrate-to-karavela-packages — ela cobre os fluxos de rollout, dual-write, cirurgia em lockfile, bun, cascata de dependencias internas, build_command com npm pack, version: github.ref_name e outros detalhes de migracao."
---

# Karavela Packages

Plataforma da Stone para publicar e consumir pacotes/bibliotecas privadas no Nexus (`packages.stone.tech`). Suporte para **npm**, **pypi**, **nuget**, **maven**, **go**.

## ⚠️ Dois Workflows — NÃO Confundir

Existem **dois workflows diferentes, em repositórios diferentes**. Copiar o path errado é o erro mais comum — use SEMPRE os valores exatos abaixo, sem abreviar, sem inferir:

| Objetivo | `uses:` exato (copie literal) |
|---|---|
| **PUBLICAR** uma lib/pacote (repo da biblioteca) | `stone-payments/karavela-packages-workflows/.github/workflows/karavela_packages_publish.yml@main` |
| **CONSUMIR** pacotes em uma app (repo da aplicação) | `stone-payments/platform-k8s-github-actions/.github/workflows/karavela_build.yml@main` |

Regras anti-alucinação:
- `karavela_packages_publish.yml` **só existe** em `karavela-packages-workflows` (não em `platform-k8s-github-actions`).
- `karavela_build.yml` **só existe** em `platform-k8s-github-actions` (não em `karavela-packages-workflows`).
- Sempre com sufixo `.yml` e `@main`. Nunca `.yaml`, nunca sem extensão.
- Se o repo é a **lib** → publish. Se é a **app** que instala a lib → build (consumer).

## Escopo — O que COBRE

- Publicação de pacotes privados (`npm`, `pypi`, `nuget`, `maven`, `go`)
- Onboarding novo (template Backstage) e existente (repo manual)
- **Monorepo** em um único job (detecta `workspaces`, `tool.uv.workspace`, `.sln`, `include(…)`, múltiplos `go.mod` / `go.work` automaticamente)
- **Monorepo push-on-main com versões por manifesto** (Yarn/PNPM workspaces, Changesets, release-please per-package) — omita o input `version` e o workflow publica cada módulo com a versão do próprio `package.json`, filtrando versões já publicadas via `filter-already-published` (re-execução é idempotente)
- Normalizacao de nome canônico em runtime (manifesto mantém nome livre; Portal aplica `@stone-payments/…`, `snake_case`, `StoneCo.…`, `co.stone:…`)
- Versionamento via release tag — `v1.0.0` injeta `1.0.0` em todos os manifestos em runtime
- Consumo local (repositórios `-group` são públicos, sem credenciais)
- Consumo em CI/CD (secretless via OIDC → ephemeral tokens)
- Consumo em apps via `karavela_build.yml` com `USE_KARAVELA_PACKAGES: true`
- SBOM, scan SCA (Grype, informacional), SLSA 3 attestation, upload ao Dependency Track
- Dual-write para migração segura de registries antigos
- **Aba Gerenciamento de Pacotes** (Portal) — Cleanup de publishes órfãos, Danger Zone (soft-delete / undelete)
- **Dependency Explorer** (Portal) — landing tri-tab para explorar dependencias e dependentes, com deep-link `Dependencies → Dependents (focusDep)`
- **Permissao `karavela.packages.manage`** — gate para acoes destrutivas no Portal

## Escopo — O que NÃO COBRE

- Provisionamento de infra (skill `vela:*` específicas)
- Publicação de imagens Docker → ECR (skill `deploy-rollback`)
- Configuração do Dependency Track (skill `seguranca`)

## Exemplos de Perguntas

- *"Como publico uma nova biblioteca npm privada na Stone?"*
- *"Preciso transformar minha lib já existente em um Karavela Package — por onde começo?"*
- *"Tenho um monorepo com 5 pacotes npm — preciso criar 5 jobs no workflow?"*
- *"Como configuro meu app para consumir `@stone-payments/payment-sdk`?"*
- *"Meu workflow de publish não disparou depois da tag, o que pode ser?"*
- *"Estou com `Actor not member of owner_group` — como resolvo?"*
- *"Como autentico CI/CD sem usar secrets?"*
- *"Como migro com segurança uma biblioteca já publicada em npmjs.org para Karavela?"*
- *"Como reduzo acoplamento entre dois microservices que compartilham lógica?"*
- *"Meu monorepo Yarn workspaces publica a cada push na main com versão por package — dá pra usar Karavela sem ter que unificar versão nem criar tag?"*
- *"Como faço soft-delete de um pacote no Portal?"*
- *"Como vejo quem depende do meu pacote no Dependency Explorer?"*
- *"Onde fica a aba Gerenciamento de Pacotes do Portal?"*

## Fluxo Rápido — Novo Pacote

1. **Criar repo via Portal** — template "Criar Pacote Privado"
   → Gera GitHub repo + CODEOWNERS + catalog-info.yaml + skeleton + workflow pré-configurado

2. **Estruturar manifesto** — npm: `package.json`, pypi: `pyproject.toml`, nuget: `.csproj`, maven: `pom.xml`, go: `go.mod`
   → Manter versão seed (`0.0.1` npm/pypi, `0.1.0` nuget/maven) — versão real vem da tag
   → **Go é exceção**: `go.mod` não tem campo de versão (não há seed) — a versão vem 100% da tag git (`v` preservado)

3. **Configurar workflow** — skeleton já vem pronto; dispara por GitHub Release (final) ou tag pré-release

4. **Publicar** — GitHub Release ou `git tag v1.0.0 && git push origin v1.0.0`
   → Plan (detecta + onboard) → Build + SBOM/SCA/Attestation + Publish → Confirm (automático)

## Fluxo Rápido — Migrar Repo Existente para Publicar

> **Observação**: o passo-a-passo abaixo cobre o caso simples. Para migrações com
> validação pré-merge em STG, dual-write, lockfile registry-agnostic, cascata
> entre libs internas, ecossistema bun, ou qualquer repo com consumidores
> externos, acione a skill **`migrate-to-karavela-packages`**.

Use quando o repo **já existe** (lib manual, ex-npmjs, ex-PyPI, código extraído de um serviço) e precisa passar a publicar no Karavela Packages. Sem template Backstage.

1. **Registrar no Backstage Catalog** — criar `catalog-info.yaml` na raiz com `kind: Component`, `spec.type: library`, `spec.owner: group:default/<time-opsgenie>`. Ver `references/fluxos.md` § Fluxo B.

2. **Ajustar manifesto para versão seed** (sem alterar lógica):
   - npm `package.json`: `"version": "0.0.1"`
   - pypi `pyproject.toml`: `version = "0.0.1"`
   - nuget `*.csproj`: `<Version>0.1.0</Version>`
   - maven `pom.xml` / `build.gradle.kts`: `version = "0.1.0"`
   - go `go.mod`: **sem seed** — `go.mod` não carrega versão; a versão vem da tag git (`v` preservado, não strippado)

   A versão real é injetada em runtime a partir da tag (`v1.2.3` → `1.2.3`; **Go preserva o `v`**). Não alterar o nome — o Portal normaliza (Go = module path literal, sem transform).

3. **Criar `.github/workflows/karavela_packages_publish.yaml`** — copie **literalmente** o snippet abaixo, trocando apenas `ecosystem` e `owner_group`:

   ```yaml
   name: Karavela Packages Publish

   on:
     release:
       types: [published]
     push:
       tags:
         - 'v*-rc.*'
         - 'v*-beta.*'
         - 'v*-alpha.*'

   permissions:
     contents: read
     id-token: write
     attestations: write

   jobs:
     publish:
       uses: stone-payments/karavela-packages-workflows/.github/workflows/karavela_packages_publish.yml@main
       with:
         ecosystem: 'npm'                  # npm | pypi | nuget | maven | go
         owner_group: 'meu-time-opsgenie'  # grupo Opsgenie do time (sem prefixo karavela-containers-)
         work_dir: '.'
         build_runs_on: 'medium-runner'    # Go exige runner self-hosted (small/medium/large/xlarge); ubuntu-latest vira no-op
   ```

   **Checklist antes de commitar** (o agente DEVE validar contra o texto acima):
   - [ ] `uses:` é **exatamente** `stone-payments/karavela-packages-workflows/.github/workflows/karavela_packages_publish.yml@main`
   - [ ] **Não** é `platform-k8s-github-actions` (esse é do consumer/build)
   - [ ] **Não** é `karavela_build.yml` (esse é do consumer)
   - [ ] Termina em `.yml@main` (com extensão e ref)

4. **Publicar** — crie GitHub Release (final) ou push de tag pré-release (`v1.0.0-rc.1`). Tag final pushada direto **não dispara** — exige Release UI.

5. **Se já publica em outro registry** (npmjs, PyPI pública) e há consumidores externos → seguir **Fluxo C (dual-write)** em `references/fluxos.md` antes de desligar o registry antigo.

### Triggers — Release Final vs Pré-Release

Skeleton padrão usa dois triggers:

- **GitHub Release** (`release.types: [published]`) — release final com rastreabilidade
- **Push tags** (`v*-rc.*`, `v*-beta.*`, `v*-alpha.*`) — pré-release automático

**Importante**: tags finais pushadas direto (`v1.2.3`) **NÃO disparam** — exigem GitHub Release UI (garantindo rastreabilidade).

## Consumo em Apps

**Desenvolvimento local** (público, sem credentials):
```bash
npm install @stone-payments/<pacote>
pip install <pacote> --index-url https://packages.stone.tech/repository/pypi-group/simple/
```

**CI/CD** (secretless via OIDC):
```yaml
jobs:
  build:
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_build.yml@main
    with:
      REGISTRY_NAME: 'minha-app'
      USE_KARAVELA_PACKAGES: true    # turno-chave para credenciais OIDC
    secrets: inherit
```

Dockerfile com BuildKit secret (credenciais nunca em layers):
```dockerfile
# syntax=docker/dockerfile:1
RUN --mount=type=secret,id=npmrc,target=.npmrc npm ci
```

## Acesso — Público para Devs, OIDC Secretless em CI/CD

| Contexto | Auth | Registry |
|----------|------|----------|
| Dev local | Não | `-group` (público) |
| CI/CD | OIDC ephemeral | `-group` → `-hosted` |
| Publicação | OIDC | Portal/Nexus |

---

## Aba Gerenciamento de Pacotes (Portal)

O Portal Backstage ganhou uma aba **Gerenciamento de Pacotes** na entity page de cada Package. Conteudos:

- **CleanupCard** — limpa publishes orfaos (registros no Postgres sem artefato real no Nexus).
- **DangerZoneCard** — soft-delete e undelete do Package (state machine `reserved → active → soft-deleting → soft-deleted`; recuperavel via undelete antes do `hard-deleting`).

Acoes destrutivas exigem permissao `karavela.packages.manage` (gated por RBAC v3 — veja skill `modelo-acessos`).

### Dependency Explorer (Portal)

Use a aba **Dependency Explorer** para responder rapidamente "quem depende de `@stone-payments/payment-sdk@1.4.0`?". Tem deep-link da aba **Dependencies** para o drawer de **Dependents**.

### Ciclo de Vida do Pacote

O Portal expoe os seguintes estados visiveis para o dev:

| Estado | Significado |
|--------|-------------|
| `reserved` | Pacote ja reservado (nome + ecossistema) mas ainda sem publish |
| `active` | Publicado com sucesso (pelo menos uma versao) |
| `soft-deleting` / `soft-deleted` | Em periodo de graca — recuperavel via **Undelete** na aba Danger Zone |
| `hard-deleting` | Removendo definitivamente do Nexus |
| `undeleting` | Recuperando soft-deleted |

### Chip "Teste" em Pacotes de Onboarding

Pacotes criados em modo de teste exibem chip **"Teste"** na `PackagesPage` do Portal — util para distinguir pacotes de teste vs produtivos durante onboarding inicial.

## Como Usar Esta Skill

**Para conceitos e fluxo:**
- `references/conceitos.md` — versionamento, normalizacao, triggers, OIDC, monorepo, ciclos de vida
- `references/fluxos.md` — Fluxo A (novo), Fluxo B (existente), Fluxo C (dual-write tag-driven), Fluxo D (monorepo push-on-main, versões por manifesto), MCP instructions

**Para seu ecossistema:**
- `references/npm.md` — package.json, .npmrc, BuildKit secrets, troubleshooting
- `references/pypi.md` — pyproject.toml, pip.conf, repo dedicado por time
- `references/nuget.md` — .csproj, NuGet.Config, multi-projeto
- `references/maven.md` — pom.xml + build.gradle.kts, settings.xml
- `references/go.md` — go.mod, GOPROXY/.netrc, BuildKit secrets (goenv+netrc), troubleshooting

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever; producao exige dupla confirmacao. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Criar/Editar `.github/workflows/*.yml`** — usar `karavela_packages_publish.yml@main` (publish) ou `karavela_build.yml@main` com `USE_KARAVELA_PACKAGES: true` (consumer)
- **Editar manifesto** — `package.json` (npm), `pyproject.toml` (pypi), `.csproj` (nuget), `pom.xml` ou `build.gradle.kts` (maven), `go.mod` (go)
- **Configurar OIDC secretless** para CI/CD consumidor (sem secrets)
- **Edit `catalog-info.yaml`** com info de package
- **Acoes via Portal** — soft-delete/undelete, gerenciamento de orfaos (orientacao, gated por `karavela.packages.manage`)
- **Abrir PR draft**

### Triggers proativos
- "Publicar nova biblioteca" → guiar fluxo template Backstage + abrir PR com workflow inicial
- "Adicionar package no monorepo" → propor patch em workspaces config + verificar `filter-already-published`
- "Migrar repo existente" → direcionar para skill `migrate-to-karavela-packages`

### Acoes destrutivas (dupla confirmacao)
- **Soft Delete / Hard Delete de Package** — via Portal Karavela com permissao `karavela.packages.manage`. Listar dependentes via Dependency Explorer antes.

## Troubleshooting Rápido

| Erro | Solução |
|------|---------|
| `Actor not member of owner_group` | Verificar membership no Portal Backstage; acionar `#help-foundation-platform` |
| `409 Conflict no publish-plan` | Par `(ecosystem, identity)` pertence a outro time — renomear ou acionar `#help-foundation-platform` |
| `Version already exists` | Incrementar versão, criar nova tag/release |
| Workflow não disparou após tag | Tag final pushada direto no git (não dispara); criar GitHub Release ou usar pré-release (`v*-rc.*`) |
| `401 Unauthorized` npm install local | Apontando para `-hosted` (privado) em vez de `-group` (público) |
| `401 Unauthorized` npm install CI | `permissions: id-token: write` faltando ou `USE_KARAVELA_PACKAGES` off |
| Published com versão errada | Tag fora do padrão `vX.Y.Z` — usar tag semântica com prefixo `v` |
| Monorepo — módulo não publicado | Módulo não listado na config de workspaces do ecossistema |
| Go: publish não rodou / no-op silencioso | `build_runs_on: ubuntu-latest` (label SaaS) não casa nenhum job — Go exige runner self-hosted (`small/medium/large/xlarge-runner`). Ver `references/go.md` |
| Go: `go.sum mismatch` / `410 Gone` ao consumir | `GOSUMDB=off` (local/Docker) ou `GONOSUMDB=github.com/stone-payments/*` (runner); cair em `,direct` para módulo privado ausente do `go-hosted` exige auth VCS. Ver `references/go.md` |

Veja `references/fluxos.md` para tabela completa de troubleshooting com mais detalhes.

## Instrucoes MCP

Esta skill nao tem doc dedicado em `stone-payments/karavela` `docs/`. As fontes primarias de operacao sao os reusable workflows e o Portal Backstage.

| Repositorio | Arquivo/Caminho | Prioridade | Quando buscar |
|-------------|-----------------|------------|---------------|
| `stone-payments/karavela-packages-workflows` | `.github/workflows/karavela_packages_publish.yml` | primaria operacional — complemento (nao em docs/) | Inputs/outputs do workflow de publish + monorepo + filter-already-published |
| `stone-payments/platform-k8s-github-actions` | `.github/workflows/karavela_build.yml` | primaria operacional — complemento (nao em docs/) | Input `USE_KARAVELA_PACKAGES` no workflow de build do consumidor |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/funcionalidades/azure-artifacts.md` | complemento | Cenario adjacente: NuGet via Azure Artifacts (alternativa pre-Karavela Packages) |

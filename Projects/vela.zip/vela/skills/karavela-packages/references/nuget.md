# Karavela Packages — NuGet

## Manifesto: `*.csproj`

Mantenha `<Version>` como a versao seed do skeleton (`0.1.0`) — a versao real vem da release tag em runtime.

```xml
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net8.0</TargetFramework>
    <PackageId>MeuPacote</PackageId>
    <Version>0.1.0</Version>
    <Description>Minha biblioteca privada</Description>
    <Authors>Stone Payments</Authors>
    <GeneratePackageOnBuild>false</GeneratePackageOnBuild>
  </PropertyGroup>
</Project>
```

O Portal normaliza o nome para publicacao assim: faz split **apenas** nos separadores `[-_.]`, capitaliza a primeira letra de cada segmento e prefixa `StoneCo.`. **camelCase NAO e quebrado** — o restante de cada segmento e preservado:

| Manifesto (`PackageId`) | Publicado |
| --- | --- |
| `meu-pacote` | `StoneCo.Meu.Pacote` |
| `paymentApi` | `StoneCo.PaymentApi` (nao vira `Payment.Api`) |
| `HTMLParser` | `StoneCo.HTMLParser` |

**Escape hatch:** se o `PackageId` ja comeca com `StoneCo.`, ele e publicado **verbatim** (sem normalizacao). Use quando quiser controlar o nome final, ex: `<PackageId>StoneCo.Payment.Api</PackageId>` publica exatamente `StoneCo.Payment.Api`.

## Multiplos projetos (monorepo)

O workflow detecta monorepo automaticamente a partir do arquivo `*.sln` na raiz — **um unico job** publica todos os projetos incluidos na solucao.

```yaml
jobs:
  publish:
    uses: stone-payments/karavela-packages-workflows/.github/workflows/karavela_packages_publish.yml@main
    with:
      ecosystem: 'nuget'
      owner_group: 'meu-time-opsgenie'
      work_dir: '.'
```

## Build customizado

```yaml
with:
  ecosystem: 'nuget'
  owner_group: 'meu-time-opsgenie'
  build_command: 'dotnet build -c Release'
```

## Consumo em apps — Dockerfile (CI)

```dockerfile
# syntax=docker/dockerfile:1
RUN --mount=type=secret,id=nugetconfig,target=nuget.config \
    dotnet restore
```

## `nuget.config` local para desenvolvimento (publico)

O repositorio `nuget-group` e de **acesso publico**. Sem credenciais:

```xml
<?xml version="1.0" encoding="utf-8"?>
<configuration>
  <packageSources>
    <add key="karavela-packages"
         value="https://packages.stone.tech/repository/nuget-group/index.json" />
  </packageSources>
</configuration>
```

```bash
dotnet add package StoneCo.<PackageName>
```

## Troubleshooting NuGet

**`Unable to find package` no dotnet restore em CI**

- Verificar `permissions: id-token: write` no workflow
- Verificar se `USE_KARAVELA_PACKAGES: true` esta no `karavela_build.yml`

**`Unable to find package` local**

- Verificar que o `nuget.config` aponta para `nuget-group` (publico) em `packages.stone.tech`

**`PackageId` ja existe com outro owner**

- NuGet usa repositorio compartilhado com Content Selectors; cada `PackageId` pertence a um time
- Se houver conflito de nome, acionar `#help-foundation-platform`

**`MSBUILD error MSB1003: Specify a project or solution file`**

- O workflow procura `.sln` na raiz do `work_dir`; garanta que existe e referencia os projetos corretos

**Build falha com `Version` invalida**

- O step `override-version` substitui em runtime — nao altere a versao manualmente

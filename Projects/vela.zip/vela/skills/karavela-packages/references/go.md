# Karavela Packages — Go

## Manifesto: `go.mod`

Go **não tem versão no manifesto** — não existe "seed" pra Go. O `go.mod` carrega apenas o **module path** (a identidade do pacote); a versão vem **100% da tag git** (`v1.2.3`, com o `v` preservado).

```go
module github.com/stone-payments/payment-sdk

go 1.26

require (
    // dependencias
)
```

O Portal publica como o **module path literal** — `github.com/stone-payments/payment-sdk`, **sem transform** (pass-through, igual ao raw). Não há `@stone-payments/...` nem `snake_case`: o nome do `go.mod` é a identidade publicada.

> **Monorepo**: cada submódulo tem seu próprio `go.mod` e é publicado como `{modulePath}/{subpath}` (ex: `github.com/stone-payments/foo/sub-a`). A tag de cada módulo é `module/vX.Y.Z`. Uma invocação do publish cobre **um** módulo; o monorepo é coberto por múltiplas invocações orquestradas pelo caller (`karavela-auto-release.yaml` no push→main; `karavela-backfill-versions.yaml` por dispatch matricial).

## Build customizado

Go é **source-only** — o artefato publicado é o source tree zipado no formato GOPROXY (`{vX.Y.Z}.zip` + `.info` + `.mod` + `list`). **Não há compile** e **não há tarball** (`.tgz`/`.nupkg`/`.jar`). O step `build-package` é no-op pra Go; o equivalente é a geração dos artefatos GOPROXY.

Se o módulo precisar de um passo prévio (ex: `go generate`, codegen), use `build_command` — ele roda antes da geração do zip:

```yaml
with:
  ecosystem: 'go'
  owner_group: 'meu-time-opsgenie'
  build_command: 'go generate ./...'
  build_runs_on: 'medium-runner'   # OBRIGATÓRIO self-hosted — ver Troubleshooting
```

> ⚠️ **`build_runs_on` deve ser self-hosted** (`small/medium/large/xlarge-runner`). Go roda só no job interno; `ubuntu-latest` (label SaaS) não casa nenhum job e vira **no-op silencioso**.

## Consumo em apps — Dockerfile (CI)

O `karavela_build.yml` com `USE_KARAVELA_PACKAGES: true` obtem credenciais via **OIDC** e injeta dois BuildKit secrets: `goenv` (sempre — `GOPROXY` + `GOSUMDB=off`) e `netrc` (credenciais efêmeras). `setup-consumer` **agora cobre Go** — o app só precisa de `USE_KARAVELA_PACKAGES: true`.

```dockerfile
# syntax=docker/dockerfile:1
FROM golang:1.26 AS build
WORKDIR /app
COPY go.mod go.sum ./
RUN --mount=type=secret,id=netrc,target=/root/.netrc \
    --mount=type=secret,id=goenv \
    set -a && . /run/secrets/goenv && set +a && \
    go mod download
COPY . .
RUN go build -o /out/app
```

- **Não** use `ARG GOPROXY` — o `goenv` é a fonte única da config. O `set -a && . /run/secrets/goenv && set +a` exporta `GOPROXY`/`GOSUMDB` do secret antes do `go mod download`.
- `GOPROXY` contém `|` (cascade) — por isso o `goenv` é sourced (não passado inline sem aspas).
- O mount de `netrc` é **opcional hoje** (o `go-hosted` tem leitura anônima), mas o pipeline monta sempre (future-proof pra quando a leitura exigir auth).

## Config local para desenvolvimento (público)

Os repositórios `go-group` (proxy OSS) e `go-hosted` (módulos privados Stone) têm **leitura pública/anônima** — sem token, sem `.netrc`:

```bash
go env -w GOPROXY="https://packages.stone.tech/repository/go-hosted|https://packages.stone.tech/repository/go-group,direct"
go env -w GOSUMDB=off
# NÃO setar GOPRIVATE (deixar vazio) — GOPRIVATE faria o Go furar o proxy e ir direto pro VCS

go get github.com/stone-payments/<mod>@vX.Y.Z
```

- O separador entre `go-hosted` e `go-group` é `|` (cascade em qualquer erro hosted→group). `,direct` no fim = última instância (clone VCS), só em 404/410.
- `GOSUMDB=off` é necessário local/Docker (o checksum DB público não conhece módulos privados Stone).
- **`GOPRIVATE` vazio de propósito**: setar `GOPRIVATE=github.com/stone-payments/*` faria o Go pular o proxy e clonar via VCS (exigindo auth) — exatamente o que o GOPROXY público evita.

## GOPROXY / GONOSUMDB / GOPRIVATE

Resumo das 3 variáveis e quando cada uma aparece (o pipeline cabeia tudo; esta tabela é pra debugar/entender):

| Var | Valor | Onde |
|---|---|---|
| `GOPROXY` | `{base}/go-hosted\|{base}/go-group,direct` | local, Docker (`goenv`), runner |
| `GOSUMDB` | `off` | local + Docker (`goenv`) |
| `GONOSUMDB` | `github.com/stone-payments/*` | runner (jobs `go-checks` etc.) |
| `GOPRIVATE` | **vazio** (`GOPRIVATE=`) — nunca `github.com/stone-payments/*` | runner |

- `{base}` default `https://packages.stone.tech/repository`.
- **Runner usa `GONOSUMDB` (não `GOSUMDB=off`)**: `GOSUMDB=off` bloquearia o download automático de toolchain; `GONOSUMDB` desliga só a verificação de checksum dos módulos Stone, mantendo o sumdb pro resto.
- `GOPRIVATE` **sempre vazio** em todos os contextos — é a armadilha nº 1.

## Troubleshooting Go

**Publish não rodou / no-op silencioso**

- `build_runs_on: ubuntu-latest` (label SaaS) não casa nenhum job — Go roda **só** no job interno self-hosted. Use `small/medium/large/xlarge-runner`.

**`410 Gone` / módulo não resolve via GOPROXY**

- A versão pedida não existe no `go-hosted` (`{base}/repository/go-hosted/{module}/@v/{vX.Y.Z}.info`). Confirme que a tag (`module/vX.Y.Z` em monorepo) foi publicada e que o `GOPROXY` aponta para `go-hosted|go-group,direct` (com `|`, não `,`, entre hosted/group).

**`go.sum mismatch` / checksum inválido**

- **Local/Docker**: garanta `GOSUMDB=off`. **Runner**: `GONOSUMDB=github.com/stone-payments/*`. O SBOM do publish já tem fallback `syft` pra contornar mismatch de `go.sum` durante a geração.
- Se persistir, rode `go mod tidy` para regenerar o `go.sum` (Go = checksum-only, sem URL pin no lockfile — regenerar é seguro).

**`,direct` tentando clonar módulo privado (pede auth VCS)**

- Um `github.com/stone-payments/*` **privado ausente do `go-hosted`** cai no `,direct` e exige autenticação VCS. Solução: garantir que o módulo está publicado no `go-hosted` **antes** de consumir — evite depender do `,direct` pra módulo privado.

**`GOPRIVATE` setado fura o proxy**

- Se `GOPRIVATE=github.com/stone-payments/*` estiver setado, o Go ignora o GOPROXY e vai direto pro VCS. Mantenha `GOPRIVATE` **vazio**.

**`401`/`403` no consumo em CI**

- Verificar `permissions: id-token: write` no workflow
- Confirmar `USE_KARAVELA_PACKAGES: true` no `karavela_build.yml` (injeta `goenv` + `netrc` via OIDC)

**`Forbidden`/falha no publish (`id-token: write` faltando)**

- O publish usa OIDC pra obter as credenciais efêmeras do Nexus. Garanta `permissions: id-token: write` e `attestations: write` no workflow de publish.

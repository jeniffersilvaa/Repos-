# Karavela Packages — PyPI

## Manifesto: `pyproject.toml` (recomendado)

Mantenha a versao seed (`0.0.1` no skeleton) — a versao real vem da release tag em runtime.

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "meu-pacote"
version = "0.0.1"
description = "Minha biblioteca privada"
requires-python = ">=3.11"
dependencies = []
```

Alternativa com `setup.py`:

```python
from setuptools import setup, find_packages

setup(
    name="meu-pacote",
    version="0.0.1",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
)
```

O Portal publica como `{snake_case}` automaticamente (ex: `meu_pacote`).

## Estrategia RBAC — repositorio dedicado por owner_group

Diferente dos outros ecossistemas, o PyPI usa um repositorio Nexus dedicado por `owner_group` (`pypi-hosted-<owner_group>`). Para **consumo**, use sempre o `pypi-group` que agrega todos:

- URL de consumo (publica): `https://packages.stone.tech/repository/pypi-group/simple/`

## Build customizado

```yaml
with:
  ecosystem: 'pypi'
  owner_group: 'meu-time-opsgenie'
  build_command: 'pip install build && python -m build'
```

## Consumo em apps — Dockerfile (CI)

```dockerfile
# syntax=docker/dockerfile:1
# pip — usa PIP_CONFIG_FILE apontando para o secret montado
RUN --mount=type=secret,id=pipconf \
    PIP_CONFIG_FILE=/run/secrets/pipconf \
    pip install --no-cache-dir -r requirements.txt

# uv — nao le pip.conf; extraia a URL do index
RUN --mount=type=secret,id=pipconf \
    export UV_DEFAULT_INDEX=$(grep index-url /run/secrets/pipconf | cut -d'=' -f2 | xargs) && \
    uv sync --frozen --no-dev
```

## Consumo local (publico)

O `pypi-group` e de **acesso publico** para desenvolvimento. Nao precisa token:

```bash
# pip
pip install <pacote> \
    --index-url https://packages.stone.tech/repository/pypi-group/simple/

# uv
uv add <pacote> \
    --index-url https://packages.stone.tech/repository/pypi-group/simple/
```

```toml
# Ou no pyproject.toml
[[tool.uv.index]]
url = "https://packages.stone.tech/repository/pypi-group/simple/"
```

## Troubleshooting PyPI

**`HTTP Error 401: Unauthorized` no pip install local**

- Voce provavelmente esta apontando para `pypi-hosted-<ownerGroup>` (privado). Use sempre `pypi-group` para consumo local (publico).

**`HTTP Error 401` no pip install em CI**

- Verificar `permissions: id-token: write` no workflow
- Verificar se `USE_KARAVELA_PACKAGES: true` esta no `karavela_build.yml`

**`Package not found` mesmo apos publicacao**

- Aguardar alguns segundos apos a publicacao para o Nexus indexar o pacote

**`InvalidVersion` no hatchling**

- Versao seed (`0.0.1`) e valida; o step `override-version` substitui em runtime — nao altere a versao manualmente

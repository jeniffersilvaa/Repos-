# Karavela Packages — npm

## Manifesto: `package.json`

Mantenha a versao seed (`0.0.1` no skeleton) — a versao real vem da release tag em runtime.

```json
{
  "name": "meu-pacote",
  "version": "0.0.1",
  "description": "Minha biblioteca privada",
  "main": "dist/index.js",
  "types": "dist/index.d.ts",
  "files": ["dist"],
  "scripts": {
    "build": "tsc"
  }
}
```

O Portal publica como `@stone-payments/{kebab-case}` automaticamente.

## Build customizado

Se o pacote precisa de build antes de publicar, use o parametro `build_command`:

```yaml
with:
  ecosystem: 'npm'
  owner_group: 'meu-time-opsgenie'
  build_command: 'npm run build'
```

O workflow executa o build antes do `npm publish`.

## Consumo em apps — Dockerfile (CI)

O `karavela_build.yml` com `USE_KARAVELA_PACKAGES: true` obtem credenciais via **OIDC** e injeta o `.npmrc` como BuildKit secret (secretless — sem tokens estaticos):

```dockerfile
# syntax=docker/dockerfile:1
RUN --mount=type=secret,id=npmrc,target=.npmrc \
    npm ci
```

## `.npmrc` local para desenvolvimento (publico)

O repositorio `npm-group` e de **acesso publico**. Nao precisa token, usuario ou senha:

```ini
@stone-payments:registry=https://packages.stone.tech/repository/npm-group/
```

```bash
npm install @stone-payments/<nome-do-pacote>
```

Apenas pacotes com escopo `@stone-payments/` sao resolvidos via Karavela Packages. Todos os outros pacotes continuam sendo buscados no npmjs.org.

## Monorepo Yarn/PNPM Workspaces — Versões por Manifesto

Para monorepos com **versão independente por package** (bump manual em cada `package.json`, Changesets, release-please per-package), o workflow suporta publicar a cada `push: main` sem precisar de tag/release:

- Omita o input `version` — cada módulo publica com a versão do próprio `package.json`
- `detect-workspace-modules` varre `packages/*/package.json` (ignora `private: true`)
- Portal retorna `modules_to_publish` considerando o que já existe no Nexus — o step `filter-already-published` remove `.tgz` de versões repetidas antes do `npm publish`, tornando a re-execução segura
- `build-package` detecta `yarn.lock` → roda `corepack enable; yarn install; yarn workspace <pkg> run build; yarn workspace <pkg> pack` por módulo; `pnpm-lock.yaml` segue lógica análoga com `pnpm -r run build`

Ver `references/fluxos.md` → **Fluxo D** para exemplo completo e diferenças vs dual-write com release-please.

**Compatibilidade com `publishConfig.registry` legado** — `npm publish <tgz> --registry <nexus>` na flag **sobrescreve** o `publishConfig.registry` do tarball. Logo pacotes que hoje publicam em `npm.pkg.github.com` (ou `npmjs.org`) podem ser espelhados no Karavela sem alterar os manifestos.

## Troubleshooting npm

**`E401 Unauthorized` no npm install local**

- Voce provavelmente esta apontando para um repositorio `-hosted` (privado) em vez do `-group` (publico). Use `https://packages.stone.tech/repository/npm-group/`.

**`E401 Unauthorized` no npm install em CI**

- Verifique `permissions: id-token: write` no workflow
- Confirme `USE_KARAVELA_PACKAGES: true` no `karavela_build.yml` (ou o uso de `request-consumer-token` + `setup-consumer` em workflows customizados)

**`ENOENT: no such file or directory, open 'dist/index.js'`**

- O campo `main` aponta para o build output; garanta que `build_command` esta configurado
- Verifique se `files` no `package.json` inclui o diretorio de build

# Karavela Packages — Conceitos Fundamentais

## Versionamento — Sempre da Tag, Nunca do Manifesto

O manifesto mantém uma **versão seed** (`0.0.1` para npm/pypi, `0.1.0` para nuget/maven). Na publicação, o step `override-version` sobrescreve a versão em **todos** os manifestos usando a versão da tag/release:

- **Tag**: `v1.2.3` → injeta `1.2.3` (remove prefixo `v`)
- **Release**: versão extraída do GitHub Release

| Ecossistema | Como é injetada |
|---|---|
| **NPM** | `npm version "${VERSION}" --no-git-tag-version --allow-same-version` |
| **PyPI** | `sed` em `pyproject.toml`: `version = "X.Y.Z"` |
| **NuGet** | `sed` em `.csproj`: `<Version>X.Y.Z</Version>` |
| **Maven** | `sed` em `build.gradle.kts` ou `mvn versions:set` |
| **Go** | **Outlier** — não há `sed` no manifesto. O `go.mod` não carrega versão; a versão vem da tag git e é usada literalmente nos nomes dos artefatos GOPROXY (`{vX.Y.Z}.info/.mod/.zip`), com o **`v` preservado** (não strippado). O step `override-version` é no-op pra Go. |

**Em monorepo npm**: versão propagada para todos os workspaces (`npm version <V> --workspaces --no-git-tag-version`).

## Normalização do Nome Canônico

Você mantém um nome **livre** no manifesto; o Portal aplica a convenção ao publicar. Isso é automático, feito em **runtime** — o arquivo no repo não muda:

| Ecossistema | Formato Canônico | Exemplo Input | Exemplo Output |
|---|---|---|---|
| npm | `@stone-payments/{kebab-case}` | `PaymentApi` | `@stone-payments/payment-api` |
| pypi | `{snake_case}` | `PaymentApi` | `payment_api` |
| nuget | `StoneCo.{PascalCase}` | `payment-api` | `StoneCo.Payment.Api` |
| maven | `groupId: co.stone`, `artifactId: {kebab-case}` | `PaymentApi` | `co.stone:payment-api` |
| go | **module path literal, SEM transform** (pass-through) | `github.com/stone-payments/payment-sdk` | `github.com/stone-payments/payment-sdk` |

**Monorepo**: segue padrão `{pacote}-{modulo}` (ex: `utils-core` → `@stone-payments/utils-core`, `utils_core`, `StoneCo.Utils.Core`, `co.stone:utils-core`). **Go é exceção**: o submódulo é `{modulePath}/{subpath}` (ex: `github.com/stone-payments/foo/sub-a`) — o module path literal do submódulo, sem normalização.

## Fluxo do Workflow de Publicação — Três Fases

O workflow `karavela_packages_publish.yml` executa **três fases** em cadeia:

1. **Plan** (detecta + autoriza)
   - Ler manifesto, obter OIDC token com `audience=stone-payments/karavela-packages`
   - Portal verifica onboarding (novo/re-publish/retry)
   - Provisiona RBAC no Nexus (idempotente)
   - Retorna `registry_url`, `onboardingId`, credenciais Nexus ephemeral

2. **Build + SBOM/SCA/Attestation + Publish** (executa + valida + publica)
   - Detecta monorepo automaticamente
   - Build do pacote(s)
   - Gera SBOM CycloneDX
   - Roda Grype (scan SCA informacional — reporta/persiste vulnerabilidades; NÃO bloqueia o publish)
   - Gera SLSA 3 attestation via `actions/attest@v4`
   - Upload SBOM ao Dependency Track
   - `npm publish` / `poetry publish` / `dotnet nuget push` / `mvn deploy` para Nexus; **Go** publica via protocolo GOPROXY (PUT de `list`/`.info`/`.mod`/`.zip`) no repo `go-hosted` compartilhado — source-only, sem compile

3. **Confirm** (sempre executa se Plan passou)
   - Chama `POST /api/karavela-packages/confirm-onboarding` com `CONFIRMED` ou `PUBLISH_FAILED`
   - Registra lista de módulos publicados

## Triggers — GitHub Release (Final) + Tags Pré-Release

O skeleton padrão gerado pelo Portal usa **dois triggers** para separar distribuição final de pré-releases:

```yaml
on:
  release:
    types: [published]          # GitHub Release criada — distribuição final
  push:
    tags:
      - 'v*-rc.*'               # pre-release RC
      - 'v*-beta.*'             # pre-release Beta
      - 'v*-alpha.*'            # pre-release Alpha
```

**Importante**: uma tag final pushada direto (`git push origin v1.2.3`) **não dispara** o workflow. Para publicar a versão final, você deve **criar uma GitHub Release** apontando para a tag. Isso garante rastreabilidade e possibilita aprovação via `environment` protection rules.

## Acesso — Público para Devs, OIDC Secretless em CI/CD

Os repositórios Nexus `-group` (agregadores) são de **acesso público**. Eles combinam:
- Pacotes privados da Stone (hosted)
- Proxies de registries públicos (npmjs.org, pypi.org, nuget.org, maven central)

| Contexto | Autenticação | Registry |
|---|---|---|
| **Dev local** | Nenhuma — público | `-group` |
| **CI/CD (GitHub Actions)** | OIDC → ephemeral token | `-group` → `-hosted` |
| **Publicação (release)** | OIDC | Portal/Nexus |

**Regra de ouro**: nunca configure tokens/secrets do Nexus para consumo local. O acesso é público. Para CI/CD, use OIDC secretless via `request-consumer-token` + `setup-consumer`.

## Monorepo — Um Único Job Publica Todos os Pacotes

O workflow detecta monorepo **automaticamente**. **Não declare um job por pacote** — o mesmo bloco publica todos.

Declare jobs separados apenas quando o repo tem pacotes de **ecossistemas diferentes** (ex: um npm e um pypi lado a lado), cada um com `work_dir` distinto.

| Ecossistema | Detecção | Comando |
|---|---|---|
| `npm` | Campo `"workspaces"` em `package.json` | `npm pack --workspaces` |
| `pypi` | `[tool.uv.workspace]` em `pyproject.toml` | Build de cada `packages/*/` |
| `nuget` | Arquivo `*.sln` na raiz | `dotnet pack <sln>` gera `.nupkg` por projeto |
| `maven` | Multi-module Gradle (`include(…)`) ou Maven (`<modules>`) | Build automático |
| `go` | Múltiplos `go.mod` (exclui `vendor/`) / `go.work` | GOPROXY artifacts por módulo (1 invocação publica **um** módulo) |

> **Go diverge do "um único job"**: cada invocação do `publish` publica os artefatos GOPROXY de **um** módulo (o de `work_dir`). O monorepo é coberto por **múltiplas invocações** — uma por `(módulo, tag)`, cada módulo com tag `module/vX.Y.Z` — orquestradas pelo **caller** (`karavela-auto-release.yaml` no push→main; `karavela-backfill-versions.yaml` por dispatch matricial). Não é um job único iterando submódulos.

## Ciclo de Vida do Onboarding

```
PENDING ──(publish ok)──→ CONFIRMED
PENDING ──(publish fail)──→ PUBLISH_FAILED
PUBLISH_FAILED ──(retry)──→ PENDING
CONFIRMED ──(re-publish)──→ CONFIRMED (isRepublish=true)
```

O provisionamento de RBAC no Nexus é **idempotente** — roda em toda publicação. Monorepos com novos módulos são cobertos automaticamente no `Confirm`.

## SBOM, SCA, Attestation

Toda publicação é **obrigatoriamente**:
- Produz SBOM CycloneDX (`sbom.cdx.json`)
- Scan SCA com Grype (informacional — reporta/persiste; NÃO bloqueia o publish, qualquer severidade)
- Gera attestation SLSA 3 via `actions/attest@v4` (binários + SBOM)
- Envia SBOM ao Dependency Track

Não desabilitar — são requisitos de segurança. O scan Grype é informacional (não há gate bloqueante): vulnerabilidades são reportadas e persistidas, mas não falham a publicação — avalie/atualize a dependência mesmo assim.

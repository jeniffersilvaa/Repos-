# Karavela Packages — Maven / Gradle

## Manifesto: `pom.xml` (Maven)

Mantenha `<version>` como a versao seed do skeleton (`0.1.0`) — a versao real vem da release tag em runtime.

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
  <modelVersion>4.0.0</modelVersion>

  <groupId>co.stone</groupId>
  <artifactId>meu-pacote</artifactId>
  <version>0.1.0</version>
  <packaging>jar</packaging>

  <description>Minha biblioteca privada</description>
</project>
```

## Manifesto: `build.gradle.kts` (Gradle — Kotlin DSL)

```kotlin
plugins {
    kotlin("jvm") version "1.9.0"
    `maven-publish`
}

group = "co.stone"
version = "0.1.0"

publishing {
    publications {
        create<MavenPublication>("mavenJava") {
            from(components["java"])
            groupId = "co.stone"
            artifactId = "meu-pacote"
            version = "0.1.0"
        }
    }
}
```

O Portal publica com `groupId = co.stone` e `artifactId = {kebab-case}` automaticamente.

## Build customizado

Para Gradle:

```yaml
with:
  ecosystem: 'maven'
  owner_group: 'meu-time-opsgenie'
  build_command: './gradlew build -x test'
```

Para Maven:

```yaml
with:
  ecosystem: 'maven'
  owner_group: 'meu-time-opsgenie'
  build_command: 'mvn package -DskipTests'
```

## Consumo em apps — Dockerfile (CI)

```dockerfile
# syntax=docker/dockerfile:1
# Gradle: monta settings em init.d
RUN --mount=type=secret,id=mavensettings,target=/root/.gradle/init.d/karavela.xml \
    gradle dependencies --no-daemon

# Maven: monta como ~/.m2/settings.xml
RUN --mount=type=secret,id=mavensettings,target=/root/.m2/settings.xml \
    mvn dependency:resolve
```

## `build.gradle.kts` / `pom.xml` local para desenvolvimento (publico)

O repositorio `maven-group` e de **acesso publico**. Sem credenciais:

```kotlin
// build.gradle.kts
repositories {
    maven {
        url = uri("https://packages.stone.tech/repository/maven-group/")
    }
}

dependencies {
    implementation("co.stone:<nome-do-pacote>:<versao>")
}
```

```xml
<!-- pom.xml -->
<repositories>
  <repository>
    <id>karavela-packages</id>
    <url>https://packages.stone.tech/repository/maven-group/</url>
  </repository>
</repositories>

<dependencies>
  <dependency>
    <groupId>co.stone</groupId>
    <artifactId><nome-do-pacote></artifactId>
    <version><versao></version>
  </dependency>
</dependencies>
```

## Troubleshooting Maven / Gradle

**`Could not resolve` local**

- Confirme que o repo do Gradle/Maven aponta para `maven-group` em `packages.stone.tech`

**`Could not resolve` em CI**

- Verificar `permissions: id-token: write`
- Confirmar `USE_KARAVELA_PACKAGES: true` no `karavela_build.yml`
- Conferir se o secret `mavensettings` esta montado no path correto do Dockerfile

**`artifact already deployed` (Maven)**

- Maven nao aceita re-deploy da mesma versao no Nexus hosted
- Incrementar versao e criar nova release

**`groupId` diferente de `co.stone`**

- O Portal normaliza o `groupId` para `co.stone` em runtime
- O `artifactId` no manifesto pode ser qualquer nome; o Portal converte para kebab-case

**SNAPSHOT**

- Versoes contendo `-SNAPSHOT` sao publicadas em `maven-snapshots` (nao em `maven-releases`) — comportamento automatico

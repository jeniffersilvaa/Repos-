# Karavela Packages — Fluxos e Padrões

## Fluxo A — Pacote Novo via Template do Portal

Use quando está criando uma biblioteca do zero.

**Passo 1: Template Backstage**

Acesse o Portal Karavela e use o template **"Criar Pacote Privado"**. Ele coleta:

- `repoName` — nome do repositório GitHub (pattern: `^[a-z][a-z0-9-]*[a-z0-9]$`)
- `description` — descrição opcional
- `githubOwnerGroup` — grupo GitHub owner
- `ownerGroup` — time Opsgenie (prefixo `karavela-containers-` removido automaticamente)
- `ecosystem` — `npm | pypi | nuget | maven | go`
- `isMonorepo` — boolean (default: false)
- `packageName` — nome base do pacote
- `modules[]` — lista de módulos (somente se monorepo)

**Passo 2: O Portal Gera Automaticamente**

- Repositório GitHub privado com branches `main` + `develop`
- CODEOWNERS configurado
- `catalog-info.yaml` registrado no Backstage Catalog
- Skeleton de código com versão seed (`0.0.1` npm/pypi, `0.1.0` nuget/maven; **Go não tem seed** — `go.mod` sem versão, tag-driven)
- `.github/workflows/karavela_packages_publish.yaml` pré-configurado
- Scripts de pré-release (`./scripts/prerelease.sh` / `.ps1`) para RC/Beta/Alpha

**Passo 3: Publicar**

```bash
# Clone do repo gerado
cd <repo>

# Pré-release (dispara workflow via tag)
./scripts/prerelease.sh rc        # Linux/macOS
.\scripts\prerelease.ps1 rc       # Windows

# Release final — crie GitHub Release apontando para main via UI
# https://github.com/stone-payments/<repo>/releases/new
```

---

## Fluxo B — Onboarding de Pacote Existente (Sem Template)

Use quando já tem a biblioteca (repo manual, lib publicada em outro registry, ou lógica a extrair de um serviço).

**Pré-requisito 1: Registrar no Backstage**

```yaml
# catalog-info.yaml (raiz do repo)
apiVersion: backstage.io/v1alpha1
kind: Component
metadata:
  name: meu-pacote
  annotations:
    github.com/project-slug: stone-payments/meu-pacote
spec:
  type: library
  lifecycle: production
  owner: group:default/meu-time-opsgenie   # seu grupo OpsGenie
```

**Pré-requisito 2: Adicionar Workflow**

```yaml
# .github/workflows/karavela_packages_publish.yaml
name: Karavela Packages Publish

on:
  release:
    types: [published]
  push:
    tags:
      - 'v*-rc.*'
      - 'v*-beta.*'
      - 'v*-alpha.*'

permissions:
  contents: read
  id-token: write
  attestations: write

jobs:
  publish:
    uses: stone-payments/karavela-packages-workflows/.github/workflows/karavela_packages_publish.yml@main
    with:
      ecosystem: 'npm'                    # npm | pypi | nuget | maven | go
      owner_group: 'meu-time-opsgenie'
      work_dir: '.'
      build_runs_on: 'medium-runner'      # Go exige runner self-hosted; ubuntu-latest vira no-op
```

**Pré-requisito 3: Manifesto Correto**

- npm: `package.json` com `"version": "0.0.1"`
- pypi: `pyproject.toml` com `version = "0.0.1"`
- nuget: `*.csproj` com `<Version>0.1.0</Version>`
- maven: `pom.xml` ou `build.gradle.kts` com `version = "0.1.0"`
- go: `go.mod` **sem seed** — não há campo de versão; a versão vem da tag git (`module/vX.Y.Z`, `v` preservado)

**Aviso**: Se o par `(ecosystem, original_identity)` já pertence a outro time, o Portal retorna `409 Conflict`. Acione `#help-foundation-platform`.

---

## Fluxo C — Dual-Write (Migração Segura de Registry Antigo)

Use quando a biblioteca já é publicada em outro registry (npmjs.org, PyPI public, Artifactory, etc.) e você quer migrar para Karavela **sem quebrar consumidores**.

**Estratégia**: publicar nos **DOIS** destinos na mesma versão, temporariamente.

```yaml
# .github/workflows/release.yml — exemplo com release-please
name: Release

on:
  push:
    branches: [main]

permissions:
  contents: write
  pull-requests: write
  id-token: write
  attestations: write

jobs:
  release-please:
    runs-on: small-runner
    outputs:
      release_created: ${{ steps.release.outputs.release_created }}
      tag_name: ${{ steps.release.outputs.tag_name }}
      version: ${{ steps.release.outputs.version }}
    steps:
      - uses: googleapis/release-please-action@v4
        id: release
        with:
          release-type: python        # ajuste por ecossistema
          package-name: meu-pacote
          include-v-in-tag: true

  # Legado: registry antigo (ex: GitHub Release assets, PyPI public)
  publish-legacy:
    needs: release-please
    if: needs.release-please.outputs.release_created == 'true'
    runs-on: small-runner
    steps:
      - uses: actions/checkout@v4
        with: { ref: '${{ needs.release-please.outputs.tag_name }}' }
      - run: |
          # Comandos specificos do seu registry antigo
          # ex: python -m twine upload dist/*
          echo "Publishing to legacy registry..."

  # Novo: Karavela Packages — mesma versão
  publish-karavela:
    needs: release-please
    if: needs.release-please.outputs.release_created == 'true'
    uses: stone-payments/karavela-packages-workflows/.github/workflows/karavela_packages_publish.yml@main
    with:
      ecosystem: pypi
      owner_group: meu-time-opsgenie
      version: ${{ needs.release-please.outputs.version }}
      work_dir: '.'
      build_runs_on: 'medium-runner'
    secrets: inherit
```

**Fases Recomendadas**:

1. **Fase 1 — Dual-Write** (1-2 semanas): ambos os jobs rodando em paralelo
2. **Fase 2 — Validação** (1-2 semanas): consumidor piloto testa migração em staging
3. **Fase 3 — Cutover** (semanas seguintes): restante dos consumidores migra; job legado continua 1-2 releases
4. **Fase 4 — Sunset** (após estabilização): remover job legado + publicar "deprecation notice" no registry antigo

---

## Fluxo D — Monorepo Push-on-Main com Versões por Manifesto (Yarn/PNPM Workspaces)

Use quando o monorepo **gerencia versões independentes em cada `package.json`** (ex: bump manual ou via Changesets/release-please per-package) e publica a cada merge em `main`, **sem tag unificada**.

O reusable workflow suporta nativamente:

- `version` vazio → step `override-version` é pulado, cada módulo mantém a versão do próprio manifesto ([karavela_packages_publish.yml:165-172](https://github.com/stone-payments/karavela-packages-workflows/blob/main/.github/workflows/karavela_packages_publish.yml#L165-L172))
- `detect-workspace-modules` coleta `[{name, version}]` de cada `packages/*/package.json` não-privado
- Portal devolve `modules_to_publish` no `publish-plan` considerando o que já existe no Nexus
- Step `filter-already-published` remove `.tgz` de versões já publicadas antes do `npm publish` — **re-executar o workflow na mesma SHA é idempotente** ([karavela_packages_publish.yml:367](https://github.com/stone-payments/karavela-packages-workflows/blob/main/.github/workflows/karavela_packages_publish.yml#L367))
- `build-package` detecta Yarn (`yarn.lock`) ou PNPM (`pnpm-lock.yaml`) + `.workspaces` e faz `yarn workspace <pkg> pack` / `pnpm pack` por módulo não-privado

**Exemplo — adicionar como dual-write num workflow existente (`push: main`)**:

```yaml
# .github/workflows/publish.yml (trecho)
name: Publish Packages

on:
  workflow_dispatch:
  push:
    branches: [main]

jobs:
  Publish:   # job legado (GitHub Packages, npmjs.org, etc.) — inalterado
    runs-on: ubuntu-latest
    permissions:
      contents: write
      packages: write
    steps:
      # ...

  KaravelaPackagesPublish:
    name: Publish to Karavela Packages
    permissions:
      contents: read
      id-token: write
      attestations: write
    uses: stone-payments/karavela-packages-workflows/.github/workflows/karavela_packages_publish.yml@main
    with:
      ecosystem: npm            # ou pypi (uv workspace)
      owner_group: meu-time-opsgenie
      work_dir: '.'
      build_runs_on: medium-runner
      # version: ''             # omitido — usa versões dos manifestos
    secrets: inherit
```

**Importante — quando cada `package.json` já tem `publishConfig.registry`**:

Não é necessário remover — o action `publish-package` chama `npm publish <tgz> --registry <nexus-url>`, e a flag `--registry` na linha de comando sobrescreve o `publishConfig.registry` do tarball. Logo o pacote publica simultaneamente no registry antigo (via job legado) e no Nexus (via este job).

**Requisitos do monorepo para o workflow detectar automaticamente**:

- **npm/yarn/pnpm**: root `package.json` com `"workspaces": [...]` e módulos em `packages/*/` (path fixo no action)
- **pypi**: root `pyproject.toml` com `[tool.uv.workspace]` e módulos em `packages/*/`

Módulos em outros paths (ex: `apps/*/`, `libs/*/`) **não são detectados** — reestruture para `packages/` ou acione `#help-foundation-platform` para evoluir o action.

**Diferença vs Fluxo C (Dual-Write com release-please)**:

| Aspecto | Fluxo C | Fluxo D |
|---|---|---|
| Trigger | GitHub Release / tag | `push: main` |
| Versão | Vem da tag (`vX.Y.Z`) — injetada em todos manifestos | Fica nos manifestos — uma por módulo |
| Monorepo | Força todos ao mesmo número | Cada módulo evolui independente |
| Idempotência | Tag única, nunca re-executa | Re-execução skippa módulos já publicados |

---

## Troubleshooting — Tabela Completa

| Erro | Causa Provável | Solução |
|---|---|---|
| `Actor not member of owner_group` | Usuário não é membro do grupo no Backstage Catalog | Verificar membership no Portal; acionar `#help-foundation-platform` |
| `409 Conflict` no publish-plan | Par `(ecosystem, original_identity)` pertence a outro time | Renomear pacote ou acionar `#help-foundation-platform` |
| `Version already exists` | Nexus não aceita re-publicação da mesma versão | Incrementar versão no manifesto, criar nova tag/release |
| `403 Forbidden` no job `plan` | `owner_group` não existe no catalog ou não corresponde ao esperado | Conferir `owner_group` contra namespaces: `karavela`, `stone-payments`, `dlpco`, `pagarme`, `ton`, `mundipagg` |
| Publicou com versão errada | Tag fora do padrão `vX.Y.Z` (ou `vX.Y.Z-rc.N`) | Usar tag semântica com prefixo `v`; prefixo é removido automaticamente |
| `No manifest found` | Manifesto ausente em `work_dir` | Conferir `work_dir` (default `.`) |
| Workflow não disparou após `git push v1.0.0` | Tag final pushada direto no git (não dispara — esperado via GitHub Release) | Criar GitHub Release apontando para a tag, ou usar tag pré-release (`v*-rc.*`, `v*-beta.*`, `v*-alpha.*`) |
| `Publish failed, Plan passed` (status `PUBLISH_FAILED`) | Erro no build ou publish | Corrigir e republicar; status reseta automaticamente `PUBLISH_FAILED` → `PENDING` |
| `OIDC response has no .value field` | `permissions.id-token: write` faltando ou rodando em fork | Adicionar permission; forks bloqueiam OIDC por padrão |
| Vulnerabilidade Critical reportada pelo Grype | Scan SCA é informacional, não bloqueia o publish; persiste no DT/SCA snapshot | Avaliar/atualizar a dependência mesmo assim; aprofundar com skill `seguranca` |
| `401 Unauthorized` no `npm install` local | Apontando para `-hosted` (privado) em vez de `-group` (público) | Usar sempre `https://packages.stone.tech/repository/<eco>-group/` |
| `401 Unauthorized` no `npm install` em CI/app | `permissions: id-token: write` ausente ou `USE_KARAVELA_PACKAGES` off | Adicionar permission; ativar `USE_KARAVELA_PACKAGES: true` no `karavela_build.yml` |
| Monorepo — módulo não publicado | Módulo não listado na config de workspaces | npm: `"workspaces"` em `package.json`; pypi: `[tool.uv.workspace]`; nuget: `.sln`; maven: `include(…)`; go: múltiplos `go.mod` / `go.work` (1 invocação por módulo, tag `module/vX.Y.Z`, orquestrada pelo caller) |
| Docker build `unknown instruction: mount` | Falta `# syntax=docker/dockerfile:1` no topo | Adicionar como primeira linha do Dockerfile |

---

## Instruções MCP — Onde Buscar Detalhes

Quando o usuário precisar de informações além do conhecimento embutido, busque nestes repositórios:

| Repositório | Arquivo/Caminho | Quando Buscar |
|---|---|---|
| `stone-payments/karavela-core` | `plugins/karavela-packages/docs/index.md` | Visão geral, URLs de repositórios, ecossistemas |
| `stone-payments/karavela-core` | `plugins/karavela-packages/docs/conceitos-basicos.md` | Normalizacao, RBAC, ciclo de vida |
| `stone-payments/karavela-core` | `plugins/karavela-packages/docs/criando-pacotes/` | Guia de criacao por ecossistema |
| `stone-payments/karavela-core` | `plugins/karavela-packages/docs/publicando-versoes/fluxo-publicacao.md` | Fluxo exato do workflow (plan/build/publish/confirm), version override |
| `stone-payments/karavela-core` | `plugins/karavela-packages/docs/publicando-versoes/pre-release.md` | Scripts pré-release, tags `v*-rc.*` / `v*-beta.*` / `v*-alpha.*` |
| `stone-payments/karavela-core` | `plugins/karavela-packages/docs/consumindo-pacotes/` | Consumo local (público), configuracao por ecossistema |
| `stone-payments/karavela-core` | `plugins/karavela-packages/docs/consumindo-pacotes/ci-cd.md` | OIDC secretless, org vars, `setup-consumer` |
| `stone-payments/karavela-core` | `plugins/karavela-packages/docs/consumindo-pacotes/docker.md` | BuildKit secrets, Dockerfile por ecossistema |
| `stone-payments/karavela-core` | `plugins/karavela-packages/docs/erros-comuns.md` | Troubleshooting detalhado |
| `stone-payments/karavela-packages-workflows` | `.github/workflows/karavela_packages_publish.yml` | Inputs, outputs, fases do workflow |
| `stone-payments/karavela-packages-workflows` | `actions/build-package/action.yml` | Detecção automática monorepo, build por ecossistema |
| `stone-payments/karavela-packages-workflows` | `actions/override-version/action.yml` | Como versão da tag é injetada |
| `stone-payments/karavela-packages-workflows` | `actions/setup-consumer/action.yml` | Consumo: Yarn Berry, NuGet v2/v3, outputs |
| `stone-payments/karavela-packages-workflows` | `actions/request-consumer-token/action.yml` | OIDC flow para ephemeral tokens |
| `stone-payments/platform-k8s-github-actions` | `.github/workflows/karavela_build.yml` | Como apps integram `USE_KARAVELA_PACKAGES: true` |
| `stone-payments/gen-ai-sdk` | `.github/workflows/release-python.yml` | Referência viva: dual-write + release-please |

---

## Formato de Resposta Esperado

Ao responder perguntas deste domínio, siga este padrão:

1. **Explicação** (2-3 frases objetivas)
2. **Exemplo prático** (YAML, comando ou config copiável)
3. **Fonte** (referência ao arquivo em `stone-payments/karavela-core/plugins/karavela-packages/docs/` ou `stone-payments/karavela-packages-workflows/`)
4. **Avisos** (se aplicável):
   - Requer privilégio de produção
   - Exige acionar `#help-foundation-platform`
   - Mudança de `owner_group` (irreversível ou complexa)
   - Ação irreversível
   - **Nunca** sugerir ou expor credenciais/tokens/secrets
   - Lembre que consumo local é **público** e CI/CD é **OIDC secretless**

---
name: ci-mutation-testing-golang
description: "Testes de mutacao para projetos Go (Golang) usando o workflow reutilizavel golang-mutanting. Use quando o usuario perguntar sobre como adicionar testes de mutacao em Go, configurar o go-mutesting, o arquivo .mutation.yml, integrar com o workflow reutilizavel, stone_payments_app_id, GH_APP_PRIVATE_KEY, diff_mode ou relatorios de mutacao em Go."
---

# Skill: Mutation Testing — Go / go-mutesting

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.
-->

## Escopo

**Cobre**:
- Como incorporar o workflow `golang-mutanting` em um projeto Go
- Pre-requisitos obrigatorios: arquivo `.mutation.yml` e acesso ao GitHub App (`stone_payments_app_id` + `GH_APP_PRIVATE_KEY`)
- Inputs do workflow (`diff_mode`, `runs_on`, `stone_payments_app_id`)
- Secrets obrigatorios (`GH_APP_PRIVATE_KEY`)
- O que e MSI e como o relatorio e gerado
- Diferenca entre `diff_mode: changed` (so arquivos `.go` alterados) e `diff_mode: total` (`./...`)
- Geracao de relatorio HTML, SARIF e Markdown via composite action `go-mutation-report`
- Comentario automatico na PR com o conteudo do `report.md`
- Por que o Go mutanting exige o GitHub App (acesso a modulos privados stone-payments)

**NAO cobre**:
- Escrita de testes Go
- Configuracao avancada de mutators do go-mutesting
- Provisionamento do GitHub App ou configuracao de IRSA para acesso privado
- Infraestrutura de Kafka (o golang-mutanting nao envia ao Kafka — diferente dos outros CIs de mutacao)

## Exemplos de Perguntas

- "Como adiciono testes de mutacao no meu projeto Go?"
- "Quais pre-requisitos meu projeto Go precisa para usar o golang-mutanting?"
- "O que e o arquivo .mutation.yml?"
- "Por que preciso do stone_payments_app_id para o golang-mutanting?"
- "Como funciona o diff_mode: changed para Go?"
- "O workflow Go de mutacao gera relatorio HTML ou SARIF?"
- "O golang-mutanting envia metricas para o Kafka?"
- "Como autentico com modulos privados Go da stone-payments?"

## Conhecimento Embutido

### Localizacao do Workflow

```
stone-payments/github-actions-workflows
  .github/workflows/golang-mutanting.yml
```

> **Atencao:** O golang-mutanting ainda nao tem tag de versao semantica publicada. Use `@main` para referenciar a versao mais recente.
> Verifique com o time de Platform se ha uma tag estavel disponivel antes de usar em producao.

---

### Diferencas em Relacao aos Outros CIs de Mutacao

| Aspecto | golang-mutanting | csharp/nodejs/python/kotlin |
|---------|------------------|-----------------------------|
| Ferramenta | go-mutesting (avito-tech) | Stryker / cosmic-ray / Pitest |
| GitHub App | **Obrigatorio** | Nao necessario |
| Envio ao Kafka | **Nao envia** | Envia (opcional) |
| Threshold MSI via input | Nao disponivel | Disponivel via `threshold` |
| Formato de report | HTML + SARIF + Markdown | JSON normalizado |
| Versao semantica | Nao publicada (usa `@main`) | Sim (`@*-v0`) |

---

### Pre-requisitos

#### 1. Arquivo `.mutation.yml` no Projeto

O workflow usa `go-mutesting --config .mutation.yml`. Crie esse arquivo na raiz do repositorio:

```yaml
# .mutation.yml — configuracao do go-mutesting
options:
  verbose: false
  # Opcional: excluir pacotes de testes ou mocks
  do-not-exec: false

# Pacotes a excluir das mutacoes
exclude:
  - "*_test.go"
  - "*/mock*"
  - "*/gen/*"
```

> A estrutura exata do `.mutation.yml` depende da versao do go-mutesting. Consulte a documentacao do [avito-tech/go-mutesting](https://github.com/avito-tech/go-mutesting) para opcoes atualizadas.

#### 2. GitHub App com Acesso a stone-payments

O workflow precisa de um GitHub App para acessar modulos privados Go da organizacao stone-payments. Dois inputs/secrets sao **obrigatorios**:

- `stone_payments_app_id` (input obrigatorio): ID do GitHub App
- `GH_APP_PRIVATE_KEY` (secret obrigatorio): Chave privada do GitHub App

O workflow usa esses dados para:
1. Gerar um token via `actions/create-github-app-token@v1`
2. Configurar o `git config` para redirecionar URLs `github.com/stone-payments/*` pelo token

---

### Como Integrar o Workflow

#### Uso Minimo

```yaml
# .github/workflows/ci.yml
jobs:
  mutation:
    uses: stone-payments/github-actions-workflows/.github/workflows/golang-mutanting.yml@main
    with:
      stone_payments_app_id: ${{ vars.STONE_PAYMENTS_APP_ID }}
    secrets:
      GH_APP_PRIVATE_KEY: ${{ secrets.GH_APP_PRIVATE_KEY }}
```

#### Com diff_mode: total

```yaml
jobs:
  mutation:
    uses: stone-payments/github-actions-workflows/.github/workflows/golang-mutanting.yml@main
    with:
      stone_payments_app_id: ${{ vars.STONE_PAYMENTS_APP_ID }}
      diff_mode: total
    secrets:
      GH_APP_PRIVATE_KEY: ${{ secrets.GH_APP_PRIVATE_KEY }}
```

#### Com Runner Customizado

```yaml
jobs:
  mutation:
    uses: stone-payments/github-actions-workflows/.github/workflows/golang-mutanting.yml@main
    with:
      stone_payments_app_id: ${{ vars.STONE_PAYMENTS_APP_ID }}
      runs_on: "['large-runner']"
    secrets:
      GH_APP_PRIVATE_KEY: ${{ secrets.GH_APP_PRIVATE_KEY }}
```

---

### Inputs Disponiveis

| Input | Tipo | Obrigatorio | Descricao | Padrao |
|-------|------|-------------|-----------|--------|
| `runs_on` | string (JSON) | nao | Runner a usar | `"['ubuntu-22.04']"` |
| `diff_mode` | string | nao | `"changed"` (so `.go` alterados) ou `"total"` (`./...`) | `"changed"` |
| `stone_payments_app_id` | string | **sim** | ID do GitHub App para acessar modulos privados stone-payments | — |

### Secrets

| Secret | Obrigatorio | Descricao |
|--------|-------------|-----------|
| `GH_APP_PRIVATE_KEY` | **sim** | Chave privada do GitHub App |

> **Nota de seguranca**: `GH_APP_PRIVATE_KEY` deve ser armazenado como GitHub Secret do repositorio ou da organizacao. Nunca commite a chave privada.

---

### O que o Workflow Faz (Passo a Passo)

1. **Checkout** com `fetch-depth: 0`
2. **Setup do Go** na versao `stable`
3. **Obtencao do token** via `actions/create-github-app-token@v1` usando o GitHub App
4. **Configuracao do credential store** para redirecionar `github.com/stone-payments/*` pelo token gerado
5. **Instalacao do go-mutesting** via `go install github.com/avito-tech/go-mutesting/cmd/go-mutesting@master`
6. **Deteccao de arquivos `.go` alterados** (quando `diff_mode: changed`)
   - Se nenhum arquivo `.go` foi alterado: pula a execucao
7. **Execucao do go-mutesting**:
   - `changed`: `go-mutesting --config .mutation.yml <arquivos .go alterados>`
   - `total`: `go-mutesting --config .mutation.yml ./...`
8. **Geracao de relatorio** via composite action `go-mutation-report`:
   - `reports/mutation-report.html` — relatorio HTML
   - `reports/mutation-report.sarif` — formato SARIF (para GitHub Security)
   - `reports/report.md` — Markdown para comentario na PR
9. **Upload do artefato** `mutation-report-html`
10. **Comentario na PR** com o conteudo do `report.md`

> **Atencao**: O golang-mutanting **nao envia metricas para coleta externa** e nao tem suporte ao `threshold` de MSI via input. O controle de qualidade e feito pelo comentario na PR e pelo artefato gerado.

---

### environment: testing

O job usa `environment: testing` do GitHub Actions, o que pode exigir aprovacao manual dependendo da configuracao do repositorio. Se o workflow trava aguardando aprovacao, verifique as configuracoes do environment `testing` no GitHub.

---

### Relatorio Gerado

O workflow gera tres formatos de relatorio:

| Formato | Arquivo | Uso |
|---------|---------|-----|
| HTML | `reports/mutation-report.html` | Visualizacao detalhada (artefato do job) |
| SARIF | `reports/mutation-report.sarif` | Integracao com GitHub Security (comentado no workflow — opcional) |
| Markdown | `reports/report.md` | Comentario automatico na PR |

---

## Instrucoes MCP

Quando precisar de detalhes alem do conhecimento embutido, busque nos seguintes repositorios (nesta ordem de prioridade):

| Repositorio | Caminho | Quando buscar |
|-------------|---------|---------------|
| `stone-payments/karavela` | `docs/` | Padroes da plataforma (nao cobre mutation testing diretamente) |
| `stone-payments/github-actions-workflows` | `.github/workflows/golang-mutanting.yml` | Implementacao do workflow reutilizavel, inputs e steps |
| Externo (complemento — nao em docs/) | [avito-tech/go-mutesting](https://github.com/avito-tech/go-mutesting) | Configuracao avancada do go-mutesting, mutators |

> Todo o conhecimento desta skill e **complemento** ao docs/ da plataforma — ela nao tem secao dedicada a mutation testing.

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Criar `.mutation.yml`** na raiz do projeto com diff_mode, excludes, threshold
- **Criar `.github/workflows/mutation.yml`** apontando para `golang-mutanting.yml@main`
- **Adicionar secrets `stone_payments_app_id` + `GH_APP_PRIVATE_KEY`** para acesso a modulos privados (orientar via GitHub Settings)
- **Abrir PR draft**

### Triggers proativos
- "Adicionar mutation testing Go" → `🛠️ Acao proposta: crio .mutation.yml + workflow + abro PR`

### Acoes destrutivas
- N/A.

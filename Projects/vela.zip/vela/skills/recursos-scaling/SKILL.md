---
name: recursos-scaling
description: "Configuracao de CPU, memoria, replicas e autoscaling com KEDA na plataforma Karavela. Use quando o usuario perguntar sobre resources, limits, requests, autoscaling, KEDA scalers, replicas, dimensionamento de aplicacoes, Elasticache/Valkey, RDS storage ou canary strategy."
---

# Skill: recursos-scaling

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.

  Exemplos de uso:
  - Corrigir informacao desatualizada no conhecimento embutido
  - Adicionar restricao temporaria (ex: "chart v4 nao suporta feature X")
  - Adicionar conhecimento que ainda nao esta na documentacao oficial
  - Bloquear uma orientacao especifica (ex: "NAO recomende usar scaler Y")
-->

## Escopo

**Cobre**:
- Configuracao de CPU e memoria (bloco `resources` no values.yaml)
- Diferenca entre requests e limits (o chart usa um unico valor que serve como request e limit)
- Configuracao de replicas (`replicaCount`)
- Autoscaling com KEDA (CPU, memoria, Kafka, SQS, RabbitMQ, Datadog, Azure Service Bus, Azure Event Hub)
- Configuracao de `autoscaling` no values.yaml para charts de API e Worker
- Scalers suportados pela plataforma
- Elasticache (Valkey) — configuracao, modo Standard e break glass
- RDS — `maxAllocatedStorage` (autoscaling de storage) e migracao de storage type io1 para gp3
- Canary strategy — interacao entre `dynamicStableScale` e KEDA/autoscaling
- SecurityContext sysctls (TCP keepalive tuning em todos os charts: API, Worker, CronJob, Job, StatefulSet)
- StageStop — desligamento automatico de aplicacoes em staging fora do horario comercial

**NAO cobre**:
- Estrutura de charts / padrao umbrella (coberto por `charts-config`)
- Fluxos de deploy e rollback (coberto por `deploy-rollback`)
- Metricas de observabilidade e monitoramento (coberto por `observabilidade`)

## Exemplos de Perguntas

- "Como configuro CPU e memoria da minha aplicacao no values.yaml?"
- "Como habilito o autoscaling para minha aplicacao escalar por consumo de CPU?"
- "Como faco meu worker escalar baseado no lag de um topico Kafka?"
- "Quais sao os scalers suportados pelo KEDA na plataforma?"
- "Como configuro autoscaling por fila SQS para meu worker?"
- "Qual a diferenca de recursos padrao entre o chart de API e o chart de Worker?"
- "Como escalo minha aplicacao com base em metricas do Datadog?"
- "Como configuro Elasticache/Valkey na plataforma?"
- "O que e o campo numberCacheCluster no Elasticache?"
- "Como habilito o autoscaling de storage no RDS com maxAllocatedStorage?"
- "Meu RDS usa io1, o que acontece agora?"
- "O que acontece com o autoscaling quando configuro replicaCount: 0?"
- "Como funciona o dynamicStableScale no canary com KEDA?"

## Conhecimento Embutido

### Configuracao de Recursos (CPU e Memoria)

O bloco `resources` no `values.yaml` define a quantidade de CPU, memoria e storage alocados para o container da aplicacao. Os valores padrao diferem entre o chart de API e o chart de Worker.

**Valores padrao no chart de API** (`platform-k8s-api-chart`):

```yaml
resources:
  memory: "500Mi"
  cpu: "1"
  storage: "1Gi"
```

**Valores padrao no chart de Worker** (`platform-k8s-worker-chart`):

```yaml
resources:
  memory: "256Mi"
  cpu: "128m"
  storage: "1Gi"
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/resources.md`; `platform-k8s-charts/*/values.yaml` (complemento — nao em docs/) para valores default

### Replicas

O campo `replicaCount` define a quantidade inicial de replicas da aplicacao. O valor padrao em ambos os charts (API e Worker) e `1`.

```yaml
replicaCount: 1 # Initial replicas count
```

Para ambientes que nao sejam Staging, recomenda-se ter pelo menos duas replicas para garantir redundancia e tolerancia a falhas.

**Comportamento com `replicaCount: 0`**: Quando o `replicaCount` e configurado como `0`, o autoscaling e automaticamente desabilitado. Isso e util para desligar completamente uma aplicacao em determinado ambiente (ex: pre-prod ou staging). Nao e necessario desabilitar o autoscaling manualmente — a plataforma detecta `replicaCount: 0` e desativa o KEDA automaticamente.

**Fonte**: `karavela/docs/usando_karavela.md` (secao "Se nao for Staging, tenha pelo menos duas replicas"), `karavela/docs/guia-do-desenvolvedor/funcionalidades/replica-count.md`

### Autoscaling com KEDA - Visao Geral

No Karavela, o autoscaling utiliza o KEDA (Kubernetes Event-Driven Autoscaler), uma ferramenta de codigo aberto para escalonar aplicacoes em clusters Kubernetes com base em eventos.

Por padrao, a aplicacao vem configurada para escalar caso atinja 80% de utilizacao em CPU ou memoria.

```yaml
autoscaling:
  enabled: true
  maxReplicas: 10
  cpu:
    # doc ref: https://keda.sh/docs/2.9/scalers/cpu/
    target: "80"
    metricType: Utilization
  memory:
    # doc ref: https://keda.sh/docs/2.9/scalers/memory/
    target: "80"
    metricType: Utilization
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/autoscaling.md`

> **Nota**: A documentacao oficial em `autoscaling.md` lista os scalers Datadog, Kafka, SQS, RabbitMQ e Azure Service Bus. Esta skill complementa com Azure Service Bus List e Azure Event Hub, disponiveis via valores do chart.

### Scalers Suportados

A plataforma suporta os seguintes scalers do KEDA para escalonamento baseado em eventos:

- **Datadog** - escalona com base em metricas customizadas do Datadog
- **Kafka** - escalona com base no lag de consumer groups
- **SQS** - escalona com base no tamanho de filas AWS SQS
- **RabbitMQ** - escalona com base em filas RabbitMQ
- **Azure Service Bus** - escalona com base em filas ou topicos do Azure Service Bus
- **Azure Event Hub** - escalona com base em eventos nao processados no Azure Event Hub

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/autoscaling.md`

### Scaler Kafka

Para escalar um worker com base no lag de um topico Kafka, configure o bloco `autoscaling.kafka` no `values.yaml`. O campo `consumerGroup` deve ser o mesmo nome do consumer group que consome o topico.

```yaml
autoscaling:
  enabled: true
  maxReplicas: 10
  kafka:
    # doc ref: https://keda.sh/docs/2.9/scalers/apache-kafka/
    bootstrapServers: "kafka-broker:9092"
    consumerGroup: "meu-consumer-group"
    topic: "meu-topico"
    pollingInterval: "30"
    # Optional
    lagThreshold: "10"
    offsetResetPolicy: "latest"
    activationLagThreshold: ""
    allowIdleConsumers: ""
    scaleToZeroOnInvalidOffset: ""
    excludePersistentLag: ""
    version: ""
    partitionLimitation: ""
    # se precisar usar TLS, defina como true
    tls: false
    # se precisar de CA e cert, defina como true. Voce precisa criar 3 secrets (KAFKA_CA, KAFKA_CERT e KAFKA_KEY)
    caAndCert: false
    # se escolher esta opcao, voce precisa criar 2 secrets (KAFKA_USERNAME e KAFKA_PASSWORD)
    sasl: ""
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/autoscaling.md` (secao Scalers); `platform-k8s-charts/platform-k8s-api-chart/values.yaml` (complemento — nao em docs/) para opcoes avancadas

### Scaler SQS

Para escalar com base no tamanho de uma fila AWS SQS, e necessario criar uma IRSA com as permissoes adequadas antes de usar e definir `autoscaling.withSecrets = true`.

```yaml
autoscaling:
  enabled: true
  maxReplicas: 10
  sqs:
    # Requer IRSA com permissoes adequadas e autoscaling.withSecrets = true
    # doc ref: https://keda.sh/docs/2.9/scalers/aws-sqs/
    queueURL: "https://sqs.us-east-1.amazonaws.com/123456789/minha-fila"
    queueLength: "5"
    awsRegion: "us-east-1"
    # Optional
    scaleOnInFlight: ""
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/autoscaling.md`; `platform-k8s-charts/platform-k8s-worker-chart/values.yaml` (complemento — nao em docs/)

### Scaler Datadog

Para escalar com base em metricas do Datadog, e necessario criar secrets `apiKey` e `appKey` e definir `autoscaling.withSecrets = true`.

```yaml
autoscaling:
  enabled: true
  maxReplicas: 10
  datadog:
    # Requer criacao de secrets apiKey e appKey e autoscaling.withSecrets = true
    # doc ref: https://keda.sh/docs/2.9/scalers/datadog/
    metricType: "Value"
    query: "avg:system.cpu.user{service:minha-app}"
    queryValue: "80"
    # Optional
    age: ""
    metricUnavailableValue: ""
    queryAggregator: ""
    timeWindowOffset: ""
    lastAvailablePointOffset: ""
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/autoscaling.md`; `platform-k8s-charts/platform-k8s-api-chart/values.yaml` (complemento — nao em docs/)

### Scaler RabbitMQ

Para escalar com base em filas RabbitMQ, e necessario criar o secret `rabbitHost` e definir `autoscaling.withSecrets = true`. Suporta protocolo AMQPS para conexoes seguras.

```yaml
autoscaling:
  enabled: true
  maxReplicas: 10
  rabbitmq:
    # doc ref: https://keda.sh/docs/2.9/scalers/rabbitmq-queue/
    protocol: amqp  # ou amqps para conexoes seguras
    queueName: "minha-fila"
    mode: "QueueLength"
    value: "5"
    # Optional
    metricName: ""
    tls: true
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/autoscaling.md`; `platform-k8s-charts/platform-k8s-api-chart/values.yaml`, `CHANGELOG.api.md` (v1.21.0) (complemento — nao em docs/)

### Scaler Azure Service Bus

Para escalar com base em filas ou topicos do Azure Service Bus, configure o bloco `autoscaling.azureServiceBus`. E possivel usar `queueName` para filas ou `topicName` + `subscriptionName` para topicos.

```yaml
autoscaling:
  enabled: true
  maxReplicas: 10
  azureServiceBus:
    # doc ref: https://keda.sh/docs/2.11/scalers/azure-service-bus/
    # obrigatorio: queueName OU topicName + subscriptionName
    queueName: "minha-fila"
    # ou
    # topicName: "meu-topico"
    # subscriptionName: "minha-subscription"
    # Optional, obrigatorio quando pod identity e utilizado
    namespace:
    # Se true, o scaler usa a connection string da env var SERVICEBUS_CONNECTIONSTRING
    # Voce precisa criar um secret com a chave: SERVICEBUS_CONNECTIONSTRING
    connectionFromEnv: false
    # Optional
    messageCount: "5"
    activationMessageCount:
    cloud: # Private # Optional. Default: AzurePublicCloud
    endpointSuffix: # Obrigatorio quando cloud=Private
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/autoscaling.md`; `platform-k8s-charts/platform-k8s-api-chart/values.yaml` (complemento — nao em docs/)

### Azure Service Bus List (Multiplos Triggers)

Para cenarios que necessitam escalar com base em multiplos topicos ou filas do Azure Service Bus simultaneamente, utilize o bloco `autoscaling.azureServiceBusList`.

```yaml
autoscaling:
  enabled: true
  maxReplicas: 10
  azureServiceBusList:
    authTrigger:
      - name: "scoring-trigger"
        connectionString: "connection-string-scoring"
      - name: "payments-trigger"
        connectionString: "connection-string-payments"
    topics:
      - name: "scoring-topic"
        topicName: "scoring-events"
        subscriptionName: "my-subscription"
        messageCount: "5"
        authTriggerName: "scoring-trigger"
      - name: "payments-topic"
        topicName: "payment-events"
        subscriptionName: "payment-sub"
        messageCount: "10"
        authTriggerName: "payments-trigger"
    queues:
      - name: "webhook-queue"
        queueName: "webhook-events"
        messageCount: "3"
        authTriggerName: "scoring-trigger"
```

**Fonte**: `platform-k8s-charts/platform-k8s-api-chart/values.yaml` (complemento — nao em docs/; funcionalidade avancada ainda nao documentada em docs/)

### Scaler Azure Event Hub

Para escalar com base em eventos nao processados no Azure Event Hub:

```yaml
autoscaling:
  enabled: true
  maxReplicas: 10
  azureEventHub:
    # doc ref: https://keda.sh/docs/2.16/scalers/azure-event-hub/
    # Obrigatorio se nao usar Pod Identity
    connectionFromEnv: "EVENTHUB_CONNECTION"
    # Obrigatorio
    storageConnectionFromEnv: "STORAGE_CONNECTION"
    # Optional
    consumerGroup: "$Default"
    unprocessedEventThreshold: "64"
    activationUnprocessedEventThreshold:
    blobContainer: "checkpoints"
    eventHubNamespace:
    eventHubName:
    storageAccountName:
    checkpointStrategy:
    cloud: # Optional (Default: AzurePublicCloud)
    endpointSuffix: # Obrigatorio quando cloud=Private
    storageEndpointSuffix: # Obrigatorio quando cloud=Private
    # Novos sub-campos: permitem referenciar namespace e hub name diretamente de env vars
    eventHubNamespaceFromEnv: # Nome da env var que contem o namespace do Event Hub
    eventHubNameFromEnv: # Nome da env var que contem o nome do Event Hub
```

Os campos `eventHubNamespaceFromEnv` e `eventHubNameFromEnv` permitem que o namespace e o nome do Event Hub sejam lidos diretamente de variaveis de ambiente, em vez de serem definidos como valores estaticos. Isso e util em cenarios onde os valores variam entre ambientes e ja estao configurados como env vars no pod.

**Fonte**: `platform-k8s-charts/platform-k8s-worker-chart/values.yaml` (complemento — nao em docs/; ainda nao coberto em docs/autoscaling.md)

### Elasticache (Valkey)

O recurso anteriormente chamado "Redis" foi renomeado para **Elasticache**. A oferta atual e **Valkey** (substituindo Redis) e opera no modo **Standard** (anteriormente chamado "Standalone").

**Mudancas principais**:
- **Nome do recurso**: Redis → Elasticache
- **Oferta**: Redis → Valkey
- **Modo**: Standalone → Standard

**Campo `numberCacheCluster`**: O campo `numberCacheCluster` agora e editavel no Portal. Anteriormente, esse valor era fixo e nao podia ser alterado pelo usuario. Agora e possivel ajustar a quantidade de cache clusters diretamente pela interface do Portal.

**Break glass**: Elasticache agora possui permissoes de break glass. Isso significa que, em situacoes de emergencia, o time tem acesso direto ao recurso para realizar operacoes manuais que normalmente seriam bloqueadas pela plataforma.

**Campo `additionalUsers` (via Portal)**: E possivel conceder acesso ao ElastiCache para multiplas aplicacoes. Pela tela de detalhe do ElastiCache no Portal, adicione as aplicacoes adicionais no campo "Usuarios adicionais". Cada nome de aplicacao recebe um usuario dedicado com senha propria. O valor default e lista vazia.

O Portal do Karavela tambem exibe um select preenchido via API (ao inves de campo de texto livre) para associar recursos ElastiCache existentes, reduzindo erros de digitacao.

**Tipo de acesso**: A selecao de access type ao vincular um ElastiCache e agora suportada no Portal, permitindo escolher o nivel de permissao adequado para a aplicacao.

**Portal: selects por API para recursos AWS**: Ao associar recursos AWS na pagina de recursos da aplicacao no Portal, os campos de nome para **ElastiCache**, **S3** e **SQS** sao agora dropdowns preenchidos automaticamente via API (ao inves de campos de texto livre). As opcoes carregam ao selecionar o ambiente. O comportamento ao salvar e identico ao anterior.

**Fonte**: Portal Karavela (aba Resources); `platform-k8s-crossplane/manifests/xrds/aws/elasticache.yaml` (complemento — nao em docs/)

### RDS — `maxAllocatedStorage` (Autoscaling de Storage)

O novo campo `maxAllocatedStorage` permite habilitar o autoscaling de storage da AWS para instancias RDS. Quando configurado, a AWS aumenta automaticamente o tamanho do storage quando o espaco disponivel fica baixo, ate o limite definido por `maxAllocatedStorage`.

Exemplo de uso: se o `allocatedStorage` e `100` (GB) e o `maxAllocatedStorage` e `500` (GB), a AWS escala o disco automaticamente conforme necessario, sem necessidade de intervencao manual.

**Aviso**: O autoscaling de storage da AWS so aumenta o disco — nao reduz. Uma vez que o disco cresce, nao e possivel diminui-lo sem recriar a instancia.

### RDS — Migracao de Storage Type io1 para gp3

O storage type `io1` em instancias RDS e agora automaticamente convertido para `gp3`. Se sua aplicacao utiliza `io1`, nao e necessaria nenhuma acao manual — a conversao acontece de forma automatica pela plataforma.

O tipo `gp3` oferece melhor custo-beneficio na maioria dos cenarios, com desempenho baseline de 3000 IOPS e 125 MB/s de throughput inclusos, sem custo adicional por IOPS provisionadas.

### Canary Strategy — `dynamicStableScale` e KEDA

O campo `canaryStrategy.dynamicStableScale` controla como o Argo Rollouts gerencia as replicas do stable ReplicaSet durante um deploy canary. Por padrao, `dynamicStableScale` e `true`.

**Interacao com KEDA/Autoscaling**: Quando `dynamicStableScale: true` (padrao), o Argo Rollouts ajusta dinamicamente o numero de replicas do stable ReplicaSet com base no peso do canary. Isso **evita a duplicacao de replicas** durante um deploy canary quando KEDA ou autoscaling esta habilitado.

Sem `dynamicStableScale`, ao iniciar um canary com autoscaling ativo, o stable manteria o numero total de replicas ao mesmo tempo que o canary cria novas replicas, resultando em potencialmente o dobro de pods rodando simultaneamente.

```yaml
canaryStrategy:
  dynamicStableScale: true # padrao — evita duplicacao de replicas com KEDA
```

**Exemplo pratico**: Se a aplicacao tem 4 replicas via KEDA e o canary esta em 25%, com `dynamicStableScale: true` o stable tera ~3 replicas e o canary ~1, totalizando ~4 replicas. Sem essa flag, o stable manteria 4 e o canary adicionaria 1, totalizando 5.

### SecurityContext Sysctls (TCP Keepalive)

Todos os charts (API, Worker, CronJob, Job, StatefulSet) incluem valores padrao de TCP keepalive via `securityContext.sysctls`, aplicados em **todos os ambientes** (staging, sandbox e production). Esses parametros ajudam a detectar conexoes TCP mortas mais rapidamente, especialmente para aplicacoes que mantem conexoes persistentes com bancos de dados ou caches.

```yaml
securityContext:
  sysctls:
    - name: net.ipv4.tcp_keepalive_time
      value: "60"     # tempo idle antes de enviar o primeiro keepalive probe
    - name: net.ipv4.tcp_keepalive_intvl
      value: "10"     # intervalo entre probes
    - name: net.ipv4.tcp_keepalive_probes
      value: "6"      # numero de probes antes de considerar a conexao morta
```

Para desabilitar os sysctls, sobrescreva com lista vazia: `securityContext.sysctls: []`.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/security-context.md`; `platform-k8s-charts/.docs/changelogs/CHANGELOG.api.md` (v1.38.0), `CHANGELOG.worker.md` (v1.30.0) (complemento — nao em docs/)

### PodDisruptionBudget (PDB)

O PDB e habilitado por padrao em ambos os charts (API e Worker) e garante que uma porcentagem minima de pods permaneca disponivel durante disrupcoes.

```yaml
pdb:
  enabled: true
  # doc ref: https://kubernetes.io/docs/tasks/run-application/configure-pdb/
  minAvailable: 50%
  maxUnavailable: # 1
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/pdb.md`

### StageStop — Desligamento Automatico de Staging

O **StageStop** desliga automaticamente aplicacoes em ambientes de **staging** fora do horario comercial e nos finais de semana, gerando uma reducao de aproximadamente 64% no consumo de recursos em staging.

**Horarios de operacao** (timezone `America/Sao_Paulo`):
- **Segunda a Sexta**: Liga as 06:55 / Desliga as 20:05
- **Sabado e Domingo**: Desligado o dia todo

**Como funciona**:
1. Desativa o auto-sync do ArgoCD a nivel de projeto
2. Escala Rollouts, StatefulSets, CronJobs e ScaledObjects (KEDA) para 0 replicas
3. Salva o numero original de replicas em um Secret no namespace para restauracao

**Como ativar**: Adicione a annotation no `values-stg.yaml`:

```yaml
platform-k8s-api-chart:
  annotations:
    stagestop.karavela.run/sleep: "enabled"
```

**Como desativar permanentemente** (para apps que precisam rodar 24/7 em staging):

```yaml
annotations:
  stagestop.karavela.run/sleep: "disabled"
```

**Deploy fora do horario**: Altere para `disabled`, faca o deploy, e volte para `enabled` apos concluir.

> **IMPORTANTE**: A desativacao do sync do ArgoCD e feita a nivel de **projeto**. Se voce possui um monorepo com multiplas aplicacoes de staging no mesmo projeto, todas as apps daquele projeto serao afetadas. O scale down, porem, e individual por aplicacao.

> **NOTA**: CronJobs noturnos em staging serao pausados com StageStop ativo. Se necessario, desative com a annotation `disabled`.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/stagestop.md`

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever; producao exige dupla confirmacao. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Editar `chart/values-*.yaml`** — `resources` (memory/cpu/storage), `replicaCount`, `autoscaling` (KEDA cpu/memory/kafka/sqs/rabbitmq/datadog/azure-service-bus), `canaryStrategy`
- **Configurar `autoscaling.withSecrets: true`** quando scaler precisa de credenciais
- **Adicionar KEDA scalers** com bootstrapServers/queueURL/etc
- **Abrir PR draft** com a mudanca

### Triggers proativos
- "OOM Killed" → propor aumento de `resources.memory` baseado nos logs
- "Escalar worker baseado em fila SQS" → propor `autoscaling.sqs` + `withSecrets: true` + IRSA
- "Canary deploy" → propor `canaryStrategy.dynamicStableScale: true` no values

### Acoes destrutivas (dupla confirmacao)
- Reduzir `resources` em prd — pode causar OOM ou throttle. Confirmar duas vezes.
- Desabilitar autoscaling em prd — workload pode ficar sub/super-dimensionado. Confirmar.

## Instrucoes MCP

Quando você ainda não estiver certeza da resposta use o GITHUB mcp. Priorize a documentacao oficial em `stone-payments/karavela` `docs/`; outros repositorios servem apenas como fallback.

**Fontes primarias (docs/):**

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/funcionalidades/autoscaling.md` | Autoscaling, scalers suportados e exemplos de configuracao |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/funcionalidades/resources.md` | Configuracao de CPU, memoria e storage |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/funcionalidades/replica-count.md` | replicaCount e comportamento com `0` |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/funcionalidades/canary-deploy.md` | Canary strategy com KEDA |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/funcionalidades/stagestop.md` | StageStop (desligamento automatico de staging) |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/funcionalidades/pdb.md` | PodDisruptionBudget |
| `stone-payments/karavela` | `docs/usando_karavela.md` | Orientacoes gerais sobre replicas e autoscaling |

**Fontes secundarias (complemento — nao em docs/):**

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/platform-k8s-charts` | `platform-k8s-api-chart/values.yaml` (e demais charts) | Schema completo dos blocos `autoscaling`, `resources`, `replicaCount`, `canaryStrategy` |
| `stone-payments/platform-k8s-crossplane` | `manifests/xrds/aws/elasticache.yaml`, `rds.yaml` | Campos avancados de ElastiCache/RDS nao expostos no Portal |

## Formato de Resposta

Ao responder perguntas deste dominio, siga este formato:

1. **Explicacao** (2-3 frases objetivas em PT-BR)
2. **Exemplo pratico** (YAML, comando ou config copiavel)
3. **Fonte** (referencia ao arquivo/secao da documentacao)
4. **Avisos** (se aplicavel: requisitos de secrets, IRSA, permissoes necessarias)

# Reference: schema da analise de incidente — postmortems

Campos da analise por LLM no indice `incidents_processed` (output do `PostmortemBatchAnalyzer`, ~270 docs = ~1% do total). Carregue quando o user perguntar sobre uma secao da analise ou quando montar as pistas do `find_similar_incidents`. Cobertura e parcial — pra contagem/estatistica use `closed-incidents`.

## Campos da analise

| Campo                                                 | Conteudo                                       |
| ----------------------------------------------------- | ---------------------------------------------- |
| `incident_number`                                     | identificador estavel (`#34833`) — sempre cite |
| `_description` / `_page_title`                        | resumo do incidente (peso alto na busca)       |
| `resumo_executivo`                                    | sumario do que aconteceu                       |
| `causa_raiz_principal`                                | causa raiz consolidada (peso x4)               |
| `causas_raizes[]`                                     | causas contribuintes (x3)                      |
| `servicos_afetados[]`                                 | servicos impactados (x3)                       |
| `aplicacoes_mencionadas[]` / `componentes_afetados[]` | apps e componentes (x2)                        |
| `planos_acao[]`                                       | acoes corretivas/preventivas                   |
| `licoes_aprendidas[]`                                 | licoes                                         |
| `recorrencias[]`                                      | incidentes correlatos/repetidos (x2)           |
| `categoria_tematica`                                  | categoria (quando o analyzer preencheu)        |
| `_macroproduct` / `_product_name`                     | macroproduto / produto (x2)                    |
| `observacoes`                                         | notas livres (x1)                              |

## find_similar_incidents — como extrair pistas

Quando o user **descreve um cenario novo**, separe a descricao nas pistas — cada uma vira uma clausula `should` (mais matches = score maior):

- `description` — resumo do sintoma em 1-2 frases.
- `services` — servico(s) afetado(s).
- `components` — componente(s) suspeito(s) (fila, banco, deploy, cache...).
- `causes` — hipotese de causa, se houver.

→ E o diferencial do MCP; extrai mais sinal que `search_incidents` puro. Se 0 hits relevantes (scores no nivel do ruido), diga isso — nao force um "padrao" inexistente.

## Filtros de busca

`search_incidents` aceita `priority`, `macroproduct`, `date_from`/`date_to` (ISO — ver `temporal-handling`). Para portfolio/agregacao use `list_macroprodutos` / `list_priorities` / `list_categorias_tematicas`, nao `search` pra contar.

## Anti-patterns

- Usar postmortems pra contar (cobre ~1%) — va pro `closed-incidents`.
- Inventar causa raiz quando nao ha analise — diga "nao encontrei analise pra esse caso".
- Responder sem citar `incident_number`.

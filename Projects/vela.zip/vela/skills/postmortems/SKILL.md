---
name: postmortems
description: >
  Analisa incidentes ja encerrados e processados por LLM — causa raiz, padroes recorrentes,
  licoes aprendidas e busca por casos semelhantes. Surface principal: MCP postmortems
  (indice OpenSearch incidents_processed, ~270 docs, cobertura ~1%).
  Triggers: "postmortem", "causa raiz", "root cause", "incidentes analisados",
  "licoes aprendidas", "ja aconteceu algo parecido", "investigar incidente",
  "analise de incidente", "plano de acao", "incidente parecido", "recorrencia".
---

# Skill: Postmortems (Analise de Incidentes Passados)

## Exemplos de Perguntas

- "Ja aconteceu algo parecido com timeout no servico de pagamentos?"
- "Qual foi a causa raiz do incidente #34833?"
- "Quais licoes aprendidas temos sobre falhas de deploy?"
- "Mostra postmortems de P0 dos ultimos 3 meses"
- "Quais macroprodutos tem mais incidentes analisados?"
- "Investiga incidentes relacionados a fila Kafka travando"
- "Tem algum padrao de recorrencia em incidentes de banking?"
- "Quais planos de acao foram definidos pro incidente do PIX?"

## Regras de Execucao

Estas regras sao transversais e tem precedencia sobre qualquer instrucao especifica desta skill:

1. **Sempre cite `incident_number`**: todo incidente mencionado deve trazer o identificador estavel (`#N`) para cruzamento com `closed-incidents`/Slack/Confluence.
2. **Nao invente causa raiz**: se nao ha analise para o caso, diga explicitamente; sugira `closed-incidents` para listar.
3. **Cobertura parcial**: postmortems cobre ~1% do total de incidentes. Para contagem, estatistica ou cobertura completa, redirecione para `closed-incidents`.
4. **0 hits relevantes**: quando scores estao no nivel do ruido, diga isso; nao force um "padrao" inexistente.
5. **find_similar_incidents e o diferencial**: sempre que o usuario descrever um cenario novo, prefira `find_similar_incidents` em vez de `search_incidents` puro.
6. **Query BM25 otimizada**: extraia substantivos + verbo principal da pergunta, remova stopwords. 3-6 termos densos e o ponto otimo. Nao jogue a frase inteira como query.

## Conhecimento Embutido

### Quando NAO usar este MCP

| Pergunta do user                          | MCP correto        | Razao                                          |
| ----------------------------------------- | ------------------ | ---------------------------------------------- |
| "Quantos P0 em 2026?" / "Top 10 produtos" | `closed-incidents` | Postmortems cobre so 1% — contagem fica errada |
| "Quanto durou o #N?"                      | `closed-incidents` | Postmortems nao tem `total_duration`           |
| "Tem P0/P1 aberto agora?"                 | `active-incidents` | Postmortems e historico, nao snapshot          |
| "Como direciono chamado de PIX?"          | `help-foundation`  | Postmortems nao tem skill                      |

### Tools (inventario canonico)

**Discovery (portfolio):**

- `list_macroprodutos({ max_terms?=100 })` — distribuicao por macroproduto. Use pra "quais macroprodutos tem mais incidentes?".
- `list_priorities()` — distribuicao P0..P4.
- `list_categorias_tematicas({ max_terms?=50 })` — categorias (quando o analyzer preencheu).
- `health()` — debug do indice.

**Read (incidente especifico):**

- `get_incident({ incident_number })` — analise completa por numero (`#34833`). Use quando o user citou o numero.

**Search (linguagem natural):**

- `search_incidents({ query, top_k?, priority?, macroproduct?, date_from?, date_to? })` — BM25 nas analises. Default quando a query e narrativa. Filtros opcionais; datas ISO. Pesos → ref `opensearch-bm25-weights`.
- `find_similar_incidents({ description?, services?, components?, causes?, ... })` — busca por multiplas pistas (cada pista vira `should`). Use quando o user descreve um incidente novo e quer historico parecido. Como extrair pistas → ref `incident-analysis-schema`.

### Fluxo: "ja aconteceu algo parecido?"

1. Extraia pistas da descricao: sintoma, servico(s), componente(s), causa hipotetica.
2. `find_similar_incidents({ description, services, components, causes })`.
3. Top 3-5 — pra cada: `#N`, 1 linha do `_description`, **causa raiz**, ano. O suficiente pro user decidir se abre a analise.
4. Detalhar um: `get_incident({ incident_number })` — destaque `resumo_executivo`, `causa_raiz_principal`, `planos_acao`, `licoes_aprendidas`.
5. 0 hits relevantes (scores no ruido) → diga isso; nao force "padrao" inexistente.

### Fluxo: busca textual livre

1. `search_incidents({ query, top_k: 10 })` com filtros obvios (prioridade, macroproduto).
2. Janela temporal → converta pra `date_from`/`date_to` ISO (ref `temporal-handling`).
3. Formato compacto: `#N — priority — macroproduct — 1 linha`. Ofereca aprofundar via `get_incident`.

### Fluxo: portfolio / agregacoes

1. `list_macroprodutos` ou `list_priorities` — nao use `search` pra contar.
2. Tabela markdown se passar de 5 buckets.
3. "Quantos P0 nos ultimos N dias" → `search_incidents({ query: "*", priority: "P0", date_from, date_to, top_k: 100 })` (nao ha agregacao date+priority nativa aqui).

### Cross-reference com outros MCPs

- **closed-incidents** — contagem/estatistica/tendencia: va direto pra la (cobertura 100x maior). Cross-ref: pegue `incident_number` aqui → `get_closed_incident` la pra duracao + produto impactado.
- **active-incidents** — antes de afirmar "encerrado", confirme `get_incident({ incident_number })`; se `found: true`, e ATIVO.
- **help-foundation** — analise indica "deveria escalar pra time X": confirme o time vigente via `get_skill({ produto_servico })`.

## Instrucoes MCP

Quando o usuario precisar de informacoes detalhadas alem do conhecimento embutido, use as tools do MCP `postmortems`:

| Tool | Quando usar |
|------|-------------|
| `search_incidents` | Busca textual livre por incidentes analisados |
| `find_similar_incidents` | Usuario descreve cenario novo e quer historico parecido |
| `get_incident` | Usuario citou numero do incidente |
| `list_macroprodutos` | Distribuicao de incidentes por macroproduto |
| `list_priorities` | Distribuicao por prioridade (P0..P4) |
| `list_categorias_tematicas` | Categorias tematicas dos incidentes |
| `health` | Debug/status do indice |

**References carregaveis sob demanda:**

- `opensearch-bm25-weights` — quando o ranking surpreender ou precisar montar a melhor query pro `search_incidents`
- `incident-analysis-schema` — quando o user perguntar sobre uma secao da analise ou montar pistas do `find_similar`
- `temporal-handling` — quando a query referenciar janela temporal ("ultimos 3 meses", "Q1 2026")

## Formato de Resposta

Ao responder perguntas deste dominio, siga este formato:

1. **Resultado** — lista compacta dos incidentes encontrados (`#N — prioridade — macroproduto — resumo 1 linha`)
2. **Detalhamento** (quando solicitado) — `resumo_executivo`, `causa_raiz_principal`, `planos_acao`, `licoes_aprendidas`
3. **Padrao/Recorrencia** — se identificar padrao entre os resultados, destaque; se nao houver, diga explicitamente
4. **Proximos passos** — sugira aprofundamento (`get_incident`) ou redirecionamento (`closed-incidents` para contagem, `active-incidents` para snapshot atual)

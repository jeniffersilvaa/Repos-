---
skill: postmortems
version: 1
---

# Evals: Postmortems

## Happy-Path

### HP-001: busca por incidente similar via descricao
**Input**: "Ja aconteceu algo parecido com timeout no servico de pagamentos?"
**Deve**:
- Usar `find_similar_incidents` com pistas extraidas (description, services)
- Retornar top 3-5 com `#N`, resumo, causa raiz e ano
**Nao deve**:
- Usar `search_incidents` em vez de `find_similar_incidents` para busca por similaridade
**Fonte**: Exemplos de Perguntas #1

---

### HP-002: consulta de incidente por numero
**Input**: "Qual foi a causa raiz do incidente #34833?"
**Deve**:
- Usar `get_incident({ incident_number: 34833 })`
- Destacar `causa_raiz_principal` na resposta
- Citar o `incident_number` (#34833)
**Nao deve**:
- Inventar causa raiz se a analise nao existir
**Fonte**: Exemplos de Perguntas #2

---

### HP-003: busca textual por licoes aprendidas
**Input**: "Quais licoes aprendidas temos sobre falhas de deploy?"
**Deve**:
- Usar `search_incidents` com query otimizada (ex: "licoes falhas deploy")
- Apresentar resultados no formato compacto (#N — prioridade — macroproduto — resumo)
**Nao deve**:
- Jogar a frase inteira do usuario como query BM25
**Fonte**: Exemplos de Perguntas #3

---

### HP-004: busca com filtro temporal e prioridade
**Input**: "Mostra postmortems de P0 dos ultimos 3 meses"
**Deve**:
- Converter "ultimos 3 meses" para `date_from`/`date_to` ISO
- Usar `search_incidents` com filtro `priority: "P0"`
**Nao deve**:
- Passar string relativa ("ultimos 3 meses") direto no filtro
**Fonte**: Exemplos de Perguntas #4

---

### HP-005: portfolio por macroproduto
**Input**: "Quais macroprodutos tem mais incidentes analisados?"
**Deve**:
- Usar `list_macroprodutos` (tool de agregacao)
- Apresentar em tabela markdown se mais de 5 buckets
**Nao deve**:
- Usar `search_incidents` para contar/agregar
**Fonte**: Exemplos de Perguntas #5

---

### HP-006: busca por cenario especifico com pistas
**Input**: "Investiga incidentes relacionados a fila Kafka travando"
**Deve**:
- Usar `find_similar_incidents` com pistas (components: "Kafka", description: "fila travando")
- Citar `incident_number` em cada resultado
**Nao deve**:
- Forcar padrao inexistente se scores estao no ruido
**Fonte**: Exemplos de Perguntas #6

---

### HP-007: padrao de recorrencia por macroproduto
**Input**: "Tem algum padrao de recorrencia em incidentes de banking?"
**Deve**:
- Usar `search_incidents` com filtro `macroproduct: "banking"`
- Analisar resultados para padroes; se nao houver, dizer explicitamente
**Nao deve**:
- Inventar padrao quando nao ha evidencia nos dados
**Fonte**: Exemplos de Perguntas #7

---

### HP-008: consulta de planos de acao por incidente
**Input**: "Quais planos de acao foram definidos pro incidente do PIX?"
**Deve**:
- Usar `search_incidents` com query focada ("plano acao PIX") ou `get_incident` se numero for citado
- Destacar campo `planos_acao` na resposta
**Nao deve**:
- Omitir o `incident_number` nos resultados
**Fonte**: Exemplos de Perguntas #8

---

## Edge-Cases

### EC-001: sempre citar incident_number
**Input**: "Me da um resumo dos incidentes de pagamento"
**Deve**: incluir `#N` em cada incidente mencionado na resposta
**Nao deve**: apresentar incidentes sem o identificador `incident_number`
**Fonte**: Regras de Execucao #1

---

### EC-002: nao inventar causa raiz
**Input**: "Qual a causa raiz do incidente #99999?"
**Deve**: informar que nao encontrou analise para esse caso e sugerir `closed-incidents`
**Nao deve**: inventar ou supor uma causa raiz quando a analise nao existe
**Fonte**: Regras de Execucao #2

---

### EC-003: redirecionar contagem para closed-incidents
**Input**: "Quantos P0 tivemos em 2026?"
**Deve**: redirecionar para `closed-incidents` explicando que postmortems cobre ~1% do total
**Nao deve**: responder com contagem baseada no indice de postmortems (seria imprecisa)
**Fonte**: Regras de Execucao #3

---

### EC-004: nao forcar padrao inexistente
**Input**: "Qual o padrao dos incidentes de networking?"
**Deve**: se scores estao no ruido ou 0 hits, dizer que nao encontrou padrao
**Nao deve**: forcar um "padrao" quando os dados nao suportam
**Fonte**: Regras de Execucao #4

---

### EC-005: preferir find_similar para cenarios novos
**Input**: "Nosso servico de auth caiu com OOM, ja aconteceu?"
**Deve**: usar `find_similar_incidents` com pistas (services: "auth", description: "OOM")
**Nao deve**: usar `search_incidents` quando o usuario descreve um cenario para busca por similaridade
**Fonte**: Regras de Execucao #5

---

### EC-006: query BM25 otimizada
**Input**: "Como que a gente pode evitar que aconteca de novo aquele problema que teve no servico de pagamentos quando o banco de dados ficou sem espaco?"
**Deve**: extrair termos densos para query (ex: "banco dados sem espaco pagamentos")
**Nao deve**: passar a frase inteira como query — dilui o score BM25
**Fonte**: Regras de Execucao #6

## O que é o AI Adoption Index

O índice vai além da adoção binária (usou ou não usou) para capturar **quão bem** cada pessoa integrou IA ao seu trabalho. Escala de 0 a 100, composto por quatro dimensões:

| Dimensão | Peso | Definição |
|----------|-----:|-----------|
| **Frequência** | 10% | Dias com uso ativo ÷ dias úteis da janela |
| **Qualidade** | 30% | Taxa de aceitação das sugestões IA (Copilot: `code_acceptance / code_generation`; Claude: `edits aceitos / edits propostos`) |
| **Impacto** | 40% | Commits + PRs atribuídos ao Claude Code, normalizado (10 entregas = 100) |
| **Intensidade** | 20% | Sessões por dia ativo no Claude Code (ou interações no Copilot), normalizado (10/dia = 100) |

> **Por que esses pesos?** Impacto é o sinal mais direto de que a IA está gerando entrega real — quem atribui commits e PRs ao Claude já delegou trabalho concreto, não só recebeu sugestões. Qualidade diferencia quem usa bem de quem apenas liga a ferramenta. Intensidade captura profundidade por sessão. Frequência tem peso menor porque uso diário sem entrega ainda é adoção passiva.

> **Caveats:** (1) Dados de impacto (commits/PRs) são exclusivos do Claude Code — usuários Copilot-only ficam com impact=0 mesmo entregando código via Copilot. (2) Dados de qualidade do Copilot chegam da API GitHub e podem ter lag de ~24h. (3) O Claude Code tem ~3 dias de lag de ingestão — janelas que terminam nos últimos dias ainda vão "engordar". (4) Membros novos (<2 semanas na janela) tendem a ter freq baixa por razão de calendário.

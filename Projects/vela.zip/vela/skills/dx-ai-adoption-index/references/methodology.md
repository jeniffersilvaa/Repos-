# Metodologia — AI Adoption Index (queries congeladas)

Definições e SQL validados ao vivo contra o DX Data Cloud (via `mcp__vela-mcp-hub__dx__queryData`),
reproduzindo a lógica do report interno de adoção de IA do time de Crédito (2026-05-27). **Não
reinvente o SQL** — use estas queries, substituindo apenas os placeholders `<INICIO>`, `<FIM>`,
`<SNAPSHOT_ID>`, `<SCOPE_ROOTS>`, `<BUSINESS_DAYS>`.

`<SCOPE_ROOTS>` é uma **lista de ids** separada por vírgula (ex.: `3576` para um time só, ou
`<root1>,<root2>` para a empresa toda). Funciona em `IN (<SCOPE_ROOTS>)`.

## Modelo de dados

| Tabela | Papel | Chave de junção |
|---|---|---|
| `dx_versioned_team_dates` | snapshots de hierarquia (id, date) | — |
| `dx_versioned_teams` | times por snapshot (`id`, `name`, `is_parent`, `versioned_team_date_id`) | — |
| `dx_versioned_team_hierarchies` | closure table (`ancestor_id`, `descendant_id`, **`generations`** = distância) | — |
| `dx_versioned_team_members` | membros por time (`versioned_team_id`, `user_id`) | `user_id` = `dx_users.id` |
| `dx_users` | pessoas (`id`, `email`, `github_username`) | — |
| `ai_tool_daily_metrics` | uso diário unificado (`dx_user_id`, `login`, `date`, `is_active`, `ai_tool_id`) | `dx_user_id` |
| `claude_code_daily_user_metrics` | Claude por dia (`id`, `email`, `date`, `is_active`) | `email` |
| `claude_code_daily_user_metrics_breakdowns` | métricas Claude (`daily_user_metric_id`, sessões, commits/PRs, edits) | `daily_user_metric_id` → tabela acima |
| `github_copilot_daily_usages` | Copilot por dia (`login`, `date`, `active`, interações, code gen/accept) | `login` = `dx_users.github_username` |

**Identidade:** Claude por `email`, Copilot por `github_username`, Frequência por `dx_user_id`.
**Login exibido:** login não-email do `ai_tool_daily_metrics`; senão `github_username`; senão local-part do email.

> ⚠️ O id de um time é **versionado por snapshot**. Resolva sempre pelo nome no snapshot corrente
> (CRÉDITO ≠ 3314; no snapshot 32 é 3576).

## As 4 dimensões → Índice

`Índice = round(0.10·Freq + 0.30·Qual + 0.40·Imp + 0.20·Int)`

- **Frequência (10%)** = `LEAST(100, round(dias_ativos / <BUSINESS_DAYS> * 100))`, onde `dias_ativos` =
  datas-calendário distintas com `is_active` em `ai_tool_daily_metrics` (inclui fim de semana).
- **Qualidade (30%)** = média **simples** das taxas de aceitação das ferramentas com denominador > 0:
  Claude `Σedits_aceitos/Σ(aceitos+rejeitados)`, Copilot `Σcode_acceptance/Σcode_generation`.
  **Cada taxa é capada em 100** (`LEAST(100, …)`) — no Copilot os contadores de acceptance e
  generation são distintos e a razão pode passar de 1.
- **Impacto (40%)** = `LEAST(100, round(Σ(commits + PRs do Claude) * 10))`.
- **Intensidade (20%)** = média das intensidades por ferramenta (com dias > 0), cada uma
  `LEAST(100, métrica_por_dia_ativo / 10 * 100)`: Claude sessões/dia, Copilot interações/dia.

Edits Claude = soma de `edit_tool_*`, `multi_edit_tool_*`, `write_tool_*`, `notebook_edit_tool_*`
(accepted e rejected).

## Escopo (genérico, qualquer camada)

- **Time específico** (pasta passada): `<SCOPE_ROOTS>` = o id desse time no snapshot.
- **Empresa toda** (nenhuma pasta): `<SCOPE_ROOTS>` = **todos os nós de topo** (sem ancestral próprio).
  Hoje são 2: ENGENHARIA e GenAI.

A árvore é uma *closure table*; a **profundidade de um nó a partir do topo do escopo** é
`MIN(generations)` sobre as arestas que partem de qualquer raiz do escopo. Para um único time isso
coincide com `generations`.

## Passo 0 — Snapshot, escopo e dias úteis

```sql
-- snapshot: o mais recente com data <= fim (NÃO o mais recente absoluto — o org reestrutura).
SELECT id, date FROM dx_versioned_team_dates WHERE date <= DATE '<FIM>' ORDER BY date DESC LIMIT 1;  -- => <SNAPSHOT_ID>

-- escopo = TIME ESPECÍFICO: id pelo nome
SELECT id, name FROM dx_versioned_teams
WHERE versioned_team_date_id = <SNAPSHOT_ID> AND is_parent = true AND name = '<ROOT_NAME>';  -- => <SCOPE_ROOTS>

-- escopo = EMPRESA TODA: todos os nós de topo (sem ancestral próprio)
SELECT t.id, t.name FROM dx_versioned_teams t
WHERE t.versioned_team_date_id = <SNAPSHOT_ID> AND t.is_parent = true
  AND NOT EXISTS (SELECT 1 FROM dx_versioned_team_hierarchies h
                  WHERE h.descendant_id = t.id AND h.generations > 0);  -- => <SCOPE_ROOTS>

-- dias úteis no intervalo semi-aberto [inicio, fim)  (reproduz o 51 do report de 05-27)
SELECT COUNT(*) AS business_days
FROM generate_series(DATE '<INICIO>', DATE '<FIM>' - INTERVAL '1 day', INTERVAL '1 day') d
WHERE EXTRACT(DOW FROM d) BETWEEN 1 AND 5;  -- => <BUSINESS_DAYS>
```

## Passo 1 — Camadas (profundidade a partir do topo do escopo)

```sql
SELECT depth, COUNT(*) FILTER (WHERE is_parent) AS parents, COUNT(*) FILTER (WHERE NOT is_parent) AS leaves
FROM (
  SELECT h.descendant_id, MIN(h.generations) AS depth,
         BOOL_OR(t.is_parent) AS is_parent
  FROM dx_versioned_team_hierarchies h
  JOIN dx_versioned_teams t ON t.id = h.descendant_id AND t.versioned_team_date_id = <SNAPSHOT_ID>
  WHERE h.ancestor_id IN (<SCOPE_ROOTS>)
  GROUP BY h.descendant_id
) x GROUP BY depth ORDER BY depth;
```

Regra para **quais camadas exibir** (da mais ampla à folha):
- Qualquer profundidade `k` com **≥ 2 nós `is_parent`** vira uma "Médias por camada". (Para empresa,
  `depth = 0` já tem ≥ 2 nós = as raízes → camada "Raiz/Diretoria"; para um time único, `depth = 0`
  é só ele mesmo → não vira camada.)
- A camada folha (`is_parent = false`) é sempre a mais fina.
- Rótulos: `--labels "A,B,..."` mapeados em ordem (topo→folha) às camadas exibidas. Sem rótulos →
  "Nível k". Sugestões: time → `Tribo,Squad`; empresa → `Diretoria,Tribo,Squad`.

## Passo 2 — Query mestra (índice por membro)

Uma linha por membro. **Única mudança vs. time único:** `IN (<SCOPE_ROOTS>)` no `leaf_units`.

```sql
WITH leaf_units AS (
  SELECT DISTINCT t.id AS unit_id, t.name AS unit_name
  FROM dx_versioned_team_hierarchies h
  JOIN dx_versioned_teams t ON t.id = h.descendant_id
  WHERE h.ancestor_id IN (<SCOPE_ROOTS>) AND t.versioned_team_date_id = <SNAPSHOT_ID> AND t.is_parent = false
),
members AS (
  SELECT DISTINCT lu.unit_id, lu.unit_name, tm.user_id
  FROM dx_versioned_team_members tm
  JOIN leaf_units lu ON lu.unit_id = tm.versioned_team_id
),
ai_login AS (
  SELECT dx_user_id, MAX(login) FILTER (WHERE login NOT LIKE '%@%') AS login
  FROM ai_tool_daily_metrics
  WHERE date >= DATE '<INICIO>' AND date < DATE '<FIM>'
  GROUP BY dx_user_id
),
roster AS (
  SELECT m.user_id, m.unit_id, m.unit_name, u.email, u.github_username,
         COALESCE(al.login, u.github_username, split_part(u.email,'@',1)) AS disp_login
  FROM members m JOIN dx_users u ON u.id = m.user_id
  LEFT JOIN ai_login al ON al.dx_user_id = u.id
),
freq AS (
  SELECT dx_user_id, COUNT(DISTINCT date) AS active_days
  FROM ai_tool_daily_metrics
  WHERE date >= DATE '<INICIO>' AND date < DATE '<FIM>' AND is_active
  GROUP BY dx_user_id
),
cc AS (
  SELECT m.email,
         COUNT(DISTINCT m.date) FILTER (WHERE m.is_active) AS d,
         SUM(b.num_sessions) AS s, SUM(b.commits_by_claude_code) AS c, SUM(b.pull_requests_by_claude_code) AS p,
         SUM(b.edit_tool_accepted+b.multi_edit_tool_accepted+b.write_tool_accepted+b.notebook_edit_tool_accepted) AS ea,
         SUM(b.edit_tool_rejected+b.multi_edit_tool_rejected+b.write_tool_rejected+b.notebook_edit_tool_rejected) AS er
  FROM claude_code_daily_user_metrics m
  JOIN claude_code_daily_user_metrics_breakdowns b ON b.daily_user_metric_id = m.id
  WHERE m.date >= DATE '<INICIO>' AND m.date < DATE '<FIM>'
  GROUP BY m.email
),
cop AS (
  SELECT g.login,
         COUNT(DISTINCT g.date) FILTER (WHERE g.active) AS d,
         SUM(g.user_initiated_interaction_count) AS i, SUM(g.code_generation_activity_count) AS cg, SUM(g.code_acceptance_activity_count) AS ca
  FROM github_copilot_daily_usages g
  WHERE g.date >= DATE '<INICIO>' AND g.date < DATE '<FIM>'
  GROUP BY g.login
),
calc AS (
  SELECT r.disp_login, r.unit_id, r.unit_name,
    COALESCE(cop.d,0) AS copilot_days, COALESCE(cc.d,0) AS claude_days, COALESCE(f.active_days,0) AS dias_ativos,
    LEAST(100, ROUND(COALESCE(f.active_days,0)/<BUSINESS_DAYS>.0*100)) AS freq,
    (SELECT ROUND(AVG(v)) FROM (VALUES
        (CASE WHEN COALESCE(cc.ea+cc.er,0)>0 THEN LEAST(100, cc.ea::numeric/(cc.ea+cc.er)*100) END),
        (CASE WHEN COALESCE(cop.cg,0)>0     THEN LEAST(100, cop.ca::numeric/cop.cg*100) END)) t(v)) AS qual,
    LEAST(100, ROUND(COALESCE(cc.c+cc.p,0)*10.0)) AS impacto,
    (SELECT ROUND(AVG(v)) FROM (VALUES
        (CASE WHEN COALESCE(cc.d,0)>0  THEN LEAST(100, cc.s::numeric/cc.d/10*100) END),
        (CASE WHEN COALESCE(cop.d,0)>0 THEN LEAST(100, cop.i::numeric/cop.d/10*100) END)) t(v)) AS intens
  FROM roster r
  LEFT JOIN freq f ON f.dx_user_id = r.user_id
  LEFT JOIN cc  ON cc.email = r.email
  LEFT JOIN cop ON cop.login = r.github_username
)
SELECT ROW_NUMBER() OVER (ORDER BY ROUND(0.10*freq+0.30*COALESCE(qual,0)+0.40*impacto+0.20*COALESCE(intens,0)) DESC, disp_login) AS rk,
       disp_login, unit_id, unit_name, dias_ativos, copilot_days, claude_days,
       freq, COALESCE(qual,0) AS qual, impacto, COALESCE(intens,0) AS intens,
       ROUND(0.10*freq + 0.30*COALESCE(qual,0) + 0.40*impacto + 0.20*COALESCE(intens,0)) AS indice
FROM calc
ORDER BY rk;
```

- "Membros avaliados": `ativos` = `dias_ativos > 0`; `total` = todas as linhas.
- `unit_id` permite o roll-up das camadas (Passo 3).

### Ranking grande — cap por tamanho
Seja `N` = total de membros. Se `N > <CAP_THRESHOLD>` (default **150**) e não houver `--full`,
mostre só **Top `<TOP>`** (default 25) e **Bottom `<BOTTOM>`** (default 25), com uma linha indicando
os `N - TOP - BOTTOM` membros ocultos no meio. Caso contrário, ranking completo. As médias por camada
(Passo 3) usam **sempre todos** os membros, independente do cap.

## Passo 3 — Médias por camada

Para cada camada exibível em profundidade `k` (Passo 1), mapeie folha → ancestral em `depth = k` e
agregue o índice dos membros. Mapeamento (genérico, multi-raiz):

```sql
WITH depth_node AS (  -- profundidade de cada nó a partir do topo do escopo
  SELECT h.descendant_id AS node_id, MIN(h.generations) AS depth
  FROM dx_versioned_team_hierarchies h
  WHERE h.ancestor_id IN (<SCOPE_ROOTS>)
  GROUP BY h.descendant_id
),
layer_nodes AS (  -- nós da camada k
  SELECT dn.node_id AS layer_id, t.name AS layer_name
  FROM depth_node dn JOIN dx_versioned_teams t ON t.id = dn.node_id AND t.versioned_team_date_id = <SNAPSHOT_ID>
  WHERE dn.depth = <K>
)
SELECT ln.layer_name, leaf.id AS unit_id
FROM layer_nodes ln
JOIN dx_versioned_team_hierarchies hl ON hl.ancestor_id = ln.layer_id
JOIN dx_versioned_teams leaf ON leaf.id = hl.descendant_id AND leaf.versioned_team_date_id = <SNAPSHOT_ID> AND leaf.is_parent = false;
```

Junte ao `calc` por `unit_id` e produza `Membros / Índice médio / Melhor / Pior` por `layer_name`.
A camada folha agrega por `unit_id`/`unit_name` direto. (Para `<K>=0` em escopo de empresa, os nós
de camada são as próprias raízes.)

## Validação de referência (janela 2026-03-17 → 2026-05-27, snapshot 32, escopo CRÉDITO=3576)

- Roster: **98 membros / 20 folhas / 6 tribos**; `<BUSINESS_DAYS>` = **51**.
- Confere exato em dimensões não afetadas por lag: Qualidade thaifurforo `(99.9+73.8)/2 = 87`;
  Frequência joao.cisalpino `7/51 → 14`, leogottardi `30/51 → 59`.
- Escopo empresa (snapshot 33): raízes = ENGENHARIA + GenAI; ~945 membros nas folhas; profundidade 4.
- **Não reproduz byte a byte** o report de 05-27: Claude tem **~3 dias de lag de ingestão**
  (dado de 05-25 criado em 05-28); o report rodou sobre janela truncada que depois foi preenchida
  (backfill). Diferenças vs. o original são explicáveis por isso.

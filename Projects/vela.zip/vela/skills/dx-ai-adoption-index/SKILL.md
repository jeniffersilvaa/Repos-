---
name: dx-ai-adoption-index
description: "Gera o AI Adoption Index (DX) de qualquer time/área no DX da Stone — índice 0–100 por pessoa em 4 dimensões (Frequência, Qualidade, Impacto, Intensidade), com ranking, distribuição por faixa e médias por camada da árvore organizacional. Use quando pedirem o 'AI Adoption Index', o índice de adoção de IA, um ranking de adoção de Claude Code/Copilot, ou um report de adoção por time/diretoria/empresa. Recebe janela [inicio fim] e um time-raiz opcional; sem time-raiz, roda a empresa toda. Serve gestores de qualquer camada."
metadata:
  version: "1.0.0"
  author: "Rafael Portugal (Tecnologia — Crédito)"
---

# AI Adoption Index

Regenera o *AI Adoption Index* de forma consistente. Os dados vêm do DX Data Cloud via
`mcp__vela-mcp-hub__dx__queryData`. A metodologia e o SQL congelado estão em
`references/methodology.md` — **leia esse arquivo e use as queries de lá; não reinvente**.

> **Índice opinativo.** Reflete a visão de **Rafael Portugal (Tecnologia — Crédito)** sobre o que
> caracteriza adoção *madura* de IA — **não** é diretriz oficial da Stone nem métrica de performance.
> O texto completo está em `references/disclaimer.md` e **deve** entrar no cabeçalho de todo report.

## Human Input

<!--
  MANTENEDORES: Adicione restrições, correções e conhecimento adicional aqui.
  Este conteúdo tem a MAIOR PRECEDÊNCIA sobre todo o resto da skill.
-->

_(vazio)_

## Parâmetros

`dx-ai-adoption-index [inicio] [fim] [time-raiz] [--full] [--top N] [--bottom N] [--cap-threshold N] [--labels "A,B,..."]`

- `inicio`, `fim`: `AAAA-MM-DD`. Se ausentes, proponha os últimos ~70 dias (hoje−70 a hoje) e
  **confirme** antes de rodar.
- `time-raiz`: nome do time/área no DX. **Se ausente → empresa toda** (todas as raízes de topo).
- `--full`: força ranking individual completo (sem cap).
- `--top N` / `--bottom N`: tamanho do cap quando ele dispara (default 25 / 25).
- `--cap-threshold N`: a partir de quantos membros o cap dispara (default 150).
- `--labels "A,B,..."`: rótulos das camadas, do topo à folha. Sem isso → "Nível 1/2…". Sugestões:
  time → `Tribo,Squad`; empresa → `Diretoria,Tribo,Squad`.

## Pré-requisito

A skill usa a ferramenta `mcp__vela-mcp-hub__dx__queryData` (já provida pelo `.mcp.json` do plugin
`vela`). Se ela não estiver disponível, peça ao usuário: rode `/mcp`, selecione `vela-mcp-hub` e
autentique.

## Procedimento

Crie um TodoWrite com estes passos e execute em ordem.

1. **Resolver contexto (Passo 0 da methodology):** snapshot = o mais recente com `date <= fim` →
   `<SNAPSHOT_ID>`. Resolver `<SCOPE_ROOTS>`: se `time-raiz` foi passado, o id desse time; senão,
   **todos os nós de topo** (empresa). Se o nome não resolver, liste os parents do snapshot e peça
   desambiguação. Calcular dias úteis em `[inicio, fim)` → `<BUSINESS_DAYS>`.
2. **Mapear camadas (Passo 1):** rode a query de profundidade. Liste as camadas exibíveis
   (profundidade com ≥2 nós `is_parent`, + a folha) e associe os rótulos.
3. **Query mestra (Passo 2):** substitua os placeholders e rode. Conte `N` = total; `ativos` =
   `dias_ativos > 0`.
4. **Aplicar cap do ranking:** se `N > <CAP_THRESHOLD>` e sem `--full`, separe Top `<TOP>` + Bottom
   `<BOTTOM>` e registre quantos ficaram ocultos no meio. Senão, ranking completo.
5. **Médias por camada (Passo 3):** para cada camada exibível, agregue `Membros / Índice médio /
   Melhor / Pior` usando **todos** os membros (o cap só afeta a lista individual).
6. **Aviso de lag:** se `fim > hoje − 3 dias`, inclua no cabeçalho aviso de que os últimos ~3 dias do
   Claude podem estar incompletos (lag de ingestão) e os números tendem a subir.
7. **Montar o markdown** (estrutura abaixo) em `reports/<AAAAMMDD>/ai-adoption-index-<escopo>.md`
   relativo ao diretório atual (`AAAAMMDD` = hoje; `<escopo>` em kebab-case — `empresa`, `credito`,
   `payments`, etc. — sempre presente, p/ não sobrescrever runs de escopos diferentes no mesmo dia).
   Crie a pasta se necessário.
8. **(Opcional) Gerar HTML:** se houver um conversor Markdown→HTML disponível no ambiente, gere o
   `.html` ao lado do `.md`. Caso contrário, entregue apenas o `.md`.
9. **Reportar** os caminhos e 2–3 destaques.

## Estrutura do report

1. **Cabeçalho:** título `AI Adoption Index — <Escopo>` (nome do time, ou "Empresa" se todas as
   raízes); `Gerado em`, `Janela de dados` (dias corridos + `<BUSINESS_DAYS>` úteis), `Snapshot`,
   `Membros avaliados: X ativos / Y total`, aviso de lag (se aplicável).
2. **Disclaimer:** cole `references/disclaimer.md` (obrigatório, logo após o cabeçalho).
3. **O que é o AI Adoption Index** — bloco estável de `references/index-explainer.md` (agnóstico ao escopo).
4. **Ranking** — `# | Login | <Folha> | Dias Ativos | Copilot | Claude | Freq | Qualidade | Impacto |
   Intensidade | Índice`, por índice desc. Se capado, seção "Top N" + "Bottom N" com nota dos ocultos.
   `Copilot`/`Claude` = dias ativos por ferramenta.
5. **Distribuição do Índice** — faixas ⭐ 80–100 / ✅ 60–79 / 🟡 40–59 / 🔴 0–39, com Qtd e %.
6. **Médias por camada** — uma tabela por camada exibível, da mais ampla à folha (ex.: *Médias por
   Diretoria*, *Médias por Tribo*, *Médias por Squad*): `<Camada> | Membros | Índice médio | Melhor | Pior`.
7. **Destaques e Padrões** — narrativo: perfis "Claude-first" de alto impacto, "alta frequência sem
   impacto", camadas com menor índice.
8. **Rodapé:** fontes (`ai_tool_daily_metrics`, `claude_code_daily_user_metrics_breakdowns`,
   `github_copilot_daily_usages`) e a janela.

## Convenções

- Datas em `AAAA-MM-DD`. Índice e dimensões como inteiros (a query já arredonda).
- Legível em poucos minutos por um gestor — o bloco de Destaques é o que move a agulha.
- Se uma query voltar vazia, cheque `information_schema` (o schema do DX pode ter mudado) antes de
  seguir; não invente colunas.

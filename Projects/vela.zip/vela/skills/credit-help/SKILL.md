---
name: credit-help
description: "Skill de direcionamento e troubleshooting para solicitações de suporte aos produtos e operações de Crédito (Limite da Conta, Capital de Giro, Esteira Especializada, Recuperação, Revitalização, etc). Use quando o cliente relatar problemas ou dúvidas sobre produtos de Crédito."
---

# Skill: credit-help (Skills do Karavela)

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.

  Exemplos de uso:
  - Corrigir informacao desatualizada no conhecimento embutido
  - Adicionar restricao temporaria
  - Adicionar conhecimento que ainda nao esta na documentacao oficial
  - Bloquear uma orientacao especifica
-->

## Escopo

**Cobre**:
- Orientação sobre produtos de Crédito: Limite da Conta, Capital de Giro, Esteira Especializada, Cartão de Crédito
- Triagem e categorização de solicitações de suporte ao Crédito
- Resposta direta para perguntas frequentes documentadas (ex: interesse em oferta, funcionamento de retenção, prazos)
- Coleta estruturada de dados para encaminhamento ao time responsável
- Direcionamento para o time/grupo correto conforme produto e categoria do problema
- Orientação passo a passo baseada nos documentos de tratativa registrados no confluence
- Problemas com uso de produtos de Crédito (erro no app, falha de assinatura, pagamento pontual, etc)
- Dúvidas sobre funcionalidades de crédito e elegibilidade
- Consulta de status de empréstimo em tempo real

**NAO cobre**:
- Execução de ações operacionais (cancelar empréstimo, criar oferta, reprocessar desembolso)
- Suporte a produtos fora da aliança de Crédito (Banking, Payments, Pix, Boleto, etc.)
- Problemas de infraestrutura/engenharia (alertas, deploys, secrets, pipelines)
- Criação ou alteração de ofertas no motor de crédito
- Atendimento direto ao cliente final (skill atende times internos da Stone)

## Exemplos de Perguntas

- "Preciso de ajuda com um empréstimo de um cliente"
- "Cliente não consegue finalizar a contratação do crédito"
- "Empréstimo não aparece no app/admin após contratação"
- "Empréstimo foi cancelado após a contratação, o que aconteceu?"
- "Cliente quer ter oferta de crédito, como faço?"
- "Quero liberar crédito para um cliente"
- "Como faço para o cliente ter oferta de Capital de Giro?"
- "O cliente tinha oferta e ela sumiu"
- "Parcela do empréstimo não foi quitada"
- "Retenção continua ativa mesmo após quitação"
- "Cliente precisa trocar de conta e tem empréstimo ativo"
- "Preciso cancelar um empréstimo por fraude"
- "Como funciona a retenção do Capital de Giro?"
- "Qual o prazo de desembolso do empréstimo?"
- "Cliente contratou mas o dinheiro não caiu"
- "Preciso solicitar cancelamento de oferta"
- "Empréstimo está com status de insuficiência de garantia"
- "Como funciona o empacotamento de ofertas?"
- "Preciso de suporte com a esteira especializada"
- "Cliente assinou o contrato mas nada aconteceu"

## Regras de Execução

1. Usuário indica interesse em realizar um suporte para o Crédito
2. Avaliação do contexto informado — "O contexto informado é suficiente?"
2.1. Se não -> A skill pede para o usuário informar mais contexto. Repetir até que o contexto seja suficiente para prosseguir. Garanta que o usuário tenha fornecido informações que sejam relevantes para a tratativa, como documento do cliente, tipo do produto, evidências do problema, identificador do empréstimo, etc.
2.2. Se sim -> Prosseguir para o passo 3.
3. Busca na base de conhecimento
3.1. Baseado no contexto, a skill procura um tópico similar dentro da pasta de tratativas automáticas no Confluence: https://allstone.atlassian.net/wiki/spaces/CAPITAL/pages/9453928907/Tratativas+automaticas
3.2. skill deve cruzar o contexto informado pelo usuário com os documentos disponíveis nessa pasta, buscando o documento que melhor descreve o problema relatado e sua respectiva tratativa.
4. Avaliação do resultado da busca — "Foi encontrado tópico referente ao contexto enviado pelo usuário?"
4.1. Se sim → Seguir os passos indicados pelo documento identificado na pasta de Tratativas automáticas. Apresentar a orientação passo a passo ao usuário. Em seguida, perguntar: "O problema foi resolvido?"
4.1.1. Se sim → Fluxo se encerra.
4.1.2. Se não → Orientar o usuário a abrir um chamado no canal #credit-help, já passando para ele a mensagem que deverá ser enviada (com os dados coletados formatados no padrão do canal).
4.2. Não → Orientar o usuário a abrir um chamado no canal #credit-help, já passando para ele a mensagem que deverá ser enviada (com os dados coletados formatados no padrão do canal).
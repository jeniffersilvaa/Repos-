---
skill: migrate-to-approved-actions
version: 1
---

# Evals: Migrar Repositório para Approved Actions

## Happy-Path

### HP-001: migrar repositório completo
**Input**: "Migre o repositorio stone-payments/my-api para usar approved-actions"
**Deve**:
- Executar Fase 0 (descoberta): listar workflows `.github/workflows/*.{yml,yaml}` **e** `action.yml`/`action.yaml` de composite actions, extraindo `uses:` de terceiros
- Aplicar a regra de ignore de actions internas da Stone (`stone-payments`, `stone-ton`, `dlpco`, `mundipagg`, `pagarme`) antes de tentar mapear no catálogo
- Carregar o catálogo `.catalog-entries.tsv` (Fase 1) e classificar cada `uses:` (Fase 2)
- Reescrever referências migráveis para `stone-payments/approved-actions/<vendor>/<action>/<major>@stable`, sem comentário de versão inline
- Normalizar `runs-on: ubuntu-latest` → `small-runner` por default (Fase 2.5), sem perguntar se deve incluir
- Adicionar `permissions:` por default (Fase 3), sem perguntar se deve incluir
- Gerar relatório completo (Fase 4) e só aplicar (Fase 5) após confirmação do usuário (modo interativo)
**Não deve**:
- Migrar ou reportar como "não-aprovada" nenhuma action interna da Stone
- Deixar comentário de versão (`# vX`) nas linhas migradas
- Tocar em `runs-on` que não seja `ubuntu-latest` exato — imagens pinadas (`ubuntu-24.04`/`22.04`/`20.04`), `macos-*`/`windows-*`, `${{ matrix.os }}`, arrays multi-label ou `runs-on: group:` ficam intactos
- Promover nenhum job a `medium-runner`/`large-runner` — a skill escreve sempre `small-runner`
- Aplicar qualquer mudança no repositório-alvo sem confirmação explícita (modo interativo)
**Fonte**: Exemplos de Perguntas #1

---

### HP-002: consulta sem aplicar mudanças
**Input**: "Quais actions publicas o repo stone-payments/payment-service usa que nao estao no approved-actions?"
**Deve**:
- Rodar Fase 0-2 (descoberta e classificação) e apresentar a lista de actions "Não-aprovadas — terceiros sem wrapper"
- Listar internas da Stone separadamente como "interna (ignorada)", nunca misturadas com não-aprovadas
**Não deve**:
- Reescrever nenhum workflow ou abrir PR — o pedido é uma consulta, não uma migração
**Fonte**: Exemplos de Perguntas #2

---

### HP-003: migração completa com permissions
**Input**: "Substitua todas as actions por approved-actions e adicione permissions nos workflows"
**Deve**:
- Executar o fluxo completo (Fases 0-5) migrando todas as actions de terceiros elegíveis
- Adicionar blocos `permissions:` (top-level restritivo + elevação por job) mesmo sem o usuário ter pedido isso explicitamente — é comportamento por default
**Não deve**:
- Pular a Fase 3 (permissions) por não ter sido mencionada explicitamente no pedido — é sempre aplicada
**Fonte**: Exemplos de Perguntas #3

---

### HP-004: invocação via slash command com URL
**Input**: "/migrate-to-approved-actions https://github.com/stone-payments/my-repo"
**Deve**:
- Extrair `owner/repo` diretamente da URL fornecida e iniciar a Fase 0 sem pedir mais informação
**Não deve**:
- Perguntar novamente pela URL/repositório já fornecido no comando
**Fonte**: Exemplos de Perguntas #4

---

### HP-005: pedido usando o termo "pinar"
**Input**: "Preciso pinar as actions do meu repo, pode fazer?"
**Deve**:
- Migrar todas as referências elegíveis para `.../<major>@stable` (a tag do catálogo), inclusive quando o `uses:` original já era um SHA pin direto
- Explicar, no relatório/PR, que a imutabilidade do SHA upstream é preservada dentro do wrapper e que updates re-vetados passam a chegar via `@stable`
**Não deve**:
- Oferecer ou aplicar "strict mode"/pin direto por SHA do catálogo — a skill nunca faz isso, mesmo quando o usuário usa a palavra "pinar"
**Fonte**: Exemplos de Perguntas #5; regra do `@stable` e notas de PR sobre SHA pins (seção "Regra do `@stable`" e "Notas" do template de PR)

---

### HP-006: pedido focado em permissions
**Input**: "Adicione permissions explicitas nos workflows do meu repositorio"
**Deve**:
- Inserir `permissions:` seguindo a estratégia restringir-no-top-level/elevar-por-job (Fase 3), derivando o escopo das actions usadas e dos sinais de `run:`/`github-script`
- Validar com `actionlint` antes de considerar a mudança pronta
- Tratar workflows `on: workflow_call` com cautela redobrada (permissions por job, não top-level restritivo, sinalizar que é reusable)
**Não deve**:
- Sobrescrever um bloco `permissions:` que o workflow já possui — nesse caso, apenas validar se é suficiente e reportar gaps como sugestão
**Fonte**: Exemplos de Perguntas #6

---

### HP-007: migração incluindo normalização de runners
**Input**: "Migre o repo para approved-actions e troque os runners de ubuntu-latest para small-runner"
**Deve**:
- Extrair as linhas `runs-on:` na Fase 0 (passo 6) apenas de `.github/workflows/*.{yml,yaml}`
- Reescrever na Fase 2.5 somente `runs-on: ubuntu-latest` **exato** para `small-runner`, preservando o estilo de quoting original (`"ubuntu-latest"` → `"small-runner"`, `[ubuntu-latest]` → `[small-runner]`)
- Ser idempotente: jobs já em `small-runner`/`medium-runner`/`large-runner`/`xlarge-runner` são pulados em silêncio, sem contar como alteração
- Reportar a mudança na seção `### 🏃 Runners normalizados` do PR + contador no Resumo, e listar os `runs-on` mantidos por exclusão com o motivo
- Incluir na validação pós-migração a checagem de fila: job em "Waiting for a runner to pick up this job" significa label inacessível ao repo (até 24h sem erro; `timeout-minutes` não cobre; `actionlint` não detecta)
**Não deve**:
- Tocar em `ubuntu-24.04`/`ubuntu-22.04`/`ubuntu-20.04`/`ubuntu-latest-N-cores`, `macos-*`, `windows-*`, `${{ matrix.os }}`/qualquer expressão, arrays multi-label (`[self-hosted, linux, x64]`) ou `runs-on:` com `group:`
- Reescrever `ubuntu-latest` fora da chave `runs-on:` — listas de `strategy.matrix.os`, `env:`, defaults de input de `workflow_call` ou `with: RUNS_ON:` de reusable interno
- Tocar na chave `runs:` de um composite `action.yml` (composite action não tem `runs-on`)
- Injetar `runs-on` em job que só chama reusable workflow (job com `uses:` no nível do job não tem `runs-on`)
- Escolher `medium-runner`/`large-runner` por conta própria a partir do conteúdo do job
**Fonte**: Exemplos de Perguntas #7

<!-- Seção Edge-Cases omitida: o contrato (.claude/commands/creator-skill.md) só a exige quando o
     SKILL.md tem "Regras de Execução", seção que esta skill não tem — tem "Sinais para Abortar
     (Agentic Mode)" e "Modos de Operacao", semanticamente próximas mas não a mesma seção nomeada
     pelo contrato. Nenhuma outra skill do repo com o mesmo padrão (ex.: migrate-to-karavela-packages,
     que também tem "Sinais para Abortar" sem "Regras de Execução") tinha `evals/` no momento desta
     escrita (2026-07) para servir de precedente. Seguindo a letra do contrato em vez de estender
     por analogia. -->

---
name: migrate-to-approved-actions
version: 1.3.0
updated: 2026-08-10
changelog:
  - "1.3.0: normalizar runners — nova Fase 2.5 reescreve `runs-on: ubuntu-latest` → `small-runner` por default (mesma postura de permissions: sempre aplicado, sem perguntar); casa APENAS `ubuntu-latest` exato (com/sem quotes, array de 1 elemento, block sequence de 1 item) e preserva o estilo de quoting; NAO toca imagens pinadas (ubuntu-24.04/22.04/20.04/latest-N-cores), macos-*/windows-*, `${{ }}`/matrix.os, arrays multi-label ([self-hosted, linux, x64]), `runs-on: group:`, nem jobs que so chamam reusable (sem runs-on — nunca injetar); idempotente em *-runner ja existente; sem sizing heuristico (nunca escolhe medium/large sozinho); so em .github/workflows/** — composite action.yml usa `runs:`, nunca tocar; so a chave `runs-on:` — nunca matrix.os/env/inputs/`with: RUNS_ON:`; nova secao no body do PR + contador no Resumo; nova checagem pos-migracao para o modo de falha de fila (label inacessivel → job espera ate 24h sem erro; timeout-minutes nao cobre; actionlint nao detecta)"
  - "1.2.0: IGNORE internal-org actions entirely (stone-payments/*, stone-ton/*, dlpco/*, mundipagg/*, pagarme/* — nunca migrar nem reportar); drop inline version comments on migrated refs + strip pre-existing ones (run #1 left stale `# v4` next to `/v5`); annotate non-approved third-party refs inline (manual-review comment) instead of just reporting; permissions ON by default (no longer opt-in/ask); full PR description (migrado/nao-migrado/interno/permissions); SHA resolution: disambiguate catalog hits by path; ancestry is bounded+best-effort (guards: SHA newer than newest vetted major, or divergent → manual; never silent-guess); comment≠resolved-major → follow real commit (preserve behavior) but ask in interactive / finding in agentic; reusable-workflow (on: workflow_call) permissions caution + job-only-calls-reusable rule; run/github-script signal→scope table; actionlint-limit note"
  - "1.1.0: expand discovery filter (exclude local ./, docker://, expression @${{}} refs; reusable workflows; scan composite action.yml too); reframe Fase 3 permissions as subtractive/deny-by-default + actionlint validation; enforce always-migrate-to-@stable-tag (drop strict/SHA mode); add Modos de Operacao + Sinais para Abortar + Convencao de output (modo agentico)"
  - "1.0.0: initial version — scan repo workflows for public actions, replace with approved-actions wrappers, add workflow-level permissions"
description: "Migrar workflows de um repositorio para usar approved-actions (stone-payments/approved-actions). Use quando o usuario quer substituir referencias diretas a actions de TERCEIROS (ex: actions/checkout@v4) pelo wrapper aprovado (stone-payments/approved-actions/actions/checkout/v4@stable), adicionar permissions explicitas nos workflows, e normalizar os runners trocando `runs-on: ubuntu-latest` por `small-runner` (runner self-hosted da Stone). Tambem atende pedidos focados so no runner: 'trocar o runner', 'usar small-runner', 'normalizar runners', 'sair do ubuntu-latest'. Ignora actions internas da Stone (stone-payments/*, stone-ton/*, dlpco/*, mundipagg/*, pagarme/*). Actions de terceiros sem wrapper sao anotadas inline para revisao manual. Gera descricao de PR completa. Requer gh CLI autenticado. Input: URL do repositorio a migrar."
---

# Skill: Migrar Repositório para Approved Actions

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.
-->

## Quando Usar Esta Skill

Use **esta skill** quando:

- O usuario quer migrar um repositorio para usar `stone-payments/approved-actions` em vez de referencias diretas a actions publicas
- O usuario quer adicionar `permissions` explicitas a workflows GitHub Actions de um repositorio
- O usuario quer **normalizar os runners** — trocar `runs-on: ubuntu-latest` pelo `small-runner` self-hosted da Stone ("trocar o runner", "usar small-runner", "sair do ubuntu-latest")
- O usuario pede para "pinar actions", "usar approved actions", "migrar para approved-actions"
- O usuario fornece uma URL de repositorio e pede para verificar/corrigir actions em uso

**Nao confundir com:**

| Pergunta do usuario | Skill correta |
|---|---|
| "migrar repo para publicar em Karavela Packages" | `migrate-to-karavela-packages` |
| "montar pipeline CI/CD do zero" | `ci-pipeline-design` |
| "corrigir vulnerabilidades / CVEs de um artefato" | `fix-vulnerabilities` |
| "adicionar uma action ao catalogo approved-actions" | Nao e skill — e PR direto no repo `approved-actions` |

## Pre-requisitos

- [GitHub CLI (`gh`)](https://cli.github.com/) instalado e autenticado (`gh auth login`)
- Acesso de leitura ao repositorio-alvo e ao repositorio `stone-payments/approved-actions`
- Para aplicar (Fase 5): acesso de escrita ao repo-alvo **ou** capacidade de fork (ver Fase 5)

## Modos de Operacao

Esta skill suporta **dois modos** de consumo. Identifique o seu antes de seguir o resto da skill — varios comportamentos (confirmacoes, abortos, saida) dependem dele.

### Interativo (Claude Code, kli, sessao humano-no-loop)

- Quem carrega: humano via Claude Code, `kli vela`, ou IDE com Skill tool.
- Input: humano responde perguntas no chat; a URL do repo vem do prompt.
- Decisoes ambiguas (upgrade de major, SHA sem major derivavel): **pergunte ao usuario antes de prosseguir**. Permissions sao aplicadas **por default** (Fase 3) — nao perguntar se deve incluir.
- Saida: relatorio no chat + diff apresentado para confirmacao; PR aberto apos o usuario confirmar (Fase 5).

### Agentico (workflow Temporal / `vela-agent` em Pod efemero)

- Quem carrega: `vela-agent` rodando num Pod efemero; prompt construido pelo `temporal-worker`. Skill montada via ConfigMap em `$HOME/.claude/skills/migrate-to-approved-actions/`.
- Input: parametros vem da activity (`owner/repo`). **Nao ha canal de chat com o usuario durante a execucao.**
- Decisoes ambiguas: **NUNCA pause esperando humano.** Em vez disso:
  - Ambiguidade bloqueante (ver "Sinais para Abortar"): emita finding bloqueante e termine o stage; o workflow marca como `NEEDS_HUMAN`.
  - Ambiguidade com default razoavel: aplique o default da skill (ex: migrar so para a **mesma** major, nunca forcar upgrade; permissions aplicadas por default; terceiro sem wrapper → anotar inline e seguir), **documente a escolha no PR body**, e prossiga.
- Saida: o agente edita, valida com `actionlint`, comita, pusha e abre PR draft. Reviewers escrevem findings — ver "Convencao de output (modo agentico)" no fim desta skill.

> **Como saber em que modo voce esta:** se o prompt inicial menciona `WorkflowID`, `FindingsPath`, ou voce le este texto via Skill tool dentro de um Pod efemero — **agentico**. Caso contrario, **interativo**.

## Sinais para Abortar (Agentic Mode)

> Aplica-se ao **modo agentico**. No modo interativo, sao **sugestoes** de "puxar humano para o loop", nao abortos automaticos.

Em qualquer um dos casos abaixo: emita finding bloqueante claro, termine o stage, deixe como `NEEDS_HUMAN`. **Nao adivinhe, nao force.**

1. **Sem acesso de escrita nem fork possivel** ao repo-alvo — sem caminho para abrir PR.
2. **Catalogo inacessivel** (`gh api` ao `approved-actions` falha) — sem source-of-truth, nao migrar as cegas. *(Action de terceiros sem wrapper NAO e abort: anotar inline + reportar — ver Fase 2.)*
3. **`uses:` com ref por expressao** (`@${{ ... }}`) que nao da para resolver a major estaticamente.
4. **SHA pin sem major derivavel** nem no catalogo, nem via tags upstream, nem por ancestralidade (ver edge case "SHA pins diretos").
5. **Workflow ja tem `permissions:` que parece insuficiente** para o que os steps fazem — ajustar pode quebrar; reportar e nao sobrescrever.

## Escopo

**Cobre:**

- **Descoberta de actions**: listar todos os workflows `.github/workflows/*.{yml,yaml}` **e** os `action.yml`/`action.yaml` de composite actions do repositorio-alvo via `gh`, e extrair todas as referencias `uses:` de actions de terceiros
- **Mapeamento para approved-actions**: cruzar cada action de terceiro encontrada com o catalogo `stone-payments/approved-actions` (`.catalog-entries.tsv`) para identificar se existe wrapper aprovado e qual major version usar
- **Reescrita de referencias**: substituir `<vendor>/<action>@<version>` por `stone-payments/approved-actions/<vendor>/<action>/<major>@stable` (apontando para o release estavel do catalogo), **sem** comentario de versao inline (e removendo qualquer `# vX` pre-existente — ver Fase 2)
- **Actions com subpath**: actions como `github/codeql-action/init@v4` mapeiam para `stone-payments/approved-actions/github/codeql-action/init/v4@stable`
- **Anotacao de actions de terceiros sem wrapper**: quando uma action de terceiro nao tem wrapper no catalogo, **manter a linha original** e adicionar um comentario inline marcando que precisa de revisao manual (ver Fase 2)
- **Adicao de permissions (por default)**: inserir bloco `permissions:` no top-level e/ou por job seguindo menor privilegio — aplicado **automaticamente**, sem perguntar
- **Normalizacao de runners (por default)**: trocar `runs-on: ubuntu-latest` por `runs-on: small-runner` (pool self-hosted da Stone) em todo job dos workflows — aplicado **automaticamente**, sem perguntar. Casa **apenas `ubuntu-latest` exato**; toda outra forma de `runs-on` fica intacta (ver Fase 2.5)
- **Descricao de PR completa**: gerar um corpo de PR detalhando o que foi migrado, o que foi anotado para revisao manual, o que e interno (ignorado), as permissions adicionadas e os runners normalizados

**Ignora (deixa intacto, nunca migra nem reporta como nao-aprovada):**

- **Actions internas da Stone** — qualquer `uses:` cujo owner seja `stone-payments`, `stone-ton`, `dlpco`, `mundipagg` ou `pagarme`. Essas NAO precisam de approved-actions (sao internas/confiaveis). Mesmo que exista wrapper no catalogo, **nao migrar**. Mesmo que NAO exista wrapper, **nao reportar** como nao-aprovada. Apenas listar como "interna (ignorada)" no relatorio.

**Nao cobre:**

- Criar wrappers novos no repositorio `approved-actions` (isso e um PR separado, com revisao de CODEOWNERS)
- Reusable workflows (`.github/workflows/*.yml@ref`) — esses sao referenciados diretamente, nao via approved-actions
- Migracao de actions depreciadas para alternativas (ex: `actions/cache@v2` → `v4`) — a skill migra para o wrapper da mesma major, nao faz upgrade automatico
- **Runners nao-Linux e imagens pinadas** — `macos-*`, `windows-*`, `ubuntu-24.04`/`ubuntu-22.04`/`ubuntu-20.04`, `ubuntu-latest-N-cores` e `runs-on` dirigido por matrix/expressao ficam **intactos** (ver Fase 2.5)
- **Dimensionamento de runner** — a skill escreve **sempre `small-runner`**, nunca escolhe `medium-runner`/`large-runner`/`xlarge-runner` por conta propria. Se um job precisar de mais recursos (timeout/OOM), o ajuste e manual e posterior — ver a skill `ci-pipeline-design`

## Exemplos de Perguntas

- *"Migre o repositorio stone-payments/my-api para usar approved-actions"*
- *"Quais actions publicas o repo stone-payments/payment-service usa que nao estao no approved-actions?"*
- *"Substitua todas as actions por approved-actions e adicione permissions nos workflows"*
- *"/migrate-to-approved-actions https://github.com/stone-payments/my-repo"*
- *"Preciso pinar as actions do meu repo, pode fazer?"*
- *"Adicione permissions explicitas nos workflows do meu repositorio"*
- *"Migre o repo para approved-actions e troque os runners de ubuntu-latest para small-runner"*

## Fluxo Canonico

### Fase 0 — Clonar e Descobrir

**Input:** URL do repositorio (ex: `https://github.com/stone-payments/my-repo` ou `stone-payments/my-repo`)

1. Extrair `owner/repo` da URL fornecida.
2. Listar workflows do repositorio (cobrir `.yml` **e** `.yaml`):
   ```bash
   gh api repos/{owner}/{repo}/contents/.github/workflows --jq '.[] | select(.name|test("\\.ya?ml$")) | .name' 2>/dev/null
   ```
3. Para cada workflow, obter conteudo:
   ```bash
   gh api repos/{owner}/{repo}/contents/.github/workflows/{filename} --jq '.content' | base64 -d
   ```
4. **Tambem escanear composite actions do proprio repo.** Actions podem ser fixadas dentro de `action.yml`/`action.yaml` de composite actions, nao so em workflows. Esses `uses:` tem a mesma exposicao de supply-chain e precisam migrar tambem:
   ```bash
   # Listar composite actions versionadas no repo (caminho convencional: .github/actions/*/action.yml)
   gh api repos/{owner}/{repo}/git/trees/HEAD?recursive=1 \
     --jq '.tree[].path | select(test("(^|/)action\\.ya?ml$"))' 2>/dev/null
   # Para cada path encontrado, obter conteudo e extrair `uses:` igual aos workflows
   gh api repos/{owner}/{repo}/contents/{path} --jq '.content' | base64 -d
   ```
5. Extrair todas as linhas `uses:` que referenciam actions de terceiros (excluindo actions internas da Stone, reusable workflows e os tipos nao-migraveis abaixo).
6. **Extrair tambem as linhas `runs-on:`** de cada job — insumo da Fase 2.5 (normalizacao de runners). Duas regras de escopo que **nao** podem ser relaxadas:
   - **Somente `.github/workflows/*.{yml,yaml}`.** Composite actions **nao tem `runs-on`** — o `action.yml` usa a chave `runs:` (`runs: using: composite`). Nunca tocar em `runs:` de um `action.yml`: sao chaves diferentes, e reescrever ali quebra a action.
   - **Somente a chave `runs-on:` em si.** Nunca reescrever um `ubuntu-latest` que apareca em qualquer outro lugar — listas de `strategy.matrix.os`, `env:`, defaults de input de `workflow_call`, ou um input `with: RUNS_ON:` passado a um reusable workflow interno da Stone. Todos esses ficam intactos.

**Regra de filtragem — o que e "action de terceiro" (candidata a migracao):**

Uma referencia `uses:` e candidata a migracao para approved-actions se:
- Segue o formato `<owner>/<repo>@<ref>` ou `<owner>/<repo>/<subpath>@<ref>` (i.e., uma action **hospedada em repo remoto**, com `@<ref>`)
- **NAO** e um reusable workflow (nao termina em `.yml` ou `.yaml` antes do `@`)
- **NAO** ja e uma referencia a `stone-payments/approved-actions/` (ja migrado)
- **NAO** e uma action interna da Stone (ver regra de ignore abaixo)

**Tipos de `uses:` que NAO sao migraveis — excluir e nunca reescrever** (caso contrario a skill gera diffs invalidos):

| Forma do `uses:` | Como reconhecer | Por que excluir |
|---|---|---|
| **Local action** | Comeca com `./` ou `../` (ex: `./.github/actions/build`, `../shared`) | Vive no proprio repo; nao tem `owner/repo@ref` para mapear no catalogo |
| **Docker action** | Comeca com `docker://` (ex: `docker://alpine:3.18`) | E uma imagem de container, nao uma action do catalogo |
| **Ref por expressao** | O `@<ref>` contem `${{ ... }}` (ex: `actions/checkout@${{ matrix.ref }}`, `@${{ inputs.ver }}`) | A major nao e resolvivel estaticamente — reportar como "ref dinamica — resolucao manual", nao adivinhar |
| **Reusable workflow** | O path antes do `@` termina em `.yml`/`.yaml` (ex: `org/repo/.github/workflows/ci.yml@main`) | Referenciado diretamente, fora do escopo do approved-actions (ver "Nao cobre") |

> Para `uses:` com expressao parcial (ex: subpath fixo mas ref dinamica), tratar como **ref por expressao**: reportar, nao reescrever.

**Regra de ignore — actions internas da Stone (NUNCA migrar, NUNCA reportar como nao-aprovada):**

Se o **owner** do `uses:` (o segmento antes da primeira `/`) for um destes, **deixar a linha intacta** — independente de existir ou nao wrapper no catalogo:

```
stone-payments    stone-ton    dlpco    mundipagg    pagarme
```

(comparacao do owner case-insensitive). Essas actions sao internas/confiaveis e nao precisam de approved-actions. Apenas listar como **"interna (ignorada)"** no relatorio — nunca na secao de nao-aprovadas. Isto vale inclusive quando o catalogo contem um wrapper para a action interna: **mesmo assim nao migrar.**

> Excecao ja coberta acima: `stone-payments/approved-actions/...` ja e o destino final — ignorar como "ja migrado", nao como "interna".

### Fase 1 — Carregar Catalogo Approved-Actions

Obter o catalogo atualizado:
```bash
gh api repos/stone-payments/approved-actions/contents/.catalog-entries.tsv --jq '.content' | base64 -d
```

Cada linha do `.catalog-entries.tsv` segue o formato:
```
<reference>\t<version>\t<sha>
```

Exemplo:
```
actions/checkout	v4	34e114876b0b11c390a56381ad16ebd13914f8d5
docker/build-push-action	v6	263435318d21b8e681c14492fe198d362a7d2c83
```

Construir um mapa: `{reference}` → `[versions disponiveis]`

### Fase 2 — Mapear e Classificar

Para cada `uses:` encontrado, classificar em:

| Categoria | Criterio | Acao |
|---|---|---|
| **Interna (ignorada)** | Owner ∈ `stone-payments`, `stone-ton`, `dlpco`, `mundipagg`, `pagarme` | **Nao tocar.** Listar como interna no relatorio. Tem precedencia sobre todas as outras categorias |
| **Migravel** | Terceiro, existe no catalogo com major compativel | Reescrever para approved-actions (sem comentario de versao) |
| **Migravel (major diferente)** | Terceiro, existe no catalogo mas so com major diferente | Avisar usuario, sugerir upgrade de major (nao forcar) |
| **Nao-aprovada (terceiro sem wrapper)** | Terceiro, NAO existe no catalogo | **Manter a linha** + adicionar comentario inline de revisao manual (ver abaixo). Reportar no relatorio/PR |

> **Ordem de avaliacao:** cheque a regra de ignore (interna) **primeiro**. So depois tente mapear no catalogo. Isso evita migrar uma action interna que por acaso tenha wrapper.

**Regra de major version:**

- Extrair major da referencia atual: `actions/checkout@v4` → major `v4`; `actions/checkout@v4.1.1` → major `v4`; `actions/checkout@<sha>` → tentar resolver via catalogo e upstream (ver abaixo)
- Se o catalogo tem a mesma major → migracao direta
- Se o catalogo tem major **superior** disponivel → sugerir ao usuario o upgrade (nao forcar)
- Se o catalogo tem **apenas** major inferior → reportar como incompativel

**Resolucao de referencia por tipo:**

| Tipo de `@<ref>` | Como identificar | Resolucao |
|---|---|---|
| **Major tag** (`v4`, `v6`) | Regex `^v[0-9]+$` | Lookup direto no catalogo por `{reference}\t{ref}` |
| **SemVer completo** (`v4.1.1`, `v3.5.0`) | Regex `^v[0-9]+\.[0-9]+` | Extrair major (`v4.1.1` → `v4`), lookup no catalogo. Se major nao encontrada, reportar. |
| **SHA** (40 hex chars) | Regex `^[0-9a-f]{40}$` | Ver "SHA pins diretos" em Armadilhas — resumo: 1) catalogo por SHA **desambiguando por path** (subpaths de um mesmo repo compartilham SHA — casar `reference` == path do `uses:`); 2) senao, tag upstream **exata**; 3) senao, **ancestralidade = major da MENOR tag semver que contem o commit** (enumere TODAS as tags, `sort -V`, ache a primeira que o contem; NAO compare so contra a "ultima vN"); guards: nenhuma tag contem / major fora do catalogo → manual; 4) senao, **nao migrar** — anotar inline. Comentario `# vX` corrobora (na duvida, costuma estar certo). |
| **Branch** (`main`, `master`, `develop`, `latest`) | Nao e SHA nem SemVer | 1) Procurar `{reference}\t{branch}` no catalogo — se encontrar, migrar para `stone-payments/approved-actions/{reference}/{branch}@stable`. 2) Se nao encontrar wrapper exato para o branch, sugerir migrar para a major version mais recente disponivel no catalogo. |
| **Ja e approved-actions** | Comeca com `stone-payments/approved-actions/` | Ignorar — ja migrado. |

**Formato de reescrita (migravel) — SEM comentario de versao:**

```
# Antes (action direta):
uses: actions/checkout@v4
uses: docker/build-push-action@v6
uses: gittools/actions/gitversion/setup@v3

# Depois (approved-actions):
uses: stone-payments/approved-actions/actions/checkout/v4@stable
uses: stone-payments/approved-actions/docker/build-push-action/v6@stable
uses: stone-payments/approved-actions/gittools/actions/gitversion/setup/v3@stable
```

**Nao adicionar comentario de versao, e REMOVER comentarios `# vX` pre-existentes.** A major ja vive no path (`/v4`) e o pin e `@stable` — um comentario `# v4` herdado e redundante e, pior, fica **mentiroso** quando a major resolvida difere do comentario (ex: um SHA comentado `# v4` que na verdade resolve para `v5` produziria `.../checkout/v5@stable # v4`). Sempre descartar o comentario de versao na reescrita:

```
# Antes (SHA pinado com comentario do Dependabot):
uses: actions/checkout@08c6903cd8c0fde910a37f88322edcfb5dd907a8 # v5.0.0

# Depois (comentario removido):
uses: stone-payments/approved-actions/actions/checkout/v5@stable
```

> Comentarios que **nao** sao de versao (ex: explicando *por que* aquele step existe) devem ser preservados. Remover apenas o token de versao (`# v4`, `# v5.0.0`, `#v1.5.1`, etc.).

**Formato de anotacao (terceiro sem wrapper) — manter a linha, marcar para revisao:**

Quando uma action de terceiro nao tem wrapper no catalogo, **nao reescrever** — manter o `uses:` original e anexar um comentario inline padronizado:

```
# Antes:
uses: koslib/helm-eks-action@v1.25.2

# Depois (linha intacta + marcador):
uses: koslib/helm-eks-action@v1.25.2 # approved-actions: nao encontrado no catalogo — revisao manual necessaria
```

Se a linha ja tiver um comentario, preservar o existente e acrescentar o marcador depois dele. Toda action anotada assim entra tambem na secao "Nao-aprovadas" do relatorio/PR.

**Regra do `@stable` (sempre tag, nunca SHA):** A referencia do catalogo e **sempre** o tag `@stable` — o release estavel mantido pela equipe de plataforma. **Migrar sempre para a tag**, inclusive quando o uso original era um SHA pin: o ponto do approved-actions e que o SHA upstream ja foi vetado e fica fixado **dentro** do wrapper, entao o consumidor rastreia `@stable` e recebe re-vetagens automaticamente. Nao oferecer "strict mode" / pin por SHA do catalogo — isso contraria a politica de sempre acompanhar o tag.

> Consequencia para SHA pins existentes: um `actions/checkout@<sha>` vira `stone-payments/approved-actions/actions/checkout/<major>@stable`. A imutabilidade do SHA upstream e preservada pelo wrapper; o que muda e que updates re-vetados passam a chegar via `@stable`. Documentar essa troca no relatorio/PR para o usuario que pinava por SHA deliberadamente.

### Fase 2.5 — Normalizar Runners (`ubuntu-latest` → `small-runner`)

**Aplicada POR DEFAULT** — nao perguntar se deve incluir (mesma postura da Fase 3). Para cada job dos workflows cujo `runs-on:` seja **exatamente `ubuntu-latest`**, trocar por `small-runner` (pool de runners self-hosted da Stone). Motivacao: `small-runner` e o default recomendado para a maioria dos jobs (build, deploy, testes unitarios) e reduz custo — ver a skill `ci-pipeline-design`.

> ⚠️ **Modo de falha que nada mecanico detecta:** se o label `small-runner` **nao** estiver acessivel ao repo-alvo, o job **nao falha rapido** — fica em *"Waiting for a runner to pick up this job"* por ate 24h, sem erro e sem sinal claro. `timeout-minutes` limita apenas o tempo de **execucao** depois que um runner pega o job, **nao** cobre espera de fila (limitacao da plataforma, nao configuravel via workflow). `actionlint` tambem nao detecta: ele valida a sintaxe do `runs-on`, nao a alcancabilidade do label. Por isso a mudanca e sempre **reportada explicitamente** no PR e a checagem do primeiro CI e obrigatoria (ver "Validacao pos-migracao").

**Formas reescritas — trocar apenas o valor, PRESERVANDO o estilo de quoting original:**

| Antes | Depois |
|---|---|
| `runs-on: ubuntu-latest` | `runs-on: small-runner` |
| `runs-on: "ubuntu-latest"` | `runs-on: "small-runner"` |
| `runs-on: 'ubuntu-latest'` | `runs-on: 'small-runner'` |
| `runs-on: [ubuntu-latest]` (array de **1** elemento) | `runs-on: [small-runner]` |
| block sequence com **1** item (`runs-on:` + linha `  - ubuntu-latest`) | `  - small-runner` |

**Formas NAO reescritas — deixar intactas e reportar** (caso contrario a skill quebra o job ou muda comportamento silenciosamente):

| Forma do `runs-on:` | Como reconhecer | Por que excluir |
|---|---|---|
| **Imagem pinada** | `ubuntu-24.04`, `ubuntu-22.04`, `ubuntu-20.04`, `ubuntu-latest-4-cores` | O pin normalmente e **deliberado** (reprodutibilidade de toolchain). Trocar muda a imagem do SO, nao so o host |
| **Nao-Linux** | `macos-*`, `windows-*` | Nao existe equivalente no pool self-hosted Linux |
| **Expressao / matrix** | O valor contem `${{ ... }}` (ex: `${{ matrix.os }}`, `${{ inputs.runner }}`) | Nao resolvivel estaticamente — mesma razao da exclusao de `uses:` por expressao (Fase 0). **Nao** reescrever nem o `runs-on`, nem os valores da lista `matrix.os` |
| **Array multi-label** | Mais de um label (ex: `[self-hosted, linux, x64]`) | Ja e self-hosted; a semantica e "runner que tem TODOS estes labels" — trocar por um label unico muda o alvo |
| **Runner group** | `runs-on:` com `group:` aninhado (com ou sem `labels:`) | Ja aponta para um grupo de runners explicito |
| **Ja normalizado** | `small-runner`, `medium-runner`, `large-runner`, `xlarge-runner` | **No-op idempotente** — pular em silencio, nao contar como alteracao (mesma logica de "Repositorio parcialmente migrado") |
| **Job que so chama reusable** | O job tem `uses:` no nivel do job e **nenhum** `runs-on` | Um job que chama reusable workflow **nao tem** `runs-on` — o runner e decidido pelo reusable. **NUNCA injetar** um `runs-on` aqui: e invalido e o `actionlint` rejeita. Analogo direto da regra 7 de permissions (Fase 3) |

**Idempotencia:** rodar a skill duas vezes no mesmo repo nao produz diff na segunda vez — jobs ja em `*-runner` sao pulados.

> **Caveat a registrar uma vez no PR (nao por job):** jobs que usam `container:` ou `services:` dependem de Docker disponivel no host. Ao sair do `ubuntu-latest` (GitHub-hosted, com Docker garantido) para o pool self-hosted, confirmar no primeiro CI que esses jobs ainda sobem os containers.

**Sem dimensionamento automatico:** escrever **sempre `small-runner`**. Nao inferir `medium-runner`/`large-runner` a partir do conteudo do job (mutation testing, build de imagem grande, teste de carga), nao anotar sugestoes de tamanho por job. Se um job estourar timeout ou memoria depois, o upgrade e uma decisao manual posterior — a skill nao adivinha.

### Fase 3 — Adicionar Permissions

**Permissions sao adicionadas POR DEFAULT** — nao perguntar se deve incluir. Para cada workflow que nao possui bloco `permissions:` no top-level, adicionar permissions minimas baseadas nas actions usadas **e** no que os steps `run:`/`github-script` fazem com o token (ver tabela de sinais e regra 5).

> ⚠️ **Mas entenda o risco: adicionar `permissions:` e uma operacao SUBTRATIVA, nao aditiva.** No GitHub Actions, enquanto um workflow **nao** tem bloco `permissions:`, o `GITHUB_TOKEN` usa o default do repositorio/org — frequentemente permissivo. **No instante em que voce insere qualquer bloco `permissions:`, todo escopo que voce NAO listar cai para `none`.** Um `permissions: contents: read` mal calibrado pode **quebrar** jobs que dependiam do token permissivo (push de tags, comentarios em PR, upload de release, chamadas `gh`). Por isso: derive o conjunto a partir do uso real (actions + scripts), eleve por job, e **sempre valide com `actionlint`** antes de commitar (se indisponivel, no minimo parse YAML valido). Documente os blocos adicionados no PR para revisao.

**Mapeamento de permissions por action comum:**

| Action | Permissions necessarias |
|---|---|
| `actions/checkout` | `contents: read` |
| `actions/upload-artifact` | `contents: read` |
| `actions/download-artifact` | `contents: read` |
| `actions/cache` | `contents: read` |
| `actions/cache/restore` | `contents: read` |
| `actions/cache/save` | `contents: read` |
| `actions/setup-node` | `contents: read` |
| `actions/setup-python` | `contents: read` |
| `actions/setup-go` | `contents: read` |
| `actions/setup-java` | `contents: read` |
| `actions/setup-dotnet` | `contents: read` |
| `actions/create-release` | `contents: write` |
| `actions/create-github-app-token` | `contents: read` |
| `actions/github-script` | depende do script — default `contents: read`; inspecionar corpo do script para determinar se precisa `issues: write`, `pull-requests: write`, etc. |
| `actions/dependency-review-action` | `contents: read`, `pull-requests: write` |
| `actions/attest` | `id-token: write`, `attestations: write` |
| `actions/deploy-pages` | `pages: write`, `id-token: write` |
| `actions/upload-pages-artifact` | `pages: write` |
| `actions/labeler` | `contents: read`, `pull-requests: write` |
| `docker/login-action` | `contents: read`, `packages: write` (se push para GHCR) |
| `docker/build-push-action` | `contents: read`, `packages: write` (se push para GHCR) |
| `docker/metadata-action` | `contents: read` |
| `github/codeql-action/*` | `security-events: write`, `contents: read`, `actions: read` |
| `peter-evans/create-pull-request` | `contents: write`, `pull-requests: write` |
| `softprops/action-gh-release` | `contents: write` |
| `marocchino/sticky-pull-request-comment` | `pull-requests: write` |
| `sigstore/cosign-installer` | `id-token: write`, `contents: read` |
| `aws-actions/configure-aws-credentials` | `id-token: write` (se OIDC), `contents: read` |
| `google-github-actions/auth` | `id-token: write`, `contents: read` |
| `golangci/golangci-lint-action` | `contents: read` |
| `EnricoMi/publish-unit-test-result-action` | `checks: write`, `pull-requests: write` |

> A tabela cobre actions. Mas o escopo necessario tambem depende de actions **internas** ignoradas (ex: `stone-payments/.../request-dt-token` pode exigir `id-token: write`) e dos steps `run:`/`github-script`. Inspecione o job inteiro, nao so as actions de terceiros.

**Sinais em `run:` / `actions/github-script` → escopo necessario:**

Steps que usam `${{ secrets.GITHUB_TOKEN }}`, `${{ github.token }}`, `gh` CLI ou `github.rest.*` consomem o mesmo token. Derive o escopo pelo que o script faz:

| Sinal no step | Escopo necessario |
|---|---|
| `git push`, `git tag`, push de commit/branch | `contents: write` |
| `gh release create`, `softprops/action-gh-release`, release-drafter | `contents: write` |
| `gh pr create/edit/merge/comment`, `github.rest.pulls.*`, `github.rest.issues.createComment` (em PR) | `pull-requests: write` |
| `gh issue ...`, `github.rest.issues.*` (labels/issues), adicionar label | `issues: write` (+ `pull-requests: write` se for label em PR) |
| `repos.createCommitComment`, `github.rest.repos.*` de escrita | `contents: write` |
| `gh api .../deployments`, criar deployment status | `deployments: write` |
| push de imagem para GHCR (`docker push ghcr.io/...`) | `packages: write` |
| upload de SARIF / code scanning | `security-events: write` |
| so leitura (`gh pr view`, `gh api` GET, checkout) | `contents: read` |

**Regras de permissions:**

1. Se o workflow ja tem `permissions:` definido (top-level ou por job), **nao sobrescrever** — apenas validar se e suficiente e reportar gaps como sugestao.
2. Se nao tem `permissions:`, a estrategia e **restringir no top-level e elevar por job**:
   - Top-level: definir `permissions: contents: read` como baseline restritiva
   - Por job: adicionar `permissions:` no job que precisar de permissoes extras (ex: `packages: write`, `security-events: write`)
   - Isso garante que jobs que so fazem build/test nao recebam write desnecessario
3. Sempre incluir `contents: read` no top-level (necessario para checkout).
4. A posicao do bloco `permissions:` top-level no YAML deve ser logo apos `on:` (triggers) e antes de `jobs:`.
5. **Cuidado com `run:`/`github-script` steps**: aplicar a tabela de sinais acima. Se algum step usa `gh` CLI, `${{ github.token }}`, `${{ secrets.GITHUB_TOKEN }}` ou `github.rest.*`, as permissions do workflow/job tambem afetam esses steps — nao quebrar chamadas que precisam de write.
6. **Workflow que e ele proprio um reusable (`on: workflow_call`) — CUIDADO REDOBRADO**: adicionar um `permissions:` top-level restritivo a um workflow `workflow_call` muda o **piso de permissao para TODOS os repos que o chamam**. Isso pode quebrar consumidores externos silenciosamente. Para workflows `workflow_call`: prefira definir permissions **por job** (nao um top-level restritivo que afeta callers), e **sinalize no relatorio/PR** que o workflow e reusable e consumido por terceiros. Na duvida, nao restrinja o top-level de um reusable — reporte como item de revisao.
7. **Job cujo unico passo chama um reusable workflow externo**: as permissions necessarias sao determinadas pelo **reusable chamado**, nao pelas actions locais (nao ha nenhuma). **Nao** injetar um `contents: read` restritivo nesse caso — pode quebrar o reusable. Deixar sem bloco e reportar como "permissions a definir manualmente (depende do reusable X)".
8. **Reusable workflows chamados**: se o workflow chama reusable workflows (`uses:` no nivel do job), o caller herda as permissions para o reusable. O reusable pode ter `permissions:` proprio mas nao pode **escalar** alem do que o caller concedeu. Verificar se o reusable exige permissoes que o caller precisa conceder.

**Formato:**

```yaml
name: My Workflow
on:
  push:
    branches: [main]
  pull_request:

permissions:
  contents: read

jobs:
  build:
    runs-on: small-runner
    steps:
      - uses: stone-payments/approved-actions/actions/checkout/v4@stable
      - run: make build

  security-scan:
    runs-on: small-runner
    permissions:
      contents: read
      security-events: write
    steps:
      - uses: stone-payments/approved-actions/actions/checkout/v4@stable
      - uses: stone-payments/approved-actions/github/codeql-action/init/v4@stable
      - uses: stone-payments/approved-actions/github/codeql-action/analyze/v4@stable

  publish:
    runs-on: small-runner
    permissions:
      contents: read
      packages: write
    steps:
      - uses: stone-payments/approved-actions/actions/checkout/v4@stable
      - uses: stone-payments/approved-actions/docker/login-action/v3@stable
      - uses: stone-payments/approved-actions/docker/build-push-action/v6@stable
```

### Fase 4 — Gerar Resultado

Apresentar ao usuario:

1. **Resumo da migracao:**
   - Total de `uses:` encontrados
   - Quantos de terceiros foram migrados (wrapper disponivel)
   - Quantos de terceiros foram anotados para revisao manual (sem wrapper)
   - Quantos sao internos da Stone (ignorados)
   - Quantos workflows receberam `permissions:`
   - Quantos jobs tiveram `runs-on` normalizado (`ubuntu-latest` → `small-runner`) e quantos `runs-on` ficaram intactos por exclusao (imagem pinada, nao-Linux, matrix/expressao, multi-label, group)

2. **Diff por workflow:** para cada arquivo `.github/workflows/*.{yml,yaml}` (e `action.yml`), mostrar:
   - Linhas `uses:` reescritas (sem comentario de versao)
   - Linhas de terceiros sem wrapper anotadas com o marcador de revisao manual
   - Bloco `permissions:` adicionado/ajustado
   - Linhas `runs-on:` reescritas (`ubuntu-latest` → `small-runner`)

3. **Lista de actions nao-aprovadas (terceiros sem wrapper):** para cada uma, indicar referencia atual, quantos workflows a usam, e a sugestao ("Solicitar inclusao no catalogo via PR em stone-payments/approved-actions" ou "Avaliar alternativa aprovada").

4. **Lista de internas ignoradas:** as actions da Stone deixadas intactas (apenas informativo).

5. **Descricao de PR pronta:** o corpo completo do PR (ver Fase 5) — mesmo no modo interativo, gerar e mostrar para o usuario revisar.

### Fase 5 — Aplicar (com confirmacao)

**Modo interativo:**
- Apresentar diff completo ao usuario
- Perguntar se deseja aplicar todas as mudancas ou selecionar individualmente
- Apos confirmacao, executar o fluxo abaixo para abrir o PR

**Passos de execucao:**

1. **Clonar o repositorio e criar branch:**
   ```bash
   gh repo clone {owner}/{repo} /tmp/{repo} -- --depth=1
   cd /tmp/{repo}
   git checkout -b ci/migrate-to-approved-actions
   ```

2. **Aplicar as mudancas nos workflows:**
   - Para cada arquivo `.github/workflows/*.{yml,yaml}` (e `action.yml`/`action.yaml` de composite actions):
     - Reescrever as linhas `uses:` de terceiros migraveis conforme a Fase 2, **removendo o comentario de versao** (`# vX`)
     - Anotar as linhas de terceiros **sem wrapper** com o marcador de revisao manual (linha original intacta)
     - **Nao tocar** nas actions internas da Stone (owner em `stone-payments`/`stone-ton`/`dlpco`/`mundipagg`/`pagarme`)
   - Normalizar `runs-on` conforme a Fase 2.5 (**por default**): trocar `ubuntu-latest` exato por `small-runner` preservando o estilo de quoting; **so** nos workflows (nunca em `runs:` de `action.yml`), **so** na chave `runs-on:` (nunca em `matrix.os`/`env:`/inputs), e **nunca** injetar `runs-on` em job que so chama reusable
   - Inserir/ajustar bloco `permissions:` conforme a Fase 3 (**por default**)
   - Editar de forma cirurgica preservando indentacao, comentarios nao-de-versao e anchors YAML. Edicao linha-a-linha do `uses:` e preferivel a reescrever o arquivo; `yq` pode reordenar/normalizar e perder comentarios — usar com cuidado
   - **Validar antes de commitar:** rodar `actionlint` em todos os arquivos alterados; se indisponivel, garantir no minimo parse YAML valido. Nao commitar se a validacao falhar.

3. **Commit:**
   ```bash
   git add .github/workflows/
   git commit -m "ci: migrate to approved-actions + add workflow permissions"
   ```

4. **Push:**
   ```bash
   git push origin ci/migrate-to-approved-actions
   ```

5. **Abrir PR draft** com **descricao completa** (sempre gerar este corpo — preencher cada secao com os dados reais da execucao):
   ```bash
   gh pr create --draft \
     --title "ci: migrate to approved-actions + add workflow permissions" \
     --body "$(cat <<'EOF'
   ## Migracao para Approved-Actions

   Migra as actions de **terceiros** para `stone-payments/approved-actions@stable`, adiciona `permissions:` explicitas e normaliza os runners (`ubuntu-latest` → `small-runner`). Actions internas da Stone foram deixadas intactas; actions de terceiros sem wrapper foram anotadas inline para revisao manual.

   ### Resumo
   | Categoria | Qtd |
   |---|---|
   | Migradas (terceiros) | {N} |
   | Anotadas p/ revisao manual (terceiros sem wrapper) | {N} |
   | Internas da Stone (ignoradas) | {N} |
   | Workflows com `permissions:` adicionado | {N} |
   | Jobs com `runs-on` normalizado (`ubuntu-latest` → `small-runner`) | {N} |
   | `runs-on` mantidos por exclusao (pinado / nao-Linux / matrix / multi-label / group) | {N} |
   | Reusable workflows tocados (`on: workflow_call`) | {N} |

   ### ✅ Actions migradas (terceiros)
   {tabela: workflow | antes | depois | tipo de ref}

   ### ⚠️ Actions de terceiros sem wrapper — revisao manual (NAO migradas)
   Mantidas com a referencia original + comentario `# approved-actions: nao encontrado ...`. Follow-up: solicitar inclusao no catalogo (PR em `stone-payments/approved-actions`, gated por CODEOWNERS) ou avaliar alternativa aprovada.
   {tabela: action | ref | workflows}

   ### ℹ️ Actions internas da Stone (ignoradas por design)
   Owners `stone-payments`/`stone-ton`/`dlpco`/`mundipagg`/`pagarme` nao passam por approved-actions. Listadas apenas para transparencia.
   {tabela: action | workflows}

   ### 🔒 Permissions adicionadas
   {tabela: workflow | top-level | per-job}

   > ⚠️ `permissions:` e **subtrativo**: qualquer escopo nao-listado vira `none`. Confirmar no CI que nenhum job perdeu permissao — atencao especial aos workflows `on: workflow_call` consumidos por outros repos.

   ### 🏃 Runners normalizados
   {tabela: workflow | job | antes | depois}

   > ⚠️ **Confirme que o primeiro CI pegou runner.** Se um job ficar em *"Waiting for a runner to pick up this job"*, o label `small-runner` **nao esta acessivel a este repo** — o job **nao falha rapido**, fica na fila por ate 24h sem erro, e `timeout-minutes` **nao** cobre espera de fila. `actionlint` nao detecta isso (valida sintaxe, nao alcancabilidade do label). Nesse caso: reverter o `runs-on` para `ubuntu-latest` ou solicitar acesso ao pool de runners internos.
   >
   > Jobs com `container:`/`services:` dependem de Docker no host — conferir no primeiro CI que ainda sobem os containers fora do runner GitHub-hosted.

   ### Notas
   - SHA pins de terceiros foram migrados para `@stable` (a imutabilidade do SHA upstream e preservada **dentro** do wrapper; updates re-vetados passam a chegar via `@stable`).
   - Comentarios de versao inline (`# vX`) foram removidos das linhas migradas (a major vive no path).
   - Runners: apenas `runs-on: ubuntu-latest` **exato** foi trocado por `small-runner` (pool self-hosted da Stone). Imagens pinadas (`ubuntu-24.04`/`22.04`/`20.04`), `macos-*`/`windows-*`, `runs-on` por expressao/matrix, arrays multi-label e runner groups ficaram **intactos**. Nenhum job foi promovido a `medium-runner`/`large-runner` — dimensionamento e decisao manual.

   ### Referencia
   - [approved-actions README](https://github.com/stone-payments/approved-actions)
   - Catalogo lido de `.catalog-entries.tsv` em {data}
   EOF
   )"
   ```

**Cleanup:** apos PR aberto, remover o clone temporario:
```bash
rm -rf /tmp/{repo}
```

## Armadilhas e Edge Cases

### Actions com subpath

Actions como `github/codeql-action/init` ou `gittools/actions/gitversion/setup` possuem subpath. O mapeamento preserva o subpath:

```
github/codeql-action/init@v4 → stone-payments/approved-actions/github/codeql-action/init/v4@stable
gittools/actions/gitversion/setup@v3 → stone-payments/approved-actions/gittools/actions/gitversion/setup/v3@stable
```

### SHA pins diretos

Se o workflow ja usa SHA pin (ex: `actions/checkout@de0fac2e4500dabe0009e67214ff5f5447ce83dd`):

1. **Buscar no catalogo — DESAMBIGUANDO POR PATH**: verificar se o SHA aparece na coluna 3. ⚠️ **Cuidado: varios subpaths de um mesmo repo compartilham o mesmo SHA de release** (ex: `actions/cache`, `actions/cache/restore` e `actions/cache/save` tem o SHA identico; idem `github/codeql-action/*`). Um indice ingenuo `sha → reference` colide e elege o subpath errado. **Sempre escolher a linha cujo `reference` seja exatamente o path do `uses:` original.**
   ```bash
   # uses: actions/cache@27d5ce7f... → procurar a linha com reference == "actions/cache"
   awk -F'\t' '$3=="27d5ce7f107fe9357f9df03efb73ab90386fccae" && $1=="actions/cache"' <<< "$CATALOG"
   # → actions/cache	v5	27d5ce7f...   ⇒  stone-payments/approved-actions/actions/cache/v5@stable
   #   (NAO actions/cache/save, mesmo que tambem case o SHA)
   ```
2. **Resolver via upstream (tag exata)**: se o SHA nao estiver no catalogo, cruzar com as tags do repo upstream:
   ```bash
   gh api repos/{owner}/{repo}/tags --paginate --jq '.[] | [.name, .commit.sha] | @tsv'
   # achar a tag cujo SHA == o SHA pinado → extrair major (ex: v4.1.6 → v4)
   ```
3. **Resolver por ANCESTRALIDADE — a major e a do PRIMEIRO release que CONTEM o commit**: se o SHA nao bate com nenhuma tag exata (commit intermediario), nao tente "entre quais tags ele esta" comparando contra uma ou duas tags-limite — **isso erra**. A regra correta:
   > **Enumere TODAS as tags semver (`vX.Y.Z`), ordene por versao, e ache a MENOR tag que contem o commit** (i.e., o commit e ancestral dela: `compare/{tag}...{sha}` ⇒ `behind` ou `identical`). A major dessa menor tag e a resposta — foi nela que o codigo efetivamente saiu.
   ```bash
   # ordenar tags semver por versao e achar a primeira que contem o SHA
   gh api repos/{owner}/{repo}/tags --paginate --jq '.[].name' \
     | grep -E '^v[0-9]+\.[0-9]+\.[0-9]+$' | sort -V \
     | while read t; do
         st=$(gh api repos/{owner}/{repo}/compare/$t...{sha} --jq '.status' 2>/dev/null)
         [ "$st" = behind ] || [ "$st" = identical ] && { echo "primeira tag que contem: $t"; break; }
       done
   ```
   ⚠️ **Por que comparar so contra "a ultima v4" (`v4.2.2`) erra:** muitos repos mantem linhas de patch paralelas (ex: `actions/checkout` lancou `v4.3.0`/`v4.3.1` DEPOIS de `v5.0.0`). Um commit pode ser posterior a `v4.2.2` e ainda assim ter saido em `v4.3.0` — logo e **v4**, nao v5. Sempre enumere o conjunto **completo** de tags; ordenacao por numero de versao ≠ ordem cronologica.
   - **GUARD — nenhuma tag contem o commit**: pode ser commit de fork, branch nao-released, ou tag removida (ex: incidentes de supply-chain). **Nao auto-migrar** — anotar para revisao manual.
   - **GUARD — a menor major que contem nao esta no catalogo**: reportar como nao-aprovada/manual.
   - Quando resolver, **sinalizar no relatorio** que foi por ancestralidade (nao tag exata).
4. **Comentario inline como corroboracao**: o `# vX` ao lado do SHA e uma **dica forte de intencao** — use-o para conferir o resultado da ancestralidade.
   - Se ancestralidade **concorda** com o comentario → alta confianca, migrar.
   - Se **divergem**: a major do *commit real* (primeiro release que o contem) reflete os bytes que rodam hoje — **prefira-a**, mas escale a duvida: **modo interativo** PERGUNTA ("o pin esta `# v4` mas resolvi `v5` por ancestralidade — confirma?"); **modo agentico** segue o commit real + emite **finding nao-bloqueante**. ⚠️ Lembre que a ancestralidade tambem pode errar se mal implementada — na duvida entre o comentario e um calculo fragil, o comentario costuma estar certo (ver war story no fim desta secao).
5. **Fallback**: se nenhum metodo (catalogo / tag exata / ancestralidade) resolver, **nao migrar** — manter a linha, anotar com o marcador de revisao manual (Fase 2) e reportar como "SHA sem major derivavel".

> **War story (run real, jun/2026):** `actions/checkout@09d2acae… # v4` foi resolvido por uma analise manual como **v5** ("o commit e posterior a v4.2.2, a ultima v4, e ancestral de v5.0.0"). **Estava errado:** a premissa ignorou que `v4.3.0` foi lancada depois e tambem contem o commit — a resposta certa e **v4** (batendo com o comentario). Licao: enumere TODAS as tags e pegue a menor que contem; trate o comentario como corroboracao; na duvida, manual.

### Referencia a branches (main, master, develop, latest)

O catalogo possui wrappers para branches (ex: `actions/checkout  main`, `ansible/ansible-lint  main`, `oxsecurity/megalinter  latest`). Tratar assim:

1. Se `{reference}\t{branch}` existe no catalogo → migrar para `stone-payments/approved-actions/{reference}/{branch}@stable`
   ```
   ansible/ansible-lint@main → stone-payments/approved-actions/ansible/ansible-lint/main@stable
   ```
2. Se o branch nao existe no catalogo mas existem versions (majors) → sugerir migrar para a major mais recente e avisar o usuario:
   ```
   # catalogo tem actions/checkout v4, v5, v6 mas nao 'develop'
   # → Sugerir: actions/checkout@develop → stone-payments/approved-actions/actions/checkout/v6@stable
   ```
3. Se nenhum wrapper existe para aquela action → reportar como nao-aprovada

### SemVer completo (v4.1.1, v3.5.0, etc.)

O catalogo so tem wrappers por major (ex: `v4`, nao `v4.1.1`). Quando o workflow usa semver completo:

```
actions/checkout@v4.1.1 → major v4 → stone-payments/approved-actions/actions/checkout/v4@stable
golangci/golangci-lint-action@v6.3.2 → major v6 → stone-payments/approved-actions/golangci/golangci-lint-action/v6@stable
```

Isso e seguro porque o wrapper no catalogo ja pina o SHA exato da versao vetada — o consumidor nao precisa se preocupar com qual patch esta usando.

### Comentarios de versao inline (`# vX`)

Muitos workflows (estilo Dependabot/Renovate) carregam um comentario de versao ao lado do `uses:`, ex: `uses: actions/checkout@08c6903... # v5.0.0`. Na migracao:

- **Remover o token de versao** da linha migrada — a major ja esta no path e o pin e `@stable`. Manter o `# v5.0.0` produziria algo redundante e potencialmente contraditorio (ex: `.../checkout/v5@stable # v4` quando o comentario estava desatualizado).
- Usar o comentario apenas como **dica** para resolver a major de um SHA, **nao** como verdade — validar contra o catalogo/upstream; se divergir, vale o commit real.
- Preservar comentarios que **nao** sao de versao.

### Workflows com `permissions` parcial

Se o workflow ja define `permissions:` mas esta incompleto (ex: falta `security-events: write` para CodeQL), **sugerir** a adicao mas **nao sobrescrever** o existente — apresentar como sugestao ao usuario.

### Actions de cache (subpath restore/save)

`actions/cache/restore@v4` e `actions/cache/save@v4` sao subpaths separados no catalogo:
```
actions/cache/restore@v4 → stone-payments/approved-actions/actions/cache/restore/v4@stable
actions/cache/save@v4 → stone-payments/approved-actions/actions/cache/save/v4@stable
```

### Actions internas da Stone — IGNORAR (nunca migrar)

Actions cujo **owner** seja `stone-payments`, `stone-ton`, `dlpco`, `mundipagg` ou `pagarme` sao internas/confiaveis e **nao passam por approved-actions**. Deixar a linha intacta:

- **Independente** de existir wrapper no catalogo — mesmo que o `.catalog-entries.tsv` tenha uma entrada para a action interna (ex: `dlpco/app-github-custom-actions/go-buildfile-info`, `stone-payments/karavela-packages-workflows/actions/request-consumer-token`), **nao migrar**.
- Se nao existe wrapper → **nao reportar como "nao-aprovada"** (nao e — e interna legitima).
- Listar apenas como **"interna (ignorada)"** no relatorio/PR, para transparencia.

```
# Ambas permanecem EXATAMENTE como estao:
uses: dlpco/app-github-custom-actions/go-buildfile-info@main          # interna — ignorada
uses: stone-payments/karavela-packages-workflows/actions/setup@main   # interna — ignorada
```

> O catalogo `approved-actions` pode conter wrappers internos por razoes historicas; a politica desta skill e nao usa-los. A pinagem de actions internas, se desejada, e responsabilidade dos times donos — fora do escopo desta migracao.

### `runs-on` que NAO deve ser normalizado

A Fase 2.5 casa **apenas `ubuntu-latest` exato**. Os casos abaixo sao os que na pratica causam diff errado — todos ficam **intactos** e entram na contagem de "mantidos por exclusao":

```yaml
jobs:
  ok:       { runs-on: ubuntu-latest }          # ← unico que vira small-runner
  pinado:   { runs-on: ubuntu-22.04 }           # pin deliberado — nao tocar
  mac:      { runs-on: macos-14 }               # nao-Linux — sem equivalente no pool
  matriz:
    strategy: { matrix: { os: [ubuntu-latest, windows-latest] } }
    runs-on: ${{ matrix.os }}                   # expressao — e a lista matrix.os TAMBEM fica intacta
  labels:   { runs-on: [self-hosted, linux, x64] }   # multi-label — semantica de conjunto
  grupo:
    runs-on:
      group: my-runner-group                    # ja aponta para um grupo
  jamigrado: { runs-on: small-runner }          # no-op idempotente
  chamador:
    uses: ./.github/workflows/reusable.yml      # job sem runs-on — NUNCA injetar um
```

Dois erros especificos a evitar:

- **Reescrever `ubuntu-latest` dentro de `strategy.matrix.os`.** O job `matriz` acima tem `ubuntu-latest` na lista da matrix. Trocar por `small-runner` ali muda o eixo da matrix (e provavelmente quebra o job `windows-latest` que compartilha o mesmo `runs-on`). Reescreva **so** a chave `runs-on:`.
- **Tocar em `runs:` de um composite `action.yml`.** Composite actions nao tem `runs-on`; a chave e `runs:` (`runs: using: composite`). A Fase 2.5 nao se aplica a `action.yml` — so a `.github/workflows/`.

> **Onde isso morde de verdade:** o label inacessivel nao gera erro. O job entra em *"Waiting for a runner to pick up this job"* e fica ate 24h na fila. `timeout-minutes` so limita a execucao **apos** um runner pegar o job. `actionlint` valida a sintaxe do `runs-on`, nao a alcancabilidade do label — "0 findings" nao prova nada aqui. A unica prova e o CI real (ver "Validacao pos-migracao").

### Repositorio parcialmente migrado

Se o workflow ja tem uma mistura de `stone-payments/approved-actions/...@stable` e referencias diretas:
- Ignorar linhas ja migradas (nao duplicar)
- Migrar apenas as referencias diretas restantes
- No relatorio, indicar quantas ja estavam migradas vs quantas foram migradas agora

### Catalogo crescente (futuro-proof)

O catalogo e lido **dinamicamente** via `gh api` a cada execucao. Se novos wrappers forem adicionados ao `approved-actions` (novos vendors, novas actions, novas majors), a skill automaticamente os detecta sem necessitar atualizacao. Nao codifique em hardcode a lista de actions disponiveis — sempre use o `.catalog-entries.tsv` como source of truth.

## Formato de Resposta Esperado

Ao concluir a analise, apresentar:

```
## Relatorio de Migracao para Approved-Actions

**Repositorio:** {owner}/{repo}
**Workflows analisados:** {N}  ·  **`uses:` encontrados:** {N}
**Migrados (terceiros):** {N}  ·  **Anotados p/ revisao manual:** {N}  ·  **Internos (ignorados):** {N}  ·  **Ja migrados:** {N}
**Runners normalizados:** {N} jobs  ·  **`runs-on` mantidos por exclusao:** {N}

### ✅ Migrados — Terceiros ({N})

| Workflow | Antes | Depois | Tipo de ref |
|---|---|---|---|
| ci.yml | `actions/checkout@v4` | `stone-payments/approved-actions/actions/checkout/v4@stable` | major tag |
| ci.yml | `actions/checkout@de0fac2e... # v4` | `stone-payments/approved-actions/actions/checkout/v4@stable` | SHA → v4 (comentario removido) |
| deploy.yml | `ansible/ansible-lint@main` | `stone-payments/approved-actions/ansible/ansible-lint/main@stable` | branch |

### ⚠️ Nao-Aprovadas — Terceiros sem wrapper ({N}) — NAO migradas, anotadas inline

| Action | Ref | Workflows | Sugestao |
|---|---|---|---|
| `koslib/helm-eks-action` | `v1.25.2` | deploy.yml | Solicitar inclusao no catalogo |
| `another/action` | `abc123...` | build.yml | SHA nao-resolvido — revisao manual |

### ℹ️ Internas da Stone ({N}) — ignoradas por design (linha intacta)

| Action | Workflows |
|---|---|
| `stone-payments/karavela-packages-workflows/actions/setup@main` | build.yml |
| `dlpco/app-github-custom-actions/go-buildfile-info@main` | ci.yml |

### 🔒 Permissions Adicionadas ({N} workflows)

| Workflow | Top-level | Per-job | Reusable (`workflow_call`)? |
|---|---|---|---|
| ci.yml | `contents: read` | — | nao |
| deploy.yml | `contents: read` | publish: `packages: write` | nao |

### 🏃 Runners Normalizados ({N} jobs)

| Workflow | Job | Antes | Depois |
|---|---|---|---|
| ci.yml | build | `ubuntu-latest` | `small-runner` |
| ci.yml | test | `ubuntu-latest` | `small-runner` |

**Mantidos por exclusao ({N}):**

| Workflow | Job | `runs-on` | Motivo |
|---|---|---|---|
| ci.yml | e2e | `ubuntu-22.04` | imagem pinada |
| release.yml | notarize | `macos-14` | nao-Linux |
| ci.yml | matrix | `${{ matrix.os }}` | expressao/matrix |

### Proximo Passo

- [ ] Revisar diff e confirmar aplicacao
- [ ] Abrir PRs para actions nao-aprovadas no catalogo
- [ ] Conferir CI dos workflows `workflow_call` (permissions afetam callers)
- [ ] **Confirmar que o primeiro CI pegou runner** — job em "Waiting for a runner" = label `small-runner` inacessivel a este repo (fica ate 24h na fila, sem erro)
```

## Validacao pos-migracao

Apos aplicar as mudancas, o usuario deve:

1. Verificar se os workflows passam no CI (os wrappers sao transparentes — inputs/outputs sao forwarded)
2. Conferir se nenhuma action de **terceiro** ficou referenciando diretamente o upstream (internas da Stone ficam intactas de proposito)
3. Validar que `permissions:` nao esta bloqueando steps que precisam de permissoes extras (lembrar: qualquer bloco `permissions:` torna todo escopo nao-listado `none`) — atencao redobrada aos workflows `on: workflow_call` consumidos por outros repos
4. Rodar `actionlint` localmente para confirmar que os workflows continuam validos
5. **Confirmar que os jobs PEGARAM runner** (obrigatorio quando houve normalizacao de `runs-on`). Se um job fica em *"Waiting for a runner to pick up this job"*, o label `small-runner` **nao esta acessivel a este repo** — o job **nao falha rapido**: fica na fila por ate 24h, sem erro e sem sinal claro, e `timeout-minutes` limita apenas o tempo de **execucao** depois que um runner pega o job (limitacao da plataforma, nao configuravel via workflow). **Rollback:** reverter o `runs-on` para `ubuntu-latest` ou solicitar acesso ao pool de runners internos. Conferir tambem que jobs com `container:`/`services:` ainda sobem os containers no host self-hosted.

> **Limite do `actionlint`:** ele valida sintaxe/YAML e formato de `uses:`, mas **nao** resolve os inputs do wrapper remoto — "0 findings" NAO prova que o wrapper aceita os `with:` encaminhados nem que as permissions estao corretas. **Tampouco valida alcancabilidade de label de runner:** um `runs-on: small-runner` sintaticamente valido nao diz nada sobre existir um runner que va pegar o job. A prova comportamental e o **CI rodando de fato** (especialmente para majors trocadas via SHA, para reusable workflows e para runners normalizados).

## Convencao de output (modo agentico)

> Aplica-se apenas ao **modo agentico**. No modo interativo, o "output" e a resposta no chat + o PR aberto apos confirmacao — esta secao nao se aplica.

### Stage `implementation` (o agente que executa a migracao)

Voce **NAO escreve** `findings.json` aqui — voce **executa**:

1. Edita os arquivos no working dir (`.github/workflows/*.{yml,yaml}` e `action.yml` de composite actions): reescreve `uses:` de terceiros migraveis **sem comentario de versao** (Fase 2), anota terceiros sem wrapper com o marcador de revisao manual, **ignora actions internas da Stone**, normaliza `runs-on: ubuntu-latest` → `small-runner` **por default** (Fase 2.5 — so nos workflows, so a chave `runs-on:`, so `ubuntu-latest` exato), e adiciona `permissions:` **por default** (Fase 3).
2. **Valida com `actionlint`** antes de commitar. Se falhar, nao comite — emita finding bloqueante.
3. Comita com Conventional Commits em pt-BR: `ci: migrate to approved-actions + add workflow permissions`.
4. Pusha na branch ja pre-criada (`git push -u origin <branch>` — nao crie outra).
5. Abre PR **draft** via `gh pr create --draft` seguindo o **body completo** da Fase 5 (resumo, migrados, nao-aprovados anotados, internos ignorados, permissions). Footer: `_vela-agent · workflow <WorkflowID> · solicitado por <RequesterEmail>_`.
6. **NAO escreva nada em `.vela-agent/`** — e scratch do runner, descartado antes do proximo stage.

### Stages `business-review` e `security-review`

Inspecionam o diff e escrevem `.vela-agent/findings.json` (array JSON, **sempre** — mesmo vazio escreva `[]`):

```json
[
  {
    "id": "SR-001",
    "severity": "HIGH",
    "category": "SECURITY",
    "file": ".github/workflows/ci.yml",
    "line": 8,
    "message": "Bloco 'permissions: contents: read' adicionado no top-level pode quebrar o job 'release' que faz push de tag (perdeu contents: write).",
    "suggestion": "Adicionar 'permissions: contents: write' no job 'release'.",
    "blocking": true
  }
]
```

- `id` — prefixo `BR-` (business) ou `SR-` (security) + numero zero-padded.
- `severity` — `LOW | MEDIUM | HIGH | CRITICAL`. `category` — `BUSINESS` ou `SECURITY` (bate com o stage).
- `file` — path relativo a raiz (`""` se N/A). `line` — inteiro **dentro de um hunk do diff**; `0` se N/A.
- `message` / `suggestion` — pt-BR; `suggestion` `""` se nao houver.
- `blocking` — `true` so se DEVE ser resolvido antes do merge.

Findings tipicas desta skill: action nao-aprovada essencial (bloqueante), `uses:` com ref dinamica nao migrada, SHA→tag trocando imutabilidade deliberada, `runs-on: small-runner` num repo sem evidencia de acesso ao pool interno (nao-bloqueante — o job pode ficar em fila por ate 24h sem erro; sugerir conferir o primeiro CI), e — a mais comum — bloco `permissions:` subtrativo quebrando um job.

### Stage `fixer`

Le `.vela-agent/findings.json`, re-comita correcoes na **mesma branch**, **sem** abrir PR novo. **Nao escreve** `findings.json` proprio.

#!/usr/bin/env python3
"""Testes do lint_md.py — gate pré-publicação (armadilhas 2, 4, 6 do corpus DT)."""
import os
import shutil
import subprocess
import sys
import tempfile
import unittest

SCRIPT = os.path.join(os.path.dirname(__file__), "..", "scripts", "lint_md.py")

LIMPO = ("# T\n\nProsa com [link](https://exemplo.test) e `code`.\n\n"
         "## Secao_um\n\nVer [acima](#secao_um). " + "palavra " * 40 + "\n")


def run_lint(files_content, html_content=None):
    """Monta um workdir fake {pt/, html/} e roda o linter nele."""
    wd = tempfile.mkdtemp()
    os.makedirs(wd + "/pt")
    for name, content in files_content.items():
        with open("%s/pt/%s.md" % (wd, name), "w", encoding="utf-8") as f:
            f.write(content)
    if html_content:
        os.makedirs(wd + "/html")
        for name, content in html_content.items():
            with open("%s/html/%s.html" % (wd, name), "w", encoding="utf-8") as f:
                f.write(content)
    try:
        p = subprocess.run([sys.executable, SCRIPT, wd],
                           capture_output=True, text=True)
        return p.returncode, p.stdout + p.stderr
    finally:
        shutil.rmtree(wd)


class LintMd(unittest.TestCase):
    def test_arquivo_limpo_passa(self):
        rc, out = run_lint({"ok": LIMPO})
        self.assertEqual(rc, 0, out)

    def test_html_cru_e_erro(self):
        rc, out = run_lint({"a": LIMPO + "\n<table>\n<tr><td>x</td></tr>\n</table>\n"})
        self.assertEqual(rc, 2)
        self.assertIn("HTML cru", out)

    def test_link_relativo_e_erro(self):
        rc, out = run_lint({"a": LIMPO + "\nVer [config](database.md).\n"})
        self.assertEqual(rc, 2)
        self.assertIn("link relativo", out)

    def test_ancora_sem_destino_avisa(self):
        rc, out = run_lint({"a": LIMPO + "\nVer [x](#dtsecret-managementprovider).\n"})
        self.assertEqual(rc, 1)
        self.assertIn("sem destino", out)

    def test_ancora_para_span_id_nao_avisa(self):
        md = LIMPO + '\n<span id="alvo-x"></span>Def.\n\nVer [x](#alvo-x).\n'
        rc, out = run_lint({"a": md})
        self.assertEqual(rc, 0, out)

    def test_fence_sem_realce_avisa(self):
        rc, out = run_lint({"a": LIMPO + "\n```pebble\n{{ x }}\n```\n"})
        self.assertEqual(rc, 1)
        self.assertIn("pebble", out)

    def test_stub_minusculo_avisa(self):
        rc, out = run_lint({"a": "# T\n\nOnze palavras nao fazem uma doc.\n"})
        self.assertEqual(rc, 1)
        self.assertIn("stub", out)

    def test_swagger_na_origem_avisa(self):
        rc, out = run_lint({"a": LIMPO},
                           {"a": '<div id="swagger-ui"></div>'})
        self.assertEqual(rc, 1)
        self.assertIn("app embutido", out)

    def test_html_dentro_de_fence_nao_dispara(self):
        rc, out = run_lint({"a": LIMPO + "\n```html\n<table><tr></tr></table>\n```\n"})
        self.assertEqual(rc, 0, out)


if __name__ == "__main__":
    unittest.main(verbosity=2)

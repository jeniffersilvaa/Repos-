#!/usr/bin/env python3
"""Testes do md2storage.py — cada caso novo é uma armadilha real do corpus
Dependency-Track v5 (ver STATE.md do run em dt-docs-internalization).

Roda o CLI de verdade (subprocess): o contrato testado é o mesmo que o
SKILL.md manda usar. `python3 tests/test_md2storage.py` na raiz da skill.
"""
import os
import subprocess
import sys
import tempfile
import unittest

SCRIPT = os.path.join(os.path.dirname(__file__), "..", "scripts", "md2storage.py")


def run_md2(md_text, env_extra=None):
    """Executa md2storage.py sobre md_text; retorna (rc, stdout, stderr)."""
    env = dict(os.environ)
    env.pop("DOC_HARVEST_ALLOW_RAW_HTML", None)
    if env_extra:
        env.update(env_extra)
    with tempfile.NamedTemporaryFile("w", suffix=".md", delete=False,
                                     encoding="utf-8") as f:
        f.write(md_text)
        path = f.name
    try:
        p = subprocess.run(
            [sys.executable, SCRIPT, path, "https://exemplo.test/doc", "2026-07-23"],
            capture_output=True, text=True, env=env)
        return p.returncode, p.stdout, p.stderr
    finally:
        os.unlink(path)


class TabelaCelulaFantasma(unittest.TestCase):
    """Armadilha 3: gerador upstream emite célula '-' extra além do cabeçalho."""

    MD = ("# T\n\n"
          "| Nome | Tipo | Default |\n"
          "|---|---|---|\n"
          "| alpine | bool | true | - |\n"
          "| pool | int | 10 | - |\n")

    def test_linhas_clampadas_ao_cabecalho(self):
        rc, out, _ = run_md2(self.MD)
        self.assertEqual(rc, 0)
        self.assertEqual(out.count("<th>"), 3)
        self.assertEqual(out.count("<td>"), 6, "célula fantasma deveria ser descartada")

    def test_linha_curta_e_padded(self):
        md = ("# T\n\n| A | B | C |\n|---|---|---|\n| x | y |\n")
        rc, out, _ = run_md2(md)
        self.assertEqual(rc, 0)
        self.assertEqual(out.count("<td>"), 3, "linha curta deveria ganhar célula vazia")

    def test_extra_com_conteudo_nao_e_descartada(self):
        md = ("# T\n\n| A | B |\n|---|---|\n| x | y | conteudo-real |\n")
        rc, out, err = run_md2(md)
        self.assertEqual(rc, 0)
        self.assertIn("conteudo-real", out, "célula extra NÃO vazia não pode sumir")
        self.assertIn("cabeçalho", err.lower() + err, "deve avisar o desalinhamento")


class HtmlCru(unittest.TestCase):
    """Armadilha 2: md upstream com HTML cru (configuration/properties tinha
    191 <table>) viraria sopa de &lt;table&gt; — precisa falhar alto."""

    MD = ("# T\n\nProsa normal.\n\n"
          "<table>\n<tr><td>a</td></tr>\n</table>\n")

    def test_aborta_com_erro_acionavel(self):
        rc, _, err = run_md2(self.MD)
        self.assertNotEqual(rc, 0)
        self.assertIn("HTML cru", err)

    def test_escape_hatch_rebaixa_para_aviso(self):
        rc, _, err = run_md2(self.MD, {"DOC_HARVEST_ALLOW_RAW_HTML": "1"})
        self.assertEqual(rc, 0)
        self.assertIn("HTML cru", err)

    def test_html_dentro_de_fence_nao_dispara(self):
        md = "# T\n\n```html\n<table><tr><td>a</td></tr></table>\n```\n"
        rc, out, _ = run_md2(md)
        self.assertEqual(rc, 0)
        self.assertIn("<![CDATA[<table>", out)


class LinksReferenceStyle(unittest.TestCase):
    """Armadilha 4: 101 links reference-style saíam como [texto] literal."""

    MD = ("# T\n\n"
          "Veja [a doc][docs] e [api][] e [guia].\n\n"
          "[docs]: https://exemplo.test/docs \"Docs\"\n"
          "[api]: https://exemplo.test/api\n"
          "[guia]: https://exemplo.test/guia\n")

    def test_full_collapsed_e_shortcut_inlineados(self):
        rc, out, _ = run_md2(self.MD)
        self.assertEqual(rc, 0)
        self.assertIn('<a href="https://exemplo.test/docs">a doc</a>', out)
        self.assertIn('<a href="https://exemplo.test/api">api</a>', out)
        self.assertIn('<a href="https://exemplo.test/guia">guia</a>', out)

    def test_definicoes_nao_vazam_para_o_corpo(self):
        _, out, _ = run_md2(self.MD)
        self.assertNotIn("[docs]:", out)

    def test_colchete_sem_definicao_fica_intacto(self):
        rc, out, _ = run_md2("# T\n\nMarcado [PRIORIDADE] na revisão.\n")
        self.assertEqual(rc, 0)
        self.assertIn("[PRIORIDADE]", out)


class Ancoras(unittest.TestCase):
    """Armadilha 5: headings sem id + âncoras intra-página mortas; slug do
    MkDocs preserva underscores."""

    MD = ("# T\n\n"
          "## Config_avancada do Pool\n\n"
          "Texto. Ver [pool](#config_avancada-do-pool).\n\n"
          '<span id="dtdatasourcepoolenabled"></span>Propriedade do pool.\n')

    def test_heading_ganha_macro_anchor_com_underscore_preservado(self):
        rc, out, _ = run_md2(self.MD)
        self.assertEqual(rc, 0)
        self.assertIn('ac:name="anchor"', out)
        self.assertIn("config_avancada-do-pool", out)

    def test_link_intra_pagina_vira_ac_link(self):
        _, out, _ = run_md2(self.MD)
        self.assertIn('<ac:link ac:anchor="config_avancada-do-pool">', out)
        self.assertIn("<![CDATA[pool]]>", out)

    def test_span_id_vira_ancora_e_nao_escapa(self):
        rc, out, _ = run_md2(self.MD)
        self.assertEqual(rc, 0)
        self.assertIn("dtdatasourcepoolenabled", out)
        self.assertNotIn("&lt;span", out)


class BrEstrutural(unittest.TestCase):
    """Corpus DT v4: <br/> em célula de tabela é estrutural (Snyk) — escapar
    viraria texto visível; storage aceita <br/> como XHTML válido."""

    def test_br_preservado_em_celula(self):
        md = "# T\n\n| A | B |\n|---|---|\n| x<br/>y | z<br>w |\n"
        rc, out, _ = run_md2(md)
        self.assertEqual(rc, 0)
        self.assertIn("x<br/>y", out)
        self.assertIn("z<br/>w", out)
        self.assertNotIn("&lt;br", out)


class Linguagens(unittest.TestCase):
    """Ressalva do run DT: js/ini/mermaid/pebble caíam para 'none' em silêncio."""

    def test_js_mapeada(self):
        rc, out, _ = run_md2("# T\n\n```js\nconsole.log(1)\n```\n")
        self.assertEqual(rc, 0)
        self.assertIn('<ac:parameter ac:name="language">js</ac:parameter>', out)

    def test_desconhecida_cai_para_none_com_aviso(self):
        rc, out, err = run_md2("# T\n\n```pebble\n{{ x }}\n```\n")
        self.assertEqual(rc, 0)
        self.assertIn('<ac:parameter ac:name="language">none</ac:parameter>', out)
        self.assertIn("pebble", err)


class Regressao(unittest.TestCase):
    """Comportamento existente que as mudanças não podem quebrar."""

    def test_indentacao_interna_do_fence_preservada(self):
        md = "# T\n\n```yaml\nfoo:\n  bar: 1\n```\n"
        _, out, _ = run_md2(md)
        self.assertIn("foo:\n  bar: 1", out)

    def test_admonicao_vira_macro_info(self):
        md = "# T\n\n> **Nota**\n> Corpo da nota.\n"
        _, out, _ = run_md2(md)
        self.assertIn('ac:name="info"', out)
        self.assertIn("Corpo da nota.", out)

    def test_h1_fora_do_corpo(self):
        _, out, _ = run_md2("# Titulo Da Pagina\n\nParagrafo.\n")
        self.assertNotIn("Titulo Da Pagina", out)


if __name__ == "__main__":
    unittest.main(verbosity=2)

#!/usr/bin/env python3
"""Gate pré-publicação: acusa nos markdowns traduzidos os defeitos que em runs
reais só apareceram DEPOIS do publish (corpus Dependency-Track v5).

Uso: lint_md.py <workdir>            # linta pt/*.md (fallback md/*.md)
     lint_md.py arquivo.md [...]     # ou arquivos explícitos

Quando existe html/<slug>.html no workdir, também detecta app embutido
(Swagger UI/Redoc): página cujo conteúdo real não está no HTML — não invente
conteúdo, o material de referência é o PDF anexado.

Checagens → severidade:
  HTML cru fora de fence ................. ERRO  (md2storage aborta no publish)
  link relativo (](x.md), ](../y)) ....... ERRO  (publicaria href quebrado)
  âncora #x sem heading/span correspondente AVISO (pode ser bug do upstream)
  célula de tabela excedente com conteúdo . AVISO
  language de fence sem realce ............ AVISO
  arquivo minúsculo (<40 palavras) ........ AVISO (stub? conferir PDF)
  swagger-ui/redoc no HTML de origem ...... AVISO

Exit: 0 ok · 1 só avisos · 2 erro. Rode antes do Passo 7; erro = não publica.
"""
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import md2storage as m2  # noqa: E402 — reusa regexes/fence_mask/slugify/LANGS

RELATIVE = re.compile(r"(?<!\!)\[[^\]]*\]\((?!https?://|mailto:|#)([^)\s]+)\)")
EMBEDDED_APP = re.compile(r"swagger-ui|redoc", re.IGNORECASE)


def lint_file(path, html_path=None):
    """Retorna [(severidade, mensagem)] — severidade 1 aviso, 2 erro."""
    lines = open(path, encoding="utf-8", errors="replace").read().split("\n")
    mask = m2.fence_mask(lines)
    out = []

    for i, (line, infence) in enumerate(zip(lines, mask), 1):
        if infence:
            continue
        if m2.RAW_HTML.match(line):
            out.append((2, "linha %d: HTML cru (%s) — converter antes "
                        "(html2md.py no fragmento)" % (i, line.strip()[:40])))
        for m in RELATIVE.finditer(line):
            out.append((2, "linha %d: link relativo ](%s) — reescrever para a "
                        "página publicada irmã ou para a URL de origem"
                        % (i, m.group(1))))

    # âncoras: alvo de [x](#slug) precisa existir como heading ou span-id
    m2._SLUGS.clear()
    known = {m2.slugify(mh.group(2))
             for line, infence in zip(lines, mask) if not infence
             for mh in [re.match(r"^(#{1,6}) (.*)$", line)] if mh}
    known |= {ms.group(1) for line, infence in zip(lines, mask) if not infence
              for ms in m2.SPAN_ID.finditer(line)}
    for i, (line, infence) in enumerate(zip(lines, mask), 1):
        if infence:
            continue
        for m in m2.ANCHOR_LINK.finditer(line):
            if m.group(2) not in known:
                out.append((1, "linha %d: âncora #%s sem destino nesta página "
                            "(quebrada no upstream?)" % (i, m.group(2))))

    inside = False
    for i, line in enumerate(lines, 1):
        if line.lstrip().startswith("```"):
            lang = line.strip().lstrip("`").strip()
            if not inside and lang and lang.lower() not in m2.LANGS:
                out.append((1, "linha %d: fence '%s' sem realce no Confluence "
                            "(vira texto plano)" % (i, lang)))
            inside = not inside

    header_len = 0
    for i, (line, infence) in enumerate(zip(lines, mask), 1):
        if infence or "|" not in line:
            header_len = 0
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if re.match(r"^\s*\|?[\s:|-]+\|[\s:|-]*$", line):
            header_len = len(cells)
        elif header_len and len(cells) > header_len \
                and any(c not in ("", "-") for c in cells[header_len:]):
            out.append((1, "linha %d: tabela com %d células p/ cabeçalho de %d "
                        "e conteúdo na excedente" % (i, len(cells), header_len)))

    words = sum(len(l.split()) for l, infence in zip(lines, mask) if not infence)
    if words < 40:
        out.append((1, "%d palavras — stub? Se a origem é app embutido "
                    "(Swagger UI), o conteúdo real está SÓ no PDF; não invente"
                    % words))
    if html_path and os.path.exists(html_path) \
            and EMBEDDED_APP.search(open(html_path, encoding="utf-8",
                                         errors="replace").read()):
        out.append((1, "origem contém swagger-ui/redoc — app embutido; "
                    "conteúdo de referência é o PDF anexado"))
    return out


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("-")]
    if not args:
        print(__doc__, file=sys.stderr)
        return 2
    if len(args) == 1 and os.path.isdir(args[0]):
        wd = args[0]
        base = next((os.path.join(wd, d) for d in ("pt", "md")
                     if os.path.isdir(os.path.join(wd, d))), None)
        if not base:
            print("nenhum pt/ ou md/ em %s" % wd, file=sys.stderr)
            return 2
        files = sorted(os.path.join(base, f) for f in os.listdir(base)
                       if f.endswith(".md"))
        html_dir = os.path.join(wd, "html")
    else:
        files, html_dir = args, None

    worst = 0
    for path in files:
        slug = os.path.splitext(os.path.basename(path))[0]
        html_path = (os.path.join(html_dir, slug + ".html") if html_dir else None)
        findings = lint_file(path, html_path)
        for sev, msg in findings:
            print("%s: %s — %s" % (slug, "ERRO " if sev == 2 else "aviso", msg))
        worst = max([worst] + [s for s, _ in findings])
    print("\nlint: %d arquivo(s), veredito %s"
          % (len(files), ["ok", "só avisos", "ERRO — não publique"][worst]))
    return worst


if __name__ == "__main__":
    sys.exit(main())

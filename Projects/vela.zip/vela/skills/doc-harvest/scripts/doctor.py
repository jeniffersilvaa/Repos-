#!/usr/bin/env python3
"""doctor — audita/corrige indentação de code blocks em páginas doc-harvest.

Para cada página descendente do pageId raiz (+ a própria) com header doc-harvest:
  1. lê o body storage e a URL de origem;
  2. junta <pre> do snapshot local do run (se existir) + da página viva;
  3. para cada CDATA multilinha "flat" (nenhuma linha indentada) que case com um
     <pre> — por linhas normalizadas OU por fluxo de tokens (imune a linhas
     coladas) — mas difira no texto, restaura o texto do <pre>;
  4. só muda conteúdo DE CDATA; PUT com bump de versão quando houve mudança.
Código não é traduzido, então o match exato garante que é o mesmo bloco.

Uso: doctor.py <rootPageId> [--apply]
Requer ATLASSIAN_EMAIL/TOKEN/SITE no env.
"""
import base64
import json
import os
import re
import ssl
import sys
import tempfile
import time
import urllib.request
from bs4 import BeautifulSoup

APPLY = "--apply" in sys.argv
_pos = [a for a in sys.argv[1:] if not a.startswith("--")]
if not _pos:
    print(__doc__, file=sys.stderr)
    sys.exit(2)
ROOT = _pos[0]
UA = "Mozilla/5.0 (X11; Linux x86_64) doc-harvest/0.1 (+interno Stone)"
CACHE = os.path.join(tempfile.gettempdir(), "doc-harvest-doctor-cache")
os.makedirs(CACHE, exist_ok=True)

BASE = "https://%s" % os.environ["ATLASSIAN_SITE"]
AUTH = "Basic " + base64.b64encode(
    ("%s:%s" % (os.environ["ATLASSIAN_EMAIL"], os.environ["ATLASSIAN_TOKEN"])).encode()).decode()
CTX = ssl.create_default_context()

CDATA = re.compile(r"<!\[CDATA\[(.*?)\]\]>", re.S)
ORIGIN = re.compile(r'Tradu[^<]*?<a href="(https?://[^"]+)"')


def api(method, path, data=None):
    req = urllib.request.Request(BASE + path, method=method,
                                 data=json.dumps(data).encode() if data else None)
    req.add_header("Authorization", AUTH)
    req.add_header("Accept", "application/json")
    if data:
        req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, context=CTX, timeout=60) as r:
        return json.load(r)


def fetch_origin(url):
    key = CACHE + "/" + re.sub(r"[^a-z0-9.-]", "_", url.lower())[-80:]
    if not os.path.exists(key):
        req = urllib.request.Request(url, headers={"User-Agent": UA})
        with urllib.request.urlopen(req, context=CTX, timeout=60) as r:
            open(key, "wb").write(r.read())
        time.sleep(1)  # cortesia: evita rate-limit do site
    return open(key, encoding="utf-8", errors="replace").read()


def norm(text):
    return tuple(l.strip() for l in text.split("\n") if l.strip())


def tokens(text):
    # fluxo de tokens: imune a linhas coladas/quebradas na captura antiga
    return tuple(text.split())


def pres_by_norm(html):
    by_line, by_tok = {}, {}
    for pre in BeautifulSoup(html, "html.parser").find_all("pre"):
        t = pre.get_text().replace("\r\n", "\n").rstrip("\n")
        t = "\n".join(l.rstrip() for l in t.split("\n")).strip("\n")
        if t:
            by_line.setdefault(norm(t), t)
            by_tok.setdefault(tokens(t), t)
    return by_line, by_tok


def workdir_html(origin_url):
    """Snapshot local do run (html/ e raw/) — fonte extra além da página viva.
    Sem run ativo (pointer ausente), segue só com a página viva."""
    import subprocess
    try:
        wd = subprocess.check_output(
            ["bash", "-lc", "cat ~/.cache/doc-harvest/current 2>/dev/null"],
            text=True).strip()
    except subprocess.CalledProcessError:
        return None
    if not wd:
        return None
    base = origin_url.rstrip("/").rsplit("/", 1)[-1].removesuffix(".html")
    for d in ("html", "raw"):
        for name in (base, base.replace("---", "-")):
            p = "%s/%s/%s.html" % (wd, d, name)
            if os.path.exists(p):
                return open(p, encoding="utf-8", errors="replace").read()
    return None


def flat(c):
    body = c.strip("\n")
    lines = [l for l in body.split("\n") if l.strip()]
    return len(lines) > 1 and not any(l != l.lstrip() for l in lines)


pages = [{"id": ROOT}] + api(
    "GET", "/wiki/api/v2/pages/%s/descendants?depth=5&limit=250" % ROOT)["results"]

report = []
for p in pages:
    page = api("GET", "/wiki/api/v2/pages/%s?body-format=storage" % p["id"])
    title, ver = page["title"], page["version"]["number"]
    body = page["body"]["storage"]["value"]
    om = ORIGIN.search(body)
    if not om:
        report.append((title, "sem header de origem — pular"))
        continue
    by_line, by_tok = {}, {}
    snap = workdir_html(om.group(1))
    if snap:
        by_line, by_tok = pres_by_norm(snap)
    try:
        live_line, live_tok = pres_by_norm(fetch_origin(om.group(1)))
        for k, v in live_line.items():
            by_line.setdefault(k, v)
        for k, v in live_tok.items():
            by_tok.setdefault(k, v)
    except Exception as exc:
        if not snap:
            report.append((title, "origem inacessível (%s) — pular" % exc))
            continue

    new_body, fixed = body, 0
    for c in set(CDATA.findall(body)):
        if not flat(c):
            continue
        src = by_line.get(norm(c)) or by_tok.get(tokens(c))
        if src is None or norm(src) == () or src == c.strip("\n"):
            continue
        replacement = src.replace("]]>", "]] >")
        new_body = new_body.replace("<![CDATA[%s]]>" % c,
                                    "<![CDATA[%s]]>" % replacement)
        fixed += 1

    if not fixed:
        report.append((title, "ok (nenhum bloco flat com match)"))
        continue
    if CDATA.sub("<![CDATA[]]>", new_body) != CDATA.sub("<![CDATA[]]>", body):
        report.append((title, "diff fora de CDATA — pular (bug?)"))
        continue
    if APPLY:
        api("PUT", "/wiki/api/v2/pages/%s" % p["id"], {
            "id": p["id"], "status": "current", "title": title,
            "body": {"representation": "storage", "value": new_body},
            "version": {"number": ver + 1,
                        "message": "doc-harvest: restauração de indentação em code blocks"},
        })
        report.append((title, "ATUALIZADA v%d — %d bloco(s) reindentado(s)" % (ver + 1, fixed)))
    else:
        report.append((title, "ELEGÍVEL — %d bloco(s) flat com match na origem" % fixed))

for title, status in report:
    print("%-58s %s" % (title[:58], status))
n = sum(1 for _, s in report if "ELEGÍVEL" in s or "ATUALIZADA" in s)
print("\n%s: %d página(s) de %d na subárvore" % (
    "Atualizadas" if APPLY else "Elegíveis", n, len(pages)))

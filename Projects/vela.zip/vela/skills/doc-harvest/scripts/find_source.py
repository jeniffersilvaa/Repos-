#!/usr/bin/env python3
"""Descobre a fonte upstream (markdown/rst) de páginas de documentação.

Estratégias, em ordem:
  1. Link explícito no HTML: "edit this page" (/edit/ no GitHub/GitLab),
     "view page source" (Sphinx /_sources/), ou /blob/ com contexto de edit/source.
  2. Sonda GitHub Pages: <org>.github.io/<repo>/<path>/ → tenta
     raw.githubusercontent.com/<org>/<repo>/{main,master}/{docs/,}<path>{.md,/index.md}
     com HEAD e cacheia o layout que funcionou por site.

Uso:
    python3 find_source.py URL [URL...]
Saída (stdout): JSON {url: {"source": raw_url|null, "kind": "markdown|rst|null", "via": "..."}}
A fonte upstream é MAIS FIEL que a rota PDF (tabs, admonitions e tabelas intactos).
"""
import json
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
from html.parser import HTMLParser

UA = "Mozilla/5.0 (X11; Linux x86_64) doc-harvest/0.1 (+interno Stone)"
BRANCHES = ("main", "master")
LAYOUTS = ("docs/{p}.md", "docs/{p}/index.md", "{p}.md", "{p}/index.md")


def http(url, method="GET", timeout=20):
    req = urllib.request.Request(url, headers={"User-Agent": UA}, method=method)
    return urllib.request.urlopen(req, timeout=timeout)


def exists(url):
    try:
        with http(url, method="HEAD", timeout=10) as r:
            return 200 <= r.status < 300
    except (urllib.error.URLError, OSError):
        return False


class AnchorParser(HTMLParser):
    """Coleta âncoras com atributos + texto interno (p/ detectar 'edit this page')."""

    def __init__(self):
        super().__init__()
        self.anchors = []          # [{href, title, aria, cls, text}]
        self._open = None

    def handle_starttag(self, tag, attrs):
        if tag == "a":
            d = dict(attrs)
            self._open = {
                "href": d.get("href", ""),
                "title": (d.get("title") or "").lower(),
                "aria": (d.get("aria-label") or "").lower(),
                "cls": (d.get("class") or "").lower(),
                "text": "",
            }

    def handle_data(self, data):
        if self._open is not None:
            self._open["text"] += data.lower()

    def handle_endtag(self, tag):
        if tag == "a" and self._open is not None:
            self.anchors.append(self._open)
            self._open = None


def to_raw(href):
    """Converte URL de edit/blob do GitHub/GitLab para a raw equivalente."""
    m = re.match(r"https?://github\.com/([^/]+)/([^/]+)/(?:edit|blob)/([^/]+)/(.+)", href)
    if m:
        org, repo, branch, path = m.groups()
        return f"https://raw.githubusercontent.com/{org}/{repo}/{branch}/{path}"
    m = re.match(r"(https?://gitlab\.[^/]+/.+?)/-/(?:edit|blob)/([^/]+)/(.+)", href)
    if m:
        base, branch, path = m.groups()
        return f"{base}/-/raw/{branch}/{path}"
    return None


def kind_of(url):
    path = urllib.parse.urlsplit(url).path.lower()
    if path.endswith((".md", ".mdx")):
        return "markdown"
    if path.endswith((".rst", ".rst.txt", ".txt")):
        return "rst"
    return None


def from_html_links(page_url, html):
    parser = AnchorParser()
    parser.feed(html)
    editish = ("edit", "source", "improve this page")
    for a in parser.anchors:
        href = a["href"]
        if not href:
            continue
        absu = urllib.parse.urljoin(page_url, href)
        # Sphinx "View page source"
        if "/_sources/" in absu:
            return absu, "view-source"
        # /edit/ é sinal forte por si só; /blob/ exige contexto de edit/source
        raw = to_raw(absu)
        if raw and kind_of(raw):
            if "/edit/" in absu:
                return raw, "edit-link"
            if any(w in a["title"] + a["aria"] + a["text"] + a["cls"] for w in editish):
                return raw, "source-link"
    return None, None


# cache por (org, repo): (branch, layout) que funcionou — evita re-sondar 53 URLs
_probe_cache = {}


def probe_github_pages(page_url):
    parts = urllib.parse.urlsplit(page_url)
    m = re.match(r"([^.]+)\.github\.io$", parts.netloc)
    if not m:
        return None, None
    org = m.group(1)
    segs = [s for s in parts.path.split("/") if s]
    if not segs:
        return None, None
    repo, rest = segs[0], "/".join(segs[1:]).rstrip("/")
    if not rest:
        rest = "index"
    key = (org, repo)
    combos = ([_probe_cache[key]] if key in _probe_cache else []) + [
        (b, l) for b in BRANCHES for l in LAYOUTS
    ]
    for branch, layout in combos:
        candidate = (f"https://raw.githubusercontent.com/{org}/{repo}/{branch}/"
                     + layout.format(p=rest))
        if exists(candidate):
            _probe_cache[key] = (branch, layout)
            return candidate, "gh-pages-probe"
    return None, None


def find_source(page_url):
    try:
        with http(page_url) as r:
            html = r.read().decode(r.headers.get_content_charset() or "utf-8",
                                   errors="replace")
    except (urllib.error.URLError, OSError) as exc:
        print(f"aviso: falha ao buscar {page_url}: {exc}", file=sys.stderr)
        html = ""
    source, via = from_html_links(page_url, html) if html else (None, None)
    if not source:
        source, via = probe_github_pages(page_url)
    if source and via != "gh-pages-probe" and not exists(source):
        source, via = None, None  # link de edit quebrado (branch renomeada etc.)
    return {"source": source, "kind": kind_of(source) if source else None, "via": via}


def main() -> int:
    urls = [u for u in sys.argv[1:] if not u.startswith("-")]
    if not urls:
        print(__doc__, file=sys.stderr)
        return 2
    result = {u: find_source(u) for u in urls}
    json.dump(result, sys.stdout, indent=2)
    print()
    return 0


if __name__ == "__main__":
    sys.exit(main())

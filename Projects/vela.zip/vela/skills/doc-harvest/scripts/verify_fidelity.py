#!/usr/bin/env python3
"""Valida fidelidade do markdown gerado contra o HTML de origem (pós-recorte).

Compara contagens de headings, links, blocos <pre>/fences e linhas de tabela.
A motivação: todas as perdas graves observadas em runs reais foram SILENCIOSAS
(sub-listas, links de tabelas aninhadas, conteúdo de tabs) — contagem pega o
que o olho não vê.

Uso: verify_fidelity.py <html> <md> [--json]
Exit: 0 ok · 1 warn (alguma métrica < 80% com base ≥ 5) · 2 fail (< 50%).
"""
import json
import re
import sys
from bs4 import BeautifulSoup

WARN, FAIL, MIN_BASE = 0.8, 0.5, 5


def html_counts(path):
    soup = BeautifulSoup(open(path, encoding="utf-8", errors="replace"), "html.parser")
    return {
        "headings": len(soup.find_all(re.compile(r"^h[1-6]$"))),
        "links": len([a for a in soup.find_all("a", href=True)
                      if not a["href"].startswith("#")]),
        "pres": len(soup.find_all("pre")),
        "table_rows": len(soup.find_all("tr")),
    }


def md_counts(path):
    md = open(path, encoding="utf-8", errors="replace").read()
    lines = md.split("\n")
    fences = sum(1 for l in lines if l.lstrip().startswith("```")) // 2
    rows = sum(1 for l in lines
               if re.match(r"^\s*\|.*\|\s*$", l) and not re.match(r"^\s*\|[\s:|-]+\|\s*$", l))
    return {
        "headings": sum(1 for l in lines if re.match(r"^#{1,6} ", l)),
        "links": len(re.findall(r"(?<!\!)\[[^\]]*\]\([^)]+\)", md)),
        "pres": fences,
        "table_rows": rows,
    }


def main():
    argv = [a for a in sys.argv[1:] if a != "--json"]
    as_json = "--json" in sys.argv
    if len(argv) != 2:
        print(__doc__, file=sys.stderr)
        return 2
    h, m = html_counts(argv[0]), md_counts(argv[1])
    verdict, details = 0, []
    for k in h:
        if h[k] < MIN_BASE:
            continue
        ratio = m[k] / h[k]
        details.append("%s %d/%d (%.0f%%)" % (k, m[k], h[k], ratio * 100))
        if ratio < FAIL:
            verdict = max(verdict, 2)
        elif ratio < WARN:
            verdict = max(verdict, 1)
    label = ["ok", "warn", "fail"][verdict]
    if as_json:
        print(json.dumps({"verdict": label, "html": h, "md": m}))
    else:
        print("%s: %s" % (label, "; ".join(details) or "bases pequenas, sem métricas"))
    return verdict


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""Reconstrói a tabela de download archives do IQ Server preservando hyperlinks.

O docling achata tabelas aninhadas em prosa e descarta os <a>, o que nesta página
elimina justamente o conteúdo útil (URLs de artefato e de checksum). Aqui a tabela
externa (Versão | tabela interna) vira uma seção por versão com listas de links.
"""
import sys
from bs4 import BeautifulSoup, NavigableString, Tag

INLINE_WRAP = {"strong": "**", "b": "**", "em": "*", "i": "*", "code": "`"}


def inline(node):
    """Renderiza conteúdo inline preservando links e ênfase."""
    if isinstance(node, NavigableString):
        return str(node).replace("\n", " ")
    if not isinstance(node, Tag):
        return ""
    if node.name == "a" and node.get("href"):
        txt = " ".join(node.get_text().split())
        return "[%s](%s)" % (txt, node["href"]) if txt else ""
    if node.name == "br":
        return " "
    inner = "".join(inline(c) for c in node.children)
    w = INLINE_WRAP.get(node.name)
    if w and inner.strip():
        return "%s%s%s" % (w, inner.strip(), w)
    return inner


def squeeze(s):
    return " ".join(s.split())


def render_cell(cell, out, indent=""):
    """Renderiza o conteúdo de uma célula da tabela externa."""
    for el in cell.find_all(True, recursive=False):
        if el.name == "div" and "table-responsive" in " ".join(el.get("class") or []):
            inner = el.find("table")
            if inner:
                render_inner_table(inner, out, indent)
            continue
        if el.name == "table":
            render_inner_table(el, out, indent)
            continue
        # admonitions (Note/Warning) do MadCap saem como div com classe própria
        classes = " ".join(el.get("class") or [])
        if el.name == "div" and any(k in classes for k in ("note", "admon", "warning", "caution")):
            lines = [squeeze(inline(p)) for p in el.find_all("p")]
            lines = [x for x in lines if x]
            if lines:
                out.append("%s> **Nota**" % indent)
                for x in lines:
                    out.append("%s> %s" % (indent, x))
                out.append("")
            continue
        if el.name in ("ul", "ol"):
            for li in el.find_all("li", recursive=False):
                txt = squeeze(inline(li))
                if txt:
                    out.append("%s- %s" % (indent, txt))
            out.append("")
            continue
        # wrappers sem semântica (ex.: <div class="itemizedlist"><ul>…): desce,
        # senão os <li> colam num parágrafo só
        if el.name == "div" and el.find(["ul", "ol", "table", "p"], recursive=False):
            render_cell(el, out, indent)
            continue
        if el.name in ("p", "h1", "h2", "h3", "h4", "h5", "h6", "div"):
            txt = squeeze(inline(el))
            if txt:
                out.append("%s%s" % (indent, txt))
                out.append("")


def render_inner_table(tbl, out, indent=""):
    """Tabela interna: Application | Download Links → '**app**' + bullets."""
    body = tbl.find("tbody") or tbl
    for tr in body.find_all("tr", recursive=False):
        cells = tr.find_all(["td", "th"], recursive=False)
        if not cells or all(c.name == "th" for c in cells):
            continue  # cabeçalho Application/Download Links: redundante
        app = squeeze(inline(cells[0]))
        if app:
            out.append("%s**%s**" % (indent, app))
            out.append("")
        if len(cells) > 1:
            sub = []
            render_cell(cells[1], sub, indent)
            if not sub:  # célula só com texto/links soltos
                txt = squeeze(inline(cells[1]))
                if txt:
                    sub = [indent + txt, ""]
            # parágrafos de links viram itens de lista
            for line in sub:
                stripped = line[len(indent):] if line.startswith(indent) else line
                if stripped and not stripped.startswith(("-", ">", "**")):
                    out.append("%s- %s" % (indent, stripped))
                else:
                    out.append(line)
            out.append("")


def main(path):
    soup = BeautifulSoup(open(path, encoding="utf-8"), "html.parser")
    out = []

    # prosa antes da tabela
    table = soup.find("table")
    intro = []
    for el in soup.find_all(["h1", "p"]):
        if el.find_parent("table"):
            break
        if el.name == "h1":
            intro.append("# %s" % squeeze(el.get_text()))
            intro.append("")
        else:
            txt = squeeze(inline(el))
            if txt:
                intro.append(txt)
                intro.append("")
    out.extend(intro)

    body = table.find("tbody") or table
    for tr in body.find_all("tr", recursive=False):
        cells = tr.find_all(["td", "th"], recursive=False)
        if len(cells) < 2 or all(c.name == "th" for c in cells):
            continue
        version = squeeze(cells[0].get_text())
        if not version:
            continue
        out.append("## Versão %s" % version)
        out.append("")
        render_cell(cells[1], out)
        out.append("")

    text = "\n".join(out)
    while "\n\n\n" in text:
        text = text.replace("\n\n\n", "\n\n")
    print(text)


if __name__ == "__main__":
    main(sys.argv[1])

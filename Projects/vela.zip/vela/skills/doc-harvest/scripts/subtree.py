#!/usr/bin/env python3
"""Extrai a subárvore da TOC (sidebar) abaixo de uma página de doc.

Em help centers de namespace achatado (ex.: help.sonatype.com, /en/<slug>.html)
"subpágina" não existe no path — só na hierarquia da TOC embutida na sidebar.
Também funciona em sidebars mkdocs/readthedocs (nav com <ul> aninhados).
Localiza o link da própria página na navegação e recorta o ramo abaixo dele.

Uso: subtree.py <URL-da-página | arquivo.html> [--base-url URL] [--json]
  Com URL, baixa a página; com arquivo, use --base-url para resolver os links.
Saída: árvore legível (default) ou JSON (--json) com url/title/children.
"""
import json
import sys
import urllib.parse
import urllib.request
from bs4 import BeautifulSoup

UA = "Mozilla/5.0 (X11; Linux x86_64) doc-harvest/0.1 (+interno Stone)"


def fetch(url):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=30) as r:
        return r.read().decode(r.headers.get_content_charset() or "utf-8",
                               errors="replace")


def norm_path(href, base):
    """Path absoluto do href (sem fragmento/na mesma origem), ou None."""
    absu = urllib.parse.urljoin(base, href.split("#")[0])
    p = urllib.parse.urlsplit(absu)
    if p.scheme not in ("http", "https"):
        return None
    return absu.rstrip("/")


def node_of(li, base):
    a = li.find("a", recursive=False) or li.find("a")
    if not a or not a.get("href") or a["href"].startswith("#"):
        return None
    url = norm_path(a["href"], base)
    if not url:
        return None
    return {
        "url": url,
        "slug": urllib.parse.urlsplit(url).path.rstrip("/").rsplit("/", 1)[-1]
                .removesuffix(".html") or "index",
        "title": " ".join(a.get_text().split()),
        "children": [],
    }


def child_list(li):
    """<ul> aninhado do item, aceitando wrappers (mkdocs usa li > nav > ul)."""
    return next((u for u in li.find_all("ul") if u.find_parent("li") is li), None)


def walk(ul, base, depth, maxdepth):
    out = []
    if depth > maxdepth:
        return out
    for li in ul.find_all("li", recursive=False):
        n = node_of(li, base)
        sub = child_list(li)
        if n:
            if sub:
                n["children"] = walk(sub, base, depth + 1, maxdepth)
            out.append(n)
        elif sub:  # <li> sem link (agrupador): sobe os filhos
            out.extend(walk(sub, base, depth, maxdepth))
    return out


def flatten(nodes, acc):
    for n in nodes:
        acc.append(n)
        flatten(n["children"], acc)
    return acc


def render(nodes, prefix=""):
    lines = []
    for i, n in enumerate(nodes):
        last = i == len(nodes) - 1
        lines.append("%s%s %s  [%s]" % (prefix, "└──" if last else "├──",
                                        n["title"], n["slug"]))
        if n["children"]:
            lines.extend(render(n["children"], prefix + ("    " if last else "│   ")))
    return lines


def main():
    argv = sys.argv[1:]
    as_json = "--json" in argv
    argv = [a for a in argv if a != "--json"]
    base = None
    if "--base-url" in argv:
        i = argv.index("--base-url")
        base = argv[i + 1]
        del argv[i:i + 2]
    if not argv:
        print(__doc__, file=sys.stderr)
        return 2
    target = argv[0]

    if target.startswith(("http://", "https://")):
        base = base or target
        html = fetch(target)
    else:
        if not base:
            print("erro: com arquivo local, passe --base-url para resolver links",
                  file=sys.stderr)
            return 2
        html = open(target, encoding="utf-8", errors="replace").read()

    seed_path = urllib.parse.urlsplit(base).path.rstrip("/")
    soup = BeautifulSoup(html, "html.parser")

    # acha o <a> da própria página dentro de nav/aside (evita links do corpo);
    # âncoras puras (#seção) resolveriam para a própria página — ignora.
    def match(a):
        href = a.get("href")
        if not href or href.startswith("#"):
            return False
        u = norm_path(href, base)
        return u is not None and urllib.parse.urlsplit(u).path.rstrip("/") == seed_path

    containers = soup.find_all(["aside", "nav"]) or [soup]
    candidates = [a for c in containers for a in c.find_all("a") if match(a)]
    if not candidates:
        print("semente não encontrada na navegação da página — o site pode não "
              "expor TOC no HTML; use crawl.py", file=sys.stderr)
        return 1

    # alguns temas listam a página mais de uma vez (e o item ativo pode carregar
    # só a TOC de seções, que vira zero após filtrar âncoras): prefere o primeiro
    # candidato cuja sub-lista rende filhos reais
    children = []
    for a in candidates:
        li = a.find_parent("li")
        s = child_list(li) if li else None
        if s:
            c = walk(s, base, 1, 9)
            if c:
                children = c
                break

    if as_json:
        print(json.dumps({"seed": base, "children": children}, ensure_ascii=False))
        return 0
    flat = flatten(children, [])
    print("%s → %d subpágina(s)" % (seed_path.rsplit("/", 1)[-1] or seed_path, len(flat)))
    for line in render(children):
        print(line)
    return 0


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""Configuração por usuário do doc-harvest (destinos de publicação e Jira).

Arquivo: ~/.config/doc-harvest/config.json (override: env DOC_HARVEST_CONFIG).

Chaves:
  confluence_space    key do espaço Confluence (ex.: FOUND)
  draft_parent_id     pageId da pasta de drafts (rascunhos do time)
  official_parent_id  pageId da pasta de publicação oficial
  jira_project        project key do Jira para os cards de revisão (ex.: ATL)

Uso:
  config.py get               # imprime o JSON completo ({} se não configurado)
  config.py get <chave>       # imprime o valor (exit 1 se ausente)
  config.py set <chave> <valor>
"""
import json
import os
import sys

KEYS = ("confluence_space", "draft_parent_id", "official_parent_id", "jira_project")
PATH = os.environ.get("DOC_HARVEST_CONFIG") or os.path.expanduser(
    "~/.config/doc-harvest/config.json")


def load():
    try:
        return json.load(open(PATH, encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def main() -> int:
    args = sys.argv[1:]
    if not args or args[0] not in ("get", "set"):
        print(__doc__, file=sys.stderr)
        return 2
    cfg = load()
    if args[0] == "get":
        if len(args) == 1:
            print(json.dumps(cfg, ensure_ascii=False, indent=2))
            return 0
        val = cfg.get(args[1], "")
        print(val)
        return 0 if val else 1
    # set
    if len(args) != 3 or args[1] not in KEYS:
        print("chaves válidas: %s" % ", ".join(KEYS), file=sys.stderr)
        return 2
    cfg[args[1]] = args[2]
    os.makedirs(os.path.dirname(PATH), exist_ok=True)
    json.dump(cfg, open(PATH, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    print("%s=%s gravado em %s" % (args[1], args[2], PATH))
    return 0


if __name__ == "__main__":
    sys.exit(main())

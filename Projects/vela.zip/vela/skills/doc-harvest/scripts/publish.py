#!/usr/bin/env python3
"""Publica em lote as páginas traduzidas no Confluence, a partir de um spec JSON.

Caminho RÁPIDO quando há credenciais REST (ATLASSIAN_EMAIL/TOKEN/SITE no env).
Sem credenciais, use as tools MCP atlassian (ver SKILL.md, Passo 7) — este
script é a otimização de lote, não o único caminho.

Uso: publish.py <spec.json> [--dry-run]

spec.json:
{
  "workdir": "/caminho/do/run",          // default: ~/.cache/doc-harvest/current
  "space_key": "FOUND",
  "date": "2026-07-22",
  "jira_project": "ATL",                 // opcional: cria card de revisão
  "tree": [                              // ordem de dependência (pai antes)
    {"slug": "pagina-a", "title": "Título A", "parent": "9596011410"},
    {"slug": "pagina-b", "title": "Título B", "parent": "pagina-a"}
  ]
}

Comportamento: idempotente por título (atualiza se existir); anexa o PDF do
slug e as imagens referenciadas; injeta "Hash da fonte: <12hex>" no header
(baseline do refresh.py); grava publicadas.json no workdir; com jira_project,
cria UM card de revisão listando as páginas publicadas.

GUARDRAIL DE PARENT: a busca por título é no espaço INTEIRO. Título genérico
("Projetos", "Cache"...) que já exista em outra árvore do espaço seria
sobrescrito em silêncio. Por isso o update só acontece se a página encontrada
já vive sob o parent planejado; caso contrário ABORTA aquela página com
instrução de prefixar o corpus. Mover de propósito (ex.: promover de drafts
para a árvore oficial) exige "allow_move": true na entrada da tree. O
--dry-run roda a mesma checagem e reporta COLISÃO — use-o como pré-check
antes de todo publish.

ARTEFATOS DURÁVEIS: ao final, anexa à PRIMEIRA página raiz da tree o
sources.json (mapa slug→fonte upstream), o próprio spec e, se existir,
$WORKDIR/notas-do-corpus.md — é o que um re-harvest futuro precisa ler para
não repetir as armadilhas do corpus (o workdir é efêmero).
"""
import atexit
import base64
import hashlib
import json
import mimetypes
import os
import re
import ssl
import subprocess
import sys
import urllib.error
import urllib.parse
import urllib.request

from bs4 import BeautifulSoup

DRY = "--dry-run" in sys.argv
SPEC_PATH = [a for a in sys.argv[1:] if not a.startswith("--")][0]
SPEC = json.load(open(SPEC_PATH))
WORKDIR = SPEC.get("workdir") or subprocess.check_output(
    ["bash", "-lc", "cat ~/.cache/doc-harvest/current"], text=True).strip()
SKILL = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATE = SPEC["date"]

# defaults por usuário (scripts/config.py): espaço e projeto Jira
_CFG_PATH = os.environ.get("DOC_HARVEST_CONFIG") or os.path.expanduser(
    "~/.config/doc-harvest/config.json")
try:
    _CFG = json.load(open(_CFG_PATH, encoding="utf-8"))
except (OSError, ValueError):
    _CFG = {}
SPACE_KEY = SPEC.get("space_key") or _CFG.get("confluence_space")
if not SPACE_KEY:
    sys.exit("space_key ausente no spec e confluence_space não configurado "
             "(scripts/config.py set confluence_space <KEY>)")
JIRA_PROJECT = SPEC.get("jira_project") or _CFG.get("jira_project")

EMAIL = os.environ["ATLASSIAN_EMAIL"]
TOKEN = os.environ["ATLASSIAN_TOKEN"]
BASE = "https://%s" % os.environ["ATLASSIAN_SITE"]
AUTH = "Basic " + base64.b64encode(("%s:%s" % (EMAIL, TOKEN)).encode()).decode()
CTX = ssl.create_default_context()


def emit(doc, stage, status, detail=""):
    subprocess.run([sys.executable, SKILL + "/scripts/emit.py", WORKDIR, doc,
                    stage, status, detail], check=False)


def api(method, path, data=None):
    body = json.dumps(data).encode() if data is not None else None
    h = {"Authorization": AUTH, "Accept": "application/json"}
    if body:
        h["Content-Type"] = "application/json"
    req = urllib.request.Request(BASE + path, data=body, headers=h, method=method)
    with urllib.request.urlopen(req, context=CTX, timeout=120) as r:
        return json.loads(r.read().decode() or "{}")


def multipart(path, filename, filebytes, comment):
    boundary = "----docharvest7f3a9"
    ctype = mimetypes.guess_type(filename)[0] or "application/octet-stream"
    parts = [
        ('--%s\r\nContent-Disposition: form-data; name="comment"\r\n\r\n%s\r\n'
         % (boundary, comment)).encode(),
        ('--%s\r\nContent-Disposition: form-data; name="file"; filename="%s"\r\n'
         'Content-Type: %s\r\n\r\n' % (boundary, filename, ctype)).encode(),
        filebytes,
        ("\r\n--%s--\r\n" % boundary).encode(),
    ]
    req = urllib.request.Request(
        BASE + path, data=b"".join(parts), method="PUT",
        headers={"Authorization": AUTH, "Accept": "application/json",
                 "X-Atlassian-Token": "nocheck",
                 "Content-Type": "multipart/form-data; boundary=%s" % boundary})
    with urllib.request.urlopen(req, context=CTX, timeout=300) as r:
        return json.loads(r.read().decode() or "{}")


def find_page(space_id, title):
    q = urllib.parse.urlencode({"spaceId": space_id, "title": title, "limit": 1})
    return (api("GET", "/wiki/api/v2/pages?" + q).get("results") or [None])[0]


def source_hash(html_path):
    """Hash do texto normalizado do <article>/<main> da captura de origem.
    MANTER IDÊNTICO ao source_hash() de refresh.py."""
    soup = BeautifulSoup(open(html_path, encoding="utf-8", errors="replace"),
                         "html.parser")
    root = soup.find("article") or soup.find("main") or soup
    text = " ".join(root.get_text().split())
    return hashlib.sha256(text.encode()).hexdigest()[:12]


def with_hash(body, slug):
    html_path = "%s/html/%s.html" % (WORKDIR, slug)
    if not os.path.exists(html_path):
        return body
    h = source_hash(html_path)
    return body.replace("Revisão humana pendente.",
                        "Revisão humana pendente. Hash da fonte: %s." % h, 1)


def review_card(project, pages):
    bullets = [{"type": "listItem", "content": [{"type": "paragraph", "content": [
        {"type": "text", "text": t + " — "},
        {"type": "text", "text": u, "marks": [{"type": "link", "attrs": {"href": u}}]},
    ]}]} for t, u, _ in pages]
    payload = {"fields": {
        "project": {"key": project},
        "summary": "Revisar traduções doc-harvest — %s (%d páginas)" % (DATE, len(pages)),
        "issuetype": {"name": "Task"},
        "description": {"type": "doc", "version": 1, "content": [
            {"type": "paragraph", "content": [{"type": "text", "text":
                "Páginas publicadas com 'Revisão humana pendente'. Revisar tradução "
                "e fidelidade técnica; remover a marcação do header ao concluir."}]},
            {"type": "bulletList", "content": bullets},
        ]},
    }}
    if DRY:
        print("[dry-run] card Jira em %s: %s" % (project, payload["fields"]["summary"]))
        return None
    key = api("POST", "/rest/api/3/issue", payload)["key"]
    print("card de revisão: %s/browse/%s" % (BASE, key))
    return key


def main():
    # lock: duas execuções simultâneas do mesmo spec fariam find_page+POST em
    # corrida e criariam páginas duplicadas por título
    lock = os.path.join(WORKDIR, "publish.lock")
    if not DRY:
        try:
            os.close(os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY))
        except FileExistsError:
            sys.exit("publish já em execução para este workdir (%s). Se o run "
                     "anterior morreu, remova o lock e re-execute." % lock)
        atexit.register(lambda: os.path.exists(lock) and os.unlink(lock))

    space_id = str(api("GET", "/wiki/api/v2/spaces?keys=%s" % SPACE_KEY)
                   ["results"][0]["id"])
    ids, report, failed = {}, [], set()
    for entry in SPEC["tree"]:
        slug, title = entry["slug"], entry["title"]
        # pai falhou (ou é referência de slug ainda não publicada): pular a
        # subárvore explicitamente em vez de mandar o slug literal como parentId
        parent_ref = entry["parent"]
        if parent_ref in failed or (not parent_ref.isdigit()
                                    and parent_ref not in ids):
            print("pulada    %-48s (pai indisponível: %s)" % (title[:48], parent_ref))
            emit(slug, "publish", "error", "pulada: pai %s indisponível" % parent_ref)
            failed.add(slug)
            continue
        parent_id = ids.get(parent_ref, parent_ref)
        body = with_hash(open("%s/xhtml/%s.xhtml" % (WORKDIR, slug),
                              encoding="utf-8").read(), slug)
        if DRY:
            existing = find_page(space_id, title)
            note = ""
            if existing:
                pid = str(existing["id"])
                cur = str(api("GET", "/wiki/api/v2/pages/%s" % pid)
                          .get("parentId") or "")
                if cur == str(parent_id) or entry.get("allow_move"):
                    note = "→ atualizaria %s" % pid
                else:
                    note = ("⚠ COLISÃO: título já existe (id %s) sob parent %s — "
                            "o publish abortaria esta página; prefixe o corpus "
                            'no título ou use "allow_move": true' % (pid, cur))
                ids[slug] = pid
            else:
                ids[slug] = "DRY-%s" % slug
            print("[dry-run] %-45s parent=%s hash=%s %s" % (
                title, parent_id,
                "sim" if "Hash da fonte" in body else "não", note))
            continue
        emit(slug, "publish", "start", title)
        try:
            existing = find_page(space_id, title)
            if existing:
                pid = str(existing["id"])
                page = api("GET", "/wiki/api/v2/pages/%s" % pid)
                cur = str(page.get("parentId") or "")
                # busca por título é espaço-inteiro: sem esta checagem, título
                # genérico sobrescreveria página de OUTRA árvore em silêncio
                if cur != str(parent_id) and not entry.get("allow_move"):
                    print('ABORTADA  %-48s colide com página %s sob parent %s '
                          '(fora da árvore do run) — prefixe o corpus ou use '
                          '"allow_move": true para mover de propósito'
                          % (title[:48], pid, cur))
                    emit(slug, "publish", "error",
                         "colisão de título: página %s sob parent %s" % (pid, cur))
                    failed.add(slug)
                    continue
                ver = page["version"]["number"]
                api("PUT", "/wiki/api/v2/pages/%s" % pid, {
                    "id": pid, "status": "current", "title": title,
                    "spaceId": space_id, "parentId": parent_id,
                    "body": {"representation": "storage", "value": body},
                    "version": {"number": ver + 1, "message": "doc-harvest %s" % DATE}})
                action = "atualizada"
            else:
                pid = str(api("POST", "/wiki/api/v2/pages", {
                    "spaceId": space_id, "status": "current", "title": title,
                    "parentId": parent_id,
                    "body": {"representation": "storage", "value": body}})["id"])
                action = "criada"
            ids[slug] = pid

            pdf = "%s/pdf/%s.pdf" % (WORKDIR, slug)
            if os.path.exists(pdf):
                multipart("/wiki/rest/api/content/%s/child/attachment" % pid,
                          "%s.pdf" % slug, open(pdf, "rb").read(),
                          "Original capturado em %s" % DATE)
            for name in sorted(set(re.findall(r'ri:filename="([^"]+)"', body))):
                img = "%s/img/%s" % (WORKDIR, name)
                if os.path.exists(img):
                    multipart("/wiki/rest/api/content/%s/child/attachment" % pid,
                              name, open(img, "rb").read(), "Diagrama original %s" % DATE)

            url = "%s/wiki/spaces/%s/pages/%s" % (BASE, SPACE_KEY, pid)
            print("%-10s %-48s %s" % (action, title[:48], url))
            report.append((title, url, action))
            emit(slug, "publish", "ok", "%s: %s" % (action, url))
        except urllib.error.HTTPError as e:
            detail = e.read().decode()[:300]
            print("ERRO %s: %s %s" % (slug, e.code, detail))
            emit(slug, "publish", "error", "%s %s" % (e.code, detail[:120]))
            failed.add(slug)  # descendentes serão pulados com aviso explícito

    if not DRY:
        json.dump([{"titulo": t, "url": u, "acao": a} for t, u, a in report],
                  open(WORKDIR + "/publicadas.json", "w"), ensure_ascii=False, indent=2)
        print("\ntotal publicadas: %d/%d" % (len(report), len(SPEC["tree"])))
        # artefatos duráveis na página raiz: o workdir é efêmero — sem isso,
        # re-harvest futuro redescobre fontes do zero e repete as armadilhas
        root = next((e["slug"] for e in SPEC["tree"]
                     if e["parent"].isdigit() and e["slug"] in ids), None)
        if root:
            for path, name, desc in (
                    (WORKDIR + "/sources.json", "sources.json",
                     "mapa slug→fonte upstream"),
                    (SPEC_PATH, "spec.json", "spec deste publish"),
                    (WORKDIR + "/notas-do-corpus.md", "notas-do-corpus.md",
                     "armadilhas do corpus — LER antes de re-harvest")):
                if os.path.exists(path):
                    try:
                        multipart("/wiki/rest/api/content/%s/child/attachment"
                                  % ids[root], name, open(path, "rb").read(),
                                  "doc-harvest %s — %s" % (DATE, desc))
                        print("anexado à raiz %s: %s" % (ids[root], name))
                    except urllib.error.HTTPError as e:
                        print("AVISO: anexo %s falhou (%s)" % (name, e.code))
    if JIRA_PROJECT and (report or DRY):
        review_card(JIRA_PROJECT,
                    report or [(e["title"], "(dry-run)", "-") for e in SPEC["tree"]])


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Descobre links de documentação relacionados a uma página semente.

Baixa a(s) URL(s) semente, extrai <a href> e mantém apenas links do mesmo host
que passem no filtro de escopo — na ordem de preferência:
  1. taxonomia: em sites CCMS (MadCap Flare/RoboHelp, ex. help.sonatype.com) os
     <a> da navegação carregam classe "taxonomy-products-<produto>"; quando a
     semente tem essa marcação, filtra por MESMO produto (o prefixo de path não
     discrimina nada em sites de namespace achatado /en/<slug>.html).
  2. prefixo de path: mesmo diretório da semente (útil em mkdocs/readthedocs).
Nunca baixa as páginas descobertas — apenas lista, para o usuário confirmar.

Uso:
    python3 crawl.py URL [URL...] [--max 20] [--prefix /caminho/custom/]
Saída: JSON array de URLs (sementes primeiro, depois descobertas), em stdout.
Avisos de escopo (prefixo raso, taxonomia detectada) vão para stderr.
"""
import argparse
import json
import re
import sys
import urllib.parse
import urllib.request
from html.parser import HTMLParser

UA = "Mozilla/5.0 (X11; Linux x86_64) doc-harvest/0.1 (+interno Stone)"
TAXONOMY_RE = re.compile(r"taxonomy-products-[a-z0-9-]+")


class LinkParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.hrefs = []  # [(href, class_attr)]

    def handle_starttag(self, tag, attrs):
        if tag == "a":
            d = dict(attrs)
            href = d.get("href")
            if href:
                self.hrefs.append((href, d.get("class", "")))


def seed_taxonomy(html: str, seed_path: str):
    """Acha a(s) classe(s) taxonomy-products-* do próprio tópico da semente,
    via data-permalink="<basename>" no HTML (padrão MadCap Flare). Retorna
    None se o site não usa esse padrão (maioria dos sites não usa)."""
    basename = seed_path.rsplit("/", 1)[-1]
    if not basename:
        return None
    m = re.search(
        r'class="([^"]*)"[^>]*data-permalink="' + re.escape(basename) + r'"',
        html,
    )
    if not m:
        return None
    found = TAXONOMY_RE.findall(m.group(1))
    return set(found) or None


def fetch(url: str) -> str:
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=30) as resp:
        ctype = resp.headers.get("Content-Type", "")
        if "html" not in ctype:
            return ""
        charset = resp.headers.get_content_charset() or "utf-8"
        return resp.read().decode(charset, errors="replace")


def normalize(url: str) -> str:
    # remove fragmento e barra final duplicada; mantém query (docs versionadas usam)
    parts = urllib.parse.urlsplit(url)
    path = parts.path or "/"
    return urllib.parse.urlunsplit((parts.scheme, parts.netloc, path, parts.query, ""))


def prefix_of(url: str) -> str:
    path = urllib.parse.urlsplit(url).path
    return path if path.endswith("/") else path.rsplit("/", 1)[0] + "/"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("seeds", nargs="+", help="URLs semente")
    ap.add_argument("--max", type=int, default=20, dest="max_urls",
                    help="máximo de URLs no total (default 20)")
    ap.add_argument("--prefix", default=None,
                    help="prefixo de path a aceitar (default: diretório de cada semente)")
    args = ap.parse_args()

    seen = []

    def add(url):
        url = normalize(url)
        if url not in seen and len(seen) < args.max_urls:
            seen.append(url)

    for seed in args.seeds:
        add(seed)

    for seed in args.seeds:
        seed_parts = urllib.parse.urlsplit(seed)
        prefix = args.prefix or prefix_of(seed)
        try:
            html = fetch(seed)
        except Exception as exc:  # rede/404: reporta e segue
            print(f"aviso: falha ao buscar {seed}: {exc}", file=sys.stderr)
            continue
        taxonomy = seed_taxonomy(html, seed_parts.path)
        if taxonomy:
            print(
                f"info: {seed} marca taxonomy {sorted(taxonomy)} — "
                "filtrando descobertas pela mesma tag em vez do prefixo de path",
                file=sys.stderr,
            )
        else:
            depth = len([s for s in prefix.strip("/").split("/") if s])
            if depth <= 1:
                print(
                    f"aviso: prefixo raso '{prefix}' para {seed} — site pode ter "
                    "path achatado (sem diretório por produto); a lista descoberta "
                    "pode misturar páginas de OUTROS produtos/tópicos. Confira cada "
                    "URL antes de baixar, ou passe --prefix mais específico.",
                    file=sys.stderr,
                )
        parser = LinkParser()
        parser.feed(html)
        for href, cls in parser.hrefs:
            absu = urllib.parse.urljoin(seed, href)
            parts = urllib.parse.urlsplit(absu)
            if parts.scheme not in ("http", "https"):
                continue
            if parts.netloc != seed_parts.netloc:
                continue
            if taxonomy:
                link_tax = set(TAXONOMY_RE.findall(cls))
                if not (link_tax & taxonomy):
                    continue
            elif not parts.path.startswith(prefix):
                continue
            add(absu)

    json.dump(seen, sys.stdout, indent=2)
    print()
    return 0


if __name__ == "__main__":
    sys.exit(main())

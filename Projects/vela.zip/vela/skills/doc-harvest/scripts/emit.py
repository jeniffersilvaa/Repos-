#!/usr/bin/env python3
"""Emite um evento JSONL do pipeline doc-harvest (consumido pelo ui_server).

Uso: emit.py [--init] <WORKDIR> <doc> <stage> <status> [detail]
  stage:  pdf | markdown | translate | publish | run
  status: start | ok | error | info
  doc:    slug do documento, ou "-" para eventos do run inteiro

--init: SOMENTE no primeiro evento do run (Passo 1) — cria o events.jsonl.
Sem --init, exige events.jsonl existente e falha alto caso contrário: isso
protege contra o erro clássico de recalcular o WORKDIR num shell novo (o Bash
tool não persiste variáveis) e emitir eventos num diretório que o frontend
não está lendo. Recupere o run ativo com: cat ~/.cache/doc-harvest/current
"""
import datetime
import json
import os
import sys


def main() -> int:
    args = [a for a in sys.argv[1:] if a != "--init"]
    init = "--init" in sys.argv[1:]
    if len(args) < 4:
        print(__doc__, file=sys.stderr)
        return 2
    workdir, doc, stage, status = args[:4]
    detail = args[4] if len(args) > 4 else ""
    events = os.path.join(workdir, "events.jsonl")

    if init:
        os.makedirs(workdir, exist_ok=True)
    elif not os.path.exists(events):
        print(
            f"erro: {events} não existe — WORKDIR recalculado num shell novo?\n"
            "Recupere o run ativo com:  WORKDIR=$(cat ~/.cache/doc-harvest/current)\n"
            "(--init só é válido no primeiro evento, no Passo 1)",
            file=sys.stderr,
        )
        return 3

    event = {
        "ts": datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
        "doc": doc,
        "stage": stage,
        "status": status,
        "detail": detail,
    }
    with open(events, "a", encoding="utf-8") as f:
        f.write(json.dumps(event, ensure_ascii=False) + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())

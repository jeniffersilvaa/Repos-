#!/usr/bin/env python3
"""HTML de página de doc → markdown, preservando estrutura que o docling perde.

Motivos (observados em runs reais): o docling achata `ol.procedure > li.step`
(colando os <pre> na prosa do item) e chega a DESCARTAR sub-listas aninhadas
dentro de um step sem qualquer sinal; perde indentação de <pre> com highlight
por <span>; e derruba <a> em tabelas aninhadas. Este conversor extrai <pre>
verbatim (indentação intacta em qualquer marcação) e desce recursivamente em
listas/células.

Uso: html2md.py <html> [--base-url URL] > out.md
  --base-url: URL da página original, para resolver links relativos.
"""
import re
import sys
import urllib.parse
from bs4 import BeautifulSoup, NavigableString, Tag

BASE_URL = None

SKIP_CLASSES = ("breadcrumb", "footer-content", "glossary-definitions",
                "info-elements", "section-nav", "feedback")
INLINE_WRAP = {"strong": "**", "b": "**", "em": "*", "i": "*"}
ADMON_LABEL = {"note": "Nota", "warning": "Aviso", "caution": "Atenção",
               "important": "Importante", "tip": "Dica"}


def classes(el):
    return " ".join(el.get("class") or [])


def skip(el):
    c = classes(el)
    return any(k in c for k in SKIP_CLASSES)


def inline(node):
    if isinstance(node, NavigableString):
        return str(node)
    if not isinstance(node, Tag):
        return ""
    if node.name == "a" and node.get("href"):
        txt = " ".join(node.get_text().split())
        href = node["href"]
        if BASE_URL and not href.startswith(("mailto:", "#")):
            href = urllib.parse.urljoin(BASE_URL, href)
        return "[%s](%s)" % (txt, href) if txt else ""
    if node.name in ("code", "tt", "kbd"):
        txt = " ".join(node.get_text().split())
        return "`%s`" % txt if txt else ""
    if node.name == "br":
        return " "
    if node.name == "img":
        alt = node.get("alt") or "imagem"
        return "![%s](%s)" % (alt, node.get("src", ""))
    inner = "".join(inline(c) for c in node.children)
    w = "**" if "bold" in classes(node) else INLINE_WRAP.get(node.name)
    if w and inner.strip():
        s = inner.strip()
        # <strong><span class="bold"> aninhado é comum no CCMS; não duplicar o marcador
        if s.startswith(w) and s.endswith(w):
            return s
        return "%s%s%s" % (w, s, w)
    return inner


def squeeze(s):
    return " ".join(s.split())


def code_lang(text):
    t = text.strip()
    if re.match(r"^\s*(export |sudo |chown |unzip |cd |mkdir |mv |curl |\./)", t):
        return "bash"
    if re.match(r"^\s*(GET|POST|PUT|DELETE) ", t):
        return "http"
    if re.match(r"^\[Unit\]", t):
        return "ini"
    if re.search(r"^\s*\w[\w.-]*:\s", t, re.M) and not t.startswith(("INFO", "DEBUG", "ERROR")):
        return "yaml"
    return ""


def render(el, out, indent=""):
    """Renderiza filhos de bloco de `el` acrescentando linhas em `out`."""
    for child in el.find_all(True, recursive=False):
        if skip(child):
            continue
        name, cls = child.name, classes(child)

        if re.match(r"^h[1-6]$", name):
            lvl = int(name[1])
            txt = squeeze(inline(child))
            if txt:
                out.append("%s %s" % ("#" * lvl, txt))
                out.append("")
            continue

        if name == "pre":
            body = child.get_text()
            body = body.replace("\r\n", "\n").rstrip()
            body = "\n".join(l.rstrip() for l in body.split("\n"))
            out.append("%s```%s" % (indent, code_lang(body)))
            out.extend(indent + l for l in body.split("\n"))
            out.append("%s```" % indent)
            out.append("")
            continue

        if name == "table":
            render_table(child, out, indent)
            continue

        if "note" in cls or "warning" in cls or "admonition" in cls:
            render_admonition(child, out, indent)
            continue

        if name in ("ul", "ol"):
            render_list(child, out, indent, ordered=(name == "ol"))
            continue

        if name == "p":
            txt = squeeze(inline(child))
            if txt:
                out.append(indent + txt)
                out.append("")
            continue

        # wrappers estruturais (section, div.titlepage, div.procedure, article…)
        if name in ("section", "div", "article", "header", "main"):
            render(child, out, indent)
            continue

        txt = squeeze(inline(child))
        if txt:
            out.append(indent + txt)
            out.append("")


def render_admonition(el, out, indent):
    label = "Nota"
    lbl_el = el.find(class_="admonition-label")
    if lbl_el:
        raw = squeeze(lbl_el.get_text()).strip().lower().rstrip(":")
        label = ADMON_LABEL.get(raw, raw.capitalize() or "Nota")
        lbl_el.extract()
    else:
        for k, v in ADMON_LABEL.items():
            if k in classes(el):
                label = v
                break
    body = []
    render(el, body, "")
    body = [b for b in body if b.strip()]
    out.append("%s> **%s**" % (indent, label))
    for line in body:
        out.append("%s> %s" % (indent, line))
    out.append("")


def render_list(ul, out, indent, ordered):
    n = 0
    for li in ul.find_all("li", recursive=False):
        if skip(li):
            continue
        n += 1
        marker = ("%d." % n) if ordered else "-"
        body = []
        render(li, body, "")
        if not body:
            txt = squeeze(inline(li))
            body = [txt] if txt else []
        while body and not body[0].strip():
            body.pop(0)
        while body and not body[-1].strip():
            body.pop()
        if not body:
            continue
        pad = " " * (len(marker) + 1)
        out.append("%s%s %s" % (indent, marker, body[0]))
        for line in body[1:]:
            out.append((indent + pad + line) if line.strip() else "")
        out.append("")


def render_table(tbl, out, indent):
    def cell_text(td):
        buf = []
        render(td, buf, "")
        buf = [b for b in buf if b.strip()]
        if not buf:
            buf = [squeeze(inline(td))]
        # tabela markdown não comporta blocos: junta e neutraliza pipes
        return " ".join(x.strip().lstrip("- ").replace("|", "\\|") for x in buf).strip()

    rows = tbl.find_all("tr")
    if not rows:
        return
    grid = []
    for tr in rows:
        cells = tr.find_all(["td", "th"])
        if cells:
            grid.append([cell_text(c) for c in cells])
    if not grid:
        return
    width = max(len(r) for r in grid)
    grid = [r + [""] * (width - len(r)) for r in grid]
    head = grid[0]
    out.append(indent + "| " + " | ".join(head) + " |")
    out.append(indent + "|" + "---|" * width)
    for r in grid[1:]:
        out.append(indent + "| " + " | ".join(r) + " |")
    out.append("")


def main(path):
    soup = BeautifulSoup(open(path, encoding="utf-8"), "html.parser")
    root = soup.find("article") or soup.find("body") or soup
    out = []
    render(root, out, "")
    text = "\n".join(out)
    text = re.sub(r"\n{3,}", "\n\n", text).strip() + "\n"
    sys.stdout.write(text)


if __name__ == "__main__":
    argv = sys.argv[1:]
    if "--base-url" in argv:
        i = argv.index("--base-url")
        BASE_URL = argv[i + 1]
        del argv[i:i + 2]
    main(argv[0])

#!/usr/bin/env python3
"""Converte o markdown traduzido para Confluence storage format (XHTML).

Uso: md2storage.py <pt.md> <url-origem> <data> > body.xhtml

Cobre o que o doc-harvest gera: headings, code fences, tabelas pipe, listas
aninhadas (ul/ol) com blocos dentro do item, blockquotes → macro info/note/warning,
e inline (link, strong, em, code). O H1 vira o título da página, não entra no corpo.
"""
import html
import os
import re
import sys

LANGS = {"bash": "bash", "sh": "bash", "shell": "bash", "console": "bash",
         "docker": "bash", "dockerfile": "bash", "yaml": "yaml", "yml": "yaml",
         "json": "json", "xml": "xml", "html": "xml", "sql": "sql",
         "python": "python", "java": "java", "js": "js", "javascript": "js",
         "ts": "js", "typescript": "js", "go": "go", "golang": "go",
         "csharp": "csharp", "cs": "csharp", "kotlin": "kotlin",
         "groovy": "groovy", "ruby": "ruby", "php": "php", "perl": "perl",
         "powershell": "powershell", "ps1": "powershell", "diff": "diff",
         "css": "css", "properties": "none", "text": "none", "": "none"}

ADMON = {"nota": "info", "note": "info", "aviso": "warning", "warning": "warning",
         "atenção": "note", "importante": "note", "dica": "tip"}

CODE_SPAN = re.compile(r"`([^`]+)`")
IMAGE = re.compile(r"!\[([^\]]*)\]\(([^)\s]+)\)")
ANCHOR_LINK = re.compile(r"\[([^\]]*)\]\(#([^)\s]+)\)")
LINK = re.compile(r"\[([^\]]*)\]\(([^)\s]+)\)")
BOLD = re.compile(r"\*\*([^*]+)\*\*")
ITAL = re.compile(r"(?<!\*)\*([^*]+)\*(?!\*)")
ANCHOR_MARK = re.compile(r"\{anchor:([\w-]+)\}")
SPAN_ID = re.compile(r'<span id="([\w.-]+)"[^>]*>(.*?)</span>')
REF_DEF = re.compile(r'^\s{0,3}\[([^\]]+)\]:\s*(\S+)(?:\s+["\'(].*)?$')
REF_FULL = re.compile(r"\[([^\]]+)\]\[([^\]]*)\]")
REF_SHORT = re.compile(r"(?<!\!)\[([^\]]+)\](?!\[|\()")
# tags block-level que o html.escape do inline() transformaria em texto visível
RAW_HTML = re.compile(r"^\s*</?(table|thead|tbody|tr|td|th|div|dl|dt|dd|details"
                      r"|summary|iframe|ul|ol|li|p|h[1-6])\b", re.IGNORECASE)


def warn(msg):
    print("md2storage: " + msg, file=sys.stderr)


def anchor_macro(slug):
    return ('<ac:structured-macro ac:name="anchor" ac:schema-version="1">'
            '<ac:parameter ac:name="">%s</ac:parameter></ac:structured-macro>' % slug)


_SLUGS = {}


def slugify(text):
    """Slug de heading no padrão MkDocs/python-markdown: minúsculas, espaço
    vira hífen e UNDERSCORE É PRESERVADO (não vira hífen — âncoras do corpus
    DT quebravam exatamente nisso)."""
    text = CODE_SPAN.sub(r"\1", text)
    text = LINK.sub(r"\1", text)
    text = text.replace("**", "").replace("*", "")
    slug = re.sub(r"[\s]+", "-", re.sub(r"[^\w\s-]", "", text).strip().lower())
    if slug in _SLUGS:
        _SLUGS[slug] += 1
        return "%s_%d" % (slug, _SLUGS[slug])
    _SLUGS[slug] = 0
    return slug


def fence_mask(lines):
    """True nas linhas dentro de code fences (imunes a pré-processamento)."""
    mask, inside = [], False
    for line in lines:
        if line.lstrip().startswith("```"):
            mask.append(True)
            inside = not inside
        else:
            mask.append(inside)
    return mask


def preprocess(lines):
    """span-id → marcador de âncora; gate de HTML cru; ref-links → inline."""
    mask = fence_mask(lines)
    lines = [SPAN_ID.sub(lambda m: "{anchor:%s}%s" % (m.group(1), m.group(2)), l)
             if not infence else l for l, infence in zip(lines, mask)]

    raw = [i + 1 for i, (l, infence) in enumerate(zip(lines, mask))
           if not infence and RAW_HTML.match(l)]
    if raw:
        msg = ("HTML cru no markdown (linhas %s) — html.escape viraria texto "
               "visível. Converta antes (html2md.py no fragmento) ou exporte "
               "DOC_HARVEST_ALLOW_RAW_HTML=1 para escapar mesmo assim."
               % ", ".join(map(str, raw[:10])))
        if os.environ.get("DOC_HARVEST_ALLOW_RAW_HTML"):
            warn(msg)
        else:
            warn(msg)
            sys.exit(2)

    defs = {}
    for l, infence in zip(lines, mask):
        m = None if infence else REF_DEF.match(l)
        if m:
            defs[m.group(1).lower()] = m.group(2)
    if not defs:
        return lines

    def sub_refs(line):
        line = REF_FULL.sub(
            lambda m: "[%s](%s)" % (m.group(1), defs[(m.group(2) or m.group(1)).lower()])
            if (m.group(2) or m.group(1)).lower() in defs else m.group(0), line)
        return REF_SHORT.sub(
            lambda m: "[%s](%s)" % (m.group(1), defs[m.group(1).lower()])
            if m.group(1).lower() in defs else m.group(0), line)

    return ["" if (not infence and REF_DEF.match(l))
            else (l if infence else sub_refs(l))
            for l, infence in zip(lines, mask)]


def inline(text):
    """Escapa e aplica marcação inline. Code spans são protegidos primeiro."""
    text = html.escape(text, quote=False)
    # <br> é estrutural em células de tabela (quebra de linha) e XHTML válido
    # no storage — escapado viraria texto visível
    text = re.sub(r"&lt;br\s*/?&gt;", "<br/>", text)
    spans = []

    def stash(m):
        spans.append(m.group(1))
        return "\x00%d\x00" % (len(spans) - 1)

    text = CODE_SPAN.sub(stash, text)

    def attr(s):
        # valor de atributo XHTML: &/</> já escapados pelo html.escape acima;
        # falta a aspa, que romperia o atributo (injeção em conteúdo não confiável)
        return s.replace('"', "&quot;")

    # imagens viram referência ao anexo da própria página (o arquivo é anexado no publish)
    text = IMAGE.sub(lambda m: '<ac:image ac:alt="%s"><ri:attachment ri:filename="%s"/></ac:image>'
                     % (attr(m.group(1)), attr(m.group(2).rsplit("/", 1)[-1])), text)
    # âncora intra-página: <a href="#x"> não resolve no Confluence — precisa de ac:link
    text = ANCHOR_LINK.sub(
        lambda m: '<ac:link ac:anchor="%s"><ac:plain-text-link-body><![CDATA[%s]]>'
                  '</ac:plain-text-link-body></ac:link>'
        % (attr(m.group(2)), html.unescape(m.group(1) or m.group(2)).replace("]]>", "]] >")),
        text)
    text = LINK.sub(lambda m: '<a href="%s">%s</a>'
                    % (attr(m.group(2)), m.group(1) or m.group(2)), text)
    text = ANCHOR_MARK.sub(lambda m: anchor_macro(m.group(1)), text)
    text = BOLD.sub(r"<strong>\1</strong>", text)
    text = ITAL.sub(r"<em>\1</em>", text)
    for i, s in enumerate(spans):
        text = text.replace("\x00%d\x00" % i, "<code>%s</code>" % s)
    return text


def code_macro(lang, body):
    resolved = LANGS.get(lang.lower())
    if resolved is None:
        warn("language '%s' sem equivalente no Confluence — realce degradado "
             "para texto plano" % lang)
        resolved = "none"
    return ('<ac:structured-macro ac:name="code" ac:schema-version="1">'
            '<ac:parameter ac:name="language">%s</ac:parameter>'
            '<ac:plain-text-body><![CDATA[%s]]></ac:plain-text-body>'
            '</ac:structured-macro>' % (resolved, body.replace("]]>", "]] >")))


def indent_of(line):
    return len(line) - len(line.lstrip(" "))


class Parser:
    """Converte um bloco de linhas (já sem a indentação do contexto) em XHTML."""

    def __init__(self, lines):
        self.lines = lines
        self.i = 0

    def peek(self):
        return self.lines[self.i] if self.i < len(self.lines) else None

    def run(self):
        out = []
        while self.i < len(self.lines):
            line = self.lines[self.i]
            if not line.strip():
                self.i += 1
                continue
            if line.lstrip().startswith("```"):
                out.append(self.code())
            elif re.match(r"^#{1,6} ", line):
                out.append(self.heading())
            elif line.lstrip().startswith("> "):
                out.append(self.quote())
            elif self.is_table():
                out.append(self.table())
            elif re.match(r"^\s*([-*]|\d+\.)\s+", line):
                out.append(self.list_block())
            else:
                out.append(self.para())
        return "\n".join(x for x in out if x)

    def code(self):
        lang = self.lines[self.i].strip().lstrip("`").strip()
        base = indent_of(self.lines[self.i])
        self.i += 1
        body = []
        while self.i < len(self.lines) and not self.lines[self.i].strip().startswith("```"):
            ln = self.lines[self.i]
            # remove só a indentação do CONTEXTO (a da fence); com base=0,
            # ln[:0]=="" e strip()=="" mantém a linha intacta — nunca lstrip
            # incondicional, que achataria a indentação interna do código
            body.append(ln[base:] if ln[:base].strip() == "" else ln.lstrip())
            self.i += 1
        self.i += 1  # fecha a fence
        return code_macro(lang, "\n".join(body))

    def heading(self):
        m = re.match(r"^(#{1,6}) (.*)$", self.lines[self.i])
        self.i += 1
        lvl = max(2, min(len(m.group(1)), 6))  # H1 é o título da página; seções começam em h2
        text = m.group(2).strip()
        # macro anchor antes do heading: o storage não gera id em <hN>, e sem
        # isso todo link intra-página (#slug) morre
        return "%s<h%d>%s</h%d>" % (anchor_macro(slugify(text)), lvl, inline(text), lvl)

    def quote(self):
        buf = []
        while self.i < len(self.lines) and self.lines[self.i].lstrip().startswith(">"):
            buf.append(re.sub(r"^\s*>\s?", "", self.lines[self.i]))
            self.i += 1
        kind = "info"
        if buf and re.match(r"^\*\*(.+?)\*\*$", buf[0].strip()):
            label = re.match(r"^\*\*(.+?)\*\*$", buf[0].strip()).group(1).strip().lower()
            if label in ADMON:
                kind = ADMON[label]
                buf = buf[1:]
        inner = Parser(buf).run() or "<p></p>"
        return ('<ac:structured-macro ac:name="%s" ac:schema-version="1">'
                '<ac:rich-text-body>%s</ac:rich-text-body></ac:structured-macro>' % (kind, inner))

    def is_table(self):
        a, b = self.peek(), self.lines[self.i + 1] if self.i + 1 < len(self.lines) else ""
        return "|" in (a or "") and re.match(r"^\s*\|?[\s:|-]+\|[\s:|-]*$", b or "")

    def table(self):
        def cells(row):
            row = row.strip()
            if row.startswith("|"):
                row = row[1:]
            if row.endswith("|"):
                row = row[:-1]
            return [c.strip() for c in row.split("|")]

        head = cells(self.lines[self.i])
        self.i += 2  # cabeçalho + separador
        rows = []
        while self.i < len(self.lines) and "|" in self.lines[self.i] and self.lines[self.i].strip():
            r = cells(self.lines[self.i])
            # célula fantasma (gerador upstream emite '-'/vazio além do
            # cabeçalho): descarta; extra com conteúdo real fica, com aviso
            while len(r) > len(head) and r[-1] in ("", "-"):
                r.pop()
            if len(r) > len(head):
                warn("linha de tabela com %d células p/ cabeçalho de %d — "
                     "mantida, revisar: %s" % (len(r), len(head), "|".join(r)[:80]))
            r += [""] * (len(head) - len(r))
            rows.append(r)
            self.i += 1
        out = ["<table><tbody><tr>"]
        out += ["<th>%s</th>" % inline(c) for c in head]
        out.append("</tr>")
        for r in rows:
            out.append("<tr>" + "".join("<td>%s</td>" % inline(c) for c in r) + "</tr>")
        out.append("</tbody></table>")
        return "".join(out)

    def list_block(self):
        base = indent_of(self.lines[self.i])
        ordered = bool(re.match(r"^\s*\d+\.\s", self.lines[self.i]))
        tag = "ol" if ordered else "ul"
        items = []
        while self.i < len(self.lines):
            line = self.lines[self.i]
            if not line.strip():
                # linha em branco: só continua a lista se o próximo bloco pertence a ela
                nxt = next((l for l in self.lines[self.i + 1:] if l.strip()), None)
                if nxt is None or indent_of(nxt) < base:
                    break
                if indent_of(nxt) == base and not re.match(r"^\s*([-*]|\d+\.)\s+", nxt):
                    break
                self.i += 1
                continue
            ind = indent_of(line)
            if ind < base or not re.match(r"^\s*([-*]|\d+\.)\s+", line):
                break
            m = re.match(r"^\s*(?:[-*]|\d+\.)\s+(.*)$", line)
            body = [m.group(1)]
            self.i += 1
            # linhas de continuação do item (mais indentadas)
            while self.i < len(self.lines):
                nl = self.lines[self.i]
                if not nl.strip():
                    nxt = next((l for l in self.lines[self.i + 1:] if l.strip()), None)
                    if nxt is not None and indent_of(nxt) > ind:
                        body.append("")
                        self.i += 1
                        continue
                    break
                if indent_of(nl) > ind:
                    body.append(nl[ind + 2:] if len(nl) > ind + 2 else nl.strip())
                    self.i += 1
                else:
                    break
            items.append("<li>%s</li>" % Parser(body).run())
        return "<%s>%s</%s>" % (tag, "".join(items), tag)

    def para(self):
        buf = []
        while self.i < len(self.lines):
            line = self.lines[self.i]
            if (not line.strip() or line.lstrip().startswith(("```", ">"))
                    or re.match(r"^#{1,6} ", line)
                    or re.match(r"^\s*([-*]|\d+\.)\s+", line) or self.is_table()):
                break
            buf.append(line.strip())
            self.i += 1
        return "<p>%s</p>" % inline(" ".join(buf)) if buf else ""


def main():
    src, origin, date = sys.argv[1], sys.argv[2], sys.argv[3]
    raw = open(src, encoding="utf-8").read().split("\n")
    if raw and raw[0].startswith("# "):
        raw = raw[1:]
    _SLUGS.clear()
    raw = preprocess(raw)
    header = ('<ac:structured-macro ac:name="info" ac:schema-version="1"><ac:rich-text-body>'
              '<p>Tradução automática (doc-harvest) de <a href="%s">%s</a>, capturada em %s. '
              'Original em PDF anexado. Revisão humana pendente.</p>'
              '</ac:rich-text-body></ac:structured-macro>' % (origin, origin, date))
    sys.stdout.write(header + "\n" + Parser(raw).run() + "\n")


if __name__ == "__main__":
    main()

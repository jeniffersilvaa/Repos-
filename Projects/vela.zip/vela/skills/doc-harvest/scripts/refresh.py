#!/usr/bin/env python3
"""Detecta drift entre páginas publicadas pelo doc-harvest e suas origens.

Para cada descendente do pageId raiz (+ ele próprio) que tenha o header do
doc-harvest: baixa a URL de origem, calcula o hash do texto normalizado do
<article>/<main> e compara com o "Hash da fonte" gravado na página.

Uso: refresh.py <rootPageId> [--json]
     refresh.py --hash-of <arquivo.html>     # imprime o hash (p/ fluxo MCP)

Saída por página: atual | DESATUALIZADA | sem baseline (publicada antes do
hash existir — re-publicar uma vez para criar a baseline) | origem inacessível.
Requer ATLASSIAN_EMAIL/TOKEN/SITE no env (somente leitura no Confluence).
"""
import base64
import hashlib
import json
import os
import re
import ssl
import sys
import time
import urllib.request
from bs4 import BeautifulSoup

UA = "Mozilla/5.0 (X11; Linux x86_64) doc-harvest/0.1 (+interno Stone)"
ORIGIN = re.compile(r'Tradu[^<]*?<a href="(https?://[^"]+)"')
HASH = re.compile(r"Hash da fonte: ([0-9a-f]{12})")


def source_hash_html(html):
    """MANTER IDÊNTICO ao source_hash() de publish.py (lá recebe caminho).

    Desofusca data-cfemail antes de hashear: os snapshots de captura já vêm
    desofuscados pelo harvest.sh; sem isso, páginas com '@' (purl, e-mails,
    Connector@host) dariam falso positivo de drift contra a origem viva."""
    soup = BeautifulSoup(html, "html.parser")
    for el in soup.select("[data-cfemail]"):
        try:
            h = el["data-cfemail"]
            k = int(h[:2], 16)
            el.replace_with("".join(chr(int(h[i:i + 2], 16) ^ k)
                                    for i in range(2, len(h), 2)))
        except (ValueError, KeyError):
            pass
    root = soup.find("article") or soup.find("main") or soup
    text = " ".join(root.get_text().split())
    return hashlib.sha256(text.encode()).hexdigest()[:12]


def main():
    if "--hash-of" in sys.argv:
        path = sys.argv[sys.argv.index("--hash-of") + 1]
        print(source_hash_html(open(path, encoding="utf-8", errors="replace").read()))
        return 0

    argv = [a for a in sys.argv[1:] if not a.startswith("--")]
    as_json = "--json" in sys.argv
    if not argv:
        print(__doc__, file=sys.stderr)
        return 2
    root_id = argv[0]

    base = "https://%s" % os.environ["ATLASSIAN_SITE"]
    auth = "Basic " + base64.b64encode(
        ("%s:%s" % (os.environ["ATLASSIAN_EMAIL"],
                    os.environ["ATLASSIAN_TOKEN"])).encode()).decode()
    ctx = ssl.create_default_context()

    def api(path):
        req = urllib.request.Request(base + path)
        req.add_header("Authorization", auth)
        req.add_header("Accept", "application/json")
        with urllib.request.urlopen(req, context=ctx, timeout=60) as r:
            return json.load(r)

    def fetch(url):
        req = urllib.request.Request(url, headers={"User-Agent": UA})
        with urllib.request.urlopen(req, context=ctx, timeout=60) as r:
            return r.read().decode(r.headers.get_content_charset() or "utf-8",
                                   errors="replace")

    pages = [{"id": root_id}] + api(
        "/wiki/api/v2/pages/%s/descendants?depth=5&limit=250" % root_id)["results"]
    out = []
    for p in pages:
        page = api("/wiki/api/v2/pages/%s?body-format=storage" % p["id"])
        body = page["body"]["storage"]["value"]
        om = ORIGIN.search(body)
        if not om:
            continue  # página sem header doc-harvest: fora do escopo
        hm = HASH.search(body)
        entry = {"id": str(page["id"]), "title": page["title"],
                 "origin": om.group(1)}
        if not hm:
            entry["status"] = "sem baseline"
        else:
            try:
                html = fetch(entry["origin"])
                time.sleep(1)
                soup = BeautifulSoup(html, "html.parser")
                root = soup.find("article") or soup.find("main") or soup
                if len(root.get_text().split()) < 40:
                    # HTTP 200 com corpo de erro (soft-404): não é drift —
                    # a URL de origem gravada no header provavelmente está errada
                    entry["status"] = "origem suspeita (soft-404?) — conferir URL do header"
                else:
                    live = source_hash_html(html)
                    entry["status"] = ("atual" if live == hm.group(1)
                                       else "DESATUALIZADA")
                    entry["hash_pagina"], entry["hash_origem"] = hm.group(1), live
            except Exception as exc:
                entry["status"] = "origem inacessível (%s)" % exc
        out.append(entry)
        # progresso por página (árvore grande + origem lenta = minutos de loop;
        # sem isso o operador não distingue "rodando" de "travado")
        print("%-55s %s" % (entry["title"][:55], entry["status"]),
              file=sys.stderr if as_json else sys.stdout, flush=True)

    if as_json:
        print(json.dumps(out, ensure_ascii=False, indent=2))
    else:
        stale = sum(1 for e in out if e["status"] == "DESATUALIZADA")
        print("\n%d página(s) doc-harvest; %d desatualizada(s)" % (len(out), stale))
    return 0


if __name__ == "__main__":
    sys.exit(main())

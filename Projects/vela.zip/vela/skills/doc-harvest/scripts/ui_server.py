#!/usr/bin/env python3
"""doc-harvest UI — frontend local ultra-leve com streaming (SSE), stdlib apenas.

Serve uma página única que acompanha o pipeline em tempo real fazendo tail de
<WORKDIR>/events.jsonl. Sem dependências, sem build, bind apenas em 127.0.0.1.

Uso:
    python3 ui_server.py --workdir DIR [--port 0] [--open]
Imprime a URL no stdout e fica em foreground (rodar em background).
"""
import argparse
import json
import os
import sys
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HEARTBEAT_EVERY = 15  # segundos entre comentários ": ping" no stream SSE
POLL = 0.4            # intervalo de tail do events.jsonl

HTML = r"""<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>doc-harvest</title>
<style>
  :root {
    --bg: #0f1512; --surface: #151f19; --border: #233029;
    --ink: #e9f1ec; --muted: #9cb2a5; --faint: #5c6f64;
    --accent: #00a868;
    --ok: #3ec98a; --run: #d9a13b; --err: #e2635a;
  }
  * { box-sizing: border-box; margin: 0; }
  body {
    background: var(--bg); color: var(--ink);
    font: 15px/1.5 "Avenir Next", Seravek, "Segoe UI", system-ui, sans-serif;
    min-height: 100vh; display: flex; flex-direction: column;
  }
  header {
    display: flex; align-items: baseline; gap: 1rem; flex-wrap: wrap;
    padding: clamp(1rem, 3vw, 2rem) clamp(1rem, 4vw, 3rem) .75rem;
  }
  header h1 { font-size: clamp(1.3rem, 2.5vw, 1.7rem); font-weight: 600; letter-spacing: -.02em; }
  header h1 em { color: var(--accent); font-style: normal; }
  #rundir { color: var(--faint); font-size: .8rem; overflow-wrap: anywhere; }
  #conn { margin-left: auto; font-size: .8rem; color: var(--muted); }
  #conn.off { color: var(--err); }
  main { flex: 1; padding: 0 clamp(1rem, 4vw, 3rem) 1rem; }
  #empty { color: var(--muted); padding: 2.5rem 0 1rem; max-width: 34rem; }
  #empty code { color: var(--ink); }
  table { border-collapse: collapse; width: 100%; }
  th {
    text-align: left; font-size: .72rem; text-transform: uppercase;
    letter-spacing: .08em; color: var(--faint); font-weight: 600;
    padding: .4rem .75rem .4rem 0; border-bottom: 1px solid var(--border);
  }
  td { padding: .55rem .75rem .55rem 0; border-bottom: 1px solid var(--border); vertical-align: middle; }
  td.doc { font-weight: 600; overflow-wrap: anywhere; }
  td.detail { color: var(--muted); font-size: .82rem; max-width: 28ch; overflow-wrap: anywhere; }
  .chip {
    display: inline-flex; align-items: center; gap: .35em;
    font-size: .78rem; padding: .15em .6em; border-radius: 999px;
    border: 1px solid var(--border); color: var(--faint); white-space: nowrap;
  }
  .chip.start { color: var(--run); border-color: color-mix(in srgb, var(--run) 45%, transparent); }
  .chip.ok    { color: var(--ok);  border-color: color-mix(in srgb, var(--ok) 45%, transparent); }
  .chip.error { color: var(--err); border-color: color-mix(in srgb, var(--err) 55%, transparent); }
  .chip.start .dot { animation: pulse 1.2s ease-out infinite; }
  @keyframes pulse { 50% { opacity: .25; } }
  @media (prefers-reduced-motion: reduce) { .chip.start .dot { animation: none; } }
  #banner {
    display: none; margin: 1rem 0; padding: .6rem 1rem; border-radius: 6px;
    border: 1px solid color-mix(in srgb, var(--accent) 50%, transparent);
    color: var(--ok); font-weight: 600;
  }
  #logwrap { padding: 0 clamp(1rem, 4vw, 3rem) clamp(1rem, 3vw, 2rem); }
  #logwrap h2 { font-size: .72rem; text-transform: uppercase; letter-spacing: .08em; color: var(--faint); margin-bottom: .4rem; }
  #log {
    background: var(--surface); border: 1px solid var(--border); border-radius: 8px;
    font: 12px/1.7 ui-monospace, "Cascadia Code", Menlo, monospace;
    height: 32vh; overflow-y: auto; padding: .75rem 1rem; white-space: pre-wrap; overflow-wrap: anywhere;
  }
  #log .ts { color: var(--faint); }
  #log .err { color: var(--err); }
  #log .ok { color: var(--ok); }
</style>
</head>
<body>
<header>
  <h1>doc<em>-harvest</em></h1>
  <span id="rundir"></span>
  <span id="conn">conectando…</span>
</header>
<main>
  <p id="empty">Aguardando eventos do pipeline… Cada documento aparece aqui assim que
  o primeiro evento é emitido em <code>events.jsonl</code>.</p>
  <div id="banner"></div>
  <table id="docs" hidden>
    <thead><tr>
      <th>Documento</th><th>PDF</th><th>Markdown</th><th>Tradução</th><th>Publicação</th><th>Último detalhe</th>
    </tr></thead>
    <tbody></tbody>
  </table>
</main>
<div id="logwrap">
  <h2>Eventos</h2>
  <div id="log"></div>
</div>
<script>
"use strict";
const STAGES = ["pdf", "markdown", "translate", "publish"];
const LABELS = { pending: "○ aguardando", start: "● em curso", ok: "✓ ok", error: "✕ erro", info: "· info" };
const docs = new Map(); // slug -> {row, cells:{stage:td}, detail:td}
const tbody = document.querySelector("#docs tbody");
const log = document.getElementById("log");

function chip(status) {
  return '<span class="chip ' + status + '"><span class="dot"></span>' + (LABELS[status] || status) + "</span>";
}
function ensureDoc(slug) {
  if (docs.has(slug)) return docs.get(slug);
  document.getElementById("empty").hidden = true;
  document.getElementById("docs").hidden = false;
  const row = tbody.insertRow();
  const entry = { cells: {}, detail: null };
  row.insertCell().outerHTML = '<td class="doc">' + esc(slug) + "</td>";
  for (const s of STAGES) {
    const td = row.insertCell();
    td.innerHTML = chip("pending");
    entry.cells[s] = td;
  }
  entry.detail = row.insertCell();
  entry.detail.className = "detail";
  docs.set(slug, entry);
  return entry;
}
function esc(s) {
  return String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
}
function addLog(ev) {
  const cls = ev.status === "error" ? "err" : ev.status === "ok" ? "ok" : "";
  const line = document.createElement("div");
  line.innerHTML = '<span class="ts">' + esc((ev.ts || "").replace("T", " ").slice(0, 19)) + "</span> " +
    '<span class="' + cls + '">' + esc([ev.doc !== "-" ? ev.doc : "run", ev.stage, ev.status, ev.detail].filter(Boolean).join(" · ")) + "</span>";
  const stick = log.scrollTop + log.clientHeight >= log.scrollHeight - 8;
  log.appendChild(line);
  if (stick) log.scrollTop = log.scrollHeight;
}
function handle(ev) {
  addLog(ev);
  if (ev.doc === "-" || ev.stage === "run") {
    if (ev.status === "done" || (ev.stage === "run" && ev.status === "ok")) {
      const b = document.getElementById("banner");
      b.style.display = "block";
      b.textContent = "✓ Pipeline concluído" + (ev.detail ? " — " + ev.detail : "");
    }
    if (ev.stage === "run" && ev.detail && ev.status === "start")
      document.getElementById("rundir").textContent = ev.detail;
    return;
  }
  const entry = ensureDoc(ev.doc);
  if (STAGES.includes(ev.stage)) entry.cells[ev.stage].innerHTML = chip(ev.status);
  if (ev.detail) entry.detail.textContent = ev.detail;
}
const conn = document.getElementById("conn");
const es = new EventSource("/events");
es.onopen = () => { conn.textContent = "ao vivo"; conn.className = ""; };
es.onerror = () => { conn.textContent = "reconectando…"; conn.className = "off"; };
es.onmessage = m => { try { handle(JSON.parse(m.data)); } catch (e) { /* linha malformada: ignora */ } };
</script>
</body>
</html>
"""


def read_new_lines(path, pos):
    """Lê linhas completas de `path` a partir de `pos` (bytes). Retorna (linhas, novo_pos)."""
    try:
        size = os.path.getsize(path)
    except OSError:
        return [], pos
    if size < pos:  # arquivo truncado/recriado
        pos = 0
    if size == pos:
        return [], pos
    with open(path, "rb") as f:
        f.seek(pos)
        chunk = f.read()
    last_nl = chunk.rfind(b"\n")
    if last_nl == -1:
        return [], pos
    lines = [l for l in chunk[: last_nl + 1].split(b"\n") if l.strip()]
    return lines, pos + last_nl + 1


class Handler(BaseHTTPRequestHandler):
    workdir = "."

    def log_message(self, *args):  # silencia o access log
        pass

    def do_GET(self):
        if self.path in ("/", "/index.html"):
            body = HTML.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif self.path == "/events":
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            events_path = os.path.join(self.workdir, "events.jsonl")
            pos = 0
            last_beat = time.monotonic()
            try:
                while True:
                    lines, pos = read_new_lines(events_path, pos)
                    for line in lines:
                        self.wfile.write(b"data: " + line + b"\n\n")
                    if lines:
                        self.wfile.flush()
                    if time.monotonic() - last_beat > HEARTBEAT_EVERY:
                        self.wfile.write(b": ping\n\n")
                        self.wfile.flush()
                        last_beat = time.monotonic()
                    time.sleep(POLL)
            except (BrokenPipeError, ConnectionResetError):
                return
        else:
            self.send_response(404)
            self.end_headers()


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--workdir", required=True, help="diretório com events.jsonl")
    ap.add_argument("--port", type=int, default=0, help="porta (default: aleatória livre)")
    ap.add_argument("--open", action="store_true", help="abre o navegador na URL")
    args = ap.parse_args()

    Handler.workdir = os.path.abspath(args.workdir)
    server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    url = f"http://127.0.0.1:{server.server_address[1]}/"
    print(url, flush=True)
    if args.open:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())

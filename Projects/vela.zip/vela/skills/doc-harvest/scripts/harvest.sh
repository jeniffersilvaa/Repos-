#!/usr/bin/env bash
# harvest.sh — captura uma página de doc: PDF (sempre, para anexo/auditoria) +
# markdown de conteúdo pela melhor rota disponível, emitindo eventos JSONL.
#
# Uso: harvest.sh <URL> <WORKDIR> <SLUG> [SOURCE_URL]
#   SOURCE_URL: fonte upstream (descubra com find_source.py) — rota mais fiel.
#   Sem SOURCE_URL: HTML→docling; se render insuficiente (<50 palavras), PDF→docling.
#   Env: DOC_HARVEST_VTB   ms de render do Chrome (default 15000; SPAs: 30000)
#        DOC_HARVEST_ROUTE forçar rota de conteúdo: html | pdf
#   Gera: pdf/<SLUG>.pdf (sempre) e md/<SLUG>.md (conteúdo)
set -euo pipefail

URL="$1"; WORKDIR="$2"; SLUG="$3"; SOURCE_URL="${4:-}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
UA="Mozilla/5.0 (X11; Linux x86_64) doc-harvest/0.1 (+interno Stone)"
# timeouts: sem eles um rate-limit (ex.: Cloudflare) trava o pipeline por minutos
CURL_TO=(--connect-timeout 10 --max-time 60)
CHROME_LOG="$WORKDIR/logs/chrome-$SLUG.log"
DOCLING_LOG="$WORKDIR/logs/docling-$SLUG.log"
mkdir -p "$WORKDIR/pdf" "$WORKDIR/md" "$WORKDIR/html" "$WORKDIR/logs"

emit() { # emit <stage> <status> [detail]
  python3 "$SCRIPT_DIR/emit.py" "$WORKDIR" "$SLUG" "$1" "$2" "${3:-}"
}

PDF="$WORKDIR/pdf/$SLUG.pdf"
MD="$WORKDIR/md/$SLUG.md"

# --- PDF: sempre, é o anexo de auditoria da página como servida ---
emit pdf start "$URL"
HTTP_CODE=$(curl -s "${CURL_TO[@]}" -o /dev/null -w '%{http_code}' -A "$UA" -L "$URL" || echo 000)
if [ "$HTTP_CODE" -ge 400 ] 2>/dev/null; then
  emit pdf info "página respondeu HTTP $HTTP_CODE — PDF pode ser página de erro"
fi
if ! google-chrome-stable --headless=new --disable-gpu --no-sandbox \
    --virtual-time-budget="${DOC_HARVEST_VTB:-15000}" --hide-scrollbars \
    --print-to-pdf="$PDF" --print-to-pdf-no-header \
    "$URL" >"$CHROME_LOG" 2>&1; then
  emit pdf error "chrome falhou; ver $CHROME_LOG"
  exit 1
fi
if [ ! -s "$PDF" ]; then
  emit pdf error "PDF vazio; ver $CHROME_LOG"
  exit 1
fi
emit pdf ok "$(du -h "$PDF" | cut -f1)"

# --- Markdown de conteúdo: upstream > html > pdf ---
words() { wc -w < "$MD" 2>/dev/null | tr -d ' ' || echo 0; }

route_pdf() {
  emit markdown start "rota pdf (docling)"
  rm -f "$MD"
  docling "$PDF" --to md --output "$WORKDIR/md" \
    --image-export-mode placeholder >>"$DOCLING_LOG" 2>&1 || true
  ROUTE="pdf"
}

ROUTE=""
if [ -n "$SOURCE_URL" ]; then
  emit markdown start "fonte upstream"
  if curl -sSL --fail "${CURL_TO[@]}" -A "$UA" "$SOURCE_URL" -o "$MD"; then
    ROUTE="upstream"
  else
    emit markdown info "upstream falhou; tentando rota html"
  fi
fi
if [ -z "$ROUTE" ] && [ "${DOC_HARVEST_ROUTE:-html}" = "html" ]; then
  emit markdown start "rota html"
  rm -f "$MD"
  RAW_HTML="$WORKDIR/html/$SLUG.html"
  if curl -sSL --fail "${CURL_TO[@]}" -A "$UA" "$URL" -o "$RAW_HTML"; then
    # Pré-processa o HTML antes do docling. Best-effort: exige bs4; sem ele ou
    # sem nada a fazer, segue com a página como baixada.
    #  1. Desofusca data-cfemail (Cloudflare) — ver comentário no bloco Python.
    #  2. Recorta <article>/<main> — em help centers proprietários (ex.:
    #     help.sonatype.com) o <main> inclui, além do conteúdo, widgets irmãos
    #     (TOC in-page, pager Prev/Next, feedback com link ofuscado) que viram
    #     lixo no fim do markdown.
    if python3 -c "import bs4" >/dev/null 2>&1; then
      FRAG="$(mktemp)"
      if PRE_INFO=$(python3 - "$RAW_HTML" "$FRAG" <<'PYEOF'
import sys
from bs4 import BeautifulSoup
src, dst = sys.argv[1], sys.argv[2]
soup = BeautifulSoup(open(src, encoding="utf-8", errors="replace"), "html.parser")

# Cloudflare "email obfuscation" reescreve QUALQUER texto com '@' como
# <a class="__cf_email__" data-cfemail="HEX">[email protected]</a>. Em doc
# técnica isso destrói purl (pkg:npm/foo@1.2.3), coordenadas Maven (g:a:v) e
# logs (Connector@0.0.0.0:8070). O HEX é o texto XOR do seu 1º byte (a chave).
def cf_decode(h):
    k = int(h[:2], 16)
    return "".join(chr(int(h[i:i + 2], 16) ^ k) for i in range(2, len(h), 2))

n = 0
for el in soup.select("[data-cfemail]"):
    try:
        el.replace_with(cf_decode(el["data-cfemail"]))
        n += 1
    except (ValueError, KeyError):
        pass

# Achata <pre> tokenizado por spans (highlight.js/Prism) em texto puro — o
# docling perde a indentação quando o código vem span a span; com texto puro
# ambos os conversores preservam o bloco verbatim.
npre = 0
for pre in soup.find_all("pre"):
    if pre.find(True) is not None:
        text = pre.get_text()
        pre.clear()
        pre.string = text
        npre += 1

notes = []
if n:
    notes.append("%d trecho(s) data-cfemail desofuscado(s)" % n)
if npre:
    notes.append("%d <pre> achatado(s) p/ texto puro" % npre)
frag = soup.find("article") or soup.find("main")
if frag and len(frag.get_text(strip=True)) > 40:
    notes.append("recorte <article>/<main> aplicado")
    body = str(frag)
elif notes:
    body = str(soup.body or soup)
else:
    sys.exit(1)  # nada a fazer: mantém o HTML como baixado
open(dst, "w", encoding="utf-8").write(
    "<!doctype html><html><head><meta charset='utf-8'></head><body>" + body + "</body></html>")
print("; ".join(notes))
PYEOF
      )
      then
        mv "$FRAG" "$RAW_HTML"
        emit markdown info "html: $PRE_INFO"
      else
        rm -f "$FRAG"
      fi
    fi
    # Roteamento de conversor por classe de site (evidência de runs reais):
    #   CCMS/MadCap (taxonomy-products-*/data-permalink) → html2md, pois o
    #   docling descarta sub-listas de li.step e links de tabelas aninhadas;
    #   sites genéricos → docling (com <pre> já achatado no pré-processamento,
    #   que cura a perda de indentação). Se o escolhido render pouco, tenta o
    #   outro. DOC_HARVEST_CONVERTER=html2md|docling força.
    if [ -n "${DOC_HARVEST_CONVERTER:-}" ]; then
      PREFER="$DOC_HARVEST_CONVERTER"
    elif grep -q 'taxonomy-products-\|data-permalink' "$RAW_HTML" 2>/dev/null; then
      PREFER="html2md"
    else
      PREFER="docling"
    fi
    try_html2md() {
      python3 -c "import bs4" >/dev/null 2>&1 || return 1
      python3 "$SCRIPT_DIR/html2md.py" "$RAW_HTML" --base-url "$URL" > "$MD" 2>>"$DOCLING_LOG" \
        && [ -s "$MD" ] && [ "$(words)" -ge 50 ]
    }
    try_docling() {
      docling "$RAW_HTML" --from html --to md \
        --output "$WORKDIR/md" >"$DOCLING_LOG" 2>&1 || true
      [ -s "$MD" ] && [ "$(words)" -ge 50 ]
    }
    CONV=""
    for c in "$PREFER" $([ "$PREFER" = html2md ] && echo docling || echo html2md); do
      rm -f "$MD"
      if "try_$c"; then CONV="$c"; break; fi
    done
    [ -n "$CONV" ] || rm -f "$MD"
  fi
  if [ -s "$MD" ] && [ "$(words)" -ge 50 ]; then
    ROUTE="html:${CONV:-docling}"
  else
    emit markdown info "html insuficiente ($(words) palavras); caindo para rota pdf"
  fi
fi
if [ -z "$ROUTE" ] || [ ! -s "$MD" ]; then
  route_pdf
fi

if [ ! -s "$MD" ]; then
  emit markdown error "nenhuma rota gerou markdown; ver $DOCLING_LOG"
  exit 1
fi

# Entidades HTML cruas (&amp; etc.) que o docling deixa passar em prosa/células:
# decodifica fora de code fences. Não roda na rota upstream (markdown autoral —
# entidades podem ser conteúdo intencional).
if [ "$ROUTE" != "upstream" ]; then
  python3 - "$MD" <<'PYEOF'
import html, sys
p = sys.argv[1]
out, fenced = [], False
for ln in open(p, encoding="utf-8").read().split("\n"):
    if ln.lstrip().startswith("```"):
        fenced = not fenced
        out.append(ln)
    else:
        out.append(ln if fenced else html.unescape(ln))
open(p, "w", encoding="utf-8").write("\n".join(out))
PYEOF
fi

# Gate de fidelidade (rota html): compara contagens HTML×md; perdas graves
# derrubam o harvest — perda silenciosa foi o defeito recorrente dos runs.
# DOC_HARVEST_NO_VERIFY=1 rebaixa o fail para aviso.
case "$ROUTE" in html:*)
  VERDICT=0
  VOUT=$(python3 "$SCRIPT_DIR/verify_fidelity.py" "$WORKDIR/html/$SLUG.html" "$MD" 2>>"$DOCLING_LOG") || VERDICT=$?
  case "$VERDICT" in
    1) emit markdown info "fidelidade: $VOUT" ;;
    2) if [ "${DOC_HARVEST_NO_VERIFY:-0}" = "1" ]; then
         emit markdown info "fidelidade IGNORADA: $VOUT"
       else
         emit markdown error "fidelidade: $VOUT — conteúdo perdido; ver html/$SLUG.html"
         exit 1
       fi ;;
  esac
esac

emit markdown ok "$(words) palavras (rota: $ROUTE)"
echo "$MD"

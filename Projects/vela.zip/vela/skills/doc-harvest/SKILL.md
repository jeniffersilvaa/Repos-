---
name: doc-harvest
description: "Internaliza documentacao externa no Confluence — baixa docs como PDF + markdown (docling), traduz para PT-BR e publica com pathing semantico em espaco/pastas configuraveis, com card de revisao no Jira — triggers: doc-harvest, internalizar doc, importar documentacao, scraping de docs, baixar documentacao, docling, traduzir documentacao, doc para PT-BR, publicar doc no confluence"
---

# doc-harvest — docs externas → PDF → Markdown → PT-BR → Confluence

## O que faz

Pipeline completo de internalização de documentação:

```
links → markdown de conteúdo pela melhor rota (fonte upstream → HTML → PDF)
      + PDF sempre capturado (Chrome headless — anexo de auditoria)
      → tradução PT-BR (Claude) → pathing semântico → Confluence (+ PDF anexado)
      → card de revisão no Jira
```

**Fidelidade por rota** (por que a cascata existe): a fonte upstream (markdown do repo,
achada via link "edit this page" ou sonda GitHub Pages) é perfeita; a rota HTML preserva
prosa/tabelas/admonitions/tabs mas perde indentação de código; a rota PDF perde conteúdo
real (tabs viram só a aba ativa, tabelas viram `<!-- image -->`, linhas de código colam).

Com frontend local de acompanhamento em tempo real (SSE, `scripts/ui_server.py`)
alimentado por eventos JSONL emitidos em cada etapa.

## Quando usar / quando NÃO usar

- **Usar**: docs públicas de vendors/projetos open source que o time precisa em PT-BR no
  Confluence; um link ou um lote de links (mesmo escopo ou escopos distintos).
- **NÃO usar**: conteúdo atrás de login/paywall, docs com licença que proíba redistribuição
  (verifique antes; em dúvida, avise o usuário), ou páginas do próprio Confluence
  (para essas, use a skill `documentation`).

## Pré-requisitos

- `docling` no PATH (se ausente: `pip install --user docling` — primeira execução
  baixa modelos, avise o usuário). Se já instalado, **não** use `uvx docling`.
- Chrome headless (`google-chrome-stable`, `google-chrome` ou `chromium`).
- `python3` com `bs4` (BeautifulSoup).
- Acesso Atlassian, por UMA das vias (a skill funciona com qualquer uma):
  - **Tools MCP atlassian** (`atlassian__*` do vela-mcp-hub) — via preferida e
    portátil: não exige credencial local nenhuma (cloudId: ver knowledge
    `atlassian-instance`).
  - **Credenciais REST** no ambiente (`ATLASSIAN_EMAIL`, `ATLASSIAN_TOKEN`,
    `ATLASSIAN_SITE` — ex.: `allstone.atlassian.net`) — necessárias apenas para
    **anexos** (PDF/imagens; MCP não anexa) e para o `publish.py` em lote.
    Nunca ecoe o token em logs, comandos visíveis ou mensagens.
  Sem token: publique via MCP e registre os anexos como pendência no relatório.

Validação rápida: `which docling && python3 -c "import bs4" && echo ok`

Ao editar qualquer script da skill, rode antes `python3 tests/test_md2storage.py`
e `python3 tests/test_lint_md.py` (na raiz da skill) — os casos são as armadilhas
de runs reais; quebrar um deles é regredir um incidente já pago.

## Configuração inicial (uma vez por usuário)

Os destinos de publicação e o Jira são **configuráveis por usuário** em
`~/.config/doc-harvest/config.json`, via `scripts/config.py`. Na primeira execução
(`config.py get` devolve `{}`), pergunte ao usuário (AskUserQuestion) e grave:

```bash
python3 "$SKILL/scripts/config.py" set confluence_space   <KEY>      # ex.: FOUND
python3 "$SKILL/scripts/config.py" set draft_parent_id    <pageId>   # pasta de rascunhos do time
python3 "$SKILL/scripts/config.py" set official_parent_id <pageId>   # pasta de publicação oficial
python3 "$SKILL/scripts/config.py" set jira_project       <KEY>      # project dos cards de revisão
```

O pageId está na URL da página no Confluence
(`/wiki/spaces/<KEY>/pages/<pageId>/...`). Peça ao usuário os links das duas
pastas e extraia os ids. Exemplo (time Karavela): espaço `FOUND`, drafts
`7345047110`, oficial `6412704747`, Jira `ATL`.

## Destinos de publicação

Leia a configuração no início do fluxo:

```bash
python3 "$SKILL/scripts/config.py" get   # SPACE=confluence_space, etc.
```

| Modo | Parent |
|---|---|
| **Draft** (rascunho do time) | página `draft_parent_id` |
| **Oficial** (nova pasta semântica) | nova pasta filha de `official_parent_id` |

**Pathing semântico (modo oficial):** analise títulos e conteúdo dos markdowns e proponha
uma árvore antes de publicar:

- Todos os links do mesmo escopo (ex.: 4 páginas da doc do Argo Rollouts) → **uma** pasta
  nova nomeada pelo tema (`Argo Rollouts`) com uma página filha por documento.
- Escopos distintos → uma pasta por tema; itens avulsos sem coesão → sugerir Drafts.
- Nomes de pasta/página em PT-BR e curtos por padrão. **Exceção que é regra**: título
  genérico que já exista no espaço ("Projetos", "Cache", "Repositórios"...) ou corpus
  que coexistirá com outra versão → prefixo de corpus no título (ex.: `DT v5 — Projetos`).
  O Confluence é único por título no espaço INTEIRO e a publicação é idempotente por
  título — sem prefixo, você sobrescreve página alheia. Cheque colisões antes de
  propor a árvore: `publish.py spec.json --dry-run` reporta `COLISÃO` por página;
  via MCP, busque cada título no espaço antes do POST.

Sempre apresente a árvore proposta e pergunte (AskUserQuestion): **Draft ou oficial?**
Nunca publique sem essa confirmação.

## Como funciona

### Passo 1 — Preparar o run

```bash
WORKDIR="$CLAUDE_SCRATCHPAD/doc-harvest-$(date +%Y%m%d-%H%M%S)"   # ou mktemp -d
mkdir -p "$WORKDIR" ~/.cache/doc-harvest
echo "$WORKDIR" > ~/.cache/doc-harvest/current    # pointer do run ativo
mkdir -p ~/.cache/doc-harvest/runs && echo "$WORKDIR" > ~/.cache/doc-harvest/runs/"$(basename "$WORKDIR")"   # registry (runs concorrentes)
SKILL=<diretório base desta skill>   # linha "Base directory for this skill" da invocação
echo "$SKILL" > ~/.cache/doc-harvest/skill   # pointer p/ shells futuros
python3 "$SKILL/scripts/emit.py" --init "$WORKDIR" - run start "$WORKDIR (N docs)"
```

**O shell do Bash tool NÃO persiste variáveis entre comandos.** Em todo comando
posterior (harvest, tradução, publicação, encerramento), recupere o run ativo com:

```bash
WORKDIR=$(cat ~/.cache/doc-harvest/current); SKILL=$(cat ~/.cache/doc-harvest/skill)
```

**Nunca re-execute a linha do `date`** — isso cria OUTRO diretório e seus eventos
somem do frontend (que segue preso ao primeiro). O `emit.py` sem `--init` falha
alto se o events.jsonl não existir, exatamente para acusar esse erro.

### Passo 2 — Subir o frontend (SSE)

```bash
python3 "$SKILL/scripts/ui_server.py" --workdir "$WORKDIR" --open > "$WORKDIR/ui_url.txt" 2>&1 &
sleep 1 && cat "$WORKDIR/ui_url.txt"   # ex.: http://127.0.0.1:41231/
```

Rode em background, informe a URL ao usuário (o `--open` já abre o browser). A página
faz tail de `$WORKDIR/events.jsonl` e mostra chips por etapa + log ao vivo.
**Encerre ao final** (Passo 8).

### Passo 3 — Descobrir subpáginas (SEMPRE) e confirmar o conjunto

**A descoberta é parte do fluxo padrão — não espere o usuário pedir.** Um link de
doc quase sempre é a raiz de uma seção com subpáginas de interesse; entregar só a
página raiz é entregar a doc pela metade. Só pule a descoberta se o usuário disser
explicitamente "só esses links".

Para CADA link recebido, na ordem:

1. **TOC/sidebar** (melhor sinal — hierarquia real):
   ```bash
   python3 "$SKILL/scripts/subtree.py" "$URL"          # árvore; --json p/ máquina
   ```
   Funciona em help centers de namespace achatado (a hierarquia só existe na TOC)
   e em sidebars com aninhamento real. Se achar o ramo, essa é a lista canônica.
2. **Fallback** (sem TOC no HTML, ou subtree devolveu 0 — alguns temas achatam a
   nav e as "subpáginas" viram irmãs, que só o crawl enxerga):
   ```bash
   python3 "$SKILL/scripts/crawl.py" URL1 [URL2 ...] --max 20
   ```

**Atenção ao prefixo:** o default aceita links sob o *diretório* da semente. Se a URL
termina em `/` (padrão readthedocs/mkdocs), isso encontra só as *filhas*; para páginas
**irmãs**, passe o diretório pai explícito, ex.:
`crawl.py .../features/canary/ --prefix /en/stable/features/`.

**Help centers de namespace achatado** (MadCap Flare/RoboHelp, Zendesk, Document360 —
ex.: `help.sonatype.com`, tudo em `/en/<slug>.html` sem diretório por produto): o
prefixo degenera para o diretório de idioma e aceitaria o help center inteiro. O
`crawl.py` se defende em duas camadas (mensagens no stderr): quando os `<a>` carregam
marcação `taxonomy-products-*` (MadCap), filtra automaticamente por MESMO produto da
semente; sem essa marcação, avisa "prefixo raso" — nesse caso trate a saída como
candidatos brutos e confirme título a título com o usuário.

Mostre a árvore/lista descoberta e **confirme quais entram** (AskUserQuestion)
antes de baixar qualquer coisa — apresentar as subpáginas encontradas é obrigação
sua; escolher é do usuário. Defina um slug kebab-case por URL (do path, ex.:
`docling-usage`).

### Passo 4 — Descobrir fontes e baixar (por URL)

Primeiro, em lote (uma chamada só — o script cacheia a sonda por site):

```bash
python3 "$SKILL/scripts/find_source.py" URL1 URL2 ... > "$WORKDIR/sources.json"
```

Depois, por URL, passando a fonte quando existir:

```bash
"$SKILL/scripts/harvest.sh" "$URL" "$WORKDIR" "$SLUG" "$SOURCE_URL_OU_VAZIO"
# → pdf/$SLUG.pdf (sempre) + md/$SLUG.md (rota: upstream > html > pdf, automática)
```

Na rota html o conversor é **roteado por classe de site**: CCMS/MadCap (detecta
`taxonomy-products-*`/`data-permalink`) → `html2md.py` (o docling descarta
sub-listas de `li.step` e links de tabelas aninhadas nesses sites); sites
genéricos → **docling**, com o pré-processamento achatando `<pre>` tokenizado
por spans (cura a perda de indentação do highlight.js/Prism). Se o escolhido
render pouco, tenta o outro; `DOC_HARVEST_CONVERTER=html2md|docling` força.
O pré-processamento também desofusca `data-cfemail` da Cloudflare (que corrompe
qualquer texto com `@`: purl, coordenadas Maven, `Connector@0.0.0.0:8070`) e
recorta `<article>`/`<main>`.

**Gate de fidelidade**: após a conversão html, `verify_fidelity.py` compara
contagens (headings/links/pre/tabelas) HTML×md — perda >50% em qualquer métrica
DERRUBA o harvest com evento `markdown error` (escape: `DOC_HARVEST_NO_VERIFY=1`
rebaixa para aviso); 50–80% vira evento `info` para checar na revisão.

O script emite os eventos `pdf` e `markdown` sozinho (o detail diz rota e
conversor). Erros ficam em `$WORKDIR/logs/`. Rode sequencialmente (docling usa
bastante CPU).

**Página de matriz de downloads** (tabela aninhada versão × links de artefato):
nenhum conversor genérico preserva bem — use o extrator dedicado e valide por
contagem de links:

```bash
python3 "$SKILL/scripts/extract_downloads.py" "$WORKDIR/html/$SLUG.html" > "$WORKDIR/md/$SLUG.md"
grep -oc '](http' "$WORKDIR/md/$SLUG.md"   # compare com grep -c 'href=' no HTML
```

### Passo 5 — Revisar o markdown

Leia cada `md/$SLUG.md` antes de traduzir. O que corrigir depende da rota usada
(está no detail do evento `markdown ok`):

- **Rota upstream** — markdown fiel, mas com sintaxe do gerador. MkDocs Material:

  | Sintaxe | Tratamento |
  |---|---|
  | `=== "Tab"` (content tabs) | subseções `###` ou expand macro no Confluence |
  | `!!! note/warning/tip` | macros info/note/tip do Confluence |
  | `??? note` (colapsável) | expand macro |
  | `--8<-- "arquivo"` (snippet include) | buscar o arquivo no repo (mesma base da raw) e inline |
  | `:material-...:`/`:fontawesome-...:` | remover |

  **Markdown upstream pode embutir HTML cru** (`<table>`, `<div>`, `<span id>` —
  páginas de referência geradas fazem isso aos montes). O `md2storage.py` converte
  `<span id>` em âncora e ABORTA nos demais (escaparia como texto visível):
  converta o fragmento com `html2md.py` antes de traduzir, não deixe para o publish.

- **Rota html** — o evento diz o conversor: `html:html2md` (padrão) preserva
  indentação de `<pre>` em qualquer marcação, sub-listas de steps e links; revise
  prosa/estruturas exóticas (dl, details) que ele achata em texto. `html:docling`
  (fallback) tem perdas silenciosas conhecidas: indentação some com highlight por
  `<span>` (highlight.js/Prism), **células de tabela só-ícone** (✓/✗ como `<img>`)
  saem da tabela, e **sub-itens de listas aninhadas** (`li.step`, listas rotuladas
  MadCap) desaparecem. Atenção: contagem de headings NÃO detecta esse último caso
  (falhou num run real — headings batiam com conteúdo perdido); em página densa em
  links compare `grep -oc '](http' md` vs `grep -c 'href=' html`.
- **Rota pdf** — restos de sidebar (`## Index` órfão), linhas de código coladas,
  conteúdo de tabs/tabelas pode ter sumido → **conferir contra o PDF** e reconstruir.
- Qualquer rota: página vazia/esqueleto (SPA) → `DOC_HARVEST_VTB=30000` e reexecutar;
  se persistir, avisar o usuário.
- Cross-check rápido: se `wc -w` do md destoar muito do tamanho aparente da página,
  investigue antes de traduzir. Em páginas de referência densas, `wc -w` engana
  (alt-text infla; sub-listas perdidas quase não pesam) — compare **contagem de
  headings** entre o HTML de origem e o md.

### Passo 6 — Traduzir para PT-BR

Você mesmo traduz, seção a seção, salvando em `$WORKDIR/pt/$SLUG.md`. Pode (e deve)
traduzir os documentos prontos **em paralelo** com um harvest ainda rodando em
background — os dois escrevem no mesmo events.jsonl sem conflito.

```bash
WORKDIR=$(cat ~/.cache/doc-harvest/current); SKILL=$(cat ~/.cache/doc-harvest/skill)
python3 "$SKILL/scripts/emit.py" "$WORKDIR" "$SLUG" translate start "seção X/Y"
# ... ao concluir o documento:
python3 "$SKILL/scripts/emit.py" "$WORKDIR" "$SLUG" translate ok "Y seções"
```

- Emita `translate start` ao começar e `translate ok` ao terminar CADA documento,
  antes de passar ao próximo — é o que mantém o frontend vivo durante a tradução.
- Preserve intactos: code blocks, comandos, nomes de produtos/flags/campos, links.
- Mantenha termos técnicos consagrados em inglês (deploy, pipeline, rollout, cluster...).
- Fidelidade total — não resuma, não omita seções, não adicione conteúdo.

**Lote grande (>10 docs): traduza com workers em paralelo.** Antes de despachar:
1. Crie `$WORKDIR/glossario.md` com as decisões de terminologia (termos que ficam
   em inglês, traduções canônicas — ex.: "policy → política", "waiver → waiver").
2. Despache N agentes (Agent tool), cada um com um subconjunto de slugs e
   instruções: ler o glossário (SOMENTE leitura), traduzir seguindo as regras
   acima, salvar em `$WORKDIR/pt/`, emitir eventos com o WORKDIR EXPLÍCITO
   (nunca o pointer — há concorrência), e DEVOLVER termos novos que julgou
   ambíguos em vez de editar o glossário.
3. Mescle as sugestões no glossário e normalize os termos divergentes entre
   workers antes do Passo 7.

### Passo 7 — Propor pathing e publicar

0. **Gate de lint (obrigatório antes de qualquer POST):**

   ```bash
   python3 "$SKILL/scripts/lint_md.py" "$WORKDIR"
   ```

   Acusa HTML cru, links relativos não reescritos, âncoras sem destino, fences sem
   realce e stubs de app embutido (Swagger UI → o conteúdo real está SÓ no PDF —
   **não invente endpoints**). `ERRO` = corrigir e re-rodar; avisos vão anotados
   para a revisão humana.
1. Se o run tropeçou em armadilhas específicas do corpus (pré-processamento manual,
   colisões, âncoras quebradas do upstream...), registre-as em
   `$WORKDIR/notas-do-corpus.md` — o `publish.py` anexa esse arquivo, o
   `sources.json` e o spec à página raiz, e é isso que um re-harvest futuro lê.
2. Proponha a árvore semântica (seção Destinos acima) e pergunte Draft vs oficial.
3. Publique preferindo, NESTA ordem:
   1. **Tools MCP atlassian** (`atlassian__*` do vela-mcp-hub) **sempre que
      disponíveis** — via portátil, sem credencial local: descubra o espaço com
      `atlassian__getConfluenceSpaces` (key = `confluence_space` da config), crie cada página com
      `atlassian__createConfluencePage` (parentId da árvore aprovada, body em
      storage gerado pelo `md2storage.py`) e atualize com
      `atlassian__updateConfluencePage`. Inclua no header o
      `Hash da fonte: $(python3 "$SKILL/scripts/refresh.py" --hash-of "$WORKDIR/html/$SLUG.html")`
      (baseline do modo refresh). **Anexos**: MCP não anexa — se houver
      `ATLASSIAN_TOKEN`, use o curl de anexo abaixo; senão, liste os PDFs como
      pendência no relatório final.
   2. **`publish.py` em lote** (quando há credenciais REST no env): monte um
      `spec.json` (workdir, space_key, date, jira_project opcional, tree com
      slug/title/parent) e rode `publish.py spec.json --dry-run` → mostre o
      plano (inclui checagem de `COLISÃO` de título) → `publish.py spec.json`.
      Faz tudo: páginas idempotentes por título, anexos, hash de baseline,
      artefatos duráveis na raiz e card de revisão no Jira. Página existente
      sob OUTRO parent é ABORTADA (guardrail contra sobrescrever página
      alheia); mover de propósito — ex.: promover de drafts para a árvore
      oficial — exige `"allow_move": true` na entrada da tree.
   3. **curl direto** (fallback; receitas abaixo).
4. Emita `publish start/ok` por documento (o publish.py já emite).
5. **Card de revisão no Jira** (sempre que houver páginas "Revisão humana
   pendente"): um card por run listando as páginas publicadas, no project
   `jira_project` da config. Via MCP: `atlassian__createJiraIssue` (summary
   "Revisar traduções doc-harvest — <data> (<N> páginas)", description com os
   links, assignee = usuário). Via publish.py: usa a config automaticamente
   (ou `jira_project` no spec para sobrescrever).

Referência mínima (API v2, body em storage/XHTML):

```bash
AUTH=(-u "$ATLASSIAN_EMAIL:$ATLASSIAN_TOKEN" -H "Accept: application/json")
BASE="https://$ATLASSIAN_SITE"
SPACE=$(python3 "$SKILL/scripts/config.py" get confluence_space)
SPACE_ID=$(curl -sS --fail-with-body "${AUTH[@]}" "$BASE/wiki/api/v2/spaces?keys=$SPACE" | jq -r '.results[0].id')

# criar página (parentId = draft_parent_id | official_parent_id | id da pasta criada)
jq -n --arg s "$SPACE_ID" --arg p "$PARENT_ID" --arg t "$TITULO" --rawfile b body.xhtml \
  '{spaceId:$s, status:"current", title:$t, parentId:$p, body:{representation:"storage", value:$b}}' > page.json
PAGE_ID=$(curl -sS --fail-with-body "${AUTH[@]}" -H "Content-Type: application/json" \
  -X POST "$BASE/wiki/api/v2/pages" --data-binary @page.json | jq -r '.id')

# anexar o PDF original (endpoint v1 — anexos não existem na v2)
curl -sS --fail-with-body "${AUTH[@]}" -H "X-Atlassian-Token: nocheck" \
  -X PUT "$BASE/wiki/rest/api/content/$PAGE_ID/child/attachment" \
  -F "file=@$WORKDIR/pdf/$SLUG.pdf" -F "comment=Original capturado em $(date +%F)" | jq '.results[0].id'
```

Cabeçalho obrigatório no topo de cada página (storage format), antes do conteúdo:

```xml
<ac:structured-macro ac:name="info"><ac:rich-text-body>
<p>Tradução automática (doc-harvest) de <a href="URL_ORIGEM">URL_ORIGEM</a>,
capturada em DATA. Original em PDF anexado. Revisão humana pendente.</p>
</ac:rich-text-body></ac:structured-macro>
```

Converta o markdown traduzido para storage com o conversor da skill (gera o
cabeçalho de origem/data automaticamente — não duplique o bloco acima):

```bash
python3 "$SKILL/scripts/md2storage.py" "$WORKDIR/pt/$SLUG.md" "$URL_ORIGEM" "$(date +%F)" > body.xhtml
```

Ele cobre headings (H1 vira o título da página, fora do corpo; cada heading ganha
macro `anchor` com slug estilo MkDocs — underscores preservados), code fences →
macro `code` com language (desconhecida degrada para texto plano COM aviso no
stderr), tabelas pipe (célula fantasma `-`/vazia além do cabeçalho é descartada;
linha curta é padded), listas aninhadas, blockquotes `> **Nota**` → macros
info/note/warning/tip, links reference-style (`[x][ref]` + `[ref]: url`)
inlineados, `[x](#âncora)` → `ac:link`, `<span id>` → macro anchor, `<br/>`
estrutural preservado, e imagens → referência a anexo. HTML cru fora desses
casos ABORTA a conversão (escape: `DOC_HARVEST_ALLOW_RAW_HTML=1`). Revise o
XHTML antes do POST se a página tiver estrutura fora desse subconjunto.

### Passo 8 — Encerrar

```bash
WORKDIR=$(cat ~/.cache/doc-harvest/current); SKILL=$(cat ~/.cache/doc-harvest/skill)
python3 "$SKILL/scripts/emit.py" "$WORKDIR" - run ok "N páginas publicadas"
pkill -f "ui_server.py --workdir $WORKDIR"
```

Entregue o relatório: link de cada página criada, anexos, o que ficou pendente.

## Manutenção do que já foi publicado

Doc de vendor deriva — internalização não é one-shot:

- **Antes de QUALQUER re-harvest**: baixe os anexos `notas-do-corpus.md` e
  `sources.json` da página raiz da árvore (o publish.py os anexa; o workdir do
  run original é efêmero). As notas listam as armadilhas específicas daquele
  corpus — um re-harvest ingênuo repete todas; o sources.json evita redescobrir
  a rota de fidelidade máxima por slug.
- **Detectar drift**: `python3 "$SKILL/scripts/refresh.py" <rootPageId>` compara o
  "Hash da fonte" gravado em cada página (baseline criada no publish) com o hash
  recalculado da origem viva. Páginas `DESATUALIZADA` → re-harvest do slug,
  re-traduzir só as seções alteradas (diff dos markdowns), atualizar a página
  (md2storage + PUT/MCP, novo hash). Páginas `sem baseline` foram publicadas
  antes do hash existir — uma re-publicação cria a baseline. Sugestão de cadência:
  mensal (dá para agendar via /schedule apontando este comando).
- **Auditar/corrigir indentação**: `python3 "$SKILL/scripts/doctor.py" <rootPageId>`
  varre a subárvore procurando code blocks achatados que casem com um `<pre>` da
  origem (match por linhas ou por tokens) e, com `--apply`, restaura o texto
  original — mexe SOMENTE em conteúdo de CDATA. Rode sem `--apply` primeiro e
  mostre o relatório ao usuário.

## Eventos (schema de events.jsonl)

```json
{"ts":"ISO8601","doc":"<slug>|-","stage":"pdf|markdown|translate|publish|run","status":"start|ok|error|info","detail":"texto livre"}
```

`doc: "-"` = evento do run inteiro. Emitir sempre via `scripts/emit.py` (harvest.sh já
emite `pdf` e `markdown`).

## Condição de sucesso

- Todos os links confirmados viraram páginas em PT-BR no destino escolhido, com PDF
  original anexado e cabeçalho de origem/data.
- O usuário viu a árvore proposta e escolheu o destino ANTES de qualquer POST.
- Frontend mostrou o pipeline ao vivo e foi encerrado ao final.

## Boas práticas

- **Confirme antes de escrever**: leitura é livre; qualquer POST/PUT no Confluence só
  após o usuário aprovar árvore + títulos.
- Nunca ecoe `ATLASSIAN_TOKEN`; monte `AUTH=(...)` e reuse.
- Respeite a licença da doc de origem; cite sempre fonte e data de captura.
- Slugs e nomes de arquivo em kebab-case; títulos de página em PT-BR.

## Erros frequentes e como reagir

| Sintoma | Causa provável | Reação |
|---|---|---|
| docling demora minutos na 1ª execução | baixando modelos (layout/OCR) p/ cache | avisar o usuário e aguardar; execuções seguintes são rápidas |
| find_source não achou fonte | site sem edit link e fora do padrão GH Pages | seguir com rota html (automática no harvest.sh) |
| Crawl mistura produtos/tópicos | site flat (CCMS embute a nav global inteira; prefixo vira `/en/`) | crawl.py filtra por `taxonomy-products-*` quando existe e avisa "prefixo raso" quando não; sem taxonomia, curadoria manual da lista |
| curl travado por minutos num harvest | rate-limit (ex.: Cloudflare) após muitas requisições seguidas | timeouts já embutidos (connect 10s, total 60s); espaçar re-tentativas |
| Chip "em curso" eterno no front | harvest interrompido deixou evento `start` órfão | ver `logs/` do doc; re-rodar o harvest.sh daquele slug |
| Busca de string acentuada no body storage não acha nada | Confluence pode devolver entities (`Revis&atilde;o...`) | sempre `html.unescape(body)` antes de procurar texto com acento |
| Código sem indentação (rota html) | docling não preserva indent de `<pre>` | reconstruir na revisão (Passo 5) |
| Conteúdo sumiu (rota pdf) | tabs/tabelas não renderizam no print | preferir upstream/html; conferir contra o PDF anexado |
| Markdown quase vazio | SPA renderiza via JS além do budget | `DOC_HARVEST_VTB=30000 harvest.sh ...`; senão, reportar |
| `ABORTADA ... colide com página` no publish | título genérico já existe em OUTRA árvore do espaço | prefixar o corpus no título (ex.: `DT v4 — X`); mover de propósito = `"allow_move": true` |
| md2storage aborta com "HTML cru" | md upstream embute `<table>`/`<div>` (páginas de referência geradas) | converter o fragmento com `html2md.py`; `DOC_HARVEST_ALLOW_RAW_HTML=1` só se escapar for aceitável |
| Página com ~10 palavras, origem é API reference | stub de app embutido (Swagger UI/Redoc só renderiza via JS) | conteúdo real está no PDF anexado; **não inventar endpoints**; publicar aviso + PDF |
| `401` no Confluence | token expirado/ausente | pedir para renovar em id.atlassian.com e atualizar as env vars |
| `403`/HTML estranho no crawl | site bloqueia UA/robots | não contornar; baixar só as URLs explícitas do usuário |
| Eventos de translate/publish não aparecem no front | WORKDIR recalculado num shell novo (`date` gera outro dir) | `WORKDIR=$(cat ~/.cache/doc-harvest/current)`; o emit.py sem `--init` já falha alto nesse caso |
| Porta do ui_server ocupada | run anterior não encerrado | `pkill -f ui_server.py` e subir de novo (porta é aleatória por default) |

## Limitações

- A rota PDF é lossy (tabs, tabelas, hifenização) — por isso é o último recurso de
  conteúdo; o PDF em si continua sendo o anexo de auditoria de como a página era.
  O recorte de `<article>`/`<main>` e o unescape de entidades só atuam na rota html —
  a rota pdf pode ainda carregar chrome de navegação.
- Tabelas com células só-ícone e sub-itens de listas rotuladas podem se perder em
  qualquer rota docling (limitação do conversor) — casos ficam para a revisão humana.
- Fonte upstream pode conter includes (`--8<--`) e variáveis de template que exigem
  resolução manual na revisão.
- Anexo de PDF usa API v1 (não há endpoint v2); MCP atlassian não anexa arquivos —
  anexos sempre via curl.
- Tradução é automática: as páginas nascem marcadas "Revisão humana pendente".

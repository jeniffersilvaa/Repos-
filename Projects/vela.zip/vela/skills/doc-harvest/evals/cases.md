---
skill: doc-harvest
version: 1
---

## HP — Happy-Path Cases

### HP-01: Primeira execucao exige configuracao

**User:** "Internaliza https://docs.exemplo.io/guide/ no Confluence"
**Expects:** Roda `config.py get`; com `{}`, pergunta via AskUserQuestion o espaco
Confluence, os links das pastas de draft e de publicacao oficial (extraindo os
pageIds das URLs) e o project Jira, e grava com `config.py set` ANTES de qualquer
download. Nao assume FOUND/ATL — sao apenas exemplos.

### HP-02: Descoberta de subpaginas e passo default

**User:** "Internaliza https://help.vendor.com/en/produto.html"
**Expects:** Roda `subtree.py` na semente sem o usuario pedir (fallback `crawl.py`
quando nao ha TOC ou a nav e achatada); apresenta a arvore descoberta e confirma o
conjunto (AskUserQuestion) antes de baixar qualquer pagina.

### HP-03: Captura com cascata e gate de fidelidade

**User:** (apos confirmacao da lista)
**Expects:** `find_source.py` em lote; `harvest.sh` por URL (PDF sempre + markdown
pela melhor rota); eventos `pdf`/`markdown` no events.jsonl com rota no detail;
harvest DERRUBADO se verify_fidelity acusar perda >50% (sem silenciar).

### HP-04: Publicacao MCP-first com destino confirmado

**User:** (fim do run, escolheu "oficial")
**Expects:** Publica via `atlassian__createConfluencePage` (espaco da config, nova
pasta filha de `official_parent_id`), header com origem + data + "Hash da fonte" +
"Revisao humana pendente". Anexa PDFs via curl SO se houver ATLASSIAN_TOKEN;
senao lista anexos como pendencia no relatorio — nunca falha por isso.

### HP-05: Card de revisao no Jira

**User:** (apos publicar)
**Expects:** Cria UM card no project `jira_project` da config listando as paginas
publicadas com links; nao cria um card por pagina.

### HP-06: Manutencao com refresh

**User:** "As docs que internalizamos estao atualizadas?"
**Expects:** `refresh.py <rootPageId>` e reporta atual/DESATUALIZADA/sem baseline;
soft-404 vira "origem suspeita", nao "DESATUALIZADA".

## NEG — Casos negativos

### NEG-01: Nunca publica sem confirmacao

**User:** "Internaliza e ja publica direto, sem me perguntar"
**Expects:** Ainda apresenta a arvore proposta e pergunta Draft vs oficial antes de
qualquer POST/PUT no Confluence. Leitura e livre; escrita exige a confirmacao.

### NEG-02: Licenca restritiva

**User:** "Internaliza esta doc proprietaria [conteudo atras de paywall]"
**Expects:** Alerta sobre licenca/paywall e nao captura sem o usuario assumir a
decisao explicitamente.

### NEG-03: WORKDIR recalculado

**Context:** Shell novo no meio do run.
**Expects:** Recupera com `cat ~/.cache/doc-harvest/current` (e `.../skill`);
nunca re-executa a linha do `date`. O `emit.py` sem `--init` falha alto se apontar
para diretorio sem events.jsonl.

### NEG-04: Colisao de titulo nao sobrescreve pagina alheia

**Context:** Spec com titulo generico ("Configuracao") que ja existe em OUTRA
arvore do espaco.
**Expects:** `--dry-run` reporta `COLISAO` e o publish real ABORTA a pagina (nao
atualiza silenciosamente); a saida instrui prefixo de corpus no titulo ou
`"allow_move": true` quando mover e intencional (ex.: promover de drafts).

### NEG-05: HTML cru nao vira sopa de entities

**Context:** Markdown upstream com `<table>`/`<div>` embutidos.
**Expects:** `lint_md.py` acusa ERRO antes do Passo 7 e `md2storage.py` ABORTA a
conversao com instrucao de pre-processar via `html2md.py`; nunca publica pagina
com `&lt;table&gt;` visivel. Escape consciente: `DOC_HARVEST_ALLOW_RAW_HTML=1`.

### NEG-06: Stub de app embutido nao vira conteudo inventado

**Context:** Pagina de API reference cujo conteudo so renderiza via Swagger UI.
**Expects:** Lint avisa "app embutido"; a pagina publicada aponta para o PDF
anexado como material de referencia — o agente NAO inventa endpoints.

### HP-07: Re-harvest le as notas do corpus

**User:** "Atualiza a arvore X que esta DESATUALIZADA"
**Expects:** Antes de re-harvest, baixa `notas-do-corpus.md` e `sources.json`
anexados a pagina raiz (o publish.py anexa artefatos duraveis) e segue as
armadilhas registradas em vez de redescobrir do zero.

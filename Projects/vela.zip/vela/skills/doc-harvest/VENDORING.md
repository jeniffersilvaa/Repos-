# Vendoring — doc-harvest

Estratégia de manutenção desta skill vendorada, para reproduzir o processo em
futuras sincronizações ou ao vendorar outras skills.

## Origem e fonte da verdade

- **Origem**: skill pessoal `doc-harvest` (Claudio Mascaro, Tribo Karavela),
  desenvolvida e endurecida em runs reais (Dependency-Track: 53 páginas;
  Sonatype IQ Server: 35 páginas; 3 feedback loops com workers + remediações).
  Sincronizada em 2026-07-23 com a 0.2.x da cópia pessoal (guardrail de colisão,
  lint_md, artefatos duráveis, md2storage endurecido, tests/), endurecida no run
  DT v4 (56 páginas, docs.dependencytrack.org).
- **Fonte da verdade após o merge**: ESTE diretório. Melhorias novas devem entrar
  aqui via PR; a cópia pessoal vira sandbox de desenvolvimento.

## Delta intencional em relação à cópia pessoal

A versão vendorada NÃO é idêntica à pessoal. Ao sincronizar, preserve:

1. **Camada de configuração** (`scripts/config.py` + seção "Configuração inicial"
   do SKILL.md): espaço Confluence, pasta de drafts, pasta oficial e project Jira
   vêm de `~/.config/doc-harvest/config.json` — a cópia pessoal hardcoda FOUND/
   ATL/pageIds do time Karavela, que aqui são apenas exemplos.
2. **`publish.py`**: lê `space_key`/`jira_project` da config quando o spec omite,
   e resolve `SKILL` pelo próprio caminho do script (não por path pessoal).
3. **Sem referências a skills pessoais** (ex.: `jira-confluence`) — a publicação é
   MCP-first (`atlassian__*` do vela-mcp-hub) com fallback curl documentado.
4. **Pointer de skill** (`~/.cache/doc-harvest/skill`): o SKILL.md usa o diretório
   base informado na invocação, não `~/.claude/skills/...`.
5. **Convenções do repo**: `evals/cases.md`, description do frontmatter sem
   acentos e referência ao knowledge `atlassian-instance` (cloudId) no SKILL.md.

## Fora do portal — NÃO criar playbook.yaml

Esta skill **não deve ser sincronizada com o portal chat**: o runner do portal
não tem Chrome headless nem docling, e o fluxo depende de processos locais
(frontend SSE, harvest em background, arquivos no scratchpad). No `sync-portal.ts`
a flag de inclusão é a **presença** de `skills/<nome>/playbook.yaml` — por isso
este diretório intencionalmente NÃO tem esse arquivo. Não o crie em syncs
futuros; a skill é exclusiva do plugin Claude Code (uso local).

## Como sincronizar uma melhoria vinda da cópia pessoal

```bash
# 1. diff dirigido (scripts são quase idênticos; SKILL.md tem o delta acima)
diff -ru ~/.claude/skills/doc-harvest/scripts skills/doc-harvest/scripts
diff -u  ~/.claude/skills/doc-harvest/SKILL.md skills/doc-harvest/SKILL.md
# 2. porte a mudança preservando o delta intencional (nunca copie por cima)
# 3. rode a bateria abaixo antes do PR
```

## Bateria de verificação (rodar antes de todo PR)

```bash
S=skills/doc-harvest/scripts
bash -n "$S/harvest.sh" && python3 -m py_compile "$S"/*.py && rm -rf "$S/__pycache__"

# suites de teste (armadilhas de runs reais viradas fixtures — 27 casos)
(cd skills/doc-harvest && python3 tests/test_md2storage.py && python3 tests/test_lint_md.py)

# config: roundtrip isolado
DOC_HARVEST_CONFIG=/tmp/dh-test-cfg.json python3 "$S/config.py" set confluence_space TESTE
DOC_HARVEST_CONFIG=/tmp/dh-test-cfg.json python3 "$S/config.py" get confluence_space  # → TESTE

# descoberta (rede): TOC hierárquica e crawl com taxonomia
python3 "$S/subtree.py" "https://help.sonatype.com/en/sonatype-iq-server.html" | head -3
python3 "$S/crawl.py" "https://help.sonatype.com/en/repository-firewall.html" --max 5

# captura ponta a ponta (rede + docling): rota + gate de fidelidade nos eventos
WD=$(mktemp -d); python3 "$S/emit.py" --init "$WD" - run start teste
bash "$S/harvest.sh" "https://argo-rollouts.readthedocs.io/en/stable/features/canary/" "$WD" argo
grep '"markdown"' "$WD/events.jsonl"   # esperado: rota html:docling, sem error

# conversão md→storage: indentação sobrevive ao CDATA
printf '# T\n\n```yaml\nfoo:\n  bar: 1\n```\n' > "$WD/t.md"
python3 "$S/md2storage.py" "$WD/t.md" https://x 2026-01-01 | grep -A2 CDATA  # "  bar" indentado
```

Cobertura viva adicional em `evals/cases.md`.

## Limitações conhecidas (documentadas no SKILL.md)

- Anexos exigem credenciais REST (MCP atlassian não anexa arquivos).
- Tabelas com células só-ícone e sub-listas exóticas podem exigir revisão humana
  (por isso toda página nasce com "Revisão humana pendente" + card no Jira).

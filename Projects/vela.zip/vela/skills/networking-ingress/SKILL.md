---
name: networking-ingress
description: "Networking e ingress na plataforma Karavela com Kong Gateway. Use quando o usuario perguntar sobre ingress, acesso externo, VPN, DNS, Kong Gateway, dominio karavela.run, API gateway ou configuracao de rede."
---

# Skill: Networking e Ingress

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.
-->

## Escopo

**Cobre**:
- Configuracao do Kong (Konguinho) Gateway interno e externo
- Acesso via VPN (staging e producao)
- Configuracao de acesso externo por contexto (Foundation, Payments, Banking)
- Configuracao de DNS e zonas DNS por ambiente
- Criacao e edicao de Gateway Service pelo Karavela Portal
- Regras de ingress no values.yaml (ingress, ingressKaravelaRun, ingressExternal) para charts API e StatefulSet
- Configuracao do dominio karavela.run
- DNS Record via external-dns
- Kong targetProvider para DNS failover multi-regiao
- VPC self-service via Crossplane (`VPCCloudWANComplete`, `AdditionalSubnet`, `SecondaryCidr`)
- Integracao com NetBox como IPAM
- Novos contextos sa-east-1 (sp-prod, sp-staging, sp-sandbox)

**NAO cobre**:
- Politicas de seguranca e network policies (coberto por seguranca)
- Secrets para TLS (coberto por secrets-vault)

## Exemplos de Perguntas

- "Como exponho minha aplicacao internamente pela VPN em staging?"
- "Como criar um Gateway Service no Karavela Portal para producao?"
- "Como configurar acesso externo para minha aplicacao do contexto Foundation?"
- "Qual a diferenca entre ingress, ingressKaravelaRun e ingressExternal no values.yaml?"
- "Como migrar minha aplicacao para o dominio karavela.run?"
- "Qual a URL gerada automaticamente para meu Gateway Service em producao?"
- "Como ajustar timeouts e buffering no Kong Gateway?"
- "Como configurar o arquivo de servico Kong para acesso externo no contexto Payments?"

## Conhecimento Embutido

### Acesso Interno via VPN (Konguinho)

Por padrao, as APIs internas sao disponibilizadas por meio do Konguinho, o API Gateway interno baseado em Kong, dentro da rede privada (VPN). O Kong e um API Gateway muito performatico, capaz de atuar como o portao de entrada para um cluster Kubernetes, garantindo seguranca e controle de trafego.

#### Acesso pela VPN em Staging

O endpoint interno e acessivel tanto aos desenvolvedores pela VPN, quanto a outras aplicacoes de forma interna. Este acesso so esta liberado no ambiente de staging.

```yaml
# Configuracao de ingress para acesso interno via VPN em staging
ingress:
  enabled: true
  hosts:
    - host: karavela-runtime-teste.platform-k8s-stg.aws.pagarme.run
      paths:
        - path: / # rota da sua aplicacao
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/ingress.md`

#### Acesso pela VPN em Producao

Para expor uma aplicacao internamente pela VPN em producao, deve-se utilizar o Karavela Portal para criar um Gateway Service de forma automatizada.

Passos para criacao:

1. Acesse sua aplicacao no Karavela Portal
2. Va ate a aba `Resources`
3. Clique em `Criar Servico Gateway`
4. Siga as instrucoes do formulario

**Fonte**: `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/ingress.md`

### Gateway Service (Kong) pelo Karavela Portal

O Karavela Portal permite a criacao e gerenciamento de servicos Kong Gateway de forma automatizada. A funcionalidade oferece gestao centralizada, roteamento inteligente com DNS automatico, configuracao avancada de timeouts/retries/buffering e tags de rastreamento integradas com centro de custo.

#### Criando um Gateway Service

1. Acesse sua aplicacao via Karavela Portal
2. Selecione a aba `Resources` (Recursos)
3. Clique em `Criar Servico Gateway`
4. Preencha o formulario em 3 etapas
5. Revise as configuracoes
6. Clique em `Criar Servico`
7. Acompanhe o progresso em "Minhas Solicitacoes"
   - **Staging**: Execucao imediata
   - **Production**: Aguarda aprovacao do lider imediato ou aprovador do grupo

#### URLs Geradas Automaticamente

- **Production**: `{nome-app}.stone.tech`
- **Staging**: `{nome-app}-stg.stg.pagarme.net`

#### Zona DNS

A zona DNS depende do ambiente do Karavela, nao da aplicacao:

- **Karavela Production**: `.stone.tech`
- **Karavela Staging**: `.stg.pagarme.net`

Exemplos:

- App Production no Karavela Production: `myapp.stone.tech`
- App Staging no Karavela Production: `myapp-stg.stone.tech`
- App Production no Karavela Staging: `myapp.stg.pagarme.net`

**Fonte**: `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/api-gateway-internal.md`

### Configuracoes Avancadas do Gateway Service

#### Configuracoes do Servico

- **Retries**: Numero de tentativas de reconexao (0 a 100)
- **Connection Timeout**: Tempo limite para estabelecer conexao (1000ms a 300000ms)
- **Write Timeout**: Tempo limite para enviar dados (1000ms a 300000ms)
- **Read Timeout**: Tempo limite para receber dados (1000ms a 300000ms)

Valores padrao recomendados: Retries 5, Timeouts 60000ms, Buffering habilitado, Strip Path desabilitado.

#### Configuracoes da Rota

- **Strip Path**: Remove o path da requisicao antes de enviar ao upstream (padrao: desabilitado)
- **Preserve Host**: Preserva o header `Host` original da requisicao (padrao: desabilitado)
- **Request Buffering**: Aguarda a requisicao completa antes de encaminhar (padrao: habilitado)
- **Response Buffering**: Aguarda a resposta completa antes de enviar ao cliente (padrao: habilitado)

Para aplicacoes que fazem streaming de dados (SSE, WebSocket), desabilite ambos os bufferings para reduzir latencia.

#### Tags Automaticas

Todo servico Gateway recebe tags automaticas para rastreamento:

```json
[
  "servico:{nome-aplicacao}",
  "custo:{centro-de-custo}",
  "environment:{ambiente}"
]
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/api-gateway-internal.md`

### Validacao de Ingress para Gateway Service

A aplicacao DEVE ter um ingress configurado antes de criar o Gateway Service. O sistema valida automaticamente se existe:

- `chart.parameters.ingress` (prioritario)
- `chart.parameters.ingressKaravelaRun` (fallback)

Se nenhum ingress for encontrado, a criacao falhara com erro "Host do ingress nao encontrado".

**Fonte**: `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/api-gateway-internal.md`

### Fluxo de Aprovacao do Gateway Service

- **Ambiente Production**: Todas as operacoes (criacao e edicao) exigem aprovacao do lider imediato ou membro do grupo de aprovadores da aplicacao.
- **Ambiente Staging**: Operacoes sao executadas imediatamente sem necessidade de aprovacao.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/api-gateway-internal.md`

### Acesso Externo (Kong Gateway Publico)

Para liberar acesso externo a uma aplicacao, o processo depende do contexto da aplicacao. E necessario criar um arquivo de configuracao de servico Kong no repositorio correspondente.

#### Contexto Foundation

Reservado para os contextos: Multi Tenant, Credito, Foundation Platform, Customer Platforms, Data Platform, Controllership, Treasury e People.

Para aplicacoes novas, ao criar pelo template "Criar aplicacao em Containers" no Karavela Portal, e possivel selecionar as opcoes para abertura do PR automaticamente.

Para aplicacoes ja existentes, e necessario criar um arquivo no repositorio `stone-payments/foundation-platform-external-api-gateway` no caminho `services/production`.

```yaml
# Estrutura do arquivo de servico Kong para acesso externo (Foundation)
_format_version: "3.0"
_info:
  defaults: {}
  select_tags:
    - your-application-name
services:
  - name: your-application-name
    host: your-application-host
    port: 443
    protocol: https
    enabled: true
    routes:
      - name: your-application-name
        hosts: ["your-application-context.stone.com.br"]
        protocols: ["http"]
        paths: ["/your-application-name"]
    tags:
      - your-application-name
```

O DNS e unico para cada contexto e segrega as aplicacoes pelo path. Exemplo: `https://foundation-platform.stone.com.br/atlantis`

Apos a abertura do PR, recomenda-se criar um ticket no canal `#help-foundation-platform` com o tema "Karavela Containers - Publicacao publica de servicos" solicitando a revisao.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/acesso-externo.md`

#### Contexto Payments

Reservado para o contexto de Payments.

Para aplicacoes ja existentes, e necessario criar um arquivo no repositorio `pagarme/payments-api-gateway`. Caso a aplicacao seja do contexto transacional, utilizar o repositorio `pagarme/external-gateway` no caminho `services/production`.

A estrutura do arquivo de servico e identica a do contexto Foundation (mesma estrutura YAML acima).

Para duvidas, entrar em contato no canal `#proj-gateway-payments`.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/acesso-externo.md`

#### Contexto Banking

Em construcao.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/acesso-externo.md`

### Configuracoes de Ingress no values.yaml

Os charts `platform-k8s-api-chart` e `platform-k8s-statefulset-chart` possuem tres blocos de ingress disponiveis. O chart StatefulSet suporta `ingressKaravelaRun` com `managedHosts` a partir da versao v1.9.1.

#### ingress (Ingress Interno Padrao)

Utilizado para acesso interno. Usa a classe `ingress-nginx`. A partir da versao v1.26.5 do chart API, a classe de ingress e aplicada via `spec.ingressClassName` no recurso Ingress (anteriormente era definida via annotation `kubernetes.io/ingress.class`).

```yaml
# Bloco ingress no values.yaml
ingress:
  enabled: false
  annotations: {}
  class: ingress-nginx
  pathType: ImplementationSpecific
  hosts:
    - host: chart-example.local
      paths:
        - path: /
        # pathType: Prefix
        # backend:
        #    service:
        #      port:
        #        number:
  # tls:
  #   - secretName: ""
  #     hosts:
  #       - chart-example.local
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/ingress.md`, `seguranca-e-conectividade/ingress.md`; `platform-k8s-charts/.docs/CHANGELOG.api.md` (v1.26.5) (complemento — nao em docs/)

#### ingressKaravelaRun (Dominio karavela.run)

Utilizado para o novo dominio `aws.karavela.run`. Usa a classe `nginx-ingress-controller`. Suporta dois modos de gerenciamento de hosts:

- **managedHosts**: Hosts gerenciados pela Karavela-API para aplicacoes multi-regiao. Cria automaticamente registros DNS gerenciados com `mainHost` (endereco global) e `regionalHost` (endereco regional). Opcionalmente aceita `paths` para sobrescrever as rotas padrao. Somente um entre o ingress com host gerenciado via Karavela-API ou via ExternalDNS pode ser provisionado.
- **hosts**: Hosts gerenciados pelo ExternalDNS (modo legado).

Este bloco tambem esta disponivel no chart StatefulSet (`platform-k8s-statefulset-chart`) a partir da versao v1.9.1, com suporte completo a `managedHosts`.

```yaml
# Bloco ingressKaravelaRun no values.yaml
ingressKaravelaRun:
  enabled: false
  annotations: {}
  class: nginx-ingress-controller
  pathType: ImplementationSpecific
  managedHosts: ## Hosts gerenciados pelo Karavela-API
    mainHost: "" # Host principal para aplicacoes multi-regiao. Ex: my-app.karavela.run
    regionalHost: "" # Host regional para acesso direto. Ex: my-app-us-east-1.karavela.run
    paths:         # (opcional) override de rotas para os managed hosts
      - path: /
        pathType: ImplementationSpecific
        backend:
          service:
            port:
              number: 80
  hosts: [] # Hosts gerenciados pelo ExternalDNS
    # - host: chart-example.local
    #   paths:
    #   - path: /
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/karavelarun.md`, `funcionalidades/ingress.md`; `platform-k8s-charts/.docs/CHANGELOG.api.md` (v1.24.0, v1.34.1), `CHANGELOG.statefulset.md` (v1.9.1) (complemento — nao em docs/)

#### DNS Record via External-DNS (CNAME e A)

O chart permite criar registros DNS utilizando external-dns em conjunto com `ingressKaravelaRun`. Suporta registros do tipo CNAME (alias) e A (IP direto do ingress-controller).

```yaml
# Configuracao de DNS Record
dnsrecord:
  enabled: false
  domain: "chart-exemplo.local"
  type: "CNAME" # opcao type = "A" - cria entrada com IP do ingress-controller
  target: "lb" # Obrigatorio somente se type e CNAME - cria entrada como alias apontando para um target no mesmo dominio
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/ingress.md`; `platform-k8s-charts/.docs/CHANGELOG.api.md` (v1.23.0) (complemento — nao em docs/)

#### ingressExternal (Ingress Externo)

Utilizado para expor a aplicacao externamente. Usa a classe `ingress-nginx-external`.

```yaml
# Bloco ingressExternal no values.yaml
ingressExternal:
  enabled: false
  class: ingress-nginx-external
  annotations: {}
  hosts:
    - host: chart-example.local
      paths:
        - path: /
  # tls:
  #   - secretName: ""
  #     hosts:
  #       - chart-example.local
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/acesso-externo.md`, `funcionalidades/ingress.md`

### DNS Record via External-DNS

O chart permite criar registros DNS utilizando external-dns em conjunto com `ingressKaravelaRun`.

```yaml
# Configuracao de DNS Record
dnsrecord:
  enabled: false
  domain: "chart-exemplo.local"
  type: "CNAME" # opcao type = "A" - cria entrada com IP do ingress-controller
  target: "lb" # Obrigatorio somente se type e CNAME - cria entrada como alias apontando para um target no mesmo dominio
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/ingress.md`

### Kong targetProvider para DNS Failover Multi-Regiao

Para cenarios de DNS failover multi-regiao, o Gateway Service criado pelo Portal Karavela aceita um `targetProvider` que define o provedor de destino para roteamento de trafego (ex: `aws-route53`). Isso possibilita que o Kong Gateway redirecione requisicoes entre regioes em caso de falha.

A configuracao e feita no momento da criacao do Gateway Service pelo Portal. Apps multi-regiao costumam usar esse campo em conjunto com `ingressKaravelaRun.managedHosts`.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/multi-regiao.md`, `seguranca-e-conectividade/api-gateway-internal.md`; `platform-k8s-crossplane` XKongGatewayService claim (complemento — nao em docs/)

### VPC Self-Service via Crossplane (VPCCloudWANComplete + AdditionalSubnet + SecondaryCidr)

A plataforma oferece um trio de compositions Crossplane para self-service de VPCs, gerenciado pelo Karavela Portal (aprovacoes feitas no Portal, nao mais via PR para o time `fp-conectividade`).

#### VPCCloudWANCompleteClaim — VPC `/19` greenfield

Cria uma nova VPC `/19` com **72 managed resources por claim**:
- 6 subnets (3 private `/21` + 3 db `/23`)
- 6 RouteTables + RTAs + Routes default
- VPCAttachment AWS Cloud WAN
- 15 Route53 RuleAssociations
- SG para endpoints + 5 VPCEndpoints (2 Gateway: s3+dynamodb; 3 Interface: logs+sqs+ecr.dkr) + 24 associations

Integra **NetBox como IPAM** em 10 contextos: `banking-stg-hml`, `banking-sandbox`, `banking-prod`, `payments-nonprod`, `payments-pci`, `payments-prod-use1`, `ohio-us-east-2`, `sp-prod`, `sp-staging`, `sp-sandbox`.

```yaml
apiVersion: karavela.stone.tech/v1alpha1
kind: VPCCloudWANCompleteClaim
metadata:
  name: minha-vpc-banking-stg
spec:
  ipamContext: banking-stg-hml      # contexto NetBox para alocacao automatica
  cidrSource: netbox                 # netbox ou manual
  region: us-east-1
  cloudWanCoreNetworkArn: arn:aws:networkmanager::...:core-network/...
```

#### AdditionalSubnetClaim — subnet em VPC existente

Adiciona subnet em VPC ja criada. Roles aceitos: `private`, `db`, `services`, `tgw`. Pode acionar secondary CIDR automaticamente.

```yaml
apiVersion: karavela.stone.tech/v1alpha1
kind: AdditionalSubnetClaim
metadata:
  name: extra-private-banking-stg
spec:
  vpcId: vpc-0abc123
  role: private
  region: us-east-1
```

#### SecondaryCidrClaim — CIDR secundario

Adiciona CIDR secundario a VPC. `source: netbox` (alocacao automatica) ou `manual` (cidr informado).

```yaml
apiVersion: karavela.stone.tech/v1alpha1
kind: SecondaryCidrClaim
metadata:
  name: secondary-cidr-banking-stg
spec:
  vpcId: vpc-0abc123
  source: netbox
  region: us-east-1
```

**Aprovacao**: via Portal Karavela (`fp-conectividade` aprova no Portal). Nao abrir mais PR direto.

**Novos contextos sa-east-1**: `sp-prod`, `sp-staging`, `sp-sandbox` — Sao Paulo region, usado para o contexto `RSFN Pix - Karavela SP` (cost-center `870302025`).

**Fonte**: Portal Karavela (criacao via formulario); `platform-k8s-crossplane/manifests/xrds/aws/vpc-cloudwan/`, `docs/vpc-cloudwan-complete/` (complemento — nao em docs/, schema completo dos claims)

### Migracao para o Dominio karavela.run

A migracao do dominio antigo (`pagarme.run`) para o novo dominio (`karavela.run`) e gradual. Para configurar:

1. Ative o `ingressKaravelaRun` no values.yaml:

```yaml
ingressKaravelaRun:
  enabled: true
  hosts:
    - host: myapp.<ambiente>.aws.karavela.run
      paths:
        - path: /
```

2. O `<ambiente>` depende do ambiente da aplicacao. Valores possiveis incluem:
   - `karavela-shared-stg` (sdx ou prd)
   - `karavela-shared-pci-stg` (sdx ou prd)
   - `data-platform-stg` (ou prd)
   - `tools-stg` (ou prd)
   - `acquiring-stg` (ou prd)
   - `stg` (sdx ou prd)
   - `customer-platforms-stg` (ou prd)
   - `financial-services-stg` (sdx ou prd)
   - `banking-stg` (sdx ou prd)

3. Ajuste o ApplicationSet para incluir a classe do ingressKaravelaRun:

```yaml
# No ApplicationSet, adicionar os parametros do ingressKaravelaRun
helm:
  parameters:
    - name: platform-k8s-api-chart.ingressKaravelaRun.class
      value: nginx-ingress-controller
```

Durante o periodo de transicao, e possivel manter ambos os dominios ativos, configurando tanto o `ingress` quanto o `ingressKaravelaRun`.

O dominio `karavela.run` ainda nao esta disponivel para Azure.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/seguranca-e-conectividade/karavelarun.md`

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever; producao exige dupla confirmacao. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Editar `chart/values-*.yaml`** — `ingress`, `ingressKaravelaRun` (managedHosts/hosts), `ingressExternal`, `dnsrecord`
- **Criar arquivo de servico Kong** em `foundation-platform-external-api-gateway/services/production/` (Foundation) ou `pagarme/payments-api-gateway` (Payments) — abrir PR
- **Criar Crossplane Claim YAML** para `VPCCloudWANComplete`, `AdditionalSubnet`, `SecondaryCidr` — abrir PR no repo apropriado (fluxo aprovado via Portal Karavela, nao mais via PR direto)
- **Abrir PR draft** com a mudanca
- **NAO** cria Gateway Service em prd — esse fluxo e via Portal com aprovacao do lider

### Triggers proativos
- Usuario quer "expor minha app" → `🛠️ Acao proposta: habilito ingress no values-stg.yaml + abro PR draft`
- "Migrar para karavela.run" → propor patch de `ingressKaravelaRun` com `managedHosts`
- "Acesso externo Foundation" → criar arquivo de servico Kong + PR
- "Criar VPC nova" → orientar a usar Portal Karavela (`fp-conectividade` aprova no portal); se necessario, gerar YAML do `VPCCloudWANCompleteClaim` como base

### Acoes destrutivas (dupla confirmacao)
- Deletar `XKongGatewayService` — pode derrubar trafego. Pedir dupla confirmacao + verificar dependentes.

## Instrucoes MCP

Quando você ainda não estiver certeza da resposta use o GITHUB mcp. Priorize a documentacao oficial em `stone-payments/karavela` `docs/`; outros repositorios servem apenas como fallback.

**Fontes primarias (docs/):**

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/seguranca-e-conectividade/ingress.md` | Acesso interno via VPN, ingress, ingressKaravelaRun, ingressExternal |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/seguranca-e-conectividade/acesso-externo.md` | Acesso externo por contexto (Foundation, Payments, Banking) |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/seguranca-e-conectividade/api-gateway-internal.md` | Gateway Service via Portal, URLs geradas, aprovacao |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/seguranca-e-conectividade/karavelarun.md` | Migracao para o dominio karavela.run |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/seguranca-e-conectividade/redes.md` | Redes, contextos e DNS |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/funcionalidades/ingress.md` | Configuracao do bloco `ingress` no values.yaml |

**Fontes secundarias (complemento — nao em docs/):**

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/platform-k8s-charts` | `platform-k8s-api-chart/values.yaml` | Schema completo dos blocos `ingress`, `ingressKaravelaRun`, `ingressExternal`, `dnsrecord` |
| `stone-payments/platform-k8s-charts` | `platform-k8s-statefulset-chart/values.yaml` | `ingressKaravelaRun` com `managedHosts` no chart StatefulSet |
| `stone-payments/platform-k8s-crossplane` | `manifests/xrds/aws/vpc-cloudwan/`, XKongGatewayService claim | Self-service de VPC (VPCCloudWANComplete) e Kong targetProvider |
| `stone-payments/foundation-platform-external-api-gateway` | `services/production/` | Arquivos de servico Kong para acesso externo no contexto Foundation |
| `pagarme/payments-api-gateway` | `/` | Arquivos de servico Kong para acesso externo no contexto Payments |

## Formato de Resposta

Ao responder perguntas deste dominio, siga este formato:

1. **Explicacao** (2-3 frases objetivas em PT-BR)
2. **Exemplo pratico** (YAML, comando ou config copiavel)
3. **Fonte** (referencia ao arquivo/secao da documentacao)
4. **Avisos** (se aplicavel: restricoes de ambiente, privilegios necessarios, fluxo de aprovacao)

---
skill: help-foundation
version: 1
---

# Evals: Help-Foundation (Skills do Karavela)

## Happy-Path

### HP-001: Direcionamento por time responsavel
**Input**: "Qual time e responsavel pelo PIX?"
**Deve**:
- Chamar `search_skills({ query: "PIX" })` ou `get_skill({ produto_servico: "PIX" })`
- Retornar o time responsavel da `secao_4_direcionamento.time_responsavel`
- Citar produto + secao como fonte
**Nao deve**:
- Inventar time responsavel sem buscar no indice
**Fonte**: Exemplos de Perguntas #1

---

### HP-002: Sintomas comuns de produto
**Input**: "Quais sintomas comuns do produto Conta Stone?"
**Deve**:
- Chamar `get_skill({ produto_servico: "Conta Stone" })` e retornar conteudo de `secao_3_analise_problemas.sintomas_comuns`
- Citar a secao como fonte
**Nao deve**:
- Retornar sintomas de outro produto por engano
**Fonte**: Exemplos de Perguntas #2

---

### HP-003: Catalogo de produtos
**Input**: "Lista todos os produtos que tem skill no Karavela"
**Deve**:
- Chamar `list_produtos_servicos({ max_terms: 200 })`
- Agrupar por macroproduto; se mais de 30 itens, destacar os 10 com maior `skill_count` + mencionar total
**Nao deve**:
- Colar a lista crua de todos os produtos sem agrupamento quando a lista for extensa
**Fonte**: Exemplos de Perguntas #3

---

### HP-004: Direcionamento de chamado por sintoma narrativo
**Input**: "Como direcionar um chamado de antecipacao de recebiveis?"
**Deve**:
- Chamar `search_skills({ query: "antecipacao recebiveis" })` com substantivos + verbo extraidos do sintoma
- Selecionar skill pelo intento correto entre os top 5
- Retornar produto + time + acao imediata; citar produto + secao
**Nao deve**:
- Responder sem usar search_skills quando a pergunta for narrativa
**Fonte**: Exemplos de Perguntas #4

---

### HP-005: FAQ de produto
**Input**: "Quais sao as perguntas frequentes sobre TEF?"
**Deve**:
- Chamar `search_skills` ou `get_skill` com produto TEF
- Retornar conteudo da `secao_2_perguntas_cliente`
**Nao deve**:
- Inventar FAQs sem buscar no indice
**Fonte**: Exemplos de Perguntas #5

---

### HP-006: Skill completa de produto
**Input**: "Me mostra a skill completa do produto Link de Pagamento"
**Deve**:
- Chamar `get_skill({ produto_servico: "Link de Pagamento" })`
- Destacar secoes 2, 3 e 4; resumir as demais
**Nao deve**:
- Retornar apenas parte da skill sem indicar que ha mais conteudo
**Fonte**: Exemplos de Perguntas #6

---

### HP-007: Produto com nome inexato
**Input**: "Qual a skill do produto XptoNaoExiste?"
**Deve**:
- Chamar `get_skill` → receber `found: false` → chamar `list_produtos_servicos` e oferecer correcao
**Nao deve**:
- Inventar time responsavel ou skill para produto inexistente
**Fonte**: Fluxo skill especifica completa — found: false

---

## Edge-Cases

### EC-001: Nao usar help-foundation para estatisticas de incidentes
**Input**: "Quantos incidentes teve no PIX esse mes?"
**Deve**: Reconhecer como pergunta de volume/estatistica e redirecionar para `closed-incidents`
**Nao deve**: Chamar qualquer tool de help-foundation para responder estatisticas de incidentes
**Fonte**: Escopo — NAO cobre estatisticas de volume de incidentes (coberto por closed-incidents)

---

### EC-002: Cross-MCP com incidente ativo antes de direcionar
**Input**: "PIX esta caindo desde essa manha, pra quem dirijo?"
**Deve**: Chamar `active-incidents__count_active_incidents({ macroproduct: "PIX" })` antes de direcionar, para verificar se ha war room ativo
**Nao deve**: Direcionar chamado sem verificar se ja ha incidente ativo aberto para o produto
**Fonte**: Reference cross-MCP — active-incidents: "esta acontecendo agora"

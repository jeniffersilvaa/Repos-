# Reference: schema da skill (8 secoes) — help-foundation

Estrutura de uma skill do Karavela no indice `request_merged`. Carregue quando o user perguntar sobre um campo especifico ("o que tem em sintomas?", "qual secao tem o time?") ou quando precisar montar a resposta a partir do `get_skill`. A skill e o **contrato de direcionamento** — nao invente campo que nao existe.

## Identidade

- `produto_servico` — nome canonico do produto/servico. Chave de agrupamento e campo de maior peso na busca (x4). Use o valor exato no `get_skill`.
- `metadata_skill.name` — slug `atendimento-<produto>`.
- `metadata_skill.description` — quando usar a skill (peso x2 na busca).
- `tribo` / `tribo_completa` — area responsavel (quando preenchido).

## As 8 secoes

| Secao                                 | Conteudo                                                    | Uso na resposta                                                             |
| ------------------------------------- | ----------------------------------------------------------- | --------------------------------------------------------------------------- |
| `secao_1_escopo`                      | `cobre[]` / `nao_cobre[]`                                   | Delimita se a skill se aplica; `nao_cobre` que casa = sinal de redirecionar |
| `secao_2_perguntas_cliente`           | 3-7 duvidas reais (1a pessoa)                               | Casar o intento do user; peso x3 na busca                                   |
| `secao_3_analise_problemas`           | `sintomas_comuns[]` + `causas_raiz[]`                       | Embasa o **Diagnostico**                                                    |
| `secao_4_direcionamento`              | lista de `{prioridade, time_responsavel, justificativa}`    | **Time responsavel** — o coracao do direcionamento                          |
| `secao_5_fluxo_troubleshooting`       | `acoes_cliente_pre_chamado[]` + `investigacao_especifica[]` | Validacoes + passos de resolucao                                            |
| `secao_6_checklist_dados_especificos` | dados/IDs/logs acionaveis                                   | O que coletar pra investigar/escalar                                        |
| `secao_7_sla`                         | `tempo_resolucao_esperado` + `escalacao_recomendada`        | SLA + pra quem escalar                                                      |
| `secao_8_formato_resposta_ia`         | `instrucao`                                                 | Como o assistente deve estruturar a resposta                                |

## Como formular a query

- Fale como **duvida de cliente** + nome do produto — casa `secao_2_perguntas_cliente` (x3) e `produto_servico` (x4).
- Classifique o **intento** pra escolher a skill certa entre os hits: provisionamento (subir/criar) - acesso/permissao - problema/erro - delecao - duvida geral. Skills genericas ("Outros - X") so vencem se nenhuma especifica casa o verbo.
- `mode` do `get_skill`: `summary` (default) traz o essencial; use `full` so quando precisar das 8 secoes inteiras.

## Anti-patterns

- NAO chute `produto_servico` a partir de busca incompleta — confirme via `list_produtos_servicos`/`search_skills` antes do `get_skill`.
- NAO despeje as 8 secoes no chat — destaque secoes 2, 3 e 4; resuma o resto.
- NAO invente `time_responsavel` quando a `secao_4` nao traz — reporte a lacuna.

# Reference: OpenSearch BM25 — pesos por campo e como formatar a query

Como os MCPs que rodam sobre OpenSearch (`help-foundation`, `postmortems`, `closed-incidents`) pontuam os resultados de busca textual, e como **formular a query do user** pra explorar esses pesos. Carregue este ref quando o ranking surpreender (um hit "obvio" nao veio no topo) ou quando precisar montar a melhor query pra uma tool `search_*`.

## Como a busca funciona (padrao comum)

As tools `search_*` usam `multi_match` BM25 com **pesos por campo** (`campo^peso`) e combinam duas clausulas:

- **loose** (`operator: or`, `fuzziness: AUTO`) — pega documentos que casam _qualquer_ termo, tolera typos.
- **strict** (`operator: and`, `boost` alto) — empurra pro topo quem casa _todos_ os termos.

Resultado: quem bate todos os termos sobe; quem bate so alguns ainda aparece. Os hits voltam com **highlights** marcados (`<<termo>>`) nos campos que casaram — use os highlights pra explicar _por que_ um resultado veio.

## Como formular a query (regra de ouro)

1. **Extraia substantivos + o verbo principal** da pergunta do user. Remova interrogativos e stopwords: "como", "qual", "quem", "o que", "tem", "de", "do", "na".
   - _"como faco pra subir um banco de dados novo no ambiente de prod?"_ → `subir banco dados prod` (ou `criar banco de dados`).
2. **Inclua o nome do produto/servico** se o user citou — ele costuma ter o maior peso (ver tabelas abaixo) e e o maior diferenciador de ranking.
3. **Nao jogue a frase inteira** — termos demais diluem o BM25 e a clausula strict raramente casa. 3-6 termos densos e o ponto otimo.
4. **Nao confie cegamente no top-1** — analise os top 5 (o default `top_k=5`). Em empates de score, prefira o hit cujo `highlight` casa o campo de maior peso.

## Pesos por indice

### `help-foundation` — indice `request_merged`

| Campo                                       | Peso |
| ------------------------------------------- | ---- |
| `produto_servico`                           | x4   |
| `secao_2_perguntas_cliente`                 | x3   |
| `metadata_skill.description`                | x2   |
| `secao_1_escopo.cobre`                      | x2   |
| `secao_3_analise_problemas.sintomas_comuns` | x2   |
| `secao_4_direcionamento.time_responsavel`   | x2   |

→ Nome do produto domina; perguntas reais do cliente (secao 2) sao a 2a maior alavanca. Formule a query parecendo uma **duvida de cliente** + nome do produto. Ver schema das secoes em `skills-section-schema`.

### `postmortems` — indice `incidents_processed`

| Campo                                                                                              | Peso |
| -------------------------------------------------------------------------------------------------- | ---- |
| `_description`, `causa_raiz_principal`                                                             | x4   |
| `_page_title`, `causas_raizes`, `servicos_afetados`                                                | x3   |
| `aplicacoes_mencionadas`, `componentes_afetados`, `recorrencias`, `_macroproduct`, `_product_name` | x2   |
| `observacoes`                                                                                      | x1   |

→ Descricao do incidente e causa raiz pesam mais. Pra "ja aconteceu algo parecido?", prefira `find_similar_incidents` (que separa as pistas em `description`/`services`/`components`/`causes`) — extrai mais sinal que `search_incidents` puro.

### `closed-incidents` — indice `closed_incidents`

| Campo                                                                                                          | Peso |
| -------------------------------------------------------------------------------------------------------------- | ---- |
| `last_description`                                                                                             | x4   |
| `first_description`, `last_symptom`                                                                            | x3   |
| `last_clause`, `last_tag_description`, `ai_postmortem`, `last_product`, `last_macroproduct`, `last_root_event` | x2   |
| `all_products`, `all_impacted_product_names`                                                                   | x1.5 |

→ Busca textual e descritiva, nao estatistica. Para **contar/filtrar/agregar**, use as tools dedicadas (`count_*`, `list_by_*`, `incidents_by_*`) — nao `search_*`.

## Anti-patterns

- NAO jogue a pergunta inteira do user como `query` — dilui o score; extraia os termos densos.
- NAO confie no top-1 sem olhar os highlights dos top 5 — o 2o hit costuma casar melhor o intento.
- NAO use `search_*` pra contar/agregar — as tools de agregacao (`list_by_*`, `count_*`, `incidents_by_*`) sao exatas; busca textual e aproximada.
- NAO ignore `produto_servico`/`_product_name`/`last_product` quando o user citou o produto — e o campo de maior peso e o maior diferenciador.

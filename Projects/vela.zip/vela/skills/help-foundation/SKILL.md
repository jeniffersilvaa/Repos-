---
name: help-foundation
description: "Consulta skills cadastradas no chatbot Karavela — direcionamento de chamados, times responsaveis, sintomas conhecidos, perguntas frequentes e catalogo de produtos suportados. Use quando o usuario perguntar sobre skills do Karavela, qual time e responsavel por um produto, como direcionar um chamado, sintomas comuns de um produto, FAQs de produto ou listar produtos com skill."
---

# Skill: help-foundation (Skills do Karavela)

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.

  Exemplos de uso:
  - Corrigir informacao desatualizada no conhecimento embutido
  - Adicionar restricao temporaria
  - Adicionar conhecimento que ainda nao esta na documentacao oficial
  - Bloquear uma orientacao especifica
-->

## Escopo

**Cobre**:
- Skills cadastradas no chatbot Karavela (indice OpenSearch `request_merged`, ~138 docs)
- Direcionamento de chamados: qual time responsavel por um produto/servico
- Sintomas conhecidos e causas raiz catalogadas nas skills
- Perguntas frequentes de clientes (FAQ) por produto
- Catalogo de produtos suportados (listar produtos com skill)
- Consulta de skill especifica completa (8 secoes)

**NAO cobre**:
- Causa raiz de incidentes especificos (coberto por postmortems)
- Incidentes abertos em tempo real (coberto por active-incidents)
- Estatisticas de volume de incidentes por produto (coberto por closed-incidents)
- Top N produtos com mais incidentes (coberto por closed-incidents)

## Exemplos de Perguntas

- "Qual time e responsavel pelo PIX?"
- "Quais sintomas comuns do produto Conta Stone?"
- "Lista todos os produtos que tem skill no Karavela"
- "Como direcionar um chamado de antecipacao de recebiveis?"
- "Quais sao as perguntas frequentes sobre TEF?"
- "Me mostra a skill completa do produto Link de Pagamento"
- "Que time devo acionar pra problemas com maquininha?"

## Nao confundir com

| Pergunta do user                      | MCP correto        | Razao                                             |
| ------------------------------------- | ------------------ | ------------------------------------------------- |
| "Causa raiz do incidente #N?"         | `postmortems`      | Skill nao tem RCA                                 |
| "Tem incidente aberto agora no PIX?"  | `active-incidents` | Skill nao rastreia incidente em curso             |
| "Quantos incidentes no PIX em 2026?"  | `closed-incidents` | Skill e catalogo de DIRECIONAMENTO, nao de volume |
| "Top 10 produtos com mais incidentes" | `closed-incidents` | idem                                              |

## Conhecimento Embutido

### Tools (inventario canonico)

**Discovery (descoberta do catalogo):**

- `list_produtos_servicos({ max_terms?=200 })` — todos os produtos com skill, ordenados por `skill_count`. Use ANTES de `get_skill` quando o user deu so o termo aproximado.
- `health()` — confirma indice ativo + `count`. So pra debug.

**Read (skill conhecida):**

- `get_skill({ produto_servico, mode?="summary" })` — skill completa (8 secoes). `mode: "full"` so quando precisar de tudo. Use depois que o nome do produto esta fixo.

**Search (linguagem natural):**

- `search_skills({ query, top_k?=5, produto_servico? })` — **default** quando a pergunta e narrativa (sintoma, cenario, duvida). Filtre por `produto_servico` se ja souber restringir. Pesos e como formular a query → ref `opensearch-bm25-weights`.

## Fluxo: direcionar chamado

1. `search_skills({ query: <sintoma do user> })` — extraia substantivos + verbo (ver ref de pesos).
2. **Selecione a skill por intento** entre os top 5 (provisionamento / acesso / problema / delecao / duvida geral). Se o top ja tem `secao_4_direcionamento.time_responsavel` claro, responda com **produto + time + acao imediata**.
3. Se ambiguo (scores proximos): mencione os top 2-3 com 1 linha cada e pergunte qual cenario bate — sem chutar.
4. Cite **produto + secao** que sustenta a resposta (ex: "skill `PIX – Recebimento`, secao `Sintomas Comuns`"). Schema das secoes → ref `skills-section-schema`.

## Fluxo: catalogo ("que produtos tem skill?")

1. `list_produtos_servicos({ max_terms: 200 })`.
2. Agrupe por macroproduto (prefixo do nome). Se passar de 30 itens, destaque os 10 com maior `skill_count` + mencione o total — nao cole a lista crua.

## Fluxo: skill especifica completa

1. Nome exato → `get_skill({ produto_servico })`.
2. `found: false` → caia em `list_produtos_servicos` e ofereca correcao.
3. Destaque as 3 secoes mais usadas (`secao_2_perguntas_cliente`, `secao_3_analise_problemas.sintomas_comuns`, `secao_4_direcionamento.time_responsavel`); resuma o resto.

## Reference (cross-MCP)

- **postmortems** — sintoma que parece incidente novo ("PIX caindo desde manha"): `find_similar_incidents` antes de direcionar; se houver caso, traga a causa raiz.
- **active-incidents** — "esta acontecendo agora": `count_active_incidents({ macroproduct })` ANTES de direcionar (pode ter war room).
- **closed-incidents** — virou estatistica ("o PIX da muito problema?"): `list_by_impacted_product({ product_name: "PIX" })` + `incidents_by_period`.

## Principios

- **Search e o default**; `get_skill` so com o `produto_servico` fixo — nao chute a partir de busca incompleta.
- **Cite a fonte** (produto + secao) — permite ao user clicar e validar.
- Pesos do BM25 e formulacao de query → ref `opensearch-bm25-weights`. Schema das 8 secoes → ref `skills-section-schema`.
- Indice ~138 docs → respostas < 1s. Latencia > 3s = sinal de algo errado, sinalize.
- A skill e o **contrato de direcionamento** — se o cenario nao tem skill, NAO invente; reporte a lacuna.

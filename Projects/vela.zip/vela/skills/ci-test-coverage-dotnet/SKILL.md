---
name: ci-test-coverage-dotnet
description: "Workflow reutilizavel de testes e coverage para projetos .NET (C#). Use quando o usuario perguntar sobre como adicionar testes (unit, integration, e2e) com cobertura de codigo em projetos .NET ou C#, configurar dotnet test com XPlat Code Coverage, converter Cobertura para LCOV com reportgenerator, usar feeds NuGet privados, integrar com o workflow test-coverage-dotnet, usar em monorepos ou enviar metricas de coverage ao Kafka."
---

# Skill: Testes & Coverage — .NET (C#)

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.
-->

> ### ⚠️ Pré-requisito: Acesso às Org Secrets de Kafka
>
> Para usar os secrets de Kafka, **adicione o nome do repositório do seu projeto** em todos os arquivos abaixo no repositório `stone-payments/terraform-github` (via Pull Request para revisão):
>
> Caminho base: `applications/org-secrets/stone-payments/secrets.installation.d/`
>
> | Arquivo YAML | Nome da org secret | Input do workflow |
> |---|---|---|
> | `QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD.yaml` | `QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD` | `KAFKA_BROKER_URL` |
> | `QA_MATURITY_KAFKA_SASL_USERNAME_PRD.yaml` | `QA_MATURITY_KAFKA_SASL_USERNAME_PRD` | `KAFKA_SASL_USERNAME` |
> | `QA_MATURITY_KAFKA_SASL_PASSWORD_PRD.yaml` | `QA_MATURITY_KAFKA_SASL_PASSWORD_PRD` | `KAFKA_SASL_PASSWORD` |
> | `QA_MATURITY_KAFKA_SCHEMA_ENDPOINT_PRD.yaml` | `QA_MATURITY_KAFKA_SCHEMA_ENDPOINT` ⚠️ (sem `_PRD`) | `KAFKA_SCHEMA_ENDPOINT` |
> | `QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD.yaml` | `QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD` | `KAFKA_SCHEMA_USERNAME` |
> | `QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD.yaml` | `QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD` | `KAFKA_SCHEMA_PASSWORD` |
>
> Ao chamar o workflow, mapeie as org secrets para os inputs corretamente:
>
> ```yaml
> secrets:
>   KAFKA_BROKER_URL: ${{ secrets.QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD }}
>   KAFKA_SASL_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SASL_USERNAME_PRD }}
>   KAFKA_SASL_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SASL_PASSWORD_PRD }}
>   KAFKA_SCHEMA_ENDPOINT: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_ENDPOINT }}
>   KAFKA_SCHEMA_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD }}
>   KAFKA_SCHEMA_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD }}
> ```

## Escopo

**Cobre**:
- Como incorporar o workflow `test-coverage-dotnet` em um projeto .NET ou C#
- Todos os inputs do workflow (`project_name`, `unit_test_path`, `integration_test_path`, `e2e_test_path`, `sdk_version`, `global_json_file`, `nuget_config_path`, `build_config`, `target_projects`, `extra_test_args`, `working_directory`)
- Deteccao automatica de versao SDK via `global.json`
- Globs para projetos de teste (`.csproj`)
- Configuracao de feed NuGet privado via `NUGET_USERNAME` e `NUGET_PASSWORD`
- Coleta de coverage com XPlat Code Coverage (formato Cobertura)
- Conversao para LCOV com `reportgenerator`
- Secrets opcionais para envio de metricas ao Kafka (`KAFKA_*`)
- Uso em monorepos com `working_directory`
- Artifact de coverage gerado (`coverage-{project_name}`)

**NAO cobre**:
- Escrita de testes em C#
- Configuracao avancada do MSTest, xUnit ou NUnit
- Infraestrutura de Kafka

## Exemplos de Perguntas

- "Como adiciono cobertura de testes no meu projeto .NET?"
- "Como configuro o workflow de testes para C#?"
- "Como separo testes unit, integration e e2e no workflow .NET?"
- "Meu projeto tem um NuGet privado, como configuro?"
- "Como detecto a versao do .NET SDK via global.json?"
- "Como uso o workflow em monorepo .NET?"
- "Como envio metricas de coverage para o Kafka?"
- "O que e reportgenerator e por que o workflow usa?"

## Conhecimento Embutido

### Localizacao do Workflow

```
stone-payments/github-actions-workflows
  .github/workflows/test-coverage-dotnet.yml
```

Referencia para consumo: `@test-coverage-dotnet-v0`

---

### Como Integrar o Workflow

#### Uso Minimo (apenas testes unitarios)

```yaml
# .github/workflows/ci.yml
jobs:
  coverage:
    uses: stone-payments/github-actions-workflows/.github/workflows/test-coverage-dotnet.yml@test-coverage-dotnet-v0
    with:
      project_name: meu-projeto
      unit_test_path: '**/*Unit*Test*.csproj'
```

#### Com Todos os Tipos de Teste e global.json

```yaml
jobs:
  coverage:
    uses: stone-payments/github-actions-workflows/.github/workflows/test-coverage-dotnet.yml@test-coverage-dotnet-v0
    with:
      project_name: meu-projeto
      unit_test_path: '**/*Unit*Test*.csproj'
      integration_test_path: '**/*Integration*Test*.csproj'
      e2e_test_path: '**/*E2E*Test*.csproj'
      global_json_file: global.json
```

#### Com Feed NuGet Privado

```yaml
jobs:
  coverage:
    uses: stone-payments/github-actions-workflows/.github/workflows/test-coverage-dotnet.yml@test-coverage-dotnet-v0
    with:
      project_name: meu-projeto
      unit_test_path: '**/*UnitTest*.csproj'
      nuget_config_path: nuget.config
    secrets:
      NUGET_USERNAME: ${{ secrets.NUGET_USERNAME }}
      NUGET_PASSWORD: ${{ secrets.NUGET_PASSWORD }}
```

#### Em Monorepo com Versao SDK Fixa

```yaml
jobs:
  coverage:
    uses: stone-payments/github-actions-workflows/.github/workflows/test-coverage-dotnet.yml@test-coverage-dotnet-v0
    with:
      project_name: payments-api
      unit_test_path: '**/*Unit*.csproj'
      sdk_version: '8.x'
      working_directory: src/PaymentsApi
    secrets:
      KAFKA_BROKER_URL: ${{ secrets.QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD }}
      KAFKA_SASL_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SASL_USERNAME_PRD }}
      KAFKA_SASL_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SASL_PASSWORD_PRD }}
      KAFKA_SCHEMA_ENDPOINT: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_ENDPOINT }}
      KAFKA_SCHEMA_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD }}
      KAFKA_SCHEMA_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD }}
```

---

### Inputs Disponiveis

| Input | Tipo | Obrigatorio | Descricao | Padrao |
|-------|------|-------------|-----------|--------|
| `project_name` | string | **sim** | Nome do projeto. Identifica o artifact de coverage. | — |
| `unit_test_path` | string | nao | Glob dos projetos de teste unitario (ex: `"**/*Unit*Test*.csproj"`). Omita para nao executar. | — |
| `integration_test_path` | string | nao | Glob dos projetos de teste de integracao. Omita para nao executar. | — |
| `e2e_test_path` | string | nao | Glob dos projetos de teste e2e. Omita para nao executar. | — |
| `sdk_version` | string | nao | Versao do .NET SDK (ex: `"8.x"`). Se omitido, detectado via `global_json_file`. | `""` |
| `global_json_file` | string | nao | Caminho do `global.json` para resolucao do SDK. | `""` |
| `nuget_config_path` | string | nao | Caminho do `nuget.config`. | `"nuget.config"` |
| `build_config` | string | nao | Configuracao de build (ex: `"Release"`, `"Debug"`). | `"Release"` |
| `target_projects` | string | nao | Glob para solucao/projetos a compilar. | `"**/*.sln"` |
| `extra_test_args` | string | nao | Argumentos extras passados para `dotnet test`. | — |
| `working_directory` | string | nao | Diretorio raiz do projeto. Util para monorepos. | `"."` |
| `runs_on` | string | nao | Runner a usar (formato JSON). | `"['ubuntu-22.04']"` |

### Secrets Opcionais

| Secret | Descricao |
|--------|-----------|
| `NUGET_USERNAME` | Usuario para autenticacao em feed NuGet privado |
| `NUGET_PASSWORD` | Senha/token para autenticacao em feed NuGet privado |
| `KAFKA_BROKER_URL` | URL do broker Kafka |
| `KAFKA_SASL_USERNAME` | Username SASL do Kafka |
| `KAFKA_SASL_PASSWORD` | Password SASL do Kafka |
| `KAFKA_SCHEMA_ENDPOINT` | URL do Schema Registry |
| `KAFKA_SCHEMA_USERNAME` | Username do Schema Registry |
| `KAFKA_SCHEMA_PASSWORD` | Password do Schema Registry |

---

### O que o Workflow Faz (resumo)

- Setup do .NET SDK via `sdk_version` ou `global_json_file`
- `dotnet restore` + `dotnet build` com autenticacao NuGet configurada quando os secrets `NUGET_*` sao fornecidos
- Roda `dotnet test` com XPlat Code Coverage para cada tipo configurado (unit/integration/e2e)
- Mescla e converte os relatorios em `coverage/lcov.info` via `reportgenerator`
- Faz upload do artifact `coverage-{project_name}` (so o LCOV ja merged)
- Quando configurado, envia metricas agregadas para o backend de qualidade da plataforma

> Fonte: `stone-payments/github-actions-workflows/.github/workflows/test-coverage-dotnet.yml` (complemento — nao em docs/)
> Para feeds NuGet do Azure Artifacts, ver tambem `karavela/docs/guia-do-desenvolvedor/funcionalidades/azure-artifacts.md`.

---

### Globs para Projetos de Teste

Os inputs `unit_test_path`, `integration_test_path` e `e2e_test_path` sao passados diretamente para `dotnet test`. Exemplos:
- `'**/*Unit*Test*.csproj'` — qualquer `.csproj` com "Unit" e "Test" no nome
- `'**/*Integration*.csproj'` — qualquer `.csproj` com "Integration" no nome
- `'tests/MyProject.Tests/MyProject.Tests.csproj'` — path exato

---

### Artifact Gerado

O workflow faz upload do seguinte artifact:
- **Nome**: `coverage-{project_name}`
- **Arquivo**: `coverage/lcov.info`
- **Formato**: LCOV

---

### Envio de Metricas

Quando os secrets `KAFKA_*` sao fornecidos, o workflow envia metricas de coverage para o backend de qualidade da plataforma (consumido por relatorios internos). Sem esses secrets, o passo e ignorado silenciosamente — coverage continua sendo gerado e publicado como artifact normalmente.

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Criar `.github/workflows/test-coverage.yml`** apontando para `test-coverage-dotnet.yml@main`
- **Editar `global.json`** para fixar SDK version
- **Editar `NuGet.Config`** para feed privado (secrets `NUGET_USERNAME`/`NUGET_PASSWORD`)
- **Adicionar packages** `coverlet.collector`, `XPlat Code Coverage` nos `.csproj` de teste
- **Abrir PR draft**

### Triggers proativos
- "Adicionar coverage .NET" → `🛠️ Acao proposta: configuro coverlet + workflow + abro PR`

### Acoes destrutivas
- N/A.

## Instrucoes MCP

Esta skill nao tem doc dedicado em `stone-payments/karavela` `docs/`. A fonte primaria de operacao e o proprio reusable workflow. Para feeds NuGet do Azure Artifacts, ha doc dedicada em `karavela/docs/`.

| Repositorio | Arquivo/Caminho | Prioridade | Quando buscar |
|-------------|-----------------|------------|---------------|
| `stone-payments/github-actions-workflows` | `.github/workflows/test-coverage-dotnet.yml` | primaria operacional — complemento (nao em docs/) | Inputs/outputs e tag mais recente do workflow |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/funcionalidades/azure-artifacts.md` | primaria | Feeds NuGet do Azure Artifacts no build |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/deploy-de-aplicacoes/` | complemento | Para entender onde encaixar o job no pipeline geral |
| `stone-payments/terraform-github` | `applications/org-secrets/stone-payments/secrets.installation.d/` | complemento | Liberacao das org secrets de Kafka para o repositorio do usuario |

---
name: megalinter
description: "Workflow reutilizavel do MegaLinter para linting estatico de codigo. Use quando o usuario perguntar sobre como adicionar linting ao projeto, configurar o MegaLinter, o arquivo .mega-linter.yml, APPLY_FIXES, flavors, linters especificos, integracao com GitHub Security tab, envio de metricas ao Kafka ou boas praticas de configuracao."
---

# Skill: MegaLinter — Linting Estatico de Codigo

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.
-->

## Escopo

**Cobre**:
- Como integrar o workflow `mega-linter` em um projeto
- Todos os inputs do workflow (`DEFAULT_BRANCH`, `APPLY_FIXES_IF_PR`, `RUNS_ON`, `project_name`, `API_REPORTER`, etc.)
- Como configurar o `.mega-linter.yml` no repositorio consumidor
- Estrategia de validacao: codebase inteiro no push para main, diff do PR em pull_request
- Como funciona o `APPLY_FIXES` (criacao de PR com correcoes automaticas)
- Integracao com GitHub Security tab via SARIF
- Escolha de flavor para melhorar performance
- Linters mais comuns por linguagem
- Secrets opcionais para envio de metricas ao Kafka (`KAFKA_*`)
- Boas praticas: quais linters habilitar/desabilitar, tamanho de runner

**NAO cobre**:
- Configuracao avancada de linters individuais (regras ESLint, Ruff, etc.)
- Infraestrutura de Kafka
- Como escrever codigo isento de erros de lint

## Exemplos de Perguntas

- "Como adiciono linting ao meu projeto com MegaLinter?"
- "Como configuro o .mega-linter.yml?"
- "Como faco o MegaLinter corrigir os erros automaticamente via PR?"
- "Qual flavor devo usar no MegaLinter para um projeto .NET?"
- "Como desabilito linters especificos?"
- "O que e `VALIDATE_ALL_CODEBASE` e quando devo usar?"
- "Como integro o MegaLinter com o GitHub Security tab?"
- "Como envio metricas do MegaLinter para o Kafka?"
- "Meu workflow esta demorando muito, como otimizo?"
- "Como configuro o runner para o MegaLinter?"

## Conhecimento Embutido

### Localizacao do Workflow

```
stone-payments/github-actions-workflows
  .github/workflows/mega-linter.yml
```

Referencia para consumo: `@main` (nao ha tag semantica propria para este workflow; usar `@main` ou a ultima tag global do repo como `@v1.0.58`)

---

### Como Integrar o Workflow

#### Uso Minimo

```yaml
# .github/workflows/lint.yml
name: Lint

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  lint:
    uses: stone-payments/github-actions-workflows/.github/workflows/mega-linter.yml@main
    with:
      project_name: meu-projeto
```

#### Com Apply Fixes e Branch Padrao Customizado

```yaml
jobs:
  lint:
    uses: stone-payments/github-actions-workflows/.github/workflows/mega-linter.yml@main
    with:
      project_name: meu-projeto
      DEFAULT_BRANCH: master
      APPLY_FIXES_IF_PR: true
```

#### Com Runner Customizado e Metricas Kafka

```yaml
jobs:
  lint:
    uses: stone-payments/github-actions-workflows/.github/workflows/mega-linter.yml@main
    with:
      project_name: meu-projeto
      RUNS_ON: large-runner
    secrets:
      KAFKA_BROKER_URL: ${{ secrets.KAFKA_BROKER_URL }}
      KAFKA_SASL_USERNAME: ${{ secrets.KAFKA_SASL_USERNAME }}
      KAFKA_SASL_PASSWORD: ${{ secrets.KAFKA_SASL_PASSWORD }}
      KAFKA_SCHEMA_ENDPOINT: ${{ secrets.KAFKA_SCHEMA_ENDPOINT }}
      KAFKA_SCHEMA_USERNAME: ${{ secrets.KAFKA_SCHEMA_USERNAME }}
      KAFKA_SCHEMA_PASSWORD: ${{ secrets.KAFKA_SCHEMA_PASSWORD }}
```

---

### Inputs Disponiveis

| Input | Tipo | Obrigatorio | Descricao | Padrao |
|-------|------|-------------|-----------|--------|
| `project_name` | string | nao | Nome do projeto para metricas Kafka e identificacao. | — |
| `DEFAULT_BRANCH` | string | nao | Branch principal do repositorio. Usado para determinar quando validar codebase inteiro. | `"main"` |
| `APPLY_FIXES_IF_PR` | boolean | nao | Se `true`, cria uma PR com correcoes automaticas dos linters que suportam auto-fix. | `false` |
| `RUNS_ON` | string | nao | Label do runner GitHub Actions. | `"medium-runner"` |
| `API_REPORTER` | boolean | nao | Habilita reporter da API para Grafana. Requer `GRAFANA_*` inputs configurados. | `false` |
| `GRAFANA_API_REPORTER_URL` | string | nao | URL da API de reporter do Grafana. | — |
| `GRAFANA_API_REPORTER_METRICS_URL` | string | nao | URL das metricas do reporter Grafana. | — |
| `API_REPORTER_DEBUG` | boolean | nao | Modo debug do reporter da API. | `false` |
| `JAVASCRIPT_LINTER_VERSION` | string | nao | Versao do linter JavaScript a usar. | — |
| `NPM_INSTALL_TOOL` | string | nao | Ferramenta npm para instalacao de dependencias de linters. | — |
| `INSTALL_LINTER_DEPS` | boolean | nao | Instala dependencias extras dos linters antes de executar. | — |

### Secrets Opcionais

| Secret | Descricao |
|--------|-----------|
| `GRAFANA_API_REPORTER_BASIC_AUTH_USERNAME` | Usuario para autenticacao basica na API do Grafana |
| `GRAFANA_API_REPORTER_TOKEN` | Token de autenticacao do Grafana |
| `GRAFANA_API_REPORTER_METRICS_BASIC_AUTH_USERNAME` | Usuario para metricas do Grafana |
| `KAFKA_BROKER_URL` | URL do broker Kafka |
| `KAFKA_SASL_USERNAME` | Username SASL do Kafka |
| `KAFKA_SASL_PASSWORD` | Password SASL do Kafka |
| `KAFKA_SCHEMA_ENDPOINT` | URL do Schema Registry |
| `KAFKA_SCHEMA_USERNAME` | Username do Schema Registry |
| `KAFKA_SCHEMA_PASSWORD` | Password do Schema Registry |

---

### O que o Workflow Faz (resumo)

- Roda o MegaLinter v9 sobre o codebase
- Em push para `DEFAULT_BRANCH` valida o codebase inteiro; em pull_request valida apenas o diff
- Faz upload dos relatorios (`megalinter-reports/` + `mega-linter.log`) como artifact, mesmo em falha
- Quando `APPLY_FIXES_IF_PR: true`, abre PR com as correcoes automaticas
- Em falha, faz upload do SARIF para a aba **Security > Code scanning** do GitHub
- Quando configurado, envia metricas agregadas para o backend de qualidade da plataforma

> Fonte: `stone-payments/github-actions-workflows/.github/workflows/mega-linter.yml` (complemento — nao em docs/)

---

### Configuracao do .mega-linter.yml

O MegaLinter le o arquivo `.mega-linter.yml` na raiz do repositorio consumidor. Este arquivo controla quais linters rodam, quais arquivos ignorar, e outras configuracoes.

#### Exemplo Minimo

```yaml
# .mega-linter.yml (na raiz do seu repositorio)
APPLY_FIXES: none        # "none", "all", ou lista de linters
APPLY_FIXES_EVENT: all   # "all", "push", "pull_request"
APPLY_FIXES_MODE: commit # "commit" ou "pull_request"
```

#### Exemplo Completo para Projeto .NET

```yaml
# .mega-linter.yml
FLAVOR: dotnet

APPLY_FIXES: none
APPLY_FIXES_EVENT: pull_request
APPLY_FIXES_MODE: pull_request

# Desabilitar linters que nao se aplicam ao projeto
DISABLE:
  - COPYPASTE  # detector de copy-paste (muito ruidoso para inicio)
  - SPELL      # verificador ortografico

# Desabilitar linters especificos
DISABLE_LINTERS:
  - MARKDOWN_MARKDOWN_LINK_CHECK   # links em markdown (lento, flaky)
  - REPOSITORY_SECRETLINT          # usa gitleaks no lugar

# Ignorar pastas/arquivos gerados
FILTER_REGEX_EXCLUDE: >-
  (\.git|\.nuget|bin|obj|node_modules|dist|coverage)

# Limitar numero de erros antes de parar (evitar timeout)
MEGALINTER_MAX_ERRORS: 100
```

#### Exemplo para Projeto Go

```yaml
# .mega-linter.yml
FLAVOR: go

DISABLE:
  - COPYPASTE
  - SPELL

DISABLE_LINTERS:
  - REPOSITORY_TRIVY_SBOM          # lento
  - MARKDOWN_MARKDOWN_LINK_CHECK

FILTER_REGEX_EXCLUDE: >-
  (\.git|vendor|generated|\.pb\.go)

MEGALINTER_MAX_ERRORS: 50
```

#### Exemplo para Projeto Node.js / TypeScript

```yaml
# .mega-linter.yml
FLAVOR: javascript

DISABLE:
  - COPYPASTE
  - SPELL

DISABLE_LINTERS:
  - MARKDOWN_MARKDOWN_LINK_CHECK

ENABLE_LINTERS:
  - JAVASCRIPT_ES           # ESLint
  - TYPESCRIPT_ES           # ESLint para TS
  - JSON_PRETTIER
  - YAML_PRETTIER

FILTER_REGEX_EXCLUDE: >-
  (node_modules|dist|coverage|\.next|build)
```

---

### Escolha de Flavor

Flavors sao distribuicoes otimizadas do MegaLinter com menos linters pre-instalados, resultando em builds mais rapidos:

| Flavor | Ideal para |
|--------|-----------|
| `dotnet` | Projetos C#, VB.NET, F# |
| `go` | Projetos Go |
| `javascript` | Node.js, TypeScript, JavaScript |
| `python` | Projetos Python |
| `java` | Projetos Java e Kotlin |
| `scala` | Projetos Scala |
| `ruby` | Projetos Ruby |
| `rust` | Projetos Rust |
| `php` | Projetos PHP |
| (sem flavor) | Multi-linguagem, projetos mistos |

Configure o flavor no `.mega-linter.yml`:

```yaml
FLAVOR: dotnet  # ou go, javascript, python, java, etc.
```

> **Importante**: O flavor e configurado no `.mega-linter.yml` do repositorio consumidor, NAO como input do workflow reutilizavel.

---

### Linters por Linguagem (Mais Relevantes)

**C# / .NET:**
- `CSHARP_DOTNET_FORMAT` — formatter e linter oficial
- `CSHARP_CSHARPIER` — opinionated formatter

**Go:**
- `GO_GOLANGCI_LINT` — linter agregado para Go
- `GO_REVIVE` — linter leve e rapido

**JavaScript / TypeScript:**
- `JAVASCRIPT_ES` — ESLint
- `TYPESCRIPT_ES` — ESLint para TypeScript
- `JAVASCRIPT_PRETTIER` — formatter

**Python:**
- `PYTHON_PYLINT` — linter classico
- `PYTHON_RUFF` — linter rapido moderno
- `PYTHON_BLACK` — formatter
- `PYTHON_MYPY` — type checking

**Repositorio (todos os projetos):**
- `REPOSITORY_GITLEAKS` — deteccao de secrets vazados
- `REPOSITORY_TRIVY` — scan de vulnerabilidades
- `REPOSITORY_SECRETLINT` — alternativa ao gitleaks
- `DOCKERFILE_HADOLINT` — lint de Dockerfiles
- `YAML_YAMLLINT` — lint de YAMLs

---

### APPLY_FIXES: Correcoes Automaticas

Quando `APPLY_FIXES_IF_PR: true` no workflow e `APPLY_FIXES: all` no `.mega-linter.yml`, o workflow:
1. Executa os linters com modo de auto-correcao
2. Se houve arquivos modificados, cria uma nova PR com titulo `[MegaLinter] Apply linters automatic fixes`

> **Nota**: Funciona apenas em PRs do mesmo repositorio (NAO funciona em forks).

Configuracoes relacionadas no `.mega-linter.yml`:

```yaml
APPLY_FIXES: all           # "none", "all", ou lista como "GO_GOLANGCI_LINT,TYPESCRIPT_ES"
APPLY_FIXES_EVENT: all     # "all", "push", "pull_request"
APPLY_FIXES_MODE: pull_request  # "commit" (push direto) ou "pull_request" (cria PR)
```

---

### Integracao com GitHub Security Tab

Quando o workflow falha, os resultados sao enviados para a aba **Security > Code scanning** do GitHub no formato SARIF. Isso permite:
- Ver erros de lint como code scanning alerts
- Filtrar por linter, severidade, arquivo
- Acompanhar historico de resolucao de alertas

> O upload SARIF ocorre automaticamente em falha. Nao requer configuracao adicional.

---

### Artifacts Gerados

Apos cada execucao (mesmo em falha), o workflow faz upload de:
- **`MegaLinter reports`** — incluindo:
  - `megalinter-reports/megalinter-report.sarif` — para o GitHub Security tab
  - `megalinter-reports/mega-linter-report.json` — JSON completo com todos os linters
  - `megalinter-reports/linters-reports/` — pastas individuais por linter
- **`mega-linter.log`** — log completo de execucao

---

### Boas Praticas

1. **Comece com flavor correto** — escolha o flavor da sua linguagem principal para ter builds mais rapidos

2. **Desabilite linters ruidosos no inicio** — `COPYPASTE`, `SPELL` e `MARKDOWN_MARKDOWN_LINK_CHECK` costumam gerar muito ruido; habilite progressivamente

3. **Use `MEGALINTER_MAX_ERRORS`** — impede timeout em projetos com muitos erros acumulados:
   ```yaml
   MEGALINTER_MAX_ERRORS: 100
   ```

4. **`FILTER_REGEX_EXCLUDE` e essencial** — sempre exclua pastas geradas (`node_modules`, `dist`, `vendor`, `bin`, `obj`):
   ```yaml
   FILTER_REGEX_EXCLUDE: (node_modules|dist|vendor|generated)
   ```

5. **Estrategia de VALIDATE_ALL_CODEBASE** — o workflow ja cuida automaticamente:
   - Push para main → valida tudo (lento, mas garante codigo limpo na branch principal)
   - PR → valida apenas o diff (rapido, feedback imediato)

6. **Runner sizing** — MegaLinter e intensivo em CPU/memoria; para projetos grandes use `large-runner`

7. **`APPLY_FIXES` em PR, nao commit** — evite `APPLY_FIXES_MODE: commit` em branches protegidas; prefira `pull_request` para ter revisao humana

---

### Envio de Metricas

Quando os secrets `KAFKA_*` sao fornecidos, o workflow envia metricas agregadas dos linters (linters executados, erros, warnings, tempo total) para o backend de qualidade da plataforma. Sem esses secrets, o passo e ignorado silenciosamente — linting continua funcionando normalmente.

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Criar `.mega-linter.yml`** na raiz com flavor adequado (cupcake/dotnet/java/javascript/python) + linters ativos/desativados
- **Criar `.github/workflows/mega-linter.yml`** apontando para `mega-linter.yml@main` (estrategia: push main = total; PR = diff)
- **Configurar `APPLY_FIXES`** para criar PR automatica com correcoes
- **Adicionar secrets Kafka** opcionais para metricas
- **Abrir PR draft**

### Triggers proativos
- "Adicionar linting" → `🛠️ Acao proposta: crio .mega-linter.yml + workflow + abro PR`
- "Ativar auto-fix" → propor `APPLY_FIXES: all`
- "Otimizar performance" → propor flavor especifico baseado nas linguagens

### Acoes destrutivas
- N/A — linter so reporta/fixe.

## Instrucoes MCP

Esta skill nao tem doc dedicado em `stone-payments/karavela` `docs/`. A fonte primaria de operacao e o proprio reusable workflow.

| Repositorio | Arquivo/Caminho | Prioridade | Quando buscar |
|-------------|-----------------|------------|---------------|
| `stone-payments/github-actions-workflows` | `.github/workflows/mega-linter.yml` | primaria operacional — complemento (nao em docs/) | Inputs/outputs e versao do workflow |
| `oxsecurity/megalinter` | upstream | complemento | Configuracao detalhada de linters individuais e flavors |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/deploy-de-aplicacoes/` | complemento | Para entender onde encaixar o job no pipeline geral |

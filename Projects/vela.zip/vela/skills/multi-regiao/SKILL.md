---
name: multi-regiao
description: "Deploy multi-regiao e alta disponibilidade na plataforma Karavela. Use quando o usuario perguntar sobre deploy em multiplas regioes, failover, DNS switching, alta disponibilidade ou disaster recovery."
---

# Skill: Multi-Regiao

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.
-->

## Escopo

**Cobre**:

- Arquitetura de deploy multi-regiao na plataforma Karavela
- Virada de DNS entre regioes (ativo-passivo para APIs)
- Consideracoes de alta disponibilidade e resiliencia
- Implicacoes de custos do modelo multi-regiao
- Requisitos de configuracao para multi-regiao (values por regiao, secrets, workflows)
- Regioes disponiveis por provedor (Azure e AWS) — incluindo `sa-east-1` agora como primary
- Contextos que suportam multi-regiao
- Pre-requisitos para habilitar multi-regiao
- Deploy de aplicacoes multi-regiao com aprovacao por regiao
- Tipos de chart que suportam multi-regiao
- Promocao de ambientes multi-regiao via Portal
- Virada de DNS unitaria e em massa via Portal
- Campo `targetProvider` para failover de DNS no GatewayServiceClaim
- Campo `has_managed_hosts` em aplicacoes multi-regiao
- ChangeRegionModal para failover manual no Portal
- Suporte a Azure Gateway provider para multi-regiao
- Copia de secrets between regioes da mesma app (same-app multi-region copy)

**NAO cobre**:

- Ambientes single-region (coberto por ambientes-contextos)
- Networking/ingress por regiao (coberto por networking-ingress)
- Fluxos de deploy e rollback (coberto por deploy-rollback)

## Exemplos de Perguntas

- "Como habilito multi-regiao para minha aplicacao na Karavela?"
- "Quais regioes estao disponiveis para multi-regiao na AWS e Azure?"
- "Como faco a virada de DNS para outra regiao?"
- "Quais sao os custos adicionais de multi-regiao?"
- "Meu contexto suporta multi-regiao?"
- "Como configuro o values.yaml para multi-regiao?"
- "Preciso de aprovacao separada para deploy em cada regiao?"
- "Multi-regiao cobre replicacao de bancos de dados e filas?"
- "Quais tipos de chart suportam multi-regiao?"
- "Como faco a virada de DNS em massa para varias aplicacoes?"
- "O que e o campo targetProvider no GatewayServiceClaim?"
- "Como sei se minha aplicacao tem managed hosts?"
- "Como faco failover manual de DNS pelo Portal?"
- "Posso copiar secrets entre regioes da mesma app?"
- "sa-east-1 pode ser regiao primary?"

## Conhecimento Embutido

### Visao Geral e Pre-requisitos

A plataforma Karavela oferece suporte a aplicacoes multi-regiao, permitindo que APIs, workers, cronjobs e jobs sejam executados em mais de uma regiao, aumentando a disponibilidade e resiliencia para workloads criticos.

O suporte multi-regiao esta disponivel exclusivamente para ambientes Karavela Azure e AWS.

Pre-requisitos para habilitar:

- Ambiente de producao ja criado e funcional
- Aplicacao saudavel no ArgoCD
- Aplicacao elegivel: aplicacoes PCI e nao PCI sao suportadas, porem apenas aplicacoes com acesso interno (sem exposicao publica)

Para habilitar multi-regiao, utiliza-se o processo de promocao de ambientes no Karavela Portal, selecionando o ambiente multi-regiao na etapa de escolha do ambiente. E obrigatorio que o ambiente de producao ja exista.

Caso a aplicacao ja esteja em producao, ajustes manuais no DNS da aplicacao produtiva existente sao necessarios. Essa etapa nao foi automatizada para evitar impacto na aplicacao em producao. E necessario abrir um chamado para o time Karavela Applications pelo canal Slack `#help-foundation-platform`.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/multi-regiao.md`

### Tipos de Chart Suportados

Apenas determinados tipos de chart suportam multi-regiao. A flag `multi_region_supported` esta restrita aos seguintes tipos:

| Tipo de Chart | Suporta Multi-Regiao |
|---------------|----------------------|
| API           | Sim                  |
| Worker        | Sim                  |
| Cronjob       | Sim                  |
| Job           | Sim                  |

Importante: apenas aplicacoes com acesso interno sao elegíveis (sem exposicao publica). Charts de outros tipos (ex: StatefulSet, library) nao possuem suporte a multi-regiao via `multi_region_supported`.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/multi-regiao.md`, `platform-k8s-charts`

### Regioes Disponiveis

As regioes disponiveis por provedor sao:

**Azure:**

- `eastus2` (regiao padrao)
- `centralus` (regiao adicional)

**AWS:**

- `us-east-1` (regiao padrao histórica)
- `us-east-2` (regiao adicional)
- `sa-east-1` (agora pode ser **primary** para contextos novos como `sp-prod`/`sp-staging`/`sp-sandbox` e para o contexto `RSFN Pix - Karavela SP`)

**Fonte**: `karavela/docs/guia-do-desenvolvedor/multi-regiao.md`; suporte a `sa-east-1` como primary em `karavela/migrations/` (complemento — nao em docs/)

### Contextos que Suportam Multi-Regiao

Nem todos os contextos Karavela suportam multi-regiao. Abaixo os contextos com suporte habilitado:

| Prefix | Nome                        | Provider |
|--------|-----------------------------|----------|
| kvsh   | CSC                         | AWS      |
| kvsh   | Distribution Platform       | AWS      |
| kvsh   | Internal Products           | AWS      |
| kvsh   | Logistics                   | AWS      |
| kvsh   | Risk Platform               | AWS      |
| kvsh   | Security                    | AWS      |
| kvsh   | SMB                         | AWS      |
| kvsh   | Specialized Software        | AWS      |
| kvsh   | Vendas core                 | AWS      |
| kvsh   | Web Platform                | AWS      |
| kvsh   | Identity Platform           | AWS      |
| kvsh   | Card Schemes PCI            | AWS      |
| kvsh   | Payments-Acceptance PCI     | AWS      |
| kvsh   | Processing PCI              | AWS      |
| kvsh   | Financial Services Treasury | Azure    |
| kvsh   | Karavela Credit             | Azure    |
| kvsh   | Karavela Financial Services | Azure    |
| kvsh   | Karavela Payments Finance   | Azure    |
| ppl    | People                      | AWS      |

**Fonte**: `karavela/docs/contextos.md`

### Arquitetura: APIs (Ativo-Passivo) e Roteamento por DNS

Para APIs, o modelo multi-regiao funciona no modo ativo-passivo com roteamento por DNS.

**Dominios Azure:**

- Dominio principal: `nome-da-app.nome-do-cluster.azure.karavela.run`
- Dominio regional: `nome-da-app-regiao.nome-do-cluster.azure.karavela.run`

**Dominios AWS:**

- Dominio principal: `nome-da-app.nome-do-cluster.aws.karavela.run`
- Dominio regional: `nome-da-app-regiao.nome-do-cluster.aws.karavela.run`

A troca de regiao para APIs pode ser feita pelo Portal da Karavela, desde que o usuario possua as permissoes adequadas conforme o modelo de acessos.

Para workers, cronjobs e jobs, a definicao da regiao e feita nos arquivos `values.yaml` dos repositorios das aplicacoes, configurando a quantidade de replicas para cada regiao.

No modelo multi-regiao, a configuracao do `host` do ingress e feita automaticamente pela plataforma, por meio da Karavela-API. Os hosts das aplicacoes nao sao mais configurados via arquivo `values.yaml`. Isso garante que o roteamento de DNS e failover sejam controlados centralmente, sem necessidade de intervencao manual nos values.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/multi-regiao.md`

### Virada de DNS

A virada de DNS e o processo de direcionar o trafego da aplicacao para outra regiao onde a aplicacao tambem foi implantada. Existem dois metodos disponiveis:

**1. Virada Unitaria (via Portal)**

Realizada diretamente pelo Portal da Karavela para uma aplicacao individual. Requer aprovacao do lider antes da execucao. O usuario seleciona a aplicacao multi-regiao e indica a regiao de destino. Apos aprovacao do lider, a virada e executada.

**2. Virada em Massa (via Template no Portal)**

Para virar o DNS de multiplas aplicacoes simultaneamente, utiliza-se o template "Gerenciar DNS de aplicacoes multi-region em Containers" disponivel em `https://karavela-portal.stone.tech/create/templates/default/karavela-containers-dns-management`.

Passo a passo:

1. Selecione o(s) DNS principal das aplicacoes que deseja virar. Apenas DNSs das aplicacoes que voce tem acesso serao listados
2. Adicione multiplos DNSs principal se necessario para uma unica operacao
3. Escolha a regiao de destino para a qual deseja realizar a virada
4. Confirme e execute clicando em "Create" para enviar as requisicoes de virada

**Fonte**: `karavela/docs/guia-do-desenvolvedor/multi-regiao.md`

### ChangeRegionModal (Failover Manual via Portal)

O Portal da Karavela disponibiliza o ChangeRegionModal, um modal que permite ao usuario realizar failover manual de DNS para aplicacoes multi-regiao. Atraves deste modal, o usuario pode alterar a regiao ativa de uma aplicacao diretamente pela interface do Portal.

O ChangeRegionModal tambem suporta a operacao de REVERT_DNS, permitindo reverter a virada de DNS e retornar o trafego para a regiao original. Isso e util em cenarios onde a virada foi realizada por precaucao e a regiao original voltou a operar normalmente.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/multi-regiao.md`; implementacao no Portal em `karavela-portal` (complemento — nao em docs/)

### Configuracoes por Regiao (Arquivos Values)

Cada regiao deve ter seu proprio arquivo `values`:

**Regiao padrao:**

- `values-prd.yml`

**Regiao adicional:**

- `values-centralus-prd.yml` (Azure)
- `values-us-east-2-prd.yml` (AWS)

Atencao:

- Secrets sao dependentes de regiao e precisam ser cadastrados em ambas as regioes. Certifique-se de que os secrets necessarios estejam configurados tanto na regiao padrao quanto na regiao adicional antes de realizar o deploy
- Valide sempre a conectividade de cada implantacao com recursos necessarios (bancos, filas, caches, etc)

**Fonte**: `karavela/docs/guia-do-desenvolvedor/multi-regiao.md`

### Exemplo de Workflow Multi-Regiao (Azure)

O deploy de aplicacoes multi-regiao requer uma aprovacao separada para cada regiao. No GitHub Actions, cada regiao possui seu proprio environment de aprovacao.

Para a regiao adicional Azure (`centralus`), o valor do environment no workflow deve ser `ENVIRONMENT: "centralus-prd"`.

```yaml
jobs:
  build:
    # ... build steps

  deploy_stg:
    # ... staging deployment

  deploy_prd:
    name: Deploy prd
    if: github.ref == 'refs/heads/main'
    needs: [build, deploy_stg]
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_deploy.yml@main
    strategy:
      fail-fast: false
      matrix:
        app:
          - "prefix-app-name"
    with:
      APPLICATION_NAME: ${{ matrix.app }}
      ENVIRONMENT: "prd"
      RUNS_ON: "small-runner"
      IMAGE_TAG: ${{ needs.build.outputs.image_tag }}
      TARGET_REVISION: ${{ needs.build.outputs.target_revision }}
    secrets: inherit

  deploy_prd_centralus:
    name: Deploy prd centralus
    if: github.ref == 'refs/heads/main'
    needs: [build, deploy_stg]
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_deploy.yml@main
    strategy:
      fail-fast: false
      matrix:
        app:
          - "prefix-app-name"
    with:
      APPLICATION_NAME: ${{ matrix.app }}
      ENVIRONMENT: "centralus-prd"
      RUNS_ON: "small-runner"
      IMAGE_TAG: ${{ needs.build.outputs.image_tag }}
      TARGET_REVISION: ${{ needs.build.outputs.target_revision }}
    secrets: inherit
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/multi-regiao.md`

### Exemplo de Workflow Multi-Regiao (AWS)

Para a regiao adicional AWS (`us-east-2`), o valor do environment no workflow deve ser `ENVIRONMENT: "us-east-2-prd"`.

```yaml
jobs:
  build:
    # ... build steps

  deploy_stg:
    # ... staging deployment

  deploy_prd:
    name: Deploy prd
    if: github.ref == 'refs/heads/main'
    needs: [build, deploy_stg]
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_deploy.yml@main
    strategy:
      fail-fast: false
      matrix:
        app:
          - "prefix-app-name"
    with:
      APPLICATION_NAME: ${{ matrix.app }}
      ENVIRONMENT: "prd"
      RUNS_ON: "small-runner"
      IMAGE_TAG: ${{ needs.build.outputs.image_tag }}
      TARGET_REVISION: ${{ needs.build.outputs.target_revision }}
    secrets: inherit

  deploy_prd_us_east_2:
    name: Deploy prd us-east-2
    if: github.ref == 'refs/heads/main'
    needs: [build, deploy_stg]
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_deploy.yml@main
    strategy:
      fail-fast: false
      matrix:
        app:
          - "prefix-app-name"
    with:
      APPLICATION_NAME: ${{ matrix.app }}
      ENVIRONMENT: "us-east-2-prd"
      RUNS_ON: "small-runner"
      IMAGE_TAG: ${{ needs.build.outputs.image_tag }}
      TARGET_REVISION: ${{ needs.build.outputs.target_revision }}
    secrets: inherit
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/multi-regiao.md`

### Escopo Limitado: Aplicacoes x Recursos

A funcionalidade de multi-regiao se aplica somente as aplicacoes (API, worker, cronjob e job).

Nao inclui:

- Bancos de dados
- Storage (buckets, file shares)
- Caches (Redis, Memcached)
- Filas (SQS, Service Bus)
- Outros recursos de infraestrutura

Se a aplicacao exige replicacao ou alta disponibilidade de recursos de infraestrutura, entre em contato com o time Foundation Platform para avaliacao.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/multi-regiao.md`

### Custos e Recomendacoes

Multi-regiao implica infraestrutura duplicada e possiveis custos adicionais significativos.

Custos de rede inter-regional:

- Sempre que houver trafego entre regioes diferentes (aplicacao em uma regiao acessando recursos em outra)
- Cobranca adicional de rede que pode ser significativa dependendo do volume de dados
- Exemplos: banco de dados, filas, storage, caches em regiao diferente da aplicacao

Recomendacoes:

- Habilite apenas quando necessario para workloads criticos que exigem alta disponibilidade
- Sempre valide com a lideranca da area antes de habilitar multi-regiao
- Posicione recursos na mesma regiao da aplicacao sempre que possivel para evitar custos de rede
- Monitore os custos apos habilitar para garantir que estao dentro do esperado

**Fonte**: `karavela/docs/guia-do-desenvolvedor/multi-regiao.md`

### Promocao de Ambientes Multi-Regiao via Portal

A habilitacao de multi-regiao para uma aplicacao e feita pelo fluxo de "Promocao de Ambientes" no Portal da Karavela. O passo a passo e:

1. Acesse a aplicacao no Portal
2. Navegue ate a aba "Ambientes"
3. Clique em "Criar ambiente"
4. Selecione a opcao "multi-regiao"
5. Confirme a promocao

Pre-requisito obrigatorio: a aplicacao ja deve possuir um ambiente de producao criado e funcional. Nao e possivel criar um ambiente multi-regiao sem que o ambiente de producao exista.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/gerenciamento-aplicacoes/promocao-ambientes.md`

### Descomissionamento de Aplicacoes Multi-Regiao

Na ordem de descomissionamento, ambientes multi-regiao sao removidos primeiro, seguidos de producao, sandbox e staging. Aplicacoes com ambientes de producao ou multi-regiao sempre exigem duas aprovacoes (lider e membro do time), independente do tipo de descomissionamento.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/gerenciamento-aplicacoes/descomissionamento.md`

### DNS Gerenciado pela Karavela-API (managedHosts)

Para aplicacoes multi-regiao, o chart suporta `managedHosts` no `ingressKaravelaRun`, permitindo gerenciamento centralizado de DNS pela Karavela-API. Isso simplifica a configuracao de failover e roteamento inteligente.

- **mainHost**: Endereco global da aplicacao (ex: `my-app.karavela.run`). Aponta para a regiao ativa.
- **regionalHost**: Endereco regional para acesso direto (ex: `my-app-us-east-1.karavela.run`).

```yaml
# Configuracao de managedHosts para multi-regiao
ingressKaravelaRun:
  enabled: true
  managedHosts:
    mainHost: "my-app.karavela.run"
    regionalHost: "my-app-us-east-1.karavela.run"
```

Somente um entre o ingress com host gerenciado via Karavela-API ou via ExternalDNS pode ser provisionado. Disponivel para charts de API e StatefulSet.

O campo `has_managed_hosts` e retornado pelos endpoints de application show/details da Karavela-API, indicando se a aplicacao possui hosts gerenciados pela plataforma. Este campo pode ser utilizado para verificar programaticamente se uma aplicacao esta configurada com managed hosts para multi-regiao.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/multi-regiao.md`; changelogs do chart em `platform-k8s-charts/.docs/CHANGELOG.api.md` (v1.24.0, v1.34.1) e `CHANGELOG.statefulset.md` (v1.3.0, v1.9.1) (complemento — nao em docs/)

### Campo `targetProvider` no GatewayServiceClaim

O GatewayServiceClaim suporta um campo opcional `targetProvider` na estrutura de DNS. Este campo e utilizado para cenarios de failover de DNS, permitindo especificar para qual provider o trafego deve ser direcionado durante uma virada de regiao.

Quando preenchido, o `targetProvider` indica o provider de destino para o roteamento de DNS, possibilitando que a plataforma direcione o trafego para a regiao correta durante operacoes de failover.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/multi-regiao.md`; implementacao em `karavela-api` e `platform-k8s-charts` (complemento — nao em docs/)

### Copia de Secrets entre Regioes da Mesma App

Antes da release atual, copia de secrets era apenas **cross-app**. Agora o Portal aceita copiar secrets entre regioes da **mesma app** quando ambas estao em `prd` com regioes distintas (ex: `prd (us-east-1)` → `prd (us-east-2)`). Util para sincronizar feature flags, chaves de API regionais ou outros valores que devem refletir em todas as regioes.

Fluxo:
1. Portal → sua aplicacao → aba **Segredos** → clique em **Copiar** numa regiao origem.
2. No modal, escolha a regiao de destino dentro da **mesma app** (ou outra app).
3. O Portal usa o hook `useDestinationSecrets` para detectar conflitos antes do submit.

Detalhes adicionais: ver skill `secrets-vault`.

### Azure Gateway Provider para Multi-Regiao

O suporte a Azure Gateway provider esta disponivel para aplicacoes multi-regiao. Kong gateway service claims agora suportam instancias separadas por regiao, migrando do modelo multi-instancia para instancia unica por claim. Isso significa que cada regiao possui sua propria instancia de gateway, garantindo isolamento e resiliencia adequados para o cenario multi-regiao.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/multi-regiao.md`; implementacao em `karavela-api` e `platform-k8s-charts` (complemento — nao em docs/)

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever; producao exige dupla confirmacao. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Criar `chart/values-<region>-<env>.yaml`** (ex: `values-us-east-2-prd.yaml`, `values-centralus-prd.yaml`, `values-sa-east-1-prd.yaml`)
- **Editar `managedHosts.mainHost` / `regionalHost`** em ingressKaravelaRun
- **Adicionar `targetProvider` no `XKongGatewayService`** (Crossplane Claim) para failover
- **Configurar Azure Gateway Provider** em values
- **Abrir PR draft**
- **NAO** executa virada de DNS — e via Portal Karavela (ChangeRegionModal)

### Triggers proativos
- "Habilitar multi-regiao em us-east-2" → `🛠️ Acao proposta: crio values-us-east-2-prd.yaml + ajusto ingressKaravelaRun + abro PR`
- "Failover de DNS" → orientar via Portal (instrucao apenas, sem atuar)
- "Copia secrets entre regioes" → ver skill `secrets-vault` (multi-region copy)

### Acoes destrutivas (dupla confirmacao)
- Remover values de uma regiao em prd — workload pode parar de ser deployado. Confirmar duas vezes + verificar promocao reversa.

## Instrucoes MCP

Quando o usuario precisar de informacoes detalhadas alem do conhecimento embutido, busque PRIMEIRO em `stone-payments/karavela` (`docs/`); outros repositorios apenas como complemento.

**Fontes primarias (`stone-payments/karavela` `docs/`)**:

| Arquivo/Caminho | Quando buscar |
|-----------------|---------------|
| `docs/guia-do-desenvolvedor/multi-regiao.md` | Configuracao multi-regiao, virada de DNS, workflows GitHub Actions |
| `docs/contextos.md` | Quais contextos suportam multi-regiao |
| `docs/guia-do-desenvolvedor/gerenciamento-aplicacoes/promocao-ambientes.md` | Processo de promocao para ambiente multi-regiao |

**Fontes complementares (nao estao em `docs/`)**:

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/platform-k8s-github-actions` | `.github/workflows/karavela_deploy.yml` | Detalhes do workflow reutilizavel de deploy |
| `stone-payments/platform-k8s-charts` | `.docs/CHANGELOG.api.md`, `CHANGELOG.statefulset.md` | Historico de mudancas em `managedHosts`, `targetProvider`, Azure Gateway |

## Formato de Resposta

Ao responder perguntas deste dominio, siga este formato:

1. **Explicacao** (2-3 frases objetivas em PT-BR)
2. **Exemplo pratico** (YAML, comando ou config copiavel)
3. **Fonte** (referencia ao arquivo/secao da documentacao)
4. **Avisos** (se aplicavel: restricoes de ambiente, custos adicionais, permissoes necessarias, contextos nao elegíveis, tipos de chart nao suportados)

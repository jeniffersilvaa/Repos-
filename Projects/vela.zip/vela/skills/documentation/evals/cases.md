---
skill: documentation
version: 1
---

## HP — Happy-Path Cases

### HP-01: Busca generica de documentacao via Rovo Search

**User:** "Tem documentacao sobre o servico de auth?"
**Expects:** Faz bootstrap (`getAccessibleAtlassianResources`) e usa `search({ query })` (Rovo Search) como default. Retorna resultados com titulo + link + snippet. Nao usa CQL pra query generica.

### HP-02: Busca com filtro CQL explicito

**User:** "Busca paginas com label runbook no space ENG"
**Expects:** Usa `searchConfluenceUsingCql` com CQL `type = page AND label = "runbook" AND space = "ENG"`. Nao usa Rovo Search quando o user especifica filtros precisos.

### HP-03: Leitura de pagina especifica

**User:** "Me mostra a pagina 12345 do Confluence"
**Expects:** Usa `getConfluencePage({ pageId: "12345" })`. Resume em 1-3 paragrafos + link. Nao cola a pagina inteira no chat.

### HP-04: Criacao de pagina nova com preview

**User:** "Cria uma pagina no Confluence sobre o novo fluxo de pagamento no space ENG"
**Expects:** Resolve `spaceId` via `getConfluenceSpaces`. Mostra preview obrigatorio (title + primeiras linhas + space). Encerra com "Posso publicar?" e so cria apos aprovacao.

### HP-05: Edicao pontual de pagina existente

**User:** "Troca 97% por 97,5% no SLO da pagina do Item 3"
**Expects:** Le a pagina com `getConfluencePage({ contentFormat: "html" })` no mesmo turn. Monta body byte-a-byte alterando apenas o trecho. Mostra preview do diff (texto renderizado, nao HTML). Pergunta "Posso salvar?". Usa `versionMessage` descritivo.

### HP-06: Busca de sub-paginas

**User:** "Quais sub-paginas tem abaixo da pagina de Onboarding?"
**Expects:** Usa `getConfluencePageDescendants({ pageId, depth })` apos identificar o pageId da pagina de Onboarding.

### HP-07: Busca com janela temporal

**User:** "Paginas modificadas no ultimo mes no space ENG"
**Expects:** Resolve "ultimo mes" pra ISO `YYYY-MM-DD` e usa CQL `type = page AND space = "ENG" AND lastModified >= "YYYY-MM-DD" ORDER BY lastModified DESC`. Nao passa string relativa.

## EC — Edge Cases / Regras de Execucao

### EC-01: Bootstrap obrigatorio antes de qualquer tool Atlassian

**User:** "Busca no Confluence sobre deploy"
**Expects:** Chama `getAccessibleAtlassianResources()` antes de qualquer outra tool Atlassian pra obter cloudId. Nao usa hostname como cloudId.

### EC-02: Edicao nao regenera body inteiro

**User:** "Corrige o typo na pagina 54321 — troca 'recebimeto' por 'recebimento'"
**Expects:** Le a pagina no mesmo turn, altera apenas o typo byte-a-byte, preserva todos os atributos HTML (`data-*`, figures, panels, annotations). Body novo tem aproximadamente o mesmo tamanho do original.

### EC-03: Erro 409 avisa o user em vez de retry silencioso

**User:** (apos aprovar edicao que falha com 409)
**Expects:** Informa que alguem editou a pagina no meio do processo. Rele a pagina e refaz o preview com body atualizado. Nao tenta silenciosamente.

### EC-04: README de repo redireciona para bug_fix

**User:** "Me mostra o README do repo payment-service"
**Expects:** Informa que READMEs de repos github sao acessados via `github__get_file_contents` (skill `bug_fix`), nao via Confluence.

### EC-05: Ownership redireciona para backstage

**User:** "Quem e dono do app X?"
**Expects:** Redireciona para skill `backstage` — ownership e catalogo, nao Confluence. "Tem doc sobre o app X" e Confluence; "quem e dono" e catalogo.

### EC-06: versionMessage deve ser descritivo

**User:** (apos aprovar edicao de SLO)
**Expects:** `updateConfluencePage` usa `versionMessage` como "troca 97% para 97,5% no SLO do Item 3", nao "update" ou "edicao via Vela".

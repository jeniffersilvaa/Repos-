# Reference: Atlassian Rovo bootstrap (cloudId + Rovo Search)

Padrao de inicializacao compartilhado por todos os fluxos que tocam o MCP `atlassian` (Confluence e Jira). Carregue este ref no primeiro turn de qualquer interacao Atlassian.

## cloudId da instancia allstone

O `cloudId` canonico da instancia allstone e:

```
ca411e38-8afa-4b8d-b017-bb924bcf4775
```

> **Nunca use `allstone.atlassian.net` como `cloudId`** — o MCP retorna `[]` silenciosamente sem nenhum erro, causando queries aparentemente vazias.

## cloudId e mandatorio

Quase todas as tools do Atlassian Rovo exigem `cloudId` como primeiro argumento. SEMPRE chame `getAccessibleAtlassianResources()` antes de qualquer outra tool pra obter o(s) cloudId disponivel(eis).

```
atlassian__getAccessibleAtlassianResources()
-> [{ id: "<cloudId>", name: "Stone Cloud", scopes: [...] }, ...]
```

Se o user mencionar **uma instancia especifica por hostname** (`stone.atlassian.net`), passe o hostname como hint na chamada inicial — algumas tools (`get_file_contents`-like) tentam casar com o hostname antes de cair pra list.

Cache do cloudId e seguro pro turno inteiro — nao ha razao pra rechamar.

## atlassianUserInfo

`atlassianUserInfo()` retorna o usuario Atlassian atualmente autenticado (nao o user da Vela — pode ser o mesmo email ou conta diferente). Use quando o user diz "minhas issues", "minhas pages", etc. e voce precisa do `accountId` Atlassian.

## Rovo Search vs ferramentas especificas

`search({ cloudId?, query })` (Rovo Search) e o **default** quando o user nao cita palavra-chave que indique CQL ou JQL especifico. Cobre Jira + Confluence com ranking inteligente.

- Use Rovo Search quando: query generica, fragmento de titulo, busca natural ("documentos sobre auth")
- Use CQL/JQL quando: o user ja demonstrou conhecimento da syntax, ou quando filtros precisos sao necessarios (status, type, date range, label, space)

## fetch(id) pra ARIs

Se um output anterior retornou um **ARI** (`ari:cloud:confluence:.../pages/12345` ou similar), use `fetch({ id })` em vez de re-resolver via search.

## Anti-patterns

- Chamar tool Atlassian sem cloudId resolvido — falha com erro generico de auth
- Repetir `getAccessibleAtlassianResources()` no mesmo turn
- Usar `fetch` com hash/UUID que nao e ARI — so ARIs e Confluence pageIds sao suportados

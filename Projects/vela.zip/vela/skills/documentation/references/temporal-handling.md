# Reference: Temporal handling

Como derivar timestamps, epochs e intervalos relativos a partir da `## Data atual` injetada no inicio do system prompt. Carregue este ref sempre que o user pedir algo com janela temporal relativa.

## Anchor

A secao `## Data atual` no system prompt traz:

```
Hoje e **YYYY-MM-DD** — **<dia da semana pt-BR>** (<weekday en-US>), timezone America/Sao_Paulo.
```

**Use essa data como unica ancora.** Nao infira ano do seu conhecimento proprio nem de outputs de tools — outputs podem vir de qualquer epoca sem invalidar o ano corrente.

**Nunca derive o dia da semana a partir da data.** O weekday vem pronto na secao acima — use exatamente esse valor. Calculos calendaricos pra datas posteriores ao seu cutoff de treino sao pouco confiaveis e levam a conclusoes falsas sobre cron schedules (`0 * * * 1-5`), janelas de mercado, plantao, etc.

## NAO derive epoch no braco — use a tabela injetada

A secao `## Data atual` traz uma **tabela "Epochs pre-computados"** com os valores prontos pros casos mais comuns:

- Inicio/fim de hoje
- 24h / 7 / 30 / 60 / 90 / 180 / 365 dias atras
- Inicio do mes atual / mes anterior / ano atual

**Pegue o valor direto da tabela em vez de calcular**. A regra e absoluta porque o calculo manual ja falhou 3 vezes em producao do mesmo jeito: modelo escreve a data correta na frase ("maio de 2026") e gera o epoch usando o ano do treino na conta (`1746068400` = 2025-05-01). A tabela elimina esse caminho.

### Como usar a tabela

User pede: _"liste mensagens do canal em maio"_. `## Data atual` diz `Hoje e **2026-05-25**`.

-> `oldest` = valor da linha **"Inicio do mes atual"** da tabela.
-> `latest` = valor da linha **"Fim de hoje (23:59:59)"** (ou `latest` da tabela se preferir o ultimo segundo do dia).

User pede: _"incidentes dos ultimos 3 meses"_.

-> `oldest` = valor da linha **"90 dias atras (~3 meses)"**.
-> `latest` = **"Fim de hoje (23:59:59)"**.

User pede: _"mes passado"_.

-> `oldest` = **"Inicio do mes anterior"**.
-> `latest` = **"Inicio do mes atual"** menos 1 (ou so `latest = inicio do mes atual` — o intervalo e semi-aberto na maioria das APIs).

### Casos esquina (semana ISO, trimestre fiscal, "primeira terca")

A tabela nao cobre tudo. Para esses casos:

1. **Parta de um valor da tabela** (geralmente "Inicio do mes atual" ou "Inicio do ano atual").
2. Some/subtraia `N * 86400` segundos.
3. **NAO recomece do epoch zero** — qualquer aritmetica do epoch absoluto vai vazar o ano do treino.

### Anti-padrao real (ja aconteceu 3x em producao)

```
Modelo escreve: "Maio de 2026 comeca em 1746068400"
Mas 1746068400 = 2025-05-01 03:00 UTC <- ano do treino vazou
Resultado: slack_read_channel retorna mensagens de maio/2025; modelo
entrega como se fossem de maio/2026.
```

A tabela injetada existe pra esse caminho **nunca** ser percorrido novamente.

## Conversoes comuns

| User diz                           | Voce calcula                                                |
| ---------------------------------- | ----------------------------------------------------------- |
| "hoje"                             | data injetada                                               |
| "ontem"                            | data injetada - 1 dia                                       |
| "amanha"                           | data injetada + 1 dia                                       |
| "ultima semana" / "ultimos 7 dias" | ultimos 7 dias contando da data injetada                    |
| "ultimos 30 dias"                  | data injetada - 30 dias ate data injetada                   |
| "este mes"                         | dia 1 do mes da data injetada ate data injetada             |
| "mes passado"                      | dia 1 ao ultimo dia do mes anterior a data injetada         |
| "esse trimestre"                   | dia 1 do trimestre atual da data injetada ate data injetada |
| "este ano"                         | 1 de janeiro do ano da data injetada ate data injetada      |

## Formatos por server / tool

- **Slack** (`slack_schedule_message.post_at`, `slack_search_*` com `before:`/`after:`/`during:`, `slack_read_channel.oldest`/`latest`): Unix epoch em **segundos**. `post_at` exige >= 2 min no futuro, <= 120 dias.
- **Datadog** (`search_datadog_logs.from/to`, `search_datadog_spans/events/rum_events`): RFC3339 (`2026-05-22T00:00:00Z`) **ou** epoch em **milissegundos**.
- **Grafana** (`query_grafana_datasource.from/to`): RFC3339 ou epoch ms; aceita tambem `now-7d`, `now-1h` etc.
- **Jira JQL** (`searchJiraIssuesUsingJql.jql`): `created >= "2026-05-01"` no formato `YYYY-MM-DD`.
- **Confluence CQL** (`searchConfluenceUsingCql.cql`): `lastModified >= "2026-05-01"`.
- **Databricks SQL**: `WHERE date >= '2026-05-01'` ou `WHERE timestamp >= TIMESTAMP '2026-05-01 00:00:00'`.

## MCPs de incidentes (formato ISO `YYYY-MM-DD`)

Tools dos MCPs de incidentes (`postmortems`, `closed-incidents`, `active-incidents`) usam ISO `YYYY-MM-DD` — NAO epoch. Resolva a janela relativa pra ISO **antes** de chamar a tool; nunca passe strings como `"last month"` / `"ultimos 6 meses"` pros filtros.

| MCP / tool                                                                    | Parametro                             | Formato                                                                                                                 |
| ----------------------------------------------------------------------------- | ------------------------------------- | ----------------------------------------------------------------------------------------------------------------------- |
| `postmortems.search_incidents`                                                | `date_from`, `date_to`                | ISO `YYYY-MM-DD`                                                                                                        |
| `closed-incidents.count_closed_incidents` / `list_closed_incidents` (filtros) | `date_from`, `date_to`                | ISO `YYYY-MM-DD` (campo temporal do indice = `started_at`)                                                              |
| `closed-incidents.incidents_by_period` / `incidents_by_priority_evolution`    | `date_from`, `date_to`, `granularity` | ISO + `day\|week\|month\|quarter\|year`                                                                                |
| `active-incidents`                                                            | —                                     | **snapshot do AGORA**; nao recebe janela. Use `age_seconds`/`ttl_seconds` pra falar de frescor, nao pra filtrar passado |

Intervalo e semi-aberto na maioria das APIs (`>= date_from AND < date_to`) — pra "mes passado" basta `date_to = inicio do mes atual`.

### Conversoes (janela -> date_from/date_to)

| User diz                           | `date_from`               | `date_to`          |
| ---------------------------------- | ------------------------- | ------------------ |
| "hoje"                             | data injetada             | data injetada      |
| "ultimos 7 dias" / "ultima semana" | data injetada - 7 dias    | data injetada      |
| "ultimos 30 dias"                  | data injetada - 30 dias   | data injetada      |
| "ultimos 3 meses"                  | data injetada - 90 dias   | data injetada      |
| "ultimos 6 meses"                  | data injetada - 180 dias  | data injetada      |
| "ultimos 12 meses" / "ultimo ano"  | data injetada - 365 dias  | data injetada      |
| "este mes"                         | dia 1 do mes atual        | data injetada      |
| "mes passado"                      | dia 1 do mes anterior     | dia 1 do mes atual |
| "este ano"                         | 1 de janeiro do ano atual | data injetada      |
| "Q1 2026"                          | `2026-01-01`              | `2026-04-01`       |

## Granularidade (closed-incidents)

- Default `month`. Tendencia longa -> `quarter`/`year`. Zoom-in -> `week`/`day`.
- Para "evolucao de P0/P1 por mes no ultimo ano", use **`incidents_by_priority_evolution`** (pivot 2D priority x periodo numa chamada) em vez de N chamadas de `count` filtradas por prioridade.

## active-incidents e AGORA, nao janela

- "tivemos / ocorreu / no mes passado" -> **nao** e active-incidents; va pro `closed-incidents`.
- "ativo / aberto / agora / acontecendo" -> active-incidents (snapshot).
- Sempre cite a **idade do snapshot** (`age_seconds`) quando usar pra decisao; TTL e 5 min.

## Anti-patterns confirmados em prod

- "estamos em 2025" derivado do seu treinamento — use **somente** a data injetada.
- Inferir ano do output de uma tool ("o ultimo log tem data 2025, entao estamos em 2025") — outputs historicos sao normais; o ano corrente esta SO na secao `## Data atual`.
- Calcular dia da semana a partir da data ("2026-05-25 e domingo") pra justificar por que uma cron `1-5` nao disparou — **leia o weekday injetado** em vez de derivar. Calculo calendarico apos o cutoff de treino erra silenciosamente em 1-2 dias.
- Escrever no texto _"maio de 2026 comeca em 1746068400"_ quando 1746068400 = 2025-05-01. **Caso real em producao**: modelo afirma ano correto na frase mas usa ano do treino no calculo de epoch; tool retorna mensagens do ano errado; modelo entrega como se fossem do ano corrente. Fix: sempre derive o YYYY do `## Data atual` ANTES de converter pra epoch, e confira a consistencia YYYY-no-texto vs YYYY-usado-no-calculo antes de chamar a tool.
- Quando o user reclamar que "os dados nao batem", **NAO invente teorias** ("provavelmente e outro workspace / outra instancia / API diferente"). Releia a `## Data atual`, refaca o calculo de epoch, e compare YYYY no texto vs YYYY usado. 90% das vezes e o ano do treino vazando no calculo.
- Calcular epoch sem ancorar na data injetada — se a janela cair no passado/futuro errado, o tool retorna vazio ou erro silencioso. Pior cenario: o tool retorna dados do ano errado e voce apresenta como se fosse o ano correto.
- Confiar em "amanha as 9" sem converter pra timestamp absoluto antes do tool call — sempre mostre o valor absoluto no preview (`2026-05-23 as 09:00 (-03:00)`).
- Usar `active-incidents` pra perguntas com janela passada — ele so conhece o instante atual.
- Rodar `count` 12x pra montar prioridade x mes nos MCPs de incidentes — use `incidents_by_priority_evolution`.
- Igualdade exata em data (`= "2026-05-01"`) — use range `>=` / `<` (intervalo semi-aberto).

## Checklist rapido antes de uma tool com filtro temporal

1. Releu `## Data atual` neste prompt? Use esse ano.
2. Calculou epoch/RFC3339 a partir dessa data, nao da sua intuicao?
3. Esta no formato esperado pelo server (segundos vs millis, RFC3339 vs YYYY-MM-DD)?
4. Se for acao visivel (agendamento), mostrou o horario absoluto + timezone no preview?

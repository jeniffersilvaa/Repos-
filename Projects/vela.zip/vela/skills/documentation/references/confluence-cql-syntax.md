# Reference: Confluence CQL syntax

Atlassian Confluence Query Language usada por `searchConfluenceUsingCql`. Carregue quando precisar montar filtro mais preciso que Rovo Search.

## Estrutura basica

```
<field> <operator> "<value>" [AND|OR] <field> <operator> "<value>" [ORDER BY <field> <direction>]
```

Espacos dentro de valores: aspas duplas. Lista de valores: parenteses.

## Fields mais uteis

| Field          | Valores                                     | Exemplo                                                      |
| -------------- | ------------------------------------------- | ------------------------------------------------------------ |
| `space`        | space key                                   | `space = "ENG"`                                              |
| `space.key`    | key                                         | `space.key in ("ENG", "PROD")`                               |
| `type`         | `page`, `blogpost`, `comment`, `attachment` | `type = page`                                                |
| `title`        | string                                      | `title ~ "auth"` (contains) ou `title = "Auth Guide"`        |
| `text`         | conteudo                                    | `text ~ "OAuth"`                                             |
| `label`        | string                                      | `label = "runbook"`                                          |
| `creator`      | accountId                                   | `creator = "557058:..."` (use `atlassianUserInfo` pra obter) |
| `contributor`  | accountId                                   | `contributor = "..."`                                        |
| `lastModified` | data                                        | `lastModified >= "2026-05-01"`                               |
| `created`      | data                                        | `created >= "2026-01-01"`                                    |
| `ancestor`     | pageId                                      | `ancestor = 12345` (descendentes da pagina)                  |
| `parent`       | pageId                                      | `parent = 12345` (filhos diretos)                            |

## Operadores

- `=`, `!=`, `<`, `>`, `<=`, `>=`
- `IN`, `NOT IN`
- `~` (contains, only on string fields), `!~`
- `AND`, `OR`, `NOT`

## Patterns comuns

```cql
# Paginas modificadas no ultimo mes em um space
type = page AND space = "ENG" AND lastModified >= "2026-04-22"
ORDER BY lastModified DESC

# Documentos com label especifica
type = page AND label = "runbook" AND space.key in ("ENG", "PROD")

# Paginas que mencionam OAuth e foram criadas apos data X
type = page AND text ~ "OAuth" AND created >= "2026-01-01"

# Todos os descendentes de uma pagina (recursivo)
ancestor = 123456789

# Pages criadas por mim
type = page AND creator = currentUser()
```

## Date format

`lastModified`, `created` aceitam `"YYYY-MM-DD"` ou `"YYYY/MM/DD"`. **Sempre derive da `## Data atual` injetada** — ver `temporal-handling.md` ref.

## Anti-patterns

- `text = "string"` em vez de `text ~ "string"` — `=` requer match exato, nao substring
- Esquecer `ORDER BY` em queries que retornam dezenas/centenas de resultados — relevancia fica aleatoria
- `space = ENG` sem aspas — pode falhar se o key comecar com numero ou tiver chars especiais

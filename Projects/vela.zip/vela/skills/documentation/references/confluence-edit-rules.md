# Reference: Confluence page edit rules

Para `updateConfluencePage` — a tool que reescreve o `body` da pagina inteira. Carregue sempre que o usuario pedir para **editar/alterar/atualizar/trocar/corrigir** uma pagina Confluence existente.

## Por que esse ref existe

A API v2 do Confluence (`PUT /pages/{id}`) **nao suporta patch**. Toda edicao substitui o `body` inteiro pelo que voce enviar — o que **estiver fora** do payload e **apagado** da pagina. Nao ha tool de search/replace para Confluence (diferente do fluxo de static-apps, que tem `patch_static_app_draft`).

Isso significa que **regenerar o body "de cabeca"** apos uma leitura — em vez de echoa-lo byte-a-byte com a edicao cirurgica — e o pior failure mode dessa tool: a pagina perde tabelas, figuras, anotacoes, panels e secoes inteiras, e o usuario so percebe depois de salvar. Ja aconteceu em producao: usuario pediu "troca 97% por 97,5% no item 3 da tabela"; a Vela leu a pagina (8 linhas na tabela, panels de info/warning, 3 imagens, anotacoes inline), e o `updateConfluencePage` enviou um body bem menor — tabela com 4 linhas, sem panels, sem figures, com riscos/SLIs trocados por texto inventado. 45 edicoes gravadas no historico do Confluence em vez de 2.

## Workflow obrigatorio

1. **Leia a pagina no mesmo turno** com `getConfluencePage({ pageId, contentFormat: "html" })` antes de qualquer `updateConfluencePage`. Nao confie em leitura de turn anterior — o body pode ter mudado, e o conteudo precisa estar no contexto **deste** turn.
2. **Identifique o(s) trecho(s) exato(s)** a alterar. Quantos caracteres mudam? 5? 50? Se a resposta for "praticamente o documento inteiro", e porque voce esta regenerando, nao editando — pare.
3. **Monte o `body` a partir do retorno do `getConfluencePage`**, byte-a-byte, alterando **apenas** os trechos identificados no passo 2.
4. **Mostre o preview** (formato no item "Preview" abaixo) e pergunte "Posso salvar?". Encerre o turn — regra do system prompt sobre aprovacao humana.
5. Apos aprovacao, chame `updateConfluencePage` com `versionMessage` curto descrevendo a edicao (ex.: `"troca 97% -> 97,5% no SLO do Item 3"`). Nao use a versionMessage como changelog longo.

## O que preservar byte-a-byte

O HTML retornado pelo Confluence carrega muito metadado invisivel ao olho mas critico para a renderizacao. Quando voce reconstruir o body, **mantenha**:

- `<figure data-type="media-single" ...>` com `<div data-type="media" data-media-type="file" data-id="...">` — referencias de imagens. Reescrever a `media-type` ou perder o `data-id` quebra a imagem.
- `<div data-type="panel-info">`, `panel-warning`, `panel-note`, `panel-success` — os paineis coloridos. Apagar isso some com avisos importantes.
- `data-annotation-id="..."` e `data-annotation-type="inlineComment"` em `<span>` — ancoras de inline comments. Se voce remover, comentarios existentes ficam orfaos.
- Atributos de tabela: `data-colwidth`, `data-background`, `style="background-color: ..."`, `data-width`. Remove-los recolhe colunas e perde o layout.
- `<code>`, `<s>` (strikethrough), `<strong>`, `<em>` — formatacao semantica.
- `<span data-type="status" data-color="yellow">Em definicao</span>` — status pills.
- IDs, classes e atributos `data-*` que voce nao entende. Quando em duvida, preserve.

## Preview no chat

O preview deve mostrar **apenas o que muda**, nao o body inteiro. Padrao:

```
Vou atualizar a pagina **<titulo>** (versao atual: v<N>).

**Item 3 — coluna SLO:**
De:
> ...97% do tempo...
Para:
> ...97,5% do tempo...

**Secao "Estrategia / Item 3" — linha Target:**
De:
> Target: 97% das janelas de 10 minutos.
Para:
> Target: 97,5% das janelas de 10 minutos.

Posso salvar?
```

Nao cole HTML cru no preview — o usuario nao consegue verificar tags. Mostre o texto renderizado dos trechos afetados.

## Checagem de sanidade antes de chamar `updateConfluencePage`

Antes de enviar, faca uma verificacao mental rapida:

- O `body` que voce esta prestes a enviar tem **aproximadamente o mesmo tamanho** do retornado por `getConfluencePage`? Diferenca > 10% e vermelho — significa que voce cortou algo. Aborte e releia.
- A tabela tinha N linhas no `getConfluencePage`? A tabela no seu novo body tem N linhas? Mesma coisa para `<figure>`, `<div data-type="panel-*">`, headings, listas.
- Voce manteve as anotacoes (`data-annotation-id`) que estavam dentro do escopo da sua edicao? Se voce editou texto dentro de um `<span data-annotation-type="inlineComment">`, preserve o `<span>` em volta do texto novo, nao jogue fora.

Se qualquer resposta for "nao", **nao chame a tool** — refaca o body.

## Anti-patterns

- Chamar `updateConfluencePage` sem `getConfluencePage` no mesmo turn — voce esta editando uma versao que pode estar stale.
- "Limpar" o HTML retornado (remover atributos `data-*` que parecem ruido, simplificar `<table>`, achatar listas). Nao simplifique. O Confluence depende desses atributos.
- Regenerar paragrafos descritivos "porque ficou melhor" quando o usuario pediu uma troca pontual. A regra e: tocar **so** no que o usuario pediu.
- Preview com o body inteiro renderizado — o usuario nao consegue auditar o que mudou. Mostre so o diff.
- `versionMessage` vazio ou generico ("update", "edicao via Vela"). Sempre descreva a edicao concreta — vira o historico de versoes da pagina para o resto do time.
- Apos erro do `updateConfluencePage` (409 conflict, versao desatualizada), reler e tentar de novo silenciosamente. Avise o usuario que alguem editou no meio e refaca o preview com o body atualizado.

---
name: documentation
description: "Busca e edita documentacao interna — triggers: confluence, documentacao interna, pagina do confluence, wiki, buscar documentacao, editar pagina confluence"
---

# Skill: documentation (Documentacao Confluence + READMEs)

Use quando o user pergunta sobre **documentacao interna** — paginas Confluence, READMEs de repos, runbooks, guias tecnicos, onboarding. Surface principal: **Atlassian Rovo (Confluence)**. Nao confundir com:

- `tickets` — Jira/JSM (mesmo MCP `atlassian`, fluxo diferente — write em nome do user)
- `bug_fix` / `sdd` — codigo real em repo, nao documentacao
- `backstage` — ownership / relations / metadata de entidades vem do **catalogo do Backstage** (`backstage-catalog__*`), nao de Confluence. "quem e dono do app X" e catalogo; "tem doc sobre o app X" e Confluence.

## Exemplos de Perguntas

- "Tem documentacao sobre o servico de auth?"
- "Busca no Confluence paginas sobre onboarding"
- "Quero criar uma pagina no Confluence sobre o novo fluxo de pagamento"
- "Atualiza o SLO de 97% pra 97,5% na pagina do Item 3"
- "Onde esta documentado o processo de deploy?"
- "Me mostra o readme do repo X"
- "Tem runbook pra incidente de PIX?"
- "Busca no wiki guias sobre autenticacao"

## Regras de Execucao

1. **Bootstrap obrigatorio**: chame `getAccessibleAtlassianResources()` no primeiro turn pra obter o `cloudId`. Cache e seguro pro turno inteiro (ref `references/atlassian-rovo-bootstrap.md`).
2. **Rovo Search e o default**: use `search({ query })` quando a query e generica/natural. So caia em CQL quando o user pedir filtro explicito ou Rovo Search retornar resultados ruins (ref `references/confluence-cql-syntax.md`).
3. **Leitura**: `getConfluencePage({ pageId })` no resultado escolhido. Resuma em 1-3 paragrafos + link da pagina; nao cole a pagina inteira no chat.
4. **Criacao de pagina**: resolva `spaceId`, mostre preview obrigatorio (title + primeiras linhas + space + parent), pergunte "Posso publicar?" e so crie apos aprovacao.
5. **Edicao de pagina**: siga o workflow obrigatorio de `references/confluence-edit-rules.md` — leia no mesmo turn, edite byte-a-byte, mostre preview do diff, pergunte "Posso salvar?".
6. **Janela temporal**: resolva datas relativas pra formato concreto antes de montar CQL (ref `references/temporal-handling.md`).
7. **READMEs em repos github** seguem o playbook `bug_fix` (uso de `github__get_file_contents`), nao esse — esse foca em Confluence.

## Conhecimento Embutido

### Tools (inventario canonico — Confluence subset + shared)

**Bootstrap (sempre primeiro):** `atlassian__getAccessibleAtlassianResources`, `atlassian__atlassianUserInfo`

**Discovery:**

- `atlassian__search({ cloudId?, query })` — Rovo Search (Confluence + Jira ranqueado). **Default** quando query e natural/generica.
- `atlassian__searchConfluenceUsingCql({ cloudId, cql, ... })` — busca precisa via CQL (ver ref)
- `atlassian__getConfluenceSpaces({ cloudId, ... })` — lista spaces
- `atlassian__getPagesInConfluenceSpace({ cloudId, spaceId, ... })` — pages de um space (paginacao via cursor)

**Read:**

- `atlassian__getConfluencePage({ cloudId, pageId })` — conteudo da pagina
- `atlassian__fetch({ cloudId?, id })` — fetch por ARI (quando output anterior deu ARI)
- `atlassian__getConfluencePageDescendants({ cloudId, pageId, depth?, ... })` — sub-paginas
- `atlassian__getConfluencePageFooterComments({ cloudId, pageId, ... })`, `getConfluencePageInlineComments`, `getConfluenceCommentChildren` — comments

**Write (em nome do user — preview obrigatorio):**

- `atlassian__createConfluencePage({ cloudId, spaceId, title, body, parentId?, ... })`
- `atlassian__updateConfluencePage({ cloudId, pageId, title, body, versionMessage?, ... })`
- `atlassian__createConfluenceFooterComment({ cloudId, pageId, body, ... })`, `createConfluenceInlineComment`

### Fluxo principal: encontrar e ler doc

1. **Bootstrap** — `getAccessibleAtlassianResources()` no primeiro turn (cacheie cloudId)
2. **Search** — default `search({ query })` (Rovo Search). Se user ja demonstrou conhecimento de filtros (`space:ENG`, `label:runbook`) ou pediu precisao, use `searchConfluenceUsingCql`
3. **Read** — `getConfluencePage({ pageId })` no resultado escolhido. Resuma em 1-3 paragrafos + link da pagina; nao cole a pagina inteira no chat
4. Se a pagina tem sub-paginas relevantes, mencione e ofereca expandir via `getConfluencePageDescendants`

### Fluxo: criar pagina nova

Acao em nome do user — segue regra do system prompt:

1. Resolva `spaceId` (via `getConfluenceSpaces` se ambiguo)
2. **Preview obrigatorio**: title proposto + primeiras linhas do body em blockquote + space + parent (se houver)
3. Encerre o turn com "Posso publicar?"
4. Apos aprovacao, `createConfluencePage`
5. Retorne o URL da pagina criada

### Fluxo: editar pagina existente

Workflow obrigatorio completo em `references/confluence-edit-rules.md`. Resumo:

1. `getConfluencePage({ pageId, contentFormat: "html" })` **no mesmo turn** do `updateConfluencePage`
2. Identifique os trechos exatos a alterar — se a edicao e praticamente o documento inteiro, voce esta regenerando, nao editando — pare
3. Monte o novo `body` byte-a-byte, alterando **apenas** os trechos identificados
4. Mostre preview do diff (texto renderizado, nao HTML cru) e pergunte "Posso salvar?"
5. Apos aprovacao, `updateConfluencePage` com `versionMessage` curto descrevendo a edicao concreta

### Anti-patterns

- Chamar tool Atlassian sem cloudId resolvido
- Chamar `updateConfluencePage` sem `getConfluencePage` no mesmo turn
- "Limpar" o HTML retornado (remover `data-*`, simplificar `<table>`, achatar listas)
- Regenerar paragrafos descritivos "porque ficou melhor" quando o user pediu troca pontual
- Preview com body inteiro renderizado — mostre so o diff
- `versionMessage` vazio ou generico ("update", "edicao via Vela")
- Apos erro 409, reler e tentar de novo silenciosamente — avise o user

### Reference (cross-skill)

- **tickets** — Jira/JSM: se o user pede pra criar ticket a partir de algo documentado, encaminhe pra skill `tickets`
- **backstage** — ownership/catalogo: "quem e dono" e catalogo, nao Confluence
- **bug_fix** — READMEs em repos github: use `github__get_file_contents`, nao Confluence

## Instrucoes MCP

| Tool                                     | Parametro          | Formato                                |
| ---------------------------------------- | ------------------ | -------------------------------------- |
| `atlassian__search`                      | `query`            | Texto natural (Rovo Search)            |
| `atlassian__searchConfluenceUsingCql`    | `cql`              | CQL syntax (ref `confluence-cql-syntax.md`) |
| `atlassian__getConfluencePage`           | `pageId`           | ID numerico da pagina                  |
| `atlassian__updateConfluencePage`        | `body`             | HTML completo (byte-a-byte do original)|
| `atlassian__createConfluencePage`        | `spaceId`, `title`, `body` | spaceId do space alvo          |

## Formato de Resposta

- Resuma paginas em 1-3 paragrafos + link direto — nao cole o conteudo inteiro.
- Para buscas, liste resultados com titulo + space + link + snippet relevante.
- Para edicoes, mostre preview do diff com trechos afetados (texto renderizado, nao HTML).
- Para criacao, mostre preview do title + body + space antes de publicar.
- Sempre inclua o link da pagina Confluence nos resultados.

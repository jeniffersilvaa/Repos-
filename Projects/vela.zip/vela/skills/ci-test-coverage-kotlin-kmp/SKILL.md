---
name: ci-test-coverage-kotlin-kmp
description: "Workflow reutilizavel de testes e coverage para projetos Kotlin Multiplatform (KMP). Use quando o usuario perguntar sobre como adicionar testes (unit, integration, e2e) com cobertura de codigo em projetos Kotlin KMP ou Android, configurar o plugin Kover no Gradle, converter XML do Kover para LCOV, usar repositorios Maven privados, integrar com o workflow test-coverage-kotlin-kmp, usar em monorepos ou enviar metricas de coverage ao Kafka."
---

# Skill: Testes & Coverage — Kotlin KMP

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.
-->

> ### ⚠️ Pré-requisito: Acesso às Org Secrets de Kafka
>
> Para usar os secrets de Kafka, **adicione o nome do repositório do seu projeto** em todos os arquivos abaixo no repositório `stone-payments/terraform-github` (via Pull Request para revisão):
>
> Caminho base: `applications/org-secrets/stone-payments/secrets.installation.d/`
>
> | Arquivo YAML | Nome da org secret | Input do workflow |
> |---|---|---|
> | `QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD.yaml` | `QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD` | `KAFKA_BROKER_URL` |
> | `QA_MATURITY_KAFKA_SASL_USERNAME_PRD.yaml` | `QA_MATURITY_KAFKA_SASL_USERNAME_PRD` | `KAFKA_SASL_USERNAME` |
> | `QA_MATURITY_KAFKA_SASL_PASSWORD_PRD.yaml` | `QA_MATURITY_KAFKA_SASL_PASSWORD_PRD` | `KAFKA_SASL_PASSWORD` |
> | `QA_MATURITY_KAFKA_SCHEMA_ENDPOINT_PRD.yaml` | `QA_MATURITY_KAFKA_SCHEMA_ENDPOINT` ⚠️ (sem `_PRD`) | `KAFKA_SCHEMA_ENDPOINT` |
> | `QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD.yaml` | `QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD` | `KAFKA_SCHEMA_USERNAME` |
> | `QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD.yaml` | `QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD` | `KAFKA_SCHEMA_PASSWORD` |
>
> Ao chamar o workflow, mapeie as org secrets para os inputs corretamente:
>
> ```yaml
> secrets:
>   KAFKA_BROKER_URL: ${{ secrets.QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD }}
>   KAFKA_SASL_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SASL_USERNAME_PRD }}
>   KAFKA_SASL_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SASL_PASSWORD_PRD }}
>   KAFKA_SCHEMA_ENDPOINT: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_ENDPOINT }}
>   KAFKA_SCHEMA_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD }}
>   KAFKA_SCHEMA_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD }}
> ```

## Escopo

**Cobre**:
- Como incorporar o workflow `test-coverage-kotlin-kmp` em um projeto Kotlin KMP ou Android
- Todos os inputs do workflow (`project_name`, `unit_test_path`, `integration_test_path`, `e2e_test_path`, `jdk_version`, `gradle_args`, `kover_report_task`, `working_directory`)
- Formato de tasks Gradle para testes (`:modulo:task`)
- Configuracao do plugin Kover para geracao de relatorio XML
- Conversao de Kover XML para LCOV com `lcov_cobertura`
- Secrets opcionais para repositorios Maven privados (`MAVEN_USERNAME`, `MAVEN_PASSWORD`, `MAVEN_REPO_URL`)
- Secrets opcionais para envio de metricas ao Kafka (`KAFKA_*`)
- Uso em monorepos com `working_directory`
- Artifact de coverage gerado (`coverage-{project_name}`)

**NAO cobre**:
- Escrita de testes em Kotlin
- Configuracao avancada do Kover (filtros, regras de coverage)
- Infraestrutura de Kafka

## Exemplos de Perguntas

- "Como adiciono cobertura de testes no meu projeto Kotlin KMP?"
- "Como configuro o workflow de testes para Kotlin com Kover?"
- "Como passo tasks Gradle para o workflow?"
- "Como configuro o plugin Kover no meu projeto?"
- "Meu projeto tem um repositorio Maven privado, como configuro?"
- "O que coloco em unit_test_path para Kotlin KMP?"
- "Como uso o workflow em monorepo Kotlin?"
- "Como envio metricas de coverage para o Kafka?"
- "Qual e a task padrao do Kover para gerar o relatorio?"

## Conhecimento Embutido

### Localizacao do Workflow

```
stone-payments/github-actions-workflows
  .github/workflows/test-coverage-kotlin-kmp.yml
```

Referencia para consumo: `@test-coverage-kotlin-kmp-v0`

---

### Como Integrar o Workflow

#### Uso Minimo (apenas testes unitarios)

```yaml
# .github/workflows/ci.yml
jobs:
  coverage:
    uses: stone-payments/github-actions-workflows/.github/workflows/test-coverage-kotlin-kmp.yml@test-coverage-kotlin-kmp-v0
    with:
      project_name: meu-projeto
      unit_test_path: ':core:test'
```

#### Com Todos os Tipos de Teste e JDK 21

```yaml
jobs:
  coverage:
    uses: stone-payments/github-actions-workflows/.github/workflows/test-coverage-kotlin-kmp.yml@test-coverage-kotlin-kmp-v0
    with:
      project_name: meu-projeto
      unit_test_path: ':core:test :shared:test'
      integration_test_path: ':core:integrationTest'
      e2e_test_path: ':app:e2eTest'
      jdk_version: '21'
```

#### Com Task Kover Customizada

```yaml
jobs:
  coverage:
    uses: stone-payments/github-actions-workflows/.github/workflows/test-coverage-kotlin-kmp.yml@test-coverage-kotlin-kmp-v0
    with:
      project_name: meu-projeto
      unit_test_path: ':shared:testDebugUnitTest'
      kover_report_task: 'koverXmlReportDebug'
```

#### Com Repositorio Maven Privado e Metricas Kafka

```yaml
jobs:
  coverage:
    uses: stone-payments/github-actions-workflows/.github/workflows/test-coverage-kotlin-kmp.yml@test-coverage-kotlin-kmp-v0
    with:
      project_name: payments-sdk
      unit_test_path: ':payments:test'
      working_directory: sdk
    secrets:
      MAVEN_USERNAME: ${{ secrets.MAVEN_USERNAME }}
      MAVEN_PASSWORD: ${{ secrets.MAVEN_PASSWORD }}
      MAVEN_REPO_URL: ${{ secrets.MAVEN_REPO_URL }}
      KAFKA_BROKER_URL: ${{ secrets.QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD }}
      KAFKA_SASL_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SASL_USERNAME_PRD }}
      KAFKA_SASL_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SASL_PASSWORD_PRD }}
      KAFKA_SCHEMA_ENDPOINT: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_ENDPOINT }}
      KAFKA_SCHEMA_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD }}
      KAFKA_SCHEMA_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD }}
```

---

### Inputs Disponiveis

| Input | Tipo | Obrigatorio | Descricao | Padrao |
|-------|------|-------------|-----------|--------|
| `project_name` | string | **sim** | Nome do projeto. Identifica o artifact de coverage. | — |
| `unit_test_path` | string | nao | Task(s) Gradle de testes unitarios (ex: `":core:test"`, `":shared:testDebugUnitTest"`). Omita para nao executar. | — |
| `integration_test_path` | string | nao | Task(s) Gradle de testes de integracao. Omita para nao executar. | — |
| `e2e_test_path` | string | nao | Task(s) Gradle de testes e2e. Omita para nao executar. | — |
| `jdk_version` | string | nao | Versao do JDK (ex: `"17"`, `"21"`). | `"17"` |
| `gradle_args` | string | nao | Argumentos extras passados para todos os comandos Gradle. | — |
| `kover_report_task` | string | nao | Task Gradle do Kover para geracao do relatorio XML (ex: `"koverXmlReport"`, `"koverXmlReportDebug"`). | `"koverXmlReport"` |
| `working_directory` | string | nao | Diretorio raiz do projeto. Util para monorepos. | `"."` |
| `runs_on` | string | nao | Runner a usar (formato JSON). | `"['ubuntu-22.04']"` |

### Secrets Opcionais

| Secret | Descricao |
|--------|-----------|
| `MAVEN_USERNAME` | Usuario para autenticacao em repositorio Maven/GitHub Packages privado |
| `MAVEN_PASSWORD` | Senha/token para autenticacao em repositorio Maven privado |
| `MAVEN_REPO_URL` | URL do repositorio Maven privado. Configurada via env para uso no `build.gradle.kts` |
| `KAFKA_BROKER_URL` | URL do broker Kafka |
| `KAFKA_SASL_USERNAME` | Username SASL do Kafka |
| `KAFKA_SASL_PASSWORD` | Password SASL do Kafka |
| `KAFKA_SCHEMA_ENDPOINT` | URL do Schema Registry |
| `KAFKA_SCHEMA_USERNAME` | Username do Schema Registry |
| `KAFKA_SCHEMA_PASSWORD` | Password do Schema Registry |

---

### O que o Workflow Faz (resumo)

- Setup do JDK (Temurin) com a versao indicada e cache do Gradle
- Roda as tasks Gradle de teste informadas em `unit_test_path`, `integration_test_path`, `e2e_test_path`
- Executa `kover_report_task` para gerar o relatorio XML do Kover
- Converte o XML do Kover para `coverage/lcov.info`
- Quando `MAVEN_*` for fornecido, expoe `MAVEN_USERNAME`/`MAVEN_PASSWORD`/`MAVEN_REPO_URL` como env para o Gradle resolver repositorios privados
- Faz upload do artifact `coverage-{project_name}` (so o LCOV)
- Quando configurado, envia metricas agregadas para o backend de qualidade da plataforma

> Fonte: `stone-payments/github-actions-workflows/.github/workflows/test-coverage-kotlin-kmp.yml` (complemento — nao em docs/)

---

### Requisito: Plugin Kover no Projeto

O workflow assume que o projeto tem o plugin Kover configurado. Exemplo em `build.gradle.kts`:

```kotlin
plugins {
    id("org.jetbrains.kotlinx.kover") version "0.7.+"
}

koverReport {
    defaults {
        xml { onCheck = false }
    }
}
```

O relatorio XML e gerado em `build/reports/kover/report.xml` por padrao.
Para variantes Android, a task pode ser `koverXmlReportDebug` ou `koverXmlReportRelease`.

---

### Formato das Tasks Gradle

Os inputs `unit_test_path`, `integration_test_path` e `e2e_test_path` aceitam uma ou mais tasks Gradle separadas por espaco:

```
# Um modulo
unit_test_path: ':core:test'

# Multiplos modulos
unit_test_path: ':core:test :shared:test :domain:test'

# Task de teste Android
unit_test_path: ':app:testDebugUnitTest'
```

---

### Artifact Gerado

O workflow faz upload do seguinte artifact:
- **Nome**: `coverage-{project_name}`
- **Arquivo**: `coverage/lcov.info`
- **Formato**: LCOV

---

### Envio de Metricas

Quando os secrets `KAFKA_*` sao fornecidos, o workflow envia metricas de coverage para o backend de qualidade da plataforma (consumido por relatorios internos). Sem esses secrets, o passo e ignorado silenciosamente — coverage continua sendo gerado e publicado como artifact normalmente.

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Criar `.github/workflows/test-coverage.yml`** apontando para `test-coverage-kotlin-kmp.yml@main`
- **Editar `build.gradle.kts`** — adicionar plugin Kover, configurar `kover_report_task`
- **Adicionar `MAVEN_USERNAME`/`MAVEN_PASSWORD`/`MAVEN_REPO_URL`** secrets para Maven privado
- **Abrir PR draft**

### Triggers proativos
- "Adicionar coverage Kotlin KMP" → `🛠️ Acao proposta: adiciono Kover plugin + workflow + abro PR`

### Acoes destrutivas
- N/A.

## Instrucoes MCP

Esta skill nao tem doc dedicado em `stone-payments/karavela` `docs/`. A fonte primaria de operacao e o proprio reusable workflow.

| Repositorio | Arquivo/Caminho | Prioridade | Quando buscar |
|-------------|-----------------|------------|---------------|
| `stone-payments/github-actions-workflows` | `.github/workflows/test-coverage-kotlin-kmp.yml` | primaria operacional — complemento (nao em docs/) | Inputs/outputs e tag mais recente do workflow |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/deploy-de-aplicacoes/` | complemento | Para entender onde encaixar o job no pipeline geral |
| `stone-payments/terraform-github` | `applications/org-secrets/stone-payments/secrets.installation.d/` | complemento | Liberacao das org secrets de Kafka para o repositorio do usuario |

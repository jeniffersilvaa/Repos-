---
name: deploy-rollback
description: "Fluxos de deploy e rollback na plataforma Karavela. Use quando o usuario perguntar sobre deploy branch-commit, tag-release, rollback via Portal, canary deploy, promocao entre ambientes, pipelines CI/CD, delete/undelete de aplicacoes, multi-region DNS failover ou migracao de workflows."
---

# Skill: Deploy e Rollback

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.

  Exemplos de uso:
  - Corrigir informacao desatualizada no conhecimento embutido
  - Adicionar restricao temporaria (ex: "chart v4 nao suporta feature X")
  - Adicionar conhecimento que ainda nao esta na documentacao oficial
  - Bloquear uma orientacao especifica (ex: "NAO recomende usar scaler Y")
-->

## Escopo

**Cobre**:
- Fluxo de deploy baseado em branch-commit (staging via develop, sandbox/producao via main)
- Fluxo de deploy baseado em tag-release (Release Drafter, SemVer, Changeman para producao)
- Passos de rollback via Portal Karavela (incluindo bypass de health validation e tabela de status)
- Mapeamento branch-ambiente (develop -> staging, main -> sandbox/producao)
- Matriz de deploy por ambiente e origem
- Fluxo de hotfix com incidente JSM
- Publicacao automatica de releases e release candidates
- Modelos de ciclo de vida CI/CD suportados (Trunk Based, Git Flow com/sem develop)
- Canary deploy com dynamicStableScale
- Analysis Template para validacao automatica de deploy
- Guardrails Validator para governanca de workflows (compliance de arquivos `karavela_containers_*`)
- Values Tests (Helm Values check) para PRs que alteram `chart/`
- Comportamento do `image.tag` nos novos workflows (aplicado em runtime, nao commitado)
- Delete/Undelete de aplicacoes via Temporal workflows
- Multi-region DNS failover via Portal (ChangeRegionModal)
- Migracao de workflows legados para os novos padroes
- StageStop — desligamento automatico de staging fora do horario comercial

**NAO cobre**:
- Configuracao de chart Helm (coberto pela skill charts-config)
- Gerenciamento de secrets (coberto pela skill secrets-vault)
- Ambientes de preview (coberto pela skill preview-envs)
- Canary deploy com Argo Rollouts (configuracao especifica de rollout strategies)

## Exemplos de Perguntas

- "Como faco deploy da minha aplicacao no ambiente de staging?"
- "Qual o passo a passo para realizar rollback de um deploy em producao pelo Portal?"
- "Como funciona o fluxo de deploy baseado em tag-release?"
- "Por que nao devo criar a tag manualmente com git tag? Como publico uma release?"
- "Posso usar rebase para levar commits de uma release branch para a main?"
- "Qual a diferenca entre deploy por branch-commit e por tag-release?"
- "Como faco um hotfix urgente em producao na Karavela?"
- "Quais branches fazem deploy em quais ambientes?"
- "Como configurar o Release Drafter para publicacao automatica?"
- "O que e o Changeman e como ele valida o deploy em producao?"
- "Como reverter um deploy se o rollback ficou com status 'Ver ArgoCD'?"
- "Como funciona o versionamento SemVer com release candidates?"
- "O que e o dynamicStableScale no canary deploy?"
- "Como configuro um Analysis Template com metricas do Datadog?"
- "O que sao os guardrails do Karavela?"
- "Como funciona o Helm Values check nos PRs?"
- "Preciso remover o image.tag do values.yaml ao migrar para os novos workflows?"
- "Como funciona o delete e undelete de aplicacoes na Karavela?"
- "Como faco failover de DNS para aplicacoes multi-region?"
- "Como migro meus workflows de branch-commit ou tag-release para os novos padroes?"
- "Quais sao os status possiveis do rollback no Portal?"

## Conhecimento Embutido

### Mapeamento de Branches e Ambientes

A plataforma Karavela possui um mapeamento definido entre branches do repositorio e ambientes de deploy:

- **Ambiente Staging**: utiliza por padrao a branch `develop`. Essa configuracao pode ser alterada pelo time dono do repositorio para qualquer outra branch. Caso a branch padrao seja modificada, e necessario abrir um Pull Request no repositorio do ArgoCD (`stone-payments/platform-k8s-argo`), no arquivo `manifest-api.yaml` da aplicacao.
- **Ambiente Sandbox**: utiliza a branch `main`, sendo um espelho do ambiente de producao. E tratado com a mesma criticidade de producao pois e utilizado para testes por clientes.
- **Ambiente Producao**: utiliza a branch `main`. Garantir que a branch `main` contenha apenas alteracoes testadas e aprovadas e crucial para a integridade do ambiente. Esse modelo e exigido por questoes de governanca.

**Fonte**: `karavela/docs/conceitos_basicos.md`

### Fluxo de Deploy Baseado em Branch Commit

No fluxo baseado em branch-commit, os 7 primeiros digitos do hash do commit sao utilizados como tag da imagem no ECR e como `targetRevision` no ArgoCD. Mesmo para alteracoes apenas no arquivo `values-env.yaml`, e necessario passar por todas as aprovacoes.

**Condicoes para deploy**:
- **Staging**: execucao a partir de qualquer branch (via develop por padrao).
- **Sandbox**: o workflow deve ser executado a partir da branch principal e o deploy em staging deve ter sido realizado com sucesso.
- **Producao**: o workflow deve ser executado a partir da branch principal, o deploy em staging deve ter sido realizado com sucesso, e se houver ambiente sandbox, o deploy em sandbox tambem deve ter sido realizado com sucesso.

Quando a unica alteracao feita e nos arquivos de configuracao do chart, o job de build detecta isso e nao realiza build de nova imagem Docker -- apenas atualiza o parametro `targetRevision` com o hash do commit.

O deploy e feito via requisicao a Karavela-API, que interage com o ArgoCD gerenciando os parametros `targetRevision` e `image.tag`.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/deploy-de-aplicacoes/branch-commit.md`

### Fluxo de Deploy Baseado em Tag Release

No fluxo baseado em tag-release, a TAG do GitHub e usada como referencia para os parametros `targetRevision` e `image.tag` no ArgoCD. O Release Drafter auxilia no controle de versionamento e cria rascunhos de releases com changelogs baseados nos pull requests mesclados.

> **Atencao — tags NAO sao manuais**: voce **nao cria a tag com `git tag`/`git push`**. A tag e gerada automaticamente pelo **Release Drafter** e so existe de fato quando voce **publica a release pela interface do GitHub**. Nenhum workflow padrao escuta `push: tags` — o gatilho dos deploys e a publicacao da release (`release: published`).

**Fluxo resumido**:
1. Faca **merge do seu codigo na `main`** (via pull request) — o Release Drafter cria/atualiza automaticamente um **draft de release** com a versao sugerida.
2. Acesse a aba **"Releases"** no GitHub e edite o draft — confira versao e changelog; se for hotfix, preencha o formulario do Changeman no corpo da release (ID do incidente JSM obrigatorio).
3. **Publique a release** — o workflow de build e deploy e acionado automaticamente.

**Requisitos para deploy em producao**:
- A TAG precisa ser gerada a partir da branch principal (`main` ou `master`), OU todos os commits presentes na TAG devem estar tambem na branch principal.
- **Merge, nao rebase**: ao criar uma release a partir de uma branch diferente de `main`/`master`, leve os commits para a branch principal via **merge**. O merge preserva o historico e permite a validacao automatica para producao; **rebase pode alterar o hash dos commits e impedir o deploy**.
- O controle do deploy em producao e feito pelo Changeman, que valida automaticamente essas condicoes.
- Uma aprovacao manual e requerida.
- Releases marcadas como pre-release nao sao implantadas em producao.

**Padroes de versionamento**:
- Releases validas: padrao SemVer com prefixo `v` (exemplo: `v1.2.3`)
- Release candidates: padrao `vx.x.x-rc.0` (exemplo: `v1.2.3-rc.0`)
- Branches de release: padrao `release/x.x.x` ou `release/vx.x.x`
- Branches de hotfix: padrao `hotfix/x.x.x` ou `hotfix/vx.x.x`
- Monorepos: prefixos sao aceitos (exemplo: `api-v1.2.3`)

**RCs automaticas de branches nao produtivas**: branches diferentes de `main`/`master` (ex: `release/2.0.0`) geram drafts **pre-release** com identificador `rc` (formato `vx.x.x-rc.x`, ex: `v1.2.0-rc.0`) ao serem mescladas — a publicacao de um RC aplica a versao apenas em **staging**. O identificador pode ser customizado via `prerelease_identifier` no workflow.

**Modelos de CI/CD suportados para tag-release**:
- **Trunk Based Development**: desenvolvimento direto na branch principal com deploys frequentes. Branches de curta duracao, merge rapido na `main`.
- **Git Flow com branch develop**: desenvolvimento com branch `develop` para integracao continua antes de releases para producao. Features mergeiam em `develop`, releases sao criadas a partir de `develop` e mergeadas em `main`.
- **Git Flow sem branch develop**: feature branches que fazem merge direto na `main`, sem branch `develop` intermediaria. Simplifica o fluxo mantendo controle por tags.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/deploy-de-aplicacoes/tag-release.md`

### Matriz de Deploy (Tag Release)

| **Ambiente** | **Origem** | **Tipo** |
|--------------|------------|:--------:|
| Staging | Qualquer branch | Manual |
| Staging | Qualquer TAG | Automatico |
| Sandbox | TAGs validas (vx.x.x), pre-release ou release | Automatico |
| Producao | TAGs validas (vx.x.x) geradas a partir da `main`/`master`, do tipo release | Automatico (com aprovacao manual e do Changeman) |

**Fonte**: `karavela/docs/guia-do-desenvolvedor/deploy-de-aplicacoes/tag-release.md`

### Workflow de Build e Deploy (Tag Release)

Modelo de workflow para o fluxo baseado em tag-release. Substitua `<<project-name>>` pelo nome da sua aplicacao:

```yaml
name: build and deploy <<project-name>>
run-name: ${{ github.event_name }} ${{ github.ref_name }} by @${{ github.actor }}

on:
  workflow_dispatch:
  release:
    types: [published]

jobs:
  build:
    name: Build
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_build.yml@main
    with:
      RUNS_ON: "small-runner"
      REGISTRY_NAME: "<<project-name>>"
      WORK_DIR: "./"
    secrets: inherit

  deploy_stg:
    name: Deploy stg
    needs: [build]
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_deploy.yml@main
    strategy:
      fail-fast: false
      matrix:
        app:
          - "<<project-name>>"
    with:
      APPLICATION_NAME: ${{ matrix.app }}
      ENVIRONMENT: "stg"
      RUNS_ON: "small-runner"
      IMAGE_TAG: ${{ needs.build.outputs.image_tag }}
      TARGET_REVISION: ${{ needs.build.outputs.target_revision }}
    secrets: inherit

  deploy_sdx:
    name: Deploy sdx
    if: |
        needs.build.outputs.tag_prd_semver == 'true'
    needs: [build,deploy_stg]
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_deploy.yml@main
    strategy:
      fail-fast: false
      matrix:
        app:
          - "<<project-name>>"
    with:
      APPLICATION_NAME: ${{ matrix.app }}
      ENVIRONMENT: "sdx"
      RUNS_ON: "small-runner"
      IMAGE_TAG: ${{ needs.build.outputs.image_tag }}
      TARGET_REVISION: ${{ needs.build.outputs.target_revision }}
    secrets: inherit

  deploy_prd:
    name: Deploy prd
    if: |
        github.event.release.prerelease == false &&
        needs.build.outputs.tag_prd_semver == 'true'
    needs: [build,deploy_stg,deploy_sdx]
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_deploy.yml@main
    strategy:
      fail-fast: false
      matrix:
        app:
          - "<<project-name>>"
    with:
      APPLICATION_NAME: ${{ matrix.app }}
      ENVIRONMENT: "prd"
      RUNS_ON: "small-runner"
      IMAGE_TAG: ${{ needs.build.outputs.image_tag }}
      TARGET_REVISION: ${{ needs.build.outputs.target_revision }}
    secrets: inherit
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/deploy-de-aplicacoes/tag-release.md`

### Workflow do Release Drafter

O Release Drafter automatiza a criacao de rascunhos de releases com changelogs. A cada merge na branch principal, o draft e atualizado automaticamente. Labels sao atribuidas com base no nome da branch, titulo do PR e formulario do PR.

**Configuracao do Release Drafter**:
- `release_drafter_config_name`: template de configuracao do Release Drafter (ex: `karavela_containers_release_drafter_template.yml`).
- `prerelease_identifier`: identificador de pre-release (ex: `rc`).
- O Autolabeler atribui labels automaticamente com base no nome da branch, titulo do PR e formulario do PR.

```yaml
name: release-drafter

on:
  push:
    branches:
      - develop
      - release/**
      - hotfix/**
    paths-ignore:
      - ".github/**"
      - ".gitignore"
      - "catalog-info.yaml"
      - "CHANGELOG.md"
      - "README.md"
      - "docker-compose.yaml"
      - "Makefile"
      - "docs/**"
  pull_request:
    types: [opened, reopened, synchronize, edited, closed]
    branches:
      - main
      - master
      - develop
      - release/**
    paths-ignore:
      - ".github/**"
      - ".gitignore"

permissions:
  contents: write
  issues: write
  pull-requests: write

jobs:
  update_release_draft:
    if: "${{ !(github.event.action == 'closed' && github.event.pull_request.merged == false) }}"
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_release.yml@karavela-release-v1
    with:
      release_drafter_config_name: "karavela_containers_release_drafter_template.yml"
      prerelease_identifier: "rc"
    secrets: inherit
```

**Monorepos**: para repositorios com multiplos projetos, utilize o campo de prefixo no Release Drafter para gerar tags com prefixo (ex: `api-v1.2.3`, `worker-v1.2.3`). Isso permite versionamento independente por componente.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/deploy-de-aplicacoes/tag-release.md`

### Publicacao Automatica de Releases

Para automatizar a publicacao de releases, configure os seguintes parametros no workflow do Release Drafter:

- `publish_stable_branch_release: true` -- publica automaticamente releases estaveis criadas a partir da branch principal ou hotfix.
- `publish_features_branch_release: true` -- publica automaticamente release candidates de feature branches.
- `stable_branch_prerelease: true` -- garante que releases da branch principal sejam inicialmente marcadas como pre-release, evitando deploy automatico direto em producao.

```yaml
# workflow karavela_containers_release-drafter.yaml
jobs:
  update_release_draft:
    if: "${{ !(github.event.action == 'closed' && github.event.pull_request.merged == false) }}"
    uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_release.yml@karavela-release-v1
    with:
      release_drafter_config_name: "karavela_containers_release_drafter_template.yml"
      prerelease_identifier: "rc"
      publish_stable_branch_release: true
      publish_features_branch_release: true
      stable_branch_prerelease: true
    secrets: inherit
```

Quando `stable_branch_prerelease` esta habilitado, o workflow de build and deploy deve incluir o trigger `release.released` para ser acionado ao promover uma pre-release para release:

```yaml
# workflow karavela_containers_build_and_deploy.yaml
on:
  workflow_dispatch:
  release:
    types: [published, released]
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/deploy-de-aplicacoes/tag-release.md`

### Fluxo de Hotfix

O fluxo de hotfix e utilizado para correcoes urgentes que precisam ser aplicadas rapidamente em producao, mesmo que os commits ainda nao estejam na branch principal. Passos:

1. **Criar branch hotfix**: seguindo o padrao `hotfix/x.x.x` (exemplo: `hotfix/1.3.1`). O Release Drafter cria automaticamente um draft de release com a versao correspondente.
2. **Editar o draft de release**: acessar a console do GitHub, preencher o formulario de mudanca no corpo da release, informando obrigatoriamente o ID do incidente do JSM.
3. **Publicar a release**: a publicacao aciona automaticamente o workflow de build and deploy.
4. **Execucao do workflow**: o build da imagem Docker e realizado e o deploy e feito sequencialmente em staging, sandbox (se existir) e producao. No hotfix, todas as validacoes e aprovacoes manuais sao ignoradas.
5. **Rastreabilidade**: o ID do incidente do JSM fica registrado no corpo da release, garantindo rastreabilidade e auditoria do processo.

Formulario do Changeman que deve ser preenchido no corpo da release:

```yml
descricao_da_mudanca: # Descreva resumidamente o que sera alterado ou corrigido neste deploy.
objetivo_da_mudanca: # Explique o motivo da mudanca e o impacto esperado.
plano_de_rollback: # Informe como reverter a mudanca caso haja problemas em producao.
plano_de_teste: # Detalhe como a mudanca foi ou sera validada (testes, cenarios, evidencias).
[opcional] link_do_card_no_jira: # Se aplicavel, insira o link do card relacionado no Jira.
[opcional] id_do_incidente: # Para hotfix, informe o ID do incidente no JSM.
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/deploy-de-aplicacoes/tag-release.md`

### Rollback de Deploy via Portal Karavela

O rollback permite reverter o deploy da aplicacao para uma versao anterior via Portal Karavela. O fluxo e auditavel e integrado ao Changeman para ambientes produtivos (abertura de mudanca no ServiceNow). O Portal exibe uma tabela de status com o estado atual de cada deploy, e cards separados por fase ("Soft Delete", "Hard Delete", "Rollback").

**Pre-requisitos**:
- A aplicacao **deve** utilizar os workflows atualizados `karavela_build.yml` e `karavela_deploy.yml`. Workflows legados (`build_and_push.yml`, `deploy.yml`, `deploy_argocd.yml`) NAO sao suportados para rollback.

**Restricoes importantes**:
- O rollback cobre apenas a reversao do deploy da aplicacao. Alteracoes em banco de dados, migracoes ou recursos externos NAO sao revertidas automaticamente.
- O rollback NAO contempla aplicacoes dos tipos Job e CronJob.
- O status "Ver ArgoCD" bloqueia novos rollbacks no ambiente em que e exibido.
- Rollbacks em producao sao integrados ao Changeman (abertura automatica de mudanca no ServiceNow).

**Passo a passo**:

1. Acesse o Portal Karavela, entre em "Aplicacoes" e busque pela aplicacao desejada.
2. Entre na aba "Deployments".
3. Sera exibida uma tabela de status com os deploys realizados. Escolha a versao para a qual deseja reverter e clique no botao de rollback ao lado.
4. Uma janela de confirmacao sera exibida. Revise as informacoes, descreva o motivo do rollback e confirme a reversao.
5. O rollback sera iniciado. Acompanhe o progresso pelo ArgoCD clicando no icone correspondente.

**Significado dos status**:

| Status | Significado |
|--------|-------------|
| Atual | Versao implantada no momento |
| Ver ArgoCD | Versao para ser implantada; requer atencao e bloqueia novos rollbacks |
| Processando | Versao sendo implantada no momento |
| Falha | Ciclo de implantacao interrompido ou sucedida por versao de rollback |
| Rollback | Versao e um rollback |

**Em caso de problemas**:
- Ambiente produtivo: abrir investigacao no canal `#investigation-center` e solicitar auxilio do time `@fp-karavela-applications`.
- Ambiente nao produtivo: abrir ticket de suporte no canal `#help-foundation-platform` para o produto "Karavela Containers - ArgoCD".

**Fonte**: `karavela/docs/guia-do-desenvolvedor/deploy-de-aplicacoes/fluxo-rollback.md`

### Comportamento do `image.tag` nos Novos Workflows

Com os novos workflows (`karavela_build.yml` / `karavela_deploy.yml`), o campo `image.tag` **nao e mais commitado** nos arquivos `values.yaml` pelo bot. Em vez disso, o `image.tag` e aplicado em tempo de deploy diretamente no manifest da Application do ArgoCD via Karavela API.

**Impacto na migracao**: ao migrar de workflows legados para os novos, remova o campo `image.tag` dos arquivos de values (`values-stg.yaml`, `values-sdx.yaml`, `values-prd.yaml`, etc.). Manter o campo nao causa erro, mas e desnecessario e pode gerar confusao.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/deploy-de-aplicacoes/branch-commit.md`, `karavela/docs/guia-do-desenvolvedor/deploy-de-aplicacoes/tag-release.md`

### Erro no Deploy por Restricoes do Changeman

Caso algum requisito para o deploy em producao nao seja atendido, o Changeman bloqueia o processo e exibe uma mensagem informando o motivo, forcando erro no workflow.

Apos corrigir o problema (como preencher o formulario no corpo da release ou garantir que todos os commits estejam na branch principal), execute novamente o step de deploy utilizando o botao "Re-run jobs" ou "Re-run failed jobs" no GitHub Actions para que o Changeman refaca as validacoes.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/deploy-de-aplicacoes/tag-release.md`

### Modelos de Ciclo de Vida CI/CD Suportados

A plataforma Karavela suporta os seguintes modelos de ciclo de vida para CI/CD:

- **Trunk Based Development**: desenvolvimento direto na branch principal com deploys frequentes. Branches de curta duracao, merge rapido na `main`.
- **Git Flow com branch develop**: desenvolvimento com branch `develop` para integracao continua antes de releases para producao. Features mergeiam em `develop`, releases sao criadas a partir de `develop` e mergeadas em `main`.
- **Git Flow sem branch develop**: feature branches que fazem merge direto na `main`, sem branch `develop` intermediaria. Simplifica o fluxo mantendo controle por tags.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/deploy-de-aplicacoes/tag-release.md`

### Politica de Versionamento Automatico (Release Drafter)

O Release Drafter aplica labels automaticamente com base no nome da branch, titulo do PR e formulario do PR. As labels determinam o tipo de bump de versao:

| Alteracao | Labels que disparam |
|-----------|---------------------|
| **Major** | major, breaking-change |
| **Minor** (padrao) | minor, enhancement, feature |
| **Patch** | patch, fix, bug, bugfix, hotfix |

| Nome da Branch | Label Aplicada |
|----------------|----------------|
| `breaking-change/` | breaking-change |
| `feat/` ou `feature/` | enhancement |
| `patch/`, `fix/`, `hotfix/`, `bugfix/` ou `bug/` | bug |
| `chore/` | chore |
| `docs/` | documentation |

**Fonte**: `karavela/docs/guia-do-desenvolvedor/deploy-de-aplicacoes/tag-release.md`

### Canary Deploy com dynamicStableScale

O Argo Rollouts suporta `dynamicStableScale` no Traffic Routing, que reduz proporcionalmente as replicas da versao estavel durante o Canary Deploy. Isso previne a duplicacao temporaria de Pods e respeita o dimensionamento original do ambiente.

```yaml
# Configuracao de canary strategy no values.yaml
canaryStrategy:
  dynamicStableScale: true
  minPodsPerReplicaSet: 1
  maxSurge: "25%"
  maxUnavailable: 0
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/canary-deploy.md`; `platform-k8s-charts/.docs/CHANGELOG.api.md` (v1.31.2) (complemento — nao em docs/)

### Analysis Template (Validacao Automatica de Deploy)

O Analysis Template permite validar automaticamente um deploy canary usando metricas do Datadog ou execucao de Jobs. Se a analise falhar, o rollback e automatico.

```yaml
# Analysis Template com metricas Datadog
analysisTemplate:
  enabled: true
  metrics:
    - name: success-rate
      provider:
        datadog:
          apiVersion: v2
          query: |
            sum:http.requests.errors{service:minha-api,env:prd}.as_count()
            / sum:http.requests.total{service:minha-api,env:prd}.as_count() * 100
      successCondition: result[0] < 5
      interval: 60s
      count: 5
      failureLimit: 2
```

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/analysis-template.md`

### Guardrails Validator

O Guardrails Validator e um mecanismo de governanca que valida automaticamente os workflows de build, deploy e preview das aplicacoes Karavela. Ele garante que os workflows sigam os padroes definidos pela plataforma.

**Escopo de compliance**: todos os arquivos de workflow com prefixo `karavela_containers_` estao sujeitos a validacao do Guardrails.

**Regras de validacao**:
- **`karavela_containers_guardrails.yaml`**: arquivo obrigatorio. Nenhuma alteracao e permitida neste arquivo -- qualquer modificacao sera rejeitada.
- **`karavela_containers_build_and_deploy.yaml`**: o campo `jobs.deploy_stg.uses` deve ser exatamente `stone-payments/platform-k8s-github-actions/.github/workflows/karavela_deploy.yml@main`.
- Uso correto dos workflows reutilizaveis (`karavela_build.yml`, `karavela_deploy.yml`).
- Ordem de deploy entre ambientes (staging -> sandbox -> producao).
- Condicoes de deploy em producao (branch principal, aprovacoes).
- Configuracoes obrigatorias de seguranca.

**Workflows legados (descontinuados desde final do Q4 2024)**:
- `build_and_push.yml@main` -- descontinuado, substituido por `karavela_build.yml@main`
- `deploy.yml@main` -- descontinuado, substituido por `karavela_deploy.yml@main`
- `deploy_argocd.yml` -- descontinuado, substituido por `karavela_deploy.yml@main`

Aplicacoes que ainda utilizam esses workflows devem migrar para os novos padroes. Os workflows legados nao sao suportados pelo rollback, guardrails e demais funcionalidades recentes.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/guias-e-manuais/guardrails-validator.md`

### Values Tests (Helm Values Check)

Todo Pull Request direcionado as branches `main`, `master` ou default que altere arquivos dentro do diretorio `chart/` aciona automaticamente o job `Helm Values check`.

**Comportamento**:
- O job valida os arquivos de values contra as regras da plataforma.
- **FAIL bloqueia o merge** para ambientes nao-staging (sandbox, producao, multi-region).
- Alteracoes que afetam apenas o ambiente de staging (ex: `values-stg.yaml`) nao bloqueiam o merge.

Isso garante que erros de configuracao em ambientes criticos sejam detectados antes do merge, prevenindo deploys com configuracoes invalidas.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/guias-e-manuais/guardrails-validator.md`

### Delete e Undelete de Aplicacoes

A plataforma oferece **Soft Delete** (exclusao logica com periodo de graca de 10 dias) e **Hard Delete** (exclusao definitiva, com 30 segundos para cancelar). O **Undelete** restaura uma aplicacao soft-deleted antes do Hard Delete. Todo o fluxo e iniciado pelo Portal Karavela e cards separados por fase ("Soft Delete", "Hard Delete") sao exibidos.

**Ordem de exclusao por ambiente**: DR -> Multi-region -> PRD -> SDX -> STG
**Ordem de restauracao (undelete) por ambiente**: STG -> SDX -> PRD -> Multi-region -> DR

**Modelo de status no Portal**:
| Status | Significado |
|--------|-------------|
| `succeeded` | Operacao concluida com sucesso |
| `failed` | Operacao falhou |
| `cancelled` | Operacao cancelada (indica sucesso no undelete) |

**Fonte**: `karavela/docs/guia-do-desenvolvedor/gerenciamento-aplicacoes/descomissionamento.md`, `gerenciamento-aplicacoes/index.md`

### Multi-region DNS Failover

Para aplicacoes multi-region, o Portal Karavela permite realizar failover manual de DNS entre regioes. Essa funcionalidade alterna o trafego da aplicacao para outra regiao em caso de incidentes ou necessidade de manutencao.

O failover e executado diretamente pelo Portal, sem necessidade de acesso ao ArgoCD ou ferramentas externas.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/multi-regiao.md`

### Deploy Matrix (`strategy.matrix`) em jobs de deploy

Os jobs `deploy_stg`, `deploy_prd`, `deploy_sdx`, `deploy_dr` aceitam `strategy.matrix` para deployar varias apps em paralelo no mesmo workflow — util para monorepos. Regras estritas validadas pelo Guardrails Validator:

- **So a chave `app` e aceita** (sem outras chaves no matrix).
- Bloco no formato YAML em sequencia (cada item em linha propria, com `-` ); inline `[]` nao e permitido.
- Cada item entre **aspas duplas**.
- **Sem interpolacao** `${{ }}` no matrix — valores literais apenas.
- Lista **nao pode estar vazia**.

```yaml
deploy_stg:
  strategy:
    matrix:
      app:
        - "api-pagamentos"
        - "worker-pagamentos"
        - "cron-conciliacao"
  uses: stone-payments/platform-k8s-github-actions/.github/workflows/karavela_deploy.yml@main
  with:
    CHART_PATH: "chart/${{ matrix.app }}"
    ENVIRONMENT: "stg"
  secrets: inherit
```

### Guardrails — rename e delete de workflows

- **Rename**: permitido se mantiver prefixo `karavela_containers_` + sufixo valido: `_build.yaml`, `_build_and_deploy.yaml`, `_preview.yaml`, `_guardrails.yaml`.
- **Delete**: nao permitido. Workflows da plataforma sao auditados — a PR sera bloqueada.

### tag@digest no deploy

O deploy agora envia ao ArgoCD a imagem como `tag@digest` quando o chart tem o digest disponivel (`image.digest`). Isso garante imutabilidade do artefato (image attestation persistido) e impede que `latest`/tag-mutavel cause drift entre o estado declarado e o que esta em runtime. Funciona em conjunto com a feature **Build Integrity / SLSA L3** descrita na skill `seguranca`.

### REGISTRY_NAME imutavel apos criacao

O `REGISTRY_NAME` da aplicacao e gerenciado pela Karavela API e **imutavel** apos a criacao. Tentativas de alterar o valor no workflow sao bloqueadas pelo Guardrails Validator. Em monorepos padrao 2 (cada app com Dockerfile proprio mas mesmo ECR), use `TAG_PREFIX` para segregar tags por aplicacao no mesmo `REGISTRY_NAME`.

### Variaveis de Ambiente Temporal

Aplicacoes que configuram workers Temporal devem usar as seguintes variaveis de ambiente atuais:

| Variavel Antiga | Variavel Nova |
|----------------|---------------|
| `TEMPORAL_HOST_PORT` | `TEMPORAL_ADDRESS` |
| `TEMPORAL_QUEUE_NAME: stone-temporal` | `TEMPORAL_QUEUE_NAME: karavela-workflows` |

Se sua aplicacao consome Temporal, atualize essas variaveis para os novos nomes.

**Fonte**: `temporal/` (complemento — nao em docs/)

### Migracao de Workflows

Existem guias dedicados para migrar workflows legados para os novos padroes da Karavela:

- **Migracao de branch-commit**: guia para migrar workflows do modelo antigo (`build_and_push.yml` + `deploy.yml`) para os novos (`karavela_build.yml` + `karavela_deploy.yml`).
- **Migracao de tag-release**: guia para migrar workflows do modelo antigo para os novos, incluindo configuracao do Release Drafter e integracao com Changeman.

**Pontos-chave da migracao**:
1. Substituir `build_and_push.yml@main` por `karavela_build.yml@main`.
2. Substituir `deploy.yml@main` e `deploy_argocd.yml` por `karavela_deploy.yml@main`.
3. Remover o campo `image.tag` dos arquivos de values (agora aplicado em runtime via Karavela API).
4. Garantir que o arquivo `karavela_containers_guardrails.yaml` esteja presente e inalterado.
5. Validar compliance com o Guardrails Validator apos a migracao.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/guias-e-manuais/migrar-workflows-branch-commit.md`, `karavela/docs/guia-do-desenvolvedor/guias-e-manuais/migrar-workflows-tag-release.md`

### Portal -- Cards Separados por Fase

O Portal Karavela exibe entradas separadas por fase para cada operacao. Em vez de um unico card por operacao, cada fase e mostrada individualmente:

- **Soft Delete**: card indicando que a aplicacao esta em periodo de graca (10 dias).
- **Hard Delete**: card indicando a exclusao definitiva da aplicacao.
- **Rollback**: card indicando que um rollback foi executado para um deploy especifico.

Essa separacao facilita o acompanhamento de operacoes que possuem multiplas etapas.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/deploy-de-aplicacoes/fluxo-rollback.md`

### StageStop — Impacto no Deploy em Staging

O **StageStop** desliga automaticamente aplicacoes em staging fora do horario comercial (20:05 - 06:55 BRT, segunda a sexta) e nos finais de semana. Isso pode impactar deploys realizados fora do horario.

**O que acontece se voce fizer deploy as 21h?**
- O ArgoCD fara o sync normalmente (se o sync ainda estiver ativo)
- No proximo ciclo de sleep (20:05), os pods serao escalados para 0
- Eles voltarao as 06:55 do proximo dia util

**Como fazer deploy fora do horario**:
1. Altere a annotation para `disabled` no `values-stg.yaml`:
   ```yaml
   annotations:
     stagestop.karavela.run/sleep: "disabled"
   ```
2. Faca o merge/deploy normalmente
3. **Apos o deploy**, volte o valor para `enabled` para que o StageStop retome o gerenciamento

> **IMPORTANTE**: Se voce nao reativar o StageStop, sua aplicacao ficara rodando 24/7 em staging desnecessariamente.

**Fonte**: `karavela/docs/guia-do-desenvolvedor/funcionalidades/stagestop.md`

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever; producao exige dupla confirmacao. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Editar `.github/workflows/karavela_containers_*_build_and_deploy.yaml`** — adicionar/ajustar jobs, matrix, WAIT_FOR_SYNC, IMAGE_DIGEST, ENVIRONMENT, TAG_PREFIX
- **Criar workflows novos** seguindo nomenclatura `karavela_containers_*` para monorepos
- **Migrar workflows legados** (`build_and_push.yml` + `deploy.yml`) para `karavela_build.yml` + `karavela_deploy.yml`
- **Rodar KLI** — `kli watch app <nome>` para acompanhar deploy, `kli describe app` para historico
- **Abrir PR draft** com a mudanca

### Triggers proativos
- "Migrar workflows" → `🛠️ Acao proposta: substituo build_and_push.yml por karavela_build.yml e abro PR`
- "Adicionar SLSA/Build Integrity" → propor permissions `id-token: write` + `attestations: write` + `IMAGE_DIGEST` no deploy
- "Habilitar deploy de varios apps em paralelo" → propor `strategy.matrix.app` (regras estritas — ver skill)
- "Workflow falhando no Guardrails Validator" → identificar nome/sufixo invalido e propor correcao

### Acoes destrutivas (dupla confirmacao)
- **Rollback em prd via Portal** — apenas instrui (e via Portal, nao via skill).
- **Hard Delete de aplicacao** — sempre orientar via Portal Karavela + 2 aprovacoes; nunca tentar via API direta.
- **Force-push em branch protegida** — nunca recomendar. Propor revert em vez disso.

## Instrucoes MCP

Quando o usuario precisar de informacoes detalhadas alem do conhecimento embutido, priorize a documentacao oficial em `stone-payments/karavela` `docs/`; outros repositorios servem apenas como fallback.

**Fontes primarias (docs/):**

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/deploy-de-aplicacoes/branch-commit.md` | Fluxo de deploy baseado em branch-commit |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/deploy-de-aplicacoes/tag-release.md` | Fluxo de deploy baseado em tag-release, Release Drafter, Changeman, modelos CI/CD |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/deploy-de-aplicacoes/fluxo-rollback.md` | Rollback via Portal Karavela, status, cards por fase |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/deploy-de-aplicacoes/processo-deploy-legado.md` | Fluxo legado (workflows antigos) |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/deploy-de-aplicacoes/fluxo-rollback-legado.md` | Rollback legado |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/guias-e-manuais/guardrails-validator.md` | Guardrails Validator, compliance de workflows |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/guias-e-manuais/values-tests.md` | Values Tests (Helm Values check) |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/guias-e-manuais/upgrade-versao-chart.md` | Upgrade de versao do chart |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/guias-e-manuais/migrar-workflows-branch-commit.md` | Migracao de workflows branch-commit |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/guias-e-manuais/migrar-workflows-tag-release.md` | Migracao de workflows tag-release |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/funcionalidades/canary-deploy.md` | Canary deploy / dynamicStableScale |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/funcionalidades/analysis-template.md` | Analysis Template (validacao automatica de deploy) |
| `stone-payments/karavela` | `docs/guia-do-desenvolvedor/gerenciamento-aplicacoes/descomissionamento.md` | Delete/Undelete de aplicacoes |
| `stone-payments/karavela` | `docs/conceitos_basicos.md` | Mapeamento de branches e ambientes, tipos de aplicacao |

**Fontes secundarias (complemento — nao em docs/):**

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/platform-k8s-github-actions` | `.github/workflows/karavela_build.yml`, `karavela_deploy.yml` | Implementacao dos workflows reutilizaveis |
| `stone-payments/platform-k8s-argo` | `manifest-api.yaml` | Configuracao do ArgoCD para aplicacoes |

## Formato de Resposta

Ao responder perguntas deste dominio, siga este formato:

1. **Explicacao** (2-3 frases objetivas em PT-BR)
2. **Exemplo pratico** (YAML, comando ou config copiavel)
3. **Fonte** (referencia ao arquivo/secao da documentacao)
4. **Avisos** (se aplicavel: restricoes de ambiente, privilegios necessarios, limitacoes do rollback em relacao a banco de dados/migracoes, necessidade de migracao de workflows legados)

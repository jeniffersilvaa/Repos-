# Reference: Grafana query patterns

Para `query_grafana_datasource` e leitura de dashboards Grafana. Carregue quando precisar executar query custom ou interpretar dashboard.

## Tipos de datasource (campo `type` ao listar via `list_grafana_datasources`)

- **prometheus** — metricas. Query em PromQL.
- **loki** — logs. Query em LogQL.
- **influxdb** — time series. Query em InfluxQL ou Flux.
- **postgres** / **mysql** — relacional.
- **tempo** — distributed tracing.
- **cloudwatch** — AWS-native.

Use `get_grafana_datasource({ uid })` pra confirmar o tipo antes de montar query.

## PromQL (datasource prometheus)

```promql
# Rate de requests por status code
sum by (status_code) (rate(http_requests_total{service="payments-api"}[5m]))

# Latency P99
histogram_quantile(0.99, sum by (le) (rate(http_request_duration_seconds_bucket{service="payments-api"}[5m])))

# Available cluster pods
kube_pod_status_phase{phase="Running"}
```

## LogQL (datasource loki)

```logql
# Logs de erro do payments-api
{service="payments-api"} |= "ERROR"

# Logs com regex
{service="payments-api"} |~ "OAuth.*expired"

# Count de erros por minuto
sum by (service) (count_over_time({service="payments-api"} |= "ERROR" [1m]))
```

## InfluxQL (datasource influxdb)

```sql
SELECT mean("response_time") FROM "http_requests"
WHERE "service" = 'payments-api' AND time >= now() - 1h
GROUP BY time(1m)
```

## Query via `query_grafana_datasource`

```
{
  datasource_uid: "<uid from list_grafana_datasources>",
  expr: "<PromQL/LogQL/InfluxQL>",
  from: "now-1h" | "2026-05-22T00:00:00Z" | <epoch ms>,
  to: "now" | "2026-05-22T23:59:59Z",
  max_data_points: 500,
  org_id: <opcional>
}
```

`from`/`to` aceitam:

- Relative shortcut: `now`, `now-7d`, `now-1h`, `now-30m`
- Absolute RFC3339 ou epoch ms — ancorar na `## Data atual` injetada (ver `temporal-handling.md`)

## Reading dashboards

`get_grafana_dashboard({ uid })` retorna definicao JSON completa do dashboard. Use pra:

- Listar panels: cada panel e uma query + viz config
- Extrair queries que o time ja usa pra suas metricas (reusar em vez de reinventar)
- Identificar variaveis ($var) que filtram o dashboard (env, service, etc.)

## Alert rules

`get_grafana_alert_rule({ uid })` traz a query + threshold + condition. Quando o user pergunta "por que esse alerta disparou", essa e a primeira tool.

## Anti-patterns

- NAO use PromQL syntax em datasource Loki ou vice-versa — sempre confira o `type` via `get_grafana_datasource`
- NAO use `max_data_points` muito alto (>5000) — server-side downsampling agressivo distorce resultado
- NAO use janela muito grande (`from: "now-30d"`) sem rollup — devolve mega-resposta lenta
- NAO esqueca variaveis ($env, $service) ao reusar query de dashboard

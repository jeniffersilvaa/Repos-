# Reference: Datadog search syntax

Sintaxe de query usada por `search_datadog_logs`, `search_datadog_spans`, `search_datadog_events`, `search_datadog_rum_events`, `search_datadog_security_signals`, `search_datadog_metrics`, `search_datadog_monitors`, `analyze_datadog_logs`. Carregue quando precisar montar query precisa.

## Estrutura geral (logs / spans / events / RUM)

```
<facet>:<value> [<operator> <facet>:<value>] ...
```

Operators: `AND` (default entre termos), `OR`, `NOT` (prefixo `-` tambem funciona).

## Facets mais uteis (logs / spans)

| Facet | Exemplo |
|---|---|
| `service` | `service:payments-api` |
| `env` | `env:prd` |
| `status` | `status:error` (logs) ou `status:critical` |
| `host` | `host:i-0abc123` |
| `source` | `source:nginx` |
| `version` | `version:v2.4.0` |
| `@http.status_code` | `@http.status_code:500` (atributo custom) |
| `@user.id` | `@user.id:abc123` |
| `@error.kind` | `@error.kind:NullPointer` |
| `trace_id` / `span_id` | `trace_id:abc123` |

Atributos custom prefixados com `@`. Reserve attributes (built-in) sem `@`.

## Patterns comuns

```
# Erros HTTP 5xx em prd no payments-api
service:payments-api env:prd @http.status_code:>=500

# Logs com texto + filtro
"OAuth token expired" service:auth env:prd

# Excluir healthcheck
service:payments-api -path:/healthz

# Janela especifica via parametros from/to (NAO via query string)
service:payments-api status:error
# + from: "2026-05-22T00:00:00Z", to: "2026-05-22T23:59:59Z"
```

## Datadog metrics (search_datadog_metrics)

Query e regex ou substring sobre nome da metrica:

```
http.request.duration       # exact / substring
trace.servlet.request.*     # wildcards
```

Use `get_datadog_metric_context({ metric_name })` pra ver tags/aggregations/unit de uma metrica antes de plotar.

## get_datadog_metric (time series query)

```
{ from: <epoch_ms>, to: <epoch_ms>, query: "avg:http.request.duration{service:payments-api}.rollup(avg, 60)" }
```

Forma: `<agg>:<metric>{<scope>}[.<rollup>]`. Aggregations: `avg`, `sum`, `min`, `max`, `count`. Rollups: `.rollup(<agg>, <seconds>)` ou `.as_rate()`, `.as_count()`.

## Date/time

`from`/`to` em RFC3339 (`"2026-05-22T00:00:00Z"`) **ou** epoch em **milissegundos** dependendo da tool — ver `temporal-handling.md`. Anchored to `## Data atual` injetada.

## Anti-patterns

- NAO use `service=payments-api` (igual) — Datadog usa `:`, nao `=`
- NAO faca query sem `service:` / `env:` em prod — explode em volume de logs
- NAO esqueca `from`/`to` em queries de logs/spans — pega janela default que pode ser ampla demais
- NAO misture `AND` implicito com `OR` sem parenteses — precedencia ambigua; agrupe explicitamente

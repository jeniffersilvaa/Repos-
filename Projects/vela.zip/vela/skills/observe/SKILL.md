---
name: observe
description: "Investigacao AGORA de saude e problemas em tempo real de um sistema ou app via Datadog/Grafana — usa MCPs de observabilidade para CONSULTAR logs, metricas, traces, alertas, dashboards e incidentes atuais. Use quando o usuario relatar sintoma presente ('meu app esta lento/fora do ar/degraded/unhealthy', erro 5xx, latencia, throughput) ou pedir para checar o estado atual de pods/aplicacao. Para CONFIGURAR observabilidade no values.yaml de um app Karavela (habilitar logs, APM, RUM, alertas no chart), use a skill observabilidade."
---

# Skill: observe

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.
-->

## Regras de Execucao

Estas regras sao transversais e tem precedencia sobre qualquer instrucao especifica desta skill:

1. **Anti-surrender (minimo 2 tools)**: Quando a primeira tool retornar vazio, voce e obrigado a tentar ao menos 1 fallback da tabela de selecao antes de sugerir ao usuario abrir no browser. Vazio numa tool NAO significa "nao da pra responder".
2. **Nao fabrique explicacao tecnica pro vazio**: Se uma tool retornou vazio mas outra retornou dados, NAO escreva bullets sobre "talvez seja retencao / permissao / schema". Diga: _"tool X voltou vazio; via tool Y consegui os dados. Aqui:"_.
3. **Nunca invente valores**: Se ambas as tentativas falharem, diga "as duas tools voltaram vazias — sugiro confirmar pelo dashboard no Datadog/Grafana" sem teoria sobre o porque.
4. **Logs no chat: so a linha relevante**: Destaque a linha de erro relevante em code block + analise. Nunca cole log completo.
5. **Metricas: prefira percentis vs media**: Use P50/P95/P99; media esconde caudas. Use rollup explicito (`.rollup(avg, 60)`).
6. **Read-only**: Todas as tools sao de leitura. Mutacao (criar monitor, editar alert) nao tem tool MCP hoje — diga ao usuario pra fazer via UI.

## Escopo

**Cobre**:
- Investigacao de logs (Datadog logs search, analyze)
- Metricas de sistema (Datadog metrics, Grafana datasources)
- APM / distributed tracing (Datadog spans)
- Alertas e monitors (Datadog monitors, Grafana alert rules)
- Dashboards (Datadog dashboards, Grafana dashboards)
- Incidentes do Datadog (alertas/monitors agrupados — NAO incidentes de produto Stone)
- SLOs, Synthetics, RUM, Error Tracking, Security Signals
- Hosts, services, service dependencies
- Saude geral do app (estado, status, degraded/healthy/unhealthy)
- Grafana: datasources, folders, annotations, contact points, health check

**NAO cobre**:
- Incidentes de produto Stone (P0..P4, war room) — coberto por `active-incidents`, `closed-incidents`, `postmortems`
- Operacao ativa (deploy, rollback, rotate secret, lista apps) — coberto por `platform`
- Comportamento de usuario / Amplitude — coberto por `product_analytics`
- Metricas DORA — coberto por `dev_metrics`

## Exemplos de Perguntas

- "Quais erros estao acontecendo no payments-api em producao?"
- "Qual a latencia P99 do service X nos ultimos 30 minutos?"
- "Tem algum alerta ativo pro payments-api?"
- "Mostra o dashboard de metricas do service X no Datadog"
- "Analisa os logs de erro do auth-service na ultima hora"
- "Qual o throughput atual do payments-api?"
- "O app payments-api esta saudavel?"
- "Que dashboards existem no Grafana pra o service X?"
- "Detalhe do incident 12345 no Datadog"
- "Quais spans tem erro no distributed trace do checkout-service?"

## Conhecimento Embutido

### Tools — Inventario Canonico (37)

**Search Datadog (18):** `search_datadog_logs`, `search_datadog_spans`, `search_datadog_events`, `search_datadog_rum_events`, `search_datadog_security_signals`, `search_datadog_metrics`, `search_datadog_monitors`, `search_datadog_dashboards`, `search_datadog_downtimes`, `search_datadog_error_tracking_issues`, `search_datadog_hosts`, `search_datadog_incidents`, `search_datadog_notebooks`, `search_datadog_service_dependencies`, `search_datadog_services`, `search_datadog_slos`, `search_datadog_synthetics`, `search_grafana_dashboards`

**Read Datadog (8):** `analyze_datadog_logs(query, from?, to?, group_by?)`, `apm_search_change_stories(query?, service?, ...)`, `get_datadog_dashboard(dashboard_id)`, `get_datadog_incident(incident_id)`, `get_datadog_metric(query, from, to)`, `get_datadog_metric_context(metric_name)`, `get_datadog_monitor(monitor_id)`, `get_datadog_notebook(notebook_id)`

**Read Grafana (5):** `get_grafana_alert_rule(uid)`, `get_grafana_dashboard(uid)`, `get_grafana_datasource(uid)`, `get_grafana_folder(uid)`, `get_grafana_health()`

**List Grafana (5):** `list_grafana_alert_rules`, `list_grafana_annotations(from?, to?, tags?)`, `list_grafana_contact_points`, `list_grafana_datasources`, `list_grafana_folders`

**Query Grafana (1):** `query_grafana_datasource({ datasource_uid, expr, from?, to?, max_data_points? })`

### Selecao de Tool por Tipo de Pergunta

Esta tabela e o primeiro passo de qualquer turn do observe. Mapeie a pergunta do usuario pra coluna certa antes de chamar qualquer tool.

| Pergunta do usuario | Tool primaria | Fallback se a primaria voltar vazia |
|---|---|---|
| "Qual a latencia agora / em tempo real / nos ultimos minutos?" | `search_datadog_spans({ query: "service:<x> env:<env>" })` | `search_datadog_logs` filtrando por endpoint/duracao, depois `get_datadog_metric` |
| "Quantos erros agora / nos ultimos minutos?" | `search_datadog_logs({ query: "service:<x> env:<env> status:error" })` | `search_datadog_spans` com filtro `@error:*`, depois `search_datadog_error_tracking_issues` |
| "Throughput / req/s agora?" | `search_datadog_spans` (conta spans por segundo na janela) | `get_datadog_metric` com `trace.http.request{...}.as_rate()` |
| "Como o app esta? Saude geral?" | `search_datadog_monitors({ query: "service:<x>" })` + `get_full_deployment_status` | `search_datadog_spans` recentes + checar `@error:*` |
| "P95/P99 latencia historica (ultima hora+)" | `get_datadog_metric({ query: "p95:trace.<service>.request{...}", from, to })` | `search_datadog_spans` agregado client-side |
| "Tendencia ao longo de um dia/semana" | `get_datadog_metric` ou `get_datadog_dashboard` | `search_datadog_logs` com `aggregation` |
| "Existe algum alerta ativo?" | `search_datadog_monitors({ query: "status:Alert service:<x>" })` | `list_grafana_alert_rules` |
| "Que dashboards existem pra esse service?" | `search_datadog_dashboards({ filter })` | `search_grafana_dashboards` |
| "Detalhe do incident X" | `get_datadog_incident({ incident_id })` | `search_datadog_incidents` se nao tiver ID |

**Regra de ouro:** pra "agora / em tempo real / ultimos minutos / valores reais", comece sempre por `search_datadog_spans` ou `search_datadog_logs` — eles leem o storage de eventos diretamente e quase nunca voltam vazio se o service estiver vivo.

### Fluxo: Investigacao de Incident / Degradacao

1. Identifique escopo (qual service / env / janela temporal)
2. **Logs**: `search_datadog_logs({ query: "service:<x> env:<env> status:error", from, to })`. Use facets (`service:`, `env:`, `@http.status_code:`) — ver ref `datadog-search-syntax`
3. **Metrics**: `get_datadog_metric` pra time series especifica; `search_datadog_metrics` pra descobrir nome se incerto
4. **APM/Tracing**: `search_datadog_spans` com mesmo formato de query dos logs
5. Se o user mencionou alert: `search_datadog_monitors({ query })` ou `get_grafana_alert_rule({ uid })` direto
6. Sumarize insight + timeline + proxima acao; destaque a linha de erro relevante em code block

### Fluxo: Ler Dashboard

1. `search_datadog_dashboards({ filter })` ou `search_grafana_dashboards({ folder_uid?, limit? })`
2. `get_datadog_dashboard({ dashboard_id })` ou `get_grafana_dashboard({ uid })` — retorna definicao JSON
3. Resuma os panels relevantes + valores atuais. Nao cole o JSON completo no chat.

### Fluxo: Incident Datadog (alertas / monitors)

Datadog Incidents e uma feature DO DATADOG (alertas, monitors agrupados em incidente automaticamente). Nao confundir com incidentes de produto Stone:

| Pergunta do user | Skill correta |
|---|---|
| "Incidentes ABERTOS agora" / "P0 ativo" / "war room rolando?" | `active-incidents` |
| "Quantos P0 em maio?" / "Top produtos com incidentes" | `closed-incidents` |
| "Causa raiz do #N" / "Ja aconteceu parecido?" | `postmortems` |
| "Detalhe do incident X no Datadog" (alerta/monitor) | `observe` (esta skill) |

1. `search_datadog_incidents({ query })` — so pra Datadog Incidents
2. `get_datadog_incident({ incident_id })` pra detalhes + timeline + commanders
3. Apresenta status atual + timeline resumida + IC atual

## Instrucoes MCP

As tools de observabilidade estao disponiveis via Observability Manager MCP (Datadog + Grafana). Nao ha repositorio de documentacao para buscar — o conhecimento esta embutido nesta skill e nos references.

Quando o usuario precisar de informacoes alem do conhecimento embutido:

| Fonte | Quando buscar |
|---|---|
| ref `datadog-search-syntax` | Montar query Datadog especifica (facets, atributos custom, aggregations) |
| ref `grafana-query-patterns` | Query custom em Grafana (PromQL/LogQL/InfluxQL) ou ler dashboard JSON |
| ref `temporal-handling` | Query referenciar janela temporal ("ultima hora", "ontem", "mes passado") |

## Formato de Resposta

Ao responder perguntas deste dominio, siga este formato:

1. **Insight** (2-3 frases objetivas com o resultado da investigacao)
2. **Dados** (linha de erro em code block, metricas P50/P95/P99, timeline — nunca log completo)
3. **Proxima acao** (o que o usuario pode fazer a seguir — investigar mais, abrir incident, escalar)
4. **Avisos** (se aplicavel: tool voltou vazia + fallback usado, limitacoes de mutacao via MCP)

---
skill: observe
version: 1
---

# Evals: observe

## Happy-Path

### HP-001: Buscar erros em producao
**Input**: "Quais erros estao acontecendo no payments-api em producao?"
**Deve**:
- Usar `search_datadog_logs` com query contendo `service:payments-api env:prd status:error`
- Destacar linhas de erro relevantes em code block
- Sumarizar insight + proxima acao
**Nao deve**:
- Colar log completo no chat
- Inventar valores se a tool retornar vazio
**Fonte**: Exemplos de Perguntas #1

---

### HP-002: Latencia P99 recente
**Input**: "Qual a latencia P99 do service X nos ultimos 30 minutos?"
**Deve**:
- Comecar por `search_datadog_spans` (dados em tempo real) ou `get_datadog_metric` com query P99
- Apresentar valores em percentis (P50/P95/P99), nao media
**Nao deve**:
- Usar media como metrica principal
- Desistir na primeira tool vazia sem tentar fallback
**Fonte**: Exemplos de Perguntas #2

---

### HP-003: Alertas ativos
**Input**: "Tem algum alerta ativo pro payments-api?"
**Deve**:
- Usar `search_datadog_monitors` com filtro de status e service
- Se vazio, tentar `list_grafana_alert_rules` como fallback
**Nao deve**:
- Confundir alertas Datadog com incidentes de produto Stone
**Fonte**: Exemplos de Perguntas #3

---

### HP-004: Dashboard Datadog
**Input**: "Mostra o dashboard de metricas do service X no Datadog"
**Deve**:
- Usar `search_datadog_dashboards` para encontrar, depois `get_datadog_dashboard` para detalhes
- Resumir panels relevantes + valores atuais
**Nao deve**:
- Colar JSON completo do dashboard no chat
**Fonte**: Exemplos de Perguntas #4

---

### HP-005: Analise de logs com janela temporal
**Input**: "Analisa os logs de erro do auth-service na ultima hora"
**Deve**:
- Derivar from/to a partir da data atual injetada (ref temporal-handling)
- Usar `search_datadog_logs` ou `analyze_datadog_logs` com facets corretos
**Nao deve**:
- Esquecer parametros from/to na query
- Calcular epoch manualmente sem ancorar na data injetada
**Fonte**: Exemplos de Perguntas #5

---

### HP-006: Throughput atual
**Input**: "Qual o throughput atual do payments-api?"
**Deve**:
- Comecar por `search_datadog_spans` contando spans por segundo
- Se vazio, usar `get_datadog_metric` com `.as_rate()` como fallback
**Nao deve**:
- Sugerir abrir no browser na primeira falha
**Fonte**: Exemplos de Perguntas #6

---

### HP-007: Saude geral do app
**Input**: "O app payments-api esta saudavel?"
**Deve**:
- Usar `search_datadog_monitors` para checar alertas + `search_datadog_spans` para erros recentes
- Apresentar visao consolidada de saude
**Nao deve**:
- Responder so com base em uma tool — cruzar monitors + spans/logs
**Fonte**: Exemplos de Perguntas #7

---

### HP-008: Dashboards Grafana
**Input**: "Que dashboards existem no Grafana pra o service X?"
**Deve**:
- Usar `search_grafana_dashboards` com filtro relevante
- Listar dashboards encontrados com uid e titulo
**Nao deve**:
- Confundir tools de Datadog com tools de Grafana
**Fonte**: Exemplos de Perguntas #8

---

### HP-009: Incident Datadog
**Input**: "Detalhe do incident 12345 no Datadog"
**Deve**:
- Usar `get_datadog_incident({ incident_id: "12345" })`
- Apresentar status + timeline resumida + IC
**Nao deve**:
- Confundir com incidentes de produto Stone (active-incidents/closed-incidents/postmortems)
**Fonte**: Exemplos de Perguntas #9

---

### HP-010: Spans com erro
**Input**: "Quais spans tem erro no distributed trace do checkout-service?"
**Deve**:
- Usar `search_datadog_spans` com filtro `@error:*` e `service:checkout-service`
- Destacar spans com erro e seus atributos relevantes
**Nao deve**:
- Despejar todos os spans no chat sem filtrar os relevantes
**Fonte**: Exemplos de Perguntas #10

---

## Edge-Cases

### EC-001: Anti-surrender — tool retorna vazio
**Input**: "Mostra os erros do payments-api na ultima hora" (cenario onde search_datadog_logs retorna vazio)
**Deve**: Tentar ao menos 1 fallback (ex: search_datadog_spans com @error:*) antes de sugerir browser
**Nao deve**: Sugerir "abre no Datadog pelo browser" na primeira tool vazia sem tentar fallback
**Fonte**: Regras de Execucao #1

---

### EC-002: Nao fabricar explicacao tecnica pro vazio
**Input**: "Latencia do payments-api" (cenario onde get_datadog_metric retorna vazio mas search_datadog_spans retorna dados)
**Deve**: Dizer "get_datadog_metric voltou vazio; via search_datadog_spans consegui os dados" e apresentar os dados
**Nao deve**: Escrever bullets sobre "talvez seja retencao / permissao / schema interno" para explicar o vazio
**Fonte**: Regras de Execucao #2

---

### EC-003: Nunca inventar valores
**Input**: "Quantos erros no payments-api?" (cenario onde ambas tools retornam vazio)
**Deve**: Dizer "as duas tools voltaram vazias — sugiro confirmar pelo dashboard no Datadog/Grafana"
**Nao deve**: Inventar numeros ou fabricar teoria sobre por que as tools voltaram vazio
**Fonte**: Regras de Execucao #3

---

### EC-004: Logs no chat — so linha relevante
**Input**: "Analisa os logs de erro do auth-service"
**Deve**: Destacar apenas a(s) linha(s) de erro relevante(s) em code block com analise
**Nao deve**: Colar o log completo retornado pela tool no chat
**Fonte**: Regras de Execucao #4

---

### EC-005: Metricas em percentis
**Input**: "Qual a latencia do payments-api?"
**Deve**: Apresentar P50/P95/P99 com rollup explicito
**Nao deve**: Usar media como metrica principal de latencia
**Fonte**: Regras de Execucao #5

---

### EC-006: Operacoes read-only
**Input**: "Cria um monitor no Datadog pro payments-api"
**Deve**: Informar que mutacao nao tem tool MCP hoje e orientar o usuario a fazer via UI
**Nao deve**: Tentar criar/editar monitor ou alerta via MCP
**Fonte**: Regras de Execucao #6

---
name: create-app
description: "Provisiona app nova na plataforma via Backstage Scaffolder. Use quando o usuario quiser criar app, nova aplicacao, provisionar app, novo servico, novo worker, novo cronjob, novo job, subir api nova, scaffolder."
---

# Skill: Criar App

Provisionar app nova (api/worker/cronjob/job) via Backstage Scaffolder + `kli-mcp__create_app`. Nao confundir com:

| Pergunta do user                                                 | Skill correta       |
| ---------------------------------------------------------------- | ------------------- |
| "criar app" / "nova aplicacao" / "provisionar app"               | `create-app`        |
| "feature de codigo em app existente" / "servico novo dentro de repo" | `sdd`           |
| "dashboard estatico" / "publicar HTML/zip em S3"                 | `static-apps`       |
| "lista apps" / "secrets" / "deploy" / "describe app"             | `platform`          |
| "rodar template generico do Scaffolder"                          | `backstage`         |

Aqui chame `kli-mcp__create_app` direto, sem PRD/spec.

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.
-->

## Exemplos de Perguntas

- "Quero criar uma api nova"
- "Cria um app pra mim"
- "Preciso de uma nova aplicacao"
- "Provisiona um novo servico"
- "Preciso subir um worker novo"
- "Cria um cronjob pro meu time"
- "Quero criar um job"
- "Nova api em nodejs"

## Conhecimento Embutido

### Tools

**Pre-fetch paralelo (1a rodada, antes de qualquer pergunta):**
`whoami`, `list_contexts`, `list_org_units`, `list_github_groups`, `list_applications` (ate 50 mais recentes; ignore falha). Guarde tudo. Nao pergunte nada antes desse batch retornar.

**Sob demanda:**

- `list_cost_centers` — so se `profile.costCenter` veio vazio
- `repository_exists` — no passo de repo, pra auto-detectar existente vs novo a partir do nome
- `search_github_repositories`, `list_github_repository_teams` — so fluxo existing-repo
- `create_app` — so apos card de confirmacao aceito. **Async** — retorna `{ taskId, status: "in_progress" }`
- `get_app_creation_status({taskId})` — long-poll (~25s). Cap 20 polls.

### Fluxo resumido

Contrato reduzido: Vela conhece os campos obrigatorios de antemao. Passos detalhados na ref `create-app-flow`. Resumo:

1. **Pre-fetch** paralelo (5 tools acima)
2. Coleta: tipo → scope (PCI-DSS) → contexto (filtrado por PCI) → nome → cost center → org unit → repo (peça o nome, valide kebab-case ≤35; `repository_exists` auto-detecta existente/novo) → github (repo novo: grupo via `list_github_groups`; repo existente: team do repo via `list_github_repository_teams`) → monorepoType (**só** repo existente) → repo desc (**só** repo novo, opcional) → deploy strategy → language → version → framework (so api)
3. **Card de confirmacao** com `<suggestions>` `Sim, criar / Cancelar / Editar X`
4. Apos aceite: `create_app(...)` → `taskId`
5. **Polling**: `get_app_creation_status({taskId})` em loop ate terminal (cap 20)
6. **Render**: sucesso = catalogo + repo + ArgoCD + 3 proximos passos; falha = recovery cirurgico (ver ref)

`isMigrated` (boolean, opcional, default `false` = app nova) existe no contrato mas **nao e perguntado** — so marque `true` quando o user sinalizar migracao de outro runtime produtivo. Detalhes na ref `create-app-fields-and-validation`.

`provider`, `useDatadog`, descricao da app, documentation URL, owner Slack, OpsGenie e resources de cronjob/job **nao existem** no contrato — nunca pergunte nem envie. Provider e derivado do contexto server-side; owner/support/team vem via `orgUnitGroup`. cronjob/job usam defaults da plataforma (sem perguntas de resources).

Detalhes de cada passo, valores canonicos e few-shot completo na ref `create-app-flow`.

## Regras de Execucao

- **Pre-fetch sempre paralelo** (4 tools no 1o turn). **Nao pergunte nada** antes do batch retornar.
- **Auto-fill silencioso**: mostre valor inferido SOMENTE no card final. Antes do card, silencio total — anunciar inferencias duplica o card. Regras na ref `create-app-fields-and-validation`.
- **Lista finita → SEMPRE `<questions>`** (wizard). NUNCA emita perguntas de opcao finita como prosa quando houver 2+ no mesmo turn. Detalhes na ref.
- **Formato canonico ≠ option label**: mapeie option label pro valor canonico antes de submeter (`orgUnitGroup` submete a ref `group:<ns>/<slug>` mesmo mostrando `displayName`; `monorepoType` submete `type1`/`type2`; etc.). Errar isto e causa no 1 de falha runtime. Tabela na ref.
- **Falha nao restarta o fluxo** — recovery cirurgico (1 turno = 1 campo). Ver ref `create-app-error-recovery`.
- **Cap 20 polls** no `get_app_creation_status`. Loop infinito nunca.

## Instrucoes MCP

Todas as tools sao do servidor `kli-mcp`. Prefixo: `kli-mcp__`.

- `kli-mcp__whoami` — identidade do user (profile, githubTeams, costCenter)
- `kli-mcp__list_contexts` — contextos disponiveis (provider derivado server-side)
- `kli-mcp__list_org_units` — organizational-unit groups (`displayName` + ref `group:<ns>/<slug>`); entrega owner/support/team server-side
- `kli-mcp__list_github_groups` — grupos GitHub do user
- `kli-mcp__list_applications` — apps do user (ate 50; para inferencia via irmas)
- `kli-mcp__list_cost_centers` — cost centers (fallback se profile vazio)
- `kli-mcp__repository_exists` — checa existência EXATA de um repo. Input: **só o slug** do repo (ex.: `meu-servico`), **não** `owner/repo` nem URL; owner assumido `stone-payments`. Normalize o nome antes (kebab-case, ≤35). Auto-detecta `existRepo`
- `kli-mcp__search_github_repositories` — buscar repos existentes (fallback/descoberta de nome)
- `kli-mcp__list_github_repository_teams` — teams de um repo existente
- `kli-mcp__create_app` — criar app (async, retorna taskId)
- `kli-mcp__get_app_creation_status` — polling do status (long-poll ~25s)

`kli-mcp__list_opsgenie_groups` **nao e mais usada** pelo create-app — owner/support/team vem via `list_org_units` + `orgUnitGroup`.

## Formato de Resposta

### Durante coleta de campos

- Campos com lista finita: usar `<questions>` (wizard)
- Campos texto livre: prosa curta + `<suggestions>` apenas para chips de flow-control
- Sempre oferecer chip `Cancelar criacao`

### Card de confirmacao

Apos todos os campos coletados, exibir card com `<details>` contendo todos os valores e `<suggestions>` com `Sim, criar / Cancelar / Editar X`.

### Resultado — sucesso

```
✅ App **<nome>** criada!

- Task: <task-id>
- Repo: <repo-url>
- ArgoCD: <env> — <name>: <url>
- Catalogo: <catalog-url>

Proximos passos: <acao 1>, <acao 2> ou <acao 3>.
```

### Resultado — falha

```
❌ Nao consegui criar a app.

- Task: <task-id se houver>
- Erro: "<msg do scaffolder>"
```

Seguido de recovery cirurgico (reabrir so o campo problematico).

### Cancelamento

Triggers: chip `Cancelar criacao`, ou `"cancelar"`/`"esquece"`/`"deixa pra la"`/`"nao, deixa"`. Resposta: `"Beleza, cancelado."`. Nao chame `create_app`.

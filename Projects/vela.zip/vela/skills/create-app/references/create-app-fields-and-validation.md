# Reference: create-app fields, auto-fill rules, validation, canonical formats

Carregue quando estiver coletando campos pro `create_app` — auto-fill silencioso, inferência via apps irmãs, validação local, formato canônico de valores submetidos.

Contrato reduzido: Vela conhece todos os campos (e quais são obrigatórios) de antemão. Valide upfront; não dependa de erro do backend pra descobrir campo faltante.

## Campos do contrato

| Campo            | Obrigatório            | Notas                                                                  |
| ---------------- | ---------------------- | ---------------------------------------------------------------------- |
| `appType`        | sim                    | `api / worker / cronjob / job`                                         |
| `name`           | sim                    | kebab-case, ≤43                                                        |
| `scope`          | **sim**                | boolean PCI-DSS. Pergunte explícito; nunca omita                       |
| `isMigrated`     | **opcional**           | boolean. Migração de outro runtime produtivo (só métricas). Default `false` = app nova. **NÃO pergunte proativamente** — só quando o user sinalizar migração |
| `context`        | sim                    | `displayName` de `list_contexts`, **filtrado por PCI** (`supportPCI == scope`). Pergunte o `scope` antes |
| `costCenter`     | sim                    | profile (auto-fill) ou `list_cost_centers`                             |
| `orgUnitGroup`   | **sim**                | ref `group:<ns>/<slug>` de `list_org_units`. Entrega owner/support/team server-side |
| `deployStrategy` | sim                    | `branch / tag`                                                         |
| `existRepo`      | sim                    | boolean. **Auto-detectado**: peça o nome, **valide/normalize** (kebab-case ≤35, regra de `repoName`) e chame `repository_exists` (existe → `true`; não → `false`). NÃO pergunte "existe? sim/não" |
| `repository`     | existing-repo          | formato canônico `github.com?owner=stone-payments&repo=<r>`            |
| `monorepoType`   | **existing-repo only** | `type1` (unificados) / `type2` (independentes). Proibido em new-repo   |
| `repoName`       | new-repo only          | kebab-case, ≤35                                                        |
| `repoDescription`| **opcional**           | new-repo; não bloqueie criação por falta dela                          |
| `github`         | sim                    | ref (new-repo) ou team slug (existing-repo)                            |
| `language`       | sim                    | `nodejs / golang / python / csharp`                                    |
| `version`        | sim                    | por language                                                           |
| `framework`      | **só `api`**           | worker/cronjob/job não têm framework                                   |

`provider`, `useDatadog`, descrição da app, documentation URL, owner Slack, OpsGenie group e resources de cronjob/job **não existem** no contrato. Nunca pergunte nem envie esses campos. O `provider` é derivado do contexto server-side; nodejs sempre recebe APM.

## Auto-fill silencioso (NÃO perguntar, NÃO anunciar)

**Mostre o valor SOMENTE no card de confirmação no final.** Antes do card, **silêncio total**. Anunciar inferências antes do card duplica o card e gera fricção.

| Campo               | Fonte                                                            | Quando auto-fill            |
| ------------------- | ---------------------------------------------------------------- | --------------------------- |
| `costCenter`        | `profile.costCenter`                                             | não-vazio                   |
| `github` (new-repo) | `profile.githubTeams[0]`                                         | 1 entry                     |
| `version`           | nodejs=24, golang=1.25, python=3.12 (csharp 8.0/10.0 → pergunte) | language ∈ {nodejs, go, py} |
| `framework`         | api+python=fastapi; api+csharp=dotnet                           | combinação única            |

### Inferência via apps irmãs

Apps irmãs = `list_applications` com `status==active` em algum `profile.githubTeams[*]`. Para cada campo elegível, conte só as irmãs que **têm aquele campo preenchido**; chame esse total de `N`.

| Sinal                                              | Ação                                                                    |
| -------------------------------------------------- | ----------------------------------------------------------------------- |
| `N == 0` ou `list_applications` falhou             | ignore inferência; siga fluxo padrão                                    |
| `N >= 1` e **todas** concordam                     | auto-fill silencioso                                                    |
| `N >= 2` e moda em **estritamente mais da metade** | use moda como **default** na pergunta (campo "Outro" deixa user trocar) |
| Empate ou nenhuma moda dominante                   | pergunte normal, sem default                                            |

Campos elegíveis: `context`, `costCenter` (fallback), `orgUnitGroup` (top-3 antes do fuzzy), `language`, `framework` (condicional a appType=api+language), `deployStrategy`.

Regras absolutas, sem percentuais — a tabela é literal.

## Validação local (antes do card)

Falha → frase curta + repergunta. Não avance, não chame tool. **Aplica também a respostas no campo "Outro" do `<questions>`.**

| Campo             | Regra                                    |
| ----------------- | ---------------------------------------- |
| `name`            | `^([a-z0-9]*)(-[a-z0-9]+)*$`, ≤ 43        |
| `orgUnitGroup`    | `^group:[a-z0-9-]+/[a-z0-9-]+$` (required) |
| `repoName`        | `^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$`, ≤ 35   |
| `repoDescription` | ≤ 200 (opcional — pode ficar vazio)       |
| `monorepoType`    | `type1` ou `type2`; required-when-existing, forbidden-when-new |
| `scope`           | boolean; required (pergunte explícito)    |
| `isMigrated`      | boolean; opcional (default false). Só `true` se migração explícita |
| `framework`       | only-for-api; ausente para worker/cronjob/job |

## Regras de pergunta

- **Lista finita → SEMPRE `<questions>`.** Aplica a `appType`, `scope`, `orgUnitGroup`, `monorepoType`, `language`, `version`, `framework`, `deployStrategy`. Frontend renderiza wizard de 1 pergunta por vez com radios/checkboxes + campo "Outro" automático — **não inclua "Outro" nas options**. Não use `<suggestions>` pra opções de campo.

- **`existRepo` NÃO é pergunta** — é auto-detectado via `repository_exists` a partir do nome do repo digitado (existe → reuso; não → criação). **Valide/normalize o nome (kebab-case, ≤35) antes de chamar** — input inválido não deve virar `repoName` (new-repo) nem `repository` canônico (existing-repo); repergunte. Só caia na pergunta `Sim / Não` se o `repository_exists` falhar/for ambíguo.

- **`isMigrated` é opt-in, não perguntado.** NÃO inclua no wizard nem no batch. Default `false` (app nova). Só marque `true` quando o user disser que está migrando uma app já existente em outro runtime produtivo (ex: "é uma migração", "essa app já roda em X"). Na dúvida, deixe `false`. Quando `true`, inclua a linha no card de confirmação.

- **Batch quando faz sentido**: vários campos finitos no mesmo turn (ex: após pré-fetch sem inferência) → um único bloco `<questions>` com múltiplas perguntas.

- **NUNCA emita perguntas de opção finita como prosa quando houver 2+ no mesmo turn.** Bullets/parágrafos do tipo "Preciso de mais alguns detalhes: - X? - Y?" violam o contrato; frontend não renderiza form.

- **Texto livre** (`name`, `repoName`, `repoDescription`) — prosa curta + `<suggestions>` apenas para chips de flow-control (meta-ações, NÃO opções de campo):

  - sempre: `Cancelar criação`
  - `repoName` se `len(name) ≤ 35`: `Usar nome da app`
  - `repoDescription`: opcional → chip `Pular descrição`

- **Listas > 8 itens** (org units, github groups) → top-8 nas `options`; campo "Outro" cobre o resto.

- **PARSE respostas multi-campo.** User pode responder com vários campos numa só mensagem (`"teste-api, nodejs 24, express, repo novo, branch"`). Extraia tudo, valide local, e pergunte só o que falta.

- **Fuzzy / aliases.** Aceite entradas amigáveis em vez de re-perguntar. Pra `language`, aceite `node`/`node.js` apenas se inequívoco (caso `api+nodejs`, pergunte api-express vs api-typescript). A KLI também aceita labels do Portal UI (`NodeJS`, `Express JS`) e normaliza — mas prefira sempre os ids técnicos canônicos.

## Formato dos valores submetidos (canonical)

Option label no `<questions>` = human-readable. Valor que vai pra `create_app(...)` = formato exato abaixo. **Errar isto é causa nº 1 de falha em runtime.**

| Campo                    | Origem                                             | Option label                   | Valor que vai                                      |
| ------------------------ | -------------------------------------------------- | ------------------------------ | -------------------------------------------------- |
| `orgUnitGroup`           | `list_org_units` → `{displayName, ref}`            | `displayName`                  | **`group:<namespace>/<slug>`** (ref completa).     |
| `context`                | `list_contexts` → `{displayName, cloudProviders}`  | `displayName`                  | **`displayName`** (literal).                       |
| `costCenter`             | `list_cost_centers` → `{cost-center, description}` | `description` ou `cost-center` | **`cost-center`** (código, ex. `820140820`).       |
| `monorepoType`           | `<questions>`                                      | `Workflows unificados/indep.`  | **`type1`** (unificados) / **`type2`** (indep.).   |
| `github` (new-repo)      | `list_github_groups`                               | ref completa                   | **`group:stone-payments/<team>`**.                 |
| `github` (existing-repo) | `list_github_repository_teams`                     | team slug                      | **team slug** sem `group:` nem `stone-payments/`.  |
| `repository` (existing)  | nome digitado, confirmado por `repository_exists` (ou `search_github_repositories`) | repo | **`github.com?owner=stone-payments&repo=<repo>`**. |

Quando user escolher via option label, mapeie pro valor canônico antes de submeter — não passe o label direto.

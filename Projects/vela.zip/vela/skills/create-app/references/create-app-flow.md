# Reference: create-app fluxo + card + polling + render

Fluxo completo, polling do scaffolder, render do resultado e few-shot. Carregue quando estiver executando criação real (não só explicando o playbook).

O contrato do `create_app` é reduzido: Vela já conhece todos os campos obrigatórios de antemão. Colete tudo upfront; recovery via erro é fallback, não o mecanismo de descoberta.

## Fluxo

1. **Pré-fetch** (whoami + list_contexts + list_org_units + list_github_groups + list_applications, paralelo). Não pergunte nada antes do batch retornar.
2. **Tipo:** `<questions>` `api / worker / cronjob / job`.
3. **Scope / PCI-DSS (obrigatório).** `<questions>` `Sim, PCI-DSS / Não`. Pergunte **antes do contexto** — o scope filtra a lista de contextos (igual ao Portal/KLI). Pergunte explicitamente; nunca omita silenciosamente. Submeta boolean.
   - **`isMigrated` (opcional, NÃO perguntar).** Default `false` = app nova. Só submeta `true` se o user sinalizar que está migrando uma app de outro runtime produtivo. Quando `true`, inclua a linha no card de confirmação.
4. **Contexto.** `<questions>` com `displayName`, **filtrado por PCI**: mostre só contextos com `supportPCI == scope` (filtre a lista do pré-fetch por `supportPCI`, ou re-chame `list_contexts(scope=true)` quando o scope for PCI). Aplique inferência dentro do conjunto filtrado. (O `provider` é derivado server-side do contexto — **não pergunte**.)
5. **Nome** (texto livre). Validação local (ver ref `create-app-fields-and-validation`).
6. **Cost center.** Auto-fill silencioso se `profile.costCenter`. Vazio → tente inferência → senão `list_cost_centers` + `<questions>` (top-8).
7. **Org unit (obrigatório).** `<questions>` com `displayName` das entries de `list_org_units`; submeta a ref `group:<namespace>/<slug>`. Ranking: (a) apps irmãs (>80% → auto-fill); (b) fuzzy match com o time do user; cap 3 options. Sem matches óbvios → top-8. Este campo entrega owner/support/team server-side (via `kapi_group_lookup` do template) — substitui Owner Slack + OpsGenie.
8. **Repositório (auto-detect — NÃO pergunte "existe? sim/não").** Peça o **nome do repo** (texto livre; reuse `name` se ≤ 35 via chip "Usar nome da app"). **Valide/normalize antes de chamar a tool** (kebab-case, ≤ 35 — mesma regra de `repoName`; aceite só o slug, sem `owner/` nem URL); input inválido → repergunte, **não** chame a tool. Chame `repository_exists({repo})` (só o slug; owner default `stone-payments`) e ramifique pelo `exists`:
   - **`exists: true` → repo existente:** `existRepo=true`; `repository` no formato canônico `github.com?owner=stone-payments&repo=<repo>`. `github`: `list_github_repository_teams` → `<questions>` com os slugs (vira o `github`). **`monorepoType` (obrigatório):** `<questions>` `Workflows unificados (type1) / Workflows independentes (type2)`.
   - **`exists: false` → repo novo:** `existRepo=false`; `repoName` = o nome digitado. `github`: auto-fill se `profile.githubTeams` tiver 1 entry, senão `<questions>` (`list_github_groups`). `repoDescription` **opcional** (texto livre ou pule — não bloqueie a criação).
     - ⚠️ **Negativo incerto:** `exists:false` vem de uma busca substring sem garantia de completude. Se o `searchedCount` no retorno for grande/no limite, trate o "não existe" como incerto e **confirme** (`Esse repo já existe? Sim / Não`) antes de assumir repo novo — evita criar um repo que já existe.
   - **Fallback (cai na pergunta `Repo existente? Sim / Não`):** quando `repository_exists` **falhar**, for **ambíguo**, ou **não estiver disponível** (ex.: `unknown tool` — o kli-mcp ainda sem o tool publicado; ≠ "a checagem falhou"). Siga o ramo escolhido. (`search_github_repositories` continua disponível pro user achar o nome exato de um repo existente.)
   - **Owner:** o fluxo assume `stone-payments`. Se o user indicar outro owner, trate como repo **existente** (o create-app só cria sob `stone-payments`) e use `search_github_repositories`/o nome canônico `github.com?owner=<owner>&repo=<repo>`.
9. **Deploy strategy:** `<questions>` `branch / tag`.
10. **Language:** inferência via irmãs; senão `<questions>` `nodejs / golang / python / csharp`.
11. **Version:** auto quando única. csharp → `<questions>` `8.0 / 10.0`.
12. **Framework** (**só `api`**). Auto quando único. Combinações com 2+ ids → inferência → senão `<questions>`. cronjob/worker/job **não** têm framework (usam defaults da plataforma). **Aliases aceitos** (mapeie pro id canônico):
    - `express` → `api-express`; `ts`/`typescript`/`express-ts` → `api-typescript`
    - `gin-gonic` → `gin`; `chi`, `gin`, `http`, `fastapi`, `dotnet` já são ids
    - api+nodejs → `api-express / api-typescript`
    - api+golang → `chi / gin / http`
    - api+python → auto `fastapi`
    - api+csharp → auto `dotnet`
13. **Confirmação:** card abaixo. **Não chame `create_app` ainda.**
14. **Submissão:** após aceite, `create_app(...)` com formatos canônicos. Retorna `{taskId, status: "in_progress"}`. Mostre "Criando… (task `<id>`)" e siga.
15. **Polling:** `get_app_creation_status({taskId})` em loop até terminal. Cada chamada é long-poll de ~25s — não martele a 1s. Cap 20 calls.

Job e cronjob **não** têm passos de resources (schedule/command/args/restartPolicy/concurrency/limits/etc.) — o template aplica defaults da plataforma. Não pergunte nada disso.

## Card de confirmação

CTA final, após todos os campos coletados. Use `<suggestions>` (não `<questions>`) — confirmar criação é ação de aprovação, não pergunta de formulário.

```markdown
<details>
<summary>Confirmar criação</summary>

- **Tipo:** api
- **Scope (PCI-DSS):** não
- **Contexto:** tools-stg
- **Nome:** minha-nova-api
- **Cost center:** 820140820 (do seu perfil)
- **Org unit:** group:stone-payments/payments-fp-platform
- **Migração de outro runtime:** sim _(inclua esta linha só quando `isMigrated` for `true`)_
- **Repo:** novo (`stone-payments/minha-nova-api`)
- **GitHub group:** group:stone-payments/payments-team (do seu perfil)
- **Deploy strategy:** branch
- **Language:** nodejs 24
- **Framework:** api-express

</details>

<suggestions>
- Sim, criar
- Cancelar
- Editar nome
- Editar contexto
- Editar language
</suggestions>
```

Para existing-repo, o bloco de repo vira `**Repo:** existente (`stone-payments/<repo>`)` + `**monorepoType:** Workflows unificados (type1)` e o `**GitHub group:**` mostra o team slug.

## Polling semantics

`create_app` é assíncrono; scaffolder real leva 1-3 min. `get_app_creation_status` faz long-poll server-side (~25s) e retorna assim que `status` ou `steps` mudam. Shape:

```json
{
  "taskId": "...",
  "status": "processing | completed | failed | cancelled",
  "steps": [{ "name": "...", "status": "...", "error": "..." }],
  "repoUrl": "https://github.com/...",
  "argocdApps": [{ "name": "...", "url": "...", "env": "..." }],
  "applicationIdentity": "namespace/name"
}
```

- `processing` → re-chame com mesmo taskId (não há cadência mínima — tool bloqueia).
- `completed` → renderize sucesso.
- `failed` / `cancelled` → renderize falha; use `steps[*].error` (1º step `failed`) pra mapear na tabela de Recovery (ver ref `create-app-error-recovery`).

**Cap 20 polls.** Se ainda `processing` no 20º, mostre "Tá demorando — abre <task-url>; me chama quando terminar." e pare. Não use loop infinito.

**Falha não restarta o fluxo** — use Recovery cirúrgico (ver ref `create-app-error-recovery`).

## Render do resultado — sucesso

Apenas com `status === "completed"`. Para o link do catálogo, divida `applicationIdentity` em `<namespace>/<name>`:

`https://karavela-portal.stone.tech/new-catalog/<namespace>/Application/<name>`

Exemplo: `applicationIdentity = "foundation-platform/karavela-vela-test-api"` → `.../new-catalog/foundation-platform/Application/karavela-vela-test-api`. **Não** use a rota antiga `/catalog/<applicationIdentity>`.

```markdown
✅ App **<nome>** criada!

- Task: <task-id>
- Repo: <repo-url>
- ArgoCD:
  - <env> — <name>: <url>
- Catálogo: <catalog-url>

Próximos passos: <ação 1>, <ação 2> ou <ação 3>.
```

Frase de "próximos passos" é prosa curta — **NÃO use `<suggestions>` nem `<questions>` aqui** (não é pergunta do flow ativo, é fechamento informativo).

**Ações sugeridas** (escolha 3 contextuais, em ordem de prioridade):

1. sempre: configurar secrets
2. se tem apps irmãs: ver runbook do time
3. se new-repo: clonar o repo
4. se cronjob/job: validar o deploy no ArgoCD

## Render do resultado — falha

Aciona quando `create_app` retorna erro síncrono **ou** `get_app_creation_status` retorna `failed`/`cancelled`. Comece com `❌ Não consegui criar a app.` + Task ID se houver. Aplique Recovery cirúrgico (ver ref `create-app-error-recovery`). **Não restart o fluxo** — identifique o campo, reabra só ele, mantenha o resto em memória, volte ao card atualizado, reenvie.

## Few-shot

**U:** quero criar uma api nova
**V:** _(pré-fetch paralelo: 0 apps irmãs → flow começa do zero, sem inferências)_

```
<questions>
- q: Qual tipo de app?
  select: single
  options:
    - api
    - worker
    - cronjob
    - job
</questions>
```

**U:** api → **V:** _(`<questions>` scope PCI-DSS)_
**U:** não → **V:** _(`<questions>` contexto — filtrado por PCI; provider derivado, não pergunta)_
**U:** tools-stg → **V:** Nome? (≤43, kebab-case)
**U:** minha-nova-api → **V:** _(`<questions>` org unit; cost center auto do perfil)_
**U:** payments-fp-platform _(submete `group:stone-payments/payments-fp-platform`)_ → **V:** Nome do repo? _(chip "Usar nome da app")_
**U:** minha-nova-api _(`repository_exists` → não existe → repo novo; github auto: payments-team; desc opcional → pula)_ → **V:** _(`<questions>` deploy + language no mesmo bloco)_
**U:** branch + python _(version auto: 3.12; framework auto: fastapi)_ → **V:** _(card de confirmação)_
**U:** Sim, criar → **V:** _(create_app → taskId)_ Criando… _(polling até completed)_
✅ App **minha-nova-api** criada! _(link do catálogo + ações)_

# Reference: create-app scaffolder error recovery

Vela agora conhece o contrato reduzido e **valida os campos obrigatórios upfront** (`scope`, `orgUnitGroup`, `monorepoType` para existing-repo, etc.). Recovery via erro é **fallback**, não o mecanismo de descoberta de campos. Quando mesmo assim `create_app` falha (síncrono ou via `get_app_creation_status` retornando `failed`/`cancelled`), o `steps[*].error` traz a causa. Aplique recovery cirúrgico — **NÃO reinicie o fluxo**, identifique o campo problemático e reabra só ele.

## Princípio: 1 turno = 1 campo

Múltiplos campos quebrando juntos é raro. Quando acontece, trate em sequência, sempre voltando ao card atualizado entre cada fix. **Não force o user a recomeçar do zero** — o resto da resposta dele continua válido na memória da conversa.

## Tabela de mapeamento erro → ação

| Mensagem do scaffolder                                        | Reabrir / explicação                                                                      |
| ------------------------------------------------------------- | ----------------------------------------------------------------------------------------- |
| `framework` rejeitado (ex: `express` em vez de `api-express`) | `framework` — só `api` tem framework; veja ids exatos por (api, language) no passo **Framework** do Fluxo |
| `version` rejeitada                                           | `version` — schema só aceita 1–2 versões por language. Veja o passo **Version** do Fluxo                  |
| `orgUnitGroup` faltando ou ref inválida (`group not found`)   | `orgUnitGroup` — relliste via `list_org_units` e submeta a ref `group:<ns>/<slug>` correta |
| `monorepoType is required` (repo existente)                   | `monorepoType` — só existing-repo. Pergunte `type1` (unificados) / `type2` (independentes) |
| `scope is required`                                           | `scope` — pergunte explícito Sim, PCI-DSS / Não e submeta boolean                         |
| `repository already exists`                                   | reabra o passo **Repositório** do Fluxo — o auto-detect (`repository_exists`) deve ter pego como existente; reuse o repo `<n>` (não pergunte Sim/Não) |
| Regex/length em `name`                                        | `name`                                                                                    |
| Regex/length em `repoName`                                    | `repoName`                                                                                |
| `invalid context`                                             | "Esse contexto não existe mais. Vou relistar." + `list_contexts`                          |
| Contexto esperado não aparece na lista                       | `scope` foi definido depois da listagem — pergunte o PCI-DSS **antes** de listar contextos (filtro `supportPCI`) |
| Erro sobre grupo organizacional na execução (formulário passou) | validação do grupo só ocorre na execução — relliste `list_org_units` e submeta a ref correta |
| Outro                                                         | Mostre a mensagem original entre aspas e sugira ticket no canal de suporte                |

## Render de falha

Inicie a resposta com:

```
❌ Não consegui criar a app.

- Task: <task-id se houver>
- Erro: "<msg do scaffolder, copiada literal>"
```

Depois aplique a tabela acima: reabra **o único campo problemático**, mantenha os outros campos do card em memória, e após o user responder, volte ao card atualizado e reenvie `create_app(...)`.

## Cancelamento

Triggers: chip flow-control `Cancelar criação`, ou texto livre `"cancelar"`, `"esquece"`, `"deixa pra lá"`, `"não, deixa"`.

Resposta: `"Beleza, cancelado."` Não chame `create_app`. Limpe o estado mental do fluxo.

## Anti-patterns

- Não restart do fluxo do passo 1 quando 1 campo falhou — perde 80% do progresso e frustra o user
- Não tente `create_app` de novo sem ajustar o campo problemático — falha igual
- Não invente ref de org unit / context / cost center — sempre olhe o resultado da `list_*` correspondente
- Não dependa de erro do backend pra "descobrir" campo obrigatório — o contrato é conhecido; colete `scope`, `orgUnitGroup` e `monorepoType` (existing-repo) upfront
- Não mostre `taskId` sem explicar o que ele significa — task IDs aparecem em URLs do scaffolder; o user precisa pra forensics

---
skill: create-app
version: 1
---

# Evals: Create App

## Happy-Path

### HP-001: Criar API nova
**Input**: "Quero criar uma api nova"
**Deve**:
- Disparar pre-fetch paralelo (whoami, list_contexts, list_org_units, list_github_groups, list_applications) antes de qualquer pergunta
- Iniciar coleta de campos via wizard (questions)
**Nao deve**:
- Perguntar algo ao user antes do pre-fetch retornar
- Assumir valores de campos sem inferencia
**Fonte**: Exemplos de Perguntas #1

---

### HP-002: Criar app generico
**Input**: "Cria um app pra mim"
**Deve**:
- Executar pre-fetch paralelo no primeiro turn
- Perguntar o tipo de app (api/worker/cronjob/job) via questions
**Nao deve**:
- Pular o pre-fetch e ir direto pra coleta de campos
- Assumir que o tipo e api sem perguntar
**Fonte**: Exemplos de Perguntas #2

---

### HP-003: Nova aplicacao
**Input**: "Preciso de uma nova aplicacao"
**Deve**:
- Reconhecer como intencao de criar app
- Executar pre-fetch paralelo no primeiro turn
**Nao deve**:
- Redirecionar pra skill platform ou sdd
- Emitir inferencias antes do card final de confirmacao
**Fonte**: Exemplos de Perguntas #3

---

### HP-004: Provisionar servico
**Input**: "Provisiona um novo servico"
**Deve**:
- Tratar como criacao de app via scaffolder
- Iniciar fluxo de coleta com pre-fetch paralelo
**Nao deve**:
- Confundir com feature nova (sdd) ou deploy de app existente (platform)
**Fonte**: Exemplos de Perguntas #4

---

### HP-005: Criar worker
**Input**: "Preciso subir um worker novo"
**Deve**:
- Inferir tipo = worker e confirmar no card final
- Seguir fluxo de coleta dos demais campos
**Nao deve**:
- Perguntar tipo novamente se o user ja informou worker
- Anunciar a inferencia antes do card de confirmacao
**Fonte**: Exemplos de Perguntas #5

---

### HP-006: Criar cronjob
**Input**: "Cria um cronjob pro meu time"
**Deve**:
- Inferir tipo = cronjob
- Coletar org unit e scope (PCI-DSS) como nos demais tipos
**Nao deve**:
- Tratar como api ou worker
- Perguntar resources de cronjob (schedule/command/etc.) — o template aplica defaults da plataforma
- Perguntar framework para cronjob
**Fonte**: Exemplos de Perguntas #6

---

### HP-007: Criar job
**Input**: "Quero criar um job"
**Deve**:
- Inferir tipo = job
- Coletar org unit e scope (PCI-DSS) como nos demais tipos
**Nao deve**:
- Confundir job com cronjob
- Pular pre-fetch paralelo
- Perguntar resources de job (command/args/restartPolicy/etc.) — defaults da plataforma
**Fonte**: Exemplos de Perguntas #7

---

### HP-008: API com linguagem especifica
**Input**: "Nova api em nodejs"
**Deve**:
- Inferir tipo = api e language = nodejs
- Confirmar ambos no card final
- Pular perguntas de tipo e linguagem durante coleta
**Nao deve**:
- Perguntar tipo ou linguagem novamente
- Anunciar inferencias antes do card final
**Fonte**: Exemplos de Perguntas #8

---

## Edge-Cases

### EC-001: Pre-fetch deve ser paralelo e bloqueante
**Input**: "Cria um app novo pra mim"
**Deve**: Chamar whoami, list_contexts, list_org_units, list_github_groups e list_applications em paralelo no primeiro turn, e so interagir com user apos retorno
**Nao deve**: Fazer as chamadas sequencialmente ou perguntar algo antes do batch retornar
**Fonte**: Regras de Execucao #1

---

### EC-002: Auto-fill silencioso ate card final
**Input**: "Cria uma api nova" (user tem um unico contexto e cost center)
**Deve**: Inferir contexto e cost center silenciosamente e mostra-los apenas no card de confirmacao final
**Nao deve**: Anunciar "Inferi que seu contexto e X" durante a coleta de campos — isso duplica o card
**Fonte**: Regras de Execucao #2

---

### EC-003: Opcoes finitas sempre via questions
**Input**: "Cria um app novo" (momento de perguntar tipo)
**Deve**: Apresentar opcoes de tipo (api/worker/cronjob/job) via bloco questions (wizard)
**Nao deve**: Emitir as opcoes como prosa corrida quando ha 2+ opcoes no mesmo turn
**Fonte**: Regras de Execucao #3

---

### EC-004: Formato canonico vs label de opcao
**Input**: User seleciona a org unit pelo displayName "meu-time-ops"
**Deve**: Mapear o displayName exibido pra ref canonica `group:<ns>/<slug>` antes de submeter a create_app no campo orgUnitGroup
**Nao deve**: Submeter o displayName legivel em vez da ref `group:...` no campo orgUnitGroup
**Fonte**: Regras de Execucao #4

---

### EC-005: Falha nao restarta fluxo completo
**Input**: create_app falha por nome duplicado
**Deve**: Reabrir apenas o campo problematico (nome) em um unico turno e resubmeter
**Nao deve**: Restartar toda a coleta de campos desde o inicio
**Fonte**: Regras de Execucao #5

---

### EC-006: Cap de 20 polls no status
**Input**: create_app retorna taskId e status fica in_progress por muito tempo
**Deve**: Parar de fazer polling apos 20 chamadas a get_app_creation_status e informar o user
**Nao deve**: Continuar polling indefinidamente em loop infinito
**Fonte**: Regras de Execucao #6

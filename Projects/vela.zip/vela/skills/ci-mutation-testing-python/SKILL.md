---
name: ci-mutation-testing-python
description: "Testes de mutacao para projetos Python usando o workflow reutilizavel python-mutanting com cosmic-ray. Use quando o usuario perguntar sobre como adicionar testes de mutacao em Python, configurar o cosmic-ray, o arquivo cosmic-ray.toml, integrar com o workflow reutilizavel, threshold de MSI, diff_mode ou envio de metricas de mutacao ao Kafka."
---

# Skill: Mutation Testing — Python / cosmic-ray

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.
-->

> ### ⚠️ Pré-requisito: Acesso às Org Secrets de Kafka
>
> Para usar os secrets de Kafka, **adicione o nome do repositório do seu projeto** em todos os arquivos abaixo no repositório `stone-payments/terraform-github` (via Pull Request para revisão):
>
> Caminho base: `applications/org-secrets/stone-payments/secrets.installation.d/`
>
> | Arquivo YAML | Nome da org secret | Input do workflow |
> |---|---|---|
> | `QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD.yaml` | `QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD` | `KAFKA_BROKER_URL` |
> | `QA_MATURITY_KAFKA_SASL_USERNAME_PRD.yaml` | `QA_MATURITY_KAFKA_SASL_USERNAME_PRD` | `KAFKA_SASL_USERNAME` |
> | `QA_MATURITY_KAFKA_SASL_PASSWORD_PRD.yaml` | `QA_MATURITY_KAFKA_SASL_PASSWORD_PRD` | `KAFKA_SASL_PASSWORD` |
> | `QA_MATURITY_KAFKA_SCHEMA_ENDPOINT_PRD.yaml` | `QA_MATURITY_KAFKA_SCHEMA_ENDPOINT` ⚠️ (sem `_PRD`) | `KAFKA_SCHEMA_ENDPOINT` |
> | `QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD.yaml` | `QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD` | `KAFKA_SCHEMA_USERNAME` |
> | `QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD.yaml` | `QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD` | `KAFKA_SCHEMA_PASSWORD` |
>
> Ao chamar o workflow, mapeie as org secrets para os inputs corretamente:
>
> ```yaml
> secrets:
>   KAFKA_BROKER_URL: ${{ secrets.QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD }}
>   KAFKA_SASL_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SASL_USERNAME_PRD }}
>   KAFKA_SASL_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SASL_PASSWORD_PRD }}
>   KAFKA_SCHEMA_ENDPOINT: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_ENDPOINT }}
>   KAFKA_SCHEMA_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD }}
>   KAFKA_SCHEMA_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD }}
> ```

## Escopo

**Cobre**:
- Como incorporar o workflow `python-mutanting` em um projeto Python
- Pre-requisito: arquivo `cosmic-ray.toml` de configuracao do cosmic-ray
- Todos os inputs do workflow (`diff_mode`, `python_version`, `working_directory`, `config_file`, `session_file`, `threshold`)
- Secrets opcionais para envio de metricas ao Kafka (`KAFKA_*`)
- O que e MSI e como funciona o threshold
- Diferenca entre `diff_mode: changed` (pula se nenhum `.py` foi alterado) e `diff_mode: total`
- Como o cosmic-ray funciona: init session → exec → leitura de resultados via WorkDB ou SQLite
- Formato do comentario automatico na PR
- Uso em monorepos com `working_directory`
- Envio de metricas ao Kafka via `quality-maturity-report-layer`

**NAO cobre**:
- Escrita de testes com pytest/unittest
- Configuracao avancada de operadores de mutacao do cosmic-ray
- Infraestrutura de Kafka

## Exemplos de Perguntas

- "Como adiciono testes de mutacao no meu projeto Python?"
- "Quais pre-requisitos meu projeto Python precisa ter para usar o python-mutanting?"
- "Como crio o arquivo cosmic-ray.toml?"
- "Como configuro o cosmic-ray para rodar com pytest?"
- "O que e diff_mode: changed vs total em Python?"
- "Como defino um threshold de MSI para Python?"
- "Posso usar o config_file em um caminho diferente da raiz?"
- "Como funciona o session_file do cosmic-ray?"
- "Como envio metricas de mutacao Python para o Kafka?"

## Conhecimento Embutido

### Localizacao do Workflow

```
stone-payments/github-actions-workflows
  .github/workflows/python-mutanting.yml
```

Referencia para consumo: `@python-mutanting-v0`

---

### Pre-requisito: Arquivo cosmic-ray.toml

O workflow usa o [cosmic-ray](https://cosmic-ray.readthedocs.io/) como ferramenta de mutation testing. O projeto precisa de um arquivo de configuracao TOML:

```toml
# cosmic-ray.toml (padrao, na raiz do projeto)

[cosmic-ray]
module-path = "src/mymodule"           # modulo Python a ser mutado
timeout = 10.0                          # timeout por mutacao em segundos
excluded-modules = []                   # modulos a excluir
test-command = "python -m pytest tests/" # comando para rodar os testes

[cosmic-ray.distributor]
name = "local"                          # executar localmente (recomendado)
```

> O cosmic-ray e instalado automaticamente pelo workflow via `pip install cosmic-ray`.
> As dependencias do projeto tambem sao instaladas automaticamente a partir de `requirements.txt`, `requirements-dev.txt` ou `pyproject.toml`.

---

### Como Integrar o Workflow

#### Uso Minimo

```yaml
# .github/workflows/ci.yml
jobs:
  mutation:
    uses: stone-payments/github-actions-workflows/.github/workflows/python-mutanting.yml@python-mutanting-v0
```

#### Com Config Customizado e Threshold

```yaml
jobs:
  mutation:
    uses: stone-payments/github-actions-workflows/.github/workflows/python-mutanting.yml@python-mutanting-v0
    with:
      python_version: '3.12'
      config_file: '.cosmic-ray/config.toml'
      diff_mode: total
      threshold: 65
```

#### Em Monorepo com working_directory

```yaml
jobs:
  mutation:
    uses: stone-payments/github-actions-workflows/.github/workflows/python-mutanting.yml@python-mutanting-v0
    with:
      working_directory: services/my-service
      config_file: 'cosmic-ray.toml'
      session_file: 'mutation-session.sqlite'
```

#### Com Envio ao Kafka

```yaml
jobs:
  mutation:
    uses: stone-payments/github-actions-workflows/.github/workflows/python-mutanting.yml@python-mutanting-v0
    with:
      threshold: 70
    secrets:
      KAFKA_BROKER_URL: ${{ secrets.QA_MATURITY_KAFKA_SASL_ENDPOINT_PRD }}
      KAFKA_SASL_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SASL_USERNAME_PRD }}
      KAFKA_SASL_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SASL_PASSWORD_PRD }}
      KAFKA_SCHEMA_ENDPOINT: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_ENDPOINT }}
      KAFKA_SCHEMA_USERNAME: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_USERNAME_PRD }}
      KAFKA_SCHEMA_PASSWORD: ${{ secrets.QA_MATURITY_KAFKA_SCHEMA_PASSWORD_PRD }}
```

---

### Inputs Disponiveis

| Input | Tipo | Obrigatorio | Descricao | Padrao |
|-------|------|-------------|-----------|--------|
| `runs_on` | string (JSON) | nao | Runner a usar | `"['small-runner']"` |
| `diff_mode` | string | nao | `"changed"` (pula se nenhum `.py` alterado) ou `"total"` (projeto todo) | `"changed"` |
| `working_directory` | string | nao | Diretorio do projeto Python | `"."` |
| `python_version` | string | nao | Versao do Python (ex: `"3.11"`, `"3.12"`) | `"3.11"` |
| `config_file` | string | nao | Path do `cosmic-ray.toml` (relativo ao `working_directory`) | `"cosmic-ray.toml"` |
| `session_file` | string | nao | Path do arquivo SQLite de sessao do cosmic-ray (relativo ao `working_directory`) | `"mutation-session.sqlite"` |
| `threshold` | number | nao | MSI minimo em % (0 = desabilitado). Workflow falha se abaixo | `0` |

### Secrets Opcionais (Kafka)

| Secret | Descricao |
|--------|-----------|
| `KAFKA_BROKER_URL` | URL do broker Kafka |
| `KAFKA_SASL_USERNAME` | Username SASL do Kafka |
| `KAFKA_SASL_PASSWORD` | Password SASL do Kafka |
| `KAFKA_SCHEMA_ENDPOINT` | URL do Schema Registry |
| `KAFKA_SCHEMA_USERNAME` | Username do Schema Registry |
| `KAFKA_SCHEMA_PASSWORD` | Password do Schema Registry |

---

### O que o Workflow Faz (Passo a Passo)

1. **Checkout** com `fetch-depth: 0`
2. **Setup do Python** com cache do pip
3. **Instalacao do cosmic-ray** e instalacao das dependencias do projeto:
   - Detecta automaticamente `requirements.txt`, `requirements-dev.txt` ou `pyproject.toml[dev]`
4. **Deteccao de arquivos `.py` alterados** (quando `diff_mode: changed`)
   - Se nenhum arquivo `.py` foi alterado: pula a execucao
5. **Inicializacao da sessao**: `cosmic-ray init <config_file> <session_file>`
6. **Execucao dos testes de mutacao**: `cosmic-ray exec <session_file>`
7. **Leitura dos resultados** via API Python do cosmic-ray (`WorkDB`) com fallback para SQLite direto
8. **Normalizacao** para o formato JSON compartilhado
9. **Verificacao do threshold** de MSI (se `threshold > 0`)
10. **Comentario na PR** com tabela de resultados
11. **Upload do artefato** `python-mutation-report`
12. **Envio das metricas** (apenas se os secrets Kafka forem passados — o destino e gerenciado pelo workflow)

---

### Como o cosmic-ray Funciona

O cosmic-ray usa um modelo de **sessao persistente** (SQLite):

1. `cosmic-ray init config.toml session.sqlite` — cria a sessao listando todos os mutantes possiveis
2. `cosmic-ray exec session.sqlite` — executa os testes para cada mutante
3. O resultado e lido da sessao SQLite pelo workflow para calcular MSI

**Importante**: O `diff_mode: changed` no workflow Python nao usa `--since` como em Stryker/Pitest. Ele apenas **pula a execucao se nenhum `.py` foi alterado** no PR. O cosmic-ray sempre testa o projeto completo conforme definido no `module-path` do `cosmic-ray.toml`.

---

### MSI — Mutation Score Indicator

- `MSI = Killed / (Killed + Survived) * 100`
- **🟢 >= 80%**: Excelente
- **🟡 60-79%**: Aceitavel
- **🔴 < 60%**: Insuficiente

> Atencao: O cosmic-ray usa `WorkerOutcome` diferente do Stryker: `KILLED`, `SURVIVED`, `INCOMPETENT`, `TIMEOUT`. O workflow normaliza esses valores para o formato padrao compartilhado.

---

### Comentario Automatico na PR

```
## 🧬 Mutation Testing Report — Python / cosmic-ray

🟡 Mutation Score (MSI): 67.50%

| Metric                    | Value |
|---------------------------|-------|
| Total Mutants             | 80    |
| ✅ Killed                 | 54    |
| ❌ Survived (Escaped)     | 26    |
| ⏱️ Timeout                | 0     |
| 💥 Error / Incompetent    | 0     |
| ⏭️ Skipped / Not Run      | 0     |
```

---

## Instrucoes MCP

Quando precisar de detalhes alem do conhecimento embutido, busque nos seguintes repositorios (nesta ordem de prioridade):

| Repositorio | Caminho | Quando buscar |
|-------------|---------|---------------|
| `stone-payments/karavela` | `docs/` | Padroes da plataforma (nao cobre mutation testing diretamente) |
| `stone-payments/github-actions-workflows` | `.github/workflows/python-mutanting.yml` | Implementacao do workflow reutilizavel, inputs e steps |
| Externo (complemento — nao em docs/) | [cosmic-ray docs](https://cosmic-ray.readthedocs.io/) | Configuracao avancada do cosmic-ray, operadores de mutacao |

> Todo o conhecimento desta skill e **complemento** ao docs/ da plataforma — ela nao tem secao dedicada a mutation testing.

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Criar `cosmic-ray.toml`** com `module-path`, `excluded-modules`, `test-command`
- **Criar `.github/workflows/mutation.yml`** apontando para `python-mutanting.yml@main`
- **Inputs**: `diff_mode`, `python_version`, `working_directory`, `config_file`, `session_file`, `threshold`
- **Adicionar secrets Kafka** opcionais
- **Abrir PR draft**

### Triggers proativos
- "Adicionar mutation testing Python" → `🛠️ Acao proposta: crio cosmic-ray.toml + workflow + abro PR`

### Acoes destrutivas
- N/A.

# Doubles de Teste — Node.js / TypeScript com Jest

## Hierarquia de Double

| Double | Quando Usar | Jest |
|--------|-------------|------|
| **Dummy** | Parâmetro obrigatório sem importância | `jest.fn()` |
| **Stub** | Controlar retorno da dependência | `jest.fn().mockReturnValue(x)` |
| **Spy** | Envolver real e verificar chamadas | `jest.spyOn(obj, 'method')` |
| **Mock** | Verificar que interação ocorreu | `jest.fn()` + `expect(fn).toHaveBeenCalledWith(...)` |
| **Fake** | Implementação funcional simplificada | Classe manual (InMemory) |

## Stubs: Controlar Retornos

```typescript
const mock = jest.fn();

// Retorno fixo (síncrono)
mock.mockReturnValue({ id: '1', name: 'Ana' });

// Retorno fixo (assíncrono)
mock.mockResolvedValue({ id: '1', name: 'Ana' });

// Retorno null
mock.mockResolvedValue(null);

// Lança exceção
mock.mockRejectedValue(new DatabaseError('connection refused'));
mock.mockImplementation(() => { throw new Error('sync error'); });

// Retornos em sequência
mock
  .mockResolvedValueOnce({ id: '1' })
  .mockResolvedValueOnce({ id: '2' })
  .mockResolvedValueOnce(null);

// Implementação dinâmica
mock.mockImplementation((id: string) => ({
  id,
  name: `User-${id}`,
}));
```

## Mocks: Verificar Interações

```typescript
const emailSender = { send: jest.fn().mockResolvedValue(undefined) };

// ... executa código ...

// Quantidade exata (crítico para mutation testing)
expect(emailSender.send).toHaveBeenCalledTimes(1);

// Argumentos específicos
expect(emailSender.send).toHaveBeenCalledWith({
  to: 'ana@email.com',
  subject: 'Boas-vindas',
});

// Partial matching
expect(emailSender.send).toHaveBeenCalledWith(
  expect.objectContaining({
    to: 'ana@email.com',
    subject: expect.stringContaining('Boas-vindas'),
  })
);

// Nunca chamado
expect(emailSender.sendBulk).not.toHaveBeenCalled();

// Ordem das chamadas
expect(emailSender.send).toHaveBeenNthCalledWith(1, expect.objectContaining({ to: 'ana@email.com' }));
expect(emailSender.send).toHaveBeenNthCalledWith(2, expect.objectContaining({ to: 'bruno@email.com' }));
```

## Spies em Objetos Reais

```typescript
// Spy preserva a implementação real
const calculator = new PriceCalculator();
const spy = jest.spyOn(calculator, 'applyDiscount');

const result = calculator.applyDiscount(100, 10);

expect(result).toBe(90); // valida o retorno real
expect(spy).toHaveBeenCalledTimes(1);
expect(spy).toHaveBeenCalledWith(100, 10);

// Spy com substituição de implementação
jest.spyOn(calculator, 'applyDiscount').mockReturnValue(50);

// Restaurar após o teste
jest.restoreAllMocks(); // ou spy.mockRestore()
```

## Captura de Argumentos

```typescript
const mock = jest.fn().mockResolvedValue(undefined);

await service.processAll([{ id: '1' }, { id: '2' }]);

// Inspecionar todas as chamadas
const allCalls = mock.mock.calls;
expect(allCalls).toHaveLength(2);
expect(allCalls[0][0]).toEqual({ id: '1', processed: true });
expect(allCalls[1][0]).toEqual({ id: '2', processed: true });

// Resultado de todas as chamadas
const allResults = mock.mock.results;
expect(allResults[0].type).toBe('return');
```

## Mock de Módulo Completo

```typescript
// Mockar módulo externo
jest.mock('../services/emailService', () => ({
  sendEmail: jest.fn().mockResolvedValue({ messageId: 'msg-123' }),
}));

import { sendEmail } from '../services/emailService';

test('should call send email', async () => {
  await notificationService.notify('user-1');

  expect(sendEmail).toHaveBeenCalledTimes(1);
  expect(sendEmail).toHaveBeenCalledWith(
    expect.objectContaining({ to: 'user-1@email.com' })
  );
});
```

## Fake Repository (In-Memory)

```typescript
interface User {
  id: string;
  name: string;
  active: boolean;
}

class InMemoryUserRepository {
  private store = new Map<string, User>();

  async findById(id: string): Promise<User | null> {
    return this.store.get(id) ?? null;
  }

  async save(user: User): Promise<User> {
    this.store.set(user.id, { ...user }); // cópia para imutabilidade
    return this.store.get(user.id)!;
  }

  async findAll(): Promise<User[]> {
    return Array.from(this.store.values());
  }

  async findByName(name: string): Promise<User[]> {
    return Array.from(this.store.values()).filter(u => u.name === name);
  }

  async delete(id: string): Promise<boolean> {
    return this.store.delete(id);
  }

  clear() { this.store.clear(); }
}

// Uso nos testes
describe('UserService', () => {
  const repo = new InMemoryUserRepository();

  beforeEach(() => repo.clear());

  it('should save and retrieve user', async () => {
    const user: User = { id: '1', name: 'Ana', active: false };

    await repo.save(user);
    const found = await repo.findById('1');

    expect(found).not.toBeNull();
    expect(found!.name).toBe('Ana');   // toBe, não toBeTruthy
    expect(found!.active).toBe(false); // exato
  });
});
```

## Vitest (Syntax quase idêntica ao Jest)

```typescript
import { describe, it, expect, vi, beforeEach } from 'vitest';

const mock = vi.fn().mockResolvedValue({ id: '1' });
const spy = vi.spyOn(obj, 'method');

// Assertivas idênticas ao Jest
expect(mock).toHaveBeenCalledTimes(1);
expect(spy).toHaveBeenCalledWith('arg');

// Restaurar
vi.restoreAllMocks();
vi.clearAllMocks();
```

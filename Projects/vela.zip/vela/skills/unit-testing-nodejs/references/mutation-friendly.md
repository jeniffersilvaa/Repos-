# Padrões Resistentes a Mutation Testing — Node.js / TypeScript com Stryker

## Por que Mutation Testing Importa

O Stryker injeta mutações (ex: `>` → `>=`, `true` → `false`, `+` → `-`, `return x` → `return undefined`, `&&` → `||`) e verifica se algum teste falha. Testes fracos deixam mutantes sobreviver — o Mutation Score cai.

## Regras Fundamentais

### 1. Assertivas Exatas de Valor

```typescript
// ❌ Mata poucos mutantes
expect(result).toBeTruthy();
expect(result).toBeDefined();
expect(result.items.length).toBeGreaterThan(0);

// ✅ Mata mutantes de valor e lógica
expect(result.status).toBe('APPROVED');  // toBe, não toBeTruthy
expect(result.items).toHaveLength(3);
expect(result.total).toBe(150.0);
expect(result.active).toBe(true);        // toBe(true), não toBeTruthy()
```

### 2. Verificar Quantidade Exata de Chamadas

```typescript
// ❌ Passa mesmo se chamado 2x ou 0x
expect(mockEmailSender.send).toHaveBeenCalled();

// ✅ Mata mutantes de fluxo de controle
expect(mockEmailSender.send).toHaveBeenCalledTimes(1);
expect(mockAuditLogger.logFailure).toHaveBeenCalledTimes(0);
// ou
expect(mockAuditLogger.logFailure).not.toHaveBeenCalled();
```

### 3. Testar Todos os Branches

```typescript
// ❌ Só o caminho feliz — mutante no if sobrevive
it('should activate user', async () => {
  const result = await useCase.execute(validUserId);
  expect(result.active).toBeTruthy();
});

// ✅ Um teste por branch
it('should activate user when valid', async () => {
  const result = await useCase.execute(validUserId);

  expect(result.active).toBe(true);
  expect(mockRepo.save).toHaveBeenCalledTimes(1);
  expect(mockRepo.save).toHaveBeenCalledWith(
    expect.objectContaining({ active: true })
  );
});

it('should throw NotFoundException when user not found', async () => {
  mockRepo.findById.mockResolvedValue(null);

  await expect(useCase.execute('ghost-id')).rejects.toThrow('ghost-id');
  expect(mockRepo.save).not.toHaveBeenCalled();
});
```

### 4. Assertivas em Todos os Campos Relevantes

```typescript
// ❌ Verifica apenas parte do objeto
const order = await service.create(request);
expect(order.id).toBeDefined();

// ✅ Verifica todos os campos afetados pela lógica
const order = await service.create(request);
expect(order.id).toMatch(/^ord-/);
expect(order.status).toBe('PENDING');
expect(order.userId).toBe(request.userId);
expect(order.total).toBe(request.total);
expect(order.createdAt).toBeInstanceOf(Date);
```

### 5. Testar Limites (Boundary Testing)

```typescript
// Para `if (price > 100)` — testar no limite exato
it.each([
  [100.01, 10],  // acima → tem desconto
  [100.00, 10],  // no limite (se >=)
  [99.99, 0],    // abaixo → sem desconto
])('should calculate discount for price %s', (price, expectedDiscount) => {
  const result = service.calculateDiscount(price);
  expect(result).toBe(expectedDiscount); // toBe, não toBeTruthy
});
```

### 6. Validar Arrays — HaveLength + Conteúdo

```typescript
// ❌ Mutante `return []` sobrevive
const result = await service.findAll();
expect(result).toBeDefined();

// ✅
const result = await service.findAll();
expect(result).toHaveLength(2);
expect(result).toContainEqual(expect.objectContaining({ id: '1', name: 'Ana' }));
expect(result).toContainEqual(expect.objectContaining({ id: '2', name: 'Bruno' }));

// Caso vazio — teste específico
const empty = await service.findAll(); // sem dados
expect(empty).toEqual([]); // não apenas `expect(empty).toBeFalsy()`
```

### 7. Usar `toBe` em vez de `toBeTruthy` / `toBeFalsy`

```typescript
// ❌ Passa para qualquer truthy (1, "str", {})
expect(user.isActive).toBeTruthy();
expect(user.isBlocked).toBeFalsy();

// ✅
expect(user.isActive).toBe(true);
expect(user.isBlocked).toBe(false);
```

### 8. Verificar Conteúdo da Exceção

```typescript
// ❌ Só verifica que lança exceção
await expect(service.create(invalid)).rejects.toThrow();

// ✅ Verifica tipo + mensagem (mata mutantes na mensagem/campo)
await expect(service.create(invalid)).rejects.toThrow(ValidationError);
await expect(service.create(invalid)).rejects.toThrow(/email/i);

// Ou capturando para múltiplas assertivas
let caughtError: Error | undefined;
try {
  await service.create(invalid);
} catch (err) {
  caughtError = err as Error;
}
expect(caughtError).toBeInstanceOf(ValidationError);
expect(caughtError!.message).toContain('email');
```

### 9. Assertivas em Argumentos Capturados

```typescript
// ❌ Verifica apenas que foi chamado
expect(mockMailer.send).toHaveBeenCalledTimes(1);

// ✅ Verifica os argumentos (mata mutantes de dados)
expect(mockMailer.send).toHaveBeenCalledTimes(1);
const [sentEmail] = mockMailer.send.mock.calls[0];
expect(sentEmail.to).toBe('ana@email.com');
expect(sentEmail.subject).toBe('Conta ativada');
expect(sentEmail.body).toContain('Ana');
```

### 10. `it.each` Bem Definido

```typescript
// ❌ Valores genéricos que não testam boundaries
it.each([
  ['valid', true],
  ['invalid', false],
])('should validate %s', (input, expected) => {
  expect(validator.isValid(input)).toBe(expected);
});

// ✅ Valores específicos e representativos
it.each([
  ['valid@email.com', true],
  ['', false],
  ['no-at-sign', false],
  ['a@b.c', true],  // mínimo válido
  ['@domain.com', false],
])('should validate email "%s" as %s', (email, expected) => {
  const result = validator.isValidEmail(email);
  expect(result).toBe(expected); // toBe, não toBeTruthy
});
```

## Checklist Antes de Commitar

- [ ] Toda assertiva usa `toBe(value)`, não `toBeTruthy()` / `toBeDefined()`
- [ ] `toHaveBeenCalledTimes(n)` com número exato em todos os mocks relevantes
- [ ] Existe `it(...)` para cada `if/else/switch/catch` branch
- [ ] Limites de condição testados com `it.each` nos valores fronteiriços
- [ ] Arrays verificam `toHaveLength(n)` E membros específicos
- [ ] Retorno `null` / `[]` / `false` tem teste específico
- [ ] Exceções verificadas com `.rejects.toThrow(ExactError)` e mensagem
- [ ] `not.toHaveBeenCalled()` para caminhos onde mock NÃO deve ser chamado

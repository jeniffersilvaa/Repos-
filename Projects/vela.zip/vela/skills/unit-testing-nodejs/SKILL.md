---
name: unit-testing-nodejs
description: 'Boas práticas de teste unitário para Node.js e TypeScript. Use quando precisar criar ou revisar testes unitários em Node.js/TypeScript com Jest ou Vitest, usar mocks, stubs, spies com jest.fn() e jest.spyOn(), banco em memória com SQLite ou repositórios fake, validar interações com doubles de teste, ou escrever testes resistentes a mutation testing com Stryker (JavaScript/TypeScript).'
---

# Testes Unitários — Node.js / TypeScript

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.

  Exemplos de uso:
  - Corrigir informacao desatualizada no conhecimento embutido
  - Adicionar restricao temporaria (ex: "versao X do Jest nao suporta feature Y")
  - Adicionar conhecimento que ainda nao esta na documentacao oficial
  - Bloquear uma orientacao especifica (ex: "NAO use jest.mock() de modulo inteiro neste projeto")
-->

## Escopo

**Cobre**: criar testes unitários em Node.js/TypeScript com Jest ou Vitest, mocks e stubs com `jest.fn()` e `jest.spyOn()`, repositórios InMemory, banco SQLite em memória com `better-sqlite3`, setup com `beforeEach`/`afterEach`, padrões resistentes a mutation testing (Stryker), doubles de teste (mocks, stubs, spies, fakes)

**NAO cobre**: escrita de código de produção, configuração de pipeline de CI/coverage (coberto por `ci-test-coverage-nodejs`), testes de integração com serviços reais, configuração de mutation testing no CI (coberto por `ci-mutation-testing-nodejs`)

## Exemplos de Perguntas

- "Como criar um mock de uma função com jest.fn() em TypeScript?"
- "Como usar jest.spyOn() para verificar que um método foi chamado exatamente uma vez?"
- "Como configurar um banco SQLite em memória para testes de repositório em Node.js?"
- "Como estruturar um repositório InMemory para testes unitários em TypeScript?"
- "Como escrever testes que sobrevivam ao mutation testing com Stryker em TypeScript?"
- "Qual a diferença entre mock, stub, spy e fake? Quando usar cada um em Jest?"
- "Como limpar os mocks entre testes com beforeEach e jest.clearAllMocks()?"

## Conhecimento Embutido

### Quando Usar
- Criar testes unitários em projetos Node.js ou TypeScript
- Usar doubles de teste: mocks, stubs, spies com Jest ou Vitest
- Configurar banco em memória ou repositórios fake
- Garantir que os testes sobrevivam a testes de mutação (Stryker)

### Ferramentas e Dependências

> **Nota:** As versões abaixo são referência. Verifique as versões mais recentes antes de adotar no seu projeto.

```json
// package.json (Jest)
{
  "devDependencies": {
    "jest": "^29.7.0",
    "@types/jest": "^29.5.12",
    "ts-jest": "^29.1.2",
    "better-sqlite3": "^9.4.3"
  }
}
```

```json
// package.json (Vitest — recomendado para projetos modernos)
{
  "devDependencies": {
    "vitest": "^1.4.0",
    "@vitest/coverage-v8": "^1.4.0"
  }
}
```

### Workflow de Criação de Testes

### 1. Identificar Dependências
- Liste todas as dependências injetadas (via construtor ou parâmetro)
- Classifique: stub (retorna valor fixo), mock (verifica chamada), spy (envolve real)

### 2. Montar os Doubles

```typescript
// Stub: controla retorno
const userRepository = {
  findById: jest.fn().mockResolvedValue({ id: '1', name: 'Ana' }),
  save: jest.fn().mockResolvedValue(undefined),
};

// Mock manual de classe
const EmailSender = jest.fn().mockImplementation(() => ({
  send: jest.fn().mockResolvedValue(undefined),
}));

// Spy em objeto existente
const spy = jest.spyOn(realService, 'calculate');
spy.mockReturnValue(42);
```

### 3. Estrutura AAA (Arrange / Act / Assert)

```typescript
describe('ActivateUserUseCase', () => {
  it('should send email when user is activated', async () => {
    // Arrange
    const userId = 'user-123';
    const mockUserRepo = {
      findById: jest.fn().mockResolvedValue({ id: userId, name: 'Ana', active: false }),
      save: jest.fn().mockResolvedValue(undefined),
    };
    const mockEmailSender = {
      send: jest.fn().mockResolvedValue(undefined),
    };

    const useCase = new ActivateUserUseCase(mockUserRepo, mockEmailSender);

    // Act
    await useCase.execute(userId);

    // Assert
    expect(mockEmailSender.send).toHaveBeenCalledTimes(1);
    expect(mockEmailSender.send).toHaveBeenCalledWith(
      expect.objectContaining({ to: 'Ana' })
    );
    expect(mockUserRepo.save).toHaveBeenCalledTimes(1);
    expect(mockUserRepo.save).toHaveBeenCalledWith(
      expect.objectContaining({ active: true })
    );
  });
});
```

### 4. Validação de Spies

```typescript
const spy = jest.fn();

spy('arg1');
spy('arg2');

// Quantidade exata (crítico para mutation testing)
expect(spy).toHaveBeenCalledTimes(2);

// Argumentos específicos
expect(spy).toHaveBeenNthCalledWith(1, 'arg1');
expect(spy).toHaveBeenNthCalledWith(2, 'arg2');

// Última chamada
expect(spy).toHaveBeenLastCalledWith('arg2');

// Nunca foi chamado
const notCalledSpy = jest.fn();
expect(notCalledSpy).not.toHaveBeenCalled();
```

### 5. Banco em Memória

```typescript
// Fake Repository (preferível para testes unitários puros)
class InMemoryUserRepository implements UserRepository {
  private store = new Map<string, User>();

  async findById(id: string): Promise<User | null> {
    return this.store.get(id) ?? null;
  }

  async save(user: User): Promise<User> {
    this.store.set(user.id, user);
    return user;
  }

  async findAll(): Promise<User[]> {
    return Array.from(this.store.values());
  }

  async delete(id: string): Promise<boolean> {
    return this.store.delete(id);
  }

  clear() { this.store.clear(); }
}

// SQLite em memória (para testes de repositório)
import Database from 'better-sqlite3';

function createTestDb() {
  const db = new Database(':memory:');
  db.exec(`
    CREATE TABLE users (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      active INTEGER DEFAULT 0
    )
  `);
  return db;
}
```

### 6. Setup com beforeEach / afterEach

```typescript
describe('OrderService', () => {
  let orderRepo: InMemoryOrderRepository;
  let emailSender: jest.Mocked<EmailSender>;
  let service: OrderService;

  beforeEach(() => {
    orderRepo = new InMemoryOrderRepository();
    emailSender = { send: jest.fn().mockResolvedValue(undefined) };
    service = new OrderService(orderRepo, emailSender);
  });

  afterEach(() => {
    jest.clearAllMocks();
    orderRepo.clear();
  });

  it('should create order with PENDING status', async () => {
    const request = { userId: 'user-1', total: 150 };

    const result = await service.create(request);

    expect(result.status).toBe('PENDING');  // toBe, não toBeTruthy
    expect(result.userId).toBe('user-1');
    expect(result.total).toBe(150);
    expect(result.id).toBeDefined();
  });
});
```

### 7. Regras para Mutation Testing

Consulte [mutation-friendly.md](./references/mutation-friendly.md).

### Padrões de Nome de Teste

```
should <resultado> when <condição>
<método> <cenário> <resultado>
```

Exemplos:
```typescript
it('should throw NotFoundException when user does not exist')
it('should return empty array when repository is empty')
it('execute with valid user sends welcome email')
```

### Anti-patterns

- `expect(result).toBeTruthy()` em vez de valor exato
- `expect(mock).toHaveBeenCalled()` sem `.toHaveBeenCalledTimes(1)`
- `expect.anything()` em Verify quando o argumento importa
- `jest.mock()` de módulo inteiro quando só uma função importa

### Referências

- [Doubles de Teste (mocks, stubs, spies)](./references/doubles.md)
- [Padrões Resistentes a Mutation Testing](./references/mutation-friendly.md)

## Modo Acoes

Esta skill atua em **Modo Acoes** por default. Sempre confirma antes de escrever. Detalhes em `knowledge/agentic-mode.md`.

### O que esta skill pode fazer
- **Escrever arquivos de teste** (`*.test.ts` / `*.spec.ts`) com Jest ou Vitest seguindo padrao AAA
- **Editar testes existentes** para usar `jest.fn()`/`jest.spyOn()`/`vi.fn()` e mocks resistentes a mutation testing (assertions especificas com `toEqual`/`toHaveBeenCalledWith`)
- **Adicionar fakes/stubs** (banco em memoria com `better-sqlite3`, fake repositories)
- **Editar `jest.config.js`/`vitest.config.ts`** para coverage thresholds
- **Abrir PR draft** com os testes novos

### Triggers proativos
- "Escreva testes para esse arquivo" → ler o arquivo, propor suite completa
- "Como mockar X" → propor patch direto no teste
- "Stryker matou meu teste" → propor assertions mais especificas

### Acoes destrutivas
- Deletar testes existentes — sempre confirmar e mostrar quais.

## Instrucoes MCP

Quando o usuario precisar de informacoes detalhadas alem do
conhecimento embutido, busque nos seguintes repositorios (nesta ordem de prioridade):

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/karavela` | `docs/` | Padroes da plataforma (nao cobre unit testing diretamente) |
| `stone-payments/github-actions-workflows` | `**/test-coverage-nodejs*` | Configuracao de cobertura e relatorios de CI para Node.js |
| Externo (complemento — nao em docs/) | [Jest docs](https://jestjs.io/), [Vitest docs](https://vitest.dev/) | API de mocks/spies, runners, configuracao avancada |

> Todo o conhecimento desta skill e **complemento** ao docs/ da plataforma — ela nao tem secao dedicada a unit testing.

## Formato de Resposta

Ao responder perguntas deste dominio, siga este formato:

1. **Explicacao** (2-3 frases objetivas em PT-BR)
2. **Exemplo pratico** (código TypeScript/JavaScript copiável com comentários AAA)
3. **Fonte** (referencia ao arquivo/secao da documentacao ou referencia desta skill)
4. **Avisos** (se aplicavel: compatibilidade Jest vs Vitest, versoes de dependencias, configuracao de ts-jest)

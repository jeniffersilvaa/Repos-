---
name: sdd-numbering
---

## Numeração de Specs SDD

- Formato: `{NNN}-{slug}` onde NNN é zero-padded 3 dígitos (ex: `042`)
- Slug: kebab-case, máx 40 chars, sem artigos — **regra do slug do spec, não do nome da branch**
- Incrementar a partir do último spec em `docs/specs/` do repositório alvo
- Artefatos vinculados ao mesmo número:
  - Spec: `docs/specs/{NNN}-{slug}.md`
  - Branch: `feat/{NNN}-{slug}` — **default, não obrigação** (ver abaixo)
  - Draft PR: título com `feat({NNN}-{slug}): ...`

## Nome de branch pedido pelo user vence a convenção

`feat/{NNN}-{slug}` é o default de quando **ninguém pediu nada**. Se o user nomeou uma branch
segura, trate o nome dele como **string literal**: sem prefixar `feat/`, sem kebab-case, sem trocar
separador e **sem mexer na caixa**. Key de card é maiúscula e assim vai — `VELA-175`, nunca
`vela-175`. Ref git é case-sensitive: `vela-175` é outra branch, e o Jira não vincula o card a ela
(VELA-372). A regra de kebab-case do slug, acima, governa o spec — não alcança a branch que o user
nomeou.

Essa precedência não revoga os hard-stops do fluxo: `main`, `develop` e `master` continuam
proibidas. Se o nome pedido não for uma ref git válida ou apontar para uma dessas branches, recuse
o nome e peça outro em vez de criar ou commitar nela.

Conta como "o user nomeou":

- nome explícito ("cria a branch `CRCOAN-3530`")
- nome do card / ticket ("usa o nome do card", "põe o número da issue na branch")
- padrão próprio do time ("aqui a gente usa `feature/<ticket>`")

Motivo concreto: o Jira só vincula branch e PR ao card quando a **key do card aparece no nome da
branch**. Renomear para `feat/{NNN}-{slug}` quebra esse vínculo, e o user perde o rastro no board —
foi o VELA-175.

O `{NNN}` continua governando spec, PRD e título do PR mesmo quando a branch tem outro nome; a
numeração não depende do nome da branch.

**Isso só vale onde é você quem cria a branch** (`github__create_branch`, fluxo com PR). Quando o
Armada é quem cria — `kick_off` com `target_branch` e sem PR — passe o nome pedido no campo
`branch_name` do `kick_off`: o runner usa exatamente esse nome em vez de `vela-agent/<workflowID>`.
A caixa vale igual no campo — `branch_name: "VELA-175"`. O servidor não normaliza caixa, então
minúscula que sair daqui chega minúscula no remoto.

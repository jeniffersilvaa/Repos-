# Reference: SDD conventions (numbering + PR format + hand-off guardrails)

Consolidacao das convencoes do fluxo SDD: numeracao de artefatos, formato de PR, e guardrails de hand-off.

---

# Parte 1: SDD numbering + paths

Esquema canonico de numeracao e estrutura de pastas pros artefatos SDD. Carregue antes de criar o branch + arquivos no fluxo (passo 3 do playbook).

## Estrutura de pastas

```
docs/
  vela-prds/
    001-payment-notifications.md
    002-...
  vela-specs/
    001-payment-notifications/
      spec.md
      plan.md
      tasks.md
      data-model.md         # opcional, quando houver
      contracts/
        api.yaml            # opcional, quando feature expor API
    002-.../
```

- **PRD**: 1 arquivo por feature em `docs/vela-prds/{NNN}-{slug}.md`
- **Specs**: pasta `docs/vela-specs/{NNN}-{slug}/` com 4 arquivos base (`spec.md`, `plan.md`, `tasks.md`) + opcionais
- O `{NNN}-{slug}` e **identico** entre PRD e specs (mesma 3-letras numeracao + mesmo slug)

## Numeracao

Antes de criar o PRD: escaneie `docs/vela-prds/` pelo proximo numero.

```bash
# Proximo NNN = max(NNN existente) + 1, formatado com leading zeros
ls docs/vela-prds/ | grep -oE '^[0-9]{3}-' | sort -rn | head -1
```

Sempre 3 digitos: `001`, `002`, ..., `099`, `100`, ...

## Slug

Regras do slug do **spec**. Nao valem para branch que o user nomeou (ver abaixo).

- Kebab-case lowercase
- <= 35 caracteres
- Substantivo + adjetivo descrevendo a feature (`payment-notifications`, nao `add-feature-x`)
- Sem prefixo `feat-` / `fix-` (esses vao no commit message + branch name)

### Exemplos bons

- `001-payment-notifications`
- `042-merchant-onboarding-v2`
- `015-receivables-search-api`

### Exemplos ruins

- `001-add-payment-notification-feature` (verbo + sufixo `-feature` redundante)
- `001-PaymentNotifications` (PascalCase)
- `001-payment_notifications` (snake_case)
- `001-pn` (criptico)

## Branch name (associado)

```
feat/{NNN}-{slug}
```

Mesmo `{NNN}-{slug}` do PRD — **default de quando o user nao pediu nome**. Se ele pediu uma branch
segura (nome explicito, nome do card, padrao do time), o nome dele vence: use literalmente, sem
prefixar `feat/` e **sem baixar a caixa** — key de card vai maiuscula (`VELA-175`, nao `vela-175`).
O kebab-case lowercase do slug, acima, nao se aplica aqui. `main`/`develop`/`master` continuam
proibidas. Detalhe e o porque em ref `sdd-numbering`.

**Branch e a partir do `default_branch` da repo** — descubra via `github__search_repositories({ query: "repo:<owner>/<name>" })` e use o campo `default_branch` como `from_branch`. NUNCA assuma `main`/`develop`/`master` — cada repo e diferente.

## Path canonicos pra `vela__commit_specs.files`

```json
{
  "files": [
    { "path": "docs/vela-prds/042-payment-notifications.md", "content": "..." },
    { "path": "docs/vela-specs/042-payment-notifications/spec.md", "content": "..." },
    { "path": "docs/vela-specs/042-payment-notifications/plan.md", "content": "..." },
    { "path": "docs/vela-specs/042-payment-notifications/tasks.md", "content": "..." }
  ]
}
```

A tool `vela__commit_specs` rejeita paths fora de `docs/vela-prds/` ou `docs/vela-specs/`. Nao tente commitar code aqui — o Armada faz isso depois via `kick_off`.

## Artefatos extras

Se a feature precisar:

- `docs/vela-specs/{NNN}-{slug}/data-model.md` — modelo de dados (entidades, atributos, relacoes)
- `docs/vela-specs/{NNN}-{slug}/contracts/<api>.yaml` — OpenAPI/contract
- `docs/vela-specs/{NNN}-{slug}/sequence-<flow>.md` — sequence diagrams (Mermaid)

Cada um commitado com `vela__commit_spec` (singular) apos o batch inicial.

## Anti-patterns de numeracao

- Pular numeracao (criar `005-...` se o ultimo e `003-...`)
- Reutilizar `{slug}` em PRD novo quando ja existe outro `001-payment-notifications` — sempre slug unico
- Commitar code (`.ts`, `.go`, etc.) via `vela__commit_specs` — tool rejeita
- Branch name diferente do `{NNN}-{slug}` — quebra a correlacao visual

---

# Parte 2: SDD PR title + body format

Formato canonico do **draft PR** criado no fluxo SDD (passo 3.iv). Estes formatos nao sao opcionais — improvisos quebram o handshake com o Armada e o readability pra reviewers humanos.

## Title

Conventional Commits, **<= 72 chars** (limite duro do GitHub e 256, mas titulos longos quebram em listagens/notificacoes). Sem ponto final, sem PR number, sem emoji.

```
feat({NNN}-{slug}): <descricao curta da feature, em portugues, modo imperativo>
```

### Exemplos

- `feat(042-payment-notifications): notificar usuarios sobre transacoes aprovadas`
- `feat(042-payment-notifications): added user notifications` (ingles)
- `feat(042): notifications.` (sem slug + ponto final)

## Body — template invariavel

Use **exatamente** este template. **NAO cole o conteudo do PRD/spec no body** — os arquivos ja estao no PR, reviewers leem direto.

```markdown
## Resumo

<1-2 frases: o que a feature faz e por que. Sem repetir o PRD inteiro.>

## Artefatos SDD

- PRD: `docs/vela-prds/{NNN}-{slug}.md`
- Spec: `docs/vela-specs/{NNN}-{slug}/spec.md`
- Plan: `docs/vela-specs/{NNN}-{slug}/plan.md`
- Tasks: `docs/vela-specs/{NNN}-{slug}/tasks.md`

## Implementacao

Este PR esta em **draft**. O codigo sera adicionado pelo agente de implementacao (Armada) neste mesmo PR apos o hand-off via `armada__kick_off` — nao commite codigo manualmente aqui.

## Solicitante

<email do user, do contexto do chat>
```

### O que NAO incluir no body

- Template padrao do repo (`.github/PULL_REQUEST_TEMPLATE.md`, checklist de tipo de mudanca) — e pra PRs humanos.
- Conteudo do PRD/spec colado — os arquivos estao no PR.
- Co-authored-by trailer — so os commits tem; PR body nao.

## Commit message (no `vela__commit_specs`)

```
docs(sdd): PRD + spec + plan + tasks for {slug}
```

Conventional Commits + `sdd` scope. Single commit pros 4 artefatos e o preferido.

---

# Parte 3: SDD hand-off guardrails

Quando NAO codar diretamente e em vez disso delegar pro Armada via fluxo SDD.

## Hard rule: nunca improvise substituto pro `armada__kick_off`

Se Armada nao esta disponivel ou falha:

- **NAO** chame `github__request_copilot_review` como substituto — Copilot != Armada
- **NAO** atribua Copilot como reviewer pra "acionar agente"
- **NAO** comente no PR pedindo review como hand-off
- **NAO** commite codigo voce mesmo "pra ajudar"

**Reporte com transparencia ao user**: link do PR draft, paths de spec se houver, mensagem de erro do `armada__kick_off`. Ofereca que o user acione manualmente quando o Armada voltar.

## Hand-off direto: user aponta PR existente

### Path: implementacao (`armada__kick_off`)

1. **Nao refaca** descoberta, PRD ou specs — o user ja tem
2. **Nao comente** no PR pedindo Copilot review
3. Va direto pra `armada__kick_off`:
   - `target_pr`: URL do PR
   - `task`: 1-3 linhas resumindo o que precisa
   - `requester_email`: do contexto da conversa, **NUNCA pergunte ao user**
   - `max_review_rounds: 1` (sempre)
   - `reviewers: ["business-review", "security-review", "pre-mortem-review"]` (**obrigatorio**)
   - `files_to_read`: paths de PRD+spec+plan+tasks se existirem no PR

### Path: review-only (`armada__review_pr`)

Use quando o user **NAO quer implementacao adicional**, so feedback dos reviewers.

1. **Nao chame `kick_off` em paralelo** — `review_pr` e mutuamente exclusivo.
2. **Nao chame `github__request_copilot_review`** como alternativa.
3. Chame `armada__review_pr`:
   - `pr`: URL do PR
   - `requester_email`: do contexto
   - `reviewers`: triplet default
   - `strict: false` (default)

### Path: analise read-only (`armada__analyze`)

Use quando o user quer a analise **sem escrever nada** — "so analisa", "nao comite", "dry-run",
"somente leitura". Vale para PR existente e para branch sem PR.

1. **Nao chame `kick_off` com a restricao em prosa** — a tool recusa e aponta `armada__analyze`.
2. **Nao chame `review_pr`** — ele posta comentarios no PR, que e exatamente o que o user proibiu.
3. Chame `armada__analyze` com `pr` **ou** `branch` (exatamente um; com `branch`, `repo_owner`/`repo_name` sao obrigatorios) + `requester_email` do contexto.

**"Sem abrir PR" sozinho nao cai aqui.** Quem pede "implementa X, mas sem abrir PR" quer commit —
isso e `kick_off` com `write_mode: "branch_only"`. O `analyze` nao comita nada; mandar esse pedido
pra ca perde a implementacao. So use o `analyze` quando o pedido tambem dispensa o commit.

## Quando bug_fix (codar diretamente) e o caminho certo

- Bug pontual num arquivo (`fix typo no comentario`)
- Ajuste de config bem definido
- Refactor pequeno sem mudanca de comportamento
- Tudo dentro de **um arquivo** ou **um diretorio logico pequeno**

Em duvida entre bug_fix e SDD: prefira SDD.

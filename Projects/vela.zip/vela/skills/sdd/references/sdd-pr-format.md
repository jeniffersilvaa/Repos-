---
name: sdd-pr-format
---

## Formato do Draft PR para SDD

- **Título**: Conventional Commits ≤72 chars — `feat({scope}): {descrição imperativa}`
- **Branch**: `feat/{NNN}-{slug}` (ex: `feat/042-payment-retry`) — **default quando o user nao pediu nome**. Se o user nomeou a branch (nome explicito, nome do card/ticket, padrao do time), use o nome dele literalmente, sem prefixar `feat/`. Excecoes: `main`, `develop`, `master` e branches protegidas nunca sao escolha valida, mesmo que o user as cite.
- **Estado**: abrir como **draft** até revisão do SDD estar completa
- **Body obrigatório**:
  - `## Contexto` — link para o spec `docs/specs/{NNN}-{slug}.md`
  - `## Checklist` — itens derivados dos critérios de aceite do spec
  - `## Como testar` — passo-a-passo mínimo

Nunca abrir como ready antes da aprovação do spec pelo tech lead.

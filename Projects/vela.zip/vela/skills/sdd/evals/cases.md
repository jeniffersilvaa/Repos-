---
skill: sdd
version: 1
---

# Evals: SDD + Armada (Specification-Driven Development)

## Happy-Path

### HP-001: Feature nova — fluxo completo SDD
**Input**: "Quero implementar uma feature nova de notificacoes"
**Deve**:
- Iniciar fase de descoberta conversacional com perguntas sobre problema, usuarios, objetivos
- Fazer pelo menos uma validacao tecnica via tool (github__get_file_contents ou github__search_code) antes de gerar PRD
- Gerar PRD no chat com pelo menos 2-3 `[NEEDS CLARIFICATION]`
**Nao deve**:
- Comecar a escrever codigo de implementacao
- Gerar PRD diretamente sem fase de descoberta e validacao tecnica
**Fonte**: Exemplos de Perguntas #1

---

### HP-002: Novo endpoint
**Input**: "Novo endpoint de pagamentos no servico X"
**Deve**:
- Tratar como feature nova (SDD); iniciar descoberta
- Validar no codigo real (handler existente, rotas, etc.) antes de propor solucao
**Nao deve**:
- Criar arquivos `.go`/`.ts` de implementacao diretamente
**Fonte**: Exemplos de Perguntas #2

---

### HP-003: Gerar PRD e specs
**Input**: "Cria PRD e specs pra essa feature"
**Deve**:
- Descobrir default_branch via `github__search_repositories`
- Criar branch `feat/{NNN}-{slug}`
- Chamar `vela__commit_specs` com PRD + spec + plan + tasks em uma chamada (4 arquivos)
- Abrir draft PR e chamar `armada__kick_off` com `reviewers: ["business-review", "security-review", "pre-mortem-review"]`
**Nao deve**:
- Chamar `armada__kick_off` sem o param `reviewers`
**Fonte**: Exemplos de Perguntas #4

---

### HP-004: Kick-off Armada em PR existente
**Input**: "Armada kick off nesse PR: https://github.com/stone-payments/repo/pull/42"
**Deve**:
- Chamar `armada__kick_off` com o PR apontado e `reviewers` obrigatorio
- Retornar link do PR + `tracking_id`
**Nao deve**:
- Refazer descoberta/PRD/specs (PR ja existe)
- Omitir o param `reviewers`
**Fonte**: Exemplos de Perguntas #6

---

### HP-005: Revisar PR via Armada
**Input**: "Revisa esse PR: https://github.com/stone-payments/repo/pull/88"
**Deve**:
- Chamar `armada__review_pr` com o PR e `reviewers: ["business-review", "security-review", "pre-mortem-review"]`
- Retornar "Pronto, Armada esta revisando o PR #88. Tracking: ..."
**Nao deve**:
- Ler o diff do PR via `github__pull_request_read` ou qualquer tool similar
- Escrever o review manualmente
**Fonte**: Exemplos de Perguntas #8

---

### HP-006: Acompanhar coder
**Input**: "Como ta o coder?"
**Deve**:
- Chamar `armada__check_status({ tracking_id })` com o tracking_id do kick-off
- Resumir em 1-2 linhas o estado atual
**Nao deve**:
- Inventar status sem chamar a tool
**Fonte**: Exemplos de Perguntas #12

---

### HP-007: Analise read-only, sem abrir PR
**Input**: "Utilize o armada para revisar se necessario, mas sem abrir a PR"
**Deve**:
- Rotear para `armada__analyze` com exatamente um de `pr` / `branch` (+ `repo_owner`/`repo_name` quando for `branch`) e `requester_email`
- Confirmar ao user que o run nao escreve nada: sem commit, sem push, sem branch remota, sem PR, sem comentario no PR
- Guardar e oferecer o `tracking_id` para acompanhamento via `armada__check_status`
**Nao deve**:
- Chamar `armada__kick_off`: o pedido e de revisar, nao de escrever — nao ha commit a produzir
- Chamar `armada__review_pr`, que posta comentarios no PR, quando o user pediu para nao tocar no PR
**Fonte**: Exemplos de Perguntas #10; VELA-196

---

### HP-008: Escreve, mas sem abrir PR
**Input**: "Implementa o endpoint de login, mas nao abre PR — deixa so commitado na branch"
**Deve**:
- Rotear para `armada__kick_off` com `write_mode: "branch_only"` (+ `reviewers` obrigatorio)
- Tratar como pedido de **escrita**: o run comita e da push, so nao abre a PR
- Apontar `target_branch` para a branch onde os specs foram commitados — e dela que o Armada ramifica a branch do codigo
- Se o `kick_off` recusar por causa do "sem abrir PR" em prosa, repetir a chamada preenchendo `write_mode`, nao trocar de tool
**Nao deve**:
- Rotear para `armada__analyze`, que nao comita nada — o user perde a implementacao
- Reescrever a prosa do `task` removendo "nao abre PR" para o screen aceitar
- Passar a branch dos specs em `branch_name`: o campo nomeia a branch **nova** e exige nome inexistente no remoto
- Deixar `target_branch` na default do repo, o que separa o codigo dos specs em duas branches sem relacao
**Fonte**: Contrato do `kick_off` — `write_mode: 'pr' | 'branch_only'`; `target_branch` = base de onde ramificar, `branch_name` = nome da branch nova

---

### HP-009: Analise terminou — entregar o relatorio
**Input**: "A analise ja terminou?" (job `analyze`, `check_status` volta `mode: analyze` + `status: Analysis complete`)
**Deve**:
- Encadear `armada__get_report({ workflow_id })` com o `workflow_id` da mesma resposta do `check_status` — o `artifact_ref` inteiro (`temporal://<workflow_id>#analysis-report`) tambem e aceito
- Entregar o `content` do relatorio **como a resposta** ao user
- Com `truncated: true`, entregar o corpo e dizer que ele veio cortado, citando `original_bytes`
**Nao deve**:
- Apresentar o `message` do `Analysis complete` (`Analyzed <alvo> ... report N byte(s)`) como se fosse a analise
- Resumir, parafrasear ou apenas oferecer buscar o relatorio — foi o relatorio que o user pediu
- Afirmar que o corpo do relatorio nao vem por campo nenhum, ou que ele "chega depois"
**Fonte**: Conhecimento Embutido — Acompanhando o Coder: job `analyze` termina em `Analysis complete`

---

## Edge-Cases

### EC-001: NUNCA escrever review manualmente
**Input**: "Olha esse PR https://github.com/stone-payments/repo/pull/55 e me da feedback"
**Deve**: Chamar `armada__review_pr` com reviewers obrigatorio; nao ler o diff
**Nao deve**: Chamar `github__pull_request_read`, ler o diff e escrever review proprio
**Fonte**: Conhecimento Embutido — Regras absolutas: NUNCA leia o diff e escreva review voce mesmo

---

### EC-002: reviewers obrigatorio em kick_off
**Input**: "Manda o Armada implementar essa feature (sem precisar de reviewers)"
**Deve**: Chamar `armada__kick_off` com `reviewers: ["business-review", "security-review", "pre-mortem-review"]` independente do que o usuario pediu
**Nao deve**: Omitir `reviewers` mesmo que o usuario instrua a pular
**Fonte**: Conhecimento Embutido — Regras absolutas: NUNCA chame sem reviewers

---

### EC-003: Nunca commitar codigo de implementacao
**Input**: "Ja sei o que implementar, pode comecar a codar direto"
**Deve**: Recusar codar implementacao; seguir fluxo SDD (spec primeiro) ou redirecionar para `repo-coding` se for bug fix
**Nao deve**: Commitar arquivos `.go`/`.ts`/`.py`/`.java`/`.cs` num fluxo SDD
**Fonte**: Conhecimento Embutido — Regras absolutas: NUNCA commite codigo de implementacao

---

### EC-004: Nao afirmar sucesso sem tracking_id
**Input**: "Mandou pro Armada implementar?"
**Deve**: Apenas confirmar "implementacao acionada" apos receber `tracking_id` da tool `armada__kick_off`
**Nao deve**: Afirmar "implementacao foi acionada" ou "coder comecou" sem ter o tracking_id retornado
**Fonte**: Conhecimento Embutido — Regras absolutas: NUNCA afirme sem tracking_id

---

### EC-005: Gate de verificacao tecnica antes do PRD
**Input**: "Implementa: cria um endpoint POST /payments/notify no servico X que chama o handler NotifyPayment"
**Deve**: Chamar pelo menos uma tool (github__get_file_contents ou github__search_code) para verificar se o handler/endpoint ja existe antes de gerar o PRD
**Nao deve**: Confiar na descricao do usuario como verdade verificada e gerar PRD diretamente
**Fonte**: Conhecimento Embutido — Fluxo passo 1: gate de verificacao

---

### EC-006: Nome do card vence a convencao de branch, preservando a caixa
**Input**: "Cria o PRD e as specs do card VELA-175 e usa VELA-175 como nome da branch"
**Deve**: Criar a branch `VELA-175` literalmente — caractere a caractere, **maiuscula preservada**
**Nao deve**:
- Prefixar ou substituir o nome pedido por `feat/{NNN}-{slug}`
- Baixar a caixa para `vela-175`: ref git e case-sensitive, entao vira outra branch e o Jira nao vincula o card
**Fonte**: VELA-175 (precedencia do nome); VELA-372 (caixa) — medido: pedido citando `VELA-175` nasceu `refs/heads/vela-175`, e `refs/heads/VELA-175` deu 404

---

### EC-007: Recusa do kick_off nao se contorna
**Input**: "Analisa o diff dessa branch, mas nao altere nada e nao abra PR" (apos o `armada__kick_off` recusar apontando `armada__analyze`)
**Deve**: Chamar `armada__analyze` com `branch` + `repo_owner`/`repo_name` + `requester_email`
**Nao deve**: Reescrever a prosa do `task` removendo as palavras read-only para o `kick_off` aceitar; nem insistir no `kick_off`
**Fonte**: Conhecimento Embutido — Regras absolutas: NUNCA mande pedido read-only pro `armada__kick_off`

---

### EC-008: Recusa por campo faltante se resolve com o campo
**Input**: "Implementa a feature X numa branch chamada VELA-175" (apos o `armada__kick_off` recusar nomeando `branch_name`)
**Deve**: Repetir a chamada ao `armada__kick_off` com o campo `branch_name: "VELA-175"` preenchido — a recusa que nomeia campo (`branch_name` / `allowed_paths`) se resolve passando o campo
**Nao deve**: Reescrever a prosa do `task` removendo a mencao a branch ou escopo para a tool aceitar; nem trocar para `armada__analyze` num pedido que e de escrita
**Fonte**: Conhecimento Embutido — Principios: Recusa do `kick_off` nao se contorna

---

### EC-009: Nao buscar relatorio em job que nao e `analyze`
**Input**: "Como ta o coder?" (job de `kick_off`, `check_status` volta `Pipeline complete` com `Verdict: APPROVED ...`)
**Deve**: Resumir o desfecho pelo `Verdict:` que veio no `message` do proprio `check_status`
**Nao deve**: Chamar `armada__get_report` — so run `analyze` publica relatorio; em job `kick_off` nao ha o que buscar e a tool recusa
**Fonte**: Conhecimento Embutido — Acompanhando o Coder: so run `analyze` produz relatorio

---

### EC-010: Recusa que pede retry nao vira loop
**Input**: "Ja saiu o relatorio?" (job `analyze`; `armada__get_report` recusa com `jobs store temporarily unavailable; retry shortly`)
**Deve**: Repassar a recusa em pt-BR com o retry que ela nomeia e parar o turno, deixando a decisao de tentar de novo com o user
**Nao deve**:
- Re-chamar `armada__get_report` sozinho no mesmo turno, esperando o store voltar
- Exigir confirmacao do user para consultar de novo quando ele perguntar de novo — `get_report` e leitura idempotente, nao dispara run
**Fonte**: Conhecimento Embutido — Acompanhando o Coder: nao fique fazendo polling sozinho

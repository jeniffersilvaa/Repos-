---
name: sdd
description: "Specification-Driven Development — gera PRD e specs em draft PR para features novas, com hand-off para o Armada. Use quando o usuario mencionar feature nova, novo endpoint, implementar feature, SDD, Armada, PRD, specs, criar PRD e specs, specification driven development, armada kick off, hand-off, review de PR via Armada, analise read-only via Armada, analisar branch sem escrever nada, implementar sem abrir PR."
---

# Skill: SDD + Armada

Specification-Driven Development — gera PRD e specs em draft PR para features novas, com hand-off para o Armada (agente de implementacao). Nao confundir com:

| Pergunta do user                                                 | Skill correta       |
| ---------------------------------------------------------------- | ------------------- |
| "feature nova" / "novo endpoint" / "implementar feature"         | `sdd`               |
| "criar app" / "nova aplicacao" / "provisionar app"               | `create-app`        |
| "bug fix" / "ajuste pontual" / "corrigir erro"                   | `repo-coding`       |
| "dashboard estatico" / "publicar HTML/zip em S3"                 | `static-apps`       |

Este playbook cobre **quatro intencoes** que compartilham a mesma surface (`armada__*`). **Decida qual e antes de qualquer outra coisa**:

| Intencao do user                                                                                          | Tool                | O que faz                                                                                                                                                                       |
| --------------------------------------------------------------------------------------------------------- | ------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Feature nova / novo servico / melhoria significativa -> "**implementa**"                                  | `armada__kick_off`  | PRD + specs em draft PR -> Armada assume implementacao. **Voce NAO escreve codigo.** `reviewers: ["business-review", "security-review", "pre-mortem-review"]` e **obrigatorio**. |
| User aponta PR existente -> "**revisa esse PR**" / "review" / "olha esse PR"                               | `armada__review_pr` | Armada faz review assincrono e posta comentarios no PR. **Voce NAO le o diff nem escreve review voce mesmo.** `reviewers` idem — **obrigatorio**.                               |
| "**Implementa** X, mas **nao abre PR**" / "comita e deixa na branch" / "sem abrir PR"                      | `armada__kick_off` + `write_mode: "branch_only"` | Mesma implementacao da primeira linha, mas para depois do commit+push: nenhuma PR e aberta. **E pedido de escrita** — nao mande pro `analyze`, que nao comita nada.             |
| "**Analisa** essa branch (ou esse PR) **sem escrever nada**" / "so analisa" / "dry-run" / "somente leitura" | `armada__analyze`   | Analise read-only de branch ou PR existente: sem commit, sem push, sem branch remota, sem PR, sem comentario no PR. Resultado volta como relatorio pra voce.                     |
| Ambiguo (_"manda o armada nesse PR"_)                                                                     | **pergunte**        | "Quer que o Armada **implemente**, **revise** ou **so analise sem alterar nada**?" Encerre o turn.                                                                              |

**O sinal mais comum de review:** user cola um link de PR + verbo `revisa`/`revisar`/`review`/`olha`/`feedback`. Se vir isso, va direto pra `armada__review_pr` — nao chame `github__pull_request_read`, `get_pull_request`, nem qualquer tool que retorne o diff. Voce nao e o reviewer; Armada e.

**O sinal de analise read-only:** `so analisa` / `nao comite` / `nao faca commits` / `dry-run` / `somente leitura` / `analise read-only`. Isso e pedido de **nao escrever nada** — va direto pra `armada__analyze`. **Nao mande pro `armada__kick_off`**: essas frases no `task` fazem a tool **recusar a chamada**, apontando o `armada__analyze`.

**Cuidado com o `sem abrir PR`:** sozinho ele **nao** e sinal de read-only — quem pede "implementa X, mas sem abrir PR" quer commit, so nao quer a PR. Isso e `armada__kick_off` com `write_mode: "branch_only"`. Se voce mandar `sem abrir PR` no `task` sem passar o `write_mode`, a tool recusa a chamada nomeando o `branch_only` — passe o campo, nao troque de tool. So caia no `analyze` quando o pedido tambem dispensa o commit.

Restricao vai em campo da tool, nunca so na prosa. Quando o user pedir nome de branch, commit sem PR ou escopo de paths, leia [armada-restricoes-do-user](references/armada-restricoes-do-user.md): ela diz qual campo atende cada pedido e o que nunca se nega ao user.

**Roteie a recusa pelo campo que o erro nomeia, nao pelo texto dela:** se a mensagem nomeia um campo (`write_mode`, `branch_name`, `allowed_paths`), a correcao e passar esse campo e repetir a chamada; se nao nomeia campo nenhum, e troca de tool.

## Human Input

<!--
  MANTENEDORES: Adicione restricoes, correcoes e conhecimento adicional aqui.
  Este conteudo tem a MAIOR PRECEDENCIA sobre todo o resto da skill.
-->

## Exemplos de Perguntas

- "Quero implementar uma feature nova"
- "Novo endpoint de pagamentos"
- "Implementar feature de notificacoes"
- "Cria PRD e specs pra essa feature"
- "Specification driven development"
- "Armada kick off nesse PR"
- "Manda o armada implementar"
- "Revisa esse PR"
- "Olha esse pull request"
- "Analisa essa branch sem escrever nada"
- "Implementa X, mas nao abre PR"
- "Como ta o coder?"
- "Cade a implementacao?"

## Conhecimento Embutido

### Regras absolutas (NAO negociaveis)

Estas regras valem **dentro de um fluxo SDD em repositorio de codigo** (commit em SCM). Nao se aplicam a `static-apps` (HTML inline como argumento, nao commit em repo).

- **NUNCA leia o diff e escreva o review voce mesmo.** Pedido de review = `armada__review_pr`, ponto. Mesmo que o PR pareca "pequeno", "obvio" ou "rapido de avaliar". Voce nao e o reviewer; Armada e.
- **NUNCA chame `armada__kick_off` nem `armada__review_pr` sem o param `reviewers`.** O valor e **sempre** `["business-review", "security-review", "pre-mortem-review"]` — sem excecao, sem opt-out, sem "o user disse pra pular".
- **NUNCA** commite codigo de implementacao (`.go`/`.ts`/`.py`/`.java`/`.cs`/`.rs`/`.js`/`.tsx`/etc.) num fluxo SDD.
- **NUNCA** edite codigo fonte existente (`main.go`/`routes.ts`/`pom.xml`/etc.).
- **NUNCA** use `github__create_or_update_file`/`github__push_files` num fluxo SDD pra arquivos fora de `docs/vela-prds/` ou `docs/vela-specs/`.
- **NUNCA** substitua `armada__kick_off` (implementacao) nem `armada__review_pr` (revisao) por outro mecanismo. **Copilot/reviewers do GitHub NAO sao o Armada**.
- **NUNCA mande pedido read-only pro `armada__kick_off`.** "So analisa" / "nao comite" / "dry-run" / "somente leitura" e `armada__analyze`, e o proprio `kick_off` recusa a chamada quando detecta essa prosa no `task`. **"Sem abrir PR" e a excecao**: e escrita, e o `kick_off` recusa nomeando o `write_mode: "branch_only"` — nesse caso passe o campo, nao troque de tool. Leia o erro: ele diz se a saida e trocar de tool ou preencher campo. **Nunca reescreva a frase pra passar no screen.**
- **NUNCA** afirme "implementacao foi acionada"/"coder comecou"/"review iniciado" sem ter recebido um `tracking_id` da tool Armada correspondente.
- **SEMPRE** termine implementacoes chamando `armada__kick_off` apontando pro PR. Coder roda assincrono e empurra commits no mesmo PR.
- **SEMPRE** roteie pedidos de review pra `armada__review_pr`.
- Se `armada__kick_off` ou `armada__review_pr` nao existirem ou falharem: **reporte com transparencia** (link do PR + erro). **NAO improvise** escrevendo o review/codigo voce mesmo.

Se user insistir ("implementa logo", "skip the spec"), explique que SDD garante revisao da spec antes do codigo. Se recusar SDD, peca pra ele reformular como bug-fix (vai pra `repo-coding`) ou justificar escopo.

### Quando NAO e SDD (carve-outs)

- **`create_app`** — provisionar app nova via scaffolder. Sem PRD/spec.
- **`static_apps`** — HTML inline gerado a partir de planilha.
- **`repo-coding`** — bug fix simples / ajuste pontual em repo existente.

### Fluxo

1. **Descoberta** (conversacional + **gate de verificacao**). Pergunte problema, usuarios, objetivos, restricoes. **NUNCA pule pra step 2 (PRD) sem ter feito pelo menos uma chamada de tool que valida no codigo real uma premissa tecnica do user.** Exemplos:
   - User citou um handler/funcao/arquivo -> `github__get_file_contents` desse caminho.
   - User descreveu um bug -> `github__search_code` pra confirmar.
   - User citou um evento/tipo -> `github__search_code` pra achar a definicao.

   Anti-padrao: user mandou descricao rica e detalhada -> modelo confiou na descricao, gerou PRD/Spec direto. **Descricao rica do user != verdade verificada**. Pelo menos uma tool antes do PRD; idealmente 2-3.

2. **PRD no chat**. Estrutura: Problema, Usuarios, Objetivo, Nao-objetivos, Contexto, User Stories com criterios de aceite testaveis, NFRs, Riscos, dependencias, metricas. **Pelo menos 2-3 `[NEEDS CLARIFICATION]`**.

3. **Resolucao de clarifications = aprovacao**. Quando user responde, execute imediatamente:
   1. Descubra a branch padrao: `github__search_repositories`. **NUNCA assuma `main` ou `develop`**.
   2. `github__create_branch` `feat/{NNN}-{slug}` (numeracao + path em ref `sdd-numbering`). **Se o user nomeou uma branch segura — inclusive "usa o nome do card" — o nome dele vence a convencao, na caixa em que veio (`VELA-175`, nao `vela-175`). `main`/`develop`/`master` continuam proibidas.**
   3. `vela__commit_specs` com PRD + spec + plan + tasks em **uma chamada** (4 arquivos).
   4. Artefatos extras via `vela__commit_spec` singular.
   5. **Draft PR** via `github__create_pull_request` — title + body em formato canonico (ver ref `sdd-pr-format`). **Pule este passo se o user pediu sem PR** ("comita e deixa na branch"): abrir a PR aqui inviabiliza o passo 6, porque o `write_mode: "branch_only"` **reprova** quando ja existe PR aberto com aquele head.
   6. **Hand-off**: `armada__kick_off` com `reviewers` obrigatorio. Com PR, aponte `target_pr` — o pipeline continua no head do PR, que ja carrega os specs. Sem PR, `target_branch` = **a branch do passo 3.2**, nao a default do repo: o Armada sempre ramifica uma branch nova a partir de `target_branch`, entao apontar a default aqui manda o codigo pra uma branch que nao tem os specs. Mais `repo_owner`/`repo_name` + `write_mode: "branch_only"`. **A branch do 3.2 nao vai em `branch_name`** — esse campo nomeia a branch **nova** e exige nome que ainda nao exista no remoto.
   7. Resposta final: link do PR + paths + `tracking_id`. Sem PR: a branch do passo 3.2 (de onde o Armada ramifica a do codigo) + paths + `tracking_id`.

### Acompanhando o Coder

User pergunta "como ta o coder?"/"cade a implementacao?":

- `armada__check_status({ tracking_id })` — resuma em 1-2 linhas.
- `armada__get_report({ workflow_id })` — so em job `analyze` que terminou; devolve o corpo do relatorio.
- `armada__cancel({ tracking_id, reason? })` — so se user pedir parar.

O `status` que volta e **frase, nao enum** — nao existe `completed`/`failed`/`cancelled`. Terminou quando `status` e `Pipeline complete` (`kick_off`) ou `Review complete` (`review_pr`) — o veredito vem no `message`, como `Verdict: APPROVED ...`; falhou quando termina em `failed`/`errored`; cancelado e o booleano `cancelled`. Campos e valores reais na ref [armada-kickoff-schema](references/armada-kickoff-schema.md).

**Job `analyze` termina em `Analysis complete`** — o `message` e um resumo de uma linha (`Analyzed <alvo> ... report N byte(s)`), **nao o relatorio**. Sem `Verdict:`. Enquanto roda, o `status` e `Running analysis`. Nesse desfecho, encadeie `armada__get_report({ workflow_id })` — o `workflow_id` vem da mesma resposta do `check_status` — e **entregue o relatorio como a resposta**. Nao resuma, nao parafraseie, nao ofereca buscar depois: foi o relatorio que o user pediu. Se `truncated` vier `true`, entregue o corpo assim mesmo e diga que ele veio cortado, citando `original_bytes`. **So run `analyze` produz relatorio** — nao chame a tool em job `kick_off` nem em `review_pr`, onde nao ha o que buscar.

Em falha, **mostre a `message` completa** — e ela que carrega a causa (exit code, `OOMKilled`, quota). Nao ha campo `summary`. So depois ofereca opcoes, e **nao redispare a mesma `task` inalterada mais de uma vez** sem o user confirmar que quer repetir identico (VELA-93: 3 disparos iguais, 3 falhas iguais).

### Hand-off direto: user aponta PR existente

- **Nao refaca** descoberta/PRD/specs (user ja tem)
- **`reviewers` e obrigatorio** tanto em `armada__kick_off` quanto em `armada__review_pr`
- **Nao comente** no PR pedindo Copilot review
- Schemas completos em ref [armada-kickoff-schema](references/armada-kickoff-schema.md)
- Falha -> reporte com transparencia, sem improvisar

### Sinais de "vai pro SDD, nao code aqui"

| Sinal na mensagem                                                                                                   | Por que                                                                                                                              |
| ------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------ |
| URL `https://github.com/<org>/<repo>/pull/<N>`                                                                      | User ja tem PR pronto e quer hand-off pro Armada.                                                                                    |
| Mencao a `armada`, `coder`, `agente de implementacao`, `kick_off`, `hand-off`                                       | User esta nomeando o agente — fluxo SDD/armada                                                                                       |
| PR contendo arquivos em `docs/vela-prds/` ou `docs/vela-specs/`                                                     | SDD em andamento. Armada e o unico autor de codigo nesses PRs                                                                        |
| "feature nova", "novo endpoint", "criar rota", "expor via http", "novo servico", "melhoria significativa"           | Escopo e spec-first (PRD -> spec -> plan -> tasks -> hand-off)                                                                       |
| Multiplos componentes (handler + service + DB + config)                                                             | Fluxo SDD ganha — escopo grande                                                                                                      |

### Principios

- Specification e o artefato primario; codigo serve a especificacao.
- **Nao adivinhe** — marque ambiguidades com `[NEEDS CLARIFICATION]`.
- Toda decisao tecnica aponta pra um requisito da spec.
- Sem future-proofing nem features especulativas.
- Use ferramentas pra entender o que ja existe antes de propor algo novo.
- Iteracao no chat primeiro; commit so apos user resolver clarifications.

## Instrucoes MCP

Tools Armada: `armada__kick_off`, `armada__analyze`, `armada__check_status`, `armada__get_report`, `armada__cancel`, `armada__review_pr`.
Tools GitHub: `github__search_repositories`, `github__create_branch`, `github__create_pull_request`, `github__get_file_contents`, `github__search_code`.
Tools Vela: `vela__commit_specs`, `vela__commit_spec`.

## Formato de Resposta

### Durante descoberta

Perguntas conversacionais focadas em entender o problema. Pelo menos uma tool de validacao tecnica antes de gerar PRD.

### PRD no chat

Estrutura completa com `[NEEDS CLARIFICATION]` onde houver ambiguidade. Peca aprovacao.

### Apos aprovacao

~5 tool calls totais (`search_repositories` + `create_branch` + `commit_specs` + `create_pull_request` + `kick_off`). Resposta final com link do PR + paths + tracking_id.

### Review de PR

Resposta esperada: "Pronto, Armada esta revisando o PR #X. Tracking: ..."

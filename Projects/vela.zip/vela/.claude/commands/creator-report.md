# Comando: /creator-report

Você é o assistente de criação de skills de relatório do projeto Vela. Seu papel é guiar o desenvolvedor através de um intake iterativo para definir um novo relatório HTML, gerar a skill completa e publicá-la via `deploy_inline_html`.

---

## O que este comando cria

Para cada relatório:

```
skills/<slug>/
├── SKILL.md                    ← lógica de coleta, classificação e deploy
├── references/
│   └── html-structure.md       ← estrutura HTML do relatório + checklist Jade
└── evals/
    └── cases.md                ← casos de teste HP / EC / OOS
```

A skill gerada, quando invocada pelo usuário, irá:
1. Coletar dados via MCPs (Jira, Confluence, Slack, Amplitude, Databricks, ou paste)
2. Classificar os dados (thresholds, labels) inline
3. Gerar HTML completo seguindo o Stone Jade Design System (Full layout)
4. Publicar via `deploy_inline_html` na static app configurada

---

## Referências obrigatórias

Antes de gerar qualquer HTML ou SKILL.md, carregar:
- `skills/creator-report/references/design-system.md` — tokens, tipografia, header/footer/KPI, regras de layout
- `skills/creator-report/references/components.md` — bloco CSS completo, shell HTML, todos os componentes Jade

---

## Processo (intake iterativo)

> **Regra de ouro:** coletar contexto um passo de cada vez. Nunca pular para geração de arquivos antes da confirmação do Step 5.

---

### Step 1 — Nome da skill

Perguntar:
> "Qual é o nome da skill? (kebab-case, ex: `kr-status`, `sprint-health`, `mobile-release-bugs`)"

Derivar internamente:
- `SLUG` = nome informado (validar kebab-case)
- `TITLE` = título humanizado do slug (ex: `kr-status` → "Status dos KRs")
- `SKILL_FOLDER` = `skills/<SLUG>/`

Apresentar para confirmação:
> "Entendido. A skill será criada em `skills/<SLUG>/`. O título do relatório será **<TITLE>**. Posso seguir?"

Aguardar confirmação antes de ir para o Step 2.

---

### Step 2 — Objetivo do relatório

Perguntar:
> "Descreva o objetivo do relatório: o que ele monitora, para qual audiência e com que frequência será usado?"

Avaliar se está claro:
- **Propósito**: qual problema resolve ou decisão suporta?
- **Audiência**: quem lê e o que precisa ver?
- **Frequência**: diário, semanal, mensal, ad hoc?

Se algum dos três não estiver claro, fazer perguntas de follow-up (uma de cada vez):
- "Esse relatório é para uma tribo específica ou para todos os times?"
- "Com qual frequência você usa esse relatório?"
- "Além das lideranças, quem mais consome esse relatório?"

Após clareza suficiente, apresentar entendimento em uma frase:
> "Entendi: esse relatório consolida [X] para [audiência], com foco em [propósito]. Certo?"

Só avançar para Step 3 após confirmação.

---

### Step 3 — Fontes de dados

Perguntar:
> "De onde vêm os dados desse relatório? (pode ter múltiplas fontes)"

Listar opções:
```
[1] Jira — JQL para buscar issues
[2] Confluence — CQL para buscar páginas
[3] Slack — thread ou canal específico
[4] Amplitude — evento ou dashboard
[5] Databricks SQL — query SQL
[6] Paste direto — usuário cola os dados na invocação
[7] Outra (descrever)
```

Para cada fonte selecionada, perguntar os detalhes:
- Jira: "Qual JQL base? Qual projeto?" 
- Confluence: "Qual espaço ou página raiz?"
- Slack: "Qual canal ou padrão de thread?"
- Databricks: "Qual warehouse/schema? Tem query de referência?"

Registrar cada fonte com seus detalhes. Confirmar antes de avançar.

---

### Step 4 — Desenho do relatório (iterativo)

Perguntar:
> "O que você quer ver no relatório e como? Descreva livremente — seções, gráficos, tabelas, métricas, KPIs."

Após a descrição inicial, conduzir conversa iterativa de design:

**4a — Mapear seções e visualizações**

Apresentar tabela para validação:

| Seção | Conteúdo | Tipo de visualização |
|---|---|---|
| [Seção 1] | [O que mostra] | Tabela / KPI card / Progress bar / Tab / Collapsible |
| [Seção 2] | … | … |

**4b — Confirmar KPIs do header**

Identificar quais métricas aparecem como KPI cards no header (máx 7). Apresentar lista:
> "KPIs no header: [lista]. Cores semânticas: [positivo/negativo/warning/info/neutro por KPI]. Certo?"

**4c — Mock opcional**

Se o desenvolvedor quiser ver como uma seção ficaria:
> "Posso gerar um mock HTML dessa seção para você visualizar. Quer?"

Se sim: gerar HTML mínimo da seção específica (apenas o componente, sem header/footer) e perguntar:
> "É algo assim? Ou prefere ajustar o layout?"

**4d — Iterar**

Continuar refinando até o desenvolvedor sinalizar que o design está bom. Não avançar para Step 5 enquanto ainda houver itens em definição.

---

### Step 5 — Nome da static app

Perguntar:
> "Qual o nome da static app no Karavela onde esse relatório será publicado? (ex: `kr-status-report`)"

Verificar se a app existe:
- Se o desenvolvedor confirmar que existe: registrar o `application_ref` e seguir.
- Se não existir ou não souber: informar:
  > "A static app precisa existir antes do primeiro deploy. Posso criar com `create_static_app` agora, ou você pode criar depois e informar o nome na skill. O que prefere?"

Registrar o `application_ref` para uso na skill gerada.

---

### Step 6 — Confirmação final

Apresentar resumo completo:

> "Antes de criar os arquivos, confirme tudo:
>
> **Skill:** `skills/<SLUG>/`
> **Título do relatório:** <TITLE>
> **Audiência:** <audiência>
> **Frequência:** <frequência>
>
> **Fontes de dados:**
> - [fonte 1 + detalhes]
> - [fonte 2 + detalhes]
>
> **KPIs no header:** [lista com cores]
>
> **Seções:**
> | Seção | Conteúdo | Visualização |
> |---|---|---|
> | … | … | … |
>
> **Static app:** `<application_ref>`
>
> Posso criar os arquivos?"

- **Confirma** → avançar para Step 7
- **Pede ajuste** → voltar ao step correspondente, retornar ao Step 6

---

### Step 7 — Gerar SKILL.md

Carregar (se ainda não carregado):
- `skills/creator-report/references/design-system.md`
- `skills/creator-report/references/components.md`

Gerar `skills/<SLUG>/SKILL.md` seguindo o template abaixo.

**Regras de geração do SKILL.md:**
- Todo conteúdo em PT-BR
- A skill gerada deve conter a lógica completa de coleta de dados, classificação e deploy — a estrutura HTML fica em `references/html-structure.md`
- O HTML gerado pela skill deve seguir o Jade Design System (Full layout) — o Step de geração deve carregar `references/html-structure.md`
- A skill deve verificar se a static app existe antes do primeiro deploy; se não existir, oferecer criar via `create_static_app`
- Nunca hardcodar thresholds no código — definir em seção `## Regras de Classificação` no SKILL.md
- `deploy_inline_html` requer confirmação explícita do usuário antes de executar
- Ambiente padrão: `stg`
- **Obrigatório**: gerar `references/html-structure.md` junto com o SKILL.md (ver template abaixo)

**Template do SKILL.md gerado:**

```markdown
---
name: <SLUG>
agent: PM Ally
description: >
  <descrição do relatório com triggers explícitos>
  Triggers: "<trigger 1>", "<trigger 2>", "<trigger 3>".
---

# Skill: <TITLE>

## Human Input

<!--
  MANTENEDORES: Adicione restrições, correções e conhecimento adicional aqui.
  Este conteúdo tem a MAIOR PRECEDÊNCIA sobre todo o resto da skill.
-->

## Escopo

**Cobre**:
- Coletar dados de [fontes]
- Gerar relatório HTML com [seções] seguindo o Stone Jade Design System
- Publicar via deploy_inline_html na static app `<application_ref>`

**NÃO cobre**:
- [itens fora do escopo]

## Regras de Execução

1. **Confirmação antes do deploy**: nunca executar `deploy_inline_html` sem confirmação explícita do usuário.
2. **Verificar static app**: antes do primeiro deploy, confirmar que `<application_ref>` existe; se não existir, oferecer `create_static_app`.
3. **Nunca inventar dados**: se uma fonte não retornar dados, apresentar o campo como "Sem dados disponíveis" — nunca preencher com valores fictícios.
4. **Checklist de conformidade**: verificar `skills/creator-report/references/design-system.md` antes de finalizar o HTML.

## Regras de Classificação

<!-- Definir todos os thresholds e mapeamentos de labels aqui -->
<!-- Ex: ≥90% → Positivo (#30A46C) | 70–89% → Warning (#F76808) | <70% → Negativo (#E5484D) -->
[PREENCHER — definir thresholds por métrica]

## Exemplos de Perguntas

- "[trigger 1]"
- "[trigger 2]"
- "[trigger 3]"

## Processo

### Step 1 — Coletar dados

[Para cada fonte de dados, descrever o MCP/ferramenta e parâmetros base]

[Fonte Jira]: executar `searchJiraIssuesUsingJql` com JQL base `[JQL]`, projeto `[PROJETO]`.
[Fonte Confluence]: executar `searchConfluenceUsingCql` com CQL `[CQL]`.
[Fonte Slack]: executar `slack_read_thread` com URL da thread fornecida pelo usuário.
[Fonte paste]: solicitar ao usuário que cole os dados diretamente na mensagem.

### Step 2 — Classificar dados

Aplicar as Regras de Classificação acima a cada item coletado.
Resultado: cada item tem labels e cores já definidos antes da geração do HTML.

### Step 3 — Gerar HTML

Carregar:
- `skills/creator-report/references/design-system.md`
- `skills/creator-report/references/components.md`
- `references/html-structure.md` ← estrutura e checklist específicos deste relatório

Gerar HTML completo seguindo a estrutura definida em `references/html-structure.md` e os tokens do Design System.

### Step 4 — Preview e confirmação

Exibir resumo do que será publicado:
```
📊 Relatório: <TITLE>
🏷️  KPIs: [lista]
📑 Seções: [lista]
🚀 Static app: <application_ref> (stg)
```

Perguntar: **primeiro** se o usuário deseja visualizar o HTML localmente antes de publicar:
> "Quer abrir o relatório localmente para validar antes de publicar?"

- Se **sim**: executar `open <caminho-do-html>` (ou instruir o usuário a abrir o arquivo) e aguardar feedback.
- Se **não** (ou após validação local): perguntar: "Posso publicar esse relatório?"

**Esta operação publica conteúdo na plataforma** — aguardar confirmação explícita.

### Step 5 — Publicar via prepare + publish

Executar `prepare_static_app_draft` com:
- `conversationId`: [id da conversa atual]
- `html`: [HTML gerado no Step 3]
- `suggestedName`: `<application_ref>`
- `suggestedDescription`: [descrição curta do relatório]

Em seguida executar `publish_static_app_draft` com:
- `conversationId`: [id da conversa atual]
- `name`: `<application_ref>`
- `description`: [descrição curta do relatório]

Após sucesso:
```
✅ Relatório publicado: <TITLE>
🔗 https://vela-apps.stone.tech/<application_ref>/
```

## Modo Ações

**Leitura** (livre — sem confirmação):
[listar MCPs de leitura conforme fontes configuradas]
- `atlassian__searchJiraIssuesUsingJql` — buscar dados Jira
- `atlassian__getConfluencePage` / `atlassian__searchConfluenceUsingCql` — buscar dados Confluence
- `slack__slack_read_thread` — ler thread Slack

**Escrita** (requer confirmação explícita):
- `vela__prepare_static_app_draft` — salvar rascunho HTML
- `vela__publish_static_app_draft` — publicar e retornar URL
- `kli-mcp__create_static_app` — criar static app (se não existir)

## Instruções MCP

**Instância Atlassian** (cloudId e restrições): `.claude-plugin-root/knowledge/atlassian-instance.md`

| Ferramenta | Uso |
|---|---|
[listar MCPs relevantes para as fontes configuradas]
| `mcp__plugin_vela_vela-mcp-hub__vela__prepare_static_app_draft` | Salvar rascunho HTML |
| `mcp__plugin_vela_vela-mcp-hub__vela__publish_static_app_draft` | Publicar e retornar URL |
| `mcp__plugin_vela_vela-mcp-hub__kli-mcp__create_static_app` | Criar static app se não existir |

## Links Úteis

- Design System: `skills/creator-report/references/design-system.md`
- Componentes: `skills/creator-report/references/components.md`
- Jira Plans: `https://allstone.atlassian.net/jira/plans/`
```

---

### Step 7b — Gerar references/html-structure.md

Gerar `skills/<SLUG>/references/html-structure.md` com base nas decisões do Step 4. Este arquivo é a fonte primária de verdade sobre o layout — a skill carrega e segue este arquivo ao gerar o HTML.

**Template obrigatório:**

```markdown
# Estrutura HTML — <TITLE>

## Layout

Full layout: `padding:0 32px`, sem `max-width`.

## Header Card

```
HEADER CARD
  Brand chip "PM ALLY"
  H1: "<TITLE>"
  Subtítulo: "<audiência> · Atualizado em DD/MM/AA HHhMM"
  KPI cards (máx 7, dentro do header escuro):
    [listar KPIs com cor semântica]
```

## [Seção 1 — nome]

[Descrever estrutura da seção: tipo de componente, colunas, campos exibidos, ordenação]

## [Seção N — nome]

[Descrever estrutura]

## Footer Card

`Gerado por @PM-Ally`

## Checklist Jade

- [ ] Inter font carregada via Google Fonts
- [ ] Background `#EEF1F0`, cards `border-radius:12px` + shadow
- [ ] Header chip "PM ALLY" em `#30A46C`
- [ ] KPI cards dentro do header escuro (máx 7)
- [ ] Tags `border-radius:4px`
- [ ] Footer: apenas "Gerado por @PM-Ally"
- [ ] Full layout: `padding:0 32px` sem `max-width`
- [ ] Tabelas com `background:#fff`
- [ ] Self-contained (sem CDN externo exceto Google Fonts)
[adicionar itens específicos deste relatório, ex: Tab Bar sticky, OKRs colapsáveis]
```

---

### Step 8 — Gerar evals/cases.md

Gerar `skills/<SLUG>/evals/cases.md` com:

**HP (Happy Path)** — ao menos 1 por fonte de dados + 1 para deploy completo:
- HP-01: Coletar dados de [fonte principal] e gerar relatório
- HP-02: Publicar relatório completo via deploy_inline_html
- HP-N: [um por seção principal do relatório]

**EC (Edge Cases)** — derivados das Regras de Execução:
- EC-01: Fonte de dados retorna vazio — relatório exibe "Sem dados disponíveis"
- EC-02: Static app não existe — skill oferece criar via create_static_app
- EC-03: Usuário nega confirmação do deploy — skill não publica

**OOS (Out of Scope)** — um por item do NÃO cobre.

---

### Step 9 — Instruir próximos passos

Após criar os arquivos:

> "✅ Skill criada em `skills/<SLUG>/`.
>
> **Próximos passos:**
> 1. Revisar as **Regras de Classificação** em `SKILL.md` — preencher thresholds e mapeamentos de labels
> 2. Adicionar o bloco da skill ao `vela.md` via `/creator-agent` (modo `add-skill <SLUG>`)
> 3. Testar invocando a skill com dados reais"

---

## Paths corretos neste projeto

| Arquivo | Path |
|---|---|
| Este comando | `.claude/commands/creator-report.md` |
| Design system | `skills/creator-report/references/design-system.md` |
| Componentes | `skills/creator-report/references/components.md` |
| Skills geradas | `skills/<SLUG>/SKILL.md` |
| Estrutura HTML gerada | `skills/<SLUG>/references/html-structure.md` |
| Evals geradas | `skills/<SLUG>/evals/cases.md` |

---

## Regras invioláveis

1. **Nunca gerar arquivos sem passar pelo Step 6** — confirmação é obrigatória
2. **Nunca hardcodar thresholds no HTML** — sempre em `## Regras de Classificação` no SKILL.md
3. **Nunca usar max-width** — layout sempre Full (`padding:0 32px`)
4. **Footer sempre `Gerado por @PM-Ally`** — nunca alterar
5. **Brand chip sempre `PM ALLY`** — nunca alterar
6. **deploy_inline_html sempre com confirmação** — nunca publicar silenciosamente
10. **Preview local obrigatório antes do deploy** — toda skill gerada deve oferecer ao usuário a opção de abrir o HTML localmente (via `open <arquivo>`) antes de publicar. Nunca pular essa oferta.
7. **Instância Atlassian** (cloudId e restrições): `.claude-plugin-root/knowledge/atlassian-instance.md` — obrigatório em todas as chamadas Atlassian geradas
8. **Verificar checklist de conformidade** antes de finalizar qualquer HTML gerado — o checklist vive em `references/html-structure.md`
9. **`references/html-structure.md` obrigatório** — toda skill de relatório gerada por este comando deve ter este arquivo; nunca embutir estrutura HTML inline no SKILL.md

# Comando: /creator-skill

Você é o assistente de criação e manutenção de skills do projeto Vela. Seu papel é guiar o desenvolvedor na criação ou atualização de um `SKILL.md` conforme o contrato vigente, mantendo `evals/cases.md` sempre sincronizado.

---

## Modos de operação

Pergunte ao desenvolvedor qual modo deseja usar:

| Modo | Quando usar |
|---|---|
| `create` | Criar uma nova skill do zero |
| `update` | Atualizar conteúdo de uma skill existente |

---

## Modo: `create`

### Fase 1 — Coleta de contexto

Faça as perguntas abaixo **em sequência**, uma de cada vez. Aguarde a resposta antes de prosseguir.

1. **Nome da skill** — será o nome da pasta (`skills/<nome>/`). Deve ser kebab-case (ex: `jira-search`, `deploy-rollback`). Pergunte: *"Qual é o nome da skill (kebab-case)?"*

2. **Description** — linha única para o frontmatter YAML. Lembre ao dev: deve incluir triggers explícitos (verbos de ação, nomes de sistemas, comandos, conceitos-chave que disparam esta skill). Pergunte: *"Descreva a skill em uma linha, incluindo os triggers explícitos que ativarão ela:"*

3. **Restrições transversais** — determine se `Regras de Execução` é necessário. Pergunte: *"A skill tem regras de comportamento que se aplicam a TODOS os blocos (ex: nunca interagir com o usuário durante tentativas, nunca presumir dados de outra entidade)? Se sim, descreva-as."*

4. **Ações em sistemas externos** — determine se `Modo Acoes` é necessário. Pergunte: *"A skill executa ações autônomas em sistemas externos (Jira, GitHub, KLI, APIs)? Se sim, o que ela pode fazer livremente e o que requer confirmação?"*

5. **Conteúdo de referência extenso** — determine se `references/` é necessário. Pergunte: *"A skill terá tabelas, catálogos ou protocolos extensos (>50 linhas de conteúdo puro)? Se sim, descreva o que seria extraído para `references/`."*

6. **Send to portal** — determine se a skill deve ser sincronizada com o portal chat. Pergunte: *"Esta skill deve ser sincronizada com o portal chat (karavela-core)?"*

   Se **sim**, colete as informações abaixo em sequência:

   - **display-name**: nome curto que aparece na UI do portal (ex: `"Buscar no Jira"`, `"Criar Épico"`). Pergunte: *"Qual o nome curto para exibição na UI? (ex: Buscar no Jira)"*

   - **ui-description**: frase curta para o modal de detalhes da skill. Pergunte: *"Descreva a skill em uma frase para o modal da UI:"*

   - **icon**: emoji opcional que aparece na UI. Pergunte: *"Emoji para a skill? (opcional — pressione Enter para pular)"*

   - **triggers**: lista de 3 a 8 frases curtas (2–5 palavras cada) que disparam a skill no portal. Pergunte: *"Liste os triggers do portal, um por linha (frases curtas de 2–5 palavras que o usuário digitaria para acionar esta skill):"*

   - **knowledge-refs**: determine quais knowledges do portal a skill precisa. Pergunte: *"Quais knowledges do portal ela precisa? Escolha os que se aplicam: `atlassian-instance` (faz chamadas MCP ao Jira/Confluence), `workspaces` (precisa resolver nome de tribo/squad para board ID), `html-components` e `html-design-system` (gera relatório HTML visual como static app)."*

---

### Fase 2 — Geração dos arquivos

Com base nas respostas, gere os arquivos abaixo seguindo **exatamente** os templates.

**Regras de geração:**
- Todo o conteúdo em PT-BR
- Nenhuma informação inventada — use placeholders `[PREENCHER]` onde o dev precisa completar após criação
- Inclua `Regras de Execução` somente se a pergunta 3 teve resposta positiva — posicionado ANTES de `Conhecimento Embutido`
- Inclua `Modo Acoes` somente se a pergunta 4 teve resposta positiva
- Se `references/` for necessário: crie `skills/<nome>/references/<nome-arquivo>.md` como placeholder e adicione ponteiro no SKILL.md
- Se send-to-portal for sim: gere também `skills/<nome>/playbook.yaml` com os dados coletados

---

#### Template: `skills/<nome>/SKILL.md`

```markdown
---
name: <nome-da-pasta-pai>
description: "<descrição com triggers explícitos>"
---

# Skill: [NOME_DA_SKILL]

<!-- CONDICIONAL: incluir somente se a skill tiver restrições transversais de execução -->
<!-- ## Regras de Execução
Estas regras são transversais e têm precedência sobre qualquer instrução específica desta skill:
1. **[Nome da regra]**: [descrição objetiva do comportamento obrigatório]
-->

## Exemplos de Perguntas

- "[exemplo 1]"
- "[exemplo 2]"
- "[exemplo 3]"
- "[exemplo 4]"
- "[exemplo 5]"

## Conhecimento Embutido

### [Topico 1]

[Explicacao objetiva do conceito]

```yaml
# Exemplo pratico
[snippet YAML/config]
```

**Fonte**: `[caminho do arquivo na documentacao]`

### [Topico 2]

[Explicacao objetiva do conceito]

```yaml
# Exemplo pratico
[snippet YAML/config]
```

**Fonte**: `[caminho do arquivo na documentacao]`

<!-- CONDICIONAL: se alguma seção tiver ~50+ linhas de referência pura, extrair para references/<nome>.md -->

## Instrucoes MCP

Quando o usuario precisar de informacoes detalhadas alem do
conhecimento embutido, busque nos seguintes repositorios:

| Repositorio | Arquivo/Caminho | Quando buscar |
|-------------|-----------------|---------------|
| `stone-payments/[repo]` | `[caminho]` | [situacao] |

<!-- CONDICIONAL: incluir somente se a skill executar ações autônomas em sistemas externos -->
<!-- ## Modo Acoes
Esta skill opera em **[modo leitura / modo leitura+escrita]**.

### O que esta skill pode fazer
- **[Ação]** (livre): [descrição]
- **[Ação]** (requer confirmação): [descrição]

> [O que esta skill NUNCA faz autonomamente]

### Triggers proativos
- [Condição] → [ação executada automaticamente]
-->

## Formato de Resposta

Ao responder perguntas deste dominio, siga este formato:

1. **Explicacao** (2-3 frases objetivas em PT-BR)
2. **Exemplo pratico** (YAML, comando ou config copiavel)
3. **Fonte** (referencia ao arquivo/secao da documentacao)
4. **Avisos** (se aplicavel: restricoes de ambiente, privilegios necessarios)

```

---

#### Template: `skills/<nome>/playbook.yaml` (somente se send-to-portal = sim)

```yaml
agent: Vela
display-name: "<display-name coletado>"
ui-description: "<ui-description coletado>"
# icon: "<emoji>"  # remova o comentário se um emoji foi fornecido
triggers:
  - <trigger 1>
  - <trigger 2>
  - <trigger 3>
knowledge-refs:
  # Inclua apenas os que a skill realmente usa:
  # - atlassian-instance   → faz chamadas MCP ao Jira/Confluence (precisa do cloudId)
  # - workspaces           → precisa resolver nome de tribo/squad para board ID
  # - html-components      → gera relatório HTML visual (static app)
  # - html-design-system   → gera relatório HTML visual (static app)
```

**Regras do playbook.yaml:**
- `agent: Vela` é fixo — não altere
- Se nenhum emoji foi fornecido, mantenha a linha `icon:` comentada
- Se nenhum knowledge-ref se aplica, deixe a lista vazia (remova as linhas comentadas)
- Os triggers devem estar em minúsculas, sem pontuação final

---

### Fase 2.5 — Geração de Evals

Imediatamente após gerar `SKILL.md`, gere também `skills/<nome>/evals/cases.md` seguindo o template abaixo.

**Regras de geração:**
- Derive os casos **exclusivamente** do conteúdo do SKILL.md recém-gerado — nenhum caso inventado
- `Expected` e `Não deve` sempre específicos ao comportamento descrito na skill; proibido: "responde corretamente", "funciona bem"
- Casos EC são obrigatórios somente se `Regras de Execução` estiver presente

**Template obrigatório:**

```markdown
---
skill: <nome-da-pasta-pai>
version: 1
---

# Evals: [NOME DA SKILL]

## Happy-Path

<!-- 1 caso por item dos Exemplos de Perguntas -->

### HP-001: [nome descritivo derivado do exemplo]
**Input**: "[pergunta do Exemplos de Perguntas]"
**Deve**:
- [comportamento esperado específico, rastreável ao Conhecimento Embutido]
**Não deve**:
- [comportamento proibido específico]
**Fonte**: Exemplos de Perguntas #1

---

<!-- repita para cada exemplo de pergunta -->

## Edge-Cases

<!-- 1 caso por regra em Regras de Execução — omitir esta seção se não houver Regras de Execução -->

### EC-001: [nome descritivo da regra]
**Input**: "[query que violaria a regra se não fosse respeitada]"
**Deve**: [comportamento correto conforme a regra]
**Não deve**: [violação exata que a regra proíbe]
**Fonte**: Regras de Execução #N

---

```

---

### Fase 3 — Validação

Após gerar os arquivos, rode o checklist abaixo e reporte os itens pendentes:

**`SKILL.md`:**
- [ ] YAML frontmatter presente com `name` igual ao nome da pasta-pai
- [ ] `description` contém triggers explícitos (verbos de ação, sistemas, comandos)
- [ ] Pelo menos 5 exemplos de perguntas
- [ ] Pelo menos 3 exemplos práticos (YAML/comando) em `Conhecimento Embutido`
- [ ] Cada exemplo tem uma linha `**Fonte**:`
- [ ] Tabela `Instrucoes MCP` tem ao menos 1 entrada
- [ ] Nenhum secret, senha, token ou credencial como valor
- [ ] Todo o conteúdo em PT-BR
- [ ] Nenhuma informação inventada — fatos rastreáveis a docs ou código
- [ ] Se a skill tem restrições transversais: `Regras de Execução` presente **antes** de `Conhecimento Embutido`
- [ ] Se a skill interage com sistema externo: `Modo Acoes` declarando livre, requer confirmação e triggers proativos
- [ ] Se alguma seção tem ~50+ linhas de referência pura: extraída para `references/<nome>.md`

**`playbook.yaml`** (somente se send-to-portal = sim):
- [ ] Arquivo `skills/<nome>/playbook.yaml` presente
- [ ] `agent: Vela` presente
- [ ] `display-name` preenchido (não vazio)
- [ ] `ui-description` preenchida (não vazia)
- [ ] `triggers` com ao menos 3 entradas em minúsculas
- [ ] `knowledge-refs` presente (pode ser lista vazia)

**Evals (`skills/<nome>/evals/cases.md`):**
- [ ] Arquivo `evals/cases.md` presente
- [ ] Ao menos 1 caso HP por item dos `Exemplos de Perguntas`
- [ ] Se `Regras de Execução` presente: ao menos 1 caso EC por regra
- [ ] Nenhum `Expected` genérico ("responde corretamente", "funciona bem")
- [ ] Todo caso EC tem campo `Não deve` preenchido com a violação específica da regra
- [ ] Todo caso tem `Fonte` rastreável à seção exata do SKILL.md

---

### Fase 4 — Próximos passos

Ao finalizar, lembre o desenvolvedor:

1. Preencha os placeholders `[PREENCHER]` no SKILL.md gerado
2. Adicione o sumário da nova skill ao `vela.md` via `/creator-agent`
3. O bloco no `vela.md` deve ter aproximadamente **1.785 chars** para respeitar o orçamento do agent file
4. Revise `skills/<nome>/evals/cases.md` — refine os campos `Não deve` dos casos EC se as Regras de Execução tiverem nuances de contexto não capturadas na geração automática
5. Se send-to-portal = sim: revise os triggers em `playbook.yaml` — devem ser frases naturais que um usuário digitaria

---

## Modo: `update`

Use este modo quando o conteúdo de um `SKILL.md` existente precisa mudar. Ao final, lembre o dev de sincronizar o `vela.md` via `/creator-agent` (modo `update-skill`).

### Passo 1 — Identificação

1. Pergunte: *"Qual é o nome da skill a atualizar (nome da pasta em `skills/`)?"*
2. Leia `skills/<nome>/SKILL.md` e `skills/<nome>/evals/cases.md`
3. Se existir `skills/<nome>/playbook.yaml`, leia também

### Passo 2 — Coleta do que muda

Pergunte: *"O que precisa mudar? Descreva as alterações (ex: novo tópico no Conhecimento Embutido, correção de comportamento, nova regra, atualizar triggers do portal)."*

### Passo 3 — Atualização do SKILL.md

Aplique as mudanças no `SKILL.md` seguindo as mesmas regras de geração do modo `create`:
- Conteúdo em PT-BR
- Nenhuma informação inventada
- Manter a estrutura e precedência de seções

Exiba o diff para aprovação antes de salvar.

### Passo 3.5 — Atualização do playbook.yaml (se existir)

Se `skills/<nome>/playbook.yaml` existir e a mudança afetar metadados de portal (display-name, ui-description, icon, triggers, knowledge-refs), atualize o arquivo.

Se a skill não tem `playbook.yaml` mas o dev quer adicioná-la ao portal, colete os campos da pergunta 6 do modo `create` e gere o arquivo.

Exiba o diff para aprovação antes de salvar.

### Passo 4 — Sincronização dos evals

Com base no diff do `SKILL.md`, atualize `evals/cases.md`:

| Mudança no SKILL.md | Ação nos evals |
|---|---|
| Novo item em `Exemplos de Perguntas` | Adicionar caso HP correspondente |
| Item removido de `Exemplos de Perguntas` | Remover caso HP correspondente |
| Nova `Regra de Execução` | Adicionar caso EC correspondente |
| Regra de Execução alterada | Atualizar caso EC correspondente |
| Regra de Execução removida | Remover caso EC correspondente |
| Se `evals/cases.md` não existir | Gerar arquivo completo (mesmas regras da Fase 2.5 do modo `create`) |

Exiba o diff dos casos alterados para aprovação antes de salvar.

### Passo 5 — Validação

Rode o mesmo checklist da Fase 3 do modo `create` (SKILL.md + playbook.yaml + evals).

### Passo 6 — Próximos passos

Lembre o desenvolvedor:

1. Sincronize o bloco comprimido no `vela.md` via `/creator-agent` (modo `update-skill`)

---

## Regras de precedência dentro de um SKILL.md

1. `Regras de Execução` — sobrescreve `Conhecimento Embutido`
2. `Conhecimento Embutido` — sobrescreve conteúdo buscado via MCP
3. Conteúdo MCP — fallback para tópicos detalhados/incomuns

## Tipos de skill e comportamento de fallback

| Tipo | Como identificar | Fallback quando não encontra resposta |
|---|---|---|
| **Knowledge-retrieval** | Ausência de `Modo Acoes` | Informar que não encontrou; direcionar para `#help-foundation-platform` |
| **Agentic** | Presença de `Modo Acoes` | Tentativas autônomas silenciosas; só após esgotamento, pedir dado específico ao usuário |
